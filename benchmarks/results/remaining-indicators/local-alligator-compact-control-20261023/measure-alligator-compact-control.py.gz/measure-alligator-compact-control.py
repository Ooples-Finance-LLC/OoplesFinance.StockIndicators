from pathlib import Path
import datetime, hashlib, json, os, psutil, shutil, subprocess

ROOT = Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
BASE = Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC')
OLD = BASE/'si-cci-wide-grid-20261022'
NEW = BASE/'si-alligator-compact-20261022'
OUT = ROOT/'local-alligator-compact-control-20261023'
REL = Path('benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks/bin/Release/net10.0')
DLL = 'OoplesFinance.StockIndicators.dll'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def manifest(p): return {f.relative_to(p).as_posix():digest(f) for f in p.rglob('*') if f.is_file()}
def head(p): return subprocess.check_output(['git','rev-parse','HEAD'],cwd=p,text=True).strip()

qualification=json.loads((ROOT/'alligator-compact/status.json').read_text(encoding='utf-8'))
assert qualification['status']=='checks-passed-review-and-publication-pending'
assert qualification['gpu_passed']==100 and qualification['parity']['passed']==20 and qualification['unit']['passed']==11
old_qualification=json.loads((ROOT/'cci-wide-grid/status.json').read_text(encoding='utf-8'))
assert old_qualification['gpu_passed']==100 and old_qualification['status']=='checks-passed-review-and-publication-pending'
assert digest(OLD/REL/DLL) in old_qualification['production_dll_sha256'].values()
assert not subprocess.check_output(['git','diff',old_qualification['input_head'],head(OLD),'--','src','tests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','benchmarks/OoplesFinance.StockIndicators.CompetitorTests','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json'],cwd=OLD)
assert digest(NEW/REL/DLL) in qualification['production_dll_sha256'].values()
# Only the three reviewed files may differ in executable/build inputs.
changed=subprocess.check_output(['git','diff','--name-only',head(OLD),head(NEW),'--','src','tests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','benchmarks/OoplesFinance.StockIndicators.CompetitorTests','Directory.Build.props','Directory.Build.targets','global.json'],cwd=NEW,text=True).splitlines()
assert set(changed)=={'src/Indicators/ValuesBarExecution.Alligator.cs','src/Indicators/GatorWithDetails.cs','tests/ModelsTests/AlligatorSharedExecutionTests.cs'},changed
original=manifest(OLD/REL)
arms={'old':OLD/REL,'new':OUT/'new'}
if OUT.exists():
 saved=json.loads((OUT/'provenance.json').read_text(encoding='utf-8'))
 assert saved['old_source']==head(OLD) and saved['new_source']==head(NEW)
 assert saved['candidate_code_source']==qualification['input_head']
 manifests=json.loads((OUT/'binary-manifest.json').read_text(encoding='utf-8'))
 assert all(manifest(arms[a])==manifests[a] for a in ['old','new'])
 state=json.loads((OUT/'status.json').read_text(encoding='utf-8'))
 assert state['status']=='paused-for-independent-correctness'
 assert state['order']==['old','new','new','old']
 for record in state['rounds']:
  assert digest(Path(record['report']))==record['sha256']
else:
 assert shutil.disk_usage(ROOT).free > sum(p.stat().st_size for p in (OLD/REL).rglob('*') if p.is_file()) + 1024**3
 OUT.mkdir()
 original=manifest(OLD/REL)
 arms={'old':OLD/REL,'new':OUT/'new'}
 assert manifest(arms['old'])==original
 shutil.copytree(arms['old'],arms['new'])
 shutil.copy2(NEW/REL/DLL,arms['new']/DLL)
 manifests={arm:manifest(arms[arm]) for arm in ['old','new']}
 assert manifests['old']==original
 assert manifests['old'].keys()==manifests['new'].keys()
 assert [p for p in original if manifests['old'][p]!=manifests['new'][p]]==[DLL]
 (OUT/'binary-manifest.json').write_text(json.dumps(manifests,indent=2),encoding='utf-8')
 (OUT/'provenance.json').write_text(json.dumps({'old_source':head(OLD),'new_source':head(NEW),'candidate_code_source':qualification['input_head'],'qualification':qualification,'old_qualification':old_qualification,'measurement_location':'Local Windows; no GitHub Actions measurement','changed_inputs':changed},indent=2),encoding='utf-8')
 state={'status':'starting','order':['old','new','new','old'],'rounds':[]}

def save():
 state['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (OUT/'status.json').write_text(json.dumps(state,indent=2),encoding='utf-8')
env=os.environ.copy();env['TEMP']=env['TMP']=str(ROOT/'temp')
for key in ['COMPARISON_PAIR','COMPARISON_SHARD','COMPARISON_SHARDS']: env.pop(key,None)
for index,arm in enumerate(state['order']):
 for fixture,methods,parameter,expected in [('SharedAlligatorBenchmarks',['BuilderFull','BuilderLatestOnly'],'Count',8),('LibraryPairBenchmarks',['Ooples','Competitor'],'Bars',8)]:
  if any(r['index']==index and r['fixture']==fixture for r in state['rounds']): continue
  state.update(status='waiting-quiet-window',round=index,arm=arm,fixture=fixture);save()
  samples=[]
  while len(samples)<3 or any(v>15 for v in samples[-3:]):
   builds=[p.pid for p in psutil.process_iter(['name','cmdline']) if (p.info['name'] or '').lower()=='dotnet.exe' and 'build' in (p.info['cmdline'] or [])]
   samples.append(psutil.cpu_percent(interval=5))
   if builds: samples=[]
  filters=[f'*{fixture}.{method}*{parameter}: {count},*{pair}*' for method in methods for pair in ['Skender.GetAlligator','Skender.GetGator'] for count in [1000,10000]]
  folder=OUT/f'round{index}-{arm}-{fixture}'
  state['status']='measuring';save()
  with folder.with_suffix('.log').open('wb') as log:
   subprocess.run(['dotnet',str(arms[arm]/'OoplesFinance.StockIndicators.CompetitorBenchmarks.dll'),'--filter',*filters,'--warmupCount','10','--iterationCount','10','--exporters','json','--artifacts',str(folder)],cwd=arms[arm],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=3600)
  reports=list((folder/'results').glob('*-report-full-compressed.json'));assert len(reports)==1
  report=json.loads(reports[0].read_bytes())
  assert len(report['Benchmarks'])==expected and all(c.get('Statistics') and c['Statistics']['N']>=7 for c in report['Benchmarks'])
  state['rounds'].append({'index':index,'arm':arm,'fixture':fixture,'quiet_cpu_samples':samples[-3:],'report':str(reports[0]),'sha256':digest(reports[0]),'cases':expected});save()
assert manifest(arms['old'])==original
assert all(manifest(arms[arm])==manifests[arm] for arm in ['old','new'])
state['status']='raw-measurements-complete-independent-verification-pending';save()
print(state['status'],flush=True)
