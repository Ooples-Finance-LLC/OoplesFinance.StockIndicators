```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean         | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-------------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)AdOsc [21]** |   **477.622 μs** | **31.6126 μs** | **18.8121 μs** |  **1.00** |    **0.05** |  **209.08 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)AdOsc [21] |     8.944 μs |  0.3373 μs |  0.2007 μs |  0.02 |    0.00 |   32.99 KB |        0.16 |
|            |       |                      |              |            |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)AdOsc [21]** | **4,344.712 μs** | **29.6109 μs** | **15.4871 μs** |  **1.00** |    **0.00** | **2054.48 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)AdOsc [21] |    67.278 μs |  3.0972 μs |  1.8431 μs |  0.02 |    0.00 |  330.91 KB |        0.16 |
