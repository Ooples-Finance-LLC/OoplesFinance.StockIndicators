```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)inOsc [21]** |   **490.3 μs** |  **25.50 μs** | **16.87 μs** |  **1.00** |    **0.05** |  **259.63 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)inOsc [21] |   119.5 μs |   7.26 μs |  3.80 μs |  0.24 |    0.01 |  495.14 KB |        1.91 |
|            |       |                      |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)inOsc [21]** | **4,559.9 μs** | **108.22 μs** | **71.58 μs** |  **1.00** |    **0.02** | **2551.68 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)inOsc [21] | 1,138.8 μs |  42.10 μs | 25.06 μs |  0.25 |    0.01 | 4854.19 KB |        1.90 |
