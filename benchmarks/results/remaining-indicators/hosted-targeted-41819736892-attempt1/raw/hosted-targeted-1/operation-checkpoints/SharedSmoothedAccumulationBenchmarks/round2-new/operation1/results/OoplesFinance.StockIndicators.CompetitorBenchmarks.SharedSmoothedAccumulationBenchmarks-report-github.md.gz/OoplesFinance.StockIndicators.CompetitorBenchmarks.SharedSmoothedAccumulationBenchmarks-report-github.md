```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio  | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|-------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **249.633 μs** |  **2.4057 μs** |  **1.2582 μs** | **100.22** |    **2.49** |       **-** |      **-** |  **73.56 KB** |        **9.42** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   244.745 μs |  1.4162 μs |  0.7407 μs |  98.26 |    2.42 |       - |      - |  25.91 KB |        3.32 |
| NativeSingle      | TaLib(...)AdOsc [21] | 1000  |     2.492 μs |  0.1116 μs |  0.0664 μs |   1.00 |    0.04 |  0.4730 |      - |    7.8 KB |        1.00 |
| NativeParallel    | TaLib(...)AdOsc [21] | 1000  |     6.666 μs |  0.4564 μs |  0.2716 μs |   2.68 |    0.12 |  1.8311 | 0.0610 |  27.56 KB |        3.53 |
|                   |                      |       |              |            |            |        |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **2,563.409 μs** | **19.9168 μs** | **10.4169 μs** | **116.09** |    **1.22** | **31.2500** |      **-** | **706.76 KB** |        **9.05** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 2,538.999 μs | 22.7080 μs | 13.5132 μs | 114.99 |    1.26 |       - |      - | 236.93 KB |        3.03 |
| NativeSingle      | TaLib(...)AdOsc [21] | 10000 |    22.083 μs |  0.3802 μs |  0.2263 μs |   1.00 |    0.01 |  4.7607 |      - |  78.12 KB |        1.00 |
| NativeParallel    | TaLib(...)AdOsc [21] | 10000 |    65.364 μs | 14.0550 μs |  8.3639 μs |   2.96 |    0.36 | 18.0664 | 4.8828 | 273.66 KB |        3.50 |
