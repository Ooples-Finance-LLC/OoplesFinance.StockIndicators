```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **253.7 μs** |  **1.30 μs** |  **0.68 μs** |       **-** |  **73.52 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   250.1 μs |  1.70 μs |  1.01 μs |       - |  25.91 KB |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **2,640.9 μs** | **26.95 μs** | **16.04 μs** | **31.2500** | **706.69 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 2,609.8 μs | 14.51 μs |  8.63 μs |       - | 236.92 KB |
