```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **250.70 μs** |   **1.466 μs** |  **0.767 μs** |  **3.69** |    **0.04** |        **-** |        **-** |       **-** |   **97.06 KB** |        **0.26** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   244.42 μs |   1.738 μs |  1.149 μs |  3.60 |    0.04 |   1.9531 |        - |       - |   49.42 KB |        0.13 |
| NativeSingle      | Skend(...)inOsc [21] | 1000  |    67.95 μs |   1.085 μs |  0.718 μs |  1.00 |    0.01 |  22.9492 |   6.8359 |       - |  379.71 KB |        1.00 |
| NativeParallel    | Skend(...)inOsc [21] | 1000  |   132.50 μs |  12.984 μs |  8.588 μs |  1.95 |    0.12 |  60.5469 |  22.4609 |       - |  958.68 KB |        2.52 |
|                   |                      |       |             |            |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **2,611.76 μs** |  **41.209 μs** | **24.523 μs** |  **2.76** |    **0.03** |  **46.8750** |  **15.6250** |       **-** |  **941.25 KB** |        **0.25** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 2,575.91 μs |  17.128 μs | 11.329 μs |  2.72 |    0.02 |  15.6250 |        - |       - |  471.35 KB |        0.12 |
| NativeSingle      | Skend(...)inOsc [21] | 10000 |   947.82 μs |  11.556 μs |  6.044 μs |  1.00 |    0.01 | 242.1875 | 148.4375 | 46.8750 | 3790.29 KB |        1.00 |
| NativeParallel    | Skend(...)inOsc [21] | 10000 | 1,831.91 μs | 141.836 μs | 93.816 μs |  1.93 |    0.10 | 593.7500 | 546.8750 | 78.1250 | 9555.28 KB |        2.52 |
