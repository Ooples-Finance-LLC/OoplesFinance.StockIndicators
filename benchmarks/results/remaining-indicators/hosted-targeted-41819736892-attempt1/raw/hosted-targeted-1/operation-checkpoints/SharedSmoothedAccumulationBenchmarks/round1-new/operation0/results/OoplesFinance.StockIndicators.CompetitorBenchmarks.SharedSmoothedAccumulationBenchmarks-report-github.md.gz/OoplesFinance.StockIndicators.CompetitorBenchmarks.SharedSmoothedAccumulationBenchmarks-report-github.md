```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **250.0 μs** |  **1.43 μs** |  **0.85 μs** |       **-** |       **-** |  **97.06 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   245.6 μs |  0.98 μs |  0.51 μs |  1.9531 |       - |  49.42 KB |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **2,640.8 μs** | **43.29 μs** | **25.76 μs** | **46.8750** | **15.6250** | **941.22 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 2,815.1 μs |  6.79 μs |  3.55 μs | 15.6250 |       - | 471.37 KB |
