```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **376.2 μs** |  **2.12 μs** |  **1.11 μs** |       **-** |  **97.03 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   379.0 μs |  6.07 μs |  3.61 μs |       - |  49.43 KB |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **3,891.2 μs** | **13.79 μs** |  **7.21 μs** | **31.2500** | **941.34 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 3,904.4 μs | 23.32 μs | 13.88 μs |       - | 471.46 KB |
