```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev  | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **380.6 μs** |  **2.16 μs** | **1.28 μs** |       **-** |  **73.53 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   372.4 μs |  5.99 μs | 3.56 μs |       - |  25.91 KB |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **3,863.0 μs** | **10.13 μs** | **5.30 μs** | **31.2500** | **706.86 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 3,871.0 μs | 10.18 μs | 5.32 μs |       - | 237.08 KB |
