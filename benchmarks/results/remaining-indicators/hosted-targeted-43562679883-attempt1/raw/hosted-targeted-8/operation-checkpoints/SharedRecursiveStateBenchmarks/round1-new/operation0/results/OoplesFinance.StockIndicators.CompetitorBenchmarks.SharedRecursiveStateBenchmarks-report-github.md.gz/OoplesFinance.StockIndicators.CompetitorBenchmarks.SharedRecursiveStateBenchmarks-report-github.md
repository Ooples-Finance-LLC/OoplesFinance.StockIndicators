```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Ema**       | **1000**  |  **20.16 μs** | **0.268 μs** | **0.159 μs** |  **2.9297** |       **-** |  **56.71 KB** |
| BuilderLatestOnly | Ema       | 1000  |  19.14 μs | 0.686 μs | 0.454 μs |  0.4883 |       - |   8.85 KB |
| **BuilderFull**       | **Ema**       | **10000** | **181.03 μs** | **2.625 μs** | **1.373 μs** | **33.2031** | **13.6719** | **549.24 KB** |
| BuilderLatestOnly | Ema       | 10000 | 169.33 μs | 1.454 μs | 0.865 μs |  3.9063 |       - |  79.17 KB |
