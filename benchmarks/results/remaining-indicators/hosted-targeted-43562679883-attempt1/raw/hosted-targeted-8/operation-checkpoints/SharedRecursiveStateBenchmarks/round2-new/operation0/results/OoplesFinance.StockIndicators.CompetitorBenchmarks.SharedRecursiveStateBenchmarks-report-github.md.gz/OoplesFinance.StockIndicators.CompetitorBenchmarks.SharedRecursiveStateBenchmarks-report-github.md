```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |---------- |------ |-----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **Ema**       | **1000**  |  **21.337 μs** | **3.2593 μs** | **1.9396 μs** | **10.79** |    **0.93** |  **3.4180** |  **0.4883** |  **56.74 KB** |        **7.35** |
| BuilderLatestOnly | Ema       | 1000  |  18.209 μs | 0.3618 μs | 0.2153 μs |  9.21 |    0.11 |  0.4883 |       - |   8.85 KB |        1.15 |
| NativeSingle      | Ema       | 1000  |   1.977 μs | 0.0167 μs | 0.0099 μs |  1.00 |    0.01 |  0.4578 |       - |   7.72 KB |        1.00 |
| NativeParallel    | Ema       | 1000  |  66.271 μs | 1.2590 μs | 0.7492 μs | 33.52 |    0.39 |  0.4883 |       - |   7.99 KB |        1.03 |
|                   |           |       |            |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **Ema**       | **10000** | **174.839 μs** | **2.8782 μs** | **1.7127 μs** |  **9.07** |    **0.10** | **33.2031** | **13.6719** | **549.27 KB** |        **7.04** |
| BuilderLatestOnly | Ema       | 10000 | 167.333 μs | 3.0520 μs | 1.8162 μs |  8.68 |    0.10 |  3.9063 |       - |  79.17 KB |        1.01 |
| NativeSingle      | Ema       | 10000 |  19.283 μs | 0.2194 μs | 0.1148 μs |  1.00 |    0.01 |  4.7607 |  0.8545 |  78.03 KB |        1.00 |
| NativeParallel    | Ema       | 10000 |  81.896 μs | 2.5354 μs | 1.6770 μs |  4.25 |    0.09 |  4.3945 |  0.4883 |   78.3 KB |        1.00 |
