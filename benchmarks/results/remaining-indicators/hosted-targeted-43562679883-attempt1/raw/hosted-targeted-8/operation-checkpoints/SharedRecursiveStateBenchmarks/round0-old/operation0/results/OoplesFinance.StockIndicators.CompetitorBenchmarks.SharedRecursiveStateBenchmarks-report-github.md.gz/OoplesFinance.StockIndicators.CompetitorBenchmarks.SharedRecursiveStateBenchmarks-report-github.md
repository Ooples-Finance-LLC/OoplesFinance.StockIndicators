```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Ema**       | **1000**  |  **22.94 μs** | **1.747 μs** | **0.914 μs** |  **2.9297** |       **-** |  **56.74 KB** |
| BuilderLatestOnly | Ema       | 1000  |  18.01 μs | 0.384 μs | 0.254 μs |  0.4883 |       - |   8.85 KB |
| **BuilderFull**       | **Ema**       | **10000** | **183.68 μs** | **3.314 μs** | **2.192 μs** | **33.2031** | **13.6719** | **549.28 KB** |
| BuilderLatestOnly | Ema       | 10000 | 171.37 μs | 1.123 μs | 0.587 μs |  3.9063 |       - |  79.17 KB |
