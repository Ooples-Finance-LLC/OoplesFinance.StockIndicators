```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId              | Mean     | Error   | StdDev  | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |-------------------- |---------:|--------:|--------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Ema** | **101.3 μs** | **2.16 μs** | **1.13 μs** |  **1.00** |    **0.01** |  **64.84 KB** |        **1.00** |
|        |       |                     |          |         |         |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Ema** | **262.1 μs** | **7.81 μs** | **5.17 μs** |  **1.00** |    **0.03** |  **634.8 KB** |        **1.00** |
