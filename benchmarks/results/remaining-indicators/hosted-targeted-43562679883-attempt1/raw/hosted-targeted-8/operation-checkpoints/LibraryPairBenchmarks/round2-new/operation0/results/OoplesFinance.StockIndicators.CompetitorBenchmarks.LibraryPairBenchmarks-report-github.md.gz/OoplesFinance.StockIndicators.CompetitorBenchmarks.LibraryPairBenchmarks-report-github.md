```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean      | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ema** |  **46.05 μs** | **1.797 μs** | **0.940 μs** |  **1.00** |    **0.03** |  **64.84 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ema |  12.84 μs | 0.386 μs | 0.230 μs |  0.28 |    0.01 |  19.25 KB |        0.30 |
|            |       |                     |           |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ema** | **262.24 μs** | **6.339 μs** | **3.772 μs** |  **1.00** |    **0.02** | **628.33 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ema |  23.00 μs | 1.246 μs | 0.742 μs |  0.09 |    0.00 | 158.61 KB |        0.25 |
