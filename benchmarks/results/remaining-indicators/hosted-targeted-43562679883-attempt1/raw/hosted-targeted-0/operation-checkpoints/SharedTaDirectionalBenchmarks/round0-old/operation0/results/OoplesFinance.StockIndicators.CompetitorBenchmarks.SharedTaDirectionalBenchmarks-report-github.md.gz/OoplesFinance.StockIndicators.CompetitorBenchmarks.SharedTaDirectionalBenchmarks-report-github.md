```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |  **90.38 μs** | **2.344 μs** | **1.395 μs** |  **3.9063** |      **-** |  **64.83 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |  86.03 μs | 0.798 μs | 0.475 μs |  0.9766 |      - |  17.26 KB |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **919.50 μs** | **7.573 μs** | **4.507 μs** | **31.2500** | **7.8125** | **627.74 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 907.83 μs | 5.554 μs | 2.905 μs |  7.8125 |      - | 157.93 KB |
