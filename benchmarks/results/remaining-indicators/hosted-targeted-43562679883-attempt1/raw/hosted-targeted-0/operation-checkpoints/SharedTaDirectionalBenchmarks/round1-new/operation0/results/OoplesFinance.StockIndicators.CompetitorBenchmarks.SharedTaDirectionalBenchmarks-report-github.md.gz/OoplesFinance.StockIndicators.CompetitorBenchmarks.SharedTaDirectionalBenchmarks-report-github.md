```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |  **68.40 μs** |  **0.673 μs** |  **0.352 μs** |  **3.9063** |       **-** |  **64.88 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |  65.14 μs |  0.571 μs |  0.299 μs |  0.9766 |       - |  17.27 KB |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **721.88 μs** | **25.740 μs** | **17.026 μs** | **35.1563** | **11.7188** | **627.73 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 697.86 μs |  4.353 μs |  2.277 μs |  7.8125 |       - | 157.93 KB |
