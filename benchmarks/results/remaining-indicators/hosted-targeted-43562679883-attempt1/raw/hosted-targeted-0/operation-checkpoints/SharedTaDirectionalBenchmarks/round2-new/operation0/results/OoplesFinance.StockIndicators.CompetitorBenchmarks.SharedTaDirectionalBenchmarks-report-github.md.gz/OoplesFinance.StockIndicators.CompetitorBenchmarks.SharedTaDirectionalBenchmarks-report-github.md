```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |  **71.15 μs** |  **2.727 μs** |  **1.623 μs** |  **6.90** |    **0.15** |  **3.9063** |       **-** |  **64.88 KB** |        **8.41** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |  68.47 μs |  0.571 μs |  0.377 μs |  6.64 |    0.05 |  0.9766 |       - |  17.27 KB |        2.24 |
| NativeSingle      | TaLib(...)lusDM [22] | 1000  |  10.30 μs |  0.080 μs |  0.053 μs |  1.00 |    0.01 |  0.4272 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 1000  |  97.50 μs |  4.165 μs |  2.479 μs |  9.46 |    0.23 |  0.9766 |       - |  27.23 KB |        3.53 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **734.98 μs** |  **4.352 μs** |  **2.276 μs** |  **7.04** |    **0.02** | **35.1563** | **11.7188** | **627.76 KB** |        **8.04** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 721.17 μs | 17.457 μs | 11.547 μs |  6.90 |    0.11 |  7.8125 |       - | 157.93 KB |        2.02 |
| NativeSingle      | TaLib(...)lusDM [22] | 10000 | 104.44 μs |  0.383 μs |  0.200 μs |  1.00 |    0.00 |  3.9063 |       - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 10000 | 206.03 μs |  9.248 μs |  6.117 μs |  1.97 |    0.06 | 17.5781 |  1.9531 | 273.33 KB |        3.50 |
