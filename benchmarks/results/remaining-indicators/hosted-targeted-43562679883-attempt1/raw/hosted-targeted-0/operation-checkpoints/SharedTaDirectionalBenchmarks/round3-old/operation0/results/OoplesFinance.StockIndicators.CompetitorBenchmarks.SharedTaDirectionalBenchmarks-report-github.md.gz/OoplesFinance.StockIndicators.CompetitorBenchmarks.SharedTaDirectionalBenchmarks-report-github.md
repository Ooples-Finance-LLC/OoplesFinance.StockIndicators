```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |  **78.70 μs** | **0.686 μs** | **0.408 μs** |  **3.9063** |      **-** |  **64.86 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |  77.06 μs | 0.809 μs | 0.423 μs |  0.9766 |      - |  17.25 KB |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **838.20 μs** | **6.183 μs** | **3.679 μs** | **31.2500** | **7.8125** | **627.77 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 822.81 μs | 2.394 μs | 1.252 μs |  7.8125 |      - | 157.94 KB |
