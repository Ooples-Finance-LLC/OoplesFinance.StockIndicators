```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDM [22]** | **142.14 μs** |  **6.197 μs** |  **3.241 μs** |  **1.00** |    **0.03** |  **105.55 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDM [22] |  17.65 μs |  1.329 μs |  0.695 μs |  0.12 |    0.01 |   40.55 KB |        0.38 |
|            |       |                      |           |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDM [22]** | **930.78 μs** | **24.411 μs** | **14.527 μs** |  **1.00** |    **0.02** | **1036.23 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDM [22] | 162.08 μs | 16.896 μs | 10.054 μs |  0.17 |    0.01 |  330.59 KB |        0.32 |
