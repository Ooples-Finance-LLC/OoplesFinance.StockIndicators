```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adx** |   **339.87 μs** | **27.206 μs** | **16.190 μs** |  **1.00** |    **0.06** | **105.77 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adx |    23.31 μs |  0.631 μs |  0.376 μs |  0.07 |    0.00 |  40.55 KB |        0.38 |
|            |       |                     |             |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adx** | **3,148.36 μs** | **26.717 μs** | **15.899 μs** |  **1.00** |    **0.01** | **1039.1 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adx |   225.36 μs | 21.754 μs | 14.389 μs |  0.07 |    0.00 | 330.64 KB |        0.32 |
