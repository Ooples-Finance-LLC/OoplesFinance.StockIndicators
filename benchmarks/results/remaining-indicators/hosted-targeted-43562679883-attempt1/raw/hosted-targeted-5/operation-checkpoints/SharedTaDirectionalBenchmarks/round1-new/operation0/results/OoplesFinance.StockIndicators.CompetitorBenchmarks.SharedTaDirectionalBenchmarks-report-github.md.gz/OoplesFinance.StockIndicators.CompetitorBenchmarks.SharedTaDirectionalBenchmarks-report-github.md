```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **257.9 μs** |  **2.42 μs** |  **1.44 μs** |       **-** |       **-** |   **65.1 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   271.0 μs | 25.25 μs | 16.70 μs |       - |       - |   17.5 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **2,933.9 μs** | **12.31 μs** |  **6.44 μs** | **31.2500** | **15.6250** | **630.67 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 2,937.8 μs | 73.16 μs | 48.39 μs |       - |       - | 160.84 KB |
