```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev  | Gen0    | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **351.3 μs** |  **2.70 μs** | **1.41 μs** |       **-** |  **65.08 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   348.5 μs |  1.74 μs | 0.91 μs |       - |  17.48 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **3,730.2 μs** | **13.52 μs** | **8.05 μs** | **31.2500** | **630.77 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 3,703.5 μs | 11.69 μs | 6.11 μs |       - | 160.71 KB |
