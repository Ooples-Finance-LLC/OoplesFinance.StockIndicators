```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **262.48 μs** |  **4.066 μs** |  **2.419 μs** | **17.57** |    **0.16** |       **-** |       **-** |   **65.1 KB** |        **8.60** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   262.23 μs |  2.269 μs |  1.350 μs | 17.56 |    0.09 |       - |       - |   17.5 KB |        2.31 |
| NativeSingle      | TaLib.Functions.Adx | 1000  |    14.94 μs |  0.047 μs |  0.028 μs |  1.00 |    0.00 |  0.3662 |       - |   7.57 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 1000  |   103.56 μs |  3.367 μs |  2.227 μs |  6.93 |    0.14 |  0.9766 |       - |  26.72 KB |        3.53 |
|                   |                     |       |             |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **2,955.70 μs** |  **9.771 μs** |  **5.110 μs** | **19.53** |    **0.13** | **31.2500** | **15.6250** | **630.55 KB** |        **8.10** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 2,933.14 μs | 28.878 μs | 15.104 μs | 19.38 |    0.16 |       - |       - | 160.84 KB |        2.06 |
| NativeSingle      | TaLib.Functions.Adx | 10000 |   151.37 μs |  2.047 μs |  1.071 μs |  1.00 |    0.01 |  3.9063 |       - |  77.89 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 10000 |   269.84 μs |  4.580 μs |  2.395 μs |  1.78 |    0.02 | 17.5781 |  3.9063 | 272.82 KB |        3.50 |
