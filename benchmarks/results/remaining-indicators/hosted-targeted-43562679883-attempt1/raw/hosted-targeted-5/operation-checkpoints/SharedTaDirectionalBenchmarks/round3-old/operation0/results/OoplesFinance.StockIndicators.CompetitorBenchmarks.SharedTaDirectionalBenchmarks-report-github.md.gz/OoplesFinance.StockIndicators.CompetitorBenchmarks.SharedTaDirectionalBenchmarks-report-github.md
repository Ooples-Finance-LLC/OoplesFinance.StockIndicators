```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **357.5 μs** | **20.36 μs** | **13.47 μs** |       **-** |  **65.05 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   345.8 μs |  2.75 μs |  1.64 μs |       - |   17.5 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **3,699.5 μs** | **55.92 μs** | **29.25 μs** | **31.2500** | **630.76 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 3,684.5 μs | 11.33 μs |  6.74 μs |       - | 160.94 KB |
