```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean     | Error    | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |------------------- |------ |---------:|---------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.T3** | **1000**  | **144.9 μs** |  **2.32 μs** | **1.21 μs** |  **3.9063** |       **-** |  **65.25 KB** |
| BuilderLatestOnly | TaLib.Functions.T3 | 1000  | 116.5 μs |  0.99 μs | 0.59 μs |  0.9766 |       - |  17.64 KB |
| **BuilderFull**       | **TaLib.Functions.T3** | **10000** | **766.9 μs** | **18.98 μs** | **9.93 μs** | **31.2500** | **15.6250** | **630.77 KB** |
| BuilderLatestOnly | TaLib.Functions.T3 | 10000 | 838.5 μs | 17.49 μs | 9.15 μs | 31.2500 | 15.6250 | 630.08 KB |
