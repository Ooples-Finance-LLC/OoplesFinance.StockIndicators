```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |-----------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.T3** | **1000**  | **119.889 μs** |  **1.1715 μs** |  **0.6127 μs** | **35.14** |    **0.36** |  **3.9063** |       **-** |  **65.25 KB** |        **9.35** |
| BuilderLatestOnly | TaLib.Functions.T3 | 1000  | 118.460 μs |  0.5292 μs |  0.3149 μs | 34.72 |    0.32 |  0.9766 |       - |  17.64 KB |        2.53 |
| NativeSingle      | TaLib.Functions.T3 | 1000  |   3.412 μs |  0.0537 μs |  0.0320 μs |  1.00 |    0.01 |  0.3967 |       - |   6.98 KB |        1.00 |
| NativeParallel    | TaLib.Functions.T3 | 1000  |  80.694 μs |  1.0053 μs |  0.5982 μs | 23.65 |    0.27 |  1.4648 |       - |  24.66 KB |        3.53 |
|                   |                    |       |            |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.T3** | **10000** | **796.949 μs** | **44.7473 μs** | **29.5976 μs** | **23.65** |    **0.86** | **35.1563** | **11.7188** | **630.74 KB** |        **8.16** |
| BuilderLatestOnly | TaLib.Functions.T3 | 10000 | 770.623 μs | 18.8351 μs |  9.8511 μs | 22.87 |    0.33 | 31.2500 | 15.6250 | 630.09 KB |        8.15 |
| NativeSingle      | TaLib.Functions.T3 | 10000 |  33.697 μs |  0.4906 μs |  0.2919 μs |  1.00 |    0.01 |  4.6387 |       - |  77.29 KB |        1.00 |
| NativeParallel    | TaLib.Functions.T3 | 10000 | 121.363 μs |  2.9018 μs |  1.5177 μs |  3.60 |    0.05 | 17.5781 |  3.9063 | 270.76 KB |        3.50 |
