```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.T3** | **1000**  | **119.2 μs** |  **0.32 μs** |  **0.17 μs** |  **3.9063** |       **-** |  **65.25 KB** |
| BuilderLatestOnly | TaLib.Functions.T3 | 1000  | 117.0 μs |  0.45 μs |  0.24 μs |  0.9766 |       - |  17.64 KB |
| **BuilderFull**       | **TaLib.Functions.T3** | **10000** | **774.0 μs** | **10.67 μs** |  **5.58 μs** | **31.2500** |  **7.8125** | **630.77 KB** |
| BuilderLatestOnly | TaLib.Functions.T3 | 10000 | 786.9 μs | 31.90 μs | 18.98 μs | 31.2500 | 15.6250 | 630.09 KB |
