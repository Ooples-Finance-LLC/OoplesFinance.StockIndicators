```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean         | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-------------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.T3** |   **187.444 μs** |   **8.9285 μs** |   **5.3132 μs** |  **1.00** |    **0.04** |  **105.92 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.T3 |     7.120 μs |   0.6985 μs |   0.4620 μs |  0.04 |    0.00 |   39.56 KB |        0.37 |
|            |       |                    |              |             |             |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.T3** | **1,219.790 μs** | **262.5637 μs** | **173.6696 μs** |  **1.02** |    **0.19** | **1038.59 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.T3 |    54.600 μs |   2.1058 μs |   1.3928 μs |  0.05 |    0.01 |  327.35 KB |        0.32 |
