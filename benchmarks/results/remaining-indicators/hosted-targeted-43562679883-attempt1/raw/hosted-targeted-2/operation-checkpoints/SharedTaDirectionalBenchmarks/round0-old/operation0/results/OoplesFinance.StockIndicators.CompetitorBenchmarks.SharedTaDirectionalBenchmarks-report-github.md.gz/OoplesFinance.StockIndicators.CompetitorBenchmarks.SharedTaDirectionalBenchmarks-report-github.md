```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **116.6 μs** |  **8.85 μs** |  **4.63 μs** |  **3.9063** |      **-** |  **64.86 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   106.1 μs |  0.44 μs |  0.26 μs |  0.9766 |      - |  17.26 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **1,389.4 μs** | **12.39 μs** |  **7.37 μs** | **31.2500** | **7.8125** | **627.72 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 1,369.0 μs | 18.33 μs | 12.13 μs |  7.8125 |      - | 157.92 KB |
