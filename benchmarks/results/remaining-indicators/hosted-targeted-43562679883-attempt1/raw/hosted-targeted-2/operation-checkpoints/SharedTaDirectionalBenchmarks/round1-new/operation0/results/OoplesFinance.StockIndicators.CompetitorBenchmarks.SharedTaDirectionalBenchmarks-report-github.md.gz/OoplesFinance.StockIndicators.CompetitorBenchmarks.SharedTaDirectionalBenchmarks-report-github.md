```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |  **74.14 μs** |  **0.454 μs** |  **0.270 μs** |  **3.9063** |      **-** |  **64.88 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |  71.77 μs |  0.287 μs |  0.171 μs |  0.9766 |      - |  17.27 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **946.19 μs** | **37.305 μs** | **19.511 μs** | **31.2500** | **7.8125** | **627.78 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 913.91 μs | 14.299 μs |  8.509 μs |  7.8125 |      - | 157.95 KB |
