```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |  **84.623 μs** | **1.9507 μs** | **1.1608 μs** | **13.17** |    **0.18** |  **3.9063** |      **-** |  **64.88 KB** |        **8.41** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |  72.651 μs | 1.2815 μs | 0.8476 μs | 11.31 |    0.14 |  0.9766 |      - |  17.27 KB |        2.24 |
| NativeSingle      | TaLib(...)lusDI [22] | 1000  |   6.423 μs | 0.0595 μs | 0.0354 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 1000  |  84.788 μs | 2.0129 μs | 1.3314 μs | 13.20 |    0.21 |  1.9531 |      - |  27.25 KB |        3.53 |
|                   |                      |       |            |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **969.093 μs** | **5.4788 μs** | **2.8655 μs** | **15.96** |    **0.09** | **31.2500** | **7.8125** | **627.77 KB** |        **8.04** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 904.589 μs | 2.8384 μs | 1.4845 μs | 14.90 |    0.07 |  7.8125 |      - | 157.96 KB |        2.02 |
| NativeSingle      | TaLib(...)lusDI [22] | 10000 |  60.709 μs | 0.5046 μs | 0.3003 μs |  1.00 |    0.01 |  4.3945 |      - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 10000 | 148.371 μs | 2.3314 μs | 1.3874 μs |  2.44 |    0.02 | 17.5781 | 3.9063 | 273.34 KB |        3.50 |
