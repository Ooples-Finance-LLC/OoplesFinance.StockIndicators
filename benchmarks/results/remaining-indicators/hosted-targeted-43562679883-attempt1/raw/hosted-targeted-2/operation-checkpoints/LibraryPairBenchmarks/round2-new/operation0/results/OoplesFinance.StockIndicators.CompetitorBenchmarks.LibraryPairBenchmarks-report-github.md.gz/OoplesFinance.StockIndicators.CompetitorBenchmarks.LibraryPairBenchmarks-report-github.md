```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDI [22]** |   **148.91 μs** |  **2.767 μs** |  **1.647 μs** |  **1.00** |    **0.01** |  **105.59 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDI [22] |    15.77 μs |  2.216 μs |  1.466 μs |  0.11 |    0.01 |   38.26 KB |        0.36 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDI [22]** | **1,132.33 μs** | **24.119 μs** | **15.953 μs** |  **1.00** |    **0.02** | **1036.89 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDI [22] |   140.47 μs |  5.374 μs |  2.811 μs |  0.12 |    0.00 |  329.94 KB |        0.32 |
