```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **394.9 μs** | **10.06 μs** |  **5.26 μs** |       **-** |  **66.16 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   381.5 μs |  3.21 μs |  2.12 μs |       - |  18.55 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **4,054.6 μs** | **34.16 μs** | **17.87 μs** | **31.2500** | **631.85 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 4,016.8 μs |  6.74 μs |  3.53 μs |       - | 162.03 KB |
