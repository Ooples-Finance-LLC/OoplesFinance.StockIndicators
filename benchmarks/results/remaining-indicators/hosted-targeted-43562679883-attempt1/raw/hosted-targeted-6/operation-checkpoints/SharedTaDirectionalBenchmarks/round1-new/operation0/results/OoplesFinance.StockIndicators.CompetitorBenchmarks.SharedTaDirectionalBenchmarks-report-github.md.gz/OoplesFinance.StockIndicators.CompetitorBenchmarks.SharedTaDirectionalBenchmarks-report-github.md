```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **324.4 μs** |  **3.26 μs** |  **1.94 μs** |       **-** |  **66.21 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   297.7 μs |  4.39 μs |  2.29 μs |       - |  18.59 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **3,369.1 μs** | **23.23 μs** | **15.37 μs** | **31.2500** | **631.86 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 3,335.6 μs | 10.35 μs |  6.16 μs |       - | 162.04 KB |
