```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **331.13 μs** | **22.773 μs** | **15.063 μs** | **19.98** |    **0.87** |       **-** |      **-** |  **66.21 KB** |        **4.42** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   293.85 μs |  1.911 μs |  1.137 μs | 17.73 |    0.08 |       - |      - |  18.57 KB |        1.24 |
| NativeSingle      | TaLib.Functions.Adxr | 1000  |    16.58 μs |  0.073 μs |  0.038 μs |  1.00 |    0.00 |  0.8545 |      - |  14.99 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 1000  |   105.32 μs |  3.093 μs |  1.840 μs |  6.35 |    0.11 |  2.9297 |      - |  45.44 KB |        3.03 |
|                   |                      |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **3,305.43 μs** | **16.866 μs** |  **8.821 μs** | **19.74** |    **0.17** | **31.2500** |      **-** | **631.88 KB** |        **4.06** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 3,293.61 μs | 21.717 μs | 14.364 μs | 19.67 |    0.18 |       - |      - | 162.04 KB |        1.04 |
| NativeSingle      | TaLib.Functions.Adxr | 10000 |   167.48 μs |  2.247 μs |  1.486 μs |  1.00 |    0.01 |  8.7891 | 0.9766 | 155.62 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 10000 |   309.30 μs | 15.274 μs | 10.103 μs |  1.85 |    0.06 | 29.2969 | 9.7656 | 467.32 KB |        3.00 |
