```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adxr** |   **376.09 μs** | **23.067 μs** | **13.727 μs** |  **1.00** |    **0.05** | **106.84 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adxr |    24.58 μs |  1.652 μs |  0.983 μs |  0.07 |    0.00 |  48.13 KB |        0.45 |
|            |       |                      |             |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adxr** | **3,567.98 μs** | **35.990 μs** | **21.417 μs** |  **1.00** |    **0.01** | **1040.5 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adxr |   229.44 μs |  6.901 μs |  3.609 μs |  0.06 |    0.00 | 408.52 KB |        0.39 |
