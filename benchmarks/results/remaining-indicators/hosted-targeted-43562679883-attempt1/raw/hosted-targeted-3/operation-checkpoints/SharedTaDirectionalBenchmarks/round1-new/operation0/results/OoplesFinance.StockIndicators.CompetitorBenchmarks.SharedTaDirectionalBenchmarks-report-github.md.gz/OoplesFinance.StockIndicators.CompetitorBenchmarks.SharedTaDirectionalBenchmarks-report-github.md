```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev  | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|--------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **106.1 μs** |  **1.32 μs** | **0.69 μs** |  **3.9063** |      **-** |  **64.88 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   101.0 μs |  0.77 μs | 0.46 μs |  0.9766 |      - |  17.27 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **1,241.1 μs** | **12.41 μs** | **6.49 μs** | **31.2500** | **7.8125** | **627.79 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 1,210.0 μs | 11.51 μs | 7.62 μs |  7.8125 |      - | 157.95 KB |
