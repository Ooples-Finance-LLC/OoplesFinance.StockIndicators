```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **160.1 μs** |  **6.37 μs** |  **3.79 μs** |  **3.9063** |  **64.86 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   158.1 μs |  1.68 μs |  0.88 μs |  0.9766 |  17.26 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **1,771.1 μs** | **29.13 μs** | **19.27 μs** | **31.2500** | **627.83 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 1,738.8 μs |  7.28 μs |  4.33 μs |       - | 158.01 KB |
