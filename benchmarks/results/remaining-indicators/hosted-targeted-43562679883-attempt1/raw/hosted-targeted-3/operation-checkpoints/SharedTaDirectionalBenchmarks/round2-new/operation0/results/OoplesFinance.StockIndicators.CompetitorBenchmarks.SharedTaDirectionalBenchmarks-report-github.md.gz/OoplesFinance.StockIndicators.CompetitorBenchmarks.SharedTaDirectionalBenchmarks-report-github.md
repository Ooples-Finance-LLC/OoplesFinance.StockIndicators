```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **106.280 μs** | **1.1163 μs** | **0.6643 μs** | **14.34** |    **0.11** |  **3.9063** |      **-** |  **64.88 KB** |        **8.41** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   100.782 μs | 0.4252 μs | 0.2224 μs | 13.60 |    0.07 |  0.9766 |      - |  17.27 KB |        2.24 |
| NativeSingle      | TaLib(...)nusDI [23] | 1000  |     7.411 μs | 0.0655 μs | 0.0390 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 1000  |    95.370 μs | 1.7489 μs | 1.0408 μs | 12.87 |    0.15 |  1.9531 |      - |  27.25 KB |        3.53 |
|                   |                      |       |              |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **1,255.191 μs** | **4.5926 μs** | **3.0377 μs** | **16.93** |    **0.06** | **31.2500** | **7.8125** | **627.79 KB** |        **8.04** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 1,216.105 μs | 7.7864 μs | 4.0724 μs | 16.40 |    0.07 |  7.8125 |      - | 157.96 KB |        2.02 |
| NativeSingle      | TaLib(...)nusDI [23] | 10000 |    74.151 μs | 0.4030 μs | 0.2108 μs |  1.00 |    0.00 |  4.3945 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 10000 |   176.603 μs | 7.7708 μs | 4.6243 μs |  2.38 |    0.06 | 17.5781 | 2.9297 | 273.34 KB |        3.50 |
