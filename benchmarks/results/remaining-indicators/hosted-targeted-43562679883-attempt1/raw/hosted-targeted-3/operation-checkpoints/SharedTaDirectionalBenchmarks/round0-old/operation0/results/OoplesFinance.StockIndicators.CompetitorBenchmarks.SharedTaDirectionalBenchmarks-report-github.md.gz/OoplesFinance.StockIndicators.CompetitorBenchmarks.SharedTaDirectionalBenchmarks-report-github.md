```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **159.6 μs** |  **2.21 μs** |  **1.16 μs** |  **3.9063** |  **64.86 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   155.3 μs |  1.11 μs |  0.58 μs |  0.9766 |  17.26 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **1,777.2 μs** | **23.66 μs** | **14.08 μs** | **31.2500** | **627.83 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 1,744.7 μs | 13.52 μs |  8.04 μs |       - |    158 KB |
