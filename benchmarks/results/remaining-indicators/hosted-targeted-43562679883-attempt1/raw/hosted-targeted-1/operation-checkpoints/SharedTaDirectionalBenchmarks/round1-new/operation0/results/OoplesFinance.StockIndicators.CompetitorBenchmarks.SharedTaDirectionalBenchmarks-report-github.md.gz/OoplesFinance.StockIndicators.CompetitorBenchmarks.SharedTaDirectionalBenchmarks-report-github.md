```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |  **63.90 μs** | **1.893 μs** | **1.127 μs** |  **3.9063** |       **-** |  **64.88 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |  63.21 μs | 2.075 μs | 1.235 μs |  0.9766 |       - |  17.27 KB |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **744.33 μs** | **5.517 μs** | **2.886 μs** | **35.1563** | **11.7188** | **627.75 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 728.08 μs | 3.341 μs | 1.748 μs |  7.8125 |       - | 157.93 KB |
