```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |  **88.76 μs** | **0.770 μs** | **0.403 μs** |  **3.9063** |      **-** |  **64.86 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |  88.22 μs | 1.687 μs | 1.004 μs |  0.9766 |      - |  17.26 KB |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **972.16 μs** | **4.290 μs** | **2.837 μs** | **31.2500** | **7.8125** | **627.77 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 954.02 μs | 9.151 μs | 5.446 μs |  7.8125 |      - | 157.94 KB |
