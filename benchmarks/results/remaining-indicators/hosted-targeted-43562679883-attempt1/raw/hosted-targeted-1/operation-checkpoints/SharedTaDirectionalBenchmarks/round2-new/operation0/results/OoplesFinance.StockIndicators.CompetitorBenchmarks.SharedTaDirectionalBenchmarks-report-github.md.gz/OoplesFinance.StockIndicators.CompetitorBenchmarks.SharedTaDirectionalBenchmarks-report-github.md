```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|---------:|---------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |  **66.25 μs** | **1.620 μs** | **0.964 μs** |  **6.54** |    **0.10** |  **3.9063** |       **-** |  **64.85 KB** |        **8.40** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |  63.13 μs | 0.467 μs | 0.278 μs |  6.23 |    0.04 |  0.9766 |       - |  17.27 KB |        2.24 |
| NativeSingle      | TaLib(...)nusDM [23] | 1000  |  10.13 μs | 0.088 μs | 0.058 μs |  1.00 |    0.01 |  0.4272 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 1000  |  97.56 μs | 2.166 μs | 1.433 μs |  9.63 |    0.14 |  0.9766 |       - |  27.23 KB |        3.53 |
|                   |                      |       |           |          |          |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **740.40 μs** | **4.593 μs** | **3.038 μs** |  **7.14** |    **0.06** | **35.1563** | **15.6250** | **627.72 KB** |        **8.04** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 729.40 μs | 9.227 μs | 5.491 μs |  7.03 |    0.07 |  7.8125 |       - | 157.93 KB |        2.02 |
| NativeSingle      | TaLib(...)nusDM [23] | 10000 | 103.74 μs | 1.130 μs | 0.747 μs |  1.00 |    0.01 |  3.9063 |       - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 10000 | 205.37 μs | 7.949 μs | 5.258 μs |  1.98 |    0.05 | 17.5781 |  1.9531 | 273.33 KB |        3.50 |
