```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev  | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **261.7 μs** |  **5.22 μs** | **3.11 μs** |       **-** |  **64.86 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   264.0 μs | 13.34 μs | 8.82 μs |       - |  17.25 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **3,319.8 μs** |  **6.89 μs** | **3.60 μs** | **31.2500** |  **627.9 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 3,303.3 μs |  7.94 μs | 4.15 μs |       - | 158.05 KB |
