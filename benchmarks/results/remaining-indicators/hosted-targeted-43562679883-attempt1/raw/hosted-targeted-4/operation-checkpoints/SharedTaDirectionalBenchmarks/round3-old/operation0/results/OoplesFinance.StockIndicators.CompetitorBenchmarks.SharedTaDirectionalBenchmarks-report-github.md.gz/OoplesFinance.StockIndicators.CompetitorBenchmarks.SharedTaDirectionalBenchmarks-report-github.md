```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **261.6 μs** |  **3.31 μs** |  **1.97 μs** |       **-** |  **64.86 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   256.3 μs |  2.75 μs |  1.44 μs |       - |  17.26 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **3,341.7 μs** | **53.38 μs** | **35.31 μs** | **31.2500** | **627.89 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 3,308.6 μs | 59.23 μs | 35.24 μs |       - | 158.05 KB |
