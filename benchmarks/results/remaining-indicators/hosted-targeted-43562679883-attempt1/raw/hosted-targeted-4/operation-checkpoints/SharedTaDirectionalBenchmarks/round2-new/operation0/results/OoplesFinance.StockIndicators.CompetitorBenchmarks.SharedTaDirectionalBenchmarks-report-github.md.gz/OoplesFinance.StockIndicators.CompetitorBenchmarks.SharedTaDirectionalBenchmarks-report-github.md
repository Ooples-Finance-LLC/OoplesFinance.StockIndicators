```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **184.12 μs** |  **2.615 μs** |  **1.368 μs** | **14.13** |    **0.11** |       **-** |      **-** |  **64.88 KB** |        **8.40** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   179.83 μs |  0.649 μs |  0.339 μs | 13.80 |    0.04 |       - |      - |  17.28 KB |        2.24 |
| NativeSingle      | TaLib.Functions.Dx | 1000  |    13.03 μs |  0.068 μs |  0.036 μs |  1.00 |    0.00 |  0.3662 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 1000  |    89.60 μs |  2.150 μs |  1.422 μs |  6.88 |    0.11 |  1.9531 |      - |  27.25 KB |        3.53 |
|                   |                    |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **2,522.41 μs** | **31.638 μs** | **18.827 μs** | **19.51** |    **0.15** | **31.2500** |      **-** | **627.83 KB** |        **8.05** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 2,365.14 μs |  5.240 μs |  2.740 μs | 18.29 |    0.07 |       - |      - |    158 KB |        2.02 |
| NativeSingle      | TaLib.Functions.Dx | 10000 |   129.30 μs |  0.802 μs |  0.477 μs |  1.00 |    0.00 |  3.9063 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 10000 |   221.41 μs |  8.684 μs |  5.744 μs |  1.71 |    0.04 | 17.5781 | 3.9063 | 273.35 KB |        3.50 |
