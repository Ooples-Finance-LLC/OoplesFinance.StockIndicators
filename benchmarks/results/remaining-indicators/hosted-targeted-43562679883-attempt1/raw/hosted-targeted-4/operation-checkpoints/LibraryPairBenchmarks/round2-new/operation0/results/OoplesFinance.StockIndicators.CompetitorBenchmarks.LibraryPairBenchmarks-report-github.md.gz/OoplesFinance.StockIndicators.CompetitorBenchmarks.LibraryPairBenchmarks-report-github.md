```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Dx** |   **277.73 μs** | **12.107 μs** |  **7.205 μs** |  **1.00** |    **0.03** |  **105.55 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Dx |    19.32 μs |  2.359 μs |  1.560 μs |  0.07 |    0.01 |   40.55 KB |        0.38 |
|            |       |                    |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Dx** | **2,590.91 μs** | **24.952 μs** | **14.848 μs** |  **1.00** |    **0.01** | **1036.89 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Dx |   158.25 μs |  4.044 μs |  2.115 μs |  0.06 |    0.00 |   328.3 KB |        0.32 |
