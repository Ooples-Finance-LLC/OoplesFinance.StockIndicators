```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **TaLib.Candles.Harami** | **1000**  |  **83.79 μs** |  **5.150 μs** |  **3.406 μs** |      **-** |  **63.72 KB** |
| BuilderLatestOnly | TaLib.Candles.Harami | 1000  |  62.31 μs |  6.055 μs |  3.603 μs |      - |  15.84 KB |
| **BuilderFull**       | **TaLib.Candles.Harami** | **10000** | **497.06 μs** | **63.775 μs** | **37.952 μs** | **3.9063** | **556.27 KB** |
| BuilderLatestOnly | TaLib.Candles.Harami | 10000 | 481.58 μs | 69.003 μs | 41.063 μs |      - |  86.18 KB |
