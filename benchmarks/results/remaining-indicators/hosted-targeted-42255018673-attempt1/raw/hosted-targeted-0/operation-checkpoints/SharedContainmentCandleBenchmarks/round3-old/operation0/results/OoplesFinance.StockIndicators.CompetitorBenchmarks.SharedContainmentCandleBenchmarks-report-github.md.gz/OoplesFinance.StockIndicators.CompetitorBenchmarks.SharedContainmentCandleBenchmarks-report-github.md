```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error      | StdDev    | Gen0   | Allocated |
|------------------ |--------------------- |------ |----------:|-----------:|----------:|-------:|----------:|
| **BuilderFull**       | **TaLib.Candles.Harami** | **1000**  |  **75.41 μs** |  **14.123 μs** |  **9.341 μs** |      **-** |  **63.72 KB** |
| BuilderLatestOnly | TaLib.Candles.Harami | 1000  |  59.70 μs |   7.567 μs |  5.005 μs |      - |  15.84 KB |
| **BuilderFull**       | **TaLib.Candles.Harami** | **10000** | **504.30 μs** |  **75.684 μs** | **50.060 μs** | **3.9063** | **556.27 KB** |
| BuilderLatestOnly | TaLib.Candles.Harami | 10000 | 497.69 μs | 117.727 μs | 77.869 μs |      - |  86.18 KB |
