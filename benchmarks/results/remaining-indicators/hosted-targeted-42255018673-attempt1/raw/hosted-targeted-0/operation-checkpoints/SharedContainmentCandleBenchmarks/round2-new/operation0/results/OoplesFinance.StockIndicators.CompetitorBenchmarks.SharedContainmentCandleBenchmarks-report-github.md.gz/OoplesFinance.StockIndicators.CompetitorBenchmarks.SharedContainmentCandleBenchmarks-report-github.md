```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0   | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|-------:|-------:|----------:|------------:|
| **NativeSingle**      | **TaLib.Candles.Harami** | **1000**  |  **37.19 μs** |  **0.875 μs** |  **0.521 μs** |  **1.00** |    **0.02** |      **-** |      **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Harami | 1000  |  26.46 μs |  4.494 μs |  2.674 μs |  0.71 |    0.07 |      - |      - |    8.4 KB |        2.12 |
| BuilderFull       | TaLib.Candles.Harami | 1000  |  58.58 μs |  4.525 μs |  2.693 μs |  1.58 |    0.07 | 0.4883 |      - |  63.69 KB |       16.05 |
| BuilderLatestOnly | TaLib.Candles.Harami | 1000  |  44.19 μs |  4.843 μs |  3.203 μs |  1.19 |    0.08 |      - |      - |  15.81 KB |        3.98 |
|                   |                      |       |           |           |           |       |         |        |        |           |             |
| **NativeSingle**      | **TaLib.Candles.Harami** | **10000** | **374.74 μs** |  **9.556 μs** |  **6.321 μs** |  **1.00** |    **0.02** |      **-** |      **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Harami | 10000 | 264.24 μs | 68.613 μs | 45.383 μs |  0.71 |    0.12 |      - |      - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib.Candles.Harami | 10000 | 330.52 μs | 22.695 μs | 15.011 μs |  0.88 |    0.04 | 5.8594 | 1.9531 | 556.22 KB |       14.21 |
| BuilderLatestOnly | TaLib.Candles.Harami | 10000 | 313.28 μs | 30.262 μs | 20.017 μs |  0.84 |    0.05 |      - |      - |  86.13 KB |        2.20 |
