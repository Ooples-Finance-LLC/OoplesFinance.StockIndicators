```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error      | StdDev     | Median    | Gen0   | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|-----------:|-----------:|----------:|-------:|-------:|----------:|
| **BuilderFull**       | **TaLib.Candles.Harami** | **1000**  | **149.11 μs** | **184.865 μs** | **122.277 μs** |  **73.11 μs** |      **-** |      **-** |  **63.73 KB** |
| BuilderLatestOnly | TaLib.Candles.Harami | 1000  |  41.68 μs |   7.705 μs |   5.096 μs |  40.66 μs |      - |      - |  15.81 KB |
| **BuilderFull**       | **TaLib.Candles.Harami** | **10000** | **326.71 μs** |  **24.250 μs** |  **16.040 μs** | **317.00 μs** | **5.8594** | **1.9531** | **556.22 KB** |
| BuilderLatestOnly | TaLib.Candles.Harami | 10000 | 338.12 μs |  89.349 μs |  59.099 μs | 320.28 μs |      - |      - |  86.12 KB |
