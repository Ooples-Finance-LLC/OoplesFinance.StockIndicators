```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean      | Error     | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |----------:|----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Candles.Harami** |  **92.80 μs** |  **11.98 μs** |   **7.127 μs** |  **1.01** |    **0.10** |  **68.36 KB** |        **1.00** |
|        |       |                      |           |           |            |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Candles.Harami** | **922.99 μs** | **265.54 μs** | **175.639 μs** |  **1.05** |    **0.32** | **639.02 KB** |        **1.00** |
