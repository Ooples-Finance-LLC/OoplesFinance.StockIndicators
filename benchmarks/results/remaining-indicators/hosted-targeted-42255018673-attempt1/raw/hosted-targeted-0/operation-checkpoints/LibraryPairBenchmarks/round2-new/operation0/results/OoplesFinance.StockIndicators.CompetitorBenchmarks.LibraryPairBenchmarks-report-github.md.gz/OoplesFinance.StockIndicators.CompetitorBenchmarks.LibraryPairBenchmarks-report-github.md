```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Candles.Harami** | **111.08 μs** |   **7.634 μs** |   **3.993 μs** |  **1.00** |    **0.05** |  **68.38 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Candles.Harami |  58.65 μs |   1.629 μs |   0.852 μs |  0.53 |    0.02 |  18.97 KB |        0.28 |
|            |       |                      |           |            |            |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Candles.Harami** | **602.26 μs** | **152.937 μs** | **101.158 μs** |  **1.03** |    **0.27** | **638.39 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Candles.Harami | 575.29 μs |  33.898 μs |  22.421 μs |  0.99 |    0.21 | 124.44 KB |        0.19 |
