```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)iStar [22]** | **1000**  | **136.75 μs** | **42.749 μs** | **28.276 μs** |  **3.9063** |       **-** |  **63.72 KB** |
| BuilderLatestOnly | TaLib(...)iStar [22] | 1000  |  72.18 μs |  4.686 μs |  3.100 μs |  0.9766 |       - |  15.84 KB |
| **BuilderFull**       | **TaLib(...)iStar [22]** | **10000** | **560.61 μs** | **69.496 μs** | **45.967 μs** | **31.2500** | **11.7188** | **556.29 KB** |
| BuilderLatestOnly | TaLib(...)iStar [22] | 10000 | 533.63 μs | 79.467 μs | 52.563 μs |  3.9063 |       - |  86.18 KB |
