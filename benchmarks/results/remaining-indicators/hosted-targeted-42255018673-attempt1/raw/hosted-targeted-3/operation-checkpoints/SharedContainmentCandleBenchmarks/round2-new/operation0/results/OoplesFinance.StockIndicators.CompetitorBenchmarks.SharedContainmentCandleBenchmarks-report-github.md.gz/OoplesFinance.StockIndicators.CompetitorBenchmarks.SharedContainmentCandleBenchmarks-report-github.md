```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|-----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)iStar [22]** | **1000**  |  **67.81 μs** |   **0.403 μs** |  **0.211 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)iStar [22] | 1000  |  38.04 μs |   5.928 μs |  3.528 μs |  0.56 |    0.05 |  0.4883 |       - |    8.4 KB |        2.12 |
| BuilderFull       | TaLib(...)iStar [22] | 1000  |  60.09 μs |   6.577 μs |  4.350 μs |  0.89 |    0.06 |  3.9063 |  0.4883 |  63.69 KB |       16.05 |
| BuilderLatestOnly | TaLib(...)iStar [22] | 1000  |  56.16 μs |   7.964 μs |  5.268 μs |  0.83 |    0.07 |  0.9766 |       - |  15.81 KB |        3.98 |
|                   |                      |       |           |            |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)iStar [22]** | **10000** | **462.94 μs** |  **11.074 μs** |  **5.792 μs** |  **1.00** |    **0.02** |       **-** |       **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)iStar [22] | 10000 | 294.82 μs |  29.730 μs | 17.692 μs |  0.64 |    0.04 |  5.8594 |       - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib(...)iStar [22] | 10000 | 503.29 μs | 112.027 μs | 74.099 μs |  1.09 |    0.15 | 31.2500 | 11.7188 | 556.26 KB |       14.21 |
| BuilderLatestOnly | TaLib(...)iStar [22] | 10000 | 468.90 μs | 110.686 μs | 73.212 μs |  1.01 |    0.15 |  3.9063 |       - |  86.15 KB |        2.20 |
