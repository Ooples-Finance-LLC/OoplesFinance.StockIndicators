```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)iStar [22]** | **130.69 μs** |  **7.720 μs** |  **4.594 μs** |  **1.00** |    **0.05** |  **68.38 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)iStar [22] |  61.88 μs |  1.709 μs |  0.894 μs |  0.47 |    0.02 |  19.58 KB |        0.29 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)iStar [22]** | **505.30 μs** | **44.894 μs** | **26.716 μs** |  **1.00** |    **0.07** |    **639 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)iStar [22] | 653.82 μs | 18.332 μs | 10.909 μs |  1.30 |    0.06 | 125.38 KB |        0.20 |
