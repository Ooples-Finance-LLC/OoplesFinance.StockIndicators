```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)igeon [26]** | **153.29 μs** | **6.014 μs** | **3.145 μs** |  **1.00** |    **0.03** |  **68.38 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)igeon [26] |  36.49 μs | 7.934 μs | 5.248 μs |  0.24 |    0.03 |   19.3 KB |        0.28 |
|            |       |                      |           |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)igeon [26]** | **213.84 μs** | **9.080 μs** | **4.749 μs** |  **1.00** |    **0.03** | **637.69 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)igeon [26] | 280.47 μs | 8.254 μs | 5.459 μs |  1.31 |    0.04 | 122.42 KB |        0.19 |
