```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)igeon [26]** | **1000**  |  **44.40 μs** |  **4.399 μs** |  **2.618 μs** |  **3.9063** |       **-** |  **63.72 KB** |
| BuilderLatestOnly | TaLib(...)igeon [26] | 1000  |  43.92 μs |  4.870 μs |  3.221 μs |  0.9766 |       - |  15.84 KB |
| **BuilderFull**       | **TaLib(...)igeon [26]** | **10000** | **301.89 μs** | **18.977 μs** | **11.293 μs** | **33.2031** | **13.6719** | **556.26 KB** |
| BuilderLatestOnly | TaLib(...)igeon [26] | 10000 | 288.75 μs | 40.130 μs | 23.880 μs |  3.9063 |       - |  86.16 KB |
