```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)igeon [26]** | **1000**  |  **52.83 μs** |  **3.296 μs** |  **2.180 μs** |  **3.9063** |       **-** |  **63.72 KB** |
| BuilderLatestOnly | TaLib(...)igeon [26] | 1000  |  40.87 μs |  2.353 μs |  1.400 μs |  0.9766 |       - |  15.84 KB |
| **BuilderFull**       | **TaLib(...)igeon [26]** | **10000** | **305.89 μs** | **40.725 μs** | **26.937 μs** | **33.2031** | **13.6719** | **556.26 KB** |
| BuilderLatestOnly | TaLib(...)igeon [26] | 10000 | 299.25 μs | 50.745 μs | 33.565 μs |  3.9063 |       - |  86.16 KB |
