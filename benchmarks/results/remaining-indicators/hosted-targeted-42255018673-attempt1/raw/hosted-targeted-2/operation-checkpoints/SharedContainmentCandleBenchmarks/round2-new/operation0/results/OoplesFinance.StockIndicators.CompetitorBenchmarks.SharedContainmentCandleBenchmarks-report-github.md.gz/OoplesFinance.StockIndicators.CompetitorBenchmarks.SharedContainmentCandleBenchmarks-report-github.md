```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)igeon [26]** | **1000**  |  **27.36 μs** |  **0.194 μs** |  **0.116 μs** |  **1.00** |    **0.01** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)igeon [26] | 1000  |  15.97 μs |  4.116 μs |  2.722 μs |  0.58 |    0.09 |  0.4883 |       - |    8.4 KB |        2.12 |
| BuilderFull       | TaLib(...)igeon [26] | 1000  |  26.56 μs |  3.037 μs |  1.807 μs |  0.97 |    0.06 |  3.9063 |  0.4883 |  63.69 KB |       16.05 |
| BuilderLatestOnly | TaLib(...)igeon [26] | 1000  |  24.07 μs |  0.976 μs |  0.510 μs |  0.88 |    0.02 |  0.9766 |       - |  15.81 KB |        3.98 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)igeon [26]** | **10000** | **192.34 μs** |  **2.284 μs** |  **1.359 μs** |  **1.00** |    **0.01** |  **1.9531** |       **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib(...)igeon [26] | 10000 | 151.81 μs |  5.305 μs |  2.775 μs |  0.79 |    0.01 |  6.8359 |  0.9766 |  78.72 KB |        2.01 |
| BuilderFull       | TaLib(...)igeon [26] | 10000 | 206.79 μs | 37.943 μs | 25.097 μs |  1.08 |    0.12 | 33.2031 | 13.6719 | 556.23 KB |       14.21 |
| BuilderLatestOnly | TaLib(...)igeon [26] | 10000 | 185.36 μs | 27.575 μs | 16.410 μs |  0.96 |    0.08 |  3.9063 |       - |  86.14 KB |        2.20 |
