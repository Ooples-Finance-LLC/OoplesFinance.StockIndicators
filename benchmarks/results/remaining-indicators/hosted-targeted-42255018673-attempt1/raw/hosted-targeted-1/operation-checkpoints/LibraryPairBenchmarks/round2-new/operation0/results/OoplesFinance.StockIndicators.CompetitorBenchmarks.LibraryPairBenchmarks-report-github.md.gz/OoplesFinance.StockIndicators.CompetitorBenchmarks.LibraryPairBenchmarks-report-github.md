```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Cross [25]** | **114.76 μs** | **50.385 μs** | **33.327 μs** |  **1.08** |    **0.43** |  **68.38 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Cross [25] |  75.79 μs |  1.049 μs |  0.549 μs |  0.71 |    0.19 |  18.31 KB |        0.27 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Cross [25]** | **526.86 μs** | **62.203 μs** | **32.534 μs** |  **1.00** |    **0.08** |    **639 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Cross [25] | 751.29 μs | 16.307 μs |  9.704 μs |  1.43 |    0.09 | 125.05 KB |        0.20 |
