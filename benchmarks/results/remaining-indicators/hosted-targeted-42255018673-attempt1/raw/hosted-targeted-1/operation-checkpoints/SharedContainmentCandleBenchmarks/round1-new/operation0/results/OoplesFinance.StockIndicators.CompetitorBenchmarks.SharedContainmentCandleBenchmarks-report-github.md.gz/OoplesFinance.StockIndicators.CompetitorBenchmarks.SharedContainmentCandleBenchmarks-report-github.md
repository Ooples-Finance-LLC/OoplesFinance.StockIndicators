```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)Cross [25]** | **1000**  |  **85.84 μs** | **22.670 μs** | **11.857 μs** |  **3.9063** |       **-** |  **63.69 KB** |
| BuilderLatestOnly | TaLib(...)Cross [25] | 1000  |  57.79 μs |  5.919 μs |  3.915 μs |  0.9766 |       - |  15.81 KB |
| **BuilderFull**       | **TaLib(...)Cross [25]** | **10000** | **494.49 μs** | **88.358 μs** | **52.581 μs** | **31.2500** | **11.7188** | **556.25 KB** |
| BuilderLatestOnly | TaLib(...)Cross [25] | 10000 | 488.43 μs | 70.931 μs | 46.916 μs |  3.9063 |       - |  86.15 KB |
