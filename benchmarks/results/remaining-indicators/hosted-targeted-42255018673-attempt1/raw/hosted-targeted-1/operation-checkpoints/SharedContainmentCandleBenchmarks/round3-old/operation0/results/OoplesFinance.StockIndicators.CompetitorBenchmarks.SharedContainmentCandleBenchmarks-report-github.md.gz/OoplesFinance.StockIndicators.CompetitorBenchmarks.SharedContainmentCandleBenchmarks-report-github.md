```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)Cross [25]** | **1000**  | **116.92 μs** | **18.637 μs** | **12.327 μs** |  **3.9063** |       **-** |  **63.76 KB** |
| BuilderLatestOnly | TaLib(...)Cross [25] | 1000  |  69.69 μs |  8.639 μs |  5.714 μs |  0.9766 |       - |  15.84 KB |
| **BuilderFull**       | **TaLib(...)Cross [25]** | **10000** | **542.59 μs** | **63.323 μs** | **41.884 μs** | **31.2500** | **11.7188** | **556.28 KB** |
| BuilderLatestOnly | TaLib(...)Cross [25] | 10000 | 488.41 μs | 34.892 μs | 18.249 μs |  3.9063 |       - |  86.18 KB |
