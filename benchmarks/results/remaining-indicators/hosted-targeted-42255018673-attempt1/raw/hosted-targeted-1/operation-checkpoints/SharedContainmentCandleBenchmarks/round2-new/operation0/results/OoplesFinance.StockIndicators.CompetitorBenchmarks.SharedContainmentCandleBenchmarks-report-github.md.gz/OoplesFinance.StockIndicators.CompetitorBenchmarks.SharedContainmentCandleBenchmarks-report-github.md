```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|-----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)Cross [25]** | **1000**  |  **66.67 μs** |   **0.447 μs** |  **0.266 μs** |  **1.00** |    **0.01** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)Cross [25] | 1000  |  35.00 μs |   8.602 μs |  5.690 μs |  0.52 |    0.08 |  0.4883 |       - |    8.4 KB |        2.12 |
| BuilderFull       | TaLib(...)Cross [25] | 1000  |  57.66 μs |   7.038 μs |  3.681 μs |  0.86 |    0.05 |  3.9063 |  0.4883 |  63.69 KB |       16.05 |
| BuilderLatestOnly | TaLib(...)Cross [25] | 1000  |  57.41 μs |   8.664 μs |  5.731 μs |  0.86 |    0.08 |  0.9766 |       - |  15.81 KB |        3.98 |
|                   |                      |       |           |            |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)Cross [25]** | **10000** | **450.35 μs** |   **5.818 μs** |  **3.462 μs** |  **1.00** |    **0.01** |       **-** |       **-** |  **39.16 KB** |        **1.00** |
| NativeParallel    | TaLib(...)Cross [25] | 10000 | 327.93 μs |  88.018 μs | 58.219 μs |  0.73 |    0.12 |  3.9063 |       - |  78.74 KB |        2.01 |
| BuilderFull       | TaLib(...)Cross [25] | 10000 | 653.04 μs | 128.610 μs | 85.067 μs |  1.45 |    0.18 | 31.2500 | 11.7188 | 556.26 KB |       14.21 |
| BuilderLatestOnly | TaLib(...)Cross [25] | 10000 | 479.59 μs |  89.166 μs | 58.978 μs |  1.06 |    0.13 |  3.9063 |       - |  86.15 KB |        2.20 |
