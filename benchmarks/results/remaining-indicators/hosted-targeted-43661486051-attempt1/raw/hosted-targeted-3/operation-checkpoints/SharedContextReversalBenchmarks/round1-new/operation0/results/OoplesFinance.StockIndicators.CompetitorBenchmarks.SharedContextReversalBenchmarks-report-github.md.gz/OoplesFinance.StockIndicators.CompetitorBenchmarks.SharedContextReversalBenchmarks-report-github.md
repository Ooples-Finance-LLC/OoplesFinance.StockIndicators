```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev  | Gen0   | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)gStar [26]** | **1000**  | **131.5 μs** |  **9.75 μs** | **5.80 μs** |      **-** |     **64 KB** |
| BuilderLatestOnly | TaLib(...)gStar [26] | 1000  | 123.6 μs |  2.47 μs | 1.63 μs |      - |  16.13 KB |
| **BuilderFull**       | **TaLib(...)gStar [26]** | **10000** | **431.2 μs** |  **2.30 μs** | **1.20 μs** | **3.9063** | **556.55 KB** |
| BuilderLatestOnly | TaLib(...)gStar [26] | 10000 | 394.2 μs | 13.22 μs | 6.91 μs |      - |  86.46 KB |
