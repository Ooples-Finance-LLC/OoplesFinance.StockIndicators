```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)gStar [26]** | **1000**  | **100.74 μs** |  **2.454 μs** |  **1.283 μs** |      **-** |     **64 KB** |
| BuilderLatestOnly | TaLib(...)gStar [26] | 1000  |  97.41 μs |  2.210 μs |  1.156 μs |      - |  16.13 KB |
| **BuilderFull**       | **TaLib(...)gStar [26]** | **10000** | **466.37 μs** | **10.379 μs** |  **5.428 μs** | **3.9063** | **556.55 KB** |
| BuilderLatestOnly | TaLib(...)gStar [26] | 10000 | 439.16 μs | 31.343 μs | 18.652 μs |      - |  86.46 KB |
