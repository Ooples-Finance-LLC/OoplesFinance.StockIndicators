```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|-------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)gStar [26]** | **1000**  |  **53.20 μs** |  **1.438 μs** |  **0.752 μs** |  **1.00** |    **0.02** |      **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)gStar [26] | 1000  | 103.73 μs | 17.765 μs | 11.750 μs |  1.95 |    0.21 |      - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib(...)gStar [26] | 1000  | 103.87 μs | 11.122 μs |  7.357 μs |  1.95 |    0.13 |      - |  63.98 KB |       16.12 |
| BuilderLatestOnly | TaLib(...)gStar [26] | 1000  |  98.30 μs |  5.721 μs |  3.405 μs |  1.85 |    0.07 |      - |  16.13 KB |        4.06 |
|                   |                      |       |           |           |           |       |         |        |           |             |
| **NativeSingle**      | **TaLib(...)gStar [26]** | **10000** | **533.39 μs** |  **7.337 μs** |  **4.366 μs** |  **1.00** |    **0.01** |      **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)gStar [26] | 10000 | 339.32 μs | 15.617 μs |  8.168 μs |  0.64 |    0.02 |      - |  78.74 KB |        2.01 |
| BuilderFull       | TaLib(...)gStar [26] | 10000 | 401.11 μs | 22.341 μs | 11.685 μs |  0.75 |    0.02 | 3.9063 | 556.52 KB |       14.21 |
| BuilderLatestOnly | TaLib(...)gStar [26] | 10000 | 386.56 μs | 29.060 μs | 19.221 μs |  0.72 |    0.03 |      - |  86.45 KB |        2.21 |
