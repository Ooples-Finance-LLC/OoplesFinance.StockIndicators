```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)gStar [26]** |  **97.44 μs** | **18.397 μs** | **10.948 μs** |  **1.01** |    **0.15** |   **68.5 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)gStar [26] |  81.58 μs |  4.419 μs |  2.311 μs |  0.85 |    0.09 |  18.92 KB |        0.28 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)gStar [26]** | **437.41 μs** | **32.523 μs** | **19.354 μs** |  **1.00** |    **0.06** | **638.55 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)gStar [26] | 802.47 μs | 35.503 μs | 23.483 μs |  1.84 |    0.09 | 124.77 KB |        0.20 |
