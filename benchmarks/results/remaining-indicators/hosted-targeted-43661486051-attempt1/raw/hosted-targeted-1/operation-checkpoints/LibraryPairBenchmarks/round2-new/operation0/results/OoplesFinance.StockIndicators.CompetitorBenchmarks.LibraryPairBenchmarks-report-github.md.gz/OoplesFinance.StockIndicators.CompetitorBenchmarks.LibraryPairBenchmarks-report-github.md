```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)ngMan [24]** |  **83.81 μs** | **14.974 μs** |  **8.911 μs** |  **1.01** |    **0.14** |  **69.76 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)ngMan [24] |  95.83 μs |  4.588 μs |  2.400 μs |  1.15 |    0.11 |  16.95 KB |        0.24 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)ngMan [24]** | **614.45 μs** | **23.863 μs** | **12.481 μs** |  **1.00** |    **0.03** | **639.77 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)ngMan [24] | 944.43 μs | 28.757 μs | 19.021 μs |  1.54 |    0.04 | 122.47 KB |        0.19 |
