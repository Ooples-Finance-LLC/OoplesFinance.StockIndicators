```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)ngMan [24]** | **1000**  |  **65.29 μs** |  **0.940 μs** |  **0.622 μs** |  **1.00** |    **0.01** |       **-** |      **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)ngMan [24] | 1000  | 109.33 μs |  2.770 μs |  1.449 μs |  1.67 |    0.03 |       - |      - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib(...)ngMan [24] | 1000  | 122.46 μs |  4.630 μs |  2.755 μs |  1.88 |    0.04 |  3.9063 |      - |  66.45 KB |       16.74 |
| BuilderLatestOnly | TaLib(...)ngMan [24] | 1000  | 119.43 μs |  4.258 μs |  2.534 μs |  1.83 |    0.04 |  0.9766 |      - |  18.56 KB |        4.68 |
|                   |                      |       |           |           |           |       |         |         |        |           |             |
| **NativeSingle**      | **TaLib(...)ngMan [24]** | **10000** | **659.32 μs** |  **3.847 μs** |  **2.012 μs** |  **1.00** |    **0.00** |       **-** |      **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib(...)ngMan [24] | 10000 | 418.32 μs |  7.676 μs |  4.015 μs |  0.63 |    0.01 |  3.9063 |      - |  78.74 KB |        2.01 |
| BuilderFull       | TaLib(...)ngMan [24] | 10000 | 520.85 μs | 58.337 μs | 34.716 μs |  0.79 |    0.05 | 31.2500 | 7.8125 |    559 KB |       14.28 |
| BuilderLatestOnly | TaLib(...)ngMan [24] | 10000 | 498.21 μs | 38.695 μs | 23.027 μs |  0.76 |    0.03 |  3.9063 |      - |   88.9 KB |        2.27 |
