```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Candles.Hammer** |   **104.1 μs** |  **3.42 μs** |  **1.79 μs** |  **1.00** |    **0.02** |  **69.73 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Candles.Hammer |   129.6 μs |  6.14 μs |  3.65 μs |  1.25 |    0.04 |  19.25 KB |        0.28 |
|            |       |                      |            |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Candles.Hammer** |   **774.3 μs** | **40.27 μs** | **23.96 μs** |  **1.00** |    **0.04** | **640.02 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Candles.Hammer | 1,224.1 μs | 28.53 μs | 14.92 μs |  1.58 |    0.05 | 125.05 KB |        0.20 |
