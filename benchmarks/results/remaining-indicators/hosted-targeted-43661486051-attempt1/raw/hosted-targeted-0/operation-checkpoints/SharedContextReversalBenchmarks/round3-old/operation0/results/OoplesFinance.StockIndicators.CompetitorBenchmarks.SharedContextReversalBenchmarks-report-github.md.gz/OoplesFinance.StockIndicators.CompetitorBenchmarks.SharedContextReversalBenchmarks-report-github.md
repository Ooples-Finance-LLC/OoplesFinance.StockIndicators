```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib.Candles.Hammer** | **1000**  | **145.7 μs** |  **7.93 μs** |  **4.72 μs** |  **3.9063** |      **-** |  **66.44 KB** |
| BuilderLatestOnly | TaLib.Candles.Hammer | 1000  | 140.8 μs |  4.21 μs |  2.20 μs |  0.9766 |      - |  18.56 KB |
| **BuilderFull**       | **TaLib.Candles.Hammer** | **10000** | **680.9 μs** | **51.79 μs** | **34.26 μs** | **31.2500** | **7.8125** |    **559 KB** |
| BuilderLatestOnly | TaLib.Candles.Hammer | 10000 | 628.6 μs | 53.81 μs | 35.59 μs |  3.9063 |      - |   88.9 KB |
