```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |---------:|---------:|---------:|------:|--------:|--------:|-------:|----------:|------------:|
| **NativeSingle**      | **TaLib.Candles.Hammer** | **1000**  | **114.1 μs** |  **1.14 μs** |  **0.60 μs** |  **1.00** |    **0.01** |       **-** |      **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Hammer | 1000  | 128.9 μs |  6.00 μs |  3.97 μs |  1.13 |    0.03 |       - |      - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib.Candles.Hammer | 1000  | 143.4 μs |  2.75 μs |  1.64 μs |  1.26 |    0.01 |  3.9063 |      - |  66.46 KB |       16.75 |
| BuilderLatestOnly | TaLib.Candles.Hammer | 1000  | 145.7 μs | 10.97 μs |  7.26 μs |  1.28 |    0.06 |  0.9766 |      - |  18.56 KB |        4.68 |
|                   |                      |       |          |          |          |       |         |         |        |           |             |
| **NativeSingle**      | **TaLib.Candles.Hammer** | **10000** | **825.6 μs** |  **4.52 μs** |  **2.69 μs** |  **1.00** |    **0.00** |       **-** |      **-** |  **39.19 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Hammer | 10000 | 496.0 μs |  7.53 μs |  3.94 μs |  0.60 |    0.00 |  3.9063 |      - |  78.74 KB |        2.01 |
| BuilderFull       | TaLib.Candles.Hammer | 10000 | 637.5 μs | 50.18 μs | 33.19 μs |  0.77 |    0.04 | 31.2500 | 7.8125 | 559.01 KB |       14.27 |
| BuilderLatestOnly | TaLib.Candles.Hammer | 10000 | 641.2 μs | 48.98 μs | 32.40 μs |  0.78 |    0.04 |  3.9063 |      - |   88.9 KB |        2.27 |
