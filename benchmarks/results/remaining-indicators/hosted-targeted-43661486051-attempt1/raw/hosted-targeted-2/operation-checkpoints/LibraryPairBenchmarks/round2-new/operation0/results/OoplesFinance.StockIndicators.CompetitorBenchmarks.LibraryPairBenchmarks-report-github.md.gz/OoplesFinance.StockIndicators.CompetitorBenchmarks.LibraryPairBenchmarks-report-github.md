```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)ammer [28]** | **100.63 μs** | **12.240 μs** |  **7.284 μs** |  **1.00** |    **0.10** |  **68.54 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)ammer [28] |  83.82 μs |  1.958 μs |  1.295 μs |  0.84 |    0.06 |  19.63 KB |        0.29 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)ammer [28]** | **454.01 μs** | **25.103 μs** | **14.938 μs** |  **1.00** |    **0.04** | **638.88 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)ammer [28] | 823.44 μs | 35.797 μs | 23.677 μs |  1.82 |    0.07 | 125.09 KB |        0.20 |
