```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev  | Gen0   | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)ammer [28]** | **1000**  | **103.3 μs** |  **4.20 μs** | **2.50 μs** |      **-** |     **64 KB** |
| BuilderLatestOnly | TaLib(...)ammer [28] | 1000  | 100.6 μs |  9.04 μs | 5.38 μs |      - |  16.13 KB |
| **BuilderFull**       | **TaLib(...)ammer [28]** | **10000** | **471.7 μs** | **13.78 μs** | **7.21 μs** | **3.9063** | **556.55 KB** |
| BuilderLatestOnly | TaLib(...)ammer [28] | 10000 | 437.1 μs |  5.13 μs | 2.68 μs |      - |  86.46 KB |
