```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0   | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)ammer [28]** | **1000**  | **103.6 μs** |  **6.20 μs** |  **3.24 μs** |      **-** |     **64 KB** |
| BuilderLatestOnly | TaLib(...)ammer [28] | 1000  | 102.8 μs | 10.00 μs |  6.62 μs |      - |  16.13 KB |
| **BuilderFull**       | **TaLib(...)ammer [28]** | **10000** | **441.4 μs** | **72.49 μs** | **47.95 μs** | **3.9063** | **556.55 KB** |
| BuilderLatestOnly | TaLib(...)ammer [28] | 10000 | 390.3 μs | 31.65 μs | 20.93 μs |      - |  86.45 KB |
