```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|-------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)ammer [28]** | **1000**  |  **54.02 μs** |  **0.302 μs** |  **0.158 μs** |  **1.00** |    **0.00** |      **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)ammer [28] | 1000  |  86.08 μs |  1.791 μs |  0.937 μs |  1.59 |    0.02 |      - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib(...)ammer [28] | 1000  | 102.62 μs |  6.517 μs |  3.409 μs |  1.90 |    0.06 |      - |  64.01 KB |       16.13 |
| BuilderLatestOnly | TaLib(...)ammer [28] | 1000  |  99.04 μs |  1.377 μs |  0.720 μs |  1.83 |    0.01 |      - |  16.13 KB |        4.06 |
|                   |                      |       |           |           |           |       |         |        |           |             |
| **NativeSingle**      | **TaLib(...)ammer [28]** | **10000** | **542.81 μs** |  **3.137 μs** |  **1.640 μs** |  **1.00** |    **0.00** |      **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)ammer [28] | 10000 | 344.19 μs |  8.491 μs |  4.441 μs |  0.63 |    0.01 |      - |  78.74 KB |        2.01 |
| BuilderFull       | TaLib(...)ammer [28] | 10000 | 409.24 μs |  8.440 μs |  4.414 μs |  0.75 |    0.01 | 3.9063 | 556.52 KB |       14.21 |
| BuilderLatestOnly | TaLib(...)ammer [28] | 10000 | 393.01 μs | 32.773 μs | 21.678 μs |  0.72 |    0.04 |      - |  86.45 KB |        2.21 |
