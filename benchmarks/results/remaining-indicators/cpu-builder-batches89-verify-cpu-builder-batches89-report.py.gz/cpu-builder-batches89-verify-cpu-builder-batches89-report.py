from pathlib import Path
import hashlib,json,re
from playwright.sync_api import sync_playwright
out=Path('C:/Users/cheat/Documents/OoplesFinance-Reports/cpu-builder-refresh-39740961454');stage=json.loads((out/'staged.json').read_text());candidate=out/'candidate.html'
def data(path,name):return json.loads(re.search(r'<script[^>]*id="'+name+r'"[^>]*>(.*?)</script>',path.read_text(encoding='utf-8'),re.S)[1])
for name in ['dataset','archived-baseline-dataset']:assert data(out/'before.html',name)==data(candidate,name)
status=data(candidate,'rollout-status-data');assert status['measurement_totals']=={**stage['verdicts'],'expected':1604,'measured':544,'pending':1060}
builder=data(candidate,'current-competitor-data');before=data(out/'before.html','current-competitor-data');assert builder['receipts'][:43]==before['receipts'] and len(builder['receipts'])==57 and builder['verdicts']==stage['verdicts']
with sync_playwright() as p:
 b=p.chromium.launch(channel='msedge',headless=True);page=b.new_page(viewport={'width':1600,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto(candidate.as_uri())
 assert page.locator('#builder-current-results tbody tr').count()==544
 for r in stage['rows']:
  row=page.locator(f'#builder-current-results tr[data-builder-pair="{r["pair"]}"][data-bars="{r["bars"]}"][data-mode="{r["mode"]}"]')
  cells=row.locator('td').all_inner_texts();assert cells[0]==r['pair'] and cells[1]==f'{r["bars"]:,}'
  assert cells[3:6]==[f'{r["ooples"]["mean_ns"]/1e6:.6f}',f'{r["native"]["NativeSingle"]["mean_ns"]/1e6:.6f}',f'{r["native"]["NativeParallel"]["mean_ns"]/1e6:.6f}']
  assert cells[6]=={'faster':'Faster than both','slower':'Slower than at least one','inconclusive':'Inconclusive'}[r['verdict']]
  assert row.locator('a').get_attribute('href').endswith('/'+r['run_id'])
 assert '544 / 1604' in page.locator('#rollout-status').inner_text() and '1060 pending' in page.locator('#current-competitors').inner_text()
 page.evaluate("window.scrollTo(0,document.querySelector('#current-competitors').offsetTop)");page.screenshot(path=str(out/'builder-results.png'));assert not errors;b.close()
(out/'builder-verification.json').write_text(json.dumps({'run_id':'39740961454','builder_comparisons':544,'new_builder_comparisons':152,'unchanged_baseline_comparisons':802,'report_sha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'javascript_errors':errors,'status_totals':status['measurement_totals']},indent=2))
print('Verified all544 displayed builder rows and provenance; baseline802 and prior392 builder records unchanged')
