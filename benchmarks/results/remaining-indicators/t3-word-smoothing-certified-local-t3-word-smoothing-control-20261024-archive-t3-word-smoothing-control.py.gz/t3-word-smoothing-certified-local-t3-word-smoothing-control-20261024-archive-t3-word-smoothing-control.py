from pathlib import Path
import sys
import gzip,hashlib,json
ROOT=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
name='t3-word-smoothing'
RUN=f'local-{name}-control-20261024'
RAW=ROOT/RUN
REPO=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
OUT=REPO/'benchmarks/results/remaining-indicators'/RUN
summary=json.loads((RAW/'verified-summary.json').read_text(encoding='utf-8'))
count=144
assert summary[f'all_{count}_cases_verified']
proof=json.loads((RAW/'provenance.json').read_text(encoding='utf-8'))
accepted=not any(r['verdict']=='slower' for r in summary['decisions']) and any(r['verdict']=='faster' for r in summary['decisions'])
state=json.loads((RAW/'status.json').read_text(encoding='utf-8'))
paths=['status.json','provenance.json','binary-manifest.json','verified-summary.json']
paths += [Path(r['report']).relative_to(RAW).as_posix() for r in state['rounds']]
paths += [p.name for p in RAW.glob('*.log')]
paths += [p.relative_to(RAW).as_posix() for p in (RAW/'invalidated-attempts').rglob('*') if p.is_file()]
OUT.mkdir(exist_ok=True)
manifest={}
for relative in paths:
 data=(RAW/relative).read_bytes();target=OUT/(relative+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(gzip.compress(data,mtime=0));manifest[relative]={'sha256':hashlib.sha256(data).hexdigest(),'archive':target.relative_to(REPO).as_posix()}
scripts={}
for script in [f'measure-{name}-control.py',f'verify-{name}-control.py']:
 data=(ROOT/script).read_bytes();(OUT/(script+'.gz')).write_bytes(gzip.compress(data,mtime=0));scripts[script]=hashlib.sha256(data).hexdigest()
(OUT/'decision.json').write_text(json.dumps({'status':'candidate-qualified-for-integration' if accepted else 'candidate-rejected-or-inconclusive','sources':summary['sources'],'candidate_code_source':proof['candidate_code_source'],'measurement_location':'Local Windows; preserved source-qualified binaries; only production DLL differs','decisions':summary['decisions'],'archives':manifest,'scripts':scripts,'report_imported':False,'production_integrated':False},indent=2)+'\n',encoding='utf-8',newline='\n')
(OUT/'.gitattributes').write_bytes(b'* -text\n')
print('Archived',count,'cases; qualified for integration:',accepted)

# Preserve the qualified-baseline diagnostic that selected this batch.
PROFILE=ROOT/'t3-qualified-profile-20261024'
profile_expected={'status.json': '64fafe9bce0065f0f118a2d1f21f4f9e25d96b36b905483d439ae1ef308194f6', 'ready.json': '51c33e1c72b9ef545d8912ddac6b0959a04ae552ac99d32ad4373501f6e037c0', 'completed.json': '1d54a69b75d444e2a0f7cd5ee186e17bb42e95cfb9379f3758e984f7283e51eb', 'profile-summary.json': '842985553a3f0be6719502ce38cf9e653702afc2dad9aac8b5d7496576ca5dac', 't3.speedscope.json': '6b900a86d10bba79fd9e2b5e0dfd01e9ade500c0252afda297770f2a2661e600', 'worker.ps1': 'f5d5b3738193a8ca7cdc93e6ecae6159ff032f165524acef2a3707118ec16d9f'}
profile_archives={}
for relative,sha in profile_expected.items():
 data=(PROFILE/relative).read_bytes();assert hashlib.sha256(data).hexdigest()==sha
 target=OUT/'profile'/(relative+'.gz');target.parent.mkdir(exist_ok=True)
 target.write_bytes(gzip.compress(data,mtime=0));profile_archives[relative]={'sha256':sha,'archive':target.relative_to(REPO).as_posix()}
decision=json.loads((OUT/'decision.json').read_text())
decision['profile_evidence']={'kind':'Qualified-baseline sampled-thread diagnostic; not benchmark timing','archives':profile_archives}
(OUT/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')

model_hashes={'review-t3-word-smoothing-model-20261024.py': 'b6b9a6a4cbd31920c092adf0327377004448e4c270e70fb69629bf1f3c68f586', 't3-word-smoothing-model-review-20261024.json': '111483ce9fa67043f584e5bd2892e936da0692ec9ebf6005849d0c9bd382006c'}
model_archives={}
for relative,sha in model_hashes.items():
 data=(ROOT/relative).read_bytes();assert hashlib.sha256(data).hexdigest()==sha
 target=OUT/(relative+'.gz');target.write_bytes(gzip.compress(data,mtime=0))
 model_archives[relative]={'sha256':sha,'archive':target.relative_to(REPO).as_posix()}
decision=json.loads((OUT/'decision.json').read_text())
decision['independent_arithmetic_model']=model_archives
(OUT/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
