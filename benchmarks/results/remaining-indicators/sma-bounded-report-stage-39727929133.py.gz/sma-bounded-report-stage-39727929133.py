"""Replace only SMA rows from the final candidate ABBA round, preserving full baseline."""
from pathlib import Path
import copy,hashlib,json,re,sys
ROOT=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
RUN='39727929133';BASE='29a41d8b7956a05812a5950631f07b84bcb04ee0';SOURCE='e4c3cbf1771d87c39ff05b28d7b7891b66e68b12'
live=Path('C:/Users/cheat/Documents/OoplesFinance-Reports/competitor-performance.html');out=live.parent/('sma-refresh-'+RUN);out.mkdir(exist_ok=True)
assert not (out/'before.html').exists()
original=live.read_bytes();s=original.decode('utf-8')
sys.path.insert(0,'C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-primary-baseline-report-20261021/benchmarks')
from primary_baseline_report import embedded,script
from current_report_status import refresh_status
s,status=refresh_status(s,Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022'))
assert not status['source_matches_published_production'] and status['changed_production_files']==['src/Helpers/CertifiedMeanRelativeError.cs']
data=embedded(s,'dataset');before=copy.deepcopy(data);assert data['evidence']['sourceSha']==BASE and not data['evidence'].get('rowOverrides')
control=json.loads((ROOT/('sma-bounded-hosted-control-'+RUN)/'comparison.json').read_text())
assert control['complete'] and control['run_id']==RUN and [r['version'] for r in control['rounds']]==['old','new','new','old']
# Use the final candidate round by chronological order, never the fastest round.
receipt=control['rounds'][2];assert receipt['version']=='new' and receipt['source_sha']==SOURCE
rawpath=ROOT/('sma-bounded-hosted-control-'+RUN)/Path(*Path(receipt['report_file']).parts[1:]);rawbytes=rawpath.read_bytes();assert hashlib.sha256(rawbytes).hexdigest()==receipt['report_sha256'];raw=json.loads(rawbytes)
url='https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/'+RUN
for item in receipt['rows']:
 row=next(r for r in data['rows'] if r['pair']==item['pair'] and r['bars']==item['bars'])
 for method,arm in [('Ooples','ooples'),('Competitor','competitor')]:
  matches=[b for b in raw['Benchmarks'] if b['Method']==method and f'Bars: {item["bars"]},' in b['FullName']];assert len(matches)==1
  b=matches[0];stats=b['Statistics'];assert stats['Mean']==item[arm]['mean_ns'] and stats['N']==len(stats['OriginalValues']) and stats['N']>=7
  row.update({arm+'_mean_ns':stats['Mean'],arm+'_stddev_ns':stats['StandardDeviation'],arm+'_samples':stats['N'],arm+'_allocated_bytes':b['Memory']['BytesAllocatedPerOperation']})
  row['raw'][method]={'samples':stats['OriginalValues'],'host':raw['HostEnvironmentInfo'],'report':receipt['report_file'],'confidence_interval':stats['ConfidenceInterval']}
 row.update(competitor_over_ooples=item['competitor_over_ooples'],source_sha=SOURCE,measurement_run_url=url)
override={'pair':'Skender.GetSmaAnalysis','sourceSha':SOURCE,'runUrl':url,'reportSha256':receipt['report_sha256'],'round':2,'selection':'Latest candidate round in chronological ABBA order, not fastest round.'}
data['evidence'].update(sourceSha=None,baseSourceSha=BASE,rowOverrides=[override])
def replace_data(document,name,value):
 result,count=re.subn(r'<script[^>]*id="'+re.escape(name)+r'"[^>]*>.*?</script>',lambda _:script(name,value),document,flags=re.S);assert count==1;return result
s=replace_data(s,'dataset',data)
status['row_overrides']=[override];s=replace_data(s,'rollout-status-data',status)
label=f'Measured builds: {BASE[:8]} (800 comparisons), {SOURCE[:8]} (two SMA comparisons).'
assert s.count('Measured build: '+BASE[:8]+'.')==1;s=s.replace('Measured build: '+BASE[:8]+'.',label)
s,count=re.subn(r'(<section id="explorer"[^>]*>.*?<p class="sub">).*?(</p>)',lambda m:m[1]+label+' Click an API for its source, samples, and runner details.'+m[2],s,count=1,flags=re.S);assert count==1
old='Later production changes in the published PR are not measured by this baseline run.'
assert s.count(old)==1;s=s.replace(old,f'The full run predates the SMA change. The two SMA rows use the latest candidate round from {SOURCE[:8]}; the other 800 retain the complete baseline run.')
s=s.replace('Three warmups and three measured iterations; one invocation per iteration, no unrolling.','Full baseline: three warmups and three measured iterations. SMA override: ten warmups and ten requested iterations; retained samples are shown in details. One invocation per iteration, no unrolling.')
s=s.replace('Three samples can be noisy, and observed wins are not confidence-qualified.','The baseline has three samples per arm; these can be noisy, and observed wins are not confidence-qualified. The SMA override retains its longer-run samples and confidence intervals.')
source_html=f'<p>800 comparisons: <code>{BASE}</code>, <a href="{data["evidence"]["runUrl"]}">full baseline run</a>.</p><p>Two SMA comparisons: <code>{SOURCE}</code>, <a href="{url}">controlled run, final candidate round (2)</a>. All four ABBA rounds are archived; this selects the latest candidate round, not the fastest.</p>'
s,count=re.subn(r"\$\('source'\)\.innerHTML=`.*?`;",lambda _:"$('source').innerHTML="+json.dumps(source_html)+';',s,flags=re.S);assert count==1
assert len(data['rows'])==802
unchanged=0
for a,b in zip(before['rows'],data['rows'],strict=True):
 assert (a['pair'],a['bars'])==(b['pair'],b['bars'])
 if a['pair']!='Skender.GetSmaAnalysis':assert a==b;unchanged+=1
assert unchanged==800 and embedded(s,'archived-baseline-dataset')==embedded(original.decode('utf-8'),'archived-baseline-dataset')
(out/'before.html').write_bytes(original);(out/'candidate.html').write_text(s,encoding='utf-8')
(out/'measurement.json').write_text(json.dumps({**receipt,'run_url':url,'selection':override['selection']},indent=2))
(out/'staged.json').write_text(json.dumps({'before_sha256':hashlib.sha256(original).hexdigest(),'candidate_sha256':hashlib.sha256((out/'candidate.html').read_bytes()).hexdigest(),'changed_rows':2,'unchanged_rows':800,'qualification_status':status,'selection':override['selection']},indent=2))
print('Staged two latest SMA comparisons; 800 other rows and archived baseline unchanged.')
