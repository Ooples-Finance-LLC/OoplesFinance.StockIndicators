```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Exp**       |  **12.415 μs** | **2.3124 μs** | **1.3761 μs** |  **3.4180** |  **0.4883** |  **56.77 KB** |
| BuilderLatestOnly | 1000  | Exp       |   9.000 μs | 0.1029 μs | 0.0612 μs |  0.5493 |       - |   9.16 KB |
| **BuilderFull**       | **10000** | **Exp**       | **103.486 μs** | **1.2600 μs** | **0.7498 μs** | **33.2031** | **13.6719** | **549.32 KB** |
| BuilderLatestOnly | 10000 | Exp       |  81.141 μs | 0.8627 μs | 0.5134 μs |  4.3945 |  0.4883 |  79.48 KB |
