```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Exp**       |  **12.110 μs** | **0.3515 μs** | **0.2091 μs** |  **1.93** |    **0.03** |  **3.4180** |  **0.4883** |  **56.77 KB** |        **7.22** |
| BuilderLatestOnly | 1000  | Exp       |   9.266 μs | 0.5011 μs | 0.2982 μs |  1.48 |    0.05 |  0.5493 |       - |   9.16 KB |        1.16 |
| NativeSingle      | 1000  | Exp       |   6.280 μs | 0.0939 μs | 0.0491 μs |  1.00 |    0.01 |  0.4272 |       - |   7.87 KB |        1.00 |
| NativeParallel    | 1000  | Exp       |  95.439 μs | 0.8932 μs | 0.5908 μs | 15.20 |    0.14 |  0.4883 |       - |   8.14 KB |        1.03 |
|                   |       |           |            |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **10000** | **Exp**       | **103.864 μs** | **0.7433 μs** | **0.3887 μs** |  **1.73** |    **0.01** | **33.2031** | **13.6719** | **549.32 KB** |        **7.03** |
| BuilderLatestOnly | 10000 | Exp       |  81.933 μs | 0.3211 μs | 0.1911 μs |  1.36 |    0.01 |  4.3945 |  0.4883 |  79.48 KB |        1.02 |
| NativeSingle      | 10000 | Exp       |  60.187 μs | 0.3420 μs | 0.2035 μs |  1.00 |    0.00 |  4.3945 |  0.4883 |  78.18 KB |        1.00 |
| NativeParallel    | 10000 | Exp       | 124.664 μs | 5.9998 μs | 3.9685 μs |  2.07 |    0.06 |  3.9063 |       - |  78.45 KB |        1.00 |
