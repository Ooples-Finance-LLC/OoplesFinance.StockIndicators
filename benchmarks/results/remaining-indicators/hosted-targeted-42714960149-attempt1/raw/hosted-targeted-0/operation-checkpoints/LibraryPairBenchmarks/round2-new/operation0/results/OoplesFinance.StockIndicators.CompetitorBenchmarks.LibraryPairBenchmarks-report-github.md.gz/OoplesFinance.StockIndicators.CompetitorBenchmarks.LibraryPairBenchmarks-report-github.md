```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Exp** | **120.91 μs** |  **5.716 μs** |  **2.990 μs** |  **1.00** |    **0.03** |  **97.92 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Exp |  21.40 μs |  6.355 μs |  3.782 μs |  0.18 |    0.03 |  40.27 KB |        0.41 |
|            |       |                     |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Exp** | **316.89 μs** | **18.766 μs** | **11.167 μs** |  **1.00** |    **0.05** | **958.27 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Exp | 182.37 μs | 14.245 μs |  8.477 μs |  0.58 |    0.03 | 330.31 KB |        0.34 |
