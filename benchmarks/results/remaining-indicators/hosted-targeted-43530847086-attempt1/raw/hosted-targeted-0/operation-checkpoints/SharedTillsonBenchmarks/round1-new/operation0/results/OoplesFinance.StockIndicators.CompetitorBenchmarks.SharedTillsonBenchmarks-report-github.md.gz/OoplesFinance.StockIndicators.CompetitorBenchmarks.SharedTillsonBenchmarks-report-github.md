```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.T3** | **1000**  | **119.0 μs** |  **0.86 μs** |  **0.45 μs** |  **3.9063** |       **-** |  **65.25 KB** |
| BuilderLatestOnly | TaLib.Functions.T3 | 1000  | 118.5 μs |  1.88 μs |  1.12 μs |  0.9766 |       - |  17.64 KB |
| **BuilderFull**       | **TaLib.Functions.T3** | **10000** | **782.2 μs** | **46.12 μs** | **30.51 μs** | **35.1563** | **11.7188** | **630.74 KB** |
| BuilderLatestOnly | TaLib.Functions.T3 | 10000 | 785.3 μs | 55.64 μs | 36.80 μs | 35.1563 | 15.6250 | 630.06 KB |
