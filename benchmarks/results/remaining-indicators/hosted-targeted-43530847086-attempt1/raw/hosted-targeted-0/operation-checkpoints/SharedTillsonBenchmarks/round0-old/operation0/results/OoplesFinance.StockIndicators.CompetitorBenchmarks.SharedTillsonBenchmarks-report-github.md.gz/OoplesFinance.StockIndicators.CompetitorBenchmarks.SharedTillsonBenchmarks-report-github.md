```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev  | Gen0    | Gen1   | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|--------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib.Functions.T3** | **1000**  |   **120.5 μs** |  **0.81 μs** | **0.48 μs** |  **3.9063** |      **-** |  **65.18 KB** |
| BuilderLatestOnly | TaLib.Functions.T3 | 1000  |   118.3 μs |  1.03 μs | 0.54 μs |  0.9766 |      - |  17.57 KB |
| **BuilderFull**       | **TaLib.Functions.T3** | **10000** | **1,218.3 μs** | **10.92 μs** | **5.71 μs** | **31.2500** | **7.8125** | **628.08 KB** |
| BuilderLatestOnly | TaLib.Functions.T3 | 10000 | 1,215.0 μs |  6.98 μs | 4.15 μs |  7.8125 |      - |  158.2 KB |
