```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |-----------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.T3** | **1000**  | **118.816 μs** |  **0.4855 μs** |  **0.2539 μs** | **37.28** |    **0.21** |  **3.9063** |       **-** |  **65.25 KB** |        **9.35** |
| BuilderLatestOnly | TaLib.Functions.T3 | 1000  | 116.811 μs |  0.2881 μs |  0.1715 μs | 36.65 |    0.20 |  0.9766 |       - |  17.64 KB |        2.53 |
| NativeSingle      | TaLib.Functions.T3 | 1000  |   3.187 μs |  0.0343 μs |  0.0180 μs |  1.00 |    0.01 |  0.3967 |       - |   6.98 KB |        1.00 |
| NativeParallel    | TaLib.Functions.T3 | 1000  |  80.465 μs |  1.1918 μs |  0.7883 μs | 25.25 |    0.27 |  1.4648 |       - |  24.66 KB |        3.53 |
|                   |                    |       |            |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.T3** | **10000** | **785.188 μs** | **30.0549 μs** | **19.8795 μs** | **24.20** |    **0.64** | **35.1563** | **11.7188** | **630.73 KB** |        **8.16** |
| BuilderLatestOnly | TaLib.Functions.T3 | 10000 | 838.263 μs | 12.1282 μs |  6.3433 μs | 25.84 |    0.33 | 31.2500 | 15.6250 | 630.03 KB |        8.15 |
| NativeSingle      | TaLib.Functions.T3 | 10000 |  32.447 μs |  0.6077 μs |  0.3616 μs |  1.00 |    0.01 |  4.6387 |       - |  77.29 KB |        1.00 |
| NativeParallel    | TaLib.Functions.T3 | 10000 | 118.466 μs |  2.4366 μs |  1.2744 μs |  3.65 |    0.05 | 17.5781 |  3.9063 | 270.76 KB |        3.50 |
