```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation            | Mean       | Error     | StdDev    | Allocated |
|------------------ |------ |--------------------- |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **1000**  | **TaLib(...)bands [24]** |   **447.2 μs** |  **13.65 μs** |   **8.12 μs** |  **99.43 KB** |
| BuilderLatestOnly | 1000  | TaLib(...)bands [24] |   443.5 μs |   3.93 μs |   2.05 μs |  51.88 KB |
| **BuilderFull**       | **10000** | **TaLib(...)bands [24]** | **2,448.3 μs** |  **55.15 μs** |  **32.82 μs** |  **953.3 KB** |
| BuilderLatestOnly | 10000 | TaLib(...)bands [24] | 2,477.5 μs | 233.08 μs | 138.70 μs | 483.36 KB |
