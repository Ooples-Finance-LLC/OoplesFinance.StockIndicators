```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation            | Mean       | Error     | StdDev    | Allocated |
|------------------ |------ |--------------------- |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **1000**  | **TaLib(...)bands [24]** |   **458.6 μs** |  **13.70 μs** |   **8.15 μs** |  **99.46 KB** |
| BuilderLatestOnly | 1000  | TaLib(...)bands [24] |   440.7 μs |   4.83 μs |   2.53 μs |  51.88 KB |
| **BuilderFull**       | **10000** | **TaLib(...)bands [24]** | **2,536.7 μs** | **231.63 μs** | **153.21 μs** |  **953.2 KB** |
| BuilderLatestOnly | 10000 | TaLib(...)bands [24] | 2,519.6 μs | 247.24 μs | 163.54 μs | 483.39 KB |
