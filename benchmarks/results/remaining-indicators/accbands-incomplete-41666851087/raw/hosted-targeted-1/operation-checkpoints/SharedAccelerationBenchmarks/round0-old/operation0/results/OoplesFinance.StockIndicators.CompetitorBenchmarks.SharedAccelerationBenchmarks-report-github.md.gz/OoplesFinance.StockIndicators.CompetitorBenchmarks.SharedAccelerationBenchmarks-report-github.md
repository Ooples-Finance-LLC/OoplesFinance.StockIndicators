```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation            | Mean      | Error     | StdDev    | Gen0     | Gen1     | Allocated |
|------------------ |------ |--------------------- |----------:|----------:|----------:|---------:|---------:|----------:|
| **BuilderFull**       | **1000**  | **TaLib(...)bands [24]** |  **1.956 ms** | **0.0732 ms** | **0.0436 ms** |        **-** |        **-** |   **3.11 MB** |
| BuilderLatestOnly | 1000  | TaLib(...)bands [24] |  1.983 ms | 0.0962 ms | 0.0573 ms |  31.2500 |        - |   3.07 MB |
| **BuilderFull**       | **10000** | **TaLib(...)bands [24]** | **12.517 ms** | **1.3288 ms** | **0.8789 ms** | **375.0000** | **250.0000** |  **31.34 MB** |
| BuilderLatestOnly | 10000 | TaLib(...)bands [24] | 11.947 ms | 0.6718 ms | 0.4443 ms | 375.0000 | 250.0000 |  30.88 MB |
