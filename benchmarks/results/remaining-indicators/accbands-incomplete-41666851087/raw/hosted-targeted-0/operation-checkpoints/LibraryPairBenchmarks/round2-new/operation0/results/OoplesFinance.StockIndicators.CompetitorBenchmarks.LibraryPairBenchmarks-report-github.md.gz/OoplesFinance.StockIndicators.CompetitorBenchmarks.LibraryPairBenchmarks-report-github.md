```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)bands [24]** |   **632.27 μs** | **11.659 μs** | **7.712 μs** |  **1.00** |    **0.02** |  **221.34 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)bands [24] |    24.21 μs |  4.138 μs | 2.462 μs |  0.04 |    0.00 |  114.02 KB |        0.52 |
|            |       |                      |             |           |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)bands [24]** | **3,323.50 μs** | **17.318 μs** | **9.057 μs** |  **1.00** |    **0.00** | **2157.97 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)bands [24] |   176.90 μs |  8.103 μs | 4.238 μs |  0.05 |    0.00 | 1128.65 KB |        0.52 |
