```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)Crows [22]** | **1000**  |  **24.26 μs** |  **0.071 μs** |  **0.037 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)Crows [22] | 1000  | 102.95 μs |  2.789 μs |  1.845 μs |  4.24 |    0.07 |       - |       - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib(...)Crows [22] | 1000  | 107.69 μs |  2.225 μs |  1.324 μs |  4.44 |    0.05 |  1.9531 |       - |   62.5 KB |       15.75 |
| BuilderLatestOnly | TaLib(...)Crows [22] | 1000  | 106.91 μs |  2.714 μs |  1.795 μs |  4.41 |    0.07 |       - |       - |  14.61 KB |        3.68 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)Crows [22]** | **10000** | **247.77 μs** |  **2.239 μs** |  **1.171 μs** |  **1.00** |    **0.01** |  **1.9531** |       **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib(...)Crows [22] | 10000 | 234.11 μs | 19.603 μs | 12.966 μs |  0.94 |    0.05 |  5.8594 |       - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib(...)Crows [22] | 10000 | 245.29 μs | 16.738 μs | 11.071 μs |  0.99 |    0.04 | 33.2031 | 13.6719 |  556.8 KB |       14.23 |
| BuilderLatestOnly | TaLib(...)Crows [22] | 10000 | 227.81 μs | 18.834 μs | 12.458 μs |  0.92 |    0.05 |  3.9063 |       - |   86.7 KB |        2.22 |
