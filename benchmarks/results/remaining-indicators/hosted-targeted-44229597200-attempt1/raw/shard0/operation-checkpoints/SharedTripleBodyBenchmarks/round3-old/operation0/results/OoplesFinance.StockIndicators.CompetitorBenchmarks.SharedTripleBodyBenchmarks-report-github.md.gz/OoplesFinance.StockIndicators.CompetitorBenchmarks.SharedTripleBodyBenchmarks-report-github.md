```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)Crows [22]** | **1000**  | **116.2 μs** | **11.87 μs** | **7.85 μs** |  **1.9531** |       **-** |  **62.49 KB** |
| BuilderLatestOnly | TaLib(...)Crows [22] | 1000  | 106.5 μs |  3.04 μs | 2.01 μs |       - |       - |  14.61 KB |
| **BuilderFull**       | **TaLib(...)Crows [22]** | **10000** | **235.8 μs** |  **4.26 μs** | **2.23 μs** | **33.2031** | **13.6719** |  **556.8 KB** |
| BuilderLatestOnly | TaLib(...)Crows [22] | 10000 | 223.5 μs |  4.37 μs | 2.29 μs |  3.9063 |       - |   86.7 KB |
