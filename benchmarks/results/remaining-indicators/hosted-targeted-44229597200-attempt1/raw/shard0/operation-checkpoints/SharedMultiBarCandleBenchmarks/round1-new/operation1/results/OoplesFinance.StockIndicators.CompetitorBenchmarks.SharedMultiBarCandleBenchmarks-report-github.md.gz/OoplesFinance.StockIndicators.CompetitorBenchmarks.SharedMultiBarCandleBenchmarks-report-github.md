```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation            | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------ |--------------------- |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **TaLib(...)allow [35]** | **128.6 μs** |  **6.64 μs** |  **3.95 μs** |  **3.9063** |       **-** |  **64.44 KB** |
| BuilderLatestOnly | 1000  | TaLib(...)allow [35] | 125.7 μs |  6.25 μs |  4.13 μs |  0.9766 |       - |  16.59 KB |
| **BuilderFull**       | **10000** | **TaLib(...)allow [35]** | **434.3 μs** | **47.73 μs** | **31.57 μs** | **31.2500** | **11.7188** | **557.01 KB** |
| BuilderLatestOnly | 10000 | TaLib(...)allow [35] | 436.8 μs | 63.21 μs | 41.81 μs |  3.9063 |       - |  86.93 KB |
