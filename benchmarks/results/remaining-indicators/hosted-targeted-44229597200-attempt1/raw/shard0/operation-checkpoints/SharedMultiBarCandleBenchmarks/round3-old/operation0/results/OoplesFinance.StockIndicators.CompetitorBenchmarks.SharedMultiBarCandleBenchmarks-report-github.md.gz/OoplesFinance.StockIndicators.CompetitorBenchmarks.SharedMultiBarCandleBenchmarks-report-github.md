```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation            | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------ |--------------------- |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **TaLib(...)kaway [23]** | **149.5 μs** | **12.60 μs** |  **7.50 μs** |  **3.9063** |       **-** |  **64.47 KB** |
| BuilderLatestOnly | 1000  | TaLib(...)kaway [23] | 139.4 μs |  2.80 μs |  1.47 μs |  0.9766 |       - |  16.59 KB |
| **BuilderFull**       | **10000** | **TaLib(...)kaway [23]** | **615.1 μs** | **49.94 μs** | **33.03 μs** | **31.2500** | **11.7188** | **557.04 KB** |
| BuilderLatestOnly | 10000 | TaLib(...)kaway [23] | 605.9 μs | 41.88 μs | 27.70 μs |  3.9063 |       - |  86.93 KB |
