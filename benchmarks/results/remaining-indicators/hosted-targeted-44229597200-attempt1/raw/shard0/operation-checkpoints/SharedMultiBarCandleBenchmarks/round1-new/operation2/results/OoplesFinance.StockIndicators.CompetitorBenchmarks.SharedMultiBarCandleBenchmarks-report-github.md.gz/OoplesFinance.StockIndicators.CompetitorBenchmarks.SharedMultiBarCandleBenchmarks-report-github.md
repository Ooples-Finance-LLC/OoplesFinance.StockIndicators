```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation            | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------ |--------------------- |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **TaLib(...)ottom [26]** | **132.1 μs** | **10.45 μs** |  **6.22 μs** |  **3.9063** |       **-** |  **64.48 KB** |
| BuilderLatestOnly | 1000  | TaLib(...)ottom [26] | 125.5 μs |  6.07 μs |  4.01 μs |  0.9766 |       - |  16.59 KB |
| **BuilderFull**       | **10000** | **TaLib(...)ottom [26]** | **438.2 μs** | **40.20 μs** | **26.59 μs** | **31.2500** | **11.7188** | **557.01 KB** |
| BuilderLatestOnly | 10000 | TaLib(...)ottom [26] | 393.3 μs | 12.67 μs |  6.62 μs |  3.9063 |       - |  86.93 KB |
