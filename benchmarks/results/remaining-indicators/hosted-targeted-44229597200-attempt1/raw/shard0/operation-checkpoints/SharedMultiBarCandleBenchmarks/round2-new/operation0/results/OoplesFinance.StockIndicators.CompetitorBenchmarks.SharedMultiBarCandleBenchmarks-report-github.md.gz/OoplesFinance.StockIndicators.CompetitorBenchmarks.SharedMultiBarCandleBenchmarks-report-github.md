```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation            | Mean     | Error    | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |------ |--------------------- |---------:|---------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **TaLib(...)kaway [23]** | **148.8 μs** | **12.57 μs** | **7.48 μs** |  **3.9063** |       **-** |  **64.47 KB** |
| BuilderLatestOnly | 1000  | TaLib(...)kaway [23] | 143.9 μs |  7.64 μs | 5.05 μs |  0.9766 |       - |  16.59 KB |
| **BuilderFull**       | **10000** | **TaLib(...)kaway [23]** | **170.0 μs** |  **7.03 μs** | **4.65 μs** | **33.2031** | **10.7422** | **551.55 KB** |
| BuilderLatestOnly | 10000 | TaLib(...)kaway [23] | 153.6 μs |  8.21 μs | 5.43 μs |  4.8828 |       - |  81.45 KB |
