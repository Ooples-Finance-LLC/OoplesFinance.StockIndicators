```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation            | Mean     | Error     | StdDev    | Median   | Gen0    | Gen1    | Allocated |
|------------------ |------ |--------------------- |---------:|----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **TaLib(...)ottom [26]** | **196.8 μs** | **157.97 μs** | **104.49 μs** | **139.8 μs** |  **3.9063** |       **-** |  **64.51 KB** |
| BuilderLatestOnly | 1000  | TaLib(...)ottom [26] | 126.2 μs |   7.38 μs |   4.88 μs | 126.0 μs |  0.9766 |       - |  16.59 KB |
| **BuilderFull**       | **10000** | **TaLib(...)ottom [26]** | **402.4 μs** |  **15.93 μs** |   **8.33 μs** | **399.2 μs** | **31.2500** | **11.7188** | **557.04 KB** |
| BuilderLatestOnly | 10000 | TaLib(...)ottom [26] | 388.6 μs |  21.17 μs |  11.07 μs | 387.2 μs |  3.9063 |       - |  86.93 KB |
