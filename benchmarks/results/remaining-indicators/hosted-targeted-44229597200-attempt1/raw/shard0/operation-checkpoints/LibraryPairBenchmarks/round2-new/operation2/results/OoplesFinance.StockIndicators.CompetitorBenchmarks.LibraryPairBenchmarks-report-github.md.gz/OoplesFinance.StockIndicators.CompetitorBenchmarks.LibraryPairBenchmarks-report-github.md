```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error      | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|-----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)ottom [26]** | **359.11 μs** |  **32.705 μs** | **17.105 μs** |  **1.00** |    **0.06** |  **68.77 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)ottom [26] |  27.20 μs |   1.805 μs |  0.944 μs |  0.08 |    0.00 |   19.3 KB |        0.28 |
|            |       |                      |           |            |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)ottom [26]** | **535.54 μs** | **159.622 μs** | **94.988 μs** |  **1.04** |    **0.28** | **639.02 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)ottom [26] | 267.56 μs |  16.360 μs | 10.821 μs |  0.52 |    0.11 | 125.05 KB |        0.20 |
