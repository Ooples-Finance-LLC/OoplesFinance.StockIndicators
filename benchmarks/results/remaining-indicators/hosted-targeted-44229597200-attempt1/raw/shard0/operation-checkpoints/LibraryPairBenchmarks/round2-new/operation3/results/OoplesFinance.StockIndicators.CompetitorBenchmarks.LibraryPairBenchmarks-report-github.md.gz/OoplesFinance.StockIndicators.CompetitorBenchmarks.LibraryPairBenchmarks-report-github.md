```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Crows [22]** |  **75.25 μs** |  **5.238 μs** |  **2.740 μs** |  **1.00** |    **0.05** |  **65.13 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Crows [22] |  42.49 μs | 10.670 μs |  7.058 μs |  0.57 |    0.09 |  18.59 KB |        0.29 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Crows [22]** | **163.96 μs** |  **8.098 μs** |  **4.819 μs** |  **1.00** |    **0.04** | **639.28 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Crows [22] | 335.81 μs | 18.604 μs | 12.305 μs |  2.05 |    0.09 | 125.09 KB |        0.20 |
