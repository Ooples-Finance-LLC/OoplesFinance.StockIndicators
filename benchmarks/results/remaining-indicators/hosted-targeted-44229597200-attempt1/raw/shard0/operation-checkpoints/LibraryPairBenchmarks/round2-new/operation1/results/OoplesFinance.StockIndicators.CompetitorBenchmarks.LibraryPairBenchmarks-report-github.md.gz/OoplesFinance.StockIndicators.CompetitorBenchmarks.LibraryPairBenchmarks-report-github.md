```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)allow [35]** | **384.45 μs** | **45.020 μs** | **29.778 μs** |  **1.01** |    **0.10** |  **68.77 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)allow [35] |  61.25 μs |  6.083 μs |  3.182 μs |  0.16 |    0.01 |  19.91 KB |        0.29 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)allow [35]** | **542.68 μs** | **23.629 μs** | **14.061 μs** |  **1.00** |    **0.03** | **639.39 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)allow [35] | 603.90 μs | 29.300 μs | 15.324 μs |  1.11 |    0.04 | 125.05 KB |        0.20 |
