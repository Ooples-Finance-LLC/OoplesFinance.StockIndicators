```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean     | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |---------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)allow [35]** | **108.2 μs** |  **48.66 μs** | **32.19 μs** |  **1.08** |    **0.43** |  **68.77 KB** |        **1.00** |
|        |       |                      |          |           |          |       |         |           |             |
| **Ooples** | **10000** | **TaLib(...)allow [35]** | **547.8 μs** | **190.28 μs** | **99.52 μs** |  **1.03** |    **0.26** | **639.39 KB** |        **1.00** |
