```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)kaway [23]** | **111.56 μs** | **15.926 μs** |  **9.477 μs** |  **1.01** |    **0.11** |  **68.77 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)kaway [23] |  40.89 μs |  1.986 μs |  1.038 μs |  0.37 |    0.03 |   19.3 KB |        0.28 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)kaway [23]** | **144.38 μs** |  **5.963 μs** |  **3.119 μs** |  **1.00** |    **0.03** | **637.57 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)kaway [23] | 422.30 μs | 24.865 μs | 16.447 μs |  2.93 |    0.12 | 125.05 KB |        0.20 |
