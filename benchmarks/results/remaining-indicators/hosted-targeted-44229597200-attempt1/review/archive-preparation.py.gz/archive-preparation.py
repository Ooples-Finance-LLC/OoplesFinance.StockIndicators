"""Prepare rejected-run evidence only; leave root authentication and commit pending."""
import gzip,hashlib,json,os,subprocess,sys,tempfile
from pathlib import Path

RUN='44229597200';HEAD='207f0d52d327d68b913e581371eb791d6092897b'
BASE='98783f08571e9055927071c096473b9b99100a3f'
TOOLING=Path(r'C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-breakaway-isolated-qualification-20261118')
PUB=TOOLING.parent/'si-rejected-breakaway-evidence-publisher-20261118'
OPS=Path(__file__).resolve().parent
Z=Path(r'Z:\StockIndicators-Archives\active-performance-evidence\breakaway-isolated-qualification-44229597200')
PREP=OPS/('hosted-inputs-'+RUN);RAW=Z/'raw'/'evidence'
def git(*args,cwd=PUB):return subprocess.check_output(['git',*args],cwd=cwd,text=True).strip()
def sha(raw):return hashlib.sha256(raw).hexdigest()
assert git('rev-parse','HEAD',cwd=TOOLING)==HEAD and not git('status','--porcelain',cwd=TOOLING)
assert git('rev-parse','HEAD')==BASE and not git('status','--porcelain')
temp=Z/'rejected-archive-tmp';temp.mkdir()
os.environ['TEMP']=str(temp);os.environ['TMP']=str(temp);tempfile.tempdir=None
os.environ['HOSTED_TIMING_PLAN']=str(TOOLING/'benchmarks/plans/hosted-breakaway-isolated-qualification-20261118.json')
sys.path.insert(0,str(TOOLING/'scripts'))
from hosted_timing import breakaway_qualification as q
from hosted_timing import archive as a
p=q.p
independent=p.read(Z/'independent-summary.json')
assert independent['accepted'] is False and independent['source_gate_accepted'] is False and independent['native_progress_gate_passed'] is True
assert independent['verdicts']==dict(inconclusive=20,faster=3,slower=1) and independent['new_closure_credit_pairs']==[]
assert not git('diff','--name-only',q.OLD,BASE,'--',*q.native.previous.SOURCE_IDENTITY_PATHS)
changed=set(git('diff','--name-only',q.OLD,q.NEW,'--','src','tests').splitlines());assert changed==q.PATHS
patch=subprocess.check_output(['git','diff','--binary',q.OLD,q.NEW,'--','src','tests'],cwd=PUB)
destination=a.archive(RAW,PREP,PUB,'targeted')
decision=p.read(destination/'decision.json');summary=p.read(destination/'verified-summary.json')
assert summary==independent
assert p.digest(destination/'verified-summary.json')=='b955479e6b812dc39aaebb4a0439417bc828ec2a63ceb9361a1d89560c5319c8'
assert decision['status']=='rejected-or-inconclusive' and decision['accepted'] is False
assert decision['source_gate_accepted'] is False and decision['native_progress_gate_passed'] is True
assert decision['new_closure_credit_pairs']==[] and decision['existing_two_crows_recounted'] is False
assert decision['production_integrated'] is False and decision['report_imported'] is False
def add(relative,raw):
    assert relative not in decision['archives']
    target=destination/(relative+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(gzip.compress(raw,mtime=0))
    decision['archives'][relative]=dict(sha256=sha(raw),archive=target.relative_to(PUB).as_posix())
add('prepared/fixture-method-inventory.json',(PREP/'fixture-method-inventory.json').read_bytes())
for name in ('run-api.json','artifact-api.json','collection-summary.json','materialization-manifest.json','qualification-rejection-detail.json','independent-summary.json'):
    add('review/'+name,(Z/name).read_bytes())
add('review/collector.py',(OPS/('collect-breakaway-'+RUN+'.py')).read_bytes())
add('review/archive-preparation.py',Path(__file__).read_bytes())
source=dict(publisher_base=BASE,production_source=q.OLD,rejected_candidate=q.NEW,
    candidate_source_patch_paths=sorted(changed),candidate_source_patch_sha256=sha(patch),
    publisher_source_identity_delta_against_qualified_9e=[],candidate_production_or_gpu_cherry_picked=False,
    rejection='LibraryPairBenchmarks LadderBottom Ooples1000 source Slower',
    new_accepted_closure_credit_pairs=[],compiled_runtime_in_git=False,historical_evidence_modified=False)
add('review/rejected-source-identity-proof.json',(json.dumps(source,indent=2)+'\n').encode())
a.write(destination/'decision.json',decision)
size=0;rawsize=0
for logical,item in decision['archives'].items():
    path=(PUB/item['archive']).resolve();assert path.is_relative_to(destination.resolve())
    assert not any(part in ('blobs','common','production') for part in Path(logical).parts)
    assert Path(logical).suffix.lower() not in ('.dll','.exe','.pdb','.so','.dylib')
    raw=gzip.decompress(path.read_bytes());assert sha(raw)==item['sha256']
    if logical=='candidate-source.patch':assert raw==patch
    size+=path.stat().st_size;rawsize+=len(raw)
expected={destination/'decision.json',destination/'verified-summary.json',destination/'.gitattributes'}|{PUB/item['archive'] for item in decision['archives'].values()}
assert {path for path in destination.rglob('*') if path.is_file()}==expected
assert git('rev-parse','HEAD')==BASE and not git('diff','--cached','--name-only')
assert not git('diff','--name-only',q.OLD,'HEAD','--',*q.native.previous.SOURCE_IDENTITY_PATHS)
subprocess.run(['git','diff','--check'],cwd=PUB,check=True)
receipt=dict(status='rejected-archive-prepared-root-auth-and-local-commit-pending',run_id=RUN,
    publisher=str(PUB),publisher_base=BASE,archive=destination.relative_to(PUB).as_posix(),
    preliminary_decision_sha256=p.digest(destination/'decision.json'),verified_summary_sha256=p.digest(destination/'verified-summary.json'),
    archive_blob_count=len(decision['archives']),files=len(expected),gzip_bytes=size,decompressed_bytes=rawsize,
    source_patch_sha256=sha(patch),source_patch_paths=sorted(changed),
    all_archive_hashes_verified=True,archiver_recollection_equals_hosted_and_independent=True,
    accepted=False,source_gate=False,native_gate=True,new_accepted_closure_credit_pairs=[],
    candidate_production_or_gpu_cherry_picked=False,committed=False,pushed=False)
p.write(Z/'rejected-archive-preparation.json',receipt)
print(json.dumps(receipt))
