"""Add the root receipt and commit only authenticated rejected-run evidence."""
import gzip,hashlib,json,os,subprocess,sys
from pathlib import Path

RUN='44229597200';HEAD='207f0d52d327d68b913e581371eb791d6092897b'
BASE='98783f08571e9055927071c096473b9b99100a3f'
TOOLING=Path(r'C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-breakaway-isolated-qualification-20261118')
PUB=TOOLING.parent/'si-rejected-breakaway-evidence-publisher-20261118'
Z=Path(r'Z:\StockIndicators-Archives\active-performance-evidence\breakaway-isolated-qualification-44229597200')
DEST=PUB/'benchmarks/results/remaining-indicators/hosted-targeted-44229597200-attempt1'
def git(*args,cwd=PUB):return subprocess.check_output(['git',*args],cwd=cwd,text=True).strip()
def sha(raw):return hashlib.sha256(raw).hexdigest()
assert git('rev-parse','HEAD',cwd=TOOLING)==HEAD and not git('status','--porcelain',cwd=TOOLING)
assert git('rev-parse','HEAD')==BASE and not git('diff','--cached','--name-only')
os.environ['HOSTED_TIMING_PLAN']=str(TOOLING/'benchmarks/plans/hosted-breakaway-isolated-qualification-20261118.json')
sys.path.insert(0,str(TOOLING/'scripts'))
from hosted_timing import breakaway_qualification as q
from hosted_timing import archive as a
p=q.p
root=p.read(Z/'root-review.json');receipt=p.read(Z/'rejected-archive-preparation.json')
assert root['status']=='root-independent-authentication-passed-rejection-confirmed'
assert root['run_id']==RUN and root['head']==HEAD and root['publisher_base']==BASE
assert root['accepted'] is False and root['source_gate'] is False and root['native_gate'] is True
assert root['new_closure_credit_pairs']==[] and root['raw_recollection_equals_hosted_and_peer'] is True
assert root['summary_sha256']==receipt['verified_summary_sha256']=='b955479e6b812dc39aaebb4a0439417bc828ec2a63ceb9361a1d89560c5319c8'
assert root['source_patch_sha256']==receipt['source_patch_sha256']
assert root['verdicts']==dict(inconclusive=20,faster=3,slower=1) and (root['cases'],root['decisions'])==(108,24)
decision=p.read(DEST/'decision.json');assert len(decision['archives'])==root['archive_entries_verified']==315
def add(relative,raw):
    assert relative not in decision['archives']
    target=DEST/(relative+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(gzip.compress(raw,mtime=0))
    decision['archives'][relative]=dict(sha256=sha(raw),archive=target.relative_to(PUB).as_posix())
add('review/root-review.json',(Z/'root-review.json').read_bytes())
add('review/archive-finalization.py',Path(__file__).read_bytes())
a.write(DEST/'decision.json',decision)
patch=subprocess.check_output(['git','diff','--binary',q.OLD,q.NEW,'--','src','tests'],cwd=PUB)
assert sha(patch)==root['source_patch_sha256']
size=0;rawsize=0
for logical,item in decision['archives'].items():
    path=(PUB/item['archive']).resolve();assert path.is_relative_to(DEST.resolve())
    assert not any(part in ('blobs','common','production') for part in Path(logical).parts)
    assert Path(logical).suffix.lower() not in ('.dll','.exe','.pdb','.so','.dylib')
    raw=gzip.decompress(path.read_bytes());assert sha(raw)==item['sha256']
    if logical=='candidate-source.patch':assert raw==patch
    size+=path.stat().st_size;rawsize+=len(raw)
expected={DEST/'decision.json',DEST/'verified-summary.json',DEST/'.gitattributes'}|{PUB/item['archive'] for item in decision['archives'].values()}
assert {path for path in DEST.rglob('*') if path.is_file()}==expected
assert p.read(DEST/'verified-summary.json')==p.read(Z/'independent-summary.json')
assert p.digest(DEST/'verified-summary.json')==root['summary_sha256']
assert decision['status']=='rejected-or-inconclusive' and decision['accepted'] is False
assert decision['source_gate_accepted'] is False and decision['native_progress_gate_passed'] is True
assert decision['new_closure_credit_pairs']==[] and decision['existing_two_crows_recounted'] is False
assert decision['production_integrated'] is False and decision['report_imported'] is False
assert not git('diff','--name-only',q.OLD,BASE,'--',*q.native.previous.SOURCE_IDENTITY_PATHS)
prefix=DEST.relative_to(PUB).as_posix()
subprocess.run(['git','diff','--check'],cwd=PUB,check=True)
subprocess.run(['git','add','--',prefix],cwd=PUB,check=True)
staged=git('diff','--cached','--name-only').splitlines()
assert len(staged)==len(expected) and all(name.startswith(prefix+'/') for name in staged)
subprocess.run(['git','diff','--cached','--check'],cwd=PUB,check=True)
subprocess.run(['git','commit','--quiet','-m','perf: archive rejected Breakaway qualification'],cwd=PUB,check=True)
head=git('rev-parse','HEAD');assert git('rev-parse',head+'^')==BASE
assert set(git('diff','--name-only',BASE,head).splitlines())==set(staged)
assert not git('status','--porcelain') and not git('diff','--name-only',q.OLD,head,'--',*q.native.previous.SOURCE_IDENTITY_PATHS)
assert q.auth.blob(BASE,'benchmarks/results/shared-rollout/local-gpu-contracts/receipt.json')==q.auth.blob(head,'benchmarks/results/shared-rollout/local-gpu-contracts/receipt.json')
fingerprint=q.common.source_fingerprint(head);assert fingerprint=='79ccf727c22cb156a0cb75cdd0f764da037603d7b74c8cd9cb075da2c6498815'
signed=subprocess.run(['git','verify-commit','--raw',head],cwd=PUB,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(Z/'rejected-archive-signature.log').write_bytes(signed.stdout);assert signed.returncode==0
result=dict(status='root-authenticated-rejected-run-archive-committed-locally',run_id=RUN,head=head,parent=BASE,
    publisher=str(PUB),decision=prefix+'/decision.json',decision_sha256=p.digest(DEST/'decision.json'),
    verified_summary_sha256=p.digest(DEST/'verified-summary.json'),root_review_sha256=p.digest(Z/'root-review.json'),
    archive_blob_count=len(decision['archives']),files=len(staged),gzip_bytes=size,decompressed_bytes=rawsize,
    source_patch_sha256=sha(patch),source_patch_paths=sorted(q.PATHS),all_gzip_hashes_verified=True,
    production_source_fingerprint=fingerprint,production_source_and_gpu_unchanged=True,candidate_cherry_picked=False,
    accepted=False,source_gate=False,native_gate=True,new_closure_credit_pairs=[],signed_and_verified=True,pushed=False)
p.write(Z/'rejected-archive-final-receipt.json',result)
print(json.dumps(result))
