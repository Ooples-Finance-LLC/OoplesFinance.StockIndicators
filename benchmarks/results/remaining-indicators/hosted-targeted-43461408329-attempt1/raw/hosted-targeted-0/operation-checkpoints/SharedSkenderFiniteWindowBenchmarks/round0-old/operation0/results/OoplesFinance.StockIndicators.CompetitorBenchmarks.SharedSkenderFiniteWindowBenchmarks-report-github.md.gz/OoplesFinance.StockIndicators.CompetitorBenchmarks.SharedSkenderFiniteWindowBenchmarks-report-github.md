```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetAwesome** | **1000**  | **118.4 μs** |  **3.33 μs** |  **1.98 μs** |  **3.9063** |       **-** |  **86.82 KB** |
| BuilderLatestOnly | Skender.GetAwesome | 1000  | 117.5 μs |  6.68 μs |  4.42 μs |  1.9531 |       - |  39.22 KB |
| **BuilderFull**       | **Skender.GetAwesome** | **10000** | **483.2 μs** | **58.79 μs** | **38.89 μs** | **46.8750** | **19.5313** | **790.34 KB** |
| BuilderLatestOnly | Skender.GetAwesome | 10000 | 420.5 μs | 38.03 μs | 22.63 μs | 19.5313 |  7.8125 | 320.51 KB |
