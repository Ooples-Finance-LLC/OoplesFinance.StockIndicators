```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Gen2    | Allocated  | Alloc Ratio |
|------------------ |------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAwesome** | **1000**  | **114.13 μs** |  **6.343 μs** |  **4.195 μs** |  **2.75** |    **0.11** |  **3.9063** |       **-** |       **-** |   **86.82 KB** |        **0.76** |
| BuilderLatestOnly | Skender.GetAwesome | 1000  | 109.55 μs |  2.161 μs |  1.130 μs |  2.64 |    0.05 |  1.9531 |       - |       - |   39.22 KB |        0.34 |
| NativeSingle      | Skender.GetAwesome | 1000  |  41.56 μs |  1.194 μs |  0.711 μs |  1.00 |    0.02 |  6.8359 |  1.2207 |       - |   113.7 KB |        1.00 |
| NativeParallel    | Skender.GetAwesome | 1000  | 101.87 μs |  3.702 μs |  2.449 μs |  2.45 |    0.07 |  8.7891 |  0.9766 |       - |  134.19 KB |        1.18 |
|                   |                    |       |           |           |           |       |         |         |         |         |            |             |
| **BuilderFull**       | **Skender.GetAwesome** | **10000** | **403.95 μs** | **30.512 μs** | **20.182 μs** |  **0.66** |    **0.03** | **46.8750** | **21.4844** |       **-** |  **790.32 KB** |        **0.70** |
| BuilderLatestOnly | Skender.GetAwesome | 10000 | 386.74 μs | 26.892 μs | 17.788 μs |  0.63 |    0.03 | 19.5313 |  7.8125 |       - |  320.49 KB |        0.28 |
| NativeSingle      | Skender.GetAwesome | 10000 | 614.93 μs | 18.701 μs | 12.369 μs |  1.00 |    0.03 | 97.6563 | 97.6563 | 97.6563 | 1134.01 KB |        1.00 |
| NativeParallel    | Skender.GetAwesome | 10000 | 355.16 μs | 18.377 μs | 12.156 μs |  0.58 |    0.02 | 78.1250 | 39.0625 |       - | 1224.04 KB |        1.08 |
