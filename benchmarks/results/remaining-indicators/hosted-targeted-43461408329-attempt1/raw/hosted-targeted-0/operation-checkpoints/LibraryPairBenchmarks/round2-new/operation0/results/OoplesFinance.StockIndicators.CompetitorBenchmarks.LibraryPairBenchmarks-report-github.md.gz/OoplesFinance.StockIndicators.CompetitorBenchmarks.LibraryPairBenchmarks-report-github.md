```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAwesome** | **101.47 μs** | **14.505 μs** |  **8.632 μs** |  **1.01** |    **0.12** |  **165.36 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAwesome |  61.06 μs |  0.778 μs |  0.407 μs |  0.61 |    0.05 |  168.55 KB |        1.02 |
|            |       |                    |           |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAwesome** | **636.32 μs** | **22.909 μs** | **13.633 μs** |  **1.00** |    **0.03** |  **1596.7 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAwesome | 630.41 μs | 21.703 μs | 12.915 μs |  0.99 |    0.03 | 1626.55 KB |        1.02 |
