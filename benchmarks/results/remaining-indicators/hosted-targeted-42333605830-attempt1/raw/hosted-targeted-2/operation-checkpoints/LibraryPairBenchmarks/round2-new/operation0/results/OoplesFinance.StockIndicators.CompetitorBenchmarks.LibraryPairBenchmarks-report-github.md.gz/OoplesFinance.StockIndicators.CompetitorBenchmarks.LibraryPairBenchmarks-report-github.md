```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dMode [27]** |  **1,045.7 μs** |  **20.81 μs** | **12.38 μs** |  **1.00** |    **0.02** |   **112.7 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dMode [27] |    418.1 μs |   9.63 μs |  6.37 μs |  0.40 |    0.01 |   31.66 KB |        0.28 |
|            |       |                      |             |           |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)dMode [27]** | **10,562.4 μs** |  **84.75 μs** | **56.05 μs** |  **1.00** |    **0.01** | **1037.84 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dMode [27] |  4,552.9 μs | 126.27 μs | 83.52 μs |  0.43 |    0.01 |  287.58 KB |        0.28 |
