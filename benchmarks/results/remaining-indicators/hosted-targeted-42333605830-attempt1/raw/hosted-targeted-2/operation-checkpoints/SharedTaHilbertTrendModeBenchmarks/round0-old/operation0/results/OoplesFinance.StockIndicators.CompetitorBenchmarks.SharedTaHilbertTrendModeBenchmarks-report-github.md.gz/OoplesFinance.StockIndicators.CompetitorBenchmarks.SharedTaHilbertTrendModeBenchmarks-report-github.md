```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |------------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |    **987.4 μs** |  **56.94 μs** |  **37.66 μs** |  **71.55 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |    942.9 μs |  10.21 μs |   5.34 μs |  23.99 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **10,750.8 μs** | **324.27 μs** | **192.97 μs** | **634.44 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 10,678.4 μs | 171.56 μs |  89.73 μs | 165.38 KB |
