```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |------------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |    **964.1 μs** |  **16.82 μs** |  **10.01 μs** |  **71.57 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |    954.1 μs |  19.83 μs |  11.80 μs |  23.99 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **10,835.2 μs** | **183.84 μs** | **109.40 μs** | **635.21 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 10,517.3 μs |  94.46 μs |  56.21 μs |  165.1 KB |
