```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |    **940.1 μs** |  **14.51 μs** |   **8.63 μs** |  **2.32** |    **0.09** |   **71.6 KB** |       **15.18** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |    935.1 μs |   9.17 μs |   4.80 μs |  2.31 |    0.08 |  24.04 KB |        5.10 |
| NativeSingle      | TaLib(...)dMode [27] | 1000  |    405.4 μs |  23.50 μs |  15.54 μs |  1.00 |    0.05 |   4.72 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 1000  |    566.8 μs |  24.33 μs |  14.48 μs |  1.40 |    0.06 |   17.4 KB |        3.69 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **10,191.2 μs** | **461.09 μs** | **274.39 μs** |  **2.40** |    **0.09** | **634.95 KB** |       **15.86** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 10,115.2 μs | 274.26 μs | 163.21 μs |  2.39 |    0.08 | 165.08 KB |        4.12 |
| NativeSingle      | TaLib(...)dMode [27] | 10000 |  4,242.7 μs | 193.23 μs | 127.81 μs |  1.00 |    0.04 |  40.04 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 10000 |  6,019.5 μs | 467.19 μs | 309.02 μs |  1.42 |    0.08 | 140.65 KB |        3.51 |
