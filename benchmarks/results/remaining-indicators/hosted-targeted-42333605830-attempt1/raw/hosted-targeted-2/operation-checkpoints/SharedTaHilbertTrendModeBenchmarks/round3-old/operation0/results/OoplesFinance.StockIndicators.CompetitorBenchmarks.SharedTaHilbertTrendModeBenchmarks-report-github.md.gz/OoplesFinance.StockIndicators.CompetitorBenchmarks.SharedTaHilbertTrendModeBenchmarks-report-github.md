```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1.003 ms** | **0.0082 ms** | **0.0049 ms** |  **71.55 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1.035 ms | 0.0546 ms | 0.0361 ms |  23.94 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **10.662 ms** | **0.2643 ms** | **0.1573 ms** | **634.93 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 10.841 ms | 0.2892 ms | 0.1721 ms | 165.05 KB |
