```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dline [27]** | **1000**  |  **1.410 ms** | **0.0110 ms** | **0.0065 ms** |  **69.23 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 1000  |  1.031 ms | 0.0055 ms | 0.0033 ms |   21.6 KB |
| **BuilderFull**       | **TaLib(...)dline [27]** | **10000** | **10.711 ms** | **0.1305 ms** | **0.0682 ms** | **632.75 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 10000 | 10.736 ms | 0.0646 ms | 0.0384 ms | 162.97 KB |
