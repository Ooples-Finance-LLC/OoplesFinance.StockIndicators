```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev   | Ratio | RatioSD | Gen0    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|---------:|------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dline [27]** | **1000**  |    **991.9 μs** |   **4.80 μs** |  **2.85 μs** |  **8.00** |    **0.03** |       **-** |  **69.27 KB** |        **8.71** |
| BuilderLatestOnly | TaLib(...)dline [27] | 1000  |    979.7 μs |  11.95 μs |  6.25 μs |  7.91 |    0.05 |       - |  21.64 KB |        2.72 |
| NativeSingle      | TaLib(...)dline [27] | 1000  |    123.9 μs |   0.44 μs |  0.26 μs |  1.00 |    0.00 |       - |   7.95 KB |        1.00 |
| NativeParallel    | TaLib(...)dline [27] | 1000  |    213.4 μs |  21.30 μs | 14.09 μs |  1.72 |    0.11 |  1.9531 |  28.52 KB |        3.59 |
|                   |                      |       |             |           |          |       |         |         |           |             |
| **BuilderFull**       | **TaLib(...)dline [27]** | **10000** | **10,109.2 μs** | **106.15 μs** | **63.17 μs** |  **7.40** |    **0.04** |       **-** | **632.83 KB** |        **8.08** |
| BuilderLatestOnly | TaLib(...)dline [27] | 10000 | 10,031.2 μs | 101.51 μs | 53.09 μs |  7.35 |    0.04 |       - | 163.02 KB |        2.08 |
| NativeSingle      | TaLib(...)dline [27] | 10000 |  1,365.6 μs |   2.76 μs |  1.44 μs |  1.00 |    0.00 |       - |  78.32 KB |        1.00 |
| NativeParallel    | TaLib(...)dline [27] | 10000 |  1,674.1 μs |  27.74 μs | 16.51 μs |  1.23 |    0.01 | 15.6250 | 274.72 KB |        3.51 |
