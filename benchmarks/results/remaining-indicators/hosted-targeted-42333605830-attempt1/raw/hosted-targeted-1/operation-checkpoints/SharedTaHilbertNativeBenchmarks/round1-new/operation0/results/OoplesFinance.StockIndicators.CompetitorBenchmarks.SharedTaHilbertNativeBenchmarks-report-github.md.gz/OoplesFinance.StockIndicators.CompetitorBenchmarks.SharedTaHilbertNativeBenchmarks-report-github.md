```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)dline [27]** | **1000**  |   **993.0 μs** |   **5.90 μs** |  **3.09 μs** |  **69.27 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 1000  |   963.8 μs |   5.79 μs |  3.03 μs |  21.64 KB |
| **BuilderFull**       | **TaLib(...)dline [27]** | **10000** | **9,993.6 μs** | **133.08 μs** | **69.60 μs** |  **632.7 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 10000 | 9,989.6 μs |  35.37 μs | 18.50 μs | 162.98 KB |
