```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dline [27]** |  **1,041.8 μs** | **35.63 μs** | **21.21 μs** |  **1.00** |    **0.03** |   **110.1 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dline [27] |    147.2 μs | 11.09 μs |  6.60 μs |  0.14 |    0.01 |    41.2 KB |        0.37 |
|            |       |                      |             |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)dline [27]** | **10,226.1 μs** | **97.12 μs** | **50.80 μs** |  **1.00** |    **0.01** | **1041.16 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dline [27] |  1,426.1 μs | 21.10 μs | 12.56 μs |  0.14 |    0.00 |  331.23 KB |        0.32 |
