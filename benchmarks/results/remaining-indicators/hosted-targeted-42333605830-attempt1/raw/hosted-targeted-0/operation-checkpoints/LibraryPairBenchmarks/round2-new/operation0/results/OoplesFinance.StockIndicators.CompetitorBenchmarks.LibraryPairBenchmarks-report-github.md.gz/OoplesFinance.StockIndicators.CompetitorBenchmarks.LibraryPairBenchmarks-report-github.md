```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)dline [22]** |   **898.6 μs** | **23.85 μs** | **14.20 μs** |  **1.00** |    **0.02** |  **222.95 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)dline [22] |   151.7 μs |  1.83 μs |  0.96 μs |  0.17 |    0.00 |  289.26 KB |        1.30 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)dline [22]** | **8,502.0 μs** | **53.28 μs** | **31.70 μs** |  **1.00** |    **0.01** | **2153.66 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)dline [22] | 1,511.8 μs | 20.31 μs | 12.08 μs |  0.18 |    0.00 | 2811.39 KB |        1.31 |
