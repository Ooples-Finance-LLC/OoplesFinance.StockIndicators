```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|-------:|----------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  |   **702.8 μs** |  **5.78 μs** |  **3.03 μs** | **3.9063** | **100.82 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  |   711.3 μs |  5.18 μs |  3.08 μs |      - |  53.23 KB |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **6,966.9 μs** | **15.05 μs** |  **7.87 μs** |      **-** |  **945.3 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 7,054.6 μs | 64.39 μs | 33.68 μs |      - | 475.45 KB |
