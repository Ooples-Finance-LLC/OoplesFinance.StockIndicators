```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  |   **706.7 μs** |  **2.89 μs** |  **1.72 μs** |  **6.63** |    **0.02** |   **3.9063** |        **-** |        **-** |  **100.86 KB** |        **0.49** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  |   698.2 μs |  4.44 μs |  2.32 μs |  6.55 |    0.03 |        - |        - |        - |   53.27 KB |        0.26 |
| NativeSingle      | Skend(...)dline [22] | 1000  |   106.6 μs |  0.58 μs |  0.30 μs |  1.00 |    0.00 |  12.6953 |   2.9297 |        - |  207.71 KB |        1.00 |
| NativeParallel    | Skend(...)dline [22] | 1000  |   208.6 μs | 15.25 μs | 10.09 μs |  1.96 |    0.09 |  33.2031 |  11.7188 |        - |  528.53 KB |        2.54 |
|                   |                      |       |            |          |          |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **6,940.3 μs** | **35.12 μs** | **18.37 μs** |  **5.67** |    **0.12** |        **-** |        **-** |        **-** |  **945.42 KB** |        **0.46** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 6,897.1 μs | 20.49 μs | 10.72 μs |  5.63 |    0.12 |        - |        - |        - |   475.6 KB |        0.23 |
| NativeSingle      | Skend(...)dline [22] | 10000 | 1,225.0 μs | 46.76 μs | 27.83 μs |  1.00 |    0.03 | 187.5000 | 156.2500 |  85.9375 |  2072.1 KB |        1.00 |
| NativeParallel    | Skend(...)dline [22] | 10000 | 2,186.0 μs | 72.88 μs | 48.21 μs |  1.79 |    0.05 | 421.8750 | 343.7500 | 140.6250 | 5258.79 KB |        2.54 |
