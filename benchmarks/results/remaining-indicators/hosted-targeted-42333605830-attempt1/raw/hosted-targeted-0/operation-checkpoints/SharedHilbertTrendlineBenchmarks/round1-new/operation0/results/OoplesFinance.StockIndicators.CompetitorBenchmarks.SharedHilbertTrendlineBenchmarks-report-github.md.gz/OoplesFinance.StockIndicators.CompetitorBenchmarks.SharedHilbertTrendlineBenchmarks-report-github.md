```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|-------:|----------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  |   **707.9 μs** |  **3.73 μs** |  **1.95 μs** | **3.9063** | **100.86 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  |   707.4 μs |  1.54 μs |  0.80 μs |      - |  53.27 KB |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **6,884.3 μs** | **33.20 μs** | **19.76 μs** |      **-** | **945.28 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 6,994.1 μs | 44.53 μs | 26.50 μs |      - | 475.67 KB |
