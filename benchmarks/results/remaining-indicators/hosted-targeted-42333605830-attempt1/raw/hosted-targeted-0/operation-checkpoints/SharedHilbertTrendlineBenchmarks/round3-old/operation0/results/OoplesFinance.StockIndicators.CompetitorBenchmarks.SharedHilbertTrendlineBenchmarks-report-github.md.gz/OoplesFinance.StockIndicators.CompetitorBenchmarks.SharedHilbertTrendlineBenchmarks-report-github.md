```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  |   **723.6 μs** | **10.84 μs** |  **5.67 μs** | **100.82 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  |   738.5 μs | 18.19 μs | 12.03 μs |  53.22 KB |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **7,108.2 μs** | **11.92 μs** |  **6.24 μs** | **945.32 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 7,169.8 μs | 29.55 μs | 17.58 μs | 475.41 KB |
