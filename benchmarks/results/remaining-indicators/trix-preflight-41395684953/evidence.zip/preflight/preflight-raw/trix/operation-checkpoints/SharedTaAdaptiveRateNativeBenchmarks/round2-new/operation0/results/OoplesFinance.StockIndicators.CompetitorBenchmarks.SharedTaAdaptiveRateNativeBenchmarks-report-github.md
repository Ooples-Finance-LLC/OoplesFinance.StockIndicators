```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **306.2 μs** |  **4.53 μs** |  **2.37 μs** |       **-** |  **89.21 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   305.9 μs |  8.47 μs |  5.60 μs |  1.9531 |   41.6 KB |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **3,426.9 μs** | **12.36 μs** |  **6.46 μs** | **31.2500** | **863.18 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 3,426.2 μs | 24.31 μs | 12.71 μs |       - | 393.32 KB |
