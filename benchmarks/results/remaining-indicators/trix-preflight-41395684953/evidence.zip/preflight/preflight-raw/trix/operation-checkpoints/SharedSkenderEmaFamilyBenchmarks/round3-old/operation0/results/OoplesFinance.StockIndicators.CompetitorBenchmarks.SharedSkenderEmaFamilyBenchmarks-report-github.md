```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **914.4 μs** |   **7.32 μs** |  **3.83 μs** |       **-** |  **89.26 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   542.9 μs |   5.03 μs |  2.99 μs |       - |   41.6 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **5,715.0 μs** | **127.99 μs** | **84.65 μs** | **31.2500** | **863.23 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 5,702.2 μs |  56.87 μs | 33.84 μs |       - | 393.33 KB |
