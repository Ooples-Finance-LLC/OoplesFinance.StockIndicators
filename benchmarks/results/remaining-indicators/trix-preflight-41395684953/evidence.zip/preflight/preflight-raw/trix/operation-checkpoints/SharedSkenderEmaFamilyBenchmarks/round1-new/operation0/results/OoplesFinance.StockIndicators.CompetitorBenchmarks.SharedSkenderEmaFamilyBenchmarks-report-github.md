```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **303.2 μs** |  **3.97 μs** |  **2.08 μs** |       **-** |  **89.21 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   333.7 μs |  2.52 μs |  1.32 μs |  1.9531 |   41.6 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **3,451.2 μs** | **35.25 μs** | **20.98 μs** | **31.2500** | **863.14 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 3,318.4 μs | 20.25 μs | 10.59 μs |       - | 393.37 KB |
