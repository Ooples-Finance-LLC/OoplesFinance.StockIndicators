```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **568.2 μs** |  **4.89 μs** |  **2.56 μs** |       **-** |  **89.26 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   551.0 μs |  3.37 μs |  2.23 μs |       - |   41.6 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **5,799.3 μs** | **96.87 μs** | **64.07 μs** | **31.2500** |  **863.2 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 5,751.1 μs | 65.98 μs | 39.26 μs |       - | 393.38 KB |
