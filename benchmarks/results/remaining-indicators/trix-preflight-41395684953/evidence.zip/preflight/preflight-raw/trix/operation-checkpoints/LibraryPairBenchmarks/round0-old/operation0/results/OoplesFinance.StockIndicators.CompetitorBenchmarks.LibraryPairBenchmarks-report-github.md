```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean     | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |---------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Trix** | **7.767 ms** | **0.0789 ms** | **0.0522 ms** |  **1.00** |  **192.99 KB** |        **1.00** |
|        |       |                      |          |           |           |       |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Trix** | **6.814 ms** | **0.0948 ms** | **0.0496 ms** |  **1.00** | **1897.48 KB** |        **1.00** |
