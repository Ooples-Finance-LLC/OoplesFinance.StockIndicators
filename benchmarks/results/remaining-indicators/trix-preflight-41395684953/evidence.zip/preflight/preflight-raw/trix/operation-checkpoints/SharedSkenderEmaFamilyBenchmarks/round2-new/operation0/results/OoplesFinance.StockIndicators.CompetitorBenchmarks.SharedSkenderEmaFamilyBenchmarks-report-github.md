```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **304.6 μs** |  **5.33 μs** |  **2.79 μs** |       **-** |  **89.21 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   304.5 μs |  9.42 μs |  6.23 μs |  1.9531 |   41.6 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **3,397.1 μs** | **61.71 μs** | **40.82 μs** | **31.2500** | **863.21 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 3,377.0 μs | 13.34 μs |  6.98 μs |       - | 393.35 KB |
