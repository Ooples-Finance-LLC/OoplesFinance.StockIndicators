```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |----------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Trix** |  **2.652 ms** | **0.0375 ms** | **0.0223 ms** |  **1.00** |  **193.01 KB** |        **1.00** |
|        |       |                      |           |           |           |       |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Trix** | **22.221 ms** | **0.1294 ms** | **0.0677 ms** |  **1.00** | **1897.78 KB** |        **1.00** |
