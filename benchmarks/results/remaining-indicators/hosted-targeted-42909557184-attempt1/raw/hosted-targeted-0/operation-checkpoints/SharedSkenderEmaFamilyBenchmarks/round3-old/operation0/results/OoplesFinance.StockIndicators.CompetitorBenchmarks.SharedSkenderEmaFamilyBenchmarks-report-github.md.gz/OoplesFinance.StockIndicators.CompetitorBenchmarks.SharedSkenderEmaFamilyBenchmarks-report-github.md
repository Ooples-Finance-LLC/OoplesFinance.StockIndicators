```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetTsi** | **1000**  | **1,055.7 μs** |  **8.68 μs** |  **4.54 μs** |  **81.07 KB** |
| BuilderLatestOnly | Skender.GetTsi | 1000  |   708.4 μs | 13.66 μs |  9.04 μs |  33.41 KB |
| **BuilderFull**       | **Skender.GetTsi** | **10000** | **7,190.7 μs** | **77.24 μs** | **45.97 μs** | **784.98 KB** |
| BuilderLatestOnly | Skender.GetTsi | 10000 | 7,186.0 μs | 88.46 μs | 46.27 μs | 315.23 KB |
