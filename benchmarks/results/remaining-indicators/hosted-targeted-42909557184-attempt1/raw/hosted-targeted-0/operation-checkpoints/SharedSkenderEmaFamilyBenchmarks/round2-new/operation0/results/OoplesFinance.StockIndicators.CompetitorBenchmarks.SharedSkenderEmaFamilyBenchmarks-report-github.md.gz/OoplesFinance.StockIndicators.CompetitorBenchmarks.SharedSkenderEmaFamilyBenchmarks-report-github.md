```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetTsi** | **1000**  |   **800.98 μs** |   **8.228 μs** |   **4.896 μs** | **20.04** |    **0.49** |        **-** |        **-** |        **-** |    **81.1 KB** |        **0.53** |
| BuilderLatestOnly | Skender.GetTsi | 1000  |   668.72 μs |  11.335 μs |   6.745 μs | 16.73 |    0.43 |        - |        - |        - |   33.44 KB |        0.22 |
| NativeSingle      | Skender.GetTsi | 1000  |    39.99 μs |   1.688 μs |   1.004 μs |  1.00 |    0.03 |   9.2773 |   1.9531 |        - |  152.88 KB |        1.00 |
| NativeParallel    | Skender.GetTsi | 1000  |   142.38 μs |   7.788 μs |   5.151 μs |  3.56 |    0.15 |  25.3906 |   6.8359 |        - |  391.01 KB |        2.56 |
|                   |                |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetTsi** | **10000** | **6,778.77 μs** | **130.045 μs** |  **77.388 μs** | **10.67** |    **0.19** |        **-** |        **-** |        **-** |  **785.01 KB** |        **0.51** |
| BuilderLatestOnly | Skender.GetTsi | 10000 | 6,759.64 μs |  15.511 μs |   9.230 μs | 10.64 |    0.16 |        - |        - |        - |  315.22 KB |        0.21 |
| NativeSingle      | Skender.GetTsi | 10000 |   635.23 μs |  16.592 μs |   9.874 μs |  1.00 |    0.02 |  97.6563 |  97.6563 |  97.6563 | 1524.76 KB |        1.00 |
| NativeParallel    | Skender.GetTsi | 10000 | 1,808.50 μs | 184.648 μs | 122.133 μs |  2.85 |    0.19 | 359.3750 | 312.5000 | 156.2500 | 3891.52 KB |        2.55 |
