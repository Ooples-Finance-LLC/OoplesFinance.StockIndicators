```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetTsi** | **1000**  |   **781.8 μs** | **11.11 μs** |  **5.81 μs** |  **81.07 KB** |
| BuilderLatestOnly | Skender.GetTsi | 1000  |   740.4 μs | 15.21 μs | 10.06 μs |  33.41 KB |
| **BuilderFull**       | **Skender.GetTsi** | **10000** | **7,452.4 μs** | **46.48 μs** | **27.66 μs** | **785.02 KB** |
| BuilderLatestOnly | Skender.GetTsi | 10000 | 7,565.6 μs | 68.43 μs | 35.79 μs | 315.21 KB |
