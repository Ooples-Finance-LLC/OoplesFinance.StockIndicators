```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Skender.GetTsi** | **1000**  | **1,730.1 μs** | **426.77 μs** | **223.21 μs** |   **81.1 KB** |
| BuilderLatestOnly | Skender.GetTsi | 1000  |   674.7 μs |   8.74 μs |   5.20 μs |  33.44 KB |
| **BuilderFull**       | **Skender.GetTsi** | **10000** | **7,017.2 μs** | **169.25 μs** | **111.95 μs** | **784.92 KB** |
| BuilderLatestOnly | Skender.GetTsi | 10000 | 6,786.9 μs |  29.52 μs |  17.57 μs |  315.2 KB |
