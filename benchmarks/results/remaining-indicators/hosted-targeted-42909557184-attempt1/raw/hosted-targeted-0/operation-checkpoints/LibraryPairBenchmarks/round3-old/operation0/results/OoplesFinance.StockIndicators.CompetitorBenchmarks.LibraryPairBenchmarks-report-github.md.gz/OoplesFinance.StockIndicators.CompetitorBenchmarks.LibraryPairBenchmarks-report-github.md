```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId         | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetTsi** |   **782.3 μs** | **22.56 μs** | **11.80 μs** |  **1.00** |    **0.02** |  **162.44 KB** |        **1.00** |
|        |       |                |            |          |          |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetTsi** | **7,588.2 μs** | **56.84 μs** | **33.83 μs** |  **1.00** |    **0.01** | **1593.77 KB** |        **1.00** |
