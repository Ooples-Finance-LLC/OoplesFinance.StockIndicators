```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)hasor [24]** |   **294.68 μs** |  **13.869 μs** |   **8.253 μs** |  **1.00** |    **0.04** |  **164.44 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)hasor [24] |    79.99 μs |   2.693 μs |   1.409 μs |  0.27 |    0.01 |   72.18 KB |        0.44 |
|            |       |                      |             |            |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)hasor [24]** | **3,061.95 μs** | **189.433 μs** | **125.298 μs** |  **1.00** |    **0.06** | **1595.11 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)hasor [24] |   781.37 μs |  21.587 μs |  14.279 μs |  0.26 |    0.01 |  652.63 KB |        0.41 |
