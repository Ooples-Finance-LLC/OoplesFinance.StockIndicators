```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)hasor [24]** | **1000**  |   **292.0 μs** |   **7.44 μs** |  **4.43 μs** |       **-** |       **-** |  **82.41 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 1000  |   289.3 μs |   6.06 μs |  4.01 μs |  1.9531 |       - |  34.81 KB |
| **BuilderFull**       | **TaLib(...)hasor [24]** | **10000** | **2,988.2 μs** | **143.78 μs** | **95.10 μs** | **46.8750** | **15.6250** | **785.95 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 10000 | 2,945.7 μs |  51.32 μs | 26.84 μs | 15.6250 |       - | 316.18 KB |
