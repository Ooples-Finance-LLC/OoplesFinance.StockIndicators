```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)hasor [24]** | **1000**  |   **243.98 μs** |   **0.962 μs** |  **0.503 μs** |  **3.31** |    **0.02** |        **-** |        **-** |        **-** |  **82.83 KB** |        **5.33** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 1000  |   233.04 μs |   8.143 μs |  5.386 μs |  3.16 |    0.07 |   1.9531 |        - |        - |  35.23 KB |        2.27 |
| NativeSingle      | TaLib(...)hasor [24] | 1000  |    73.72 μs |   0.783 μs |  0.409 μs |  1.00 |    0.01 |   0.4883 |        - |        - |  15.55 KB |        1.00 |
| NativeParallel    | TaLib(...)hasor [24] | 1000  |   170.51 μs |   9.065 μs |  5.996 μs |  2.31 |    0.08 |   3.9063 |        - |        - |  54.83 KB |        3.53 |
|                   |                      |       |             |            |           |       |         |          |          |          |           |             |
| **BuilderFull**       | **TaLib(...)hasor [24]** | **10000** | **2,372.71 μs** | **120.888 μs** | **79.960 μs** |  **2.95** |    **0.10** |  **46.8750** |  **15.6250** |        **-** | **786.38 KB** |        **5.02** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 10000 | 2,429.66 μs |  88.038 μs | 52.390 μs |  3.02 |    0.07 |  15.6250 |        - |        - | 316.56 KB |        2.02 |
| NativeSingle      | TaLib(...)hasor [24] | 10000 |   803.94 μs |  14.497 μs |  7.582 μs |  1.00 |    0.01 |  46.8750 |  46.8750 |  46.8750 | 156.57 KB |        1.00 |
| NativeParallel    | TaLib(...)hasor [24] | 10000 | 1,099.72 μs |  36.760 μs | 24.315 μs |  1.37 |    0.03 | 132.8125 | 132.8125 | 132.8125 |  548.1 KB |        3.50 |
