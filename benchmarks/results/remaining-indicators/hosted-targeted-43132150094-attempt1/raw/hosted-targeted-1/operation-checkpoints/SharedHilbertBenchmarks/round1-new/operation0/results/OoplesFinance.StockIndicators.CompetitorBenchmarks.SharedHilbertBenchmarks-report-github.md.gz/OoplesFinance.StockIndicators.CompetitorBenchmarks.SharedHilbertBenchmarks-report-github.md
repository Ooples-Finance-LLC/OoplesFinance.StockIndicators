```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)hasor [24]** | **1000**  |   **239.0 μs** |   **7.01 μs** |  **4.64 μs** |       **-** |       **-** |  **82.83 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 1000  |   236.1 μs |   9.10 μs |  6.02 μs |  1.9531 |       - |  35.23 KB |
| **BuilderFull**       | **TaLib(...)hasor [24]** | **10000** | **2,392.2 μs** | **135.66 μs** | **89.73 μs** | **46.8750** | **15.6250** | **786.38 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 10000 | 2,318.8 μs |  64.70 μs | 38.50 μs | 15.6250 |       - | 316.54 KB |
