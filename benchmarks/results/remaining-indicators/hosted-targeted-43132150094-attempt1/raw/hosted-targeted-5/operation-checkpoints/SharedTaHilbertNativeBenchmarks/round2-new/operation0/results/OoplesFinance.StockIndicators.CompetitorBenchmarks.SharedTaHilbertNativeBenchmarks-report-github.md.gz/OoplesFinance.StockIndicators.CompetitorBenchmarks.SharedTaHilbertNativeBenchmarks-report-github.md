```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dline [27]** | **1000**  |   **439.25 μs** |  **4.919 μs** |  **2.927 μs** |  **5.66** |    **0.09** |       **-** |  **69.62 KB** |        **8.76** |
| BuilderLatestOnly | TaLib(...)dline [27] | 1000  |   434.58 μs |  2.871 μs |  1.502 μs |  5.60 |    0.08 |       - |  22.02 KB |        2.77 |
| NativeSingle      | TaLib(...)dline [27] | 1000  |    77.65 μs |  1.699 μs |  1.124 μs |  1.00 |    0.02 |       - |   7.95 KB |        1.00 |
| NativeParallel    | TaLib(...)dline [27] | 1000  |   136.75 μs |  7.879 μs |  4.689 μs |  1.76 |    0.06 |  1.9531 |  28.52 KB |        3.59 |
|                   |                      |       |             |           |           |       |         |         |           |             |
| **BuilderFull**       | **TaLib(...)dline [27]** | **10000** | **4,684.94 μs** | **24.993 μs** | **14.873 μs** |  **5.37** |    **0.12** | **31.2500** | **632.56 KB** |        **8.08** |
| BuilderLatestOnly | TaLib(...)dline [27] | 10000 | 4,663.43 μs | 76.281 μs | 45.393 μs |  5.34 |    0.13 |       - | 162.78 KB |        2.08 |
| NativeSingle      | TaLib(...)dline [27] | 10000 |   873.59 μs | 36.328 μs | 21.618 μs |  1.00 |    0.03 |       - |  78.28 KB |        1.00 |
| NativeParallel    | TaLib(...)dline [27] | 10000 | 1,088.31 μs | 47.836 μs | 31.640 μs |  1.25 |    0.04 | 15.6250 | 274.65 KB |        3.51 |
