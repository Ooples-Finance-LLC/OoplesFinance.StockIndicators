```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)dline [27]** | **1000**  |   **508.3 μs** |  **21.31 μs** | **14.09 μs** |  **3.9063** |  **69.19 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 1000  |   493.8 μs |   4.87 μs |  2.55 μs |       - |   21.6 KB |
| **BuilderFull**       | **TaLib(...)dline [27]** | **10000** | **5,328.4 μs** | **134.25 μs** | **88.80 μs** | **31.2500** | **632.08 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 10000 | 5,227.3 μs | 116.95 μs | 69.59 μs |       - | 162.44 KB |
