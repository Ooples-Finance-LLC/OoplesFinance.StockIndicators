```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)dline [27]** | **1000**  |   **476.2 μs** |  **13.44 μs** |  **8.00 μs** |  **3.9063** |  **69.61 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 1000  |   480.4 μs |  16.41 μs |  9.77 μs |       - |  22.03 KB |
| **BuilderFull**       | **TaLib(...)dline [27]** | **10000** | **5,017.3 μs** |  **86.40 μs** | **45.19 μs** | **31.2500** | **632.64 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 10000 | 4,917.9 μs | 157.77 μs | 82.52 μs |       - | 162.88 KB |
