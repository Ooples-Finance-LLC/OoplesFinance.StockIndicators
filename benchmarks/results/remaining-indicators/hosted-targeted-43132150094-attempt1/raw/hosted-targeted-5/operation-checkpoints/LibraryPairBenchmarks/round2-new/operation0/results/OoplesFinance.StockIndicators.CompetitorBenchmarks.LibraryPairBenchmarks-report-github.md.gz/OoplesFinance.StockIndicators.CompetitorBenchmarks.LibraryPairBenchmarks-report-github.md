```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dline [27]** |   **481.52 μs** | **19.085 μs** | **11.357 μs** |  **1.00** |    **0.03** | **110.52 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dline [27] |    97.76 μs |  4.192 μs |  2.495 μs |  0.20 |    0.01 |  35.62 KB |        0.32 |
|            |       |                      |             |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)dline [27]** | **4,727.52 μs** | **27.355 μs** | **18.094 μs** |  **1.00** |    **0.01** | **1033.7 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dline [27] |   935.16 μs | 20.358 μs | 13.466 μs |  0.20 |    0.00 | 325.98 KB |        0.32 |
