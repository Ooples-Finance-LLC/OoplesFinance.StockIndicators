```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetMama** | **1000**  |   **282.45 μs** |   **4.768 μs** |   **2.494 μs** |  **3.51** |    **0.07** |        **-** |        **-** |        **-** |   **83.03 KB** |        **0.43** |
| BuilderLatestOnly | Skender.GetMama | 1000  |   299.69 μs |  11.271 μs |   7.455 μs |  3.72 |    0.11 |   1.9531 |        - |        - |   35.43 KB |        0.18 |
| NativeSingle      | Skender.GetMama | 1000  |    80.51 μs |   2.191 μs |   1.449 μs |  1.00 |    0.02 |  11.7188 |   2.9297 |        - |  192.06 KB |        1.00 |
| NativeParallel    | Skender.GetMama | 1000  |   153.50 μs |   5.167 μs |   3.418 μs |  1.91 |    0.05 |  31.2500 |   9.7656 |        - |  489.37 KB |        2.55 |
|                   |                 |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetMama** | **10000** | **2,883.66 μs** |  **82.900 μs** |  **54.833 μs** |  **3.17** |    **0.07** |  **46.8750** |  **15.6250** |        **-** |  **786.56 KB** |        **0.41** |
| BuilderLatestOnly | Skender.GetMama | 10000 | 2,871.11 μs |  31.619 μs |  16.537 μs |  3.16 |    0.05 |  15.6250 |        - |        - |  316.76 KB |        0.17 |
| NativeSingle      | Skender.GetMama | 10000 |   909.85 μs |  22.043 μs |  13.117 μs |  1.00 |    0.02 | 179.6875 | 140.6250 |  85.9375 | 1915.63 KB |        1.00 |
| NativeParallel    | Skender.GetMama | 10000 | 1,737.44 μs | 183.188 μs | 121.167 μs |  1.91 |    0.13 | 406.2500 | 328.1250 | 140.6250 | 4868.09 KB |        2.54 |
