```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetMama** | **1000**  |   **346.1 μs** |  **5.10 μs** |  **3.03 μs** |  **3.9063** |  **82.61 KB** |
| BuilderLatestOnly | Skender.GetMama | 1000  |   333.5 μs |  7.85 μs |  5.19 μs |  1.9531 |     35 KB |
| **BuilderFull**       | **Skender.GetMama** | **10000** | **3,355.8 μs** | **79.94 μs** | **47.57 μs** | **31.2500** | **786.21 KB** |
| BuilderLatestOnly | Skender.GetMama | 10000 | 3,383.5 μs | 65.85 μs | 43.55 μs |       - | 316.38 KB |
