```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetMama** | **1000**  |   **351.0 μs** |  **7.34 μs** |  **4.37 μs** |       **-** |  **82.58 KB** |
| BuilderLatestOnly | Skender.GetMama | 1000  |   349.8 μs |  5.19 μs |  3.09 μs |  1.9531 |  35.01 KB |
| **BuilderFull**       | **Skender.GetMama** | **10000** | **3,450.1 μs** | **76.19 μs** | **39.85 μs** | **31.2500** | **786.06 KB** |
| BuilderLatestOnly | Skender.GetMama | 10000 | 3,453.4 μs | 20.52 μs | 12.21 μs |       - | 316.35 KB |
