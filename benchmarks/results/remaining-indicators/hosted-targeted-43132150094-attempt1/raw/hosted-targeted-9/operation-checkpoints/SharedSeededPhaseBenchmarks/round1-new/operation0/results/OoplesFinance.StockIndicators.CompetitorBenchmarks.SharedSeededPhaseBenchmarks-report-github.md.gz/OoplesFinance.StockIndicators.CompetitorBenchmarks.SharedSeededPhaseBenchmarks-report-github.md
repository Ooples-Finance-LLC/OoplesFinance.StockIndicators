```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetMama** | **1000**  |   **290.8 μs** |  **7.49 μs** |  **4.46 μs** |  **3.9063** |       **-** |  **83.03 KB** |
| BuilderLatestOnly | Skender.GetMama | 1000  |   278.1 μs |  5.24 μs |  3.12 μs |  1.9531 |       - |  35.43 KB |
| **BuilderFull**       | **Skender.GetMama** | **10000** | **2,767.8 μs** | **50.36 μs** | **29.97 μs** | **46.8750** | **15.6250** | **786.52 KB** |
| BuilderLatestOnly | Skender.GetMama | 10000 | 2,726.4 μs | 75.10 μs | 44.69 μs | 15.6250 |       - | 316.68 KB |
