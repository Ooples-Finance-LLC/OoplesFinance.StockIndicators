```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId          | Mean        | Error      | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |------------:|-----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetMama** |   **544.94 μs** |  **16.413 μs** |  **9.767 μs** |  **1.00** |    **0.02** |  **164.44 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetMama |    87.33 μs |   7.013 μs |  4.173 μs |  0.16 |    0.01 |  245.34 KB |        1.49 |
|            |       |                 |             |            |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetMama** | **5,151.54 μs** | **101.193 μs** | **60.218 μs** |  **1.00** |    **0.02** | **1590.28 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetMama |   896.33 μs |  22.246 μs | 13.238 μs |  0.17 |    0.00 | 2405.86 KB |        1.51 |
