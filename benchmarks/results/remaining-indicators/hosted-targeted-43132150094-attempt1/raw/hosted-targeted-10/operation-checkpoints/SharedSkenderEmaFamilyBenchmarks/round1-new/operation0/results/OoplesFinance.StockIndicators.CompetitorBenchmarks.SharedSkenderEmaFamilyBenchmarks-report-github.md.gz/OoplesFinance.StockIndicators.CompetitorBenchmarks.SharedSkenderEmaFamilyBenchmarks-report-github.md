```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetTsi** | **1000**  |   **631.5 μs** |  **4.10 μs** |  **2.14 μs** |   **81.1 KB** |
| BuilderLatestOnly | Skender.GetTsi | 1000  |   610.4 μs |  5.31 μs |  3.51 μs |  33.44 KB |
| **BuilderFull**       | **Skender.GetTsi** | **10000** | **6,192.6 μs** | **47.10 μs** | **24.63 μs** | **785.03 KB** |
| BuilderLatestOnly | Skender.GetTsi | 10000 | 6,174.1 μs | 18.59 μs | 11.06 μs | 315.19 KB |
