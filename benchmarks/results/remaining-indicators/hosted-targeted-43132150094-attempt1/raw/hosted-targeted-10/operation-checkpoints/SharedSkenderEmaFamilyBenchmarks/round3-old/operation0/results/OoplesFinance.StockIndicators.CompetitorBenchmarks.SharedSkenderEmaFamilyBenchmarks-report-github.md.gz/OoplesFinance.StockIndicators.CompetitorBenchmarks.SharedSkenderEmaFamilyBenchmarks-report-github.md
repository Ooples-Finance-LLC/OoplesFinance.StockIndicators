```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetTsi** | **1000**  |   **662.9 μs** |  **6.41 μs** |  **3.82 μs** |   **81.1 KB** |
| BuilderLatestOnly | Skender.GetTsi | 1000  |   646.8 μs |  6.31 μs |  3.75 μs |  33.44 KB |
| **BuilderFull**       | **Skender.GetTsi** | **10000** | **6,584.9 μs** | **36.19 μs** | **18.93 μs** | **785.03 KB** |
| BuilderLatestOnly | Skender.GetTsi | 10000 | 6,608.4 μs | 42.05 μs | 25.03 μs | 315.17 KB |
