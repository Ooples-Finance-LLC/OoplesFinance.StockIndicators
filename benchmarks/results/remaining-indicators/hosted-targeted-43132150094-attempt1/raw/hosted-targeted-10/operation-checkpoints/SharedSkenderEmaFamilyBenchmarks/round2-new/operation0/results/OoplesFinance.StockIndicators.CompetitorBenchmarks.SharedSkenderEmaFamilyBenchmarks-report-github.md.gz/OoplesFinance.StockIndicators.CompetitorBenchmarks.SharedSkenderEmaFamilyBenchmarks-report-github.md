```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetTsi** | **1000**  | **1,133.92 μs** | **323.848 μs** | **214.206 μs** | **27.90** |    **5.10** |        **-** |        **-** |        **-** |    **81.1 KB** |        **0.53** |
| BuilderLatestOnly | Skender.GetTsi | 1000  |   633.72 μs |   6.404 μs |   3.349 μs | 15.59 |    0.50 |        - |        - |        - |   33.44 KB |        0.22 |
| NativeSingle      | Skender.GetTsi | 1000  |    40.68 μs |   2.042 μs |   1.351 μs |  1.00 |    0.04 |   9.2773 |   1.9531 |        - |  152.88 KB |        1.00 |
| NativeParallel    | Skender.GetTsi | 1000  |   146.05 μs |   5.913 μs |   3.519 μs |  3.59 |    0.14 |  25.3906 |   6.8359 |        - |  391.01 KB |        2.56 |
|                   |                |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetTsi** | **10000** | **6,557.18 μs** |  **35.335 μs** |  **18.481 μs** | **10.00** |    **0.14** |        **-** |        **-** |        **-** |     **785 KB** |        **0.51** |
| BuilderLatestOnly | Skender.GetTsi | 10000 | 6,584.58 μs |  23.966 μs |  12.535 μs | 10.04 |    0.14 |        - |        - |        - |  315.19 KB |        0.21 |
| NativeSingle      | Skender.GetTsi | 10000 |   655.71 μs |  14.278 μs |   9.444 μs |  1.00 |    0.02 |  97.6563 |  97.6563 |  97.6563 | 1524.76 KB |        1.00 |
| NativeParallel    | Skender.GetTsi | 10000 | 1,862.77 μs | 295.604 μs | 195.524 μs |  2.84 |    0.29 | 359.3750 | 296.8750 | 156.2500 | 3892.21 KB |        2.55 |
