```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error    | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|---------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetTsi** |   **728.85 μs** | **31.02 μs** | **20.515 μs** |  **1.00** |    **0.04** |  **162.43 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetTsi |    64.61 μs | 12.99 μs |  7.732 μs |  0.09 |    0.01 |  211.05 KB |        1.30 |
|            |       |                |             |          |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetTsi** | **7,008.79 μs** | **76.31 μs** | **45.411 μs** |  **1.00** |    **0.01** | **1594.74 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetTsi |   723.90 μs | 55.82 μs | 29.196 μs |  0.10 |    0.00 |  2021.6 KB |        1.27 |
