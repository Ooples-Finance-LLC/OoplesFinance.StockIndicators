```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Mama** |   **512.5 μs** | **39.39 μs** | **26.05 μs** |  **1.00** |    **0.07** |  **164.44 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Mama |   267.1 μs |  3.19 μs |  1.90 μs |  0.52 |    0.02 |   90.47 KB |        0.55 |
|            |       |                |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Mama** | **4,746.0 μs** | **41.34 μs** | **24.60 μs** |  **1.00** |    **0.01** | **1593.19 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Mama | 2,632.7 μs | 22.91 μs | 13.63 μs |  0.55 |    0.00 |     888 KB |        0.56 |
