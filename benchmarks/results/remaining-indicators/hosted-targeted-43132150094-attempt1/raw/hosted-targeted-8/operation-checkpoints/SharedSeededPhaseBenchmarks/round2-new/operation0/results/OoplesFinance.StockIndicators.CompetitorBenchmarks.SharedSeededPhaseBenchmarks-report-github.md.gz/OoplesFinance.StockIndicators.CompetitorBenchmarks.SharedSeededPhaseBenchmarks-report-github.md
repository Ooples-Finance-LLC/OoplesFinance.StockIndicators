```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |-----------:|----------:|----------:|------:|--------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Mama** | **1000**  |   **358.5 μs** |   **2.81 μs** |   **1.67 μs** |  **1.53** |    **0.03** |       **-** |       **-** |       **-** |   **83.03 KB** |        **1.48** |
| BuilderLatestOnly | QuanTAlib.Mama | 1000  |   361.8 μs |   4.43 μs |   2.93 μs |  1.54 |    0.04 |       - |       - |       - |   35.43 KB |        0.63 |
| NativeSingle      | QuanTAlib.Mama | 1000  |   235.1 μs |   8.14 μs |   5.39 μs |  1.00 |    0.03 |  1.9531 |       - |       - |   56.24 KB |        1.00 |
| NativeParallel    | QuanTAlib.Mama | 1000  |   586.9 μs | 182.53 μs | 120.73 μs |  2.50 |    0.49 |       - |       - |       - |  119.66 KB |        2.13 |
|                   |                |       |            |           |           |       |         |         |         |         |            |             |
| **BuilderFull**       | **QuanTAlib.Mama** | **10000** | **3,541.2 μs** |  **33.67 μs** |  **20.04 μs** |  **1.49** |    **0.01** | **31.2500** |       **-** |       **-** |  **786.69 KB** |        **1.43** |
| BuilderLatestOnly | QuanTAlib.Mama | 10000 | 3,482.9 μs |  29.68 μs |  15.52 μs |  1.47 |    0.01 |       - |       - |       - |  316.82 KB |        0.58 |
| NativeSingle      | QuanTAlib.Mama | 10000 | 2,377.0 μs |  24.55 μs |  16.24 μs |  1.00 |    0.01 | 46.8750 | 31.2500 | 31.2500 |  548.73 KB |        1.00 |
| NativeParallel    | QuanTAlib.Mama | 10000 | 4,371.7 μs | 299.99 μs | 198.43 μs |  1.84 |    0.08 | 31.2500 |       - |       - | 1139.36 KB |        2.08 |
