```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Mama** | **1000**  |   **440.9 μs** |  **3.60 μs** |  **2.14 μs** |       **-** |  **82.61 KB** |
| BuilderLatestOnly | QuanTAlib.Mama | 1000  |   440.1 μs |  3.54 μs |  2.34 μs |       - |  35.02 KB |
| **BuilderFull**       | **QuanTAlib.Mama** | **10000** | **4,186.3 μs** | **31.30 μs** | **20.70 μs** | **31.2500** | **786.28 KB** |
| BuilderLatestOnly | QuanTAlib.Mama | 10000 | 4,155.5 μs | 16.43 μs |  9.78 μs |       - | 316.38 KB |
