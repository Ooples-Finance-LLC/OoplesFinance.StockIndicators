```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |---------- |------ |-----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **133.6 μs** |  **3.93 μs** |  **2.06 μs** |  **3.9063** |      **-** |  **64.85 KB** |
| BuilderLatestOnly | Ad        | 1000  |   132.8 μs |  1.29 μs |  0.77 μs |  0.9766 |      - |  17.27 KB |
| **BuilderFull**       | **Ad**        | **10000** | **1,249.3 μs** | **26.29 μs** | **17.39 μs** | **31.2500** | **7.8125** | **627.76 KB** |
| BuilderLatestOnly | Ad        | 10000 | 1,190.1 μs |  6.38 μs |  3.34 μs |  7.8125 |      - | 157.96 KB |
