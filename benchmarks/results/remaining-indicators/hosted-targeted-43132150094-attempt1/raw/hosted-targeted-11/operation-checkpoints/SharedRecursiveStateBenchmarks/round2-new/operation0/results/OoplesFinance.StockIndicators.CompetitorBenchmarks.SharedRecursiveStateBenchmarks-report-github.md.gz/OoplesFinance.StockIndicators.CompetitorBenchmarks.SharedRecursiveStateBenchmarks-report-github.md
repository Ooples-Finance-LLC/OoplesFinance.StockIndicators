```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **135.977 μs** |  **3.9790 μs** |  **2.0811 μs** | **55.34** |    **1.16** |  **3.9063** |      **-** |  **64.89 KB** |        **8.24** |
| BuilderLatestOnly | Ad        | 1000  |   130.041 μs |  0.9244 μs |  0.4835 μs | 52.92 |    0.82 |  0.9766 |      - |  17.28 KB |        2.19 |
| NativeSingle      | Ad        | 1000  |     2.458 μs |  0.0664 μs |  0.0395 μs |  1.00 |    0.02 |  0.4730 |      - |   7.88 KB |        1.00 |
| NativeParallel    | Ad        | 1000  |    88.669 μs |  1.1566 μs |  0.7650 μs | 36.08 |    0.62 |  0.4883 |      - |   8.17 KB |        1.04 |
|                   |           |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **Ad**        | **10000** | **1,232.945 μs** |  **6.6736 μs** |  **3.9714 μs** | **56.16** |    **0.40** | **31.2500** | **7.8125** | **627.79 KB** |        **8.03** |
| BuilderLatestOnly | Ad        | 10000 | 1,253.279 μs | 26.2127 μs | 15.5988 μs | 57.09 |    0.77 |  7.8125 |      - | 157.96 KB |        2.02 |
| NativeSingle      | Ad        | 10000 |    21.955 μs |  0.2842 μs |  0.1486 μs |  1.00 |    0.01 |  4.7607 | 0.8545 |  78.19 KB |        1.00 |
| NativeParallel    | Ad        | 10000 |   109.047 μs |  2.0205 μs |  1.0568 μs |  4.97 |    0.06 |  3.9063 |      - |  78.48 KB |        1.00 |
