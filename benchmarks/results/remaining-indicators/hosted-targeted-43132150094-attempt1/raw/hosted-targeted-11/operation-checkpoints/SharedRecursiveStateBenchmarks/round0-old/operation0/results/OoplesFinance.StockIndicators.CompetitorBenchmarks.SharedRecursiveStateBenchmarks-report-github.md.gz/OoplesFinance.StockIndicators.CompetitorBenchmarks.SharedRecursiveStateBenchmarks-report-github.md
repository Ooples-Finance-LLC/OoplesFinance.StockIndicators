```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |---------- |------ |-----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **137.5 μs** |  **6.52 μs** |  **3.88 μs** |  **3.9063** |      **-** |  **64.88 KB** |
| BuilderLatestOnly | Ad        | 1000  |   130.0 μs |  1.84 μs |  0.96 μs |  0.9766 |      - |  17.27 KB |
| **BuilderFull**       | **Ad**        | **10000** | **1,222.0 μs** | **27.45 μs** | **16.34 μs** | **31.2500** | **7.8125** | **627.79 KB** |
| BuilderLatestOnly | Ad        | 10000 | 1,201.0 μs | 32.64 μs | 19.42 μs |  7.8125 |      - | 157.96 KB |
