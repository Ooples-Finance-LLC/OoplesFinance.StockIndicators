```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error    | StdDev  | Gen0    | Gen1   | Allocated |
|------------------ |---------- |------ |-----------:|---------:|--------:|--------:|-------:|----------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **140.2 μs** | **14.18 μs** | **9.38 μs** |  **3.9063** |      **-** |  **64.89 KB** |
| BuilderLatestOnly | Ad        | 1000  |   130.8 μs |  0.89 μs | 0.53 μs |  0.9766 |      - |  17.28 KB |
| **BuilderFull**       | **Ad**        | **10000** | **1,210.1 μs** | **15.07 μs** | **8.97 μs** | **31.2500** | **7.8125** |  **627.8 KB** |
| BuilderLatestOnly | Ad        | 10000 | 1,201.8 μs |  7.11 μs | 4.23 μs |  7.8125 |      - | 157.96 KB |
