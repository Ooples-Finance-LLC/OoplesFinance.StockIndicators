```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean       | Error      | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |------------------- |-----------:|-----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ad** | **121.138 μs** |  **7.3292 μs** | **3.8333 μs** |  **1.00** |    **0.04** |  **72.95 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ad |   4.433 μs |  0.3565 μs | 0.2121 μs |  0.04 |    0.00 |   8.76 KB |        0.12 |
|            |       |                    |            |            |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ad** | **887.089 μs** | **11.8543 μs** | **7.0543 μs** |  **1.00** |    **0.01** | **713.91 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ad |  23.837 μs |  0.7945 μs | 0.4155 μs |  0.03 |    0.00 |  86.29 KB |        0.12 |
