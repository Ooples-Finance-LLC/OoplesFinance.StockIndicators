```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Mama** |   **559.0 μs** | **83.30 μs** | **55.10 μs** |  **1.01** |    **0.13** |  **164.44 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Mama |   132.6 μs |  2.09 μs |  1.38 μs |  0.24 |    0.02 |   73.45 KB |        0.45 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Mama** | **5,051.4 μs** | **61.43 μs** | **36.56 μs** |  **1.00** |    **0.01** | **1594.78 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Mama | 1,232.0 μs | 36.29 μs | 21.60 μs |  0.24 |    0.00 |  652.27 KB |        0.41 |
