```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mama** | **1000**  |   **617.2 μs** |  **19.25 μs** |  **11.45 μs** |  **82.61 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 1000  |   608.5 μs |  20.90 μs |  13.82 μs |  35.02 KB |
| **BuilderFull**       | **TaLib.Functions.Mama** | **10000** | **6,041.2 μs** |  **84.81 μs** |  **50.47 μs** | **786.32 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 10000 | 6,033.1 μs | 172.47 μs | 114.08 μs |  316.5 KB |
