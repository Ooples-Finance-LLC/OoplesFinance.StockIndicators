```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Mama** | **1000**  |   **430.8 μs** |  **6.22 μs** |  **4.11 μs** |  **4.08** |    **0.04** |        **-** |        **-** |        **-** |  **83.03 KB** |        **5.34** |
| BuilderLatestOnly | TaLib.Functions.Mama | 1000  |   416.9 μs |  3.20 μs |  1.91 μs |  3.95 |    0.02 |        - |        - |        - |  35.45 KB |        2.28 |
| NativeSingle      | TaLib.Functions.Mama | 1000  |   105.5 μs |  0.39 μs |  0.20 μs |  1.00 |    0.00 |        - |        - |        - |  15.55 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mama | 1000  |   167.6 μs | 16.61 μs | 10.99 μs |  1.59 |    0.10 |        - |        - |        - |  54.83 KB |        3.52 |
|                   |                      |       |            |          |          |       |         |          |          |          |           |             |
| **BuilderFull**       | **TaLib.Functions.Mama** | **10000** | **4,192.2 μs** | **31.60 μs** | **20.90 μs** |  **3.38** |    **0.08** |        **-** |        **-** |        **-** | **786.73 KB** |        **5.02** |
| BuilderLatestOnly | TaLib.Functions.Mama | 10000 | 4,101.0 μs | 52.29 μs | 31.12 μs |  3.31 |    0.08 |        - |        - |        - | 316.92 KB |        2.02 |
| NativeSingle      | TaLib.Functions.Mama | 10000 | 1,240.3 μs | 50.40 μs | 29.99 μs |  1.00 |    0.03 |  46.8750 |  46.8750 |  46.8750 |  156.6 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mama | 10000 | 1,549.0 μs | 42.64 μs | 25.38 μs |  1.25 |    0.03 | 125.0000 | 125.0000 | 125.0000 | 548.11 KB |        3.50 |
