```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mama** | **1000**  |   **602.1 μs** |  **4.23 μs** |  **2.21 μs** |  **82.61 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 1000  |   601.5 μs | 20.06 μs | 13.27 μs |  35.02 KB |
| **BuilderFull**       | **TaLib.Functions.Mama** | **10000** | **5,960.9 μs** | **54.39 μs** | **28.45 μs** | **786.31 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 10000 | 5,869.0 μs | 46.29 μs | 24.21 μs | 316.75 KB |
