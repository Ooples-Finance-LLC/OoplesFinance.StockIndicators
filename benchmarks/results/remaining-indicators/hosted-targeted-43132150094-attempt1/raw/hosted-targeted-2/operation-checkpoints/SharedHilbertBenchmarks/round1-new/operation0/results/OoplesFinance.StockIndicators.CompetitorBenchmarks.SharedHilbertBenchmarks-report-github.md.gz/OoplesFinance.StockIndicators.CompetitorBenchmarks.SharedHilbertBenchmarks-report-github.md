```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mama** | **1000**  |   **430.5 μs** | **30.26 μs** | **18.01 μs** |  **83.07 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 1000  |   405.2 μs |  2.01 μs |  1.05 μs |  35.44 KB |
| **BuilderFull**       | **TaLib.Functions.Mama** | **10000** | **4,159.3 μs** | **48.94 μs** | **25.60 μs** | **786.72 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 10000 | 4,000.5 μs | 23.33 μs | 12.20 μs |  316.9 KB |
