```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Phase [25]** |   **770.0 μs** |  **53.40 μs** |  **31.78 μs** |  **1.00** |    **0.06** |  **110.48 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Phase [25] |   582.5 μs |  81.67 μs |  48.60 μs |  0.76 |    0.07 |   42.09 KB |        0.38 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)Phase [25]** | **7,989.8 μs** | **556.93 μs** | **368.38 μs** |  **1.00** |    **0.06** | **1041.82 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Phase [25] | 6,145.4 μs | 492.45 μs | 293.05 μs |  0.77 |    0.05 |  332.13 KB |        0.32 |
