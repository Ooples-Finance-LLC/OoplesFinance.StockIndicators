```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **695.9 μs** |  **12.08 μs** |   **7.19 μs** |  **1.34** |    **0.01** |  **69.37 KB** |        **8.27** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   686.1 μs |  30.32 μs |  20.06 μs |  1.32 |    0.04 |  21.78 KB |        2.60 |
| NativeSingle      | TaLib(...)Phase [25] | 1000  |   519.8 μs |   2.06 μs |   1.22 μs |  1.00 |    0.00 |   8.39 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 1000  |   755.1 μs |  17.13 μs |  11.33 μs |  1.45 |    0.02 |  30.19 KB |        3.60 |
|                   |                      |       |            |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **7,133.3 μs** | **101.93 μs** |  **60.66 μs** |  **1.27** |    **0.01** | **632.74 KB** |        **8.02** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 7,042.2 μs |  14.76 μs |   7.72 μs |  1.25 |    0.00 | 162.41 KB |        2.06 |
| NativeSingle      | TaLib(...)Phase [25] | 10000 | 5,629.7 μs |   8.21 μs |   4.88 μs |  1.00 |    0.00 |  78.91 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 10000 | 7,631.2 μs | 669.72 μs | 442.98 μs |  1.36 |    0.08 | 276.86 KB |        3.51 |
