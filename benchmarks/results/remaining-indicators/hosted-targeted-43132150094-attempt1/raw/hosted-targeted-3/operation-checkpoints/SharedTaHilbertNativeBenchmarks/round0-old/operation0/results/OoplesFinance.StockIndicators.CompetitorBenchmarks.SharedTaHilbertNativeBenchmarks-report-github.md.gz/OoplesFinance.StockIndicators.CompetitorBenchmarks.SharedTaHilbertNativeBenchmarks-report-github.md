```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev    | Allocated |
|------------------ |--------------------- |------ |------------:|------------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |    **874.0 μs** |   **152.20 μs** | **100.67 μs** |  **68.91 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |    811.6 μs |    22.04 μs |  11.53 μs |  21.38 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** |  **8,606.1 μs** |   **243.38 μs** | **127.29 μs** | **632.42 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 10,145.0 μs | 1,252.40 μs | 745.28 μs | 162.65 KB |
