```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **680.6 μs** |  **5.56 μs** |  **2.91 μs** |  **69.36 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   679.6 μs | 14.87 μs |  8.85 μs |  21.78 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **7,037.7 μs** | **44.30 μs** | **23.17 μs** | **632.78 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 7,024.2 μs | 32.20 μs | 19.16 μs | 162.91 KB |
