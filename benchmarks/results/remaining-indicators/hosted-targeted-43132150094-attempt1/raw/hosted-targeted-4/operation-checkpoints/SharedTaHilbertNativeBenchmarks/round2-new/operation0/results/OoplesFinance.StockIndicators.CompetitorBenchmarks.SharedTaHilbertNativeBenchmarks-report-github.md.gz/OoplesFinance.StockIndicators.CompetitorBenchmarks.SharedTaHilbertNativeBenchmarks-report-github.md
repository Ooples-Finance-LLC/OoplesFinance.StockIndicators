```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **718.8 μs** |   **5.19 μs** |   **3.09 μs** |  **1.32** |    **0.01** |  **85.25 KB** |        **5.42** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   710.3 μs |   4.22 μs |   2.21 μs |  1.30 |    0.01 |  37.66 KB |        2.39 |
| NativeSingle      | TaLib(...)tSine [22] | 1000  |   544.7 μs |   5.04 μs |   3.00 μs |  1.00 |    0.01 |  15.74 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 1000  |   781.4 μs |  27.99 μs |  16.65 μs |  1.43 |    0.03 |  55.99 KB |        3.56 |
|                   |                      |       |            |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **7,423.8 μs** |  **73.90 μs** |  **48.88 μs** |  **1.26** |    **0.01** | **789.28 KB** |        **5.04** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 7,374.5 μs |  27.89 μs |  14.59 μs |  1.25 |    0.01 | 319.47 KB |        2.04 |
| NativeSingle      | TaLib(...)tSine [22] | 10000 | 5,880.1 μs |  41.18 μs |  24.50 μs |  1.00 |    0.01 | 156.57 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 10000 | 8,424.6 μs | 506.28 μs | 301.28 μs |  1.43 |    0.05 | 548.77 KB |        3.50 |
