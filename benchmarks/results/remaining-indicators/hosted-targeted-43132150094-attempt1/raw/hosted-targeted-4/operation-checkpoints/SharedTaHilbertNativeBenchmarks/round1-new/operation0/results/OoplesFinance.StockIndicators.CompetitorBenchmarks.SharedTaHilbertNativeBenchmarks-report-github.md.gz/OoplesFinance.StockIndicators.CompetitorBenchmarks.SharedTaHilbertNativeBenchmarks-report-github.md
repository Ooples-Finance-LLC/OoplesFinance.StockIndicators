```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **941.9 μs** | **113.90 μs** | **75.34 μs** |  **85.22 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   735.3 μs |  37.96 μs | 19.85 μs |   37.7 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **7,334.7 μs** |  **19.06 μs** |  **9.97 μs** | **789.24 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 7,301.0 μs |  18.08 μs |  9.46 μs | 319.46 KB |
