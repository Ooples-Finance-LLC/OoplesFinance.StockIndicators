```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **836.8 μs** |  **28.32 μs** | **14.81 μs** |  **84.84 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   834.9 μs |  17.02 μs | 10.13 μs |  37.27 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **8,668.0 μs** |  **66.57 μs** | **39.62 μs** | **788.93 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 8,594.7 μs | 103.40 μs | 54.08 μs |  319.2 KB |
