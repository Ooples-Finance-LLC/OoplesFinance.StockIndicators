```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tSine [22]** |   **813.0 μs** |  **30.26 μs** |  **18.00 μs** |  **1.00** |    **0.03** | **166.88 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tSine [22] |   608.4 μs |  49.47 μs |  29.44 μs |  0.75 |    0.04 |  74.56 KB |        0.45 |
|            |       |                      |            |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)tSine [22]** | **9,287.5 μs** | **582.84 μs** | **385.51 μs** |  **1.00** |    **0.06** | **1599.2 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tSine [22] | 6,021.3 μs |  22.50 μs |  11.77 μs |  0.65 |    0.03 | 654.64 KB |        0.41 |
