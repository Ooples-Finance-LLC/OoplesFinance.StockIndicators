```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  |   **984.3 μs** |  **3.03 μs** |  **1.80 μs** | **100.95 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  |   966.0 μs |  7.38 μs |  3.86 μs |  53.31 KB |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **9,564.3 μs** | **64.69 μs** | **33.84 μs** | **945.71 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 9,587.9 μs | 64.25 μs | 38.23 μs | 475.87 KB |
