```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  |   **979.1 μs** |  **2.51 μs** |  **1.49 μs** | **100.91 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  |   972.2 μs |  7.63 μs |  5.05 μs |  53.32 KB |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **9,487.0 μs** | **39.83 μs** | **20.83 μs** | **945.65 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 9,527.5 μs | 28.08 μs | 14.68 μs | 475.87 KB |
