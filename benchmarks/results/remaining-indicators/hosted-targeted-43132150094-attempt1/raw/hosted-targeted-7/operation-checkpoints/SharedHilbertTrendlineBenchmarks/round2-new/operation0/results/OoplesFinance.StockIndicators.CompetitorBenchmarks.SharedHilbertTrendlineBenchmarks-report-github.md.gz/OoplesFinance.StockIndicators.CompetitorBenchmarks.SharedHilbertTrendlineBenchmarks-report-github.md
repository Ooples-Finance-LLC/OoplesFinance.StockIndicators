```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  |   **870.8 μs** |   **5.14 μs** |   **3.06 μs** |  **6.44** |    **0.07** |        **-** |        **-** |        **-** |  **101.36 KB** |        **0.49** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  |   843.2 μs |   5.87 μs |   3.07 μs |  6.24 |    0.06 |        - |        - |        - |   53.74 KB |        0.26 |
| NativeSingle      | Skend(...)dline [22] | 1000  |   135.2 μs |   2.31 μs |   1.37 μs |  1.00 |    0.01 |  12.6953 |   2.9297 |        - |  207.71 KB |        1.00 |
| NativeParallel    | Skend(...)dline [22] | 1000  |   259.2 μs |  16.09 μs |  10.64 μs |  1.92 |    0.08 |  33.2031 |  11.7188 |        - |  528.53 KB |        2.54 |
|                   |                      |       |            |           |           |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **8,400.7 μs** |  **65.38 μs** |  **43.24 μs** |  **5.44** |    **0.14** |        **-** |        **-** |        **-** |  **945.95 KB** |        **0.46** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 8,321.3 μs |  51.71 μs |  27.05 μs |  5.39 |    0.14 |        - |        - |        - |  476.23 KB |        0.23 |
| NativeSingle      | Skend(...)dline [22] | 10000 | 1,544.1 μs |  61.48 μs |  40.67 μs |  1.00 |    0.04 | 179.6875 | 140.6250 |  78.1250 | 2071.66 KB |        1.00 |
| NativeParallel    | Skend(...)dline [22] | 10000 | 3,213.4 μs | 540.61 μs | 357.58 μs |  2.08 |    0.23 | 406.2500 | 312.5000 | 125.0000 | 5258.48 KB |        2.54 |
