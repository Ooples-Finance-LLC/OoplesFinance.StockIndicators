```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)dline [22]** | **1,014.8 μs** |  **36.88 μs** | **21.95 μs** |  **1.00** |    **0.03** |  **223.38 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)dline [22] |   182.6 μs |   2.87 μs |  1.50 μs |  0.18 |    0.00 |  290.52 KB |        1.30 |
|            |       |                      |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)dline [22]** | **9,724.1 μs** | **122.36 μs** | **72.81 μs** |  **1.00** |    **0.01** | **2156.66 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)dline [22] | 1,864.1 μs |  29.21 μs | 17.38 μs |  0.19 |    0.00 | 2812.98 KB |        1.30 |
