```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Ratio | RatioSD | Gen0    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)eriod [26]** | **1000**  |   **384.0 μs** |  **5.62 μs** |  **2.94 μs** |  **3.08** |    **0.02** |       **-** |  **66.94 KB** |        **8.38** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 1000  |   382.0 μs |  2.59 μs |  1.35 μs |  3.07 |    0.01 |       - |  19.34 KB |        2.42 |
| NativeSingle      | TaLib(...)eriod [26] | 1000  |   124.5 μs |  0.33 μs |  0.18 μs |  1.00 |    0.00 |       - |   7.99 KB |        1.00 |
| NativeParallel    | TaLib(...)eriod [26] | 1000  |   215.4 μs | 24.87 μs | 16.45 μs |  1.73 |    0.13 |  1.9531 |  28.37 KB |        3.55 |
|                   |                      |       |            |          |          |       |         |         |           |             |
| **BuilderFull**       | **TaLib(...)eriod [26]** | **10000** | **3,775.2 μs** | **46.18 μs** | **24.15 μs** |  **3.00** |    **0.02** | **31.2500** | **629.99 KB** |        **8.04** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 10000 | 3,744.2 μs | 16.26 μs |  9.68 μs |  2.98 |    0.01 |       - | 160.19 KB |        2.04 |
| NativeSingle      | TaLib(...)eriod [26] | 10000 | 1,257.8 μs |  3.70 μs |  1.93 μs |  1.00 |    0.00 |       - |  78.35 KB |        1.00 |
| NativeParallel    | TaLib(...)eriod [26] | 10000 | 1,385.0 μs | 78.66 μs | 52.03 μs |  1.10 |    0.04 | 15.6250 | 274.51 KB |        3.50 |
