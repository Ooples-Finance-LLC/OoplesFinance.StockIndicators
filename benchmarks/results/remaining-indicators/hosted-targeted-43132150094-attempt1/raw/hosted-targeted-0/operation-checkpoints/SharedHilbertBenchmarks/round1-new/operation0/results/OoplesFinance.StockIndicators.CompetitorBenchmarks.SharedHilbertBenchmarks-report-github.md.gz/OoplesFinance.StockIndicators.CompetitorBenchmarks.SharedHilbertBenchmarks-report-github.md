```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)eriod [26]** | **1000**  |   **381.5 μs** |  **1.96 μs** |  **1.02 μs** |       **-** |  **66.95 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 1000  |   378.8 μs |  1.72 μs |  0.90 μs |       - |  19.35 KB |
| **BuilderFull**       | **TaLib(...)eriod [26]** | **10000** | **3,758.0 μs** | **61.26 μs** | **36.46 μs** | **31.2500** | **630.02 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 10000 | 3,712.9 μs | 11.06 μs |  5.78 μs |       - | 160.14 KB |
