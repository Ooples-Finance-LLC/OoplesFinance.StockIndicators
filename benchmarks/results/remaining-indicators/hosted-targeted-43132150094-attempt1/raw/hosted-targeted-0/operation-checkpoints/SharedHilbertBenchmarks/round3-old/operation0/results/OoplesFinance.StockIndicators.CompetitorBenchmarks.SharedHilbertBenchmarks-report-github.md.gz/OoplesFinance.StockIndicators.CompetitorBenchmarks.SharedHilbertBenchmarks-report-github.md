```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)eriod [26]** | **1000**  |   **477.1 μs** |  **4.44 μs** |  **2.32 μs** |       **-** |  **66.53 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 1000  |   478.7 μs |  5.38 μs |  2.81 μs |       - |  18.94 KB |
| **BuilderFull**       | **TaLib(...)eriod [26]** | **10000** | **4,714.5 μs** | **34.01 μs** | **22.50 μs** | **31.2500** | **629.61 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 10000 | 4,697.7 μs | 55.21 μs | 28.87 μs |       - | 159.74 KB |
