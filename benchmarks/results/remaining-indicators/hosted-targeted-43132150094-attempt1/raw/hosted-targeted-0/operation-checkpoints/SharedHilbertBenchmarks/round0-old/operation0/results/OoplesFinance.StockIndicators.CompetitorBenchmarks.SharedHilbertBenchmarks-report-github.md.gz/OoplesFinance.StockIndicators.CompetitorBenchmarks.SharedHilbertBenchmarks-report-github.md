```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)eriod [26]** | **1000**  |   **476.4 μs** |   **4.49 μs** |  **2.35 μs** |       **-** |  **66.49 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 1000  |   472.5 μs |   2.44 μs |  1.45 μs |       - |  18.92 KB |
| **BuilderFull**       | **TaLib(...)eriod [26]** | **10000** | **4,747.9 μs** | **119.16 μs** | **78.82 μs** | **31.2500** | **629.59 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 10000 | 4,655.6 μs |  25.62 μs | 13.40 μs |       - | 159.74 KB |
