```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)eriod [26]** |   **523.4 μs** | **16.00 μs** |  **8.37 μs** |  **1.00** |    **0.02** |  **108.07 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)eriod [26] |   123.4 μs |  3.29 μs |  1.96 μs |  0.24 |    0.00 |   40.69 KB |        0.38 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)eriod [26]** | **4,990.4 μs** | **22.39 μs** | **13.32 μs** |  **1.00** |    **0.00** | **1038.47 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)eriod [26] | 1,213.9 μs | 28.00 μs | 18.52 μs |  0.24 |    0.00 |  331.71 KB |        0.32 |
