```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dMode [27]** |  **1,060.5 μs** |  **50.52 μs** |  **33.41 μs** |  **1.00** |    **0.04** |  **113.15 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dMode [27] |    531.4 μs |  33.37 μs |  19.86 μs |  0.50 |    0.02 |   37.85 KB |        0.33 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)dMode [27]** | **10,844.7 μs** | **435.18 μs** | **287.84 μs** |  **1.00** |    **0.04** | **1038.95 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dMode [27] |  5,752.1 μs | 458.83 μs | 303.49 μs |  0.53 |    0.03 |  291.75 KB |        0.28 |
