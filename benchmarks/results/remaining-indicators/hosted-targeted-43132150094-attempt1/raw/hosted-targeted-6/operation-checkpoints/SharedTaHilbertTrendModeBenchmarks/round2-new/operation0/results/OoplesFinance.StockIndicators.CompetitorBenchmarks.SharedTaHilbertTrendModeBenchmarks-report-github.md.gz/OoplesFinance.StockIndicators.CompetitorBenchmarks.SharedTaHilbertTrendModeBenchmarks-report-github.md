```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1,109.8 μs** |  **23.91 μs** |  **14.23 μs** |  **1.98** |    **0.03** |   **72.1 KB** |       **15.33** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1,087.4 μs |  30.96 μs |  20.48 μs |  1.94 |    0.04 |  24.47 KB |        5.20 |
| NativeSingle      | TaLib(...)dMode [27] | 1000  |    559.5 μs |  10.37 μs |   6.86 μs |  1.00 |    0.02 |    4.7 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 1000  |    781.3 μs |  43.21 μs |  28.58 μs |  1.40 |    0.05 |  17.43 KB |        3.71 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **11,353.8 μs** | **305.23 μs** | **201.89 μs** |  **1.84** |    **0.05** | **635.49 KB** |       **15.75** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 11,328.7 μs | 468.07 μs | 278.54 μs |  1.84 |    0.06 | 165.79 KB |        4.11 |
| NativeSingle      | TaLib(...)dMode [27] | 10000 |  6,164.1 μs | 233.34 μs | 122.04 μs |  1.00 |    0.03 |  40.35 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 10000 |  8,421.5 μs | 655.26 μs | 433.42 μs |  1.37 |    0.07 | 141.13 KB |        3.50 |
