```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1.334 ms** | **0.0419 ms** | **0.0277 ms** |  **71.69 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1.294 ms | 0.0492 ms | 0.0325 ms |  24.05 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **13.454 ms** | **0.2186 ms** | **0.1446 ms** | **635.23 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 13.532 ms | 0.1569 ms | 0.0933 ms | 165.46 KB |
