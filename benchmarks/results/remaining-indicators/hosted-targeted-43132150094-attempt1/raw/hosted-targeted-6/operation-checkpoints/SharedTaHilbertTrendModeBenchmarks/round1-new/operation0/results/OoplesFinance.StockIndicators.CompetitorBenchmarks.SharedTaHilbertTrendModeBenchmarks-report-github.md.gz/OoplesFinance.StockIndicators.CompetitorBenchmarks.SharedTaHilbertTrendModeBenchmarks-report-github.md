```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1.110 ms** | **0.0496 ms** | **0.0328 ms** |   **72.1 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1.078 ms | 0.0156 ms | 0.0093 ms |  24.47 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **11.679 ms** | **0.4429 ms** | **0.2930 ms** | **635.75 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 11.301 ms | 0.2069 ms | 0.1231 ms | 165.97 KB |
