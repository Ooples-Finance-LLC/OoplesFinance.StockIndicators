```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1.280 ms** | **0.0677 ms** | **0.0448 ms** |   **71.6 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1.238 ms | 0.0330 ms | 0.0196 ms |  24.05 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **13.275 ms** | **0.2785 ms** | **0.1657 ms** | **635.32 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 13.272 ms | 0.2642 ms | 0.1382 ms | 165.67 KB |
