```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |------------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Phase [25]** |  **1,143.5 μs** | **32.21 μs** | **21.30 μs** |  **1.00** |    **0.03** | **110.06 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Phase [25] |    552.4 μs | 22.30 μs | 13.27 μs |  0.48 |    0.01 |   41.8 KB |        0.38 |
|            |       |                      |             |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Phase [25]** | **11,381.5 μs** | **42.30 μs** | **22.12 μs** |  **1.00** |    **0.00** | **1041.4 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Phase [25] |  5,682.9 μs | 27.48 μs | 18.18 μs |  0.50 |    0.00 |  331.8 KB |        0.32 |
