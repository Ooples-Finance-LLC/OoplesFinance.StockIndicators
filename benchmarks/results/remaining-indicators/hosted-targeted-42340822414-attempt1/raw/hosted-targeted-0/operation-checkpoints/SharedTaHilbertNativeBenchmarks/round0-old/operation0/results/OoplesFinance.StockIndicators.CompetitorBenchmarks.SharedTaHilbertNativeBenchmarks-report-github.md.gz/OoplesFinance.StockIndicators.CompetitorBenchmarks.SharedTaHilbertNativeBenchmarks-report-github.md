```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **1.089 ms** | **0.0070 ms** | **0.0037 ms** |  **68.95 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1.083 ms | 0.0055 ms | 0.0029 ms |  21.39 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **11.357 ms** | **0.0443 ms** | **0.0264 ms** |  **632.7 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 11.288 ms | 0.0301 ms | 0.0158 ms | 162.96 KB |
