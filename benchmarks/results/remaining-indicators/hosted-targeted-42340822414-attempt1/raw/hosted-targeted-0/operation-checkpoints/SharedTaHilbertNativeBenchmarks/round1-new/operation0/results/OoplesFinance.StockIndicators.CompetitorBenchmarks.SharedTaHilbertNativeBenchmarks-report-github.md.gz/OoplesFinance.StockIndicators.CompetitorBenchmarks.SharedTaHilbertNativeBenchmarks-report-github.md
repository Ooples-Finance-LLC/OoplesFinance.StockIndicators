```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **1.075 ms** | **0.0067 ms** | **0.0040 ms** |  **68.95 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1.072 ms | 0.0108 ms | 0.0064 ms |  21.38 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **11.212 ms** | **0.1761 ms** | **0.0921 ms** | **632.67 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 11.125 ms | 0.0675 ms | 0.0446 ms | 162.73 KB |
