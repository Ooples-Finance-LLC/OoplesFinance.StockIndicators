```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **1.097 ms** | **0.0191 ms** | **0.0113 ms** |  **68.95 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1.086 ms | 0.0059 ms | 0.0031 ms |  21.38 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **11.292 ms** | **0.0596 ms** | **0.0355 ms** | **632.67 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 11.365 ms | 0.1866 ms | 0.1111 ms | 162.85 KB |
