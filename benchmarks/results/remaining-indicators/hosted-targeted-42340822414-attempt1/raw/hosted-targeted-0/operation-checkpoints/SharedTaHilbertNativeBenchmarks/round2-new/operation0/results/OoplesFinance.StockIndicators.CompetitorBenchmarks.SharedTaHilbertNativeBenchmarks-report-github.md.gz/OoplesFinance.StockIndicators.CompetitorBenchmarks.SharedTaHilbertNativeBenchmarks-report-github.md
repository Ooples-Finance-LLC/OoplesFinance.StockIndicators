```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **1,088.0 μs** |  **26.54 μs** |  **15.79 μs** |  **2.10** |    **0.03** |  **68.95 KB** |        **8.22** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1,088.2 μs |  36.50 μs |  24.14 μs |  2.10 |    0.05 |  21.39 KB |        2.55 |
| NativeSingle      | TaLib(...)Phase [25] | 1000  |    518.4 μs |   3.57 μs |   1.87 μs |  1.00 |    0.00 |   8.39 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 1000  |    744.1 μs |  26.27 μs |  15.63 μs |  1.44 |    0.03 |  30.19 KB |        3.60 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **11,195.0 μs** |  **44.53 μs** |  **23.29 μs** |  **1.88** |    **0.07** |  **632.7 KB** |        **8.02** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 11,199.4 μs |  76.71 μs |  50.74 μs |  1.88 |    0.07 | 162.89 KB |        2.06 |
| NativeSingle      | TaLib(...)Phase [25] | 10000 |  5,951.6 μs | 367.21 μs | 218.52 μs |  1.00 |    0.05 |  78.92 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 10000 |  7,747.3 μs | 486.76 μs | 289.66 μs |  1.30 |    0.07 | 276.86 KB |        3.51 |
