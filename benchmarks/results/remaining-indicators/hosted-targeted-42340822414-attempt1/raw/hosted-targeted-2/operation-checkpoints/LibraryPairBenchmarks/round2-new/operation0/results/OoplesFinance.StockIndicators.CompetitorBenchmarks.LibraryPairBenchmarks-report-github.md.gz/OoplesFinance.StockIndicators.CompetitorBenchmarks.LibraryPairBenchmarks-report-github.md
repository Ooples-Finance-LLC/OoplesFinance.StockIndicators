```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dMode [27]** |  **1,757.5 μs** |  **52.54 μs** | **31.27 μs** |  **1.00** |    **0.02** |  **112.73 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dMode [27] |    631.1 μs |  37.42 μs | 24.75 μs |  0.36 |    0.01 |   36.87 KB |        0.33 |
|            |       |                      |             |           |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)dMode [27]** | **17,433.8 μs** | **126.89 μs** | **83.93 μs** |  **1.00** |    **0.01** | **1043.41 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dMode [27] |  6,403.4 μs |  16.89 μs | 11.17 μs |  0.37 |    0.00 |  292.78 KB |        0.28 |
