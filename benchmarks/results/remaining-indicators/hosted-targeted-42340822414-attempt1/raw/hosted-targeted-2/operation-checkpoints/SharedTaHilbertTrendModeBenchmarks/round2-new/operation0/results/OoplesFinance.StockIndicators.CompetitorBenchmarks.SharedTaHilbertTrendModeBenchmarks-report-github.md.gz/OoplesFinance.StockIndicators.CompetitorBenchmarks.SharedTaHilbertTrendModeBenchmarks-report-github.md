```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1,668.0 μs** |     **8.70 μs** |     **4.55 μs** |  **2.86** |    **0.01** |   **71.7 KB** |       **15.15** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1,629.3 μs |    11.61 μs |     7.68 μs |  2.79 |    0.02 |  24.11 KB |        5.09 |
| NativeSingle      | TaLib(...)dMode [27] | 1000  |    583.8 μs |     4.93 μs |     2.58 μs |  1.00 |    0.01 |   4.73 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 1000  |    824.0 μs |    30.47 μs |    18.13 μs |  1.41 |    0.03 |  17.43 KB |        3.68 |
|                   |                      |       |             |             |             |       |         |           |             |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **17,040.7 μs** |   **110.24 μs** |    **65.60 μs** |  **2.66** |    **0.05** | **635.78 KB** |       **15.76** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 20,231.1 μs | 2,297.44 μs | 1,519.61 μs |  3.16 |    0.23 | 165.97 KB |        4.12 |
| NativeSingle      | TaLib(...)dMode [27] | 10000 |  6,409.8 μs |   194.23 μs |   115.59 μs |  1.00 |    0.02 |  40.33 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 10000 |  8,552.8 μs |   467.12 μs |   277.98 μs |  1.33 |    0.05 | 141.02 KB |        3.50 |
