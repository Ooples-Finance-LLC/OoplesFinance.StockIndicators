```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tSine [22]** |   **953.6 μs** | **20.84 μs** | **13.78 μs** |  **1.00** |    **0.02** |  **166.46 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tSine [22] |   459.9 μs | 23.24 μs | 15.38 μs |  0.48 |    0.02 |   74.56 KB |        0.45 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)tSine [22]** | **9,573.8 μs** | **87.36 μs** | **51.99 μs** |  **1.00** |    **0.01** | **1591.27 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tSine [22] | 4,643.2 μs | 18.68 μs | 12.35 μs |  0.49 |    0.00 |  654.64 KB |        0.41 |
