```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|------------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **811.5 μs** |    **15.56 μs** |   **9.26 μs** |  **2.07** |    **0.04** |  **84.83 KB** |        **5.40** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   808.8 μs |     6.86 μs |   4.08 μs |  2.07 |    0.04 |  37.26 KB |        2.37 |
| NativeSingle      | TaLib(...)tSine [22] | 1000  |   391.6 μs |    11.39 μs |   7.53 μs |  1.00 |    0.03 |  15.72 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 1000  |   589.6 μs |    17.89 μs |  10.65 μs |  1.51 |    0.04 |  55.96 KB |        3.56 |
|                   |                      |       |            |             |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **9,952.5 μs** | **1,167.28 μs** | **772.08 μs** |  **2.17** |    **0.16** | **789.04 KB** |        **5.04** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 9,208.6 μs |    76.73 μs |  40.13 μs |  2.01 |    0.01 |  319.2 KB |        2.04 |
| NativeSingle      | TaLib(...)tSine [22] | 10000 | 4,580.5 μs |    44.20 μs |  26.30 μs |  1.00 |    0.01 | 156.51 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 10000 | 6,423.1 μs |   255.42 μs | 133.59 μs |  1.40 |    0.03 | 548.64 KB |        3.51 |
