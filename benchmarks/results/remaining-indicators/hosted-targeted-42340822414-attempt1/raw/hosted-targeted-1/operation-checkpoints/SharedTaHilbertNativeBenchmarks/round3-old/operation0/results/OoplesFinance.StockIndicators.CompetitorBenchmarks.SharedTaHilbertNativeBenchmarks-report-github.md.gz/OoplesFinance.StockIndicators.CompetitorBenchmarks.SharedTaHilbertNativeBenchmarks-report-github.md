```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **817.3 μs** |   **6.90 μs** |   **3.61 μs** |  **84.83 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   816.8 μs |  14.93 μs |   8.89 μs |  37.25 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **9,348.5 μs** | **417.83 μs** | **276.37 μs** | **788.86 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 9,210.0 μs |  23.78 μs |  15.73 μs | 319.23 KB |
