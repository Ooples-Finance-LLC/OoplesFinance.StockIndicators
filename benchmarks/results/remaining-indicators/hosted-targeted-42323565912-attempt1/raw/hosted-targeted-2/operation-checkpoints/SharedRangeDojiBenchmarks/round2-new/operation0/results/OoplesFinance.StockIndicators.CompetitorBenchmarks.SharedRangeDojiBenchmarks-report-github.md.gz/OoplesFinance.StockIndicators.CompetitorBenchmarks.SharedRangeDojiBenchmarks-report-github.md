```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|---------:|---------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)yDoji [27]** | **1000**  |  **71.57 μs** | **0.541 μs** | **0.322 μs** |  **1.00** |    **0.01** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)yDoji [27] | 1000  | 115.54 μs | 4.277 μs | 2.545 μs |  1.61 |    0.03 |       - |       - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib(...)yDoji [27] | 1000  |  66.84 μs | 0.903 μs | 0.537 μs |  0.93 |    0.01 |  3.4180 |  0.4883 |  57.27 KB |       14.43 |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 1000  |  62.86 μs | 0.429 μs | 0.255 μs |  0.88 |    0.01 |  0.4883 |       - |   9.39 KB |        2.37 |
|                   |                      |       |           |          |          |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)yDoji [27]** | **10000** | **554.61 μs** | **3.254 μs** | **1.702 μs** |  **1.00** |    **0.00** |       **-** |       **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)yDoji [27] | 10000 | 369.33 μs | 7.749 μs | 4.611 μs |  0.67 |    0.01 |  3.9063 |       - |  78.74 KB |        2.01 |
| BuilderFull       | TaLib(...)yDoji [27] | 10000 | 616.23 μs | 3.835 μs | 2.282 μs |  1.11 |    0.01 | 31.2500 | 11.7188 | 549.83 KB |       14.04 |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 10000 | 579.61 μs | 1.926 μs | 1.008 μs |  1.05 |    0.00 |  3.9063 |       - |  79.73 KB |        2.04 |
