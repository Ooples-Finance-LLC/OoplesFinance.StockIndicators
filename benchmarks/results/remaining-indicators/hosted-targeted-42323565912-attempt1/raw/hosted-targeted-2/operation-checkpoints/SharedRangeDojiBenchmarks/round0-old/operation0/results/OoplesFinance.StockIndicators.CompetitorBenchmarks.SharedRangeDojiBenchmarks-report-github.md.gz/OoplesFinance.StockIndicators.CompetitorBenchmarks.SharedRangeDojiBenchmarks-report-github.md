```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)yDoji [27]** | **1000**  |  **74.10 μs** | **0.432 μs** | **0.257 μs** |       **-** |       **-** |  **57.23 KB** |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 1000  |  71.87 μs | 0.331 μs | 0.173 μs |  0.4883 |       - |   9.38 KB |
| **BuilderFull**       | **TaLib(...)yDoji [27]** | **10000** | **707.32 μs** | **3.475 μs** | **2.068 μs** | **31.2500** | **11.7188** | **549.79 KB** |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 10000 | 678.45 μs | 2.279 μs | 1.192 μs |  3.9063 |       - |  79.72 KB |
