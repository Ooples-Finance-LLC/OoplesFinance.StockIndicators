```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)yDoji [27]** |  **75.45 μs** |  **4.341 μs** |  **2.270 μs** |  **1.00** |    **0.04** |  **65.33 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)yDoji [27] |  51.77 μs |  0.198 μs |  0.104 μs |  0.69 |    0.02 |   19.3 KB |        0.30 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)yDoji [27]** | **575.30 μs** | **30.311 μs** | **18.037 μs** |  **1.00** |    **0.04** | **635.38 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)yDoji [27] | 540.79 μs | 24.311 μs | 16.080 μs |  0.94 |    0.04 | 124.77 KB |        0.20 |
