```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)eDoji [28]** | **1000**  |  **64.13 μs** | **2.762 μs** | **1.643 μs** |  **1.9531** |       **-** |  **57.23 KB** |
| BuilderLatestOnly | TaLib(...)eDoji [28] | 1000  |  58.38 μs | 0.319 μs | 0.211 μs |  0.4883 |       - |   9.39 KB |
| **BuilderFull**       | **TaLib(...)eDoji [28]** | **10000** | **600.07 μs** | **3.431 μs** | **1.794 μs** | **31.2500** | **11.7188** | **549.79 KB** |
| BuilderLatestOnly | TaLib(...)eDoji [28] | 10000 | 540.89 μs | 3.650 μs | 2.415 μs |  3.9063 |       - |  79.73 KB |
