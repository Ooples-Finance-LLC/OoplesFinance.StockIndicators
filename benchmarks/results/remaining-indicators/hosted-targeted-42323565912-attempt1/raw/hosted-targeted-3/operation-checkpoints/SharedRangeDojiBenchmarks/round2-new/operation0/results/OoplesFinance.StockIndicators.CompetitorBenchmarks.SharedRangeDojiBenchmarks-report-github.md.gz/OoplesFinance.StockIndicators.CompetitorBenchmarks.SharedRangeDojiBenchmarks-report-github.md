```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)eDoji [28]** | **1000**  |  **71.03 μs** |  **1.457 μs** |  **0.964 μs** |  **1.00** |    **0.02** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)eDoji [28] | 1000  | 114.29 μs |  4.234 μs |  2.520 μs |  1.61 |    0.04 |       - |       - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib(...)eDoji [28] | 1000  |  64.23 μs |  0.791 μs |  0.471 μs |  0.90 |    0.01 |  3.4180 |  0.4883 |  57.27 KB |       14.43 |
| BuilderLatestOnly | TaLib(...)eDoji [28] | 1000  |  61.23 μs |  2.220 μs |  1.321 μs |  0.86 |    0.02 |  0.4883 |       - |   9.39 KB |        2.37 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)eDoji [28]** | **10000** | **544.85 μs** |  **2.805 μs** |  **1.669 μs** |  **1.00** |    **0.00** |       **-** |       **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)eDoji [28] | 10000 | 387.79 μs | 33.289 μs | 19.810 μs |  0.71 |    0.03 |  5.8594 |       - |   78.7 KB |        2.01 |
| BuilderFull       | TaLib(...)eDoji [28] | 10000 | 588.50 μs |  4.749 μs |  2.826 μs |  1.08 |    0.01 | 31.2500 | 11.7188 | 549.83 KB |       14.04 |
| BuilderLatestOnly | TaLib(...)eDoji [28] | 10000 | 561.65 μs |  6.857 μs |  4.080 μs |  1.03 |    0.01 |  3.9063 |       - |  79.73 KB |        2.04 |
