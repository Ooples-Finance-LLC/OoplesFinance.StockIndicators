```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)eDoji [28]** | **637.72 μs** | **22.821 μs** | **15.095 μs** |  **1.00** |    **0.03** |  **65.37 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)eDoji [28] |  54.25 μs | 12.018 μs |  6.286 μs |  0.09 |    0.01 |  19.63 KB |        0.30 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)eDoji [28]** | **555.31 μs** |  **2.846 μs** |  **1.488 μs** |  **1.00** |    **0.00** |  **635.7 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)eDoji [28] | 516.82 μs | 22.583 μs | 14.937 μs |  0.93 |    0.03 | 124.44 KB |        0.20 |
