```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |-------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mfi** | **1000**  | **113.1 μs** |  **1.42 μs** |  **0.74 μs** |  **3.9063** |       **-** |  **65.12 KB** |
| BuilderLatestOnly | TaLib.Functions.Mfi | 1000  | 107.7 μs |  1.91 μs |  1.00 μs |  0.9766 |       - |  17.48 KB |
| **BuilderFull**       | **TaLib.Functions.Mfi** | **10000** | **314.7 μs** | **25.58 μs** | **15.22 μs** | **37.1094** | **13.6719** | **627.95 KB** |
| BuilderLatestOnly | TaLib.Functions.Mfi | 10000 | 297.3 μs | 25.42 μs | 16.82 μs |  7.8125 |  1.9531 | 158.12 KB |
