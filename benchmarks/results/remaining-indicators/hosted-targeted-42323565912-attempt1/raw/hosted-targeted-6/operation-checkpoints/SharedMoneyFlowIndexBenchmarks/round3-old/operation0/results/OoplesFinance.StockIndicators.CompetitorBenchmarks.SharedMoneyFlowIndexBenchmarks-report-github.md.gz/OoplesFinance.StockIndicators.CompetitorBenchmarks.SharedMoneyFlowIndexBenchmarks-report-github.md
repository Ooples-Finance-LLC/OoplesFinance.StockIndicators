```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |-------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mfi** | **1000**  | **127.4 μs** | **36.47 μs** | **19.07 μs** |  **3.9063** |       **-** |  **65.08 KB** |
| BuilderLatestOnly | TaLib.Functions.Mfi | 1000  | 107.4 μs |  1.88 μs |  0.98 μs |  0.9766 |       - |  17.48 KB |
| **BuilderFull**       | **TaLib.Functions.Mfi** | **10000** | **320.3 μs** | **26.42 μs** | **17.48 μs** | **37.1094** | **13.6719** | **627.95 KB** |
| BuilderLatestOnly | TaLib.Functions.Mfi | 10000 | 295.7 μs | 10.35 μs |  5.41 μs |  7.8125 |  1.9531 | 158.12 KB |
