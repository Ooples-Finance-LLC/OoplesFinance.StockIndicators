```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |-----------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Mfi** | **1000**  | **125.864 μs** | **30.9227 μs** | **16.1732 μs** | **13.54** |    **1.65** |  **3.9063** |       **-** |  **65.08 KB** |        **8.13** |
| BuilderLatestOnly | TaLib.Functions.Mfi | 1000  | 108.541 μs |  4.1217 μs |  2.7262 μs | 11.67 |    0.32 |  0.9766 |       - |  17.48 KB |        2.18 |
| NativeSingle      | TaLib.Functions.Mfi | 1000  |   9.300 μs |  0.2003 μs |  0.1325 μs |  1.00 |    0.02 |  0.4883 |       - |   8.01 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mfi | 1000  |  90.240 μs |  0.9369 μs |  0.6197 μs |  9.71 |    0.15 |  0.4883 |       - |   9.03 KB |        1.13 |
|                   |                     |       |            |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Mfi** | **10000** | **318.882 μs** | **22.8368 μs** | **15.1051 μs** |  **3.47** |    **0.18** | **37.1094** | **13.6719** | **627.95 KB** |        **8.02** |
| BuilderLatestOnly | TaLib.Functions.Mfi | 10000 | 305.405 μs | 24.9304 μs | 16.4899 μs |  3.32 |    0.19 |  7.8125 |  1.9531 | 158.12 KB |        2.02 |
| NativeSingle      | TaLib.Functions.Mfi | 10000 |  91.995 μs |  3.7978 μs |  2.5120 μs |  1.00 |    0.04 |  4.3945 |  0.4883 |  78.32 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mfi | 10000 | 133.288 μs |  3.4780 μs |  2.0697 μs |  1.45 |    0.04 |  3.9063 |       - |  79.34 KB |        1.01 |
