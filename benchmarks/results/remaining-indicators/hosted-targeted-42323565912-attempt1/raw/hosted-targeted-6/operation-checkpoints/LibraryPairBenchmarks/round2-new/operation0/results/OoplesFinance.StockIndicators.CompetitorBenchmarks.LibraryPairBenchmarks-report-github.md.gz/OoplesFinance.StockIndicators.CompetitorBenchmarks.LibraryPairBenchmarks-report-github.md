```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Mfi** |  **97.67 μs** |  **8.147 μs** |  **4.261 μs** |  **1.00** |    **0.06** |  **105.57 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Mfi |  22.51 μs |  4.551 μs |  2.708 μs |  0.23 |    0.03 |   40.56 KB |        0.38 |
|            |       |                     |           |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Mfi** | **735.63 μs** | **25.213 μs** | **15.004 μs** |  **1.00** |    **0.03** | **1036.58 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Mfi | 195.70 μs |  6.404 μs |  3.811 μs |  0.27 |    0.01 |  329.95 KB |        0.32 |
