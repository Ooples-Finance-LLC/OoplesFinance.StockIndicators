```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated | Alloc Ratio |
|------------------ |--------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|----------:|------------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |    **38.44 μs** |  **0.795 μs** |  **0.526 μs** |  **0.50** |    **0.01** |   **5.3711** |   **0.9766** |  **88.31 KB** |        **0.50** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |    35.12 μs |  0.438 μs |  0.261 μs |  0.45 |    0.01 |   2.4414 |   0.2441 |   40.7 KB |        0.23 |
| NativeSingle      | Skender.GetAdl | 1000  |    77.41 μs |  2.520 μs |  1.667 μs |  1.00 |    0.03 |  10.7422 |   2.4414 | 176.21 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 1000  |   194.22 μs | 12.551 μs |  8.302 μs |  2.51 |    0.11 |  28.3203 |   8.7891 |  449.4 KB |        2.55 |
|                   |                |       |             |           |           |       |         |          |          |           |             |
| **BuilderFull**       | **Skender.GetAdl** | **10000** |   **619.35 μs** | **21.760 μs** | **14.393 μs** |  **0.72** |    **0.02** |  **50.7813** |  **15.6250** | **862.14 KB** |        **0.49** |
| BuilderLatestOnly | Skender.GetAdl | 10000 |   344.06 μs |  3.016 μs |  1.995 μs |  0.40 |    0.00 |  23.4375 |   9.7656 | 392.29 KB |        0.22 |
| NativeSingle      | Skender.GetAdl | 10000 |   860.79 μs | 14.429 μs |  8.587 μs |  1.00 |    0.01 | 101.5625 |  62.5000 | 1758.3 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 10000 | 1,846.68 μs | 92.442 μs | 55.011 μs |  2.15 |    0.06 | 265.6250 | 187.5000 | 4474.9 KB |        2.55 |
