```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error      | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------- |------------:|-----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAdl** |   **252.57 μs** |   **2.740 μs** |  **1.433 μs** |  **1.00** |    **0.01** | **158.96 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAdl |    90.25 μs |   1.027 μs |  0.537 μs |  0.36 |    0.00 | 273.98 KB |        1.72 |
|            |       |                |             |            |           |       |         |           |             |
| **Ooples**     | **10000** | **Skender.GetAdl** | **1,679.96 μs** | **108.973 μs** | **64.848 μs** |  **1.00** |    **0.05** |   **1512 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAdl |   938.00 μs |  37.538 μs | 24.829 μs |  0.56 |    0.03 | 2656.2 KB |        1.76 |
