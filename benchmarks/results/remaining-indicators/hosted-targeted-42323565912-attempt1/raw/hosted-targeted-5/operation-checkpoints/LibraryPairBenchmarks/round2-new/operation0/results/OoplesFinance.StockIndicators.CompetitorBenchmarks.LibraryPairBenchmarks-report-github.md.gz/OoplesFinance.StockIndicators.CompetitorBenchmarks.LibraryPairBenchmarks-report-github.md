```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error    | StdDev   | Ratio | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|---------:|---------:|------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)iLine [24]** |  **87.51 μs** | **1.230 μs** | **0.732 μs** |  **1.00** |  **65.37 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)iLine [24] |  58.63 μs | 0.534 μs | 0.353 μs |  0.67 |  16.63 KB |        0.25 |
|            |       |                      |           |          |          |       |           |             |
| **Ooples**     | **10000** | **TaLib(...)iLine [24]** | **446.91 μs** | **7.934 μs** | **4.150 μs** |  **1.00** | **633.08 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)iLine [24] | 546.74 μs | 2.715 μs | 1.420 μs |  1.22 |  122.8 KB |        0.19 |
