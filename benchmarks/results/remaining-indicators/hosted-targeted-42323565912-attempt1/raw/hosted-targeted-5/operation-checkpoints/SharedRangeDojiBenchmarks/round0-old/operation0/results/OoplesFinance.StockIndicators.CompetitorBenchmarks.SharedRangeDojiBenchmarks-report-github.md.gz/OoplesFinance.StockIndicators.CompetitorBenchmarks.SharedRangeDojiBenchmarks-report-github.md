```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)iLine [24]** | **1000**  |  **69.13 μs** | **0.354 μs** | **0.211 μs** |       **-** |      **-** |  **57.27 KB** |
| BuilderLatestOnly | TaLib(...)iLine [24] | 1000  |  53.97 μs | 0.364 μs | 0.217 μs |  0.4883 |      - |   9.38 KB |
| **BuilderFull**       | **TaLib(...)iLine [24]** | **10000** | **585.10 μs** | **9.368 μs** | **4.899 μs** | **31.2500** | **7.8125** |  **549.8 KB** |
| BuilderLatestOnly | TaLib(...)iLine [24] | 10000 | 499.75 μs | 1.655 μs | 0.985 μs |  3.9063 |      - |  79.71 KB |
