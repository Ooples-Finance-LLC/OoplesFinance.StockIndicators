```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev   | Ratio | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|---------:|------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)iLine [24]** | **1000**  |  **72.05 μs** |  **0.447 μs** | **0.266 μs** |  **1.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)iLine [24] | 1000  | 104.84 μs |  1.621 μs | 0.848 μs |  1.46 |       - |       - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib(...)iLine [24] | 1000  |  49.52 μs |  0.285 μs | 0.170 μs |  0.69 |  3.4180 |  0.4883 |  57.27 KB |       14.43 |
| BuilderLatestOnly | TaLib(...)iLine [24] | 1000  |  47.11 μs |  0.243 μs | 0.127 μs |  0.65 |  0.4883 |       - |   9.38 KB |        2.36 |
|                   |                      |       |           |           |          |       |         |         |           |             |
| **NativeSingle**      | **TaLib(...)iLine [24]** | **10000** | **604.53 μs** |  **4.045 μs** | **2.407 μs** |  **1.00** |       **-** |       **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib(...)iLine [24] | 10000 | 376.43 μs |  7.860 μs | 4.111 μs |  0.62 |  3.9063 |       - |  78.72 KB |        2.01 |
| BuilderFull       | TaLib(...)iLine [24] | 10000 | 455.00 μs | 12.369 μs | 7.361 μs |  0.75 | 31.2500 | 11.7188 | 549.83 KB |       14.05 |
| BuilderLatestOnly | TaLib(...)iLine [24] | 10000 | 422.09 μs |  2.559 μs | 1.338 μs |  0.70 |  3.9063 |       - |  79.73 KB |        2.04 |
