```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Candles.Harami** | **151.33 μs** |  **51.90 μs** | **34.327 μs** |  **1.04** |    **0.30** |  **68.38 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Candles.Harami |  72.09 μs |  10.22 μs |  6.757 μs |  0.50 |    0.10 |  19.91 KB |        0.29 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Candles.Harami** | **602.71 μs** | **135.97 μs** | **80.911 μs** |  **1.02** |    **0.22** |    **639 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Candles.Harami | 619.85 μs |  13.50 μs |  7.062 μs |  1.05 |    0.19 | 125.38 KB |        0.20 |
