```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib.Candles.Harami** | **1000**  |  **44.32 μs** |  **0.188 μs** |  **0.112 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Harami | 1000  | 110.57 μs |  4.234 μs |  2.801 μs |  2.49 |    0.06 |       - |       - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib.Candles.Harami | 1000  | 120.85 μs |  4.483 μs |  2.965 μs |  2.73 |    0.06 |  3.9063 |       - |  63.66 KB |       16.04 |
| BuilderLatestOnly | TaLib.Candles.Harami | 1000  | 116.21 μs |  1.975 μs |  1.033 μs |  2.62 |    0.02 |  0.9766 |       - |  15.81 KB |        3.98 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib.Candles.Harami** | **10000** | **471.34 μs** |  **3.190 μs** |  **1.668 μs** |  **1.00** |    **0.00** |       **-** |       **-** |  **39.16 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Harami | 10000 | 333.64 μs | 28.825 μs | 19.066 μs |  0.71 |    0.04 |  5.8594 |       - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib.Candles.Harami | 10000 | 389.62 μs | 18.357 μs |  9.601 μs |  0.83 |    0.02 | 31.2500 | 11.7188 | 556.22 KB |       14.21 |
| BuilderLatestOnly | TaLib.Candles.Harami | 10000 | 402.26 μs | 31.070 μs | 20.551 μs |  0.85 |    0.04 |  3.9063 |       - |  86.14 KB |        2.20 |
