```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error    | StdDev   | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |----------:|---------:|---------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib.Candles.Doji** | **1000**  |  **44.50 μs** | **0.298 μs** | **0.177 μs** |  **1.00** |    **0.01** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Doji | 1000  | 101.59 μs | 1.673 μs | 1.107 μs |  2.28 |    0.03 |       - |       - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib.Candles.Doji | 1000  |  51.34 μs | 1.066 μs | 0.558 μs |  1.15 |    0.01 |  3.4180 |  0.4883 |  57.27 KB |       14.43 |
| BuilderLatestOnly | TaLib.Candles.Doji | 1000  |  46.73 μs | 1.235 μs | 0.817 μs |  1.05 |    0.02 |  0.4883 |       - |   9.38 KB |        2.36 |
|                   |                    |       |           |          |          |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib.Candles.Doji** | **10000** | **262.29 μs** | **1.591 μs** | **0.832 μs** |  **1.00** |    **0.00** |  **1.9531** |       **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Doji | 10000 | 231.69 μs | 2.131 μs | 1.114 μs |  0.88 |    0.00 |  5.8594 |       - |   78.7 KB |        2.01 |
| BuilderFull       | TaLib.Candles.Doji | 10000 | 448.25 μs | 5.624 μs | 3.720 μs |  1.71 |    0.01 | 31.2500 | 11.7188 | 549.83 KB |       14.05 |
| BuilderLatestOnly | TaLib.Candles.Doji | 10000 | 416.93 μs | 2.495 μs | 1.305 μs |  1.59 |    0.01 |  3.9063 |       - |  79.73 KB |        2.04 |
