```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Candles.Doji** | **1000**  |  **50.42 μs** | **0.885 μs** | **0.463 μs** |  **1.9531** |       **-** |  **57.27 KB** |
| BuilderLatestOnly | TaLib.Candles.Doji | 1000  |  45.59 μs | 0.255 μs | 0.152 μs |  0.4883 |       - |   9.38 KB |
| **BuilderFull**       | **TaLib.Candles.Doji** | **10000** | **456.81 μs** | **4.600 μs** | **2.737 μs** | **31.2500** | **11.7188** | **549.83 KB** |
| BuilderLatestOnly | TaLib.Candles.Doji | 10000 | 414.21 μs | 6.517 μs | 3.409 μs |  3.9063 |       - |  79.73 KB |
