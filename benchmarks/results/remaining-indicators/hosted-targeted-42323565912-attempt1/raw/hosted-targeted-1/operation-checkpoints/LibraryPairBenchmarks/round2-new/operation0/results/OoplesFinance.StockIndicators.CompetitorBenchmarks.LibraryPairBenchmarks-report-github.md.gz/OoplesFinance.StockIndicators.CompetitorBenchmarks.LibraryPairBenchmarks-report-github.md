```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Candles.Doji** | **101.07 μs** | **11.896 μs** |  **7.079 μs** |  **1.00** |    **0.09** |  **65.33 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Candles.Doji |  31.58 μs |  1.022 μs |  0.608 μs |  0.31 |    0.02 |  19.91 KB |        0.30 |
|            |       |                    |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Candles.Doji** | **546.28 μs** | **27.577 μs** | **16.411 μs** |  **1.00** |    **0.04** | **635.66 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Candles.Doji | 295.29 μs |  2.831 μs |  1.685 μs |  0.54 |    0.02 | 124.06 KB |        0.20 |
