```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dDoji [28]** | **100.80 μs** |  **6.415 μs** |  **3.355 μs** |  **1.00** |    **0.04** |  **65.37 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dDoji [28] |  73.10 μs | 21.926 μs | 14.503 μs |  0.73 |    0.14 |   19.3 KB |        0.30 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)dDoji [28]** | **577.23 μs** | **27.802 μs** | **16.545 μs** |  **1.00** |    **0.04** |    **635 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dDoji [28] | 744.28 μs |  4.169 μs |  2.481 μs |  1.29 |    0.03 | 124.72 KB |        0.20 |
