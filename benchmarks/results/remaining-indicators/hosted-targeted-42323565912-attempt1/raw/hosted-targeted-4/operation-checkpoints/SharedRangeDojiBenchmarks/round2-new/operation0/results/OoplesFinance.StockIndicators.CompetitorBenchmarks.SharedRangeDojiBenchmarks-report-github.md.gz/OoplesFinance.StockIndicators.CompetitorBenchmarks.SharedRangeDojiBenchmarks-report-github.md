```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)dDoji [28]** | **1000**  |  **81.77 μs** |  **0.486 μs** |  **0.289 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)dDoji [28] | 1000  | 115.73 μs |  2.019 μs |  1.056 μs |  1.42 |    0.01 |       - |       - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib(...)dDoji [28] | 1000  |  65.01 μs |  1.027 μs |  0.611 μs |  0.80 |    0.01 |  3.4180 |  0.4883 |  57.27 KB |       14.43 |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 1000  |  60.07 μs |  2.405 μs |  1.431 μs |  0.73 |    0.02 |  0.4883 |       - |   9.39 KB |        2.37 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)dDoji [28]** | **10000** | **600.76 μs** | **21.974 μs** | **11.493 μs** |  **1.00** |    **0.03** |       **-** |       **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)dDoji [28] | 10000 | 402.95 μs | 12.582 μs |  6.581 μs |  0.67 |    0.02 |  3.9063 |       - |  78.72 KB |        2.01 |
| BuilderFull       | TaLib(...)dDoji [28] | 10000 | 588.92 μs |  2.512 μs |  1.495 μs |  0.98 |    0.02 | 31.2500 | 11.7188 | 549.83 KB |       14.04 |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 10000 | 552.90 μs |  7.096 μs |  4.222 μs |  0.92 |    0.02 |  3.9063 |       - |  79.73 KB |        2.04 |
