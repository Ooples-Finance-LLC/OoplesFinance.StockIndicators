```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetMfi** |   **138.9 μs** |  **5.06 μs** |  **2.65 μs** |  **1.00** |    **0.03** |   **105.6 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetMfi |   137.3 μs | 29.10 μs | 19.25 μs |  0.99 |    0.13 |  189.25 KB |        1.79 |
|            |       |                |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetMfi** |   **729.1 μs** | **16.69 μs** |  **8.73 μs** |  **1.00** |    **0.02** | **1036.94 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetMfi | 1,314.2 μs | 33.77 μs | 20.10 μs |  1.80 |    0.03 | 1815.84 KB |        1.75 |
