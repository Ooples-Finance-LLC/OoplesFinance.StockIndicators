```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetMfi** | **1000**  | **122.69 μs** | **19.511 μs** | **12.905 μs** |  **1.77** |    **0.18** |  **3.9063** |       **-** |   **65.08 KB** |        **0.42** |
| BuilderLatestOnly | Skender.GetMfi | 1000  | 110.12 μs |  3.819 μs |  2.526 μs |  1.59 |    0.05 |  0.9766 |       - |   17.48 KB |        0.11 |
| NativeSingle      | Skender.GetMfi | 1000  |  69.41 μs |  2.670 μs |  1.589 μs |  1.00 |    0.03 |  9.2773 |  1.9531 |  156.75 KB |        1.00 |
| NativeParallel    | Skender.GetMfi | 1000  | 132.66 μs |  7.061 μs |  4.670 μs |  1.91 |    0.08 |  9.7656 |  1.9531 |  165.09 KB |        1.05 |
|                   |                |       |           |           |           |       |         |         |         |            |             |
| **BuilderFull**       | **Skender.GetMfi** | **10000** | **330.77 μs** | **28.392 μs** | **16.895 μs** |  **0.43** |    **0.02** | **37.1094** | **13.6719** |  **627.95 KB** |        **0.40** |
| BuilderLatestOnly | Skender.GetMfi | 10000 | 303.08 μs | 24.359 μs | 16.112 μs |  0.40 |    0.02 |  7.8125 |  1.9531 |  158.12 KB |        0.10 |
| NativeSingle      | Skender.GetMfi | 10000 | 761.97 μs |  8.961 μs |  5.333 μs |  1.00 |    0.01 | 93.7500 | 46.8750 | 1563.03 KB |        1.00 |
| NativeParallel    | Skender.GetMfi | 10000 | 580.89 μs | 38.804 μs | 25.666 μs |  0.76 |    0.03 | 97.6563 | 46.8750 | 1571.37 KB |        1.01 |
