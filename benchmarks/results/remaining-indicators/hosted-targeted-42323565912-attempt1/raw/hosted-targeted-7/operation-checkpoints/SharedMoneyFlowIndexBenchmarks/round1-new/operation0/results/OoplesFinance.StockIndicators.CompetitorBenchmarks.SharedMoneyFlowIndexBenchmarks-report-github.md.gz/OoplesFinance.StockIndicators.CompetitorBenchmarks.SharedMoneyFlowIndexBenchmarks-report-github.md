```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetMfi** | **1000**  | **125.2 μs** | **17.47 μs** | **11.55 μs** |  **3.9063** |       **-** |  **65.08 KB** |
| BuilderLatestOnly | Skender.GetMfi | 1000  | 110.8 μs |  3.12 μs |  2.06 μs |  0.9766 |       - |  17.48 KB |
| **BuilderFull**       | **Skender.GetMfi** | **10000** | **333.9 μs** | **37.08 μs** | **24.52 μs** | **37.1094** | **13.6719** | **627.95 KB** |
| BuilderLatestOnly | Skender.GetMfi | 10000 | 309.1 μs | 22.77 μs | 15.06 μs |  7.8125 |  1.9531 | 158.12 KB |
