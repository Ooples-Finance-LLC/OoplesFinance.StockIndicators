```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetRenkoAtr** |   **502.5 μs** | **23.21 μs** | **15.35 μs** |  **1.00** |    **0.04** |  **758.04 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetRenkoAtr |   172.5 μs | 36.70 μs | 21.84 μs |  0.34 |    0.04 |  225.39 KB |        0.30 |
|            |       |                     |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetRenkoAtr** | **4,939.1 μs** | **86.36 μs** | **45.17 μs** |  **1.00** |    **0.01** | **7559.11 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetRenkoAtr | 1,681.3 μs | 30.24 μs | 17.99 μs |  0.34 |    0.00 | 2148.81 KB |        0.28 |
