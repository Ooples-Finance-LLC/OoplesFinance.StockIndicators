```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method         | Count | Operation           | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|--------------- |------ |-------------------- |-----------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **Snapshot**       | **1000**  | **Skender.GetRenkoAtr** |   **606.2 μs** | **210.20 μs** | **139.04 μs** |  **4.06** |    **0.90** |  **31.2500** |       **-** |  **752.59 KB** |        **3.61** |
| NativeSingle   | 1000  | Skender.GetRenkoAtr |   149.6 μs |  10.31 μs |   6.14 μs |  1.00 |    0.05 |   7.8125 |       - |  208.73 KB |        1.00 |
| NativeParallel | 1000  | Skender.GetRenkoAtr |   207.0 μs |  31.17 μs |  20.62 μs |  1.39 |    0.14 |  17.5781 |  3.9063 |  270.48 KB |        1.30 |
|                |       |                     |            |           |           |       |         |          |         |            |             |
| **Snapshot**       | **10000** | **Skender.GetRenkoAtr** | **5,150.9 μs** | **236.34 μs** | **156.32 μs** |  **2.93** |    **0.09** | **437.5000** |       **-** | **7522.27 KB** |        **3.62** |
| NativeSingle   | 10000 | Skender.GetRenkoAtr | 1,758.1 μs |  23.87 μs |  14.21 μs |  1.00 |    0.01 | 125.0000 | 62.5000 | 2078.58 KB |        1.00 |
| NativeParallel | 10000 | Skender.GetRenkoAtr | 2,170.7 μs | 152.23 μs | 100.69 μs |  1.23 |    0.06 | 156.2500 | 78.1250 | 2686.36 KB |        1.29 |
