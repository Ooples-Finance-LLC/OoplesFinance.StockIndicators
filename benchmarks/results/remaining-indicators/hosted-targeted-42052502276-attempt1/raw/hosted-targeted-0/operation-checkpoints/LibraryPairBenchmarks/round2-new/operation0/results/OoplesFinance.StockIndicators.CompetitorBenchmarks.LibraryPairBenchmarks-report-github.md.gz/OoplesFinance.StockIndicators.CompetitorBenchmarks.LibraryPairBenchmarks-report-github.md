```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId           | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |----------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetRenko** |   **284.18 μs** |  **8.159 μs** |  **4.855 μs** |  **1.00** |    **0.02** |  **793.49 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetRenko |    64.54 μs |  9.977 μs |  5.937 μs |  0.23 |    0.02 |   76.61 KB |        0.10 |
|            |       |                  |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetRenko** | **2,571.80 μs** | **56.718 μs** | **33.752 μs** |  **1.00** |    **0.02** | **7908.78 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetRenko |   614.14 μs | 10.812 μs |  7.152 μs |  0.24 |    0.00 |  730.72 KB |        0.09 |
