```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method   | Count | Operation        | Mean       | Error    | StdDev   | Gen0     | Gen1    | Allocated  |
|--------- |------ |----------------- |-----------:|---------:|---------:|---------:|--------:|-----------:|
| **Snapshot** | **1000**  | **Skender.GetRenko** |   **289.8 μs** |  **8.39 μs** |  **4.99 μs** |  **54.6875** |       **-** |  **938.91 KB** |
| **Snapshot** | **10000** | **Skender.GetRenko** | **3,113.2 μs** | **68.94 μs** | **41.02 μs** | **562.5000** | **78.1250** | **9384.14 KB** |
