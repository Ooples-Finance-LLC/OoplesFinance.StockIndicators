```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method   | Count | Operation        | Mean       | Error     | StdDev    | Gen0     | Gen1    | Allocated  |
|--------- |------ |----------------- |-----------:|----------:|----------:|---------:|--------:|-----------:|
| **Snapshot** | **1000**  | **Skender.GetRenko** |   **279.5 μs** |  **16.38 μs** |   **8.57 μs** |  **46.8750** |       **-** |  **781.64 KB** |
| **Snapshot** | **10000** | **Skender.GetRenko** | **2,848.6 μs** | **185.57 μs** | **110.43 μs** | **468.7500** | **62.5000** | **7813.87 KB** |
