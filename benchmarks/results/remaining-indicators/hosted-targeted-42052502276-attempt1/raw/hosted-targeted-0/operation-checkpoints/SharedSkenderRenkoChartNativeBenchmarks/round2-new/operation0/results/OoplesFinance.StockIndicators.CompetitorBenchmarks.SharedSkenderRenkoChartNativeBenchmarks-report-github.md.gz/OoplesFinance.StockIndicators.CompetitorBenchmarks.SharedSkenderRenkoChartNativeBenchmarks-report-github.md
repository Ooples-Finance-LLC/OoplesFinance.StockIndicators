```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method         | Count | Operation        | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|--------------- |------ |----------------- |------------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **Snapshot**       | **1000**  | **Skender.GetRenko** |   **281.29 μs** |  **5.419 μs** |  **3.584 μs** |  **6.34** |    **0.10** |  **46.8750** |       **-** |  **781.64 KB** |       **15.20** |
| NativeSingle   | 1000  | Skender.GetRenko |    44.35 μs |  0.835 μs |  0.437 μs |  1.00 |    0.01 |   1.9531 |       - |   51.41 KB |        1.00 |
| NativeParallel | 1000  | Skender.GetRenko |    76.47 μs |  4.988 μs |  3.299 μs |  1.72 |    0.07 |   8.7891 |  0.9766 |     130 KB |        2.53 |
|                |       |                  |             |           |           |       |         |          |         |            |             |
| **Snapshot**       | **10000** | **Skender.GetRenko** | **2,729.33 μs** | **46.989 μs** | **27.963 μs** |  **5.49** |    **0.11** | **468.7500** | **62.5000** |  **7813.9 KB** |       **15.22** |
| NativeSingle   | 10000 | Skender.GetRenko |   497.03 μs | 14.905 μs |  8.870 μs |  1.00 |    0.02 |  31.2500 |  7.8125 |  513.29 KB |        1.00 |
| NativeParallel | 10000 | Skender.GetRenko |   659.22 μs | 37.439 μs | 24.763 μs |  1.33 |    0.05 |  82.0313 | 39.0625 | 1309.53 KB |        2.55 |
