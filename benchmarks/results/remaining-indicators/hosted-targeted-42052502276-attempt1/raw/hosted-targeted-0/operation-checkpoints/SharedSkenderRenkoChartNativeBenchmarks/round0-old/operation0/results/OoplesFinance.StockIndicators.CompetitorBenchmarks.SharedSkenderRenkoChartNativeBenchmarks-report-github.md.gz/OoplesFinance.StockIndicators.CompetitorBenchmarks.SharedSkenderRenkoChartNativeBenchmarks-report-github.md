```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method   | Count | Operation        | Mean       | Error    | StdDev   | Gen0     | Gen1    | Allocated |
|--------- |------ |----------------- |-----------:|---------:|---------:|---------:|--------:|----------:|
| **Snapshot** | **1000**  | **Skender.GetRenko** |   **327.0 μs** | **11.30 μs** |  **7.47 μs** |  **54.6875** |       **-** | **938.91 KB** |
| **Snapshot** | **10000** | **Skender.GetRenko** | **3,276.2 μs** | **72.49 μs** | **43.14 μs** | **562.5000** | **93.7500** | **9384.2 KB** |
