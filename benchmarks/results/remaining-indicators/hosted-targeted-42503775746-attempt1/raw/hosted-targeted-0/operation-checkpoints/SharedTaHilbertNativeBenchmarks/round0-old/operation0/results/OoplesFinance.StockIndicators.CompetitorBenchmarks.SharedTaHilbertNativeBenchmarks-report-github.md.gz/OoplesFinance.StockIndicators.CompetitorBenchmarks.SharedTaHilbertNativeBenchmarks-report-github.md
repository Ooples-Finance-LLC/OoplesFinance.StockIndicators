```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **466.3 μs** | **107.40 μs** | **71.04 μs** |       **-** |  **68.94 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   415.1 μs |   9.84 μs |  5.15 μs |       - |  21.34 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **4,387.6 μs** |  **58.09 μs** | **34.57 μs** | **31.2500** | **631.95 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 4,463.3 μs | 123.24 μs | 64.46 μs |       - |  162.1 KB |
