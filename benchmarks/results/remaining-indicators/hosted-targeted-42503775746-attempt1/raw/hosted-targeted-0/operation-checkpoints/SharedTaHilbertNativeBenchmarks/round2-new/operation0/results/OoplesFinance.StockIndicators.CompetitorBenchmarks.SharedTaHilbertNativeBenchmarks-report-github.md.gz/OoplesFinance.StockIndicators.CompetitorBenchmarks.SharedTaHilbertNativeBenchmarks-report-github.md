```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **402.7 μs** |   **9.16 μs** |   **5.45 μs** |  **1.15** |    **0.03** |       **-** |  **68.94 KB** |        **8.24** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   401.1 μs |  13.77 μs |   8.19 μs |  1.14 |    0.03 |       - |  21.34 KB |        2.55 |
| NativeSingle      | TaLib(...)Phase [25] | 1000  |   350.8 μs |  12.03 μs |   7.96 μs |  1.00 |    0.03 |       - |   8.37 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 1000  |   520.5 μs |  34.98 μs |  20.81 μs |  1.48 |    0.06 |       - |  30.19 KB |        3.61 |
|                   |                      |       |            |           |           |       |         |         |           |             |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **4,488.3 μs** |  **90.47 μs** |  **59.84 μs** |  **1.17** |    **0.02** | **31.2500** | **631.95 KB** |        **8.01** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 4,604.9 μs | 283.87 μs | 168.93 μs |  1.20 |    0.04 |       - | 162.12 KB |        2.05 |
| NativeSingle      | TaLib(...)Phase [25] | 10000 | 3,835.2 μs |  83.24 μs |  43.53 μs |  1.00 |    0.02 |       - |  78.92 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 10000 | 5,609.5 μs | 292.07 μs | 193.19 μs |  1.46 |    0.05 |       - |  276.4 KB |        3.50 |
