```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **421.6 μs** |   **6.55 μs** |  **3.90 μs** |       **-** |  **68.94 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   422.4 μs |  10.45 μs |  5.46 μs |       - |  21.35 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **4,613.7 μs** | **105.67 μs** | **55.27 μs** | **31.2500** | **631.96 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 4,567.2 μs | 120.54 μs | 79.73 μs |       - | 162.07 KB |
