```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **619.8 μs** |  **4.10 μs** |  **2.44 μs** |  **84.83 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   616.7 μs |  4.06 μs |  2.13 μs |  37.24 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **6,680.3 μs** | **10.82 μs** |  **5.66 μs** | **788.75 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 6,711.5 μs | 46.57 μs | 24.36 μs | 318.92 KB |
