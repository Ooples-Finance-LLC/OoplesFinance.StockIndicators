```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **608.8 μs** |   **5.93 μs** |   **3.53 μs** |  **1.57** |    **0.02** |  **84.83 KB** |        **5.40** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   607.5 μs |   9.14 μs |   5.44 μs |  1.57 |    0.02 |  37.24 KB |        2.37 |
| NativeSingle      | TaLib(...)tSine [22] | 1000  |   387.9 μs |   7.23 μs |   4.30 μs |  1.00 |    0.01 |  15.72 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 1000  |   593.3 μs |  25.53 μs |  16.88 μs |  1.53 |    0.04 |  55.96 KB |        3.56 |
|                   |                      |       |            |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **6,636.9 μs** |  **89.85 μs** |  **53.47 μs** |  **1.44** |    **0.03** | **788.79 KB** |        **5.04** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 6,603.9 μs |  21.07 μs |  11.02 μs |  1.43 |    0.02 | 318.81 KB |        2.04 |
| NativeSingle      | TaLib(...)tSine [22] | 10000 | 4,616.7 μs | 136.79 μs |  81.40 μs |  1.00 |    0.02 | 156.58 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 10000 | 6,458.6 μs | 222.39 μs | 132.34 μs |  1.40 |    0.04 | 548.64 KB |        3.50 |
