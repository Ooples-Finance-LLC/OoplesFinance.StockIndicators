```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **605.8 μs** |  **4.35 μs** |  **2.27 μs** |  **84.83 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   600.7 μs | 10.11 μs |  6.02 μs |  37.24 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **6,612.5 μs** | **26.65 μs** | **13.94 μs** | **788.66 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 6,650.6 μs | 27.29 μs | 16.24 μs | 318.85 KB |
