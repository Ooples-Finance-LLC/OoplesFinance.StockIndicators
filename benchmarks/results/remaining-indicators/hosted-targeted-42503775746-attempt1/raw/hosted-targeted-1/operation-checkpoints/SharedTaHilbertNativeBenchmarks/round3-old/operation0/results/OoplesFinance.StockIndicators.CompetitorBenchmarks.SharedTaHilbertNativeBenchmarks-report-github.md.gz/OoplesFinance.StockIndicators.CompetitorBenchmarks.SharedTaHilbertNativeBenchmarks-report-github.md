```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **615.7 μs** |  **9.62 μs** |  **5.72 μs** |  **84.83 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   605.0 μs |  6.74 μs |  4.01 μs |  37.24 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **6,980.7 μs** | **89.90 μs** | **53.50 μs** |  **788.6 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 6,648.0 μs | 22.61 μs | 11.83 μs |    319 KB |
