```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tSine [22]** |   **707.2 μs** | **33.37 μs** | **19.86 μs** |  **1.00** |    **0.04** |  **166.46 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tSine [22] |   449.8 μs | 12.50 μs |  8.26 μs |  0.64 |    0.02 |   72.27 KB |        0.43 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)tSine [22]** | **6,852.5 μs** | **25.03 μs** | **16.55 μs** |  **1.00** |    **0.00** | **1594.51 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tSine [22] | 4,635.6 μs | 38.34 μs | 22.82 μs |  0.68 |    0.00 |  652.67 KB |        0.41 |
