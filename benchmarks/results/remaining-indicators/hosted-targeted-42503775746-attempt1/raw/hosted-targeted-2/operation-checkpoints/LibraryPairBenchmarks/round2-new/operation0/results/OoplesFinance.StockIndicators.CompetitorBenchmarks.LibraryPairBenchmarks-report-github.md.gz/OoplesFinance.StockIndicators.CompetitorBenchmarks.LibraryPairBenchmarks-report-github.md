```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dMode [27]** |   **818.7 μs** |  **13.77 μs** |  **8.20 μs** |  **1.00** |    **0.01** |  **112.73 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dMode [27] |   435.0 μs |  92.21 μs | 54.87 μs |  0.53 |    0.06 |   30.02 KB |        0.27 |
|            |       |                      |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)dMode [27]** | **8,741.9 μs** | **148.43 μs** | **98.18 μs** |  **1.00** |    **0.02** | **1035.91 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dMode [27] | 4,267.9 μs |  58.16 μs | 38.47 μs |  0.49 |    0.01 |  284.91 KB |        0.28 |
