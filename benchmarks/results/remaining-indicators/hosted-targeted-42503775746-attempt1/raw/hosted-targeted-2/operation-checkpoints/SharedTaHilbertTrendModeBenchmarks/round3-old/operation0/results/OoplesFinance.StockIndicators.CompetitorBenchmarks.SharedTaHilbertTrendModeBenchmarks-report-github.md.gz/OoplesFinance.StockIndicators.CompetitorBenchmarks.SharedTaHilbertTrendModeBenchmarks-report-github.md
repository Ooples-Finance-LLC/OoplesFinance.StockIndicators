```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |   **791.7 μs** |  **36.22 μs** |  **23.96 μs** |   **71.6 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |   776.6 μs |  14.14 μs |   7.40 μs |  24.01 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **8,353.3 μs** | **303.37 μs** | **200.66 μs** | **634.86 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 8,575.8 μs | 293.88 μs | 174.89 μs | 164.99 KB |
