```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |   **766.8 μs** |  **35.79 μs** |  **23.67 μs** |  **2.01** |    **0.07** | **3.9063** |   **71.6 KB** |       **15.18** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |   770.3 μs |   8.72 μs |   5.77 μs |  2.02 |    0.04 |      - |  24.03 KB |        5.09 |
| NativeSingle      | TaLib(...)dMode [27] | 1000  |   382.4 μs |  12.50 μs |   8.27 μs |  1.00 |    0.03 |      - |   4.72 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 1000  |   563.3 μs |  34.47 μs |  22.80 μs |  1.47 |    0.06 |      - |   17.4 KB |        3.69 |
|                   |                      |       |            |           |           |       |         |        |           |             |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **8,305.7 μs** | **159.37 μs** | **105.41 μs** |  **1.97** |    **0.08** |      **-** | **634.75 KB** |       **15.86** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 8,216.7 μs | 291.60 μs | 192.87 μs |  1.95 |    0.09 |      - | 164.89 KB |        4.12 |
| NativeSingle      | TaLib(...)dMode [27] | 10000 | 4,217.2 μs | 296.41 μs | 176.39 μs |  1.00 |    0.05 |      - |  40.01 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 10000 | 6,031.5 μs | 273.24 μs | 180.73 μs |  1.43 |    0.07 |      - | 140.63 KB |        3.51 |
