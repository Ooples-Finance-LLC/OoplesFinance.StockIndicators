```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |   **770.6 μs** |   **9.82 μs** |   **5.84 μs** | **3.9063** |   **71.6 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |   769.5 μs |   9.18 μs |   5.46 μs |      - |  24.03 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **8,403.7 μs** | **361.00 μs** | **238.78 μs** |      **-** | **634.47 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 8,417.5 μs | 446.62 μs | 265.77 μs |      - | 164.99 KB |
