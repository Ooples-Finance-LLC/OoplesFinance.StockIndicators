```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |   **787.7 μs** |  **12.92 μs** |  **6.76 μs** |  **71.57 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |   804.1 μs |  19.93 μs | 11.86 μs |  24.04 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **8,555.0 μs** | **187.36 μs** | **97.99 μs** | **634.85 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 8,491.8 μs |  75.12 μs | 39.29 μs | 164.91 KB |
