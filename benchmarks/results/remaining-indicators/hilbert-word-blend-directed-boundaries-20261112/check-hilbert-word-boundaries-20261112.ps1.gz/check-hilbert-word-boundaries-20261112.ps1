$ErrorActionPreference = 'Stop'
$assemblyPath = 'C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-hilbert-word-blend-20261112\src\bin\Release\net10.0\OoplesFinance.StockIndicators.dll'
if ((Get-FileHash -LiteralPath $assemblyPath).Hash.ToLowerInvariant() -ne 'f2d6ad572dc8675b29ad6b666b73f7263f1d6c5b160c05bbe0aaf2a4ce963917') { throw 'Source-bound binary mismatch' }
$assembly = [System.Reflection.Assembly]::LoadFrom($assemblyPath)
$type = $assembly.GetType('OoplesFinance.StockIndicators.Indicators.HilbertPhaseState', $true)
$method = $type.GetMethod('TryWordBlend', [System.Reflection.BindingFlags]'Static,NonPublic')
$cases = Get-Content -LiteralPath 'hilbert-word-boundary-cases-20261112.json' -Raw | ConvertFrom-Json
$passed = 0
foreach ($case in $cases) {
    $arguments = [object[]]@([double]$case.a,[double]$case.b,[double]0)
    if (-not $method.Invoke($null,$arguments)) { throw 'Directed normal boundary unexpectedly rejected' }
    $actual = [BitConverter]::DoubleToUInt64Bits([double]$arguments[2]).ToString('x16')
    if ($actual -ne $case.expected) { throw ('Rounding boundary mismatch: ' + $case.kind) }
    $passed++
}
@{ passed=$passed; source='2dc70ba934d6365beca13314c018fdf4089e3c19'; production_sha256='f2d6ad572dc8675b29ad6b666b73f7263f1d6c5b160c05bbe0aaf2a4ce963917'; independent_reference='Unfactored Python Fraction(a)*Fraction(.2)+Fraction(b)*Fraction(.8), rounded once'; rebuild=$false; performance_claim=$false } | ConvertTo-Json | Set-Content -LiteralPath 'hilbert-word-boundary-result-20261112.json'
Write-Output "$passed source-bound directed halfway/carry/sign/zero cases passed"
