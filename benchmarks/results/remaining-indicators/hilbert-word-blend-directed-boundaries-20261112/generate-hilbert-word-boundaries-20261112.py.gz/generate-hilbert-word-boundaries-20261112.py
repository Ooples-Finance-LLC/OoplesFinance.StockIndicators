import fractions
import json
import math
import struct
from pathlib import Path

cases=[]
for exponent in [-900,-500,-1,0,1,500,900]:
    for a,b,kind in [(1,-1,'halfway'),(-1,1,'negative-halfway'),(3,0,'halfway-zero-old'),
        (1,math.nextafter(1,-math.inf),'exponent-carry'),(-1,-math.nextafter(1,-math.inf),'negative-exponent-carry'),(-0.0,0,'canonical-zero')]:
        a=math.ldexp(a,exponent)
        b=math.ldexp(b,exponent)
        expected=float(fractions.Fraction(a)*fractions.Fraction(.2)+fractions.Fraction(b)*fractions.Fraction(.8))
        bits=struct.unpack('<Q',struct.pack('<d',expected if expected else 0))[0]
        cases.append(dict(a=a,b=b,kind=kind,expected=f'{bits:016x}'))
Path(__file__).with_name('hilbert-word-boundary-cases-20261112.json').write_text(json.dumps(cases,indent=2)+'\n')
print(len(cases),'independent directed cases generated')
