```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |-----------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Mfi** | **1000**  |  **44.519 μs** |  **0.6733 μs** |  **0.3521 μs** |  **4.81** |    **0.08** |  **3.9063** |       **-** |  **65.05 KB** |        **8.12** |
| BuilderLatestOnly | TaLib.Functions.Mfi | 1000  |  31.836 μs |  8.4451 μs |  5.5859 μs |  3.44 |    0.58 |  0.9766 |       - |  17.47 KB |        2.18 |
| NativeSingle      | TaLib.Functions.Mfi | 1000  |   9.248 μs |  0.2369 μs |  0.1410 μs |  1.00 |    0.02 |  0.4883 |       - |   8.01 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mfi | 1000  |   6.544 μs |  0.4927 μs |  0.3259 μs |  0.71 |    0.04 |  0.5493 |       - |   9.02 KB |        1.13 |
|                   |                     |       |            |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Mfi** | **10000** | **313.452 μs** | **28.4588 μs** | **18.8237 μs** |  **3.41** |    **0.21** | **37.1094** | **13.6719** | **627.91 KB** |        **8.02** |
| BuilderLatestOnly | TaLib.Functions.Mfi | 10000 | 282.656 μs | 45.4124 μs | 27.0242 μs |  3.07 |    0.28 |  7.8125 |  1.9531 | 158.12 KB |        2.02 |
| NativeSingle      | TaLib.Functions.Mfi | 10000 |  92.016 μs |  2.7340 μs |  1.8084 μs |  1.00 |    0.03 |  4.3945 |  0.4883 |  78.32 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mfi | 10000 |  63.615 μs |  3.6163 μs |  2.3920 μs |  0.69 |    0.03 |  4.3945 |  0.4883 |  79.34 KB |        1.01 |
