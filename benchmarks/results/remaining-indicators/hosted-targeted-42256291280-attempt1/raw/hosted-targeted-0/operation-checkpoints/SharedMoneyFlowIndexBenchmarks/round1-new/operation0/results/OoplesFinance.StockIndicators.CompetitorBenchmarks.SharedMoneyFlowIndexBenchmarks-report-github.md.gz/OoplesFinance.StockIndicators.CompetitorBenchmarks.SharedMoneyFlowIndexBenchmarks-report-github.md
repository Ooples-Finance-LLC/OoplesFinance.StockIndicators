```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |-------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mfi** | **1000**  |  **46.44 μs** |  **6.380 μs** |  **3.797 μs** |  **3.9063** |       **-** |  **65.08 KB** |
| BuilderLatestOnly | TaLib.Functions.Mfi | 1000  |  31.25 μs |  2.913 μs |  1.524 μs |  0.9766 |       - |  17.47 KB |
| **BuilderFull**       | **TaLib.Functions.Mfi** | **10000** | **383.45 μs** | **81.023 μs** | **53.592 μs** | **35.1563** | **11.7188** | **627.96 KB** |
| BuilderLatestOnly | TaLib.Functions.Mfi | 10000 | 396.16 μs | 15.136 μs |  9.007 μs |  7.8125 |       - | 158.13 KB |
