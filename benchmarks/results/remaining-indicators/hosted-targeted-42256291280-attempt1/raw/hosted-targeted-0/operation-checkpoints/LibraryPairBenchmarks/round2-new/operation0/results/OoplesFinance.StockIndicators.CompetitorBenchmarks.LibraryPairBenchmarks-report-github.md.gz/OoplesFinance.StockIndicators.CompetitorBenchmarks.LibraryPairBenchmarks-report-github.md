```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Mfi** | **112.82 μs** | **18.223 μs** | **10.844 μs** |  **1.01** |    **0.13** |  **105.57 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Mfi |  22.13 μs |  1.089 μs |  0.648 μs |  0.20 |    0.02 |   41.22 KB |        0.39 |
|            |       |                     |           |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Mfi** | **768.54 μs** | **48.302 μs** | **28.744 μs** |  **1.00** |    **0.05** | **1036.91 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Mfi | 202.65 μs | 16.805 μs | 11.115 μs |  0.26 |    0.02 |  331.26 KB |        0.32 |
