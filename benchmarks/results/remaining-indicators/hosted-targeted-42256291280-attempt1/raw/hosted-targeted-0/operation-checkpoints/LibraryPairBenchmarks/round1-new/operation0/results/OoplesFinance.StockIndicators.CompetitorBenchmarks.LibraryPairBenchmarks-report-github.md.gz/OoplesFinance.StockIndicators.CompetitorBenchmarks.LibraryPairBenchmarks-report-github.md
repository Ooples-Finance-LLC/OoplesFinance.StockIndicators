```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId              | Mean     | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |-------------------- |---------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Mfi** | **104.8 μs** |  **29.05 μs** |  **19.21 μs** |  **1.03** |    **0.24** |   **105.6 KB** |        **1.00** |
|        |       |                     |          |           |           |       |         |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Mfi** | **995.5 μs** | **394.73 μs** | **261.09 μs** |  **1.06** |    **0.38** | **1036.94 KB** |        **1.00** |
