```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId              | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |-------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Mfi** |   **184.0 μs** | **29.40 μs** | **17.50 μs** |  **1.01** |    **0.12** |   **105.6 KB** |        **1.00** |
|        |       |                     |            |          |          |       |         |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Mfi** | **1,049.3 μs** | **53.25 μs** | **31.69 μs** |  **1.00** |    **0.04** | **1036.61 KB** |        **1.00** |
