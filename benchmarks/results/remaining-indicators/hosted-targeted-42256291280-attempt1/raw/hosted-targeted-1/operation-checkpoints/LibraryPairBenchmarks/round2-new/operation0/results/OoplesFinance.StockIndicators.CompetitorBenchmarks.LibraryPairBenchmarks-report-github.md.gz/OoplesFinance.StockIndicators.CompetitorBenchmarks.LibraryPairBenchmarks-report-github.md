```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetMfi** |    **93.96 μs** |  **5.682 μs** |  **3.381 μs** |  **1.00** |    **0.05** |   **105.6 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetMfi |   130.28 μs |  5.224 μs |  3.109 μs |  1.39 |    0.06 |   189.2 KB |        1.79 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetMfi** |   **731.10 μs** | **13.038 μs** |  **7.759 μs** |  **1.00** |    **0.01** | **1036.61 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetMfi | 1,361.02 μs | 30.844 μs | 18.354 μs |  1.86 |    0.03 | 1815.23 KB |        1.75 |
