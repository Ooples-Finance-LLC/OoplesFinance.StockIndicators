```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetMfi** | **1000**  |  **44.71 μs** |  **9.908 μs** |  **5.896 μs** |  **3.9063** |       **-** |  **65.08 KB** |
| BuilderLatestOnly | Skender.GetMfi | 1000  |  29.28 μs |  3.515 μs |  2.092 μs |  0.9766 |       - |  17.47 KB |
| **BuilderFull**       | **Skender.GetMfi** | **10000** | **305.67 μs** | **46.061 μs** | **30.466 μs** | **37.1094** | **13.6719** | **627.95 KB** |
| BuilderLatestOnly | Skender.GetMfi | 10000 | 312.14 μs | 49.288 μs | 32.601 μs |  7.8125 |  1.9531 | 158.11 KB |
