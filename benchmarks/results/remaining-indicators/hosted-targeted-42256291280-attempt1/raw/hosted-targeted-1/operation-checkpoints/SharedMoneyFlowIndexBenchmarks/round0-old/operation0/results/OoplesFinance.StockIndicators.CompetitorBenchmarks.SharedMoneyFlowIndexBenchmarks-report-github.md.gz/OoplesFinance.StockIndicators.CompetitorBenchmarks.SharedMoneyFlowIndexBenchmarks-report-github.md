```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetMfi** | **1000**  |  **50.86 μs** |  **0.611 μs** |  **0.364 μs** |  **3.9063** |       **-** |  **65.12 KB** |
| BuilderLatestOnly | Skender.GetMfi | 1000  |  34.22 μs |  7.611 μs |  5.035 μs |  0.9766 |       - |  17.47 KB |
| **BuilderFull**       | **Skender.GetMfi** | **10000** | **310.83 μs** | **47.288 μs** | **31.278 μs** | **37.1094** | **13.6719** | **627.95 KB** |
| BuilderLatestOnly | Skender.GetMfi | 10000 | 286.53 μs | 51.313 μs | 33.941 μs |  7.8125 |  1.9531 | 158.12 KB |
