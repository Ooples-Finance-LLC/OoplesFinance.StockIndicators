```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetMfi** | **1000**  |  **45.41 μs** |  **0.697 μs** |  **0.415 μs** |  **0.69** |    **0.01** |  **3.9063** |       **-** |   **65.08 KB** |        **0.42** |
| BuilderLatestOnly | Skender.GetMfi | 1000  |  28.22 μs |  3.582 μs |  2.131 μs |  0.43 |    0.03 |  0.9766 |       - |   17.47 KB |        0.11 |
| NativeSingle      | Skender.GetMfi | 1000  |  66.25 μs |  0.515 μs |  0.269 μs |  1.00 |    0.01 |  9.2773 |  1.9531 |  156.75 KB |        1.00 |
| NativeParallel    | Skender.GetMfi | 1000  |  44.37 μs |  2.215 μs |  1.318 μs |  0.67 |    0.02 | 10.2539 |  2.1973 |  165.09 KB |        1.05 |
|                   |                |       |           |           |           |       |         |         |         |            |             |
| **BuilderFull**       | **Skender.GetMfi** | **10000** | **310.26 μs** | **27.288 μs** | **18.049 μs** |  **0.42** |    **0.02** | **37.1094** | **13.6719** |  **627.95 KB** |        **0.40** |
| BuilderLatestOnly | Skender.GetMfi | 10000 | 309.61 μs | 45.307 μs | 29.968 μs |  0.41 |    0.04 |  7.8125 |  1.9531 |  158.11 KB |        0.10 |
| NativeSingle      | Skender.GetMfi | 10000 | 747.50 μs | 11.847 μs |  7.050 μs |  1.00 |    0.01 | 93.7500 | 46.8750 | 1563.03 KB |        1.00 |
| NativeParallel    | Skender.GetMfi | 10000 | 514.16 μs | 40.735 μs | 26.944 μs |  0.69 |    0.03 | 97.6563 | 46.8750 | 1571.37 KB |        1.01 |
