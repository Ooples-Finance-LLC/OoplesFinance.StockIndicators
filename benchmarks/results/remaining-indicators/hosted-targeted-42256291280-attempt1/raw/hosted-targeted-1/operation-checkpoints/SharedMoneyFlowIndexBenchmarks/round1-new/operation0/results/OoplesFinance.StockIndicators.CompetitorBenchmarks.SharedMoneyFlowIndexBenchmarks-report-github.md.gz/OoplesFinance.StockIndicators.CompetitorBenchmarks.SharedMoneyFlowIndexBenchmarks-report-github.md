```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetMfi** | **1000**  |  **45.91 μs** |  **0.523 μs** |  **0.311 μs** |  **3.9063** |       **-** |  **65.08 KB** |
| BuilderLatestOnly | Skender.GetMfi | 1000  |  30.76 μs |  4.767 μs |  3.153 μs |  0.9766 |       - |  17.47 KB |
| **BuilderFull**       | **Skender.GetMfi** | **10000** | **350.11 μs** | **41.612 μs** | **21.764 μs** | **35.1563** | **11.7188** | **627.96 KB** |
| BuilderLatestOnly | Skender.GetMfi | 10000 | 289.18 μs | 47.487 μs | 31.410 μs |  7.8125 |  1.9531 | 158.12 KB |
