import hashlib
import gzip
import json
import re
import subprocess
from pathlib import Path

OPERATIONS = dict(Add='vaddsd', Subtract='vsubsd', Multiply='vmulsd', Divide='vdivsd')


def check_body(body, operation, arm):
    header = body.splitlines()[0]
    kernel = 'CloseOpenBinaryKernel' if arm == 'new' else 'BinaryKernel'
    assert header.endswith('(Tier1)') and f'+{kernel}`1[' in header
    assert f'+{operation}]]' in header
    calls = [line.strip() for line in body.splitlines() if re.search(r'\bcall\s', line)]
    selectors = [line for line in calls if ':Select(byref,int):double' in line]
    assert len(selectors) == (0 if arm == 'new' else 2)
    if arm == 'new':
        assert all('CORINFO_HELP_RNGCHKFAIL' in line or 'CORINFO_HELP_OVERFLOW' in line for line in calls)
        assert len(re.findall(r'\b' + OPERATIONS[operation] + r'\s', body)) == 1
    return len(selectors)


def validate(proof_path, record, check_tree=True):
    proof_path = Path(proof_path)
    root = proof_path.parent.resolve()
    proof = json.loads(proof_path.read_text())
    assert proof['schema'] == 1 and proof['kind'] == 'source-bound-arithmetic-selector-jit'
    assert proof['accepted'] and proof['timing_qualification'] is False
    for key in ['source', 'baseline', 'source_fingerprint', 'production_sha256']:
        assert proof[key] == record[key], key
    assert set(proof['operations']) == set(OPERATIONS)
    assert {'old-runtime-origin.json', 'new-runtime-origin.json'} <= proof['files'].keys()
    def read(name):
        path = (root / name).resolve()
        assert path.is_relative_to(root)
        return path.read_bytes() if path.is_file() else gzip.decompress(path.with_name(path.name + '.gz').read_bytes())
    for name, sha in proof['files'].items():
        assert hashlib.sha256(read(name)).hexdigest() == sha, name
    for operation, item in proof['operations'].items():
        for arm in ['old', 'new']:
            name = item[arm + '_asm']
            assert name in proof['files']
            check_body(read(name).decode(), operation, arm)
    old = json.loads(read('old-runtime-origin.json'))
    new = json.loads(read('new-runtime-origin.json'))
    assert old['published_source'] == record['baseline']
    assert new['compiled_source'] == record['source']
    assert new['production_sha256'] == record['production_sha256']
    assert new['source_fingerprint'] == record['source_fingerprint']
    if check_tree:
        assert not subprocess.check_output(['git', 'diff', old['compiled_source'], record['baseline'],
                                            '--', 'src', 'tests'], cwd=record['repo'])
        assert not subprocess.check_output(['git', 'diff', record['source'], record['qualified_source'],
                                            '--', 'src', 'tests'], cwd=record['repo'])
    return proof
