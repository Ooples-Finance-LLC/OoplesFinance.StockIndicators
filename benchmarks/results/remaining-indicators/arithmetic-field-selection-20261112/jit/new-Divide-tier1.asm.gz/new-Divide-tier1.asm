; Assembly listing for method OoplesFinance.StockIndicators.Indicators.ValuesBarExecution:ComputePointwiseRegion[OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+CloseOpenBinaryKernel`1[OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+Divide]](System.ReadOnlySpan`1[OoplesFinance.StockIndicators.Indicators.Bar],System.Span`1[double],ulong[],OoplesFinance.StockIndicators.Indicators.OwnedBarBuffer,int,OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+CloseOpenBinaryKernel`1[OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+Divide],System.Threading.CancellationToken):OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+PointwiseRegion (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 18
; 4 inlinees with PGO data; 17 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 168
       vmovaps  xmmword ptr [rsp+0x90], xmm6
       vmovaps  xmmword ptr [rsp+0x80], xmm7
       vmovaps  xmmword ptr [rsp+0x70], xmm8
       vmovaps  xmmword ptr [rsp+0x60], xmm9
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x30], ymm4
       vmovdqa  xmmword ptr [rsp+0x50], xmm4
       mov      rax, gword ptr [rsp+0x110]
       mov      r10d, dword ptr [rsp+0x118]
       mov      r11, gword ptr [rsp+0x128]
 
G_M000_IG02:
       mov      rbx, bword ptr [rdx]
       mov      edx, dword ptr [rdx+0x08]
       xor      esi, esi
       mov      dword ptr [rsp+0x2C], esi
       mov      edi, -1
       vxorps   xmm0, xmm0, xmm0
       xor      ebp, ebp
       vxorps   xmm1, xmm1, xmm1
       vxorps   xmm2, xmm2, xmm2
       vxorps   xmm3, xmm3, xmm3
       vxorps   xmm4, xmm4, xmm4
       vxorps   xmm5, xmm5, xmm5
       xor      r14d, r14d
       cmp      r14d, edx
       jl       G_M000_IG08
       jmp      G_M000_IG16
       align    [0 bytes for IG03]
 
G_M000_IG03:
       test     rax, rax
       je       SHORT G_M000_IG06
 
G_M000_IG04:
       mov      r13d, r10d
       add      r13d, r14d
       jo       G_M000_IG22
       cmp      gword ptr [rax+0x10], 0
       jne      G_M000_IG20
       mov      r12, gword ptr [rax+0x08]
       mov      esi, r13d
       sar      esi, 10
       cmp      esi, dword ptr [r12+0x08]
       jae      G_M000_IG21
       mov      rsi, gword ptr [r12+8*rsi+0x10]
       and      r13d, 0x3FF
       cmp      r13d, dword ptr [rsi+0x08]
       jae      G_M000_IG21
       imul     r13, r13, 48
       lea      rsi, bword ptr [rsi+r13+0x10]
 
G_M000_IG05:
       vmovsd   qword ptr [rsi+0x08], xmm1
       vmovsd   qword ptr [rsi+0x10], xmm2
       vmovsd   qword ptr [rsi+0x18], xmm3
       vmovsd   qword ptr [rsi+0x20], xmm4
       vmovsd   qword ptr [rsi+0x28], xmm5
       mov      qword ptr [rsi], r15
 
G_M000_IG06:
       vmovq    r15, xmm6
       mov      r13, 0xD1FFAB1E
       andn     r15, r15, r13
       je       G_M000_IG13
 
G_M000_IG07:
       add      r14d, 1
       jo       G_M000_IG22
       cmp      r14d, edx
       jge      G_M000_IG16
 
G_M000_IG08:
       test     r11, r11
       jne      G_M000_IG18
 
G_M000_IG09:
       imul     r15, r14, 48
       add      r15, rbx
       vmovsd   xmm1, qword ptr [r15+0x08]
       vmovsd   xmm2, qword ptr [r15+0x10]
       vmovsd   xmm3, qword ptr [r15+0x18]
       vmovsd   xmm4, qword ptr [r15+0x20]
       vmovsd   xmm5, qword ptr [r15+0x28]
       mov      r15, qword ptr [r15]
       mov      qword ptr [rsp+0x30], r15
       vbroadcastsd ymm6, qword ptr [reloc @RWD00]
       vmovaps  xmm7, xmm1
       vmovaps  xmm8, xmm2
       vunpcklpd xmm7, xmm7, xmm8
       vmovaps  xmm8, xmm3
       vmovaps  xmm9, xmm4
       vunpcklpd xmm8, xmm8, xmm9
       vinsertf128 ymm7, ymm7, xmm8
       vpand    ymm7, ymm7, ymm6
       vpcmpeqq ymm6, ymm7, ymm6
       vptest   ymm6, ymm6
       jne      G_M000_IG15
       vmovq    r13, xmm5
       mov      r12, 0xD1FFAB1E
       andn     r13, r13, r12
       je       G_M000_IG15
 
G_M000_IG10:
       vandps   xmm6, xmm1, xmmword ptr [reloc @RWD16]
       vxorps   xmm7, xmm7, xmm7
       vucomisd xmm6, xmm7
       seta     r13b
       movzx    r13, r13b
       test     r13d, r13d
       je       G_M000_IG19
       vdivsd   xmm6, xmm4, xmm1
 
G_M000_IG11:
       cmp      r14d, dword ptr [r8+0x08]
       jae      G_M000_IG21
       mov      r12, bword ptr [r8]
       vmovsd   qword ptr [r12+8*r14], xmm6
       test     r13d, r13d
       jne      G_M000_IG03
 
G_M000_IG12:
       mov      ebp, r10d
       add      ebp, r14d
       jo       G_M000_IG22
       mov      r13d, ebp
       sar      r13d, 6
       cmp      r13d, dword ptr [r9+0x08]
       jae      G_M000_IG21
       lea      r13, bword ptr [r9+8*r13+0x10]
       mov      r12d, 1
       shlx     rbp, r12, rbp
       or       qword ptr [r13], rbp
       mov      ebp, 1
       jmp      G_M000_IG03
 
G_M000_IG13:
       test     edi, edi
       jge      G_M000_IG07
 
G_M000_IG14:
       mov      edi, r10d
       add      edi, r14d
       jo       G_M000_IG22
       vmovaps  xmm0, xmm6
       jmp      G_M000_IG07
 
G_M000_IG15:
       mov      esi, 1
       mov      dword ptr [rsp+0x2C], esi
 
G_M000_IG16:
       mov      rax, qword ptr [rsp+0x30]
       vmovsd   qword ptr [rcx+0x08], xmm1
       vmovsd   qword ptr [rcx+0x10], xmm2
       vmovsd   qword ptr [rcx+0x18], xmm3
       vmovsd   qword ptr [rcx+0x20], xmm4
       vmovsd   qword ptr [rcx+0x28], xmm5
       mov      esi, dword ptr [rsp+0x2C]
       mov      byte  ptr [rcx+0x30], sil
       mov      dword ptr [rcx+0x34], edi
       vmovsd   qword ptr [rcx+0x38], xmm0
       mov      byte  ptr [rcx+0x40], bpl
       mov      qword ptr [rcx], rax
       mov      rax, rcx
 
G_M000_IG17:
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x90]
       vmovaps  xmm7, xmmword ptr [rsp+0x80]
       vmovaps  xmm8, xmmword ptr [rsp+0x70]
       vmovaps  xmm9, xmmword ptr [rsp+0x60]
       add      rsp, 168
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG18:
       cmp      dword ptr [r11+0x20], 0
       jne      SHORT G_M000_IG16
       jmp      G_M000_IG09
 
G_M000_IG19:
       vxorps   xmm6, xmm6, xmm6
       jmp      G_M000_IG11
 
G_M000_IG20:
       mov      r12, gword ptr [rax+0x10]
       cmp      r13d, dword ptr [r12+0x08]
       jae      SHORT G_M000_IG21
       mov      r13d, r13d
       imul     r13, r13, 48
       lea      r13, bword ptr [r12+r13+0x10]
       mov      rsi, r13
       jmp      G_M000_IG05
 
G_M000_IG21:
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG22:
       call     CORINFO_HELP_OVERFLOW
       int3     
 
RWD00  	dq	7FF0000000000000h
RWD08  	dd	00000000h, 00000000h
RWD16  	dq	7FFFFFFFFFFFFFFFh, 7FFFFFFFFFFFFFFFh

; Total bytes of code 778

