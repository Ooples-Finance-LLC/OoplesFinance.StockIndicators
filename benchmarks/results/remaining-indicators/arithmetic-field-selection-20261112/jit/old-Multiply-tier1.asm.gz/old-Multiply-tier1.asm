; Assembly listing for method OoplesFinance.StockIndicators.Indicators.ValuesBarExecution:ComputePointwiseRegion[OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+BinaryKernel`1[OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+Multiply]](System.ReadOnlySpan`1[OoplesFinance.StockIndicators.Indicators.Bar],System.Span`1[double],ulong[],OoplesFinance.StockIndicators.Indicators.OwnedBarBuffer,int,OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+BinaryKernel`1[OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+Multiply],System.Threading.CancellationToken):OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+PointwiseRegion (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 18
; 4 inlinees with PGO data; 14 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 216
       vmovaps  xmmword ptr [rsp+0xC0], xmm6
       vmovaps  xmmword ptr [rsp+0xB0], xmm7
       xor      eax, eax
       mov      qword ptr [rsp+0x38], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x40], ymm4
       mov      qword ptr [rsp+0x60], rax
       mov      r14, rcx
       mov      rbx, r8
       mov      rsi, gword ptr [rsp+0x140]
       mov      ebp, dword ptr [rsp+0x148]
       mov      rdi, gword ptr [rsp+0x158]
 
G_M000_IG02:
       mov      r15, bword ptr [rdx]
       mov      r13d, dword ptr [rdx+0x08]
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rsp+0x68], ymm0
       vmovdqu  ymmword ptr [rsp+0x88], ymm0
       vmovdqu  xmmword ptr [rsp+0xA0], xmm0
       xor      r12d, r12d
       mov      dword ptr [rsp+0x2C], -1
       vxorps   xmm6, xmm6, xmm6
       mov      r8d, dword ptr [rsp+0x150]
       mov      dword ptr [rsp+0x34], r8d
       mov      r10d, dword ptr [rsp+0x154]
       mov      dword ptr [rsp+0x30], r10d
       xor      r9d, r9d
       cmp      r9d, r13d
       jl       SHORT G_M000_IG04
       jmp      G_M000_IG13
 
G_M000_IG03:
       add      eax, 1
       jo       G_M000_IG18
       cmp      eax, r13d
       mov      r9, rax
       mov      r8d, dword ptr [rsp+0x34]
       jge      G_M000_IG13
 
G_M000_IG04:
       test     rdi, rdi
       jne      G_M000_IG15
 
G_M000_IG05:
       mov      qword ptr [rsp+0x20], r9
       imul     rcx, r9, 48
       vmovdqu  ymm0, ymmword ptr [r15+rcx]
       vmovdqu  ymmword ptr [rsp+0x38], ymm0
       vmovdqu  xmm0, xmmword ptr [r15+rcx+0x20]
       vmovdqu  xmmword ptr [rsp+0x58], xmm0
       vmovsd   xmm0, qword ptr [rsp+0x40]
       vmovsd   xmm1, qword ptr [rsp+0x48]
       vmovsd   xmm2, qword ptr [rsp+0x50]
       vbroadcastsd ymm3, qword ptr [reloc @RWD00]
       vunpcklpd xmm0, xmm0, xmm1
       vmovsd   xmm1, qword ptr [rsp+0x58]
       vunpcklpd xmm1, xmm2, xmm1
       vinsertf128 ymm0, ymm0, xmm1
       vpand    ymm0, ymm0, ymm3
       vpcmpeqq ymm0, ymm0, ymm3
       vptest   ymm0, ymm0
       jne      G_M000_IG12
       mov      rcx, qword ptr [rsp+0x60]
       mov      rdx, 0xD1FFAB1E
       andn     rcx, rcx, rdx
       je       G_M000_IG12
 
G_M000_IG06:
       lea      rcx, [rsp+0x38]
       mov      edx, r8d
       call     [OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+BinaryKernel`1[OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+Multiply]:Select(byref,int):double]
       vmovaps  xmm7, xmm0
       lea      rcx, [rsp+0x38]
       mov      edx, dword ptr [rsp+0x30]
       call     [OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+BinaryKernel`1[OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+Multiply]:Select(byref,int):double]
       vmulsd   xmm0, xmm7, xmm0
       mov      rax, qword ptr [rsp+0x20]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG17
       mov      rcx, bword ptr [rbx]
       vmovsd   qword ptr [rcx+8*rax], xmm0
       test     rsi, rsi
       je       SHORT G_M000_IG09
 
G_M000_IG07:
       mov      ecx, ebp
       add      ecx, eax
       jo       G_M000_IG18
       cmp      gword ptr [rsi+0x10], 0
       jne      G_M000_IG16
       mov      rdx, gword ptr [rsi+0x08]
       mov      r8d, ecx
       sar      r8d, 10
       cmp      r8d, dword ptr [rdx+0x08]
       jae      G_M000_IG17
       mov      rdx, gword ptr [rdx+8*r8+0x10]
       and      ecx, 0x3FF
       cmp      ecx, dword ptr [rdx+0x08]
       jae      G_M000_IG17
       imul     rcx, rcx, 48
       lea      rcx, bword ptr [rdx+rcx+0x10]
 
G_M000_IG08:
       vmovdqu  ymm1, ymmword ptr [rsp+0x38]
       vmovdqu  ymmword ptr [rcx], ymm1
       vmovdqu  xmm1, xmmword ptr [rsp+0x58]
       vmovdqu  xmmword ptr [rcx+0x20], xmm1
 
G_M000_IG09:
       vmovq    rcx, xmm0
       mov      rdx, 0xD1FFAB1E
       andn     rcx, rcx, rdx
       jne      G_M000_IG03
 
G_M000_IG10:
       mov      ecx, dword ptr [rsp+0x2C]
       test     ecx, ecx
       mov      dword ptr [rsp+0x2C], ecx
       jge      G_M000_IG03
 
G_M000_IG11:
       mov      ecx, ebp
       add      ecx, eax
       jo       G_M000_IG18
       vmovaps  xmm6, xmm0
       mov      dword ptr [rsp+0x2C], ecx
       jmp      G_M000_IG03
 
G_M000_IG12:
       mov      r12d, 1
 
G_M000_IG13:
       vmovdqu  ymm0, ymmword ptr [rsp+0x38]
       vmovdqu  ymmword ptr [rsp+0x68], ymm0
       vmovdqu  xmm0, xmmword ptr [rsp+0x58]
       vmovdqu  xmmword ptr [rsp+0x88], xmm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x68]
       vmovdqu  ymmword ptr [r14], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x88]
       vmovdqu  ymmword ptr [r14+0x20], ymm0
       mov      rax, qword ptr [rsp+0xA8]
       mov      qword ptr [r14+0x40], rax
       mov      byte  ptr [r14+0x30], r12b
       mov      ecx, dword ptr [rsp+0x2C]
       mov      dword ptr [r14+0x34], ecx
       vmovsd   qword ptr [r14+0x38], xmm6
       mov      rax, r14
 
G_M000_IG14:
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0xC0]
       vmovaps  xmm7, xmmword ptr [rsp+0xB0]
       add      rsp, 216
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG15:
       cmp      dword ptr [rdi+0x20], 0
       jne      G_M000_IG13
       jmp      G_M000_IG05
 
G_M000_IG16:
       mov      rdx, gword ptr [rsi+0x10]
       cmp      ecx, dword ptr [rdx+0x08]
       jae      SHORT G_M000_IG17
       mov      ecx, ecx
       imul     rcx, rcx, 48
       lea      rcx, bword ptr [rdx+rcx+0x10]
       jmp      G_M000_IG08
 
G_M000_IG17:
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG18:
       call     CORINFO_HELP_OVERFLOW
       int3     
 
RWD00  	dq	7FF0000000000000h

; Total bytes of code 745

