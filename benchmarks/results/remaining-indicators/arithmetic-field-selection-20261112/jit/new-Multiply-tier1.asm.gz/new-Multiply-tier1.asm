; Assembly listing for method OoplesFinance.StockIndicators.Indicators.ValuesBarExecution:ComputePointwiseRegion[OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+CloseOpenBinaryKernel`1[OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+Multiply]](System.ReadOnlySpan`1[OoplesFinance.StockIndicators.Indicators.Bar],System.Span`1[double],ulong[],OoplesFinance.StockIndicators.Indicators.OwnedBarBuffer,int,OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+CloseOpenBinaryKernel`1[OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+Multiply],System.Threading.CancellationToken):OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+PointwiseRegion (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 18
; 4 inlinees with PGO data; 17 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 224
       vmovaps  xmmword ptr [rsp+0xD0], xmm6
       vmovaps  xmmword ptr [rsp+0xC0], xmm7
       vmovaps  xmmword ptr [rsp+0xB0], xmm8
       vmovaps  xmmword ptr [rsp+0xA0], xmm9
       xor      eax, eax
       mov      qword ptr [rsp+0x28], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x30], ymm4
       mov      qword ptr [rsp+0x50], rax
       mov      rax, gword ptr [rsp+0x140]
       mov      r9d, dword ptr [rsp+0x148]
       mov      r10, gword ptr [rsp+0x158]
 
G_M000_IG02:
       mov      r11, bword ptr [rdx]
       mov      edx, dword ptr [rdx+0x08]
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rsp+0x58], ymm0
       vmovdqu  ymmword ptr [rsp+0x78], ymm0
       vmovdqu  xmmword ptr [rsp+0x90], xmm0
       xor      ebx, ebx
       mov      esi, -1
       vxorps   xmm0, xmm0, xmm0
       vxorps   xmm1, xmm1, xmm1
       vxorps   xmm2, xmm2, xmm2
       vxorps   xmm3, xmm3, xmm3
       vxorps   xmm4, xmm4, xmm4
       vxorps   xmm5, xmm5, xmm5
       xor      edi, edi
       cmp      edi, edx
       jl       SHORT G_M000_IG04
       jmp      G_M000_IG13
       align    [0 bytes for IG03]
 
G_M000_IG03:
       add      edi, 1
       jo       G_M000_IG18
       cmp      edi, edx
       jge      G_M000_IG13
 
G_M000_IG04:
       test     r10, r10
       jne      G_M000_IG15
 
G_M000_IG05:
       imul     rbp, rdi, 48
       add      rbp, r11
       vmovsd   xmm1, qword ptr [rbp+0x08]
       vmovsd   xmm2, qword ptr [rbp+0x10]
       vmovsd   xmm3, qword ptr [rbp+0x18]
       vmovsd   xmm4, qword ptr [rbp+0x20]
       vmovsd   xmm5, qword ptr [rbp+0x28]
       mov      rbp, qword ptr [rbp]
       mov      qword ptr [rsp+0x28], rbp
       vbroadcastsd ymm6, qword ptr [reloc @RWD00]
       vmovaps  xmm7, xmm1
       vmovaps  xmm8, xmm2
       vunpcklpd xmm7, xmm7, xmm8
       vmovaps  xmm8, xmm3
       vmovaps  xmm9, xmm4
       vunpcklpd xmm8, xmm8, xmm9
       vinsertf128 ymm7, ymm7, xmm8
       vpand    ymm7, ymm7, ymm6
       vpcmpeqq ymm6, ymm7, ymm6
       vptest   ymm6, ymm6
       jne      G_M000_IG12
       vmovq    r14, xmm5
       mov      r15, 0xD1FFAB1E
       andn     r14, r14, r15
       je       G_M000_IG12
 
G_M000_IG06:
       vmulsd   xmm6, xmm4, xmm1
       cmp      edi, dword ptr [r8+0x08]
       jae      G_M000_IG17
       mov      r14, bword ptr [r8]
       vmovsd   qword ptr [r14+8*rdi], xmm6
       test     rax, rax
       je       SHORT G_M000_IG09
 
G_M000_IG07:
       mov      r14d, r9d
       add      r14d, edi
       jo       G_M000_IG18
       cmp      gword ptr [rax+0x10], 0
       jne      G_M000_IG16
       mov      r15, gword ptr [rax+0x08]
       mov      r13d, r14d
       sar      r13d, 10
       cmp      r13d, dword ptr [r15+0x08]
       jae      G_M000_IG17
       mov      r15, gword ptr [r15+8*r13+0x10]
       and      r14d, 0x3FF
       cmp      r14d, dword ptr [r15+0x08]
       jae      G_M000_IG17
       imul     r14, r14, 48
       lea      r14, bword ptr [r15+r14+0x10]
 
G_M000_IG08:
       vmovsd   qword ptr [r14+0x08], xmm1
       vmovsd   qword ptr [r14+0x10], xmm2
       vmovsd   qword ptr [r14+0x18], xmm3
       vmovsd   qword ptr [r14+0x20], xmm4
       vmovsd   qword ptr [r14+0x28], xmm5
       mov      qword ptr [r14], rbp
 
G_M000_IG09:
       vmovq    rbp, xmm6
       mov      r14, 0xD1FFAB1E
       andn     rbp, rbp, r14
       jne      G_M000_IG03
 
G_M000_IG10:
       test     esi, esi
       jge      G_M000_IG03
 
G_M000_IG11:
       mov      esi, r9d
       add      esi, edi
       jo       G_M000_IG18
       vmovaps  xmm0, xmm6
       jmp      G_M000_IG03
 
G_M000_IG12:
       mov      ebx, 1
 
G_M000_IG13:
       mov      rax, qword ptr [rsp+0x28]
       mov      qword ptr [rsp+0x58], rax
       vmovdqu  ymm6, ymmword ptr [rsp+0x58]
       vmovdqu  ymmword ptr [rcx], ymm6
       vmovdqu  ymm6, ymmword ptr [rsp+0x78]
       vmovdqu  ymmword ptr [rcx+0x20], ymm6
       mov      rax, qword ptr [rsp+0x98]
       mov      qword ptr [rcx+0x40], rax
       vmovsd   qword ptr [rcx+0x08], xmm1
       vmovsd   qword ptr [rcx+0x10], xmm2
       vmovsd   qword ptr [rcx+0x18], xmm3
       vmovsd   qword ptr [rcx+0x20], xmm4
       vmovsd   qword ptr [rcx+0x28], xmm5
       mov      byte  ptr [rcx+0x30], bl
       mov      dword ptr [rcx+0x34], esi
       vmovsd   qword ptr [rcx+0x38], xmm0
       mov      rax, rcx
 
G_M000_IG14:
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0xD0]
       vmovaps  xmm7, xmmword ptr [rsp+0xC0]
       vmovaps  xmm8, xmmword ptr [rsp+0xB0]
       vmovaps  xmm9, xmmword ptr [rsp+0xA0]
       add      rsp, 224
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG15:
       cmp      dword ptr [r10+0x20], 0
       jne      G_M000_IG13
       jmp      G_M000_IG05
 
G_M000_IG16:
       mov      r15, gword ptr [rax+0x10]
       cmp      r14d, dword ptr [r15+0x08]
       jae      SHORT G_M000_IG17
       mov      r14d, r14d
       imul     r14, r14, 48
       lea      r14, bword ptr [r15+r14+0x10]
       jmp      G_M000_IG08
 
G_M000_IG17:
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG18:
       call     CORINFO_HELP_OVERFLOW
       int3     
 
RWD00  	dq	7FF0000000000000h

; Total bytes of code 715

