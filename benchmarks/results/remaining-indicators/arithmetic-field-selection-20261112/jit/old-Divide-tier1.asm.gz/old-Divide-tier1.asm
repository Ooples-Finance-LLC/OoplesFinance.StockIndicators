; Assembly listing for method OoplesFinance.StockIndicators.Indicators.ValuesBarExecution:ComputePointwiseRegion[OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+BinaryKernel`1[OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+Divide]](System.ReadOnlySpan`1[OoplesFinance.StockIndicators.Indicators.Bar],System.Span`1[double],ulong[],OoplesFinance.StockIndicators.Indicators.OwnedBarBuffer,int,OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+BinaryKernel`1[OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+Divide],System.Threading.CancellationToken):OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+PointwiseRegion (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 18
; 4 inlinees with PGO data; 14 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 232
       vmovaps  xmmword ptr [rsp+0xD0], xmm6
       vmovaps  xmmword ptr [rsp+0xC0], xmm7
       xor      eax, eax
       mov      qword ptr [rsp+0x48], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x50], ymm4
       vmovdqu  ymmword ptr [rsp+0x70], ymm4
       vmovdqu  ymmword ptr [rsp+0x90], ymm4
       vmovdqa  xmmword ptr [rsp+0xB0], xmm4
       mov      r14, rcx
       mov      rbx, r8
       mov      r15, r9
       mov      rsi, gword ptr [rsp+0x150]
       mov      ebp, dword ptr [rsp+0x158]
       mov      rdi, gword ptr [rsp+0x168]
 
G_M000_IG02:
       mov      r13, bword ptr [rdx]
       mov      r12d, dword ptr [rdx+0x08]
       xor      eax, eax
       mov      dword ptr [rsp+0x3C], eax
       mov      dword ptr [rsp+0x38], -1
       vxorps   xmm6, xmm6, xmm6
       xor      r10d, r10d
       mov      dword ptr [rsp+0x34], r10d
       mov      r9d, dword ptr [rsp+0x160]
       mov      dword ptr [rsp+0x44], r9d
       mov      r11d, dword ptr [rsp+0x164]
       mov      dword ptr [rsp+0x40], r11d
       xor      edx, edx
       cmp      edx, r12d
       jl       G_M000_IG08
       jmp      G_M000_IG16
 
G_M000_IG03:
       test     rsi, rsi
       je       SHORT G_M000_IG06
 
G_M000_IG04:
       mov      ecx, ebp
       add      ecx, edx
       jo       G_M000_IG22
       cmp      gword ptr [rsi+0x10], 0
       jne      G_M000_IG20
       mov      r8, gword ptr [rsi+0x08]
       mov      r10d, ecx
       sar      r10d, 10
       cmp      r10d, dword ptr [r8+0x08]
       jae      G_M000_IG21
       mov      r8, gword ptr [r8+8*r10+0x10]
       and      ecx, 0x3FF
       cmp      ecx, dword ptr [r8+0x08]
       jae      G_M000_IG21
       imul     rcx, rcx, 48
       lea      rcx, bword ptr [r8+rcx+0x10]
 
G_M000_IG05:
       vmovdqu  ymm1, ymmword ptr [rsp+0x48]
       vmovdqu  ymmword ptr [rcx], ymm1
       vmovdqu  xmm1, xmmword ptr [rsp+0x68]
       vmovdqu  xmmword ptr [rcx+0x20], xmm1
 
G_M000_IG06:
       vmovq    rcx, xmm0
       mov      r8, 0xD1FFAB1E
       andn     rcx, rcx, r8
       je       G_M000_IG13
 
G_M000_IG07:
       add      edx, 1
       jo       G_M000_IG22
       cmp      edx, r12d
       mov      r9d, dword ptr [rsp+0x44]
       jge      G_M000_IG16
 
G_M000_IG08:
       test     rdi, rdi
       jne      G_M000_IG18
 
G_M000_IG09:
       mov      qword ptr [rsp+0x28], rdx
       imul     rcx, rdx, 48
       vmovdqu  ymm0, ymmword ptr [rcx+r13]
       vmovdqu  ymmword ptr [rsp+0x48], ymm0
       vmovdqu  xmm0, xmmword ptr [r13+rcx+0x20]
       vmovdqu  xmmword ptr [rsp+0x68], xmm0
       vmovsd   xmm0, qword ptr [rsp+0x50]
       vmovsd   xmm1, qword ptr [rsp+0x58]
       vmovsd   xmm2, qword ptr [rsp+0x60]
       vbroadcastsd ymm3, qword ptr [reloc @RWD00]
       vunpcklpd xmm0, xmm0, xmm1
       vmovsd   xmm1, qword ptr [rsp+0x68]
       vunpcklpd xmm1, xmm2, xmm1
       vinsertf128 ymm0, ymm0, xmm1
       vpand    ymm0, ymm0, ymm3
       vpcmpeqq ymm0, ymm0, ymm3
       vptest   ymm0, ymm0
       jne      G_M000_IG15
       mov      rcx, qword ptr [rsp+0x70]
       mov      rax, 0xD1FFAB1E
       andn     rcx, rcx, rax
       je       G_M000_IG15
 
G_M000_IG10:
       lea      rcx, [rsp+0x48]
       mov      edx, r9d
       call     [OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+BinaryKernel`1[OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+Divide]:Select(byref,int):double]
       vmovaps  xmm7, xmm0
       lea      rcx, [rsp+0x48]
       mov      edx, dword ptr [rsp+0x40]
       call     [OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+BinaryKernel`1[OoplesFinance.StockIndicators.Indicators.ValuesBarExecution+Divide]:Select(byref,int):double]
       vandps   xmm1, xmm0, xmmword ptr [reloc @RWD16]
       vxorps   xmm2, xmm2, xmm2
       vucomisd xmm1, xmm2
       seta     al
       movzx    rax, al
       test     eax, eax
       je       G_M000_IG19
       vdivsd   xmm0, xmm7, xmm0
 
G_M000_IG11:
       mov      rdx, qword ptr [rsp+0x28]
       cmp      edx, dword ptr [rbx+0x08]
       jae      G_M000_IG21
       mov      rcx, bword ptr [rbx]
       vmovsd   qword ptr [rcx+8*rdx], xmm0
       test     eax, eax
       jne      G_M000_IG03
 
G_M000_IG12:
       mov      eax, ebp
       add      eax, edx
       jo       G_M000_IG22
       mov      ecx, eax
       sar      ecx, 6
       cmp      ecx, dword ptr [r15+0x08]
       jae      G_M000_IG21
       lea      rcx, bword ptr [r15+8*rcx+0x10]
       mov      r8d, 1
       shlx     rax, r8, rax
       or       qword ptr [rcx], rax
       mov      eax, 1
       mov      dword ptr [rsp+0x34], eax
       jmp      G_M000_IG03
 
G_M000_IG13:
       mov      r8d, dword ptr [rsp+0x38]
       test     r8d, r8d
       mov      dword ptr [rsp+0x38], r8d
       jge      G_M000_IG07
 
G_M000_IG14:
       mov      r8d, ebp
       add      r8d, edx
       jo       G_M000_IG22
       vmovaps  xmm6, xmm0
       mov      dword ptr [rsp+0x38], r8d
       jmp      G_M000_IG07
 
G_M000_IG15:
       mov      ebx, 1
       mov      dword ptr [rsp+0x3C], ebx
 
G_M000_IG16:
       vmovdqu  ymm0, ymmword ptr [rsp+0x48]
       vmovdqu  ymmword ptr [rsp+0x78], ymm0
       vmovdqu  xmm0, xmmword ptr [rsp+0x68]
       vmovdqu  xmmword ptr [rsp+0x98], xmm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x78]
       vmovdqu  ymmword ptr [r14], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x98]
       vmovdqu  ymmword ptr [r14+0x20], ymm0
       mov      rcx, qword ptr [rsp+0xB8]
       mov      qword ptr [r14+0x40], rcx
       mov      ebx, dword ptr [rsp+0x3C]
       mov      byte  ptr [r14+0x30], bl
       mov      r8d, dword ptr [rsp+0x38]
       mov      dword ptr [r14+0x34], r8d
       vmovsd   qword ptr [r14+0x38], xmm6
       mov      eax, dword ptr [rsp+0x34]
       mov      byte  ptr [r14+0x40], al
       mov      rax, r14
 
G_M000_IG17:
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0xD0]
       vmovaps  xmm7, xmmword ptr [rsp+0xC0]
       add      rsp, 232
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG18:
       cmp      dword ptr [rdi+0x20], 0
       jne      G_M000_IG16
       jmp      G_M000_IG09
 
G_M000_IG19:
       vxorps   xmm0, xmm0, xmm0
       jmp      G_M000_IG11
 
G_M000_IG20:
       mov      r8, gword ptr [rsi+0x10]
       cmp      ecx, dword ptr [r8+0x08]
       jae      SHORT G_M000_IG21
       mov      ecx, ecx
       imul     rcx, rcx, 48
       lea      rcx, bword ptr [r8+rcx+0x10]
       jmp      G_M000_IG05
 
G_M000_IG21:
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG22:
       call     CORINFO_HELP_OVERFLOW
       int3     
 
RWD00  	dq	7FF0000000000000h
RWD08  	dd	00000000h, 00000000h
RWD16  	dq	7FFFFFFFFFFFFFFFh, 7FFFFFFFFFFFFFFFh

; Total bytes of code 879

