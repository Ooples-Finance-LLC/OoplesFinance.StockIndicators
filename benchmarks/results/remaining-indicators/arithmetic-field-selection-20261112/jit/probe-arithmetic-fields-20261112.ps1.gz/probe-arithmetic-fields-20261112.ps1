param([Parameter(Mandatory=$true)][string]$Runtime, [Parameter(Mandatory=$true)][string]$ExpectedProductionSha)
$ErrorActionPreference='Stop'
if ([Environment]::Version.Major -ne 10) { throw 'JIT replay requires .NET10' }
if ((Get-FileHash -LiteralPath (Join-Path $Runtime 'OoplesFinance.StockIndicators.dll') -Algorithm SHA256).Hash.ToLowerInvariant() -ne $ExpectedProductionSha) { throw 'Unverified production binary' }
Add-Type -TypeDefinition @"
using System;
using System.IO;
using System.Reflection;
using System.Runtime.Loader;
using System.Diagnostics;
public static class ArithmeticFieldReplay {
 public static void Run(string runtime) {
  AssemblyLoadContext.Default.Resolving+=(c,n)=>{string p=Path.Combine(runtime,n.Name+".dll");return File.Exists(p)?c.LoadFromAssemblyPath(p):null;};
  AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(runtime,"OoplesFinance.StockIndicators.dll"));
  var assembly=AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(runtime,"OoplesFinance.StockIndicators.CompetitorBenchmarks.dll"));
  var type=assembly.GetType("OoplesFinance.StockIndicators.CompetitorBenchmarks.SharedPairInputBenchmarks",true);
  string[] operations={"Add","Sub","Mult","Div"};var fixtures=new object[operations.Length];
  var setup=type.GetMethod("Setup");var build=type.GetMethod("BuilderFull");
  for(int i=0;i<operations.Length;i++) {
   var fixture=Activator.CreateInstance(type);type.GetProperty("Operation").SetValue(fixture,operations[i]);type.GetProperty("Count").SetValue(fixture,1000);setup.Invoke(fixture,null);fixtures[i]=fixture;
  }
  var elapsed=Stopwatch.StartNew();long builds=0;
  do {foreach(var fixture in fixtures){((IDisposable)build.Invoke(fixture,null)).Dispose();builds++;}} while(elapsed.ElapsedMilliseconds<5000);
  for(int i=fixtures.Length-1;i>=0;i--)type.GetMethod("Cleanup").Invoke(fixtures[i],null);
  Console.WriteLine("Diagnostic replay complete; operations=Add,Sub,Mult,Div; builds="+builds+"; runtime="+Environment.Version+"; no timing qualification.");
 }
}
"@
[ArithmeticFieldReplay]::Run($Runtime)
