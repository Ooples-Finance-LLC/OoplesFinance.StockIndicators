import copy
import hashlib
import gzip
import json
import tempfile
import unittest
from pathlib import Path
from arithmetic_selector_jit_gate import OPERATIONS, check_body, validate


def body(operation, arm):
    kernel = 'CloseOpenBinaryKernel' if arm == 'new' else 'BinaryKernel'
    header = f'; Assembly listing for method X+{kernel}`1[X+{operation}]](Tier1)'
    code = f'  {OPERATIONS[operation]} xmm0, xmm1, xmm2\n' if arm == 'new' else '  call X:Select(byref,int):double\n' * 2
    return header + '\n' + code


class SelectorGateTests(unittest.TestCase):
    def test_all_operations_observed(self):
        for operation in OPERATIONS:
            self.assertEqual(2, check_body(body(operation, 'old'), operation, 'old'))
            self.assertEqual(0, check_body(body(operation, 'new'), operation, 'new'))

    def test_remaining_selector_rejected(self):
        with self.assertRaises(AssertionError):
            check_body(body('Add', 'new') + '  call X:Select(byref,int):double\n', 'Add', 'new')

    def test_wrong_operation_or_tier_rejected(self):
        for candidate in [body('Add', 'new').replace('Tier1', 'Tier0'), body('Subtract', 'new')]:
            with self.assertRaises(AssertionError):
                check_body(candidate, 'Add', 'new')

    def test_arithmetic_call_rejected(self):
        with self.assertRaises(AssertionError):
            check_body(body('Add', 'new') + '  call SomeOtherKernel\n', 'Add', 'new')

    def test_missing_arithmetic_instruction_rejected(self):
        with self.assertRaises(AssertionError):
            check_body(body('Add', 'new').replace('vaddsd', 'vmulsd'), 'Add', 'new')

    def test_source_drift_and_tampered_evidence_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            record = dict(source='candidate', baseline='baseline', source_fingerprint='fingerprint', production_sha256='binary')
            proof = dict(record, schema=1, kind='source-bound-arithmetic-selector-jit', accepted=True, timing_qualification=False, operations={}, files={})
            for operation in OPERATIONS:
                proof['operations'][operation] = {}
                for arm in ['old', 'new']:
                    name = arm + operation + '.asm'
                    (root / name).write_text(body(operation, arm))
                    proof['operations'][operation][arm + '_asm'] = name
            (root / 'old-runtime-origin.json').write_text(json.dumps(dict(published_source='baseline')))
            (root / 'new-runtime-origin.json').write_text(json.dumps(dict(compiled_source='candidate', source_fingerprint='fingerprint', production_sha256='binary')))
            proof['files'] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in root.iterdir()}
            target = root / 'proof.json'
            target.write_text(json.dumps(proof))
            validate(target, record, check_tree=False)
            archived = root / 'newAdd.asm'
            archived.with_name(archived.name + '.gz').write_bytes(gzip.compress(archived.read_bytes()))
            archived.unlink()
            validate(target, record, check_tree=False)
            with self.assertRaises(AssertionError):
                validate(target, dict(record, source='wrong-source'), check_tree=False)
            (root / 'newAdd.asm').write_text(body('Add', 'new') + '  call X:Select(byref,int):double\n')
            with self.assertRaises(AssertionError):
                validate(target, record, check_tree=False)
            proof['files']['newAdd.asm'] = hashlib.sha256((root / 'newAdd.asm').read_bytes()).hexdigest()
            target.write_text(json.dumps(proof))
            with self.assertRaises(AssertionError):
                validate(target, record, check_tree=False)


if __name__ == '__main__':
    unittest.main()
