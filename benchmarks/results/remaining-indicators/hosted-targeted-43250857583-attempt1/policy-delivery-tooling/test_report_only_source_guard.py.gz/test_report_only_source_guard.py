import subprocess
import tempfile
import unittest
from pathlib import Path
from report_only_source_guard import verify_retained_source


class ReportOnlySourceTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='si-report-source-guard-');self.addCleanup(self.temp.cleanup)
        self.repo=Path(self.temp.name)
        self.git('init','-q');self.git('config','user.name','Test');self.git('config','user.email','test@example.invalid')
        for name in ('src/Indicators/ValuesBarExecution.Arithmetic.cs','src/Indicators/ValuesBarExecution.ReturnBeta.cs',
                     'src/Project.csproj','tests/case.cs','benchmarks/results/shared-rollout/local-gpu-contracts/receipt.json'):
            p=self.repo/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('original\n')
        self.commit();old=self.git('rev-parse','HEAD')
        (self.repo/'src/Indicators/ValuesBarExecution.ReturnBeta.cs').write_text('accepted private Beta\n')
        self.commit();base=self.git('rev-parse','HEAD')
        self.record=dict(report_refresh_only=True,no_source_integration=True,production_integrated=False,
            qualified_source=old,publication_baseline=base,preserved_src_tree=self.git('rev-parse','HEAD:src'),
            preserved_tests_tree=self.git('rev-parse','HEAD:tests'))

    def git(self,*args):return subprocess.check_output(['git',*args],cwd=self.repo,text=True,stderr=subprocess.PIPE).strip()
    def commit(self):self.git('add','.');self.git('commit','-q','-m','fixture')

    def test_private_beta_retained_and_report_evidence_allowed(self):
        (self.repo/'evidence.json').write_text('{}');self.commit()
        proof=verify_retained_source(self.repo,self.record)
        self.assertFalse(proof['production_source_imported'])
        self.assertEqual(['src/Indicators/ValuesBarExecution.ReturnBeta.cs'],proof['unrelated_private_source_changes'])

    def test_reverting_beta_cannot_pass(self):
        (self.repo/'src/Indicators/ValuesBarExecution.ReturnBeta.cs').write_text('original\n');self.commit()
        with self.assertRaises(AssertionError):verify_retained_source(self.repo,self.record)

    def test_uncommitted_arithmetic_change_cannot_pass(self):
        (self.repo/'src/Indicators/ValuesBarExecution.Arithmetic.cs').write_text('different\n')
        with self.assertRaises(AssertionError):verify_retained_source(self.repo,self.record)

    def test_staged_beta_reversion_cannot_pass(self):
        (self.repo/'src/Indicators/ValuesBarExecution.ReturnBeta.cs').write_text('original\n')
        self.git('add','src')
        with self.assertRaises(AssertionError):verify_retained_source(self.repo,self.record)

    def test_unreviewed_shared_change_cannot_be_rebased_silently(self):
        (self.repo/'src/Project.csproj').write_text('different dependency\n');self.commit()
        q=dict(self.record,publication_baseline=self.git('rev-parse','HEAD'),preserved_src_tree=self.git('rev-parse','HEAD:src'))
        with self.assertRaises(AssertionError):verify_retained_source(self.repo,q)

    def test_gpu_receipt_change_cannot_pass(self):
        (self.repo/'benchmarks/results/shared-rollout/local-gpu-contracts/receipt.json').write_text('changed\n');self.commit()
        with self.assertRaises(AssertionError):verify_retained_source(self.repo,self.record)

    def test_source_import_flag_cannot_be_claimed(self):
        with self.assertRaises(AssertionError):verify_retained_source(self.repo,dict(self.record,production_integrated=True))


if __name__=='__main__':unittest.main()
