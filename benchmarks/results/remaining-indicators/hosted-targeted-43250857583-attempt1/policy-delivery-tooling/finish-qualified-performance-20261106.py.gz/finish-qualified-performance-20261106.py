"""Close the bounded publication only after its fresh complete CI receipt."""
import argparse, datetime, json, subprocess
from pathlib import Path
from publication_status_policy import completion_message

p=argparse.ArgumentParser();p.add_argument('record');a=p.parse_args()
r=Path(__file__).parent;checkpoint=r/'continuation-latest-20261028.json'
d=json.loads(checkpoint.read_text());parent=d['performance_continuation_20261103'];q=parent[a.record];head=q['published_head']
receipt_path=r/('pr266-ci-'+head[:9]+'-20261104.json');receipt=json.loads(receipt_path.read_text())
assert receipt['head']==head and receipt['counts']['success']>=70
assert all(c['status']=='completed' and c['conclusion'] in ('success','skipped') for c in receipt['checks'])
endpoint='repos/Ooples-Finance-LLC/OoplesFinance.StockIndicators/pulls/266'
pr=json.loads(subprocess.check_output(['gh','api',endpoint]))
assert pr['head']['sha']==head and pr['draft'] and pr['auto_merge'] is None and pr['base']['ref']=='master'
marker='### '+q['publication_title'];assert pr['body'].count(marker)==1
assert pr['body'].count('Publication CI is running.')==1
payload=r/('pr266-'+a.record+'-body-complete.json')
body=pr['body'].replace('Publication CI is running.',
    completion_message(receipt.get('publication_status_policy',{})))
for replacement in q.get('pr_replacements_after_publication',[]):
    assert body.count(replacement['before'])==1
    body=body.replace(replacement['before'],replacement['after'],1)
payload.write_text(json.dumps(dict(body=body))+'\n')
subprocess.run(['gh','api',endpoint,'--method','PATCH','--input',str(payload),'--silent'],check=True)
q.update(status='COMPLETE BOUNDED PUBLICATION: accepted source/report and fresh CI/SonarCloud/CodeRabbit passed',
    fresh_publication_ci_status='passed',publication_ci_receipt=str(receipt_path),scope_completion_only=True,
    completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
if receipt.get('publication_status_policy',{}).get('optional_absence_approved'):
    q['status']='COMPLETE BOUNDED PUBLICATION: accepted source/report and fresh CI/SonarCloud passed; CodeRabbit status not posted under approved optional draft-status policy.'
if q.get('report_refresh_only') is True:
    q['status']=q['status'].replace('accepted source/report','accepted report-only refresh; production source retained')

for selected in q.get('selected_records',[]):
    item=parent[selected];assert item['accepted'] and item['local_hosted_collection_equal']
    assert not subprocess.check_output(['git','diff',item['qualified_source'],head,'--',*item['paths']],cwd=d['publishing_checkout'])
    item.update(production_integrated=True,integrated_by=a.record,integrated_publication_head=head,
        individual_timings_reused=False,
        status='COMPLETE selected source integrated through '+a.record+'; original timings remain historical and were not reused')
d.pop('current_published_ci_pending',None);parent.update(full_goal_complete=False,
    next=q.get('next_after_publication','Continue the recorded remaining performance batches on this verified baseline under existing authorization.'))
checkpoint.write_text(json.dumps(d,indent=2)+'\n');print(head,'bounded publication complete; overall performance work continues')
