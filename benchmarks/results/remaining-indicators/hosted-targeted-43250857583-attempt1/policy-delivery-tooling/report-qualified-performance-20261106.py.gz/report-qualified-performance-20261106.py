"""Stage and browser-verify the complete accepted consumer scope before import."""
import argparse, gzip, hashlib, json, os, re, subprocess, sys
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('record');a=p.parse_args()
r=Path(__file__).parent;checkpoint=r/'continuation-latest-20261028.json'
d=json.loads(checkpoint.read_text());q=d['performance_continuation_20261103'][a.record]
report_only=q.get('report_refresh_only') is True
assert q['accepted'] and (q['production_integrated'] or report_only) and not q['report_imported']
repo=Path(d['publishing_checkout']);tooling=Path(q.get('delivery_tooling_checkout',q['tooling_checkout']));run=str(q['timing_run'])
if report_only:
    from report_only_source_guard import verify_retained_source
    q['source_retention_verified']=verify_retained_source(repo,q)
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==q['integration_parent_after_individual_archives']
else:
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==q['source_integration_commit']
    assert not subprocess.check_output(['git','diff',q['qualified_source'],'--','src','tests'],cwd=repo)
plan_path=tooling/'benchmarks/plans'/q['plan'];plan=json.loads(plan_path.read_text())
os.environ['HOSTED_TIMING_PLAN']=str(plan_path);sys.path.insert(0,str(tooling/'scripts'))
from hosted_timing.report import stage
tasks=[task for shard in plan['targeted_shards'] for task in shard['tasks']]
def pairs(method):return {op['pair'] for task in tasks if method in task['methods'] for op in task['operations']}
expected=dict(baseline_rows=2*len(plan['affected_pairs']),builder_slots=4*len(pairs('BuilderFull')),
    snapshot_rows=2*len(pairs('Snapshot')))
live=Path('C:/Users/cheat/Documents/OoplesFinance-Reports/competitor-performance.html')
dataset=lambda path:json.loads(re.search(r'<script[^>]*id="dataset"[^>]*>(.*?)</script>',path.read_text(encoding='utf-8'),re.S)[1])
base=dataset(live)['evidence']['baseSourceSha'];assert base
out=r/(a.record+'-report');assert not out.exists()
stage(live,Path(os.environ.get('STOCK_INDICATORS_HOSTED_RUNS_ROOT',str(r/'hosted-runs')))/run/'evidence',repo,out,phase='targeted')
staged=json.loads((out/'staged.json').read_text())
assert (staged['changed_baseline_rows'],staged['changed_builder_slots'],staged.get('changed_snapshot_rows',0))==(
    expected['baseline_rows'],expected['builder_slots'],expected['snapshot_rows'])
assert staged.get('added_builder_slots',0)==0 and len(staged['builder_rows'])==1544
proof=json.loads((Path(os.environ.get('STOCK_INDICATORS_HOSTED_RUNS_ROOT',str(r/'hosted-runs')))/run/'verified-targeted-local.json').read_text())
for receipt in staged.get('snapshot_receipts',[]):
    assert receipt['complete'] and receipt['source_sha']==q['qualified_source'] and str(receipt['run_id'])==run
    key=lambda row:(row['pair'],row['bars'],row['method'])
    actual={key(row):row for row in receipt['rows']}
    expected_rows={key(row):row for row in proof['final_candidate_rows'][receipt['fixture']]
        if row['provenance']['shard']==receipt['measurement_shard']}
    assert actual==expected_rows
if q.get('delivery_tooling_checkout'):
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=tooling)
    delivery=out/'delivery-tooling';delivery.mkdir()
    for name in ('scripts/hosted_timing/report.py','scripts/test_hosted_report.py'):
        (delivery/Path(name).name).write_bytes((tooling/name).read_bytes())
    (delivery/'origin.json').write_bytes((json.dumps(dict(measurement_tooling=q['tooling_head'],
        delivery_tooling=q['delivery_tooling_head'],measurement_plan_sha256=q['plan_sha256']),indent=2)+'\n').encode())
for label,args in [('browser',['python',str(r/'verify-hosted-certified-report-20261101.py'),str(out/'candidate.html'),base,run,str(out)]),
    ('import',['python',str(r/'import-hosted-certified-report-20261101.py'),str(out)])]:
    with (out/(label+'.log')).open('wb') as log:subprocess.run(args,cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
verified=json.loads((out/'browser-verification.json').read_text())
assert verified['comparisons']==verified['displayed_table_comparisons']==verified['exported_comparisons']==802
assert not verified['javascript_errors']
report_hash=hashlib.sha256(live.read_bytes()).hexdigest()
assert report_hash==staged['candidate_sha256']==verified['report_sha256']
archive=repo/'benchmarks/results/remaining-indicators'/(a.record+'-report-integration');archive.mkdir()
(archive/'.gitattributes').write_bytes(b'* -text\n');manifest={}
for path in sorted(out.rglob('*')):
    if not path.is_file():continue
    raw=path.read_bytes();target=archive/(path.relative_to(out).as_posix()+'.gz')
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(raw,mtime=0))
    assert gzip.decompress(target.read_bytes())==raw
    manifest[path.relative_to(out).as_posix()]=dict(sha256=hashlib.sha256(raw).hexdigest(),archive=target.relative_to(repo).as_posix())
(archive/'manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
decision_path=Path(q['archive'])/'decision.json';decision=json.loads(decision_path.read_text())
assert decision['accepted'] and not decision['report_imported']
if report_only:
    assert not decision['production_integrated']
    q['source_retention_verified']=verify_retained_source(repo,q)
    decision['existing_source_retained']=q['source_retention_verified']
else:
    assert decision['production_integrated']
decision.update(report_imported=True,report_sha256=report_hash,report_archive=archive.relative_to(repo).as_posix())
decision_path.write_bytes((json.dumps(decision,indent=2)+'\n').encode())
rows=dataset(live)['rows'];wins={str(n):sum(x['bars']==n and x['competitor_over_ooples']>1 for x in rows) for n in (1000,10000)}
q.update(report_imported=True,report_sha256=report_hash,report_out=str(out),report_archive=str(archive),
    report_wins=wins,expected_report_changes=expected,exact_snapshot_rows_verified=expected['snapshot_rows'],
    status='Accepted source/report imported and browser-verified; visual inspection/publication pending')
if report_only:
    q['status']='Accepted report-only refresh imported and browser-verified; production retained; visual inspection/publication pending'
parent=d['performance_continuation_20261103'];parent.update(report_sha256=report_hash,
    remaining_gaps={n:401-v for n,v in wins.items()},remaining_10000_bar_gaps=401-wins['10000'],full_goal_complete=False)
subprocess.run(['git','add','benchmarks/results/remaining-indicators'],cwd=repo,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=repo,check=True)
subprocess.run(['git','commit','-m','perf: publish verified '+a.record+' report'],cwd=repo,check=True)
q['prepared_publication_head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
checkpoint.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(head=q['prepared_publication_head'],wins=wins,changes=expected)))
