"""Publish an already verified source/report while preserving draft PR state."""
import argparse, hashlib, json, re, subprocess, time
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('record');a=p.parse_args()
r=Path(__file__).parent;checkpoint=r/'continuation-latest-20261028.json'
d=json.loads(checkpoint.read_text());q=d['performance_continuation_20261103'][a.record];repo=Path(d['publishing_checkout'])
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
report_only=q.get('report_refresh_only') is True
assert all(q[k] for k in ('accepted','report_imported','report_visual_verified'))
assert q['production_integrated'] or report_only and q.get('source_retention_verified')
assert q['verdicts'].get('faster',0)>0 and not q['verdicts'].get('slower',0)
assert hashlib.sha256(Path('C:/Users/cheat/Documents/OoplesFinance-Reports/competitor-performance.html').read_bytes()).hexdigest()==q['report_sha256']
head=git('rev-parse','HEAD');assert head==q['prepared_publication_head'] and not git('status','--porcelain')
if report_only:
    from report_only_source_guard import verify_retained_source
    verify_retained_source(repo,q)
else:
    assert not git('diff',q['qualified_source'],'--','src','tests')
publication_baseline=q['publication_baseline'] if report_only else q['baseline']
assert git('ls-remote','origin','refs/heads/perf/remaining-indicator-rollout').split()[0]==publication_baseline
endpoint='repos/Ooples-Finance-LLC/OoplesFinance.StockIndicators/pulls/266'
pr=json.loads(subprocess.check_output(['gh','api',endpoint]))
assert pr['head']['sha']==publication_baseline and pr['draft'] and pr['auto_merge'] is None and pr['base']['ref']=='master'
marker='### '+q['publication_title'];assert marker not in pr['body']
plan=json.loads((Path(q['tooling_checkout'])/'benchmarks/plans'/q['plan']).read_text())
c=plan['source_correctness'];v=q['verdicts'];changes=q['expected_report_changes']
change_text=', '.join(str(changes[k])+' '+label for k,label in
    [('baseline_rows','batch rows'),('builder_slots','builder slots'),('snapshot_rows','snapshot rows')] if changes.get(k,0))
correctness_text=(f"Reused immutable source-bound binaries retain their verified {c['unit']} unit, {c['comparator']} comparator and 100 actual GPU cases. Current production source and GPU evidence were preserved."
    if report_only else f"Fresh source-bound CI binaries passed {c['unit']} unit cases, {c['comparator']} comparator cases and all 100 actual local GPU contracts.")
publication_label='Accepted report refresh' if report_only else 'Accepted source/report'
section=f'''{marker}

{q['publication_summary']}

{correctness_text} The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/{q['timing_run']}) covered {plan['cases']} cases / {plan['decisions']} decisions: {v.get('faster',0)} faster, {v.get('inconclusive',0)} inconclusive and zero slower. Independent local collection matched CI exactly; measured iterations, runtime, CPU and acceptance gates are unchanged.

The report refreshes {change_text} with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

{publication_label} published at `{head[:9]}`. Publication CI is running. Overall performance work remains open.
'''
intro,history=pr['body'].split('\n\n',1)
history,count=re.subn(r'The report shows \*\*.*?auto-merge disabled\.\s*','',history,count=1,flags=re.S);assert count==1
w=q['report_wins'];report=f"The report shows **{w['1000']}/401 wins at 1,000 bars and {w['10000']}/401 at 10,000 bars**; {401-w['10000']} batch gaps remain at 10,000 bars. Work continues with this PR kept draft, targeting master, with auto-merge disabled."
payload=r/('pr266-'+a.record+'-body.json');payload.write_text(json.dumps(dict(body=intro+'\n\n'+section+'\n'+report+'\n\n'+history.rstrip()+'\n'))+'\n')
subprocess.run(['git','push','origin','HEAD:refs/heads/perf/remaining-indicator-rollout'],cwd=repo,check=True)
q.update(published_head=head,fresh_publication_ci_status='running',pr_body_payload=str(payload),status='Accepted source/report published; fresh publication CI pending')
d.update(published_head=head,local_head=head,working_tree='clean',report_sha256=q['report_sha256'],
    current_published_ci_pending=dict(head=head,reason=a.record))
checkpoint.write_text(json.dumps(d,indent=2)+'\n')
for attempt in range(10):
    current=json.loads(subprocess.check_output(['gh','api',endpoint]))
    if current['head']['sha']==head:break
    time.sleep(2)
assert current['head']['sha']==head and current['draft'] and current['auto_merge'] is None
# Let the synchronize-event title check finish before the edited-event check
# starts, avoiding a superseded cancellation in the retained CI receipt.
for attempt in range(90):
    checks=json.loads(subprocess.check_output(['gh','api',
        'repos/Ooples-Finance-LLC/OoplesFinance.StockIndicators/commits/'+head+'/check-runs?per_page=100']))['check_runs']
    titles=[c for c in checks if c['name']=='Auto-Fix PR Title']
    if titles and all(c['status']=='completed' for c in titles):
        assert all(c['conclusion'] in ('success','skipped') for c in titles),'Repair only the unsuccessful metadata workflow'
        break
    time.sleep(2)
else:raise RuntimeError('Source published; title check has not completed; prepared PR body remains pending')
subprocess.run(['gh','api',endpoint,'--method','PATCH','--input',str(payload),'--silent'],check=True)
print(head)
