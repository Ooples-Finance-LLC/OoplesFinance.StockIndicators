"""Keep the current accepted source while refreshing historical measurements."""
import subprocess
from pathlib import Path


def verify_retained_source(repo, record):
    repo=Path(repo)
    assert record.get('report_refresh_only') is True and record.get('no_source_integration') is True
    assert record.get('production_integrated') is False
    def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True,timeout=60).strip()
    head=git('rev-parse','HEAD');base=record['publication_baseline']
    assert git('rev-parse','HEAD:src')==record['preserved_src_tree']
    assert git('rev-parse','HEAD:tests')==record['preserved_tests_tree']
    assert not git('diff','HEAD','--','src','tests'), 'Uncommitted production/test changes'
    changed=set(git('diff','--name-only',record['qualified_source'],base,'--','src').splitlines())
    assert changed<={'src/Indicators/ValuesBarExecution.ReturnBeta.cs'}, 'Unreviewed shared source changes'
    gpu='benchmarks/results/shared-rollout/local-gpu-contracts'
    assert not git('diff',base,'HEAD','--',gpu) and not git('diff','HEAD','--',gpu), 'GPU evidence changed'
    return dict(retained_head=head,publication_baseline=base,historical_qualified_source=record['qualified_source'],
        src_tree=record['preserved_src_tree'],tests_tree=record['preserved_tests_tree'],
        unrelated_private_source_changes=sorted(changed),production_source_imported=False,gpu_evidence_preserved=True)
