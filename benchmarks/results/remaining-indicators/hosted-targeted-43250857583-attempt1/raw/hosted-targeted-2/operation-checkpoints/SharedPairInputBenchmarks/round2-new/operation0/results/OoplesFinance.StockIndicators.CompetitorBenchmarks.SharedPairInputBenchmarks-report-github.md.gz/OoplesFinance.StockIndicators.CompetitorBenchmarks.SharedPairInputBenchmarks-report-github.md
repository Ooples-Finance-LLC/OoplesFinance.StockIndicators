```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-------------:|------------:|------------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Mult**      |   **6,409.1 ns** |   **101.94 ns** |    **53.31 ns** |  **6.53** |    **0.22** |  **3.4180** |  **0.4883** |  **56.82 KB** |        **7.22** |
| BuilderLatestOnly | 1000  | Mult      |   4,346.5 ns |    70.08 ns |    36.65 ns |  4.43 |    0.15 |  0.5493 |       - |   9.21 KB |        1.17 |
| NativeSingle      | 1000  | Mult      |     983.0 ns |    50.83 ns |    33.62 ns |  1.00 |    0.05 |  0.4807 |  0.0076 |   7.87 KB |        1.00 |
| NativeParallel    | 1000  | Mult      |  85,952.9 ns |   860.22 ns |   568.98 ns | 87.53 |    2.94 |  0.4883 |       - |   8.14 KB |        1.03 |
|                   |       |           |              |             |             |       |         |         |         |           |             |
| **BuilderFull**       | **10000** | **Mult**      | **124,386.6 ns** | **4,533.50 ns** | **2,998.63 ns** | **16.57** |    **0.41** | **33.2031** | **13.6719** | **549.82 KB** |        **7.03** |
| BuilderLatestOnly | 10000 | Mult      | 106,198.8 ns | 1,708.61 ns |   893.64 ns | 14.15 |    0.17 |  3.9063 |       - |  79.97 KB |        1.02 |
| NativeSingle      | 10000 | Mult      |   7,506.4 ns |   108.31 ns |    71.64 ns |  1.00 |    0.01 |  4.7607 |  0.9155 |  78.18 KB |        1.00 |
| NativeParallel    | 10000 | Mult      |  91,394.7 ns | 1,359.07 ns |   898.94 ns | 12.18 |    0.16 |  4.3945 |  0.4883 |  78.45 KB |        1.00 |
