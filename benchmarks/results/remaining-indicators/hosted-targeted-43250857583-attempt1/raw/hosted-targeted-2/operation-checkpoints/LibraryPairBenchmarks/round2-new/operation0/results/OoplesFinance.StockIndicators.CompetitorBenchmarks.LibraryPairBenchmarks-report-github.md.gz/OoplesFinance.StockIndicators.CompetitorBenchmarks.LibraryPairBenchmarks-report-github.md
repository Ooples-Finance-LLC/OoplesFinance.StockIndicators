```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=20000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Mult** |  **40.90 μs** |  **1.046 μs** | **0.622 μs** |  **1.00** |    **0.02** |  **98.15 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Mult |  14.69 μs |  0.540 μs | 0.283 μs |  0.36 |    0.01 |  39.95 KB |        0.41 |
|            |       |                      |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Mult** | **279.49 μs** | **13.109 μs** | **6.856 μs** |  **1.00** |    **0.03** | **959.47 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Mult | 118.41 μs |  2.406 μs | 1.259 μs |  0.42 |    0.01 | 330.31 KB |        0.34 |
