```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=20000  

```
| Method     | Bars  | PairId              | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Sub** |  **30.59 μs** |  **0.996 μs** | **0.593 μs** |  **1.00** |    **0.03** |  **98.15 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Sub |  11.87 μs |  2.878 μs | 1.904 μs |  0.39 |    0.06 |  37.37 KB |        0.38 |
|            |       |                     |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Sub** | **209.23 μs** | **14.243 μs** | **8.476 μs** |  **1.00** |    **0.05** | **959.47 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Sub |  83.18 μs |  0.835 μs | 0.497 μs |  0.40 |    0.02 |    329 KB |        0.34 |
