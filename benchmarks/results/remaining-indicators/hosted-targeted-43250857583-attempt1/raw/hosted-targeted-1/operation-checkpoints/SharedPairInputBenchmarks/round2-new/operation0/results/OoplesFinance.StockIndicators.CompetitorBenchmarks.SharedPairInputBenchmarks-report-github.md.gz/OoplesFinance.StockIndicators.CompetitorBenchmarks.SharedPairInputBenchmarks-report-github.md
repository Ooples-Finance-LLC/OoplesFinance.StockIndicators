```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-------------:|------------:|------------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Sub**       |   **5,108.4 ns** |   **124.74 ns** |    **74.23 ns** |  **6.56** |    **0.19** |  **3.4180** |  **0.4883** |  **56.82 KB** |        **7.22** |
| BuilderLatestOnly | 1000  | Sub       |   2,869.4 ns |   110.68 ns |    73.21 ns |  3.68 |    0.13 |  0.5493 |       - |   9.21 KB |        1.17 |
| NativeSingle      | 1000  | Sub       |     779.4 ns |    30.89 ns |    20.43 ns |  1.00 |    0.04 |  0.4807 |  0.0076 |   7.87 KB |        1.00 |
| NativeParallel    | 1000  | Sub       |  75,881.0 ns |   549.56 ns |   363.50 ns | 97.42 |    2.45 |  0.4883 |       - |   8.14 KB |        1.03 |
|                   |       |           |              |             |             |       |         |         |         |           |             |
| **BuilderFull**       | **10000** | **Sub**       | **101,406.5 ns** | **1,749.92 ns** |   **915.24 ns** | **15.73** |    **0.26** | **33.2031** | **13.6719** | **549.82 KB** |        **7.03** |
| BuilderLatestOnly | 10000 | Sub       |  87,585.1 ns | 2,595.06 ns | 1,716.47 ns | 13.58 |    0.32 |  4.3945 |  0.4883 |  79.97 KB |        1.02 |
| NativeSingle      | 10000 | Sub       |   6,449.8 ns |   161.26 ns |    95.96 ns |  1.00 |    0.02 |  4.7607 |  0.9155 |  78.18 KB |        1.00 |
| NativeParallel    | 10000 | Sub       |  79,401.1 ns | 1,194.32 ns |   789.97 ns | 12.31 |    0.21 |  4.3945 |  0.4883 |  78.45 KB |        1.00 |
