```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=20000  

```
| Method     | Bars  | PairId              | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Add** |  **39.75 μs** |  **0.903 μs** |  **0.472 μs** |  **1.00** |    **0.02** |  **98.15 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Add |  13.74 μs |  0.227 μs |  0.119 μs |  0.35 |    0.00 |  34.74 KB |        0.35 |
|            |       |                     |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Add** | **263.46 μs** | **18.673 μs** | **11.112 μs** |  **1.00** |    **0.06** | **959.47 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Add | 120.30 μs |  3.832 μs |  2.004 μs |  0.46 |    0.02 | 330.97 KB |        0.34 |
