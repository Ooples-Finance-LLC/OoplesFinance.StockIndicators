```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-------------:|------------:|------------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Add**       |   **6,571.5 ns** |   **159.99 ns** |    **95.21 ns** |  **7.08** |    **0.11** |  **3.4180** |  **0.4883** |  **56.82 KB** |        **7.22** |
| BuilderLatestOnly | 1000  | Add       |   3,758.8 ns |    67.96 ns |    40.44 ns |  4.05 |    0.05 |  0.5493 |       - |   9.21 KB |        1.17 |
| NativeSingle      | 1000  | Add       |     928.3 ns |    12.43 ns |     8.22 ns |  1.00 |    0.01 |  0.4807 |  0.0076 |   7.87 KB |        1.00 |
| NativeParallel    | 1000  | Add       |  85,849.7 ns |   975.91 ns |   645.50 ns | 92.49 |    1.02 |  0.4883 |       - |   8.14 KB |        1.03 |
|                   |       |           |              |             |             |       |         |         |         |           |             |
| **BuilderFull**       | **10000** | **Add**       | **118,700.3 ns** | **6,159.85 ns** | **4,074.36 ns** | **15.98** |    **0.53** | **33.2031** | **13.6719** | **549.82 KB** |        **7.03** |
| BuilderLatestOnly | 10000 | Add       | 100,934.4 ns | 1,404.85 ns |   734.77 ns | 13.59 |    0.12 |  3.9063 |       - |  79.97 KB |        1.02 |
| NativeSingle      | 10000 | Add       |   7,427.1 ns |    78.45 ns |    46.68 ns |  1.00 |    0.01 |  4.7607 |  0.9155 |  78.18 KB |        1.00 |
| NativeParallel    | 10000 | Add       |  91,341.3 ns | 1,137.86 ns |   752.62 ns | 12.30 |    0.12 |  4.3945 |  0.4883 |  78.45 KB |        1.00 |
