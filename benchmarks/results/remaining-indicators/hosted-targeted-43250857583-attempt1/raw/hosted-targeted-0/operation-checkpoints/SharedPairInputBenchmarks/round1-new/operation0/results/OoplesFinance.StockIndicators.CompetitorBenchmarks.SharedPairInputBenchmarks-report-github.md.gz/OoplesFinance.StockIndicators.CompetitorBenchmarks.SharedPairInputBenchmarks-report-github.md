```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Add**       |   **6.486 μs** | **0.1906 μs** | **0.1134 μs** |  **3.4180** |  **0.4883** |  **56.82 KB** |
| BuilderLatestOnly | 1000  | Add       |   3.717 μs | 0.0477 μs | 0.0284 μs |  0.5493 |       - |   9.21 KB |
| **BuilderFull**       | **10000** | **Add**       | **120.592 μs** | **7.1641 μs** | **4.7386 μs** | **33.2031** | **13.6719** | **549.82 KB** |
| BuilderLatestOnly | 10000 | Add       | 101.311 μs | 2.1368 μs | 1.2716 μs |  3.9063 |       - |  79.97 KB |
