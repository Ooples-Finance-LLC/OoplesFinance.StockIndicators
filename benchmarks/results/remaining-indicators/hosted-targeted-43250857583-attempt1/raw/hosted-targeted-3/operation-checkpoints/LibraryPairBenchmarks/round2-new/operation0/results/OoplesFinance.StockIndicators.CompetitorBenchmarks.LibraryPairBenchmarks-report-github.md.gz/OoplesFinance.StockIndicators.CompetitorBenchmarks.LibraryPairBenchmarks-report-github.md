```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=20000  

```
| Method     | Bars  | PairId              | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Div** |  **40.70 μs** |  **1.606 μs** | **0.840 μs** |  **1.00** |    **0.03** |  **98.15 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Div |  14.40 μs |  0.368 μs | 0.193 μs |  0.35 |    0.01 |   40.6 KB |        0.41 |
|            |       |                     |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Div** | **255.57 μs** |  **7.489 μs** | **3.917 μs** |  **1.00** |    **0.02** |  **959.8 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Div | 128.76 μs | 11.430 μs | 7.560 μs |  0.50 |    0.03 | 330.97 KB |        0.34 |
