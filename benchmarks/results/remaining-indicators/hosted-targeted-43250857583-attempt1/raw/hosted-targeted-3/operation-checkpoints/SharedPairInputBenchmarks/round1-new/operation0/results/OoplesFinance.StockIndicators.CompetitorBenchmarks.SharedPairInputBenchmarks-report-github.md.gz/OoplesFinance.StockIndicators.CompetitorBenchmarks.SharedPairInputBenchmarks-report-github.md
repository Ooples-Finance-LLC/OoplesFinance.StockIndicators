```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Div**       |   **7.181 μs** | **0.1958 μs** | **0.1165 μs** |  **3.4180** |  **0.4883** |  **56.82 KB** |
| BuilderLatestOnly | 1000  | Div       |   4.467 μs | 0.0448 μs | 0.0267 μs |  0.5493 |       - |   9.21 KB |
| **BuilderFull**       | **10000** | **Div**       | **124.805 μs** | **3.8460 μs** | **2.0115 μs** | **33.2031** | **13.6719** | **549.82 KB** |
| BuilderLatestOnly | 10000 | Div       | 105.186 μs | 1.3673 μs | 0.7151 μs |  3.9063 |       - |  79.97 KB |
