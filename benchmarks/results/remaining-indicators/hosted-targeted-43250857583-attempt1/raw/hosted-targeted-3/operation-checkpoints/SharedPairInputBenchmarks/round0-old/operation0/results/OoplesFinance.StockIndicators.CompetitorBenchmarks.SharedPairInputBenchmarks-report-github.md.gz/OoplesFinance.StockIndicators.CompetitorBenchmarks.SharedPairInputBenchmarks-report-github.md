```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Div**       |   **9.537 μs** | **0.1846 μs** | **0.1098 μs** |  **3.4180** |  **0.4883** |  **56.83 KB** |
| BuilderLatestOnly | 1000  | Div       |   7.112 μs | 0.1052 μs | 0.0626 μs |  0.5493 |       - |   9.22 KB |
| **BuilderFull**       | **10000** | **Div**       | **139.745 μs** | **8.8222 μs** | **5.2499 μs** | **33.2031** | **13.6719** | **549.83 KB** |
| BuilderLatestOnly | 10000 | Div       | 124.844 μs | 1.9923 μs | 1.0420 μs |  3.9063 |       - |  79.98 KB |
