```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Div**       |   **7.018 μs** | **0.0855 μs** | **0.0509 μs** |  **4.03** |    **0.06** |  **3.4180** |  **0.4883** |  **56.82 KB** |        **7.22** |
| BuilderLatestOnly | 1000  | Div       |   4.465 μs | 0.0528 μs | 0.0349 μs |  2.56 |    0.04 |  0.5493 |       - |   9.21 KB |        1.17 |
| NativeSingle      | 1000  | Div       |   1.743 μs | 0.0347 μs | 0.0229 μs |  1.00 |    0.02 |  0.4730 |       - |   7.87 KB |        1.00 |
| NativeParallel    | 1000  | Div       |  86.467 μs | 0.9981 μs | 0.6602 μs | 49.62 |    0.72 |  0.4883 |       - |   8.14 KB |        1.03 |
|                   |       |           |            |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **10000** | **Div**       | **124.138 μs** | **2.1104 μs** | **1.1038 μs** |  **8.02** |    **0.09** | **33.2031** | **13.6719** | **549.82 KB** |        **7.03** |
| BuilderLatestOnly | 10000 | Div       | 109.082 μs | 5.1496 μs | 3.4061 μs |  7.05 |    0.22 |  3.9063 |       - |  79.97 KB |        1.02 |
| NativeSingle      | 10000 | Div       |  15.472 μs | 0.2268 μs | 0.1350 μs |  1.00 |    0.01 |  4.7607 |  0.8545 |  78.18 KB |        1.00 |
| NativeParallel    | 10000 | Div       |  93.691 μs | 1.4518 μs | 0.9603 μs |  6.06 |    0.08 |  4.3945 |  0.4883 |  78.45 KB |        1.00 |
