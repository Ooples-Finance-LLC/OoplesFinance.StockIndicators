from pathlib import Path
from benchmark_process_cleanup import capture_children, stop_owned_benchmark, archive_with_retry
import datetime, hashlib, json, os, psutil, shutil, subprocess, time

ROOT = Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
BASE = Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC')
BASELINE=json.loads((ROOT/'cached-node-handlers-baseline.json').read_text(encoding='utf-8'))
OLD = Path(BASELINE['checkout'])
NEW = BASE/'si-cached-node-handlers-20261027'
OUT = ROOT/'local-cached-node-handlers-control-20261027'
REL = Path('benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks/bin/Release/net10.0')
DLL = 'OoplesFinance.StockIndicators.dll'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def manifest(p): return {f.relative_to(p).as_posix():digest(f) for f in p.rglob('*') if f.is_file()}
def head(p): return subprocess.check_output(['git','rev-parse','HEAD'],cwd=p,text=True).strip()

qualification=json.loads((ROOT/'cached-node-handlers/status.json').read_text(encoding='utf-8'))
assert qualification['status']=='checks-passed-review-and-publication-pending'
assert qualification['gpu_passed']==100 and qualification['parity']['passed']==170 and qualification['unit']['passed']>0
old_qualification=json.loads(Path(BASELINE['qualification']).read_text(encoding='utf-8'))
assert old_qualification['gpu_passed']==100 and old_qualification['status']=='checks-passed-review-and-publication-pending'
assert digest(OLD/REL/DLL) in old_qualification['production_dll_sha256'].values()
assert not subprocess.check_output(['git','diff',old_qualification['input_head'],head(OLD),'--','src','tests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','benchmarks/OoplesFinance.StockIndicators.CompetitorTests','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json'],cwd=OLD)
assert digest(NEW/REL/DLL) in qualification['production_dll_sha256'].values()
# Only the reviewed helper may differ in executable/build inputs.
changed=subprocess.check_output(['git','diff','--name-only',head(OLD),head(NEW),'--','src','tests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','benchmarks/OoplesFinance.StockIndicators.CompetitorTests','Directory.Build.props','Directory.Build.targets','global.json'],cwd=NEW,text=True).splitlines()
assert set(changed)=={'src/Indicators/ValuesBarExecution.cs','tests/ModelsTests/CachedNodeHandlerTests.cs'},changed
original=manifest(OLD/REL)
arms={'old':OLD/REL,'new':OUT/'new'}
if OUT.exists():
 saved=json.loads((OUT/'provenance.json').read_text(encoding='utf-8'))
 assert saved['old_source']==head(OLD) and saved['new_source']==head(NEW)
 assert saved['candidate_code_source']==qualification['input_head']
 manifests=json.loads((OUT/'binary-manifest.json').read_text(encoding='utf-8'))
 assert all(manifest(arms[a])==manifests[a] for a in ['old','new'])
 state=json.loads((OUT/'status.json').read_text(encoding='utf-8'))
 assert state['status']=='paused-for-independent-correctness'
 assert state['order']==['old','new','new','old']
 for record in state['rounds']:
  assert digest(Path(record['report']))==record['sha256']
else:
 assert shutil.disk_usage(ROOT).free > sum(p.stat().st_size for p in (OLD/REL).rglob('*') if p.is_file()) + 1024**3
 OUT.mkdir()
 original=manifest(OLD/REL)
 arms={'old':OLD/REL,'new':OUT/'new'}
 assert manifest(arms['old'])==original
 shutil.copytree(arms['old'],arms['new'])
 shutil.copy2(NEW/REL/DLL,arms['new']/DLL)
 manifests={arm:manifest(arms[arm]) for arm in ['old','new']}
 assert manifests['old']==original
 assert manifests['old'].keys()==manifests['new'].keys()
 assert [p for p in original if manifests['old'][p]!=manifests['new'][p]]==[DLL]
 (OUT/'binary-manifest.json').write_text(json.dumps(manifests,indent=2),encoding='utf-8')
 (OUT/'provenance.json').write_text(json.dumps({'old_source':head(OLD),'new_source':head(NEW),'candidate_code_source':qualification['input_head'],'qualification':qualification,'old_qualification':old_qualification,'measurement_location':'Local Windows; no GitHub Actions measurement','changed_inputs':changed},indent=2),encoding='utf-8')
 state={'status':'starting','order':['old','new','new','old'],'rounds':[]}

def save():
 state['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (OUT/'status.json').write_text(json.dumps(state,indent=2),encoding='utf-8')
env=os.environ.copy();env['TEMP']=env['TMP']=str(ROOT/'temp')
for key in ['COMPARISON_PAIR','COMPARISON_SHARD','COMPARISON_SHARDS']: env.pop(key,None)
for index,arm in enumerate(state['order']):
 for fixture,methods,parameter,expected in [('SharedTaMacdNativeBenchmarks', ['BuilderFull', 'BuilderLatestOnly', 'NativeSingle', 'NativeParallel'], 'Count', 16), ('SharedTradyMacdBenchmarks', ['BuilderFull', 'BuilderLatestOnly', 'NativeSingle', 'NativeParallel'], 'Count', 16), ('SharedSkenderEmaFamilyBenchmarks', ['BuilderFull', 'BuilderLatestOnly', 'NativeSingle', 'NativeParallel'], 'Count', 16), ('SharedTaAverageNativeBenchmarks', ['BuilderFull', 'BuilderLatestOnly', 'NativeSingle', 'NativeParallel'], 'Count', 16), ('SharedTillsonBenchmarks', ['BuilderFull', 'BuilderLatestOnly', 'NativeSingle', 'NativeParallel'], 'Count', 24), ('SharedRecursiveStateBenchmarks', ['BuilderFull', 'BuilderLatestOnly', 'NativeSingle', 'NativeParallel'], 'Count', 8), ('SharedTradyNativeVolumeBenchmarks', ['BuilderFull', 'BuilderLatestOnly', 'NativeSingle', 'NativeParallel'], 'Count', 8), ('SharedAdlDetailsBenchmarks', ['BuilderFull', 'BuilderLatestOnly', 'NativeSingle', 'NativeParallel'], 'Count', 8), ('LibraryPairBenchmarks', ['Ooples', 'Competitor'], 'Bars', 56)]:
  if any(r['index']==index and r['fixture']==fixture for r in state['rounds']): continue
  while True:
   state.update(status='waiting-quiet-window',round=index,arm=arm,fixture=fixture);save()
   samples=[]
   while len(samples)<12 or any(v>15 for v in samples[-12:]):
    builds=[p.pid for p in psutil.process_iter(['name','cmdline']) if (p.info['name'] or '').lower()=='dotnet.exe' and 'build' in (p.info['cmdline'] or [])]
    samples.append(psutil.cpu_percent(interval=5))
    if builds: samples=[]
    state.update(waiting_build_pids=builds, quiet_cpu_samples=samples[-12:]);save()
   filters=[f'*{fixture}.{method}*"{pair}"*' for method in methods for pair in ({'SharedTaMacdNativeBenchmarks': ['TaLib.Functions.Macd', 'TaLib.Functions.MacdFix'], 'SharedTradyMacdBenchmarks': ['MovingAverageConvergenceDivergence', 'MovingAverageConvergenceDivergenceHistogram'], 'SharedSkenderEmaFamilyBenchmarks': ['Skender.GetMacd', 'Skender.GetPvo'], 'SharedTaAverageNativeBenchmarks': ['TaLib.Functions.Apo', 'TaLib.Functions.Ppo'], 'SharedTillsonBenchmarks': ['Skender.GetT3', 'TaLib.Functions.T3', 'QuanTAlib.T3'], 'SharedRecursiveStateBenchmarks': ['Ad'], 'SharedTradyNativeVolumeBenchmarks': ['AccumulationDistributionLine'], 'SharedAdlDetailsBenchmarks': ['Skender.GetAdl'], 'LibraryPairBenchmarks': ['TaLib.Functions.Macd', 'TaLib.Functions.MacdFix', 'Trady.Indicator.MovingAverageConvergenceDivergence', 'Trady.Indicator.MovingAverageConvergenceDivergenceHistogram', 'Skender.GetMacd', 'Skender.GetPvo', 'TaLib.Functions.Apo', 'TaLib.Functions.Ppo', 'Skender.GetT3', 'TaLib.Functions.T3', 'QuanTAlib.T3', 'TaLib.Functions.Ad', 'Trady.Indicator.AccumulationDistributionLine', 'Skender.GetAdl']}[fixture])]
   folder=OUT/f'round{index}-{arm}-{fixture}'
   state['status']='measuring';save()
   with folder.with_suffix('.log').open('wb') as log:
    args=['dotnet',str(arms[arm]/'OoplesFinance.StockIndicators.CompetitorBenchmarks.dll'),'--filter',*filters,'--warmupCount','10','--iterationCount','10','--exporters','json','--artifacts',str(folder)]
    process=subprocess.Popen(args,cwd=arms[arm],env=env,stdout=log,stderr=subprocess.STDOUT)
    started=time.monotonic(); interrupted=[]; observations=0; owned_children={}
    while True:
     capture_children(process, owned_children)
     builds=[p.pid for p in psutil.process_iter(['name','cmdline']) if (p.info['name'] or '').lower()=='dotnet.exe' and 'build' in (p.info['cmdline'] or [])]
     observations+=1
     if builds:
      interrupted=builds
      stop_owned_benchmark(process, owned_children);break
     code=process.poll()
     if code is not None:
      if code:raise subprocess.CalledProcessError(code,args)
      break
     if time.monotonic()-started>3600:
      stop_owned_benchmark(process, owned_children);raise subprocess.TimeoutExpired(args,3600)
     time.sleep(1)
   if interrupted:
    rejected=OUT/'invalidated-attempts'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%f')
    rejected.mkdir(parents=True,exist_ok=False)
    for source in [folder,folder.with_suffix('.log')]:
     if source.exists():
      target=rejected/source.name
      assert source.resolve().is_relative_to(OUT.resolve()) and target.resolve().is_relative_to(OUT.resolve()) and not target.exists()
      archive_with_retry(source,target,OUT)
    (rejected/'interruption.json').write_text(json.dumps({'round':index,'arm':arm,'fixture':fixture,'external_build_pids':interrupted,'reason':'Build observed during timing; this attempt is excluded and will be retried after a quiet window.'},indent=2)+'\n',encoding='utf-8',newline='\n')
    continue
   reports=list((folder/'results').glob('*-report-full-compressed.json'));assert len(reports)==1
   report=json.loads(reports[0].read_bytes())
   assert len(report['Benchmarks'])==expected and all(c.get('Statistics') and c['Statistics']['N']>=7 for c in report['Benchmarks'])
   state['rounds'].append({'index':index,'arm':arm,'fixture':fixture,'quiet_cpu_samples':samples[-3:],'quiet_build_free_samples':12,'build_monitor_observations':observations,'report':str(reports[0]),'sha256':digest(reports[0]),'cases':expected});save()
   break
assert manifest(arms['old'])==original
assert all(manifest(arms[arm])==manifests[arm] for arm in ['old','new'])
state['status']='raw-measurements-complete-independent-verification-pending';save()
print(state['status'],flush=True)
