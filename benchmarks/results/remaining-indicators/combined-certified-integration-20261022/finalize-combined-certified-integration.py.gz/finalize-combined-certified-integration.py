from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
repo=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
raw=root/'combined-certified-integration-20261022'
state=json.loads((raw/'status.json').read_text(encoding='utf-8'))
assert state['status']=='checks-passed-review-and-publication-pending'
assert (state['unit']['passed'],state['parity']['passed'],state['gpu_passed'])==(74,78,100)
subprocess.run(['python3.13.exe',str(root/'archive-combined-certified-integration.py')],check=True)
out=repo/'benchmarks/results/remaining-indicators/combined-certified-integration-20261022'
out.mkdir(exist_ok=False)
(out/'.gitattributes').write_bytes(b'* -text\n')
manifest={}
for path in [*raw.glob('*.log'),root/'validate-combined-certified-integration.py',root/'archive-combined-certified-integration.py',root/'finalize-combined-certified-integration.py']:
    data=path.read_bytes();(out/(path.name+'.gz')).write_bytes(gzip.compress(data,mtime=0));manifest[path.name]=hashlib.sha256(data).hexdigest()
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['fibonacci','hilbert']:
    path=repo/f'benchmarks/results/remaining-indicators/local-{name}-certified-control-20261022/decision.json'
    decision=json.loads(path.read_text(encoding='utf-8'))
    assert decision['status']=='candidate-qualified-for-integration'
    decision.update(production_integrated=True,integration_source=state['input_head'],integration_verification='benchmarks/results/remaining-indicators/publication-combined-integration-certified-20261022-verification.json')
    path.write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Archived combined integration receipts and marked both qualified changes integrated.')
