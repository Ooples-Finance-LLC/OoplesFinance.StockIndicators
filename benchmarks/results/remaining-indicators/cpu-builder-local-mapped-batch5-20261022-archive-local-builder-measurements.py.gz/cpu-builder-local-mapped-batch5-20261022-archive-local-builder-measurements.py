from pathlib import Path
import gzip,hashlib,json,re,subprocess,sys
ROOT=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
REPO=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
run,measure,verify=sys.argv[1:];assert re.fullmatch(r'[a-zA-Z0-9-]+',run)
RAW=ROOT/run;OUT=REPO/'benchmarks/results/remaining-indicators'/run
summary=json.loads((RAW/'verified-summary.json').read_text(encoding='utf-8'));state=json.loads((RAW/'status.json').read_text(encoding='utf-8'))
if summary.get('partial'):
 assert state['status']=='interrupted-for-cost-review' and (RAW/'interrupted-for-cost-review.json').exists()
 assert summary['excluded_fixtures'] and not set(summary['excluded_fixtures']).intersection(r['fixture'] for r in summary['receipts'])
else:
 assert state['status']=='raw-measurements-complete-independent-verification-pending'
assert all(r['complete'] and r['run_id']==run for r in summary['receipts'])
assert not subprocess.check_output(['git','diff',summary['source_sha'],'HEAD','--',*summary['matched_current_source_paths']],cwd=REPO)
files=['verified-summary.json','status.json','provenance.json','binary-manifest.json']
if summary.get('partial'): files.append('interrupted-for-cost-review.json')
files += [r['report_file'] for r in summary['receipts']]
files += [p.name for p in RAW.glob('*.log')]
OUT.mkdir(exist_ok=True);archives={}
for name in files:
 raw=(RAW/name).read_bytes();target=OUT/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(raw,mtime=0));archives[name]={'sha256':hashlib.sha256(raw).hexdigest(),'archive':target.relative_to(REPO).as_posix()}
scripts={}
for name in [measure,verify]:
 assert Path(name).name==name
 raw=(ROOT/name).read_bytes();(OUT/(name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));scripts[name]=hashlib.sha256(raw).hexdigest()
(OUT/'manifest.json').write_text(json.dumps({'source_sha':summary['source_sha'],'measurement_location':'Local Windows; unchanged correctness setup; CPU builder and native methods timed','cases':sum(state['fixtures'][r['fixture']]['cases'] for r in summary['receipts']),'comparisons':sum(len(r['comparisons']) for r in summary['receipts']),'partial':summary.get('partial',False),'excluded_fixtures':summary.get('excluded_fixtures',[]),'archives':archives,'scripts':scripts},indent=2)+'\n',encoding='utf-8')
(OUT/'.gitattributes').write_bytes(b'* -text\n')
print('Archived local evidence:',run)
