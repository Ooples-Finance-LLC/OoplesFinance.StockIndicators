```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |   **417.3 μs** |  **8.31 μs** |  **4.95 μs** |  **73.68 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |   396.9 μs |  2.62 μs |  1.56 μs |  26.04 KB |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** | **4,196.4 μs** | **71.58 μs** | **42.59 μs** |    **707 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 | 4,092.6 μs | 33.28 μs | 19.81 μs | 237.18 KB |
