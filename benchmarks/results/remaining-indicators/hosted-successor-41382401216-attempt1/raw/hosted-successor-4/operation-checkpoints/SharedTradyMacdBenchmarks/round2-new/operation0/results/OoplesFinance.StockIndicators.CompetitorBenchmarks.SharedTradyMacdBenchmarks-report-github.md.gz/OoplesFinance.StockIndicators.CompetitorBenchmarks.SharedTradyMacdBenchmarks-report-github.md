```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |    **441.8 μs** |    **10.50 μs** |     **6.25 μs** |  **0.20** |    **0.01** |         **-** |         **-** |         **-** |   **104.99 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |    442.0 μs |     2.30 μs |     1.20 μs |  0.20 |    0.01 |         - |         - |         - |    57.39 KB |        0.02 |
| NativeSingle      | Movin(...)gence [34] | 1000  |  2,164.7 μs |    96.27 μs |    63.68 μs |  1.00 |    0.04 |   46.8750 |   46.8750 |   46.8750 |  3232.17 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 1000  |  1,699.3 μs |    37.70 μs |    19.72 μs |  0.79 |    0.02 |   62.5000 |   46.8750 |         - |   5670.9 KB |        1.75 |
|                   |                      |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** |  **4,517.2 μs** |    **48.68 μs** |    **28.97 μs** |  **0.17** |    **0.01** |         **-** |         **-** |         **-** |   **1019.5 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 |  4,402.4 μs |    18.73 μs |     9.80 μs |  0.17 |    0.01 |         - |         - |         - |    549.8 KB |        0.02 |
| NativeSingle      | Movin(...)gence [34] | 10000 | 25,953.1 μs | 2,315.14 μs | 1,377.70 μs |  1.00 |    0.07 | 1200.0000 | 1000.0000 | 1000.0000 | 31913.71 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 10000 | 29,569.3 μs | 6,756.19 μs | 4,468.80 μs |  1.14 |    0.18 | 1400.0000 | 1200.0000 | 1200.0000 | 56067.36 KB |        1.76 |
