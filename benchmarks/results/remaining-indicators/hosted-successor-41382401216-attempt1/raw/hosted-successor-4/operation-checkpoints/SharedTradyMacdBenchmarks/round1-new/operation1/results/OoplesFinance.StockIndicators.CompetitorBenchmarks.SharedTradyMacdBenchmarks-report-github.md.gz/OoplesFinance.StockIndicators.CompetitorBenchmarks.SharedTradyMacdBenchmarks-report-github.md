```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |   **420.6 μs** |   **6.90 μs** |   **3.61 μs** |  **73.64 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |   400.9 μs |   4.06 μs |   2.12 μs |  26.04 KB |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** | **4,183.1 μs** | **233.94 μs** | **154.73 μs** | **706.87 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 | 4,020.3 μs |  40.79 μs |  24.27 μs | 237.18 KB |
