```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |    **425.8 μs** |     **7.36 μs** |     **3.85 μs** |  **0.19** |    **0.01** |         **-** |         **-** |         **-** |    **73.68 KB** |       **0.022** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |    411.6 μs |     4.80 μs |     2.85 μs |  0.19 |    0.00 |         - |         - |         - |    26.04 KB |       0.008 |
| NativeSingle      | Movin(...)ogram [43] | 1000  |  2,201.1 μs |    86.74 μs |    57.37 μs |  1.00 |    0.04 |   46.8750 |   46.8750 |   46.8750 |  3389.07 KB |       1.000 |
| NativeParallel    | Movin(...)ogram [43] | 1000  |  1,724.7 μs |    90.27 μs |    53.72 μs |  0.78 |    0.03 |   62.5000 |   31.2500 |         - |   5597.5 KB |       1.652 |
|                   |                      |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** |  **4,181.6 μs** |    **92.99 μs** |    **61.51 μs** |  **0.16** |    **0.01** |         **-** |         **-** |         **-** |   **707.02 KB** |       **0.021** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 |  4,136.0 μs |    22.66 μs |    13.49 μs |  0.15 |    0.01 |         - |         - |         - |   237.17 KB |       0.007 |
| NativeSingle      | Movin(...)ogram [43] | 10000 | 26,953.9 μs | 3,259.80 μs | 2,156.15 μs |  1.01 |    0.11 | 1250.0000 | 1250.0000 | 1250.0000 | 33361.17 KB |       1.000 |
| NativeParallel    | Movin(...)ogram [43] | 10000 | 29,708.4 μs | 9,062.46 μs | 5,994.26 μs |  1.11 |    0.23 | 2000.0000 | 1750.0000 | 1750.0000 | 55285.27 KB |       1.657 |
