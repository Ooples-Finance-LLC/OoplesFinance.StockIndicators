```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |   **435.3 μs** |  **5.89 μs** |  **3.50 μs** |  **73.68 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |   418.5 μs |  6.22 μs |  3.26 μs |  26.05 KB |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** | **4,269.4 μs** | **61.48 μs** | **40.66 μs** |    **707 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 | 4,240.9 μs | 60.59 μs | 40.08 μs | 237.15 KB |
