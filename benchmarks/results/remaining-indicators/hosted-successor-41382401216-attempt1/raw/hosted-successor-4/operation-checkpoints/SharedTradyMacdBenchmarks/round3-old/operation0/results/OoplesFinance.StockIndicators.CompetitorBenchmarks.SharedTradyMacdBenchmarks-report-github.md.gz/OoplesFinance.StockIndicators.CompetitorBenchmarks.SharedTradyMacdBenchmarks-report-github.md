```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |   **454.6 μs** |  **4.87 μs** |  **2.55 μs** |  **104.99 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |   438.8 μs |  6.49 μs |  3.86 μs |   57.39 KB |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** | **4,540.2 μs** | **81.89 μs** | **48.73 μs** | **1019.61 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 | 4,463.8 μs | 55.80 μs | 33.21 μs |  549.78 KB |
