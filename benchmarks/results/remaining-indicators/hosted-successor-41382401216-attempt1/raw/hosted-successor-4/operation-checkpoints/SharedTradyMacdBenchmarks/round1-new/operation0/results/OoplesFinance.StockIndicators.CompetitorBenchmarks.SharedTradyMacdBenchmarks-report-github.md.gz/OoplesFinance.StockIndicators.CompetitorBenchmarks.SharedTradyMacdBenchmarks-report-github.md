```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |   **466.5 μs** | **29.37 μs** | **19.43 μs** |  **105.03 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |   447.2 μs | 10.25 μs |  5.36 μs |   57.39 KB |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** | **4,589.0 μs** | **45.57 μs** | **30.14 μs** | **1019.48 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 | 4,456.8 μs | 44.10 μs | 23.07 μs |  549.76 KB |
