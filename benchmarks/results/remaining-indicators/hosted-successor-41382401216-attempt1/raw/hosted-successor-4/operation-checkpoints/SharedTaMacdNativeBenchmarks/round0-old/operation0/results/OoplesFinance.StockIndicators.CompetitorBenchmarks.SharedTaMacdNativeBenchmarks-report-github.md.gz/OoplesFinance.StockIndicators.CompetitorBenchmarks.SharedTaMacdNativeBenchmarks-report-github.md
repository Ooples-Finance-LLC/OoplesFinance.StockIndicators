```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error       | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|------------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **1000**  |   **862.1 μs** |   **221.07 μs** | **146.23 μs** |       **-** |       **-** |  **665.08 KB** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 1000  |   498.0 μs |    31.08 μs |  16.26 μs |       - |       - |  617.46 KB |
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **10000** | **5,181.8 μs** | **1,069.56 μs** | **636.48 μs** | **66.6667** |       **-** | **6140.83 KB** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 10000 | 5,026.7 μs |   526.32 μs | 348.13 μs | 62.5000 | 31.2500 | 5670.75 KB |
