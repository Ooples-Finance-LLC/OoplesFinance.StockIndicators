```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|-----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Macd** | **1000**  |   **351.54 μs** |  **6.172 μs** |  **3.673 μs** | **22.69** |    **0.27** |       **-** |      **-** |   **81.29 KB** |        **2.12** |
| BuilderLatestOnly | TaLib.Functions.Macd | 1000  |   336.03 μs |  2.120 μs |  1.402 μs | 21.69 |    0.17 |       - |      - |   33.64 KB |        0.88 |
| NativeSingle      | TaLib.Functions.Macd | 1000  |    15.49 μs |  0.183 μs |  0.109 μs |  1.00 |    0.01 |  0.3662 |      - |   38.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Macd | 1000  |    29.78 μs |  0.619 μs |  0.409 μs |  1.92 |    0.03 |  1.4648 | 0.2441 |  119.47 KB |        3.12 |
|                   |                      |       |             |           |           |       |         |         |        |            |             |
| **BuilderFull**       | **TaLib.Functions.Macd** | **10000** | **3,507.55 μs** | **35.750 μs** | **23.647 μs** | **24.44** |    **0.24** |       **-** |      **-** |  **784.84 KB** |        **2.01** |
| BuilderLatestOnly | TaLib.Functions.Macd | 10000 | 3,434.08 μs | 52.980 μs | 35.043 μs | 23.93 |    0.30 |       - |      - |  315.04 KB |        0.81 |
| NativeSingle      | TaLib.Functions.Macd | 10000 |   143.50 μs |  1.742 μs |  1.152 μs |  1.00 |    0.01 |  3.9063 | 1.9531 |  389.83 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Macd | 10000 |   238.91 μs |  8.216 μs |  5.434 μs |  1.66 |    0.04 | 13.6719 | 9.7656 | 1209.33 KB |        3.10 |
