```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Macd** | **1000**  |   **344.5 μs** |  **3.40 μs** |  **2.03 μs** |  **81.24 KB** |
| BuilderLatestOnly | TaLib.Functions.Macd | 1000  |   334.1 μs |  5.13 μs |  2.68 μs |  33.64 KB |
| **BuilderFull**       | **TaLib.Functions.Macd** | **10000** | **3,526.2 μs** | **36.77 μs** | **21.88 μs** | **784.83 KB** |
| BuilderLatestOnly | TaLib.Functions.Macd | 10000 | 3,416.1 μs | 30.88 μs | 20.43 μs | 315.07 KB |
