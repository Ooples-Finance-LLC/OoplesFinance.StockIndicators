```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Macd** | **1000**  |   **346.6 μs** |  **2.53 μs** |  **1.50 μs** |  **81.24 KB** |
| BuilderLatestOnly | TaLib.Functions.Macd | 1000  |   336.6 μs |  2.23 μs |  1.33 μs |  33.66 KB |
| **BuilderFull**       | **TaLib.Functions.Macd** | **10000** | **3,539.4 μs** | **84.88 μs** | **44.39 μs** | **784.91 KB** |
| BuilderLatestOnly | TaLib.Functions.Macd | 10000 | 3,557.7 μs | 64.98 μs | 38.67 μs | 315.07 KB |
