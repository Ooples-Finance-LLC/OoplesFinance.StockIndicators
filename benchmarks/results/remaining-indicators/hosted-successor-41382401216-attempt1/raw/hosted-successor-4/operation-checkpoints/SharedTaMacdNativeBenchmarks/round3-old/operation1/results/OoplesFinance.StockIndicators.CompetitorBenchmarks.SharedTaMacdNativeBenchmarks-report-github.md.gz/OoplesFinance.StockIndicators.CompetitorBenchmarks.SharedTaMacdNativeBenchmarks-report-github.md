```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Macd** | **1000**  |   **352.1 μs** |  **5.84 μs** |  **3.48 μs** |  **81.29 KB** |
| BuilderLatestOnly | TaLib.Functions.Macd | 1000  |   335.1 μs |  1.40 μs |  0.84 μs |  33.64 KB |
| **BuilderFull**       | **TaLib.Functions.Macd** | **10000** | **3,638.0 μs** | **65.49 μs** | **43.32 μs** | **784.89 KB** |
| BuilderLatestOnly | TaLib.Functions.Macd | 10000 | 3,440.7 μs | 90.50 μs | 53.85 μs | 315.07 KB |
