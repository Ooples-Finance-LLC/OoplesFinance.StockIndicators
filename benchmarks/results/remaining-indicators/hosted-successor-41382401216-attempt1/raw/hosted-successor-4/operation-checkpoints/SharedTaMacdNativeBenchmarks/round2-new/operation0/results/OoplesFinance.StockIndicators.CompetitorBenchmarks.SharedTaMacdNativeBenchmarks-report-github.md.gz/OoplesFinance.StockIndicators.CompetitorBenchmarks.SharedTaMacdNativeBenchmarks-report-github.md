```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **1000**  |   **829.37 μs** |  **22.327 μs** |  **13.287 μs** | **77.47** |    **1.57** |       **-** |       **-** |  **665.04 KB** |       **17.29** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 1000  |   518.70 μs |  56.538 μs |  37.396 μs | 48.45 |    3.39 |  3.9063 |       - |  617.43 KB |       16.06 |
| NativeSingle      | TaLib(...)cdExt [23] | 1000  |    10.71 μs |   0.225 μs |   0.149 μs |  1.00 |    0.02 |  0.4272 |       - |   38.45 KB |        1.00 |
| NativeParallel    | TaLib(...)cdExt [23] | 1000  |    25.38 μs |   1.400 μs |   0.732 μs |  2.37 |    0.07 |  1.4648 |       - |  120.22 KB |        3.13 |
|                   |                      |       |             |            |            |       |         |         |         |            |             |
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **10000** | **5,053.15 μs** | **555.649 μs** | **367.527 μs** | **55.52** |    **3.98** | **62.5000** | **31.2500** | **6140.48 KB** |       **15.74** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 10000 | 4,929.49 μs | 421.068 μs | 278.510 μs | 54.16 |    3.08 | 62.5000 | 31.2500 | 5670.82 KB |       14.54 |
| NativeSingle      | TaLib(...)cdExt [23] | 10000 |    91.05 μs |   2.641 μs |   1.747 μs |  1.00 |    0.03 |  4.3945 |  1.9531 |  390.02 KB |        1.00 |
| NativeParallel    | TaLib(...)cdExt [23] | 10000 |   195.61 μs |  22.763 μs |  15.056 μs |  2.15 |    0.16 | 14.6484 | 10.7422 | 1210.07 KB |        3.10 |
