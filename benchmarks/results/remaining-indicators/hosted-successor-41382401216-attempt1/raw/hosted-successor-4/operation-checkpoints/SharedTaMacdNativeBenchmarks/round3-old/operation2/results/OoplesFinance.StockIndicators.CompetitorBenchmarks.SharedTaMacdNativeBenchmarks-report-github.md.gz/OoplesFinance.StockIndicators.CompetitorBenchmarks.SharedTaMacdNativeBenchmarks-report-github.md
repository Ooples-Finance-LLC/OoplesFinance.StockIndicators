```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **1000**  |   **360.6 μs** |  **9.38 μs** |  **4.90 μs** |  **81.32 KB** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 1000  |   361.7 μs |  2.67 μs |  1.59 μs |   33.7 KB |
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **10000** | **3,671.3 μs** | **25.70 μs** | **13.44 μs** | **784.99 KB** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 10000 | 3,580.2 μs | 30.90 μs | 16.16 μs | 315.12 KB |
