```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **1000**  |   **370.27 μs** |  **9.934 μs** |  **5.196 μs** | **23.84** |    **0.41** |       **-** |      **-** |   **81.36 KB** |        **2.13** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 1000  |   352.08 μs |  2.634 μs |  1.568 μs | 22.66 |    0.26 |       - |      - |    33.7 KB |        0.88 |
| NativeSingle      | TaLib(...)cdFix [23] | 1000  |    15.54 μs |  0.269 μs |  0.178 μs |  1.00 |    0.02 |  0.3662 |      - |   38.27 KB |        1.00 |
| NativeParallel    | TaLib(...)cdFix [23] | 1000  |    28.93 μs |  1.151 μs |  0.685 μs |  1.86 |    0.05 |  1.4648 | 0.2441 |  119.47 KB |        3.12 |
|                   |                      |       |             |           |           |       |         |         |        |            |             |
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **10000** | **3,674.44 μs** | **35.402 μs** | **21.067 μs** | **25.62** |    **0.28** |       **-** |      **-** |  **784.92 KB** |        **2.01** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 10000 | 3,604.43 μs | 27.599 μs | 18.255 μs | 25.13 |    0.27 |       - |      - |  315.16 KB |        0.81 |
| NativeSingle      | TaLib(...)cdFix [23] | 10000 |   143.43 μs |  2.195 μs |  1.452 μs |  1.00 |    0.01 |  3.9063 | 1.9531 |  389.83 KB |        1.00 |
| NativeParallel    | TaLib(...)cdFix [23] | 10000 |   239.69 μs |  8.919 μs |  5.308 μs |  1.67 |    0.04 | 13.6719 | 9.7656 | 1209.33 KB |        3.10 |
