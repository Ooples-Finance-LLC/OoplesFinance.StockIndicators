```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **1000**  |   **366.4 μs** |  **4.47 μs** |  **2.66 μs** |  **81.32 KB** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 1000  |   352.8 μs |  5.74 μs |  3.00 μs |   33.7 KB |
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **10000** | **3,696.5 μs** | **17.49 μs** | **10.41 μs** | **784.86 KB** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 10000 | 3,585.1 μs | 27.35 μs | 14.30 μs | 315.16 KB |
