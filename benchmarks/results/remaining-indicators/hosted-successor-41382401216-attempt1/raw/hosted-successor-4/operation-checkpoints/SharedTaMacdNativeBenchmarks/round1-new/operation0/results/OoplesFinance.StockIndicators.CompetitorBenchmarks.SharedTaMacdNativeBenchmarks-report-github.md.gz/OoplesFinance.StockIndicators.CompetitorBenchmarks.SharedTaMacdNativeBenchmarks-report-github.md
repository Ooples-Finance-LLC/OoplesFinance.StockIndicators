```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **1000**  |   **795.6 μs** | **151.46 μs** |  **90.13 μs** |       **-** |       **-** |  **665.04 KB** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 1000  |   526.6 μs |  40.79 μs |  26.98 μs |  3.9063 |       - |  617.43 KB |
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **10000** | **5,033.0 μs** | **468.86 μs** | **310.12 μs** | **62.5000** | **31.2500** | **6140.59 KB** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 10000 | 5,055.5 μs | 701.35 μs | 463.90 μs | 62.5000 | 31.2500 | 5670.82 KB |
