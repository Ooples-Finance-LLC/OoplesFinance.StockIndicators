```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **1000**  |   **637.9 μs** | **266.9 μs** | **176.53 μs** |       **-** |       **-** |  **665.04 KB** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 1000  |   538.3 μs | 120.5 μs |  79.69 μs |       - |       - |  617.46 KB |
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **10000** | **4,808.7 μs** | **504.5 μs** | **300.20 μs** |       **-** |       **-** | **6140.92 KB** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 10000 | 4,999.6 μs | 621.8 μs | 411.29 μs | 62.5000 | 31.2500 | 5670.78 KB |
