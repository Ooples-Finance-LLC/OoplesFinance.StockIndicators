```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **1000**  |   **351.2 μs** |  **4.48 μs** |  **2.34 μs** |  **81.36 KB** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 1000  |   339.5 μs |  2.66 μs |  1.58 μs |   33.7 KB |
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **10000** | **3,581.5 μs** | **28.81 μs** | **17.14 μs** | **784.96 KB** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 10000 | 3,480.5 μs | 23.62 μs | 14.05 μs | 315.11 KB |
