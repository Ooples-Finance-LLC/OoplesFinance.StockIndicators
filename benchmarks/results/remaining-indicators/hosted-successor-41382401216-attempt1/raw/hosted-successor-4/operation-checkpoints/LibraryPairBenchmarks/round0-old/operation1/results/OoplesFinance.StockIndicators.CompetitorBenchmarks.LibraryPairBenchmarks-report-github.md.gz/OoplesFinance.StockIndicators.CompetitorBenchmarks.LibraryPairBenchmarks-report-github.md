```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId         | Mean     | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------- |---------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetPvo** | **7.058 ms** | **0.1614 ms** | **0.0961 ms** |  **1.00** |    **0.02** | **290.13 KB** |        **1.00** |
|        |       |                |          |           |           |       |         |           |             |
| **Ooples** | **10000** | **Skender.GetPvo** | **7.912 ms** | **1.8653 ms** | **1.2338 ms** |  **1.02** |    **0.21** | **2855.9 KB** |        **1.00** |
