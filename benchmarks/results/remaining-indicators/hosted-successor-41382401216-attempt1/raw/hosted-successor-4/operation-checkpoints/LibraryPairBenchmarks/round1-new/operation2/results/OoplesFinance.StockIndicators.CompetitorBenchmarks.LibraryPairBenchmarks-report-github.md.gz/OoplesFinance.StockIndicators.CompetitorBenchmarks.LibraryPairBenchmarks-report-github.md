```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId           | Mean      | Error      | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |----------------- |----------:|-----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetRocWb** |  **3.396 ms** |  **0.0659 ms** | **0.0392 ms** |  **1.00** |    **0.02** |  **172.61 KB** |        **1.00** |
|        |       |                  |           |            |           |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetRocWb** | **30.227 ms** | **11.6883 ms** | **6.1132 ms** |  **1.06** |    **0.38** | **1692.48 KB** |        **1.00** |
