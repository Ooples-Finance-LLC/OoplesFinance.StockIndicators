```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean      | Error      | StdDev    | Median   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |----------:|-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skend(...)lysis [22]** |  **4.156 ms** |  **0.0774 ms** | **0.0512 ms** | **4.145 ms** |  **1.00** |    **0.02** |  **298.85 KB** |        **1.00** |
|        |       |                      |           |            |           |          |       |         |            |             |
| **Ooples** | **10000** | **Skend(...)lysis [22]** | **11.710 ms** | **13.4128 ms** | **8.8717 ms** | **6.745 ms** |  **1.48** |    **1.37** | **2876.71 KB** |        **1.00** |
