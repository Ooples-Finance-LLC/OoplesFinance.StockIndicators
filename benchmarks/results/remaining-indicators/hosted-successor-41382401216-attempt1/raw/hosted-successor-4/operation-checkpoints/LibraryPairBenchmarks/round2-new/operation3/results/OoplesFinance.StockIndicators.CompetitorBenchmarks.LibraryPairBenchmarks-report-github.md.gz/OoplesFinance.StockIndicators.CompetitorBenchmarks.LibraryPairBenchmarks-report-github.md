```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean     | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |---------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)ivots [24]** | **1.732 ms** | **0.0700 ms** | **0.0417 ms** |  **1.00** |    **0.03** |   **388.2 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)ivots [24] | 2.273 ms | 0.0977 ms | 0.0581 ms |  1.31 |    0.04 |  738.16 KB |        1.90 |
|            |       |                      |          |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)ivots [24]** | **3.697 ms** | **0.1085 ms** | **0.0646 ms** |  **1.00** |    **0.02** | **3850.13 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)ivots [24] | 8.543 ms | 0.2825 ms | 0.1868 ms |  2.31 |    0.06 | 7319.53 KB |        1.90 |
