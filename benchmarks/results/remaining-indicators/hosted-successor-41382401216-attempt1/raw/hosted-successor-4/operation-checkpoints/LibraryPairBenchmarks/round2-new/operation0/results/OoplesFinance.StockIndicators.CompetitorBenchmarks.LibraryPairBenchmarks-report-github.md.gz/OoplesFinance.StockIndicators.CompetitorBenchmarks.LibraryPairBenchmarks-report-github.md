```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean       | Error    | StdDev    | Ratio | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |--------------- |-----------:|---------:|----------:|------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetPrs** | **4,363.3 μs** | **191.3 μs** | **113.83 μs** |  **1.00** |    **0.04** |  **1079.65 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetPrs |   905.1 μs | 273.7 μs | 181.07 μs |  0.21 |    0.04 |   255.94 KB |        0.24 |
|            |       |                |            |          |           |       |         |             |             |
| **Ooples**     | **10000** | **Skender.GetPrs** | **6,708.5 μs** | **136.0 μs** |  **80.95 μs** |  **1.00** |    **0.02** | **10607.02 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetPrs | 1,322.7 μs | 184.3 μs | 109.67 μs |  0.20 |    0.02 |  2461.71 KB |        0.23 |
