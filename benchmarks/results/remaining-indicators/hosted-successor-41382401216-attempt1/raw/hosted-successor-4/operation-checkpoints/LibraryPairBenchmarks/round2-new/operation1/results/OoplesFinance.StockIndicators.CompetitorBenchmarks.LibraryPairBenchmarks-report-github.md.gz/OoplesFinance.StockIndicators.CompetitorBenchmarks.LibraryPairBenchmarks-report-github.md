```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetPvo** | **7,177.7 μs** | **178.97 μs** | **118.38 μs** |  **1.00** |    **0.02** |  **290.13 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetPvo |   743.8 μs |  91.80 μs |  54.63 μs |  0.10 |    0.01 |  376.24 KB |        1.30 |
|            |       |                |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetPvo** | **6,740.6 μs** | **217.00 μs** | **129.13 μs** |  **1.00** |    **0.03** | **2855.24 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetPvo | 2,086.2 μs | 108.96 μs |  72.07 μs |  0.31 |    0.01 |  3870.7 KB |        1.36 |
