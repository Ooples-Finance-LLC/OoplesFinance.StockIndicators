```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId        | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetT3** |   **790.0 μs** |  **50.89 μs** |  **33.66 μs** |  **1.00** |    **0.06** |  **105.89 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetT3 |   739.9 μs |  71.53 μs |  47.32 μs |  0.94 |    0.07 |  115.37 KB |        1.09 |
|            |       |               |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetT3** | **4,298.6 μs** | **883.99 μs** | **584.71 μs** |  **1.02** |    **0.20** | **1037.23 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetT3 | 1,061.6 μs |  86.32 μs |  51.37 μs |  0.25 |    0.04 | 1073.38 KB |        1.03 |
