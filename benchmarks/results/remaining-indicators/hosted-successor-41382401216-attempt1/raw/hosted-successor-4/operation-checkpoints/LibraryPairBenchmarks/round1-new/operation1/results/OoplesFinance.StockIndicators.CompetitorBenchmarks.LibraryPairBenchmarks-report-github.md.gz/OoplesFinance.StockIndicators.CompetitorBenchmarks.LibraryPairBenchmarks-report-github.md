```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId         | Mean     | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|------- |------ |--------------- |---------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetPvo** | **7.016 ms** | **0.0524 ms** | **0.0312 ms** |  **1.00** |  **290.13 KB** |        **1.00** |
|        |       |                |          |           |           |       |            |             |
| **Ooples** | **10000** | **Skender.GetPvo** | **6.600 ms** | **0.1144 ms** | **0.0598 ms** |  **1.00** | **2855.62 KB** |        **1.00** |
