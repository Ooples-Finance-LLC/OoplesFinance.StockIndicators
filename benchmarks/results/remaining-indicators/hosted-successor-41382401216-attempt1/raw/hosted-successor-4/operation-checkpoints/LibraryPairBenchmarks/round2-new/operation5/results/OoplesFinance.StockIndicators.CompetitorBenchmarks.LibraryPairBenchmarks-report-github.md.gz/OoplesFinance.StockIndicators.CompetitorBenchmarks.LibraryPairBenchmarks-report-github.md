```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean     | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |---------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)Bands [21]** | **1.848 ms** | **0.1082 ms** | **0.0716 ms** |  **1.00** |    **0.05** |  **219.57 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)Bands [21] | 1.088 ms | 0.1276 ms | 0.0844 ms |  0.59 |    0.05 |  419.63 KB |        1.91 |
|            |       |                      |          |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)Bands [21]** | **3.709 ms** | **0.1542 ms** | **0.1020 ms** |  **1.00** |    **0.04** | **2152.86 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)Bands [21] | 1.779 ms | 0.1661 ms | 0.1099 ms |  0.48 |    0.03 | 4100.19 KB |        1.90 |
