```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean     | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |---------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skend(...)Bands [21]** | **1.769 ms** | **0.0679 ms** | **0.0404 ms** |  **1.00** |    **0.03** |  **219.57 KB** |        **1.00** |
|        |       |                      |          |           |           |       |         |            |             |
| **Ooples** | **10000** | **Skend(...)Bands [21]** | **5.193 ms** | **0.1336 ms** | **0.0795 ms** |  **1.00** |    **0.02** | **2152.86 KB** |        **1.00** |
