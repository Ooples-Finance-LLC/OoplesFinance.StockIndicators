```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId          | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetTrix** | **2,753.9 μs** |  **57.12 μs** | **29.87 μs** |  **1.00** |    **0.01** |  **211.15 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetTrix |   811.0 μs | 131.44 μs | 86.94 μs |  0.29 |    0.03 |  203.65 KB |        0.96 |
|            |       |                 |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetTrix** | **3,728.9 μs** | **125.61 μs** | **83.08 μs** |  **1.00** |    **0.03** | **2074.13 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetTrix |   967.9 μs |  56.25 μs | 37.21 μs |  0.26 |    0.01 | 1953.33 KB |        0.94 |
