```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)lysis [22]** | **3,935.1 μs** |  **66.01 μs** |  **39.28 μs** |  **1.00** |    **0.01** |  **298.85 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)lysis [22] |   875.9 μs | 239.13 μs | 142.30 μs |  0.22 |    0.03 |  291.85 KB |        0.98 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)lysis [22]** | **5,533.5 μs** |  **93.71 μs** |  **49.01 μs** |  **1.00** |    **0.01** | **2876.71 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)lysis [22] | 1,424.1 μs |  48.22 μs |  31.89 μs |  0.26 |    0.01 | 2822.49 KB |        0.98 |
