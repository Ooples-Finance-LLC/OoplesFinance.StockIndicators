```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId           | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |----------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetRocWb** | **3,356.9 μs** |  **72.24 μs** |  **42.99 μs** |  **1.00** |    **0.02** |  **172.61 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetRocWb |   755.0 μs |  78.92 μs |  46.97 μs |  0.22 |    0.01 |  275.09 KB |        1.59 |
|            |       |                  |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetRocWb** | **4,101.9 μs** |  **73.52 μs** |  **38.45 μs** |  **1.00** |    **0.01** | **1690.84 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetRocWb | 2,832.6 μs | 729.75 μs | 482.69 μs |  0.69 |    0.11 | 2666.65 KB |        1.58 |
