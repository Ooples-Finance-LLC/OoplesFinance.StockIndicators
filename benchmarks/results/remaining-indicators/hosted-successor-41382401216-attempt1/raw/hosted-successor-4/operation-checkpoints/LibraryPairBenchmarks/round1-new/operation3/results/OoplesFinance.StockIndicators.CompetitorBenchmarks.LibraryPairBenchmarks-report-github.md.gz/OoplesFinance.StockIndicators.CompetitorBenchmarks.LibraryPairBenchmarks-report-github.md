```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean     | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |---------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skend(...)ivots [24]** | **1.800 ms** | **0.0823 ms** | **0.0489 ms** |  **1.00** |    **0.04** |   **388.2 KB** |        **1.00** |
|        |       |                      |          |           |           |       |         |            |             |
| **Ooples** | **10000** | **Skend(...)ivots [24]** | **4.704 ms** | **2.6469 ms** | **1.3844 ms** |  **1.05** |    **0.35** | **3850.13 KB** |        **1.00** |
