```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Skender.GetCci** | **1000**  |   **242.6 μs** |  **20.77 μs** |  **12.36 μs** |  **66.74 KB** |
| BuilderLatestOnly | Skender.GetCci | 1000  |   192.7 μs |  36.43 μs |  24.10 μs |  19.13 KB |
| **BuilderFull**       | **Skender.GetCci** | **10000** | **1,732.0 μs** | **158.14 μs** |  **94.10 μs** | **629.67 KB** |
| BuilderLatestOnly | Skender.GetCci | 10000 | 1,733.5 μs | 238.06 μs | 157.46 μs | 159.88 KB |
