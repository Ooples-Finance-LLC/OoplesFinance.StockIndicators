```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetCci** | **1000**  |   **245.6 μs** |   **5.81 μs** |  **3.46 μs** |  **66.78 KB** |
| BuilderLatestOnly | Skender.GetCci | 1000  |   202.9 μs |  28.03 μs | 18.54 μs |  19.13 KB |
| **BuilderFull**       | **Skender.GetCci** | **10000** | **1,679.8 μs** |  **22.60 μs** | **11.82 μs** | **629.68 KB** |
| BuilderLatestOnly | Skender.GetCci | 10000 | 1,675.3 μs | 160.12 μs | 95.28 μs | 159.84 KB |
