```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Skender.GetCci** | **1000**  |   **230.3 μs** |  **55.12 μs** |  **32.80 μs** |  **66.78 KB** |
| BuilderLatestOnly | Skender.GetCci | 1000  |   181.7 μs |  32.27 μs |  21.34 μs |  19.13 KB |
| **BuilderFull**       | **Skender.GetCci** | **10000** | **1,692.6 μs** |  **48.25 μs** |  **25.24 μs** | **629.69 KB** |
| BuilderLatestOnly | Skender.GetCci | 10000 | 1,755.7 μs | 265.08 μs | 175.34 μs | 159.87 KB |
