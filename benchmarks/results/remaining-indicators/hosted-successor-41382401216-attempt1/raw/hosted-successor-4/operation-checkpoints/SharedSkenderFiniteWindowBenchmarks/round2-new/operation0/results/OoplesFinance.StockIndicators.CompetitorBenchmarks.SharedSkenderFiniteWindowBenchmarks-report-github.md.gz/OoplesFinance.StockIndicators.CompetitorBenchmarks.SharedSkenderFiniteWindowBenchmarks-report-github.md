```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetCci** | **1000**  |   **237.89 μs** |  **41.046 μs** | **24.426 μs** |  **3.01** |    **0.30** |       **-** |       **-** |   **66.78 KB** |        **0.46** |
| BuilderLatestOnly | Skender.GetCci | 1000  |   175.60 μs |  29.273 μs | 19.362 μs |  2.22 |    0.24 |       - |       - |   19.13 KB |        0.13 |
| NativeSingle      | Skender.GetCci | 1000  |    79.08 μs |   2.159 μs |  1.285 μs |  1.00 |    0.02 |  1.4648 |       - |  145.01 KB |        1.00 |
| NativeParallel    | Skender.GetCci | 1000  |    66.16 μs |   3.976 μs |  2.630 μs |  0.84 |    0.03 |  1.9531 |  0.4883 |  162.64 KB |        1.12 |
|                   |                |       |             |            |           |       |         |         |         |            |             |
| **BuilderFull**       | **Skender.GetCci** | **10000** | **1,738.65 μs** | **152.335 μs** | **90.652 μs** |  **2.01** |    **0.10** |       **-** |       **-** |  **629.67 KB** |        **0.44** |
| BuilderLatestOnly | Skender.GetCci | 10000 | 1,603.88 μs |  39.736 μs | 20.783 μs |  1.85 |    0.03 |       - |       - |  159.87 KB |        0.11 |
| NativeSingle      | Skender.GetCci | 10000 |   865.01 μs |  16.081 μs |  9.570 μs |  1.00 |    0.01 | 15.6250 |  7.8125 | 1445.84 KB |        1.00 |
| NativeParallel    | Skender.GetCci | 10000 |   519.20 μs |  46.947 μs | 31.053 μs |  0.60 |    0.03 | 19.5313 | 15.6250 | 1533.76 KB |        1.06 |
