```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |    **57.63 μs** |  **1.042 μs** |  **0.689 μs** |  **0.71** |    **0.01** |  **0.9766** |       **-** |   **88.31 KB** |        **0.50** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |    51.29 μs |  0.772 μs |  0.459 μs |  0.63 |    0.01 |  0.4883 |       - |    40.7 KB |        0.23 |
| NativeSingle      | Skender.GetAdl | 1000  |    81.67 μs |  1.548 μs |  1.024 μs |  1.00 |    0.02 |  1.9531 |  0.4883 |  176.21 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 1000  |   144.88 μs | 10.431 μs |  6.900 μs |  1.77 |    0.08 |  4.8828 |  1.9531 |   449.4 KB |        2.55 |
|                   |                |       |             |           |           |       |         |         |         |            |             |
| **BuilderFull**       | **Skender.GetAdl** | **10000** |   **538.57 μs** |  **6.334 μs** |  **3.769 μs** |  **0.60** |    **0.02** |  **7.8125** |       **-** |   **862.1 KB** |        **0.49** |
| BuilderLatestOnly | Skender.GetAdl | 10000 |   480.10 μs |  5.666 μs |  2.964 μs |  0.53 |    0.02 |  3.9063 |       - |  392.29 KB |        0.22 |
| NativeSingle      | Skender.GetAdl | 10000 |   899.43 μs | 55.104 μs | 32.791 μs |  1.00 |    0.05 | 15.6250 |  7.8125 | 1758.28 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 10000 | 1,396.26 μs | 75.904 μs | 50.206 μs |  1.55 |    0.08 | 54.6875 | 46.8750 | 4474.84 KB |        2.55 |
