```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |  **58.14 μs** |  **1.297 μs** |  **0.858 μs** | **0.9766** |  **88.31 KB** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |  54.00 μs |  1.098 μs |  0.574 μs | 0.4883 |   40.7 KB |
| **BuilderFull**       | **Skender.GetAdl** | **10000** | **554.89 μs** | **20.761 μs** | **12.354 μs** | **7.8125** |  **862.1 KB** |
| BuilderLatestOnly | Skender.GetAdl | 10000 | 500.31 μs | 10.210 μs |  6.076 μs | 3.9063 | 392.29 KB |
