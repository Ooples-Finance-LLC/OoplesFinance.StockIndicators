```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error    | StdDev   | Gen0   | Allocated |
|------------------ |--------------- |------ |----------:|---------:|---------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |  **57.59 μs** | **1.252 μs** | **0.745 μs** | **0.9766** |  **88.31 KB** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |  52.65 μs | 1.305 μs | 0.777 μs | 0.4883 |   40.7 KB |
| **BuilderFull**       | **Skender.GetAdl** | **10000** | **544.04 μs** | **6.374 μs** | **4.216 μs** | **7.8125** |  **862.1 KB** |
| BuilderLatestOnly | Skender.GetAdl | 10000 | 511.23 μs | 4.455 μs | 2.651 μs | 3.9063 | 392.29 KB |
