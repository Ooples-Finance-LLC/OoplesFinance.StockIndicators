```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev   | Gen0   | Allocated |
|------------------ |--------------- |------ |----------:|----------:|---------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |  **57.30 μs** |  **0.665 μs** | **0.348 μs** | **0.9766** |  **88.31 KB** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |  51.61 μs |  0.591 μs | 0.352 μs | 0.4883 |   40.7 KB |
| **BuilderFull**       | **Skender.GetAdl** | **10000** | **556.16 μs** | **16.638 μs** | **9.901 μs** | **7.8125** |  **862.1 KB** |
| BuilderLatestOnly | Skender.GetAdl | 10000 | 499.94 μs |  9.586 μs | 5.705 μs | 3.9063 | 392.28 KB |
