```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |----------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetRocWb** | **1000**  |   **374.26 μs** |   **2.508 μs** |   **1.312 μs** |  **7.03** |    **0.16** |        **-** |        **-** |        **-** |  **105.31 KB** |        **0.46** |
| BuilderLatestOnly | Skender.GetRocWb | 1000  |   385.14 μs |  10.912 μs |   7.218 μs |  7.23 |    0.21 |   1.9531 |        - |        - |   57.71 KB |        0.25 |
| NativeSingle      | Skender.GetRocWb | 1000  |    53.30 μs |   2.154 μs |   1.282 μs |  1.00 |    0.03 |   9.2773 |   1.9531 |        - |  231.09 KB |        1.00 |
| NativeParallel    | Skender.GetRocWb | 1000  |   109.56 μs |   8.811 μs |   5.828 μs |  2.06 |    0.11 |  24.4141 |   7.8125 |        - |  586.66 KB |        2.54 |
|                   |                  |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetRocWb** | **10000** | **4,059.45 μs** |  **41.319 μs** |  **24.588 μs** |  **4.24** |    **0.07** |  **31.2500** |        **-** |        **-** | **1019.96 KB** |        **0.44** |
| BuilderLatestOnly | Skender.GetRocWb | 10000 | 3,835.55 μs |  35.351 μs |  18.489 μs |  4.00 |    0.06 |        - |        - |        - |  550.12 KB |        0.24 |
| NativeSingle      | Skender.GetRocWb | 10000 |   958.45 μs |  27.423 μs |  14.343 μs |  1.00 |    0.02 | 148.4375 | 148.4375 | 148.4375 | 2306.53 KB |        1.00 |
| NativeParallel    | Skender.GetRocWb | 10000 | 3,038.82 μs | 313.261 μs | 207.203 μs |  3.17 |    0.21 | 406.2500 | 375.0000 | 234.3750 | 5845.23 KB |        2.53 |
