```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |----------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetRocWb** | **1000**  |   **355.2 μs** |  **5.99 μs** |  **3.13 μs** |       **-** |  **105.31 KB** |
| BuilderLatestOnly | Skender.GetRocWb | 1000  |   348.7 μs |  1.39 μs |  0.73 μs |  1.9531 |   57.71 KB |
| **BuilderFull**       | **Skender.GetRocWb** | **10000** | **3,863.2 μs** | **47.67 μs** | **24.93 μs** | **31.2500** | **1019.96 KB** |
| BuilderLatestOnly | Skender.GetRocWb | 10000 | 3,767.7 μs | 42.96 μs | 25.57 μs |       - |  550.12 KB |
