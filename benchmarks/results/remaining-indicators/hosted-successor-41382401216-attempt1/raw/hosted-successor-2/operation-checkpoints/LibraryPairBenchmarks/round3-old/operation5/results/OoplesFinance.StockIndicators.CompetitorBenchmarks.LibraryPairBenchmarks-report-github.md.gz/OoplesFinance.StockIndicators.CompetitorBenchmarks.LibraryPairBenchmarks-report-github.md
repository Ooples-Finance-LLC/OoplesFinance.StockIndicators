```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId        | Mean     | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |-------------- |---------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **QuanTAlib.Wma** | **201.8 μs** |  **22.84 μs** | **11.95 μs** |  **1.00** |    **0.08** |  **65.77 KB** |        **1.00** |
|        |       |               |          |           |          |       |         |           |             |
| **Ooples** | **10000** | **QuanTAlib.Wma** | **460.8 μs** | **144.78 μs** | **95.76 μs** |  **1.03** |    **0.27** |  **636.1 KB** |        **1.00** |
