```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId          | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0      | Allocated | Alloc Ratio |
|----------- |------ |---------------- |----------:|----------:|----------:|------:|--------:|----------:|----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetBeta** | **10.668 ms** | **0.1331 ms** | **0.0792 ms** |  **1.00** |    **0.01** |         **-** |   **1.56 MB** |        **1.00** |
| Competitor | 1000  | Skender.GetBeta |  2.115 ms | 0.0587 ms | 0.0349 ms |  0.20 |    0.00 |         - |   2.66 MB |        1.70 |
|            |       |                 |           |           |           |       |         |           |           |             |
| **Ooples**     | **10000** | **Skender.GetBeta** | **24.744 ms** | **7.8970 ms** | **5.2234 ms** |  **1.05** |    **0.34** |         **-** |  **15.74 MB** |        **1.00** |
| Competitor | 10000 | Skender.GetBeta |  8.574 ms | 0.2019 ms | 0.1056 ms |  0.36 |    0.09 | 1000.0000 |  26.89 MB |        1.71 |
