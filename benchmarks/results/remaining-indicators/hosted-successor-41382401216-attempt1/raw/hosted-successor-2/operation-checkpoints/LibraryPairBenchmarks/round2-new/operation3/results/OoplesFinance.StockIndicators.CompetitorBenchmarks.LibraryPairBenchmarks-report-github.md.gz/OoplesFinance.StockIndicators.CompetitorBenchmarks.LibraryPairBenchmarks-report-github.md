```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId        | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Rma** |   **377.0 μs** |  **36.36 μs** |  **21.64 μs** |  **1.00** |    **0.07** |   **97.58 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Rma |   210.4 μs |  27.90 μs |  16.60 μs |  0.56 |    0.05 |   54.77 KB |        0.56 |
|            |       |               |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Rma** | **9,510.3 μs** | **764.30 μs** | **454.83 μs** |  **1.00** |    **0.06** | **5245.35 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Rma | 1,374.9 μs | 100.92 μs |  60.05 μs |  0.14 |    0.01 |  476.65 KB |        0.09 |
