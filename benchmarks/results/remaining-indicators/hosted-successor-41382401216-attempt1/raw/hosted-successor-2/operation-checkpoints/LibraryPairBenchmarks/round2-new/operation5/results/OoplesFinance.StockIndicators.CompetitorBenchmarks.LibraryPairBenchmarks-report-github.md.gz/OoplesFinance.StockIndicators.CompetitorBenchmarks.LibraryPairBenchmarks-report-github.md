```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId        | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Wma** |   **189.1 μs** |  **21.71 μs** |  **14.36 μs** |  **1.01** |    **0.10** |   **65.77 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Wma |   557.1 μs |  34.17 μs |  22.60 μs |  2.96 |    0.24 |  262.55 KB |        3.99 |
|            |       |               |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Wma** |   **231.6 μs** |  **55.85 μs** |  **33.24 μs** |  **1.02** |    **0.19** |  **635.49 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Wma | 1,308.9 μs | 371.00 μs | 245.39 μs |  5.75 |    1.26 | 2572.04 KB |        4.05 |
