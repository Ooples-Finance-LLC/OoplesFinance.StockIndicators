```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)gence [50]** |  **3.412 ms** | **0.0508 ms** | **0.0303 ms** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |   **290.13 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)gence [50] |  6.912 ms | 0.1404 ms | 0.0929 ms |  2.03 |    0.03 |         - |         - |         - |  4583.87 KB |       15.80 |
|            |       |                      |           |           |           |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)gence [50]** | **11.933 ms** | **3.1411 ms** | **1.6428 ms** |  **1.01** |    **0.17** |         **-** |         **-** |         **-** |  **2856.88 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)gence [50] | 25.400 ms | 3.7792 ms | 2.4997 ms |  2.16 |    0.30 | 1000.0000 | 1000.0000 | 1000.0000 | 34692.48 KB |       12.14 |
