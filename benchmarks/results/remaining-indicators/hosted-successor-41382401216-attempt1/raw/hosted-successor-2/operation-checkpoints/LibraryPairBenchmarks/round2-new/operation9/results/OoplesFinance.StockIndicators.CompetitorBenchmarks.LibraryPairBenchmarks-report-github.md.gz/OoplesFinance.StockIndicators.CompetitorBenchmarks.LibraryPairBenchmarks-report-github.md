```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean         | Error       | StdDev      | Ratio  | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |-------------:|------------:|------------:|-------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)erage [40]** |     **217.2 μs** |    **10.08 μs** |     **5.27 μs** |   **1.00** |    **0.03** |    **64.76 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)erage [40] |  22,595.1 μs | 2,209.81 μs | 1,461.65 μs | 104.08 |    6.87 |  1489.11 KB |       23.00 |
|            |       |                      |              |             |             |        |         |             |             |
| **Ooples**     | **10000** | **Trady(...)erage [40]** |   **2,163.8 μs** |   **285.01 μs** |   **149.06 μs** |   **1.00** |    **0.09** |   **636.07 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)erage [40] | 232,526.5 μs | 8,387.64 μs | 5,547.90 μs | 107.88 |    7.01 | 13293.03 KB |       20.90 |
