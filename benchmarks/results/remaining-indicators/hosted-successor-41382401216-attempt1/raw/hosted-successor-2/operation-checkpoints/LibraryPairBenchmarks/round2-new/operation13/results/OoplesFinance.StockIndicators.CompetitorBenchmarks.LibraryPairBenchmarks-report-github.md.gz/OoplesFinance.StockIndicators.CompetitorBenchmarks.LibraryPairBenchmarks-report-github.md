```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error      | StdDev     | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |----------:|-----------:|-----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)ogram [59]** |  **3.424 ms** |  **0.0259 ms** |  **0.0154 ms** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |   **240.77 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)ogram [59] |  7.429 ms |  0.5639 ms |  0.2950 ms |  2.17 |    0.08 |         - |         - |         - |     4824 KB |       20.04 |
|            |       |                      |           |            |            |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)ogram [59]** | **23.814 ms** | **23.0037 ms** | **15.2155 ms** |  **1.81** |    **2.09** |         **-** |         **-** |         **-** |  **2368.12 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)ogram [59] | 27.023 ms |  3.1856 ms |  1.6661 ms |  2.06 |    1.73 | 1000.0000 | 1000.0000 | 1000.0000 | 36353.51 KB |       15.35 |
