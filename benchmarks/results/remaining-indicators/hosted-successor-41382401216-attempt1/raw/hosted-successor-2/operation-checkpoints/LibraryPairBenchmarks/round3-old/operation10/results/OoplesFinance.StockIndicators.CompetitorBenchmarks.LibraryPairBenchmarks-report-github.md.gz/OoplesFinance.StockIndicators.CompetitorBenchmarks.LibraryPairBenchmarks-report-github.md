```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Trady(...)lator [50]** |   **611.0 μs** |  **53.85 μs** |  **35.62 μs** |  **1.00** |    **0.08** |  **105.64 KB** |        **1.00** |
|        |       |                      |            |           |           |       |         |            |             |
| **Ooples** | **10000** | **Trady(...)lator [50]** | **4,168.8 μs** | **207.03 μs** | **123.20 μs** |  **1.00** |    **0.04** | **1037.96 KB** |        **1.00** |
