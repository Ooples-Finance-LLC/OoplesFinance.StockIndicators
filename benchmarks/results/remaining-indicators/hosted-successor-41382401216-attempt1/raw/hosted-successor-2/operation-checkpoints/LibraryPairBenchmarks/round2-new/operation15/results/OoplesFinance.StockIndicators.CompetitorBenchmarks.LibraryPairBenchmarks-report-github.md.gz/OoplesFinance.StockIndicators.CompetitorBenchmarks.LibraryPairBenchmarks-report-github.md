```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio  | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|-------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)erage [37]** |    **236.5 μs** |    **23.47 μs** |    **15.52 μs** |   **1.00** |    **0.09** |   **65.77 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)erage [37] |  5,605.7 μs |   171.65 μs |    89.78 μs |  23.79 |    1.57 |  913.82 KB |       13.89 |
|            |       |                      |             |             |             |        |         |            |             |
| **Ooples**     | **10000** | **Trady(...)erage [37]** |    **341.8 μs** |    **75.93 μs** |    **45.18 μs** |   **1.01** |    **0.17** |  **637.09 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)erage [37] | 36,105.0 μs | 5,573.12 μs | 2,914.85 μs | 107.16 |   14.91 | 8327.48 KB |       13.07 |
