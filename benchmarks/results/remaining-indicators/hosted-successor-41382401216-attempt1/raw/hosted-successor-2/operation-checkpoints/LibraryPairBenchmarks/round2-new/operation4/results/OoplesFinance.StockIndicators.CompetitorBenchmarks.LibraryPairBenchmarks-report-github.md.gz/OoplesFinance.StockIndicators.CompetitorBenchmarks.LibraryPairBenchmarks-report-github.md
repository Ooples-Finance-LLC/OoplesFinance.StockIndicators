```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId       | Mean       | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------- |-----------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.T3** |   **889.2 μs** |    **46.28 μs** |    **30.61 μs** |  **1.00** |    **0.05** |  **105.89 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.T3 |   309.4 μs |    17.79 μs |    10.58 μs |  0.35 |    0.02 |      74 KB |        0.70 |
|            |       |              |            |             |             |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.T3** | **7,074.7 μs** | **4,369.50 μs** | **2,890.15 μs** |  **1.21** |    **0.77** | **1037.23 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.T3 |   838.3 μs |    54.09 μs |    35.78 μs |  0.14 |    0.07 |  645.05 KB |        0.62 |
