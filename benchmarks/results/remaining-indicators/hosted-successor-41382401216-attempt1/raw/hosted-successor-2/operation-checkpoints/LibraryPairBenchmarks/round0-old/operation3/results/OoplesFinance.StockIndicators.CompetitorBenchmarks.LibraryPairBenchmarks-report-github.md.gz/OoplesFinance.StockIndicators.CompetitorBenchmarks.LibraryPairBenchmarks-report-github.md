```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId        | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |-------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **QuanTAlib.Rma** |   **376.6 μs** |  **35.02 μs** |  **20.84 μs** |  **1.00** |    **0.07** |   **97.58 KB** |        **1.00** |
|        |       |               |            |           |           |       |         |            |             |
| **Ooples** | **10000** | **QuanTAlib.Rma** | **8,831.4 μs** | **705.69 μs** | **369.09 μs** |  **1.00** |    **0.05** | **5245.63 KB** |        **1.00** |
