```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)Index [37]** |   **1.970 ms** | **0.0265 ms** | **0.0139 ms** |  **1.00** |    **0.01** |         **-** |   **108.34 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)Index [37] |  42.298 ms | 0.2476 ms | 0.1295 ms | 21.47 |    0.16 |         - |  4766.78 KB |       44.00 |
|            |       |                      |            |           |           |       |         |           |             |             |
| **Ooples**     | **10000** | **Trady(...)Index [37]** |   **3.565 ms** | **0.5843 ms** | **0.3056 ms** |  **1.01** |    **0.13** |         **-** |     **1040 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)Index [37] | 129.575 ms | 2.6051 ms | 1.5502 ms | 36.64 |    3.63 | 1000.0000 | 48259.56 KB |       46.40 |
