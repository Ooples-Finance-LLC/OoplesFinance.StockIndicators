```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean      | Error      | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |----------:|-----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Trady(...)gence [50]** |  **3.752 ms** |  **0.0240 ms** | **0.0143 ms** |  **1.00** |    **0.01** |  **290.13 KB** |        **1.00** |
|        |       |                      |           |            |           |       |         |            |             |
| **Ooples** | **10000** | **Trady(...)gence [50]** | **32.485 ms** | **13.4628 ms** | **8.9048 ms** |  **1.11** |    **0.55** | **2857.21 KB** |        **1.00** |
