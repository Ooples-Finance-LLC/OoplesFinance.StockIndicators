```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev    | Ratio | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|----------:|------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)lator [45]** |    **610.4 μs** |    **40.72 μs** |  **21.30 μs** |  **1.00** |    **0.05** |   **107.88 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)lator [45] |  5,060.5 μs |   294.18 μs | 175.06 μs |  8.30 |    0.39 |  1702.57 KB |       15.78 |
|            |       |                      |             |             |           |       |         |             |             |
| **Ooples**     | **10000** | **Trady(...)lator [45]** |  **2,119.9 μs** |    **60.57 μs** |  **36.04 μs** |  **1.00** |    **0.02** |  **1039.87 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)lator [45] | 13,377.9 μs | 1,155.17 μs | 604.18 μs |  6.31 |    0.29 | 13490.08 KB |       12.97 |
