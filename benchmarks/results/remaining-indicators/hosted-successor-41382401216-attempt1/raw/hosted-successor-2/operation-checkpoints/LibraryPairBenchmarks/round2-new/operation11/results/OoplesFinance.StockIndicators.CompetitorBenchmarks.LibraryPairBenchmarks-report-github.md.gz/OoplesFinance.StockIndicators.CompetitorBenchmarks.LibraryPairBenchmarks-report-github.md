```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)nnels [31]** |  **1.987 ms** | **0.0520 ms** | **0.0310 ms** |  **1.00** |    **0.02** |         **-** |         **-** |         **-** |   **219.01 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)nnels [31] |  6.122 ms | 0.1878 ms | 0.1117 ms |  3.08 |    0.07 |         - |         - |         - |  3955.23 KB |       18.06 |
|            |       |                      |           |           |           |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)nnels [31]** | **13.102 ms** | **0.0875 ms** | **0.0521 ms** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |  **2153.28 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)nnels [31] | 24.632 ms | 5.4885 ms | 3.2661 ms |  1.88 |    0.24 | 1000.0000 | 1000.0000 | 1000.0000 | 32626.14 KB |       15.15 |
