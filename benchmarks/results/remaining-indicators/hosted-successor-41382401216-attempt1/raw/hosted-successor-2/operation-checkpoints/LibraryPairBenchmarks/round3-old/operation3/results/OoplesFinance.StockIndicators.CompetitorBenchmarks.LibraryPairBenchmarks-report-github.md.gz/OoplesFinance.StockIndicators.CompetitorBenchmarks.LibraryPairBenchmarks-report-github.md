```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId        | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |-------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **QuanTAlib.Rma** |   **394.3 μs** |  **39.22 μs** | **25.94 μs** |  **1.00** |    **0.09** |   **97.58 KB** |        **1.00** |
|        |       |               |            |           |          |       |         |            |             |
| **Ooples** | **10000** | **QuanTAlib.Rma** | **9,046.1 μs** | **167.97 μs** | **87.85 μs** |  **1.00** |    **0.01** | **5245.96 KB** |        **1.00** |
