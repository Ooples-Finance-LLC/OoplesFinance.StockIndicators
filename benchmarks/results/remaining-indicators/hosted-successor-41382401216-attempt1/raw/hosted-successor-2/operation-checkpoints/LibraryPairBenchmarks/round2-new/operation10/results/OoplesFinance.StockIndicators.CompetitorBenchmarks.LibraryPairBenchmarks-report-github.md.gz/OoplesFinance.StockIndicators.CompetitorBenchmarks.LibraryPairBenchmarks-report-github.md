```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)lator [50]** |    **726.9 μs** |    **51.92 μs** |    **34.34 μs** |  **1.00** |    **0.06** |         **-** |         **-** |         **-** |   **105.64 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)lator [50] |  5,061.2 μs |   124.24 μs |    82.18 μs |  6.98 |    0.32 |         - |         - |         - |  3073.71 KB |       29.10 |
|            |       |                      |             |             |             |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)lator [50]** |  **4,126.7 μs** |    **92.69 μs** |    **55.16 μs** |  **1.00** |    **0.02** |         **-** |         **-** |         **-** |  **1037.96 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)lator [50] | 24,745.5 μs | 7,640.73 μs | 4,546.88 μs |  6.00 |    1.05 | 1000.0000 | 1000.0000 | 1000.0000 | 24971.13 KB |       24.06 |
