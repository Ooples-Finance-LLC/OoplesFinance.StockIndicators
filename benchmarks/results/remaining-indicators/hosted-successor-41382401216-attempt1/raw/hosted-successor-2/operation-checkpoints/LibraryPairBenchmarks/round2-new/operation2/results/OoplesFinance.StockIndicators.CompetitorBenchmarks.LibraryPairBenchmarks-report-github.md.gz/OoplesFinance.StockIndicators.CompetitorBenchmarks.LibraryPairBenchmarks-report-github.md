```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------- |-----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Fwma** |   **509.5 μs** |  **41.48 μs** | **24.68 μs** |  **1.00** |    **0.06** |  **15.98 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Fwma |   570.4 μs |  30.26 μs | 18.01 μs |  1.12 |    0.06 | 260.44 KB |       16.30 |
|            |       |                |            |           |          |       |         |           |             |
| **Ooples**     | **10000** | **QuanTAlib.Fwma** |   **693.6 μs** |  **30.48 μs** | **18.14 μs** |  **1.00** |    **0.03** | **164.43 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Fwma | 1,060.7 μs | 149.23 μs | 98.70 μs |  1.53 |    0.14 | 2572.5 KB |       15.64 |
