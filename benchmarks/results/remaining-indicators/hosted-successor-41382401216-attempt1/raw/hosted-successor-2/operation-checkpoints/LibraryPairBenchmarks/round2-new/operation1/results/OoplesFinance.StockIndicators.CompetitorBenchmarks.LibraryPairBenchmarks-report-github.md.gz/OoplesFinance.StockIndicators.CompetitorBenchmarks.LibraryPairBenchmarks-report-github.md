```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------- |-----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Dwma** |   **360.0 μs** |  **21.34 μs** | **14.12 μs** |  **1.00** |    **0.05** |  **66.41 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Dwma |   969.7 μs |  29.77 μs | 19.69 μs |  2.70 |    0.11 | 548.34 KB |        8.26 |
|            |       |                |            |           |          |       |         |           |             |
| **Ooples**     | **10000** | **QuanTAlib.Dwma** |   **726.9 μs** |  **37.01 μs** | **19.36 μs** |  **1.00** |    **0.04** | **637.06 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Dwma | 2,121.6 μs | 190.01 μs | 99.38 μs |  2.92 |    0.15 | 5447.2 KB |        8.55 |
