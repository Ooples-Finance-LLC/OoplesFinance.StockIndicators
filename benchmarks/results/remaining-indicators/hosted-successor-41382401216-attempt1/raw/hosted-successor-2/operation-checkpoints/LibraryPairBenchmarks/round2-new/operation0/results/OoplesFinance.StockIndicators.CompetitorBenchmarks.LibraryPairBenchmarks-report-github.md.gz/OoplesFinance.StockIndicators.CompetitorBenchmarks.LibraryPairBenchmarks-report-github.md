```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId           | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |----------------- |-----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Afirma** |   **628.4 μs** |  **31.32 μs** | **20.72 μs** |  **1.00** |    **0.04** |  **24.68 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Afirma | 1,075.0 μs |  29.70 μs | 15.53 μs |  1.71 |    0.06 |  56.05 KB |        2.27 |
|            |       |                  |            |           |          |       |         |           |             |
| **Ooples**     | **10000** | **QuanTAlib.Afirma** | **1,166.1 μs** |  **76.66 μs** | **50.70 μs** |  **1.00** |    **0.06** | **243.45 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Afirma | 1,779.1 μs | 105.84 μs | 62.98 μs |  1.53 |    0.08 | 477.93 KB |        1.96 |
