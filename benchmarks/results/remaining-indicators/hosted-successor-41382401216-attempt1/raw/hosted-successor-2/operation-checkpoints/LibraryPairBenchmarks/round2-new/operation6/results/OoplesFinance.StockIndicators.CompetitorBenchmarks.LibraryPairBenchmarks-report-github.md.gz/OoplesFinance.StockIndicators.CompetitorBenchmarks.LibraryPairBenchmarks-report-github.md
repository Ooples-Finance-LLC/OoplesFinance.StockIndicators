```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAdl** |   **691.5 μs** |    **59.51 μs** |  **35.41 μs** |  **1.00** |    **0.07** |  **246.88 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAdl |   498.5 μs |    24.30 μs |  14.46 μs |  0.72 |    0.04 |  274.31 KB |        1.11 |
|            |       |                |            |             |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAdl** | **6,708.3 μs** | **1,345.07 μs** | **889.68 μs** |  **1.02** |    **0.18** | **2814.32 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAdl | 2,227.3 μs |    53.96 μs |  32.11 μs |  0.34 |    0.04 | 2655.54 KB |        0.94 |
