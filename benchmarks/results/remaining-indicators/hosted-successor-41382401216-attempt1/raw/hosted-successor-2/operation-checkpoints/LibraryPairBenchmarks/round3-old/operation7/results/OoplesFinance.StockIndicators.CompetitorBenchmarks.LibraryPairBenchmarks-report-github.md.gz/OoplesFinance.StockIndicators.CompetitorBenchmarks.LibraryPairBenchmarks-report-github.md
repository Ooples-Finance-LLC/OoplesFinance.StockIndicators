```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId          | Mean     | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |---------------- |---------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetBeta** | **11.95 ms** | **2.789 ms** | **1.845 ms** |  **1.02** |    **0.20** |   **1.56 MB** |        **1.00** |
|        |       |                 |          |          |          |       |         |           |             |
| **Ooples** | **10000** | **Skender.GetBeta** | **24.04 ms** | **9.189 ms** | **6.078 ms** |  **1.07** |    **0.39** |  **15.71 MB** |        **1.00** |
