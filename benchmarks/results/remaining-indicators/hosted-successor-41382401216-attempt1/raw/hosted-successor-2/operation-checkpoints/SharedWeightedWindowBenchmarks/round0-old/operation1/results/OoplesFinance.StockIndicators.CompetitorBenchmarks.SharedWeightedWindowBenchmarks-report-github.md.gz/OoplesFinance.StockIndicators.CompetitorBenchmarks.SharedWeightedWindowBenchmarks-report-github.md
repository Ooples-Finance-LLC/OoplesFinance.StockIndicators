```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |---------- |------ |-----------:|----------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Dwma**      | **1000**  |   **157.7 μs** |  **27.48 μs** |  **18.17 μs** |  **3.9063** |       **-** |   **173.3 KB** |
| BuilderLatestOnly | Dwma      | 1000  |   130.6 μs |  29.28 μs |  19.37 μs |  4.8828 |       - |  125.63 KB |
| **BuilderFull**       | **Dwma**      | **10000** | **1,068.9 μs** | **193.87 μs** | **115.37 μs** | **62.5000** | **46.8750** | **1609.03 KB** |
| BuilderLatestOnly | Dwma      | 10000 | 1,064.6 μs | 180.97 μs | 107.69 μs | 39.0625 |  7.8125 | 1139.19 KB |
