```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Wma**       | **1000**  |  **21.41 μs** |  **2.639 μs** |  **1.746 μs** |  **1.9531** |       **-** |  **58.45 KB** |
| BuilderLatestOnly | Wma       | 1000  |  13.17 μs |  1.962 μs |  1.298 μs |  0.3662 |       - |  10.56 KB |
| **BuilderFull**       | **Wma**       | **10000** | **110.29 μs** | **17.516 μs** | **10.423 μs** | **21.4844** | **11.7188** | **550.98 KB** |
| BuilderLatestOnly | Wma       | 10000 | 103.27 μs | 23.612 μs | 15.618 μs |  2.9297 |       - |  80.88 KB |
