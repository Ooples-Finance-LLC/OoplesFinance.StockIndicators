```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Wma**       | **1000**  |  **21.21 μs** |  **3.576 μs** |  **2.365 μs** |  **1.9531** |       **-** |  **58.45 KB** |
| BuilderLatestOnly | Wma       | 1000  |  14.25 μs |  2.477 μs |  1.639 μs |  0.3662 |       - |  10.56 KB |
| **BuilderFull**       | **Wma**       | **10000** | **116.46 μs** | **20.956 μs** | **13.861 μs** | **21.4844** | **11.7188** | **550.98 KB** |
| BuilderLatestOnly | Wma       | 10000 | 115.22 μs | 18.101 μs | 11.973 μs |  2.9297 |       - |  80.88 KB |
