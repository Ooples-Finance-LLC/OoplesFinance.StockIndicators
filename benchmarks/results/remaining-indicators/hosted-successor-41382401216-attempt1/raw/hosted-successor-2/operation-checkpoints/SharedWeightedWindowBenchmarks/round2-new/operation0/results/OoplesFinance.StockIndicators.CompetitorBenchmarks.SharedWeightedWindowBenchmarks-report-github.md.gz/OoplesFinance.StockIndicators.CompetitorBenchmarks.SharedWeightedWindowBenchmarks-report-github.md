```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |---------- |------ |----------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Wma**       | **1000**  |  **19.55 μs** |  **1.531 μs** |  **0.911 μs** |  **0.24** |    **0.01** |   **1.9531** |       **-** |   **58.45 KB** |        **0.23** |
| BuilderLatestOnly | Wma       | 1000  |  13.17 μs |  1.188 μs |  0.707 μs |  0.16 |    0.01 |   0.3662 |       - |   10.56 KB |        0.04 |
| NativeSingle      | Wma       | 1000  |  81.59 μs |  4.736 μs |  3.133 μs |  1.00 |    0.05 |  10.2539 |       - |  254.32 KB |        1.00 |
| NativeParallel    | Wma       | 1000  |  78.78 μs |  2.134 μs |  1.412 μs |  0.97 |    0.04 |  10.7422 |       - |  261.98 KB |        1.03 |
|                   |           |       |           |           |           |       |         |          |         |            |             |
| **BuilderFull**       | **Wma**       | **10000** | **123.86 μs** | **19.653 μs** | **13.000 μs** |  **0.15** |    **0.01** |  **21.4844** |  **8.7891** |  **550.98 KB** |        **0.21** |
| BuilderLatestOnly | Wma       | 10000 |  95.37 μs |  7.399 μs |  4.894 μs |  0.11 |    0.01 |   2.9297 |  0.4883 |   80.88 KB |        0.03 |
| NativeSingle      | Wma       | 10000 | 841.87 μs | 27.225 μs | 16.201 μs |  1.00 |    0.03 | 101.5625 | 15.6250 | 2564.15 KB |        1.00 |
| NativeParallel    | Wma       | 10000 | 523.94 μs | 38.681 μs | 25.585 μs |  0.62 |    0.03 | 105.4688 | 19.5313 | 2571.95 KB |        1.00 |
