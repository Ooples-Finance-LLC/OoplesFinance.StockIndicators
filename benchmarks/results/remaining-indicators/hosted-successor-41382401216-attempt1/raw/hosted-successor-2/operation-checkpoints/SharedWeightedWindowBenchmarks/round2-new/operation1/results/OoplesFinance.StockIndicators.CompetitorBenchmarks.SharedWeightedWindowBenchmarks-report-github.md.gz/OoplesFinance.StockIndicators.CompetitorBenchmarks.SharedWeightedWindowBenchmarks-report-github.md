```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error     | StdDev   | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |---------- |------ |-----------:|----------:|---------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Dwma**      | **1000**  |   **169.1 μs** |  **16.15 μs** | **10.68 μs** |  **0.92** |    **0.06** |   **3.9063** |       **-** |  **173.26 KB** |        **0.32** |
| BuilderLatestOnly | Dwma      | 1000  |   129.7 μs |  27.43 μs | 18.14 μs |  0.71 |    0.10 |   4.8828 |       - |  125.63 KB |        0.23 |
| NativeSingle      | Dwma      | 1000  |   183.4 μs |   7.25 μs |  4.80 μs |  1.00 |    0.04 |  21.4844 |       - |  540.12 KB |        1.00 |
| NativeParallel    | Dwma      | 1000  |   164.1 μs |   5.07 μs |  3.35 μs |  0.89 |    0.03 |  23.4375 |  0.9766 |  588.75 KB |        1.09 |
|                   |           |       |            |           |          |       |         |          |         |            |             |
| **BuilderFull**       | **Dwma**      | **10000** | **1,078.0 μs** | **103.05 μs** | **68.16 μs** |  **0.58** |    **0.04** |  **62.5000** | **23.4375** | **1609.03 KB** |        **0.30** |
| BuilderLatestOnly | Dwma      | 10000 | 1,052.1 μs | 130.28 μs | 86.17 μs |  0.57 |    0.05 |  39.0625 |  7.8125 | 1139.19 KB |        0.21 |
| NativeSingle      | Dwma      | 10000 | 1,857.6 μs | 113.94 μs | 75.37 μs |  1.00 |    0.05 | 218.7500 | 31.2500 | 5441.01 KB |        1.00 |
| NativeParallel    | Dwma      | 10000 | 1,209.6 μs | 122.43 μs | 80.98 μs |  0.65 |    0.05 | 218.7500 | 39.0625 | 5489.94 KB |        1.01 |
