```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |------ |-----------:|----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **1000**  |   **286.9 μs** |  **89.23 μs** |  **59.02 μs** |  **0.59** |    **0.12** |        **-** |        **-** |  **128.45 KB** |        **0.26** |
| BuilderLatestOnly | 1000  |   221.7 μs |  41.89 μs |  27.71 μs |  0.46 |    0.05 |   1.9531 |        - |   80.85 KB |        0.16 |
| NativeSingle      | 1000  |   485.2 μs |   9.57 μs |   5.01 μs |  1.00 |    0.01 |  19.5313 |   3.9063 |  499.63 KB |        1.00 |
| NativeParallel    | 1000  |   320.8 μs |  23.99 μs |  15.87 μs |  0.66 |    0.03 |  21.4844 |   5.8594 |  525.32 KB |        1.05 |
|                   |       |            |           |           |       |         |          |          |            |             |
| **BuilderFull**       | **10000** | **1,747.3 μs** | **142.74 μs** |  **74.66 μs** |  **0.35** |    **0.01** |  **46.8750** |  **15.6250** | **1183.61 KB** |        **0.24** |
| BuilderLatestOnly | 10000 | 1,903.1 μs | 478.41 μs | 316.44 μs |  0.38 |    0.06 |  15.6250 |        - |  713.79 KB |        0.14 |
| NativeSingle      | 10000 | 5,058.7 μs | 118.70 μs |  70.64 μs |  1.00 |    0.02 | 187.5000 |  93.7500 | 5035.01 KB |        1.00 |
| NativeParallel    | 10000 | 2,990.4 μs | 260.46 μs | 172.28 μs |  0.59 |    0.03 | 203.1250 | 125.0000 | 5130.95 KB |        1.02 |
