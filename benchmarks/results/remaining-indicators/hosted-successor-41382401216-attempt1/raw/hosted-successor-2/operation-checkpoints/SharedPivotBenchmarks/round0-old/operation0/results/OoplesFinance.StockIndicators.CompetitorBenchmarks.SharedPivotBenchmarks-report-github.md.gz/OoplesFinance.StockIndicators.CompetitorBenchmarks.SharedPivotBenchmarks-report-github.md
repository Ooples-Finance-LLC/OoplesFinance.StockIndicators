```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |------ |-----------:|----------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **1000**  |   **271.7 μs** |  **95.86 μs** |  **63.41 μs** |       **-** |       **-** |  **128.45 KB** |
| BuilderLatestOnly | 1000  |   229.6 μs |  56.76 μs |  37.55 μs |  1.9531 |       - |   80.85 KB |
| **BuilderFull**       | **10000** | **1,706.1 μs** |  **20.32 μs** |  **10.63 μs** | **46.8750** | **15.6250** | **1183.62 KB** |
| BuilderLatestOnly | 10000 | 1,838.6 μs | 315.00 μs | 208.35 μs | 15.6250 |       - |  713.77 KB |
