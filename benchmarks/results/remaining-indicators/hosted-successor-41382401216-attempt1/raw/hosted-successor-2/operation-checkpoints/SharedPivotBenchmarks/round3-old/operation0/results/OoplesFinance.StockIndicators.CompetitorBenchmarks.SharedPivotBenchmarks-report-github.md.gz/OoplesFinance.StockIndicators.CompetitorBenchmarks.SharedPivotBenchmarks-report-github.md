```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |------ |-----------:|----------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **1000**  |   **280.0 μs** |  **84.79 μs** |  **56.09 μs** |       **-** |       **-** |  **128.45 KB** |
| BuilderLatestOnly | 1000  |   208.0 μs |  26.31 μs |  15.66 μs |  1.9531 |       - |   80.85 KB |
| **BuilderFull**       | **10000** | **1,768.6 μs** | **239.37 μs** | **142.45 μs** | **46.8750** | **15.6250** | **1183.62 KB** |
| BuilderLatestOnly | 10000 | 1,823.9 μs | 305.12 μs | 201.82 μs | 15.6250 |       - |  713.79 KB |
