```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |------ |-----------:|----------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **1000**  |   **273.5 μs** |  **86.08 μs** |  **56.93 μs** |       **-** |       **-** |  **128.45 KB** |
| BuilderLatestOnly | 1000  |   220.3 μs |  48.91 μs |  32.35 μs |  1.9531 |       - |   80.84 KB |
| **BuilderFull**       | **10000** | **1,691.7 μs** | **124.01 μs** |  **64.86 μs** | **46.8750** | **15.6250** | **1183.61 KB** |
| BuilderLatestOnly | 10000 | 1,820.7 μs | 366.07 μs | 242.13 μs | 15.6250 |       - |  713.78 KB |
