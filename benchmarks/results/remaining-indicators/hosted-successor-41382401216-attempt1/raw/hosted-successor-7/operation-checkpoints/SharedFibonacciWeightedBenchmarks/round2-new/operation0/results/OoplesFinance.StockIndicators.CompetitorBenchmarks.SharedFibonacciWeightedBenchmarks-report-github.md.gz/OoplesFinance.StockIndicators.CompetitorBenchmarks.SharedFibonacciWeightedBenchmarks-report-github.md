```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |----------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Fwma** | **1000**  |  **78.81 μs** |  **2.517 μs** |  **1.665 μs** |  **0.92** |    **0.02** |   **1.9531** |       **-** |   **60.39 KB** |        **0.24** |
| BuilderLatestOnly | QuanTAlib.Fwma | 1000  |  72.02 μs |  4.593 μs |  3.038 μs |  0.84 |    0.04 |   0.4883 |       - |   12.46 KB |        0.05 |
| NativeSingle      | QuanTAlib.Fwma | 1000  |  85.92 μs |  1.951 μs |  1.021 μs |  1.00 |    0.02 |  15.1367 |  0.4883 |   254.5 KB |        1.00 |
| NativeParallel    | QuanTAlib.Fwma | 1000  |  76.42 μs |  2.930 μs |  1.938 μs |  0.89 |    0.02 |  16.1133 |  0.4883 |   262.7 KB |        1.03 |
|                   |                |       |           |           |           |       |         |          |         |            |             |
| **BuilderFull**       | **QuanTAlib.Fwma** | **10000** | **429.45 μs** | **46.055 μs** | **30.462 μs** |  **0.50** |    **0.04** |  **31.2500** | **11.7188** |  **552.91 KB** |        **0.22** |
| BuilderLatestOnly | QuanTAlib.Fwma | 10000 | 396.93 μs | 13.941 μs |  7.291 μs |  0.46 |    0.02 |   3.9063 |       - |   82.81 KB |        0.03 |
| NativeSingle      | QuanTAlib.Fwma | 10000 | 856.16 μs | 41.403 μs | 27.386 μs |  1.00 |    0.04 | 156.2500 | 31.2500 | 2564.32 KB |        1.00 |
| NativeParallel    | QuanTAlib.Fwma | 10000 | 502.95 μs | 23.426 μs | 15.495 μs |  0.59 |    0.02 | 156.2500 | 31.2500 | 2572.67 KB |        1.00 |
