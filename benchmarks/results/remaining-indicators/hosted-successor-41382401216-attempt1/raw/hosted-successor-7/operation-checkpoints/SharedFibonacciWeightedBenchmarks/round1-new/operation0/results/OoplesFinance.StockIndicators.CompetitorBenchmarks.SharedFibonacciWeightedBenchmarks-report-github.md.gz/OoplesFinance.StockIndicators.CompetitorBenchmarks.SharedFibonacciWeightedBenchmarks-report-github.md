```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Fwma** | **1000**  |  **75.56 μs** |  **5.674 μs** |  **2.968 μs** |  **1.9531** |       **-** |  **60.35 KB** |
| BuilderLatestOnly | QuanTAlib.Fwma | 1000  |  73.78 μs |  2.277 μs |  1.506 μs |  0.4883 |       - |  12.46 KB |
| **BuilderFull**       | **QuanTAlib.Fwma** | **10000** | **428.79 μs** | **51.804 μs** | **34.265 μs** | **31.2500** | **11.7188** | **552.91 KB** |
| BuilderLatestOnly | QuanTAlib.Fwma | 10000 | 398.51 μs |  4.787 μs |  2.503 μs |  3.9063 |       - |  82.81 KB |
