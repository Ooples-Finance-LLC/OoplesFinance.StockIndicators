```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDI [22]** |  **2,244.8 μs** |    **16.55 μs** |     **8.66 μs** |  **1.00** |    **0.01** |  **105.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDI [22] |    207.4 μs |    10.10 μs |     5.28 μs |  0.09 |    0.00 |   40.27 KB |        0.38 |
|            |       |                      |             |             |             |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDI [22]** | **18,165.5 μs** | **4,634.54 μs** | **3,065.46 μs** |  **1.02** |    **0.22** | **1036.72 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDI [22] |    287.1 μs |    24.13 μs |    14.36 μs |  0.02 |    0.00 |  330.92 KB |        0.32 |
