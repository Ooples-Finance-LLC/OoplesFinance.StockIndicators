```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error       | StdDev      | Median     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|------------:|------------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Macd** | **4,900.9 μs** |    **87.64 μs** |    **52.15 μs** | **4,897.5 μs** |  **1.00** |    **0.01** |  **203.19 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Macd |   256.9 μs |    13.63 μs |     8.11 μs |   253.6 μs |  0.05 |    0.00 |   120.7 KB |        0.59 |
|            |       |                      |            |             |             |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Macd** | **6,798.2 μs** | **7,457.48 μs** | **3,900.41 μs** | **5,204.9 μs** |  **1.16** |    **0.71** | **1994.91 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Macd |   355.1 μs |    18.34 μs |    12.13 μs |   360.5 μs |  0.06 |    0.02 | 1131.16 KB |        0.57 |
