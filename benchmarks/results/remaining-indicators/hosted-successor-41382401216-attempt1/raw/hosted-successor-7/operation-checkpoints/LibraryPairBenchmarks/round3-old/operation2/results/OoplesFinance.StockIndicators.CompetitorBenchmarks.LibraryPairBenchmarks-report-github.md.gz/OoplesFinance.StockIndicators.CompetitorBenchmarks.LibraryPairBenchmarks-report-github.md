```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean      | Error      | StdDev     | Median    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |----------:|-----------:|-----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)cdFix [23]** |  **5.766 ms** |  **0.0629 ms** |  **0.0416 ms** |  **5.752 ms** |  **1.00** |    **0.01** |  **203.25 KB** |        **1.00** |
|        |       |                      |           |            |            |           |       |         |            |             |
| **Ooples** | **10000** | **TaLib(...)cdFix [23]** | **41.403 ms** | **32.7339 ms** | **21.6515 ms** | **55.089 ms** |  **1.95** |    **2.57** | **1995.91 KB** |        **1.00** |
