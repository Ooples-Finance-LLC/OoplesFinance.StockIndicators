```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error        | StdDev       | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-------------:|-------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)cdExt [23]** |  **3,562.0 μs** |     **57.39 μs** |     **34.15 μs** |  **1.00** |    **0.01** |   **752.1 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)cdExt [23] |    260.7 μs |     17.59 μs |     10.47 μs |  0.07 |    0.00 |  121.87 KB |        0.16 |
|            |       |                      |             |              |              |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)cdExt [23]** | **35,599.6 μs** | **19,266.53 μs** | **12,743.62 μs** |  **1.23** |    **0.87** | **7316.67 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)cdExt [23] |    473.4 μs |     39.71 μs |     23.63 μs |  0.02 |    0.01 | 1132.61 KB |        0.15 |
