```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)cdFix [23]** | **5,708.3 μs** |    **62.34 μs** |    **37.10 μs** |  **1.00** |    **0.01** |  **203.25 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)cdFix [23] |   259.4 μs |    36.94 μs |    21.98 μs |  0.05 |    0.00 |  120.75 KB |        0.59 |
|            |       |                      |            |             |             |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)cdFix [23]** | **6,476.2 μs** | **3,241.04 μs** | **1,695.12 μs** |  **1.05** |    **0.33** |  **1994.6 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)cdFix [23] |   348.1 μs |    21.80 μs |    14.42 μs |  0.06 |    0.01 | 1131.12 KB |        0.57 |
