```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean      | Error      | StdDev     | Median    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |----------:|-----------:|-----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Macd** |  **4.884 ms** |  **0.1044 ms** |  **0.0691 ms** |  **4.869 ms** |  **1.00** |    **0.02** |  **203.19 KB** |        **1.00** |
|        |       |                      |           |            |            |           |       |         |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Macd** | **31.330 ms** | **29.8816 ms** | **19.7648 ms** | **42.294 ms** |  **2.09** |    **2.69** | **1995.85 KB** |        **1.00** |
