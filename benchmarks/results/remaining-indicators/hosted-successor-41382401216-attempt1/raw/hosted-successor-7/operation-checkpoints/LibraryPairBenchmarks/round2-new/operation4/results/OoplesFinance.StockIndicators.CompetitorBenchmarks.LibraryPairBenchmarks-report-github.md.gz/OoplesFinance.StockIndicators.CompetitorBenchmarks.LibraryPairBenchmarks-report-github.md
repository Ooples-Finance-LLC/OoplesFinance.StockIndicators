```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDI [23]** | **2,241.2 μs** |    **45.84 μs** |    **27.28 μs** |  **1.00** |    **0.02** |  **105.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDI [23] |   215.1 μs |    12.36 μs |     8.18 μs |  0.10 |    0.00 |   40.55 KB |        0.38 |
|            |       |                      |            |             |             |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDI [23]** | **5,395.6 μs** | **2,985.55 μs** | **1,974.76 μs** |  **1.11** |    **0.52** | **1037.05 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDI [23] |   244.1 μs |     6.27 μs |     3.73 μs |  0.05 |    0.01 |  330.92 KB |        0.32 |
