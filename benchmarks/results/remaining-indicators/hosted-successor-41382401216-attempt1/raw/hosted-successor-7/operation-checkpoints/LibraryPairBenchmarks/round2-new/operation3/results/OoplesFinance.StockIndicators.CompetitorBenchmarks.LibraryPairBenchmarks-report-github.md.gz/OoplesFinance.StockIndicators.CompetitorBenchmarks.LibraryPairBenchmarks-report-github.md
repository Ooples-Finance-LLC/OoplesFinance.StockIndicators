```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Mavp** |   **795.7 μs** |  **39.49 μs** |  **23.50 μs** |  **1.00** |    **0.04** |  **107.52 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Mavp |   273.2 μs |  13.78 μs |   7.21 μs |  0.34 |    0.01 |   60.81 KB |        0.57 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Mavp** | **4,891.4 μs** | **809.19 μs** | **481.53 μs** |  **1.01** |    **0.13** | **1038.86 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Mavp |   706.0 μs |  31.75 μs |  18.90 μs |  0.15 |    0.01 |  525.98 KB |        0.51 |
