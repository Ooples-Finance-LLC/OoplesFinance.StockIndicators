```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|---------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDM [23]** | **1,555.0 μs** |  **28.63 μs** | **17.04 μs** |  **1.00** |  **105.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDM [23] |   147.8 μs |   2.98 μs |  1.97 μs |  0.10 |   40.27 KB |        0.38 |
|            |       |                      |            |           |          |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDM [23]** | **9,150.0 μs** | **186.60 μs** | **97.59 μs** |  **1.00** | **1037.05 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDM [23] |   319.1 μs |  22.38 μs | 13.32 μs |  0.03 |  329.93 KB |        0.32 |
