```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **420.4 μs** |   **2.08 μs** |   **1.24 μs** |       **-** |  **69.36 KB** |
| BuilderLatestOnly | 1000  | Beta      |   429.0 μs |  31.28 μs |  20.69 μs |       - |  21.67 KB |
| **BuilderFull**       | **10000** | **Beta**      | **4,174.1 μs** | **238.68 μs** | **142.03 μs** | **31.2500** | **632.37 KB** |
| BuilderLatestOnly | 10000 | Beta      | 4,250.3 μs | 479.32 μs | 317.04 μs |       - |  162.5 KB |
