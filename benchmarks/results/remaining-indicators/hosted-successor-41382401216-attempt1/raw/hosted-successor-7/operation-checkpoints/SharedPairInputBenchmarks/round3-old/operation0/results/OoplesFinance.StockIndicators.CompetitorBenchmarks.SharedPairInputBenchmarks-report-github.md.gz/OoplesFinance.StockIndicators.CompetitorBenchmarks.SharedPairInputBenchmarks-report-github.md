```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **491.8 μs** | **135.82 μs** |  **89.83 μs** |       **-** |  **69.39 KB** |
| BuilderLatestOnly | 1000  | Beta      |   448.9 μs |  76.76 μs |  50.77 μs |       - |  21.67 KB |
| **BuilderFull**       | **10000** | **Beta**      | **4,204.9 μs** | **389.20 μs** | **231.61 μs** | **31.2500** | **632.36 KB** |
| BuilderLatestOnly | 10000 | Beta      | 4,379.7 μs | 475.82 μs | 314.72 μs |       - | 162.52 KB |
