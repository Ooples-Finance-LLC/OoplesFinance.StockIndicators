```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-------------:|------------:|------------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **491.404 μs** | **142.1356 μs** |  **94.0139 μs** | **63.34** |   **11.56** |       **-** |      **-** |  **69.36 KB** |        **9.00** |
| BuilderLatestOnly | 1000  | Beta      |   426.852 μs |  46.7529 μs |  30.9242 μs | 55.02 |    3.81 |       - |      - |  21.67 KB |        2.81 |
| NativeSingle      | 1000  | Beta      |     7.759 μs |   0.0648 μs |   0.0429 μs |  1.00 |    0.01 |  0.4272 |      - |   7.71 KB |        1.00 |
| NativeParallel    | 1000  | Beta      |     6.196 μs |   0.6344 μs |   0.4196 μs |  0.80 |    0.05 |  0.4883 |      - |   7.98 KB |        1.03 |
|                   |       |           |              |             |             |       |         |         |        |           |             |
| **BuilderFull**       | **10000** | **Beta**      | **4,193.499 μs** | **424.2553 μs** | **280.6186 μs** | **56.36** |    **3.60** | **31.2500** |      **-** | **632.38 KB** |        **8.10** |
| BuilderLatestOnly | 10000 | Beta      | 4,031.961 μs | 311.3526 μs | 185.2809 μs | 54.19 |    2.37 |       - |      - |  162.5 KB |        2.08 |
| NativeSingle      | 10000 | Beta      |    74.404 μs |   0.3891 μs |   0.2035 μs |  1.00 |    0.00 |  4.3945 | 0.4883 |  78.03 KB |        1.00 |
| NativeParallel    | 10000 | Beta      |    54.550 μs |  11.4198 μs |   7.5535 μs |  0.73 |    0.10 |  4.3945 | 0.4883 |  78.29 KB |        1.00 |
