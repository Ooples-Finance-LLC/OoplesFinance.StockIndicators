```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **538.0 μs** | **160.14 μs** | **105.92 μs** |       **-** |  **69.36 KB** |
| BuilderLatestOnly | 1000  | Beta      |   418.9 μs |  41.18 μs |  24.51 μs |       - |  21.67 KB |
| **BuilderFull**       | **10000** | **Beta**      | **4,280.9 μs** | **393.26 μs** | **260.11 μs** | **31.2500** | **632.36 KB** |
| BuilderLatestOnly | 10000 | Beta      | 4,095.6 μs | 343.38 μs | 204.34 μs |       - | 162.54 KB |
