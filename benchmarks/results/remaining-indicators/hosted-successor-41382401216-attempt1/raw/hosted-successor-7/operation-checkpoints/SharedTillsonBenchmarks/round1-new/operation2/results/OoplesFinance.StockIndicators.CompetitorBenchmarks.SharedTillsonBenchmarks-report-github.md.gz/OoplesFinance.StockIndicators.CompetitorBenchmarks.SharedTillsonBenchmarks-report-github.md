```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation    | Count | Mean       | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |------------- |------ |-----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **QuanTAlib.T3** | **1000**  |   **164.3 μs** |  **3.79 μs** |  **2.25 μs** |  **3.9063** |      **-** |  **65.18 KB** |
| BuilderLatestOnly | QuanTAlib.T3 | 1000  |   154.6 μs |  1.53 μs |  0.91 μs |  0.9766 |      - |  17.57 KB |
| **BuilderFull**       | **QuanTAlib.T3** | **10000** | **1,496.4 μs** | **18.69 μs** | **11.12 μs** | **31.2500** | **7.8125** | **628.09 KB** |
| BuilderLatestOnly | QuanTAlib.T3 | 10000 | 1,472.1 μs |  7.38 μs |  4.39 μs |  7.8125 |      - | 158.26 KB |
