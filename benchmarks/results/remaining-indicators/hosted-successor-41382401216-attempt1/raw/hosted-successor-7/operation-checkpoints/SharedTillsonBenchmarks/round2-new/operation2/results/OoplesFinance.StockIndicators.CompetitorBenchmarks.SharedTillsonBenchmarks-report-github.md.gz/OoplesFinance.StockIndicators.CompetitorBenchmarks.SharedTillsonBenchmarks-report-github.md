```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation    | Count | Mean        | Error     | StdDev   | Ratio | RatioSD | Gen0    | Gen1    | Gen2   | Allocated  | Alloc Ratio |
|------------------ |------------- |------ |------------:|----------:|---------:|------:|--------:|--------:|--------:|-------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.T3** | **1000**  |   **160.97 μs** |  **1.635 μs** | **0.855 μs** |  **5.21** |    **0.06** |  **3.9063** |       **-** |      **-** |   **65.14 KB** |        **1.34** |
| BuilderLatestOnly | QuanTAlib.T3 | 1000  |   157.34 μs |  2.244 μs | 1.174 μs |  5.09 |    0.07 |  0.9766 |       - |      - |   17.57 KB |        0.36 |
| NativeSingle      | QuanTAlib.T3 | 1000  |    30.89 μs |  0.621 μs | 0.369 μs |  1.00 |    0.02 |  2.9297 |  0.2441 | 0.2441 |   48.69 KB |        1.00 |
| NativeParallel    | QuanTAlib.T3 | 1000  |    74.41 μs |  2.294 μs | 1.365 μs |  2.41 |    0.05 |  6.8359 |  0.9766 | 0.9766 |  112.86 KB |        2.32 |
|                   |              |       |             |           |          |       |         |         |         |        |            |             |
| **BuilderFull**       | **QuanTAlib.T3** | **10000** | **1,480.09 μs** |  **5.532 μs** | **2.893 μs** |  **5.56** |    **0.06** | **31.2500** |  **7.8125** |      **-** |  **628.04 KB** |        **1.33** |
| BuilderLatestOnly | QuanTAlib.T3 | 10000 | 1,468.45 μs |  7.922 μs | 5.240 μs |  5.52 |    0.06 |  7.8125 |       - |      - |  158.26 KB |        0.34 |
| NativeSingle      | QuanTAlib.T3 | 10000 |   266.07 μs |  5.111 μs | 3.042 μs |  1.00 |    0.02 | 27.3438 |  3.9063 |      - |  470.58 KB |        1.00 |
| NativeParallel    | QuanTAlib.T3 | 10000 |   345.35 μs | 12.263 μs | 6.414 μs |  1.30 |    0.03 | 62.5000 | 11.7188 |      - | 1062.09 KB |        2.26 |
