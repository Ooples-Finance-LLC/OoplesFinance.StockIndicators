```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev  | Gen0    | Gen1   | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|--------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib.Functions.T3** | **1000**  |   **149.3 μs** |  **1.41 μs** | **0.74 μs** |  **3.9063** |      **-** |  **65.18 KB** |
| BuilderLatestOnly | TaLib.Functions.T3 | 1000  |   144.5 μs |  1.97 μs | 1.17 μs |  0.9766 |      - |  17.56 KB |
| **BuilderFull**       | **TaLib.Functions.T3** | **10000** | **1,483.6 μs** | **12.28 μs** | **7.31 μs** | **31.2500** | **7.8125** | **628.07 KB** |
| BuilderLatestOnly | TaLib.Functions.T3 | 10000 | 1,471.0 μs |  9.98 μs | 6.60 μs |  7.8125 |      - | 158.26 KB |
