```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation     | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |-------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetT3** | **1000**  |   **157.5 μs** |  **2.25 μs** |  **1.18 μs** |  **3.9063** |  **65.18 KB** |
| BuilderLatestOnly | Skender.GetT3 | 1000  |   151.2 μs |  3.39 μs |  2.25 μs |  0.9766 |  17.57 KB |
| **BuilderFull**       | **Skender.GetT3** | **10000** | **1,477.0 μs** |  **7.61 μs** |  **3.98 μs** | **31.2500** | **628.15 KB** |
| BuilderLatestOnly | Skender.GetT3 | 10000 | 1,453.7 μs | 19.04 μs | 12.59 μs |  7.8125 | 158.26 KB |
