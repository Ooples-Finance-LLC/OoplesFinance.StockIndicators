```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation    | Count | Mean       | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |------------- |------ |-----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **QuanTAlib.T3** | **1000**  |   **163.3 μs** |  **2.28 μs** |  **1.19 μs** |  **3.9063** |      **-** |  **65.18 KB** |
| BuilderLatestOnly | QuanTAlib.T3 | 1000  |   156.7 μs |  2.22 μs |  1.16 μs |  0.9766 |      - |  17.57 KB |
| **BuilderFull**       | **QuanTAlib.T3** | **10000** | **1,491.4 μs** | **17.41 μs** | **10.36 μs** | **31.2500** | **7.8125** | **628.08 KB** |
| BuilderLatestOnly | QuanTAlib.T3 | 10000 | 1,434.5 μs | 13.31 μs |  6.96 μs |  7.8125 |      - | 158.26 KB |
