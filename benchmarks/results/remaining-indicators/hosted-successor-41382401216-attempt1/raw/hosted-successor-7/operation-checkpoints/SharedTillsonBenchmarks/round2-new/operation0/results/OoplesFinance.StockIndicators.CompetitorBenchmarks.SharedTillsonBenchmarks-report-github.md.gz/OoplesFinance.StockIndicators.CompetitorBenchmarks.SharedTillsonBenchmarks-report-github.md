```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation     | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |-------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetT3** | **1000**  |   **161.38 μs** |   **3.541 μs** |   **1.852 μs** |  **3.33** |    **0.05** |   **3.9063** |        **-** |        **-** |   **65.18 KB** |        **0.72** |
| BuilderLatestOnly | Skender.GetT3 | 1000  |   152.74 μs |   3.042 μs |   2.012 μs |  3.15 |    0.05 |   0.9766 |        - |        - |   17.57 KB |        0.19 |
| NativeSingle      | Skender.GetT3 | 1000  |    48.43 μs |   0.884 μs |   0.585 μs |  1.00 |    0.02 |   5.3711 |   0.7324 |        - |   90.24 KB |        1.00 |
| NativeParallel    | Skender.GetT3 | 1000  |   105.07 μs |   6.775 μs |   4.481 μs |  2.17 |    0.09 |  15.6250 |   2.9297 |        - |  234.43 KB |        2.60 |
|                   |               |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetT3** | **10000** | **1,490.38 μs** |  **12.027 μs** |   **6.290 μs** |  **2.08** |    **0.08** |  **31.2500** |   **7.8125** |        **-** |  **628.09 KB** |        **0.70** |
| BuilderLatestOnly | Skender.GetT3 | 10000 | 1,476.61 μs |   8.314 μs |   4.947 μs |  2.06 |    0.08 |   7.8125 |        - |        - |  158.26 KB |        0.18 |
| NativeSingle      | Skender.GetT3 | 10000 |   716.42 μs |  45.239 μs |  29.923 μs |  1.00 |    0.06 | 117.1875 |  93.7500 |  82.0313 |   899.6 KB |        1.00 |
| NativeParallel    | Skender.GetT3 | 10000 | 1,875.94 μs | 400.396 μs | 264.837 μs |  2.62 |    0.37 | 250.0000 | 187.5000 | 140.6250 | 2329.05 KB |        2.59 |
