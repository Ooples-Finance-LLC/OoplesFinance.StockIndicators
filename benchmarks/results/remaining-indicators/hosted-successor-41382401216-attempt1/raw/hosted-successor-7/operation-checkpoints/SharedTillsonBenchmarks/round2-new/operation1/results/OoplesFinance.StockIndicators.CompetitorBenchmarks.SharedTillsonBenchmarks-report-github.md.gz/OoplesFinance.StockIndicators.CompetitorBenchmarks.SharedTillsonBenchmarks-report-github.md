```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean         | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |-------------:|-----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.T3** | **1000**  |   **152.444 μs** |  **3.1065 μs** | **1.8486 μs** | **38.72** |    **0.91** |  **3.9063** |      **-** |  **65.18 KB** |        **9.34** |
| BuilderLatestOnly | TaLib.Functions.T3 | 1000  |   143.576 μs |  1.9168 μs | 1.1406 μs | 36.47 |    0.80 |  0.9766 |      - |  17.57 KB |        2.52 |
| NativeSingle      | TaLib.Functions.T3 | 1000  |     3.939 μs |  0.1465 μs | 0.0872 μs |  1.00 |    0.03 |  0.3967 |      - |   6.98 KB |        1.00 |
| NativeParallel    | TaLib.Functions.T3 | 1000  |     8.754 μs |  0.3009 μs | 0.1791 μs |  2.22 |    0.06 |  1.8311 | 0.0610 |  24.66 KB |        3.53 |
|                   |                    |       |              |            |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.T3** | **10000** | **1,503.844 μs** |  **4.3677 μs** | **2.5991 μs** | **36.67** |    **0.84** | **31.2500** | **7.8125** | **628.09 KB** |        **8.13** |
| BuilderLatestOnly | TaLib.Functions.T3 | 10000 | 1,456.721 μs | 10.5188 μs | 6.9576 μs | 35.52 |    0.83 |  7.8125 |      - | 158.26 KB |        2.05 |
| NativeSingle      | TaLib.Functions.T3 | 10000 |    41.027 μs |  1.4802 μs | 0.9791 μs |  1.00 |    0.03 |  4.6387 |      - |  77.29 KB |        1.00 |
| NativeParallel    | TaLib.Functions.T3 | 10000 |    90.442 μs |  7.5177 μs | 4.9725 μs |  2.21 |    0.13 | 18.0664 | 3.9063 | 270.75 KB |        3.50 |
