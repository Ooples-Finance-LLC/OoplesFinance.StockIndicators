```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **4.400 ms** | **2.6170 ms** | **1.7310 ms** |  **69.08 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1.844 ms | 0.0181 ms | 0.0107 ms |  21.45 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **18.922 ms** | **0.0956 ms** | **0.0569 ms** | **633.11 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 18.964 ms | 0.1083 ms | 0.0644 ms | 163.25 KB |
