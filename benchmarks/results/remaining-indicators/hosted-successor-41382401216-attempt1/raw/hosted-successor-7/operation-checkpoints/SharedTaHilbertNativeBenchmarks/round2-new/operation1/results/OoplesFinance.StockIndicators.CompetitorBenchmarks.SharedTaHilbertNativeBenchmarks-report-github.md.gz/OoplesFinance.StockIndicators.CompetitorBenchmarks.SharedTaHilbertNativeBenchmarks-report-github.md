```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **2,139.2 μs** |  **14.82 μs** |   **8.82 μs** |  **3.94** |    **0.02** |  **84.97 KB** |        **5.40** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1,885.2 μs |  13.19 μs |   7.85 μs |  3.47 |    0.02 |  37.34 KB |        2.37 |
| NativeSingle      | TaLib(...)tSine [22] | 1000  |    543.2 μs |   2.43 μs |   1.27 μs |  1.00 |    0.00 |  15.74 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 1000  |    707.0 μs |   5.41 μs |   2.83 μs |  1.30 |    0.01 |  55.99 KB |        3.56 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **19,448.6 μs** |  **60.46 μs** |  **31.62 μs** |  **3.30** |    **0.01** | **789.58 KB** |        **5.04** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 19,510.7 μs | 141.52 μs |  93.61 μs |  3.31 |    0.02 | 319.83 KB |        2.04 |
| NativeSingle      | TaLib(...)tSine [22] | 10000 |  5,888.0 μs |  38.83 μs |  23.11 μs |  1.00 |    0.01 | 156.56 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 10000 |  7,485.8 μs | 255.12 μs | 133.43 μs |  1.27 |    0.02 | 548.68 KB |        3.50 |
