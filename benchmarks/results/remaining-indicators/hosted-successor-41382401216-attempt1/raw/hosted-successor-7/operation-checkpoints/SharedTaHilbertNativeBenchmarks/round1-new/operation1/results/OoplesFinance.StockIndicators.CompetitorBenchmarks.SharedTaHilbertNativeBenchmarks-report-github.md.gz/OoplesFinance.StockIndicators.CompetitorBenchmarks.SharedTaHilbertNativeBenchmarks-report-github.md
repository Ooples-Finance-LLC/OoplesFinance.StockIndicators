```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **2.175 ms** | **0.0160 ms** | **0.0095 ms** |  **84.97 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1.859 ms | 0.0122 ms | 0.0064 ms |  37.34 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **19.223 ms** | **0.0469 ms** | **0.0245 ms** | **789.64 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 19.169 ms | 0.1054 ms | 0.0697 ms | 319.72 KB |
