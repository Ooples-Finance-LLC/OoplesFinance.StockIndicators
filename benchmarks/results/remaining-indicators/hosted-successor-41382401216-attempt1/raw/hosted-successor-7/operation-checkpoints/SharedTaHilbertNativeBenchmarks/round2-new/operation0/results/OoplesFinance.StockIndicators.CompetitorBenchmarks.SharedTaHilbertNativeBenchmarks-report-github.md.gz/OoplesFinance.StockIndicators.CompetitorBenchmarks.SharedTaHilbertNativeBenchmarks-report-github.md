```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **2,139.5 μs** |  **24.10 μs** |  **14.34 μs** |  **4.12** |    **0.03** |  **69.08 KB** |        **8.23** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1,823.2 μs |  17.76 μs |  11.75 μs |  3.51 |    0.02 |  21.44 KB |        2.56 |
| NativeSingle      | TaLib(...)Phase [25] | 1000  |    518.9 μs |   2.61 μs |   1.36 μs |  1.00 |    0.00 |   8.39 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 1000  |    696.9 μs |  47.47 μs |  31.40 μs |  1.34 |    0.06 |  30.19 KB |        3.60 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **18,940.6 μs** | **349.55 μs** | **182.82 μs** |  **3.34** |    **0.05** | **633.12 KB** |        **8.02** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 18,979.4 μs | 109.07 μs |  57.05 μs |  3.35 |    0.04 | 163.31 KB |        2.07 |
| NativeSingle      | TaLib(...)Phase [25] | 10000 |  5,671.8 μs | 111.90 μs |  74.01 μs |  1.00 |    0.02 |  78.92 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 10000 |  7,127.7 μs | 243.65 μs | 127.43 μs |  1.26 |    0.03 | 276.78 KB |        3.51 |
