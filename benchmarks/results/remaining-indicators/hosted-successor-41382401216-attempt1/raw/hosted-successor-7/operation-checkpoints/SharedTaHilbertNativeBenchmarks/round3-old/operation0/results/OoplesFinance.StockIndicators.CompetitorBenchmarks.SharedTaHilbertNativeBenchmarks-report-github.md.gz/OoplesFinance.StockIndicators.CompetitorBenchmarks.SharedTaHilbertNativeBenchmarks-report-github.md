```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **2.094 ms** | **0.0294 ms** | **0.0154 ms** |  **69.08 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1.842 ms | 0.0098 ms | 0.0058 ms |  21.44 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **19.526 ms** | **1.2858 ms** | **0.8505 ms** | **633.12 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 18.971 ms | 0.0611 ms | 0.0319 ms | 163.31 KB |
