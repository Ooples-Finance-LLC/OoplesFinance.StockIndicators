```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **2.553 ms** | **0.0186 ms** | **0.0097 ms** |  **84.97 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1.888 ms | 0.0065 ms | 0.0034 ms |  37.33 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **19.394 ms** | **0.1386 ms** | **0.0825 ms** | **789.61 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 19.241 ms | 0.1252 ms | 0.0828 ms | 319.55 KB |
