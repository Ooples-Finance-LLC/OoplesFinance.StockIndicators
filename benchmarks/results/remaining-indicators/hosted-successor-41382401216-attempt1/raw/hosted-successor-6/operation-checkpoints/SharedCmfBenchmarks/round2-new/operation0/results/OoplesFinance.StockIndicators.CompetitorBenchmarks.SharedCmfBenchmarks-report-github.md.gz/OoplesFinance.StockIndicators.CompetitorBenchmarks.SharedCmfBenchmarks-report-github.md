```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetCmf** | **1000**  |   **107.22 μs** | **15.918 μs** | **10.529 μs** |  **0.77** |    **0.07** |   **3.9063** |        **-** |       **-** |   **85.77 KB** |        **0.29** |
| BuilderLatestOnly | Skender.GetCmf | 1000  |    81.37 μs |  2.857 μs |  1.890 μs |  0.59 |    0.02 |   1.9531 |        - |       - |   38.12 KB |        0.13 |
| NativeSingle      | Skender.GetCmf | 1000  |   139.06 μs |  3.284 μs |  1.954 μs |  1.00 |    0.02 |  17.5781 |   4.8828 |       - |   297.9 KB |        1.00 |
| NativeParallel    | Skender.GetCmf | 1000  |   111.50 μs | 15.871 μs | 10.497 μs |  0.80 |    0.07 |  20.5078 |   5.8594 |       - |   326.3 KB |        1.10 |
|                   |                |       |             |           |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skender.GetCmf** | **10000** |   **587.19 μs** | **74.471 μs** | **49.258 μs** |  **0.34** |    **0.03** |  **46.8750** |  **15.6250** |       **-** |  **789.24 KB** |        **0.27** |
| BuilderLatestOnly | Skender.GetCmf | 10000 |   561.28 μs | 67.320 μs | 44.528 μs |  0.33 |    0.03 |  15.6250 |   3.9063 |       - |  319.41 KB |        0.11 |
| NativeSingle      | Skender.GetCmf | 10000 | 1,718.87 μs | 45.449 μs | 23.771 μs |  1.00 |    0.02 | 187.5000 | 140.6250 | 46.8750 | 2970.23 KB |        1.00 |
| NativeParallel    | Skender.GetCmf | 10000 |   947.11 μs | 94.598 μs | 62.571 μs |  0.55 |    0.04 | 195.3125 | 117.1875 |       - | 3068.54 KB |        1.03 |
