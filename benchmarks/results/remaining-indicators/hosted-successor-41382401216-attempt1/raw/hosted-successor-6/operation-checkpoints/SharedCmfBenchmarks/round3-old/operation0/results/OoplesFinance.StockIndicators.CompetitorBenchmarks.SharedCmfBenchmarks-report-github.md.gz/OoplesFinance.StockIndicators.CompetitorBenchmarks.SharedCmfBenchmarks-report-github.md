```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error      | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|-----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetCmf** | **1000**  |  **88.44 μs** |   **8.159 μs** |  **4.855 μs** |  **3.9063** |       **-** |  **85.73 KB** |
| BuilderLatestOnly | Skender.GetCmf | 1000  |  84.22 μs |   8.019 μs |  5.304 μs |  1.9531 |       - |  38.13 KB |
| **BuilderFull**       | **Skender.GetCmf** | **10000** | **591.78 μs** | **104.420 μs** | **69.067 μs** | **46.8750** | **15.6250** | **789.24 KB** |
| BuilderLatestOnly | Skender.GetCmf | 10000 | 544.08 μs |  66.626 μs | 44.069 μs | 15.6250 |  3.9063 |  319.4 KB |
