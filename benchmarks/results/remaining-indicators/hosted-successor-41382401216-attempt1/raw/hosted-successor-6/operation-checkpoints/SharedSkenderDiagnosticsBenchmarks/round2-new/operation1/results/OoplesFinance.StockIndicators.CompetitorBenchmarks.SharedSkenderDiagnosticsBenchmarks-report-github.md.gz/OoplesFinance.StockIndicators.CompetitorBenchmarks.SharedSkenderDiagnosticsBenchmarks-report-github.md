```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)lysis [22]** | **1000**  |   **445.43 μs** | **143.915 μs** |  **95.191 μs** |  **5.07** |    **1.04** |        **-** |        **-** |       **-** |  **144.21 KB** |        **0.78** |
| BuilderLatestOnly | Skend(...)lysis [22] | 1000  |   295.97 μs |  52.597 μs |  31.299 μs |  3.37 |    0.34 |   3.9063 |        - |       - |   96.58 KB |        0.52 |
| NativeSingle      | Skend(...)lysis [22] | 1000  |    87.90 μs |   2.122 μs |   1.403 μs |  1.00 |    0.02 |  11.2305 |   2.4414 |       - |  184.11 KB |        1.00 |
| NativeParallel    | Skend(...)lysis [22] | 1000  |    64.03 μs |   5.142 μs |   3.060 μs |  0.73 |    0.03 |  13.1836 |   2.9297 |       - |  204.15 KB |        1.11 |
|                   |                      |       |             |            |            |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)lysis [22]** | **10000** | **2,814.40 μs** | **205.886 μs** | **136.181 μs** |  **2.13** |    **0.11** |  **62.5000** |  **31.2500** |       **-** | **1272.61 KB** |        **0.69** |
| BuilderLatestOnly | Skend(...)lysis [22] | 10000 | 2,642.34 μs |  56.614 μs |  33.690 μs |  2.00 |    0.06 |  31.2500 |        - |       - |  802.92 KB |        0.44 |
| NativeSingle      | Skend(...)lysis [22] | 10000 | 1,325.00 μs |  65.089 μs |  38.733 μs |  1.00 |    0.04 | 171.8750 | 117.1875 | 85.9375 | 1837.33 KB |        1.00 |
| NativeParallel    | Skend(...)lysis [22] | 10000 |   596.74 μs |  47.879 μs |  31.669 μs |  0.45 |    0.03 | 121.0938 |  58.5938 |       - | 1926.82 KB |        1.05 |
