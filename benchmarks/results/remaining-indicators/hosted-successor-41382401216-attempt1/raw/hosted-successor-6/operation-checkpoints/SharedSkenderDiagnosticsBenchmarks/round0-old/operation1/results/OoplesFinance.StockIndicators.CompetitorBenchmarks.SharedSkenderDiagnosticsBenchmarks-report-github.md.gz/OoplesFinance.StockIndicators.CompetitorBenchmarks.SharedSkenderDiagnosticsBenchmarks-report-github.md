```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Skend(...)lysis [22]** | **1000**  |   **318.5 μs** |  **12.96 μs** |   **7.71 μs** |       **-** |       **-** |  **144.21 KB** |
| BuilderLatestOnly | Skend(...)lysis [22] | 1000  |   285.5 μs |  19.86 μs |  10.39 μs |  3.9063 |       - |   96.58 KB |
| **BuilderFull**       | **Skend(...)lysis [22]** | **10000** | **2,705.5 μs** | **149.35 μs** |  **88.87 μs** | **62.5000** | **31.2500** | **1272.62 KB** |
| BuilderLatestOnly | Skend(...)lysis [22] | 10000 | 2,724.1 μs | 291.62 μs | 173.54 μs | 46.8750 | 15.6250 |   802.8 KB |
