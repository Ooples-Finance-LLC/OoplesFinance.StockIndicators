```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)lysis [22]** | **1000**  |   **419.5 μs** | **147.30 μs** |  **97.43 μs** |       **-** |       **-** | **144.21 KB** |
| BuilderLatestOnly | Skend(...)lysis [22] | 1000  |   284.0 μs |  15.10 μs |   7.90 μs |  3.9063 |       - |  96.58 KB |
| **BuilderFull**       | **Skend(...)lysis [22]** | **10000** | **2,731.9 μs** | **280.46 μs** | **166.90 μs** | **62.5000** | **31.2500** | **1272.6 KB** |
| BuilderLatestOnly | Skend(...)lysis [22] | 10000 | 2,734.2 μs | 169.47 μs | 100.85 μs | 46.8750 | 15.6250 |  802.8 KB |
