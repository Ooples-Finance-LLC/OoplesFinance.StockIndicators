```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetPrs** | **1000**  |   **608.34 μs** | **170.277 μs** | **112.628 μs** | **10.95** |    **1.94** |  **46.8750** |        **-** |        **-** |  **991.03 KB** |        **6.01** |
| BuilderLatestOnly | Skender.GetPrs | 1000  |   428.37 μs |  57.585 μs |  38.089 μs |  7.71 |    0.66 |  54.6875 |   7.8125 |        - |  943.45 KB |        5.73 |
| NativeSingle      | Skender.GetPrs | 1000  |    55.57 μs |   1.198 μs |   0.793 μs |  1.00 |    0.02 |   9.7656 |   1.4648 |        - |  164.79 KB |        1.00 |
| NativeParallel    | Skender.GetPrs | 1000  |    38.72 μs |   5.753 μs |   3.806 μs |  0.70 |    0.07 |  12.6953 |   2.6855 |        - |  184.81 KB |        1.12 |
|                   |                |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetPrs** | **10000** | **4,071.28 μs** | **224.026 μs** | **133.314 μs** |  **4.93** |    **0.19** | **562.5000** | **281.2500** |        **-** | **9429.55 KB** |        **5.74** |
| BuilderLatestOnly | Skender.GetPrs | 10000 | 4,146.96 μs | 274.584 μs | 163.401 μs |  5.02 |    0.22 | 531.2500 | 250.0000 |        - |  8959.7 KB |        5.45 |
| NativeSingle      | Skender.GetPrs | 10000 |   826.07 μs |  36.003 μs |  21.425 μs |  1.00 |    0.03 | 203.1250 | 156.2500 | 148.4375 | 1643.12 KB |        1.00 |
| NativeParallel    | Skender.GetPrs | 10000 |   420.56 μs |  33.269 μs |  19.798 μs |  0.51 |    0.03 | 113.2813 |  50.7813 |        - | 1731.72 KB |        1.05 |
