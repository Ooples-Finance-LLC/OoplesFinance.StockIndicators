```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |--------------- |------ |-----------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetPrs** | **1000**  |   **555.9 μs** | **166.71 μs** | **110.27 μs** |  **46.8750** |        **-** |  **991.03 KB** |
| BuilderLatestOnly | Skender.GetPrs | 1000  |   453.6 μs |  40.24 μs |  26.62 μs |  54.6875 |   7.8125 |  943.42 KB |
| **BuilderFull**       | **Skender.GetPrs** | **10000** | **4,432.4 μs** | **464.16 μs** | **307.01 μs** | **562.5000** | **281.2500** | **9429.55 KB** |
| BuilderLatestOnly | Skender.GetPrs | 10000 | 4,319.3 μs | 317.35 μs | 209.91 μs | 531.2500 | 250.0000 | 8959.71 KB |
