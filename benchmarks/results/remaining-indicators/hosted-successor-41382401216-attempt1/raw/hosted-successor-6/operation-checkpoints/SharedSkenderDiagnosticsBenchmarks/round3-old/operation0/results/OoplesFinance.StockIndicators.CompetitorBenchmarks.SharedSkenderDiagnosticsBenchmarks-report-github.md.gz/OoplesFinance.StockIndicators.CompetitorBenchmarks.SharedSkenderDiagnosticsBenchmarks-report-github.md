```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |--------------- |------ |-----------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetPrs** | **1000**  |   **586.1 μs** | **162.63 μs** | **107.57 μs** |  **46.8750** |        **-** |  **991.03 KB** |
| BuilderLatestOnly | Skender.GetPrs | 1000  |   438.9 μs |  69.42 μs |  45.91 μs |  54.6875 |   7.8125 |  943.45 KB |
| **BuilderFull**       | **Skender.GetPrs** | **10000** | **4,153.5 μs** | **288.55 μs** | **190.86 μs** | **562.5000** | **281.2500** | **9429.55 KB** |
| BuilderLatestOnly | Skender.GetPrs | 10000 | 4,197.5 μs | 396.96 μs | 262.57 μs | 531.2500 | 250.0000 |  8959.7 KB |
