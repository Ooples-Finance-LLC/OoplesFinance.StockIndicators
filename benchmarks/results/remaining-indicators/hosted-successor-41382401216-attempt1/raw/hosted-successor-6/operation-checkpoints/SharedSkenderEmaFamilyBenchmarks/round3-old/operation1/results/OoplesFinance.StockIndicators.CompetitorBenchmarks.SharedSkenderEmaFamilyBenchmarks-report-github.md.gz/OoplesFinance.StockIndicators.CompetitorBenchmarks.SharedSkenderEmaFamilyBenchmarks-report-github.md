```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated  |
|------------------ |--------------- |------ |-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **724.3 μs** | **29.91 μs** | **17.80 μs** |  **105.05 KB** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   731.5 μs | 14.33 μs |  9.48 μs |   57.37 KB |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **7,369.8 μs** | **35.79 μs** | **21.30 μs** | **1019.92 KB** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 7,233.1 μs | 83.14 μs | 49.48 μs |  550.08 KB |
