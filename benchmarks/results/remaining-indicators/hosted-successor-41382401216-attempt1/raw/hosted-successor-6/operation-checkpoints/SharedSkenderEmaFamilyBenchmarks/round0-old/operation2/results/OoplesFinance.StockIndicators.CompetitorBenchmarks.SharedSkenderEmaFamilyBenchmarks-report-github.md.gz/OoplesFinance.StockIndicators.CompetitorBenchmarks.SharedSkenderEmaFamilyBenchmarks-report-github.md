```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |---------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **621.1 μs** |  **86.49 μs** |  **51.47 μs** |  **89.27 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   586.8 μs |  52.48 μs |  34.71 μs |   41.6 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **5,410.0 μs** | **520.89 μs** | **344.53 μs** | **863.47 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 5,823.5 μs | 441.67 μs | 292.14 μs | 393.66 KB |
