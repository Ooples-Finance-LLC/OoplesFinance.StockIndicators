```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **682.80 μs** |   **6.577 μs** |   **3.440 μs** |  **9.57** |    **0.24** |        **-** |        **-** |        **-** |  **105.05 KB** |        **0.37** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   668.41 μs |   7.986 μs |   4.752 μs |  9.36 |    0.24 |        - |        - |        - |   57.42 KB |        0.20 |
| NativeSingle      | Skender.GetPvo | 1000  |    71.43 μs |   2.875 μs |   1.902 μs |  1.00 |    0.04 |  17.0898 |   3.4180 |        - |  285.61 KB |        1.00 |
| NativeParallel    | Skender.GetPvo | 1000  |   139.97 μs |  10.766 μs |   7.121 μs |  1.96 |    0.11 |  46.8750 |  18.5547 |        - |  729.53 KB |        2.55 |
|                   |                |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **6,733.80 μs** |  **53.830 μs** |  **32.033 μs** |  **5.87** |    **0.15** |        **-** |        **-** |        **-** | **1019.83 KB** |        **0.33** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 6,770.80 μs |  58.503 μs |  34.814 μs |  5.90 |    0.16 |        - |        - |        - |  550.07 KB |        0.18 |
| NativeSingle      | Skender.GetPvo | 10000 | 1,148.28 μs |  47.810 μs |  31.624 μs |  1.00 |    0.04 | 164.0625 | 164.0625 | 164.0625 |  3052.2 KB |        1.00 |
| NativeParallel    | Skender.GetPvo | 10000 | 3,624.16 μs | 517.430 μs | 342.248 μs |  3.16 |    0.30 | 625.0000 | 531.2500 | 250.0000 | 7581.34 KB |        2.48 |
