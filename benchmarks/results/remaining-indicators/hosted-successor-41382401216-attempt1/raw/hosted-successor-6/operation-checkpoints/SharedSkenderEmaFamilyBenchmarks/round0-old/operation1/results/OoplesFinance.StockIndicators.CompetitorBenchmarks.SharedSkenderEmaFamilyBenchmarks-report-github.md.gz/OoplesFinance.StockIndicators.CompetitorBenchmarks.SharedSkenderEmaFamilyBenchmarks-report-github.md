```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Allocated  |
|------------------ |--------------- |------ |-----------:|----------:|----------:|-----------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **695.2 μs** |   **4.36 μs** |   **2.60 μs** |  **105.05 KB** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   683.5 μs |  13.48 μs |   8.92 μs |   57.39 KB |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **6,933.3 μs** | **232.95 μs** | **138.63 μs** | **1019.96 KB** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 7,161.1 μs | 433.27 μs | 286.58 μs |  550.11 KB |
