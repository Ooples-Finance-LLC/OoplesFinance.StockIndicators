```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **328.40 μs** |   **2.404 μs** |   **1.257 μs** |  **9.76** |    **0.20** |        **-** |        **-** |        **-** |   **89.21 KB** |        **0.73** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   324.02 μs |   2.993 μs |   1.565 μs |  9.63 |    0.20 |   1.9531 |        - |        - |    41.6 KB |        0.34 |
| NativeSingle      | Skender.GetTrix | 1000  |    33.66 μs |   1.223 μs |   0.728 μs |  1.00 |    0.03 |   7.3242 |   1.7090 |        - |  121.49 KB |        1.00 |
| NativeParallel    | Skender.GetTrix | 1000  |    68.33 μs |   2.655 μs |   1.756 μs |  2.03 |    0.06 |  20.5078 |   5.8594 |        - |  312.32 KB |        2.57 |
|                   |                 |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **3,324.82 μs** |  **15.728 μs** |   **8.226 μs** |  **5.54** |    **0.13** |  **31.2500** |        **-** |        **-** |  **863.25 KB** |        **0.71** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 3,355.05 μs |  27.859 μs |  18.427 μs |  5.59 |    0.13 |        - |        - |        - |  393.38 KB |        0.32 |
| NativeSingle      | Skender.GetTrix | 10000 |   600.35 μs |  22.395 μs |  14.813 μs |  1.00 |    0.03 |  97.6563 |  97.6563 |  97.6563 | 1212.12 KB |        1.00 |
| NativeParallel    | Skender.GetTrix | 10000 | 1,775.32 μs | 291.724 μs | 192.957 μs |  2.96 |    0.31 | 296.8750 | 250.0000 | 156.2500 | 3109.29 KB |        2.57 |
