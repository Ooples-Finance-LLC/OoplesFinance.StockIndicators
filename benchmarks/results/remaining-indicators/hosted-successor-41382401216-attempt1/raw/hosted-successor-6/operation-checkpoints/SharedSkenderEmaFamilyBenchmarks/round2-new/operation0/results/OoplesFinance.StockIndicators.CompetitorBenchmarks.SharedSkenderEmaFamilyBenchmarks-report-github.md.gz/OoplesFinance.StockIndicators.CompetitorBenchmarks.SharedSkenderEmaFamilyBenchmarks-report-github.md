```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **565.61 μs** |   **3.730 μs** |   **2.220 μs** |  **8.59** |    **0.33** |        **-** |        **-** |        **-** |  **128.54 KB** |        **0.40** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   562.04 μs |   7.228 μs |   4.301 μs |  8.54 |    0.33 |   3.9063 |        - |        - |    80.9 KB |        0.25 |
| NativeSingle      | Skender.GetMacd | 1000  |    65.94 μs |   4.029 μs |   2.665 μs |  1.00 |    0.05 |  19.5313 |   6.3477 |        - |  324.54 KB |        1.00 |
| NativeParallel    | Skender.GetMacd | 1000  |   132.81 μs |  11.946 μs |   7.902 μs |  2.02 |    0.14 |  53.7109 |  21.4844 |        - |  826.62 KB |        2.55 |
|                   |                 |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **5,608.10 μs** |  **86.513 μs** |  **57.223 μs** |  **4.47** |    **0.08** |  **62.5000** |        **-** |        **-** | **1254.09 KB** |        **0.36** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 5,611.70 μs |  39.717 μs |  23.635 μs |  4.47 |    0.07 |  31.2500 |        - |        - |  784.26 KB |        0.23 |
| NativeSingle      | Skender.GetMacd | 10000 | 1,256.19 μs |  34.289 μs |  20.405 μs |  1.00 |    0.02 | 218.7500 | 218.7500 | 218.7500 | 3443.11 KB |        1.00 |
| NativeParallel    | Skender.GetMacd | 10000 | 4,413.24 μs | 582.158 μs | 385.062 μs |  3.51 |    0.30 | 750.0000 | 656.2500 | 312.5000 | 8556.62 KB |        2.49 |
