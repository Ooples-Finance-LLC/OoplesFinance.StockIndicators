```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **556.6 μs** | **13.25 μs** |  **7.88 μs** |       **-** |  **128.54 KB** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   546.1 μs |  4.82 μs |  2.52 μs |  3.9063 |    80.9 KB |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **5,623.2 μs** | **45.46 μs** | **27.05 μs** | **62.5000** | **1254.08 KB** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 5,490.0 μs | 32.82 μs | 21.71 μs | 31.2500 |  784.27 KB |
