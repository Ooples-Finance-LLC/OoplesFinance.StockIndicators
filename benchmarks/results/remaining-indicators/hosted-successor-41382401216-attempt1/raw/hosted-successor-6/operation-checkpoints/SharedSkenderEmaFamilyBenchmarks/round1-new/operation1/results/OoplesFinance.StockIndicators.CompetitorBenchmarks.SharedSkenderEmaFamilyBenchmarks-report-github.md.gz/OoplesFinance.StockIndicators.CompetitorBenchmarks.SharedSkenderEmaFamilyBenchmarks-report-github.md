```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated  |
|------------------ |--------------- |------ |-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **728.6 μs** | **81.76 μs** | **54.08 μs** |  **105.05 KB** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   684.9 μs |  5.59 μs |  3.33 μs |   57.37 KB |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **6,836.6 μs** | **48.37 μs** | **28.79 μs** | **1019.86 KB** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 6,805.7 μs | 55.68 μs | 29.12 μs |  550.09 KB |
