```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **3,499.8 μs** |  **46.25 μs** |  **24.19 μs** |  **5.99** |    **0.04** |  **71.75 KB** |       **15.17** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  2,651.0 μs | 111.64 μs |  73.84 μs |  4.54 |    0.12 |  24.06 KB |        5.09 |
| NativeSingle      | TaLib(...)dMode [27] | 1000  |    584.4 μs |   3.61 μs |   1.89 μs |  1.00 |    0.00 |   4.73 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 1000  |    776.8 μs |  46.88 μs |  31.01 μs |  1.33 |    0.05 |  17.39 KB |        3.68 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **27,118.0 μs** | **501.57 μs** | **262.33 μs** |  **4.27** |    **0.04** | **636.42 KB** |       **15.78** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 26,960.3 μs | 320.77 μs | 190.88 μs |  4.25 |    0.03 | 166.68 KB |        4.13 |
| NativeSingle      | TaLib(...)dMode [27] | 10000 |  6,348.5 μs |  20.35 μs |  10.64 μs |  1.00 |    0.00 |  40.33 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 10000 |  8,365.7 μs | 916.51 μs | 606.22 μs |  1.32 |    0.09 | 141.02 KB |        3.50 |
