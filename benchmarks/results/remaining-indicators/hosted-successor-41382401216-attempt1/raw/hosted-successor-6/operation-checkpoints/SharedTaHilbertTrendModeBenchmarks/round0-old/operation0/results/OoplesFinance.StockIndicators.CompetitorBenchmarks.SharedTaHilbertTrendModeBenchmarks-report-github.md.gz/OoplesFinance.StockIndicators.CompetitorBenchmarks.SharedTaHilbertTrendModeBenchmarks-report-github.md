```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **5.100 ms** | **1.6746 ms** | **1.1077 ms** |  **71.75 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  2.598 ms | 0.0215 ms | 0.0128 ms |  24.01 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **26.966 ms** | **0.4634 ms** | **0.2424 ms** |    **636 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 26.855 ms | 0.3430 ms | 0.2269 ms | 166.61 KB |
