```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **4.197 ms** | **0.0673 ms** | **0.0400 ms** |  **71.75 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  2.623 ms | 0.0277 ms | 0.0165 ms |  24.07 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **27.288 ms** | **0.4100 ms** | **0.2712 ms** | **636.41 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 27.488 ms | 0.3405 ms | 0.2026 ms | 166.43 KB |
