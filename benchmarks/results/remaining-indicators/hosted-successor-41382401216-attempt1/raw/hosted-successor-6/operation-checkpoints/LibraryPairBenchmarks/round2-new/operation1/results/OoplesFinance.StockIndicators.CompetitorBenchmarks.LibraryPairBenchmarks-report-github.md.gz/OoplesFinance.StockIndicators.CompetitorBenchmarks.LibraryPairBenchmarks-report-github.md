```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Beta** | **5,843.9 μs** |  **36.61 μs** |  **21.78 μs** |  **1.00** |    **0.00** | **108.47 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Beta |   188.6 μs |  18.48 μs |  11.00 μs |  0.03 |    0.00 |  41.14 KB |        0.38 |
|            |       |                      |            |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Beta** | **6,806.1 μs** | **832.84 μs** | **435.59 μs** |  **1.00** |    **0.08** | **1039.8 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Beta |   221.3 μs |  69.33 μs |  45.86 μs |  0.03 |    0.01 | 331.18 KB |        0.32 |
