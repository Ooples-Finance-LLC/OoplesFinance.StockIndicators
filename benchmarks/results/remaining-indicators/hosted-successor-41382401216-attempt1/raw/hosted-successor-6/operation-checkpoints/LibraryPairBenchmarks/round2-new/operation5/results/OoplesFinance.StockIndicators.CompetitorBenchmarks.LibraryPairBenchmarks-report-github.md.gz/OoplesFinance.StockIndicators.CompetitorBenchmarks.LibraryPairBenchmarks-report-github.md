```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tSine [22]** | **18.647 ms** | **0.0767 ms** | **0.0456 ms** |  **1.00** |    **0.00** |  **166.54 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tSine [22] |  1.965 ms | 0.0136 ms | 0.0090 ms |  0.11 |    0.00 |   74.23 KB |        0.45 |
|            |       |                      |           |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)tSine [22]** | **20.469 ms** | **1.2892 ms** | **0.6743 ms** |  **1.00** |    **0.04** | **1598.85 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tSine [22] |  6.089 ms | 0.1257 ms | 0.0832 ms |  0.30 |    0.01 |  653.33 KB |        0.41 |
