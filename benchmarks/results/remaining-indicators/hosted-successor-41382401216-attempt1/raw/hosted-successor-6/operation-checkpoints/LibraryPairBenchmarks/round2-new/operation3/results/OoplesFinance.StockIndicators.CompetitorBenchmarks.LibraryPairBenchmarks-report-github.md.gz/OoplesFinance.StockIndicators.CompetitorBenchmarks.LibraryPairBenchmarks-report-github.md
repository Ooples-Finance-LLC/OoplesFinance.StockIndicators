```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId             | Mean       | Error     | StdDev   | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-----------:|----------:|---------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Dx** | **3,768.5 μs** |  **49.42 μs** | **32.69 μs** |  **1.00** |  **105.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Dx |   272.2 μs |  14.51 μs |  9.59 μs |  0.07 |    40.6 KB |        0.38 |
|            |       |                    |            |           |          |       |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Dx** | **7,262.8 μs** | **110.10 μs** | **65.52 μs** |  **1.00** | **1036.72 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Dx |   368.2 μs |   9.29 μs |  4.86 μs |  0.05 |  330.59 KB |        0.32 |
