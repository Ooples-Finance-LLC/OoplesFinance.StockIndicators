```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId              | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Cci** | **1,964.0 μs** |  **26.73 μs** |  **15.90 μs** |  **1.00** |    **0.01** |  **106.46 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Cci |   446.1 μs |  15.59 μs |  10.31 μs |  0.23 |    0.01 |   40.73 KB |        0.38 |
|            |       |                     |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Cci** | **3,071.5 μs** | **489.93 μs** | **291.55 μs** |  **1.01** |    **0.13** | **1037.19 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Cci |   478.9 μs |  46.48 μs |  27.66 μs |  0.16 |    0.02 |   331.1 KB |        0.32 |
