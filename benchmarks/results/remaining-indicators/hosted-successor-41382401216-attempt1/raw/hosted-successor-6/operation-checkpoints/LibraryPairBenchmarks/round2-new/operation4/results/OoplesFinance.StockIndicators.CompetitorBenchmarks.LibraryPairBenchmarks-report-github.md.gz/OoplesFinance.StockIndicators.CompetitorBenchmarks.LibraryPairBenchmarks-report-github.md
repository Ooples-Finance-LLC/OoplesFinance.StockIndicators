```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Phase [25]** | **18.589 ms** | **0.1108 ms** | **0.0733 ms** |  **1.00** |    **0.01** |  **110.13 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Phase [25] |  1.854 ms | 0.0112 ms | 0.0067 ms |  0.10 |    0.00 |   41.43 KB |        0.38 |
|            |       |                      |           |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)Phase [25]** | **19.992 ms** | **0.4068 ms** | **0.2421 ms** |  **1.00** |    **0.02** | **1041.47 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Phase [25] |  5.799 ms | 0.0655 ms | 0.0433 ms |  0.29 |    0.00 |   331.8 KB |        0.32 |
