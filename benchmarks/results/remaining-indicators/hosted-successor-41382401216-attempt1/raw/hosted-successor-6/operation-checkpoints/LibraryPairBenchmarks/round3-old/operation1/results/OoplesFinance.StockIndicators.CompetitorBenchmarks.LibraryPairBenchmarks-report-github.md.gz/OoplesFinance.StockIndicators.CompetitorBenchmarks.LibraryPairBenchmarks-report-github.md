```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean     | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |---------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Beta** | **5.797 ms** | **0.0692 ms** | **0.0458 ms** |  **1.00** |    **0.01** | **108.47 KB** |        **1.00** |
|        |       |                      |          |           |           |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Beta** | **6.565 ms** | **2.9127 ms** | **1.9266 ms** |  **1.07** |    **0.39** | **1039.8 KB** |        **1.00** |
