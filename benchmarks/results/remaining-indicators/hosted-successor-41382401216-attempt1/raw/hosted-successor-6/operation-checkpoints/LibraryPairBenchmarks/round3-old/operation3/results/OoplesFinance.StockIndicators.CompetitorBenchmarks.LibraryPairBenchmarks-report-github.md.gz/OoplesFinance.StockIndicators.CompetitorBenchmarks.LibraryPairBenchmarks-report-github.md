```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId             | Mean      | Error      | StdDev    | Median   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |------------------- |----------:|-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Dx** |  **3.624 ms** |  **0.0404 ms** | **0.0240 ms** | **3.623 ms** |  **1.00** |    **0.01** |  **105.71 KB** |        **1.00** |
|        |       |                    |           |            |           |          |       |         |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Dx** | **11.316 ms** | **10.5302 ms** | **6.2664 ms** | **7.308 ms** |  **1.21** |    **0.80** | **1037.05 KB** |        **1.00** |
