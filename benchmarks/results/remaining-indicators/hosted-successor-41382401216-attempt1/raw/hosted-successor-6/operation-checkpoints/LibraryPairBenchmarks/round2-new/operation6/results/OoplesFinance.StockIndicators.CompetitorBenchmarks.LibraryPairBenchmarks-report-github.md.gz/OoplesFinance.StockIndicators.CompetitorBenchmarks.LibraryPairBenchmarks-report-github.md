```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dMode [27]** | **24.910 ms** | **0.1859 ms** | **0.1230 ms** |  **1.00** | **112.75 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dMode [27] |  2.244 ms | 0.0290 ms | 0.0173 ms |  0.09 |   37.9 KB |        0.34 |
|            |       |                      |           |           |           |       |           |             |
| **Ooples**     | **10000** | **TaLib(...)dMode [27]** | **27.181 ms** | **0.5314 ms** | **0.2780 ms** |  **1.00** | **1043.8 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dMode [27] |  6.578 ms | 0.2126 ms | 0.1265 ms |  0.24 | 292.78 KB |        0.28 |
