```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId             | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ma** |   **846.7 μs** |  **33.59 μs** |  **19.99 μs** |  **1.00** |    **0.03** |  **112.63 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ma |   111.9 μs |  19.48 μs |  11.59 μs |  0.13 |    0.01 |   40.91 KB |        0.36 |
|            |       |                    |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ma** | **6,904.1 μs** | **927.66 μs** | **613.59 μs** |  **1.01** |    **0.12** | **1043.97 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ma |   191.7 μs |  20.41 μs |  12.15 μs |  0.03 |    0.00 |  330.66 KB |        0.32 |
