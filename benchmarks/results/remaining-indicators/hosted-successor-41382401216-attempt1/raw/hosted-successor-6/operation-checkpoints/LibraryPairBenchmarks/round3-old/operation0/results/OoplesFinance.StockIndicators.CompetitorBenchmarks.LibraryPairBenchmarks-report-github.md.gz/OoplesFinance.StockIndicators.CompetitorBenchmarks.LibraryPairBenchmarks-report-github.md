```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean     | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |---------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)bands [22]** | **1.188 ms** | **0.0964 ms** | **0.0638 ms** |  **1.00** |    **0.07** |  **205.27 KB** |        **1.00** |
|        |       |                      |          |           |           |       |         |            |             |
| **Ooples** | **10000** | **TaLib(...)bands [22]** | **4.979 ms** | **0.6841 ms** | **0.4525 ms** |  **1.01** |    **0.12** | **1997.93 KB** |        **1.00** |
