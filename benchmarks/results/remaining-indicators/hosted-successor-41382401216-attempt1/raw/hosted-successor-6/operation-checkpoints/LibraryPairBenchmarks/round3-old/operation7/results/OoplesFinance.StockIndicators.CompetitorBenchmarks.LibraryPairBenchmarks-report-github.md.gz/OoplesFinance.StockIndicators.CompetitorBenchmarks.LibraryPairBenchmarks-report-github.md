```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId             | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Ma** |   **972.4 μs** | **215.45 μs** | **142.50 μs** |  **1.02** |    **0.20** |  **112.63 KB** |        **1.00** |
|        |       |                    |            |           |           |       |         |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Ma** | **7,299.7 μs** |  **92.09 μs** |  **48.16 μs** |  **1.00** |    **0.01** | **1043.97 KB** |        **1.00** |
