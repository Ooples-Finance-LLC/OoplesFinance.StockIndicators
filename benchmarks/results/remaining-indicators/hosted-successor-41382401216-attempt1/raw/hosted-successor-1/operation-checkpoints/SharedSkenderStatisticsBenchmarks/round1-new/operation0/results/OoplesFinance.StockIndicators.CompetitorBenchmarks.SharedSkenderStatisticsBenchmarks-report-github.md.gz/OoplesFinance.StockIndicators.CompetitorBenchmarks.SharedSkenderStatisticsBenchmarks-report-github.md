```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Gen0     | Gen1     | Allocated |
|------------------ |---------------- |------ |----------:|----------:|----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetBeta** | **1000**  |  **2.094 ms** | **0.1810 ms** | **0.1077 ms** |        **-** |        **-** |   **1.29 MB** |
| BuilderLatestOnly | Skender.GetBeta | 1000  |  1.408 ms | 0.0916 ms | 0.0545 ms |  78.1250 |  15.6250 |   1.24 MB |
| **BuilderFull**       | **Skender.GetBeta** | **10000** | **14.551 ms** | **0.3203 ms** | **0.1675 ms** | **714.2857** | **571.4286** |  **12.96 MB** |
| BuilderLatestOnly | Skender.GetBeta | 10000 | 14.726 ms | 0.6645 ms | 0.3475 ms | 714.2857 | 428.5714 |  12.51 MB |
