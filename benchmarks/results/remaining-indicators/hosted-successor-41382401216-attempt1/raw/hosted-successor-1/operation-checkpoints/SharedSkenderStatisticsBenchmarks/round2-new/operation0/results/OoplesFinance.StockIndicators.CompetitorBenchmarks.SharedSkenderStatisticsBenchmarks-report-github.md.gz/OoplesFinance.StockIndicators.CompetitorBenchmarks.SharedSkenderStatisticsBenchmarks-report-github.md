```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error       | StdDev    | Ratio | RatioSD | Gen0      | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------------ |---------------- |------ |------------:|------------:|----------:|------:|--------:|----------:|---------:|---------:|----------:|------------:|
| **BuilderFull**       | **Skender.GetBeta** | **1000**  |  **1,676.2 μs** |    **51.53 μs** |  **30.67 μs** |  **4.47** |    **0.09** |         **-** |        **-** |        **-** |   **1.29 MB** |        **0.52** |
| BuilderLatestOnly | Skender.GetBeta | 1000  |  1,420.0 μs |   137.06 μs |  90.66 μs |  3.79 |    0.23 |   78.1250 |  15.6250 |        - |   1.24 MB |        0.50 |
| NativeSingle      | Skender.GetBeta | 1000  |    374.7 μs |     6.65 μs |   3.48 μs |  1.00 |    0.01 |  154.2969 |  42.9688 |        - |   2.47 MB |        1.00 |
| NativeParallel    | Skender.GetBeta | 1000  |    276.2 μs |    12.50 μs |   8.27 μs |  0.74 |    0.02 |  158.2031 |  44.9219 |        - |    2.5 MB |        1.01 |
|                   |                 |       |             |             |           |       |         |           |          |          |           |             |
| **BuilderFull**       | **Skender.GetBeta** | **10000** | **15,196.4 μs** | **1,030.06 μs** | **681.32 μs** |  **2.65** |    **0.12** |  **714.2857** | **571.4286** |        **-** |  **12.96 MB** |        **0.52** |
| BuilderLatestOnly | Skender.GetBeta | 10000 | 14,849.5 μs |   650.86 μs | 430.50 μs |  2.59 |    0.09 |  714.2857 | 428.5714 |        - |  12.51 MB |        0.50 |
| NativeSingle      | Skender.GetBeta | 10000 |  5,737.3 μs |   219.02 μs | 114.55 μs |  1.00 |    0.03 | 1687.5000 | 812.5000 | 187.5000 |  25.13 MB |        1.00 |
| NativeParallel    | Skender.GetBeta | 10000 |  3,611.1 μs |   333.66 μs | 220.69 μs |  0.63 |    0.04 | 1593.7500 | 718.7500 |        - |  25.23 MB |        1.00 |
