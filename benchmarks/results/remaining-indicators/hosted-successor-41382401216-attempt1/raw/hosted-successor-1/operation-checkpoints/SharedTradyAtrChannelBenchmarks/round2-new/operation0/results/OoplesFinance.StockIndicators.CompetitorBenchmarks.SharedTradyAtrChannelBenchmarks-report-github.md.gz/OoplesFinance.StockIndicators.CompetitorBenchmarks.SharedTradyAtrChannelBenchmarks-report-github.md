```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **ChandelierExit** | **1000**  |    **166.4 μs** |     **1.86 μs** |     **1.11 μs** |  **0.12** |    **0.00** |         **-** |         **-** |        **-** |    **73.65 KB** |       **0.028** |
| BuilderLatestOnly | ChandelierExit | 1000  |    165.8 μs |     0.84 μs |     0.55 μs |  0.12 |    0.00 |    0.9766 |         - |        - |    26.05 KB |       0.010 |
| NativeSingle      | ChandelierExit | 1000  |  1,411.4 μs |    23.51 μs |    13.99 μs |  1.00 |    0.01 |  148.4375 |   93.7500 |  31.2500 |  2630.98 KB |       1.000 |
| NativeParallel    | ChandelierExit | 1000  |  1,004.0 μs |    10.20 μs |     5.33 μs |  0.71 |    0.01 |  250.0000 |  125.0000 |        - |  3937.18 KB |       1.496 |
|                   |                |       |             |             |             |       |         |           |           |          |             |             |
| **BuilderFull**       | **ChandelierExit** | **10000** |  **2,027.2 μs** |    **17.59 μs** |     **9.20 μs** |  **0.12** |    **0.01** |   **31.2500** |         **-** |        **-** |   **706.91 KB** |       **0.028** |
| BuilderLatestOnly | ChandelierExit | 10000 |  1,997.3 μs |     6.14 μs |     3.65 μs |  0.11 |    0.01 |         - |         - |        - |   237.07 KB |       0.009 |
| NativeSingle      | ChandelierExit | 10000 | 17,481.2 μs | 2,002.38 μs | 1,324.45 μs |  1.00 |    0.10 | 1571.4286 | 1000.0000 | 714.2857 | 25626.76 KB |       1.000 |
| NativeParallel    | ChandelierExit | 10000 | 14,830.7 μs | 2,336.29 μs | 1,545.31 μs |  0.85 |    0.10 | 2142.8571 | 1285.7143 | 714.2857 | 38820.02 KB |       1.515 |
