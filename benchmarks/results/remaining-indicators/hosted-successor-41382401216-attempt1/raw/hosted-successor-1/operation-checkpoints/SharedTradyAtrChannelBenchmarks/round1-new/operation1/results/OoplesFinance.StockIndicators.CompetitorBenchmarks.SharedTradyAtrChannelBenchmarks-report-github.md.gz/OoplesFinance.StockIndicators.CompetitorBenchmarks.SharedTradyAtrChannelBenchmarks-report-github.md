```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **KeltnerChannels** | **1000**  |   **214.0 μs** | **15.25 μs** | **10.09 μs** |       **-** |       **-** |  **96.79 KB** |
| BuilderLatestOnly | KeltnerChannels | 1000  |   206.0 μs |  1.38 μs |  0.82 μs |  1.9531 |       - |  49.22 KB |
| **BuilderFull**       | **KeltnerChannels** | **10000** | **2,267.4 μs** | **15.97 μs** |  **9.50 μs** | **46.8750** | **15.6250** |    **941 KB** |
| BuilderLatestOnly | KeltnerChannels | 10000 | 2,261.0 μs | 11.51 μs |  6.85 μs | 15.6250 |       - |  471.2 KB |
