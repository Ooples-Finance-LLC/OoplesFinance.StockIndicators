```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **ChandelierExit** | **1000**  |   **164.9 μs** |  **2.78 μs** |  **1.65 μs** |       **-** |  **73.65 KB** |
| BuilderLatestOnly | ChandelierExit | 1000  |   165.3 μs |  1.28 μs |  0.67 μs |  0.9766 |  26.05 KB |
| **BuilderFull**       | **ChandelierExit** | **10000** | **2,026.1 μs** |  **5.30 μs** |  **2.77 μs** | **31.2500** | **706.91 KB** |
| BuilderLatestOnly | ChandelierExit | 10000 | 1,994.4 μs | 42.89 μs | 25.52 μs |       - | 237.06 KB |
