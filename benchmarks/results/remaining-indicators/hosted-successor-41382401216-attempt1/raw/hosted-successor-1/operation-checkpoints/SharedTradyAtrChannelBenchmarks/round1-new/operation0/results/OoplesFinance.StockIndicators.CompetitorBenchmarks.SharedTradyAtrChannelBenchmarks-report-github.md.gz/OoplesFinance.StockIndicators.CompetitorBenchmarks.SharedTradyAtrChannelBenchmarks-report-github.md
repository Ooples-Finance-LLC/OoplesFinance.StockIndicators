```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev  | Gen0    | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **ChandelierExit** | **1000**  |   **169.0 μs** |  **1.08 μs** | **0.57 μs** |       **-** |  **73.65 KB** |
| BuilderLatestOnly | ChandelierExit | 1000  |   162.7 μs |  2.28 μs | 1.51 μs |  0.9766 |  26.05 KB |
| **BuilderFull**       | **ChandelierExit** | **10000** | **2,030.4 μs** | **17.34 μs** | **9.07 μs** | **31.2500** | **706.92 KB** |
| BuilderLatestOnly | ChandelierExit | 10000 | 1,986.5 μs |  8.35 μs | 4.37 μs |       - | 237.11 KB |
