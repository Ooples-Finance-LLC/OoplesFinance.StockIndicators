```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **KeltnerChannels** | **1000**  |   **207.4 μs** |  **3.24 μs** | **1.93 μs** |       **-** |       **-** |  **96.83 KB** |
| BuilderLatestOnly | KeltnerChannels | 1000  |   204.8 μs |  1.58 μs | 0.83 μs |  1.9531 |       - |  49.23 KB |
| **BuilderFull**       | **KeltnerChannels** | **10000** | **2,252.0 μs** | **16.79 μs** | **9.99 μs** | **46.8750** | **15.6250** | **941.02 KB** |
| BuilderLatestOnly | KeltnerChannels | 10000 | 2,208.4 μs | 10.04 μs | 5.25 μs | 15.6250 |       - | 471.18 KB |
