```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **KeltnerChannels** | **1000**  |   **210.8 μs** |  **7.56 μs** | **4.50 μs** |       **-** |       **-** |  **96.83 KB** |
| BuilderLatestOnly | KeltnerChannels | 1000  |   207.1 μs |  3.83 μs | 2.28 μs |  1.9531 |       - |  49.22 KB |
| **BuilderFull**       | **KeltnerChannels** | **10000** | **2,263.5 μs** |  **9.08 μs** | **4.75 μs** | **46.8750** | **15.6250** | **941.04 KB** |
| BuilderLatestOnly | KeltnerChannels | 10000 | 2,242.2 μs | 10.48 μs | 5.48 μs | 15.6250 |       - | 471.18 KB |
