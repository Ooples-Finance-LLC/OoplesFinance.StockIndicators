```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated   | Alloc Ratio |
|------------------ |---------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **KeltnerChannels** | **1000**  |    **207.7 μs** |     **1.35 μs** |     **0.81 μs** |  **0.14** |    **0.00** |         **-** |         **-** |        **-** |    **96.79 KB** |        **0.03** |
| BuilderLatestOnly | KeltnerChannels | 1000  |    207.6 μs |     2.39 μs |     1.42 μs |  0.14 |    0.00 |    1.9531 |         - |        - |    49.22 KB |        0.02 |
| NativeSingle      | KeltnerChannels | 1000  |  1,435.1 μs |    32.88 μs |    19.56 μs |  1.00 |    0.02 |  203.1250 |  140.6250 |  46.8750 |  3049.18 KB |        1.00 |
| NativeParallel    | KeltnerChannels | 1000  |  1,172.4 μs |    68.18 μs |    45.09 μs |  0.82 |    0.03 |  312.5000 |  171.8750 |        - |  4839.31 KB |        1.59 |
|                   |                 |       |             |             |             |       |         |           |           |          |             |             |
| **BuilderFull**       | **KeltnerChannels** | **10000** |  **2,271.6 μs** |    **26.22 μs** |    **17.34 μs** |  **0.14** |    **0.01** |   **46.8750** |   **15.6250** |        **-** |      **941 KB** |        **0.03** |
| BuilderLatestOnly | KeltnerChannels | 10000 |  2,236.4 μs |    16.64 μs |     9.90 μs |  0.14 |    0.01 |   15.6250 |         - |        - |   471.18 KB |        0.02 |
| NativeSingle      | KeltnerChannels | 10000 | 16,433.0 μs | 1,451.78 μs |   960.26 μs |  1.00 |    0.08 | 1714.2857 | 1142.8571 | 714.2857 | 29771.13 KB |        1.00 |
| NativeParallel    | KeltnerChannels | 10000 | 15,839.4 μs | 2,016.67 μs | 1,333.90 μs |  0.97 |    0.09 | 2571.4286 | 1714.2857 | 857.1429 | 47666.86 KB |        1.60 |
