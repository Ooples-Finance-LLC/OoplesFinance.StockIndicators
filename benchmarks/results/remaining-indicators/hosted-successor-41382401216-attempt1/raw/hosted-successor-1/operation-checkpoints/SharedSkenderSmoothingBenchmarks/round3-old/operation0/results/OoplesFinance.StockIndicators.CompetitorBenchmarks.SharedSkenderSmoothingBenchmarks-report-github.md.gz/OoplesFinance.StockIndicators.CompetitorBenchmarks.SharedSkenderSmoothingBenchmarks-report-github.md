```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |-------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetElderRay** | **1000**  |  **74.69 μs** | **0.611 μs** | **0.364 μs** |  **3.9063** |       **-** |  **80.61 KB** |
| BuilderLatestOnly | Skender.GetElderRay | 1000  |  72.22 μs | 0.455 μs | 0.301 μs |  1.9531 |       - |     33 KB |
| **BuilderFull**       | **Skender.GetElderRay** | **10000** | **777.64 μs** | **5.176 μs** | **3.080 μs** | **46.8750** | **19.5313** |  **784.1 KB** |
| BuilderLatestOnly | Skender.GetElderRay | 10000 | 754.63 μs | 3.786 μs | 2.253 μs | 15.6250 |  3.9063 | 314.28 KB |
