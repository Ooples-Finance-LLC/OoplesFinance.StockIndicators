```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetElderRay** | **1000**  |    **75.37 μs** |  **0.700 μs** |  **0.417 μs** |  **1.02** |    **0.01** |   **3.9063** |        **-** |       **-** |   **80.61 KB** |        **0.32** |
| BuilderLatestOnly | Skender.GetElderRay | 1000  |    72.74 μs |  0.868 μs |  0.454 μs |  0.99 |    0.01 |   1.9531 |        - |       - |      33 KB |        0.13 |
| NativeSingle      | Skender.GetElderRay | 1000  |    73.72 μs |  1.620 μs |  0.847 μs |  1.00 |    0.02 |  15.1367 |   3.9063 |       - |  251.06 KB |        1.00 |
| NativeParallel    | Skender.GetElderRay | 1000  |   131.59 μs | 11.647 μs |  7.704 μs |  1.79 |    0.10 |  41.0156 |  13.6719 |       - |  637.18 KB |        2.54 |
|                   |                     |       |             |           |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skender.GetElderRay** | **10000** |   **781.31 μs** |  **4.133 μs** |  **2.734 μs** |  **0.81** |    **0.00** |  **46.8750** |  **23.4375** |       **-** |  **784.12 KB** |        **0.31** |
| BuilderLatestOnly | Skender.GetElderRay | 10000 |   760.50 μs |  7.590 μs |  4.516 μs |  0.79 |    0.01 |  15.6250 |   3.9063 |       - |  314.28 KB |        0.13 |
| NativeSingle      | Skender.GetElderRay | 10000 |   960.15 μs |  9.350 μs |  4.890 μs |  1.00 |    0.01 | 148.4375 | 101.5625 | 46.8750 | 2501.46 KB |        1.00 |
| NativeParallel    | Skender.GetElderRay | 10000 | 1,593.55 μs | 48.698 μs | 25.470 μs |  1.66 |    0.03 | 421.8750 | 359.3750 | 78.1250 | 6333.22 KB |        2.53 |
