```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId             | Mean       | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |------------------- |-----------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.T3** |   **726.1 μs** |    **34.75 μs** |    **22.98 μs** |  **1.00** |    **0.04** |  **105.89 KB** |        **1.00** |
|        |       |                    |            |             |             |       |         |            |             |
| **Ooples** | **10000** | **TaLib.Functions.T3** | **7,863.3 μs** | **1,573.11 μs** | **1,040.51 μs** |  **1.02** |    **0.18** | **1035.91 KB** |        **1.00** |
