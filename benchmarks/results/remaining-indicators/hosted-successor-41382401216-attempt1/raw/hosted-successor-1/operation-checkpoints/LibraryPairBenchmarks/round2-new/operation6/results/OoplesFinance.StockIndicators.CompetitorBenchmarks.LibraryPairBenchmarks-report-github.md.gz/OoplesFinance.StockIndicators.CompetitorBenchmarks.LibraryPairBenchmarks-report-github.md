```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)nLine [44]** |    **937.6 μs** |    **40.94 μs** |    **24.37 μs** |  **1.00** |    **0.03** |  **194.68 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)nLine [44] |  2,482.3 μs |   157.38 μs |    93.66 μs |  2.65 |    0.11 |  965.26 KB |        4.96 |
|            |       |                      |             |             |             |       |         |            |             |
| **Ooples**     | **10000** | **Trady(...)nLine [44]** |  **7,323.8 μs** | **2,018.38 μs** | **1,335.03 μs** |  **1.03** |    **0.24** | **2340.89 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)nLine [44] | 16,459.6 μs |   200.28 μs |   119.18 μs |  2.31 |    0.35 | 9433.27 KB |        4.03 |
