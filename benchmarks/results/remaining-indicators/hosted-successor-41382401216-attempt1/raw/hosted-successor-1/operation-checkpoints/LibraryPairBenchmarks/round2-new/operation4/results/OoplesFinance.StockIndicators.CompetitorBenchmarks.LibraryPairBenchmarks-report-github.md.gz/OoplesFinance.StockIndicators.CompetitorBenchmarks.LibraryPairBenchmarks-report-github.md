```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId             | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-----------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.T3** |   **736.8 μs** |    **26.36 μs** |  **15.69 μs** |  **1.00** |    **0.03** |  **105.89 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.T3 |   112.2 μs |    10.48 μs |   5.48 μs |  0.15 |    0.01 |   40.59 KB |        0.38 |
|            |       |                    |            |             |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.T3** | **2,829.5 μs** | **1,035.69 μs** | **541.68 μs** |  **1.03** |    **0.25** | **1037.23 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.T3 |   122.6 μs |     5.90 μs |   3.51 μs |  0.04 |    0.01 |  329.27 KB |        0.32 |
