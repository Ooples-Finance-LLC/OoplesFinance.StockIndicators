```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId             | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |------------------- |-----------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.T3** |   **717.4 μs** |    **25.16 μs** |  **14.97 μs** |  **1.00** |    **0.03** |  **105.89 KB** |        **1.00** |
|        |       |                    |            |             |           |       |         |            |             |
| **Ooples** | **10000** | **TaLib.Functions.T3** | **7,956.2 μs** | **1,103.26 μs** | **656.53 μs** |  **1.01** |    **0.12** | **1035.59 KB** |        **1.00** |
