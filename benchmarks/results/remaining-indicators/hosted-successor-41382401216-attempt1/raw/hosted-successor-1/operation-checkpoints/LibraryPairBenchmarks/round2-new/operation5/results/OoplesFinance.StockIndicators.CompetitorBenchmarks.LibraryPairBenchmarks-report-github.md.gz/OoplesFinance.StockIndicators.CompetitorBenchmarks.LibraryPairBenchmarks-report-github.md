```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error    | StdDev   | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|---------:|---------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Trix** |  **2,117.9 μs** |  **8.45 μs** |  **5.03 μs** |  **1.00** |  **193.01 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Trix |    134.8 μs | 13.87 μs |  9.17 μs |  0.06 |   48.46 KB |        0.25 |
|            |       |                      |             |          |          |       |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Trix** | **17,805.6 μs** | **56.20 μs** | **29.39 μs** |  **1.00** | **1897.78 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Trix |    235.6 μs | 23.23 μs | 15.37 μs |  0.01 |  408.48 KB |        0.22 |
