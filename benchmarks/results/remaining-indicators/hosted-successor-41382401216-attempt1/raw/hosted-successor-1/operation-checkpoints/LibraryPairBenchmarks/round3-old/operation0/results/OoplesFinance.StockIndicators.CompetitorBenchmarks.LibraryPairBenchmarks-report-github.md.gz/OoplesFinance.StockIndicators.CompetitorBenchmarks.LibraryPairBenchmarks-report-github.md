```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId              | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |-------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Ppo** |  **2.795 ms** | **0.0182 ms** | **0.0108 ms** |  **1.00** |    **0.01** |   **1.47 MB** |        **1.00** |
|        |       |                     |           |           |           |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Ppo** | **23.953 ms** | **4.1177 ms** | **2.7236 ms** |  **1.01** |    **0.16** |  **14.78 MB** |        **1.00** |
