```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)chRsi [24]** |  **2,647.5 μs** |  **86.23 μs** |  **57.04 μs** |  **1.00** |    **0.03** |  **264.34 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)chRsi [24] |    298.1 μs |  12.52 μs |   8.28 μs |  0.11 |    0.00 |   88.31 KB |        0.33 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)chRsi [24]** | **20,993.4 μs** | **202.09 μs** | **133.67 μs** |  **1.00** |    **0.01** | **2610.71 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)chRsi [24] |    613.9 μs |  25.17 μs |  14.98 μs |  0.03 |    0.00 |  809.02 KB |        0.31 |
