```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId              | Mean        | Error       | StdDev    | Ratio | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |-------------------- |------------:|------------:|----------:|------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ppo** |  **2,833.4 μs** |    **62.32 μs** |  **37.08 μs** |  **1.00** |    **0.02** |  **1505.25 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ppo |    125.1 μs |    10.74 μs |   7.10 μs |  0.04 |    0.00 |    48.51 KB |        0.03 |
|            |       |                     |             |             |           |       |         |             |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ppo** | **21,072.4 μs** | **1,079.01 μs** | **564.35 μs** |  **1.00** |    **0.03** | **15133.63 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ppo |    218.1 μs |    19.28 μs |  10.08 μs |  0.01 |    0.00 |   409.19 KB |        0.03 |
