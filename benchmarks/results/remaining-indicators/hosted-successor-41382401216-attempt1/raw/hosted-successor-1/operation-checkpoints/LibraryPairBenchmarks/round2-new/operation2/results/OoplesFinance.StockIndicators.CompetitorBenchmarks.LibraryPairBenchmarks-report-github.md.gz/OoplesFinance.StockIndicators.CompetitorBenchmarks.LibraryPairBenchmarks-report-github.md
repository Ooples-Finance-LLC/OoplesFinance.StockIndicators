```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tochF [22]** |  **1,721.5 μs** |    **23.19 μs** |    **13.80 μs** |  **1.00** |    **0.01** |  **469.99 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tochF [22] |    240.0 μs |    13.98 μs |     9.25 μs |  0.14 |    0.01 |   97.05 KB |        0.21 |
|            |       |                      |             |             |             |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)tochF [22]** | **13,640.6 μs** | **2,476.20 μs** | **1,637.85 μs** |  **1.01** |    **0.16** | **4644.21 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tochF [22] |    437.7 μs |    16.95 μs |    11.21 μs |  0.03 |    0.00 |  888.34 KB |        0.19 |
