```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)rExit [30]** |  **1.566 ms** | **0.0333 ms** | **0.0198 ms** |  **1.00** |    **0.02** |         **-** |         **-** |         **-** |   **155.14 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)rExit [30] |  6.149 ms | 0.1419 ms | 0.0845 ms |  3.93 |    0.07 |         - |         - |         - |  3535.73 KB |       22.79 |
|            |       |                      |           |           |           |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)rExit [30]** | **11.978 ms** | **0.4370 ms** | **0.2600 ms** |  **1.00** |    **0.03** |         **-** |         **-** |         **-** |  **1517.84 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)rExit [30] | 26.983 ms | 4.5255 ms | 2.9933 ms |  2.25 |    0.24 | 2000.0000 | 1000.0000 | 1000.0000 | 28940.75 KB |       19.07 |
