```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Expon(...)erage [24]** | **1000**  |  **26.57 μs** | **0.513 μs** | **0.269 μs** |  **2.9297** |       **-** |  **56.66 KB** |
| BuilderLatestOnly | Expon(...)erage [24] | 1000  |  24.54 μs | 0.101 μs | 0.053 μs |  0.4883 |       - |   8.78 KB |
| **BuilderFull**       | **Expon(...)erage [24]** | **10000** | **220.62 μs** | **3.091 μs** | **2.044 μs** | **33.2031** | **13.6719** |  **549.2 KB** |
| BuilderLatestOnly | Expon(...)erage [24] | 10000 | 210.72 μs | 1.239 μs | 0.648 μs |  3.9063 |       - |   79.1 KB |
