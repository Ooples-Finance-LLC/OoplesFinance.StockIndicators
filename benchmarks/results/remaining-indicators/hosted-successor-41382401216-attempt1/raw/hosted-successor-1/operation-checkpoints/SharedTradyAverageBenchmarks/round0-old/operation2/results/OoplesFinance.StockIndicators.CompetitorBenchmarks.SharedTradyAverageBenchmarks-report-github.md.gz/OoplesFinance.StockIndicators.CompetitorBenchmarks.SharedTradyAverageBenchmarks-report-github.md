```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Simpl(...)lator [29]** | **1000**  |  **46.26 μs** |  **0.804 μs** |  **0.420 μs** |  **3.9063** |       **-** |  **69.55 KB** |
| BuilderLatestOnly | Simpl(...)lator [29] | 1000  |  47.79 μs |  1.336 μs |  0.884 μs |  1.2207 |       - |  21.94 KB |
| **BuilderFull**       | **Simpl(...)lator [29]** | **10000** | **287.47 μs** | **37.391 μs** | **24.732 μs** | **37.1094** | **15.6250** | **632.41 KB** |
| BuilderLatestOnly | Simpl(...)lator [29] | 10000 | 262.96 μs | 27.005 μs | 17.862 μs |  9.7656 |  1.9531 | 162.58 KB |
