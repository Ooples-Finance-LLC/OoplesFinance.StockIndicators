```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0      | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|----------:|---------:|---------:|------------:|------------:|
| **BuilderFull**       | **Simpl(...)lator [29]** | **1000**  |    **47.96 μs** |   **0.862 μs** |   **0.513 μs** |  **0.06** |    **0.00** |    **3.9063** |        **-** |        **-** |    **69.55 KB** |        **0.06** |
| BuilderLatestOnly | Simpl(...)lator [29] | 1000  |    43.84 μs |   1.412 μs |   0.840 μs |  0.06 |    0.00 |    1.2207 |        - |        - |    21.94 KB |        0.02 |
| NativeSingle      | Simpl(...)lator [29] | 1000  |   777.79 μs |   7.016 μs |   3.670 μs |  1.00 |    0.01 |   62.5000 |  23.4375 |        - |   1081.5 KB |        1.00 |
| NativeParallel    | Simpl(...)lator [29] | 1000  |   431.08 μs |  53.470 μs |  35.367 μs |  0.55 |    0.04 |   66.4063 |  19.5313 |        - |   1055.8 KB |        0.98 |
|                   |                      |       |             |            |            |       |         |           |          |          |             |             |
| **BuilderFull**       | **Simpl(...)lator [29]** | **10000** |   **290.03 μs** |  **44.343 μs** |  **29.330 μs** |  **0.03** |    **0.00** |   **37.1094** |  **15.6250** |        **-** |   **632.41 KB** |        **0.06** |
| BuilderLatestOnly | Simpl(...)lator [29] | 10000 |   249.19 μs |   5.956 μs |   3.544 μs |  0.03 |    0.00 |    7.8125 |        - |        - |    162.6 KB |        0.02 |
| NativeSingle      | Simpl(...)lator [29] | 10000 | 8,656.36 μs | 265.720 μs | 158.125 μs |  1.00 |    0.02 | 1090.9091 | 818.1818 | 727.2727 | 10508.81 KB |        1.00 |
| NativeParallel    | Simpl(...)lator [29] | 10000 | 6,174.07 μs | 953.942 μs | 630.973 μs |  0.71 |    0.07 | 1000.0000 | 800.0000 | 533.3333 | 10388.27 KB |        0.99 |
