```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Expon(...)erage [24]** | **1000**  |  **27.51 μs** | **0.736 μs** | **0.487 μs** |  **2.9297** |       **-** |  **56.66 KB** |
| BuilderLatestOnly | Expon(...)erage [24] | 1000  |  24.54 μs | 0.376 μs | 0.224 μs |  0.4883 |       - |   8.78 KB |
| **BuilderFull**       | **Expon(...)erage [24]** | **10000** | **223.96 μs** | **2.468 μs** | **1.291 μs** | **33.2031** | **13.6719** | **549.21 KB** |
| BuilderLatestOnly | Expon(...)erage [24] | 10000 | 208.97 μs | 1.628 μs | 1.077 μs |  3.9063 |       - |   79.1 KB |
