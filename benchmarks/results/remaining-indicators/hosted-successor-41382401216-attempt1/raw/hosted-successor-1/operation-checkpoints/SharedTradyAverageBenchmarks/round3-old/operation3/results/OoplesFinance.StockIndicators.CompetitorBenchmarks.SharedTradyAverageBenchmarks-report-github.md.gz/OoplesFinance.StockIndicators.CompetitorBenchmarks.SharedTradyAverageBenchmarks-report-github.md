```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Expon(...)lator [34]** | **1000**  |  **57.22 μs** |  **0.807 μs** | **0.480 μs** |  **3.9063** |       **-** |  **64.93 KB** |
| BuilderLatestOnly | Expon(...)lator [34] | 1000  |  54.34 μs |  0.408 μs | 0.270 μs |  0.9766 |       - |  17.32 KB |
| **BuilderFull**       | **Expon(...)lator [34]** | **10000** | **725.28 μs** |  **8.377 μs** | **4.985 μs** | **35.1563** | **11.7188** |  **627.8 KB** |
| BuilderLatestOnly | Expon(...)lator [34] | 10000 | 705.24 μs | 13.934 μs | 9.216 μs |  7.8125 |       - | 157.97 KB |
