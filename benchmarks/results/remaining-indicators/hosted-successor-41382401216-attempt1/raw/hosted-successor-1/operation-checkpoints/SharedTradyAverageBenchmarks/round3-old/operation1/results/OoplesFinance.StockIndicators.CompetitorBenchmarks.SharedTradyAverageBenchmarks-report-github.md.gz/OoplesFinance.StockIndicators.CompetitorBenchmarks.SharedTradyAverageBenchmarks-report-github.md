```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Weigh(...)erage [21]** | **1000**  | **15.53 μs** | **0.769 μs** | **0.457 μs** |  **3.4180** |  **0.4883** |  **58.47 KB** |
| BuilderLatestOnly | Weigh(...)erage [21] | 1000  | 10.21 μs | 1.686 μs | 1.003 μs |  0.6104 |       - |  10.59 KB |
| **BuilderFull**       | **Weigh(...)erage [21]** | **10000** | **80.50 μs** | **6.256 μs** | **3.723 μs** | **33.2031** | **11.7188** | **551.01 KB** |
| BuilderLatestOnly | Weigh(...)erage [21] | 10000 | 65.26 μs | 4.380 μs | 2.897 μs |  4.8828 |  0.4883 |   80.9 KB |
