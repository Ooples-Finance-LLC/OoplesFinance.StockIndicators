```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|----------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **Expon(...)erage [24]** | **1000**  |    **27.19 μs** |   **0.929 μs** |   **0.615 μs** |  **0.06** |    **0.00** |    **2.9297** |         **-** |        **-** |    **56.66 KB** |       **0.062** |
| BuilderLatestOnly | Expon(...)erage [24] | 1000  |    23.98 μs |   0.138 μs |   0.082 μs |  0.06 |    0.00 |    0.4883 |         - |        - |     8.78 KB |       0.010 |
| NativeSingle      | Expon(...)erage [24] | 1000  |   431.56 μs |   5.833 μs |   3.051 μs |  1.00 |    0.01 |   54.6875 |   15.6250 |        - |   915.28 KB |       1.000 |
| NativeParallel    | Expon(...)erage [24] | 1000  |   408.47 μs |   9.300 μs |   4.864 μs |  0.95 |    0.01 |   82.0313 |   27.3438 |        - |  1328.65 KB |       1.452 |
|                   |                      |       |             |            |            |       |         |           |           |          |             |             |
| **BuilderFull**       | **Expon(...)erage [24]** | **10000** |   **225.71 μs** |   **2.545 μs** |   **1.683 μs** |  **0.05** |    **0.00** |   **33.2031** |   **13.6719** |        **-** |   **549.21 KB** |       **0.062** |
| BuilderLatestOnly | Expon(...)erage [24] | 10000 |   209.25 μs |   2.830 μs |   1.872 μs |  0.04 |    0.00 |    3.9063 |         - |        - |     79.1 KB |       0.009 |
| NativeSingle      | Expon(...)erage [24] | 10000 | 4,841.14 μs | 139.702 μs |  83.134 μs |  1.00 |    0.02 | 1312.5000 | 1031.2500 | 968.7500 |  8914.42 KB |       1.000 |
| NativeParallel    | Expon(...)erage [24] | 10000 | 7,191.35 μs | 548.088 μs | 326.159 μs |  1.49 |    0.07 | 1357.1429 | 1000.0000 | 857.1429 | 13010.44 KB |       1.459 |
