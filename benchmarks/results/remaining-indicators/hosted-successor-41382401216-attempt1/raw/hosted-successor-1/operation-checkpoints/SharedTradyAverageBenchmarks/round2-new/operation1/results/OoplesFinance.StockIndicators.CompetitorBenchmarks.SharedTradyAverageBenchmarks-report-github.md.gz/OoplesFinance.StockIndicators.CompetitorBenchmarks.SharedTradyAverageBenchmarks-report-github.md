```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Weigh(...)erage [21]** | **1000**  |     **15.23 μs** |   **1.085 μs** |   **0.646 μs** | **0.010** |    **0.00** |   **3.4180** |   **0.4883** |        **-** |   **58.47 KB** |        **0.10** |
| BuilderLatestOnly | Weigh(...)erage [21] | 1000  |     10.39 μs |   0.939 μs |   0.621 μs | 0.007 |    0.00 |   0.6104 |        - |        - |   10.59 KB |        0.02 |
| NativeSingle      | Weigh(...)erage [21] | 1000  |  1,501.60 μs |  14.500 μs |   8.629 μs | 1.000 |    0.01 |  31.2500 |   7.8125 |        - |  559.52 KB |        1.00 |
| NativeParallel    | Weigh(...)erage [21] | 1000  |    768.38 μs |  50.390 μs |  33.330 μs | 0.512 |    0.02 |  31.2500 |   7.8125 |        - |   565.1 KB |        1.01 |
|                   |                      |       |              |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Weigh(...)erage [21]** | **10000** |     **84.38 μs** |   **6.181 μs** |   **4.088 μs** | **0.005** |    **0.00** |  **33.2031** |  **12.2070** |        **-** |  **551.01 KB** |        **0.10** |
| BuilderLatestOnly | Weigh(...)erage [21] | 10000 |     65.67 μs |   3.686 μs |   2.438 μs | 0.004 |    0.00 |   4.8828 |   0.4883 |        - |    80.9 KB |        0.01 |
| NativeSingle      | Weigh(...)erage [21] | 10000 | 15,904.55 μs | 233.718 μs | 139.082 μs | 1.000 |    0.01 | 571.4286 | 428.5714 | 428.5714 | 5508.45 KB |        1.00 |
| NativeParallel    | Weigh(...)erage [21] | 10000 |  8,376.45 μs | 136.410 μs |  81.175 μs | 0.527 |    0.01 | 461.5385 | 307.6923 | 230.7692 | 5621.04 KB |        1.02 |
