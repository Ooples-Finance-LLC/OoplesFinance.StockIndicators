```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error        | StdDev       | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-------------:|-------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Expon(...)lator [34]** | **1000**  |     **58.38 μs** |     **0.363 μs** |     **0.216 μs** |  **0.06** |    **0.00** |    **3.9063** |         **-** |         **-** |    **64.93 KB** |       **0.030** |
| BuilderLatestOnly | Expon(...)lator [34] | 1000  |     54.39 μs |     0.442 μs |     0.231 μs |  0.05 |    0.00 |    0.9766 |         - |         - |    17.32 KB |       0.008 |
| NativeSingle      | Expon(...)lator [34] | 1000  |  1,048.37 μs |     9.829 μs |     6.501 μs |  1.00 |    0.01 |  132.8125 |   54.6875 |         - |  2200.74 KB |       1.000 |
| NativeParallel    | Expon(...)lator [34] | 1000  |    913.37 μs |    21.764 μs |    11.383 μs |  0.87 |    0.01 |  210.9375 |   85.9375 |         - |  3332.39 KB |       1.514 |
|                   |                      |       |              |              |              |       |         |           |           |           |             |             |
| **BuilderFull**       | **Expon(...)lator [34]** | **10000** |    **734.25 μs** |     **2.911 μs** |     **1.522 μs** |  **0.05** |    **0.00** |   **35.1563** |   **11.7188** |         **-** |   **627.77 KB** |       **0.029** |
| BuilderLatestOnly | Expon(...)lator [34] | 10000 |    709.30 μs |     5.889 μs |     3.504 μs |  0.05 |    0.00 |    7.8125 |         - |         - |   157.97 KB |       0.007 |
| NativeSingle      | Expon(...)lator [34] | 10000 | 13,805.05 μs | 1,293.478 μs |   855.556 μs |  1.00 |    0.08 | 1500.0000 | 1000.0000 |  750.0000 | 21974.16 KB |       1.000 |
| NativeParallel    | Expon(...)lator [34] | 10000 | 13,937.50 μs | 3,175.259 μs | 2,100.237 μs |  1.01 |    0.16 | 2285.7143 | 1571.4286 | 1000.0000 | 33529.79 KB |       1.526 |
