```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev  | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **388.7 μs** |  **4.28 μs** | **2.55 μs** |       **-** |  **73.57 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   380.9 μs |  3.01 μs | 1.57 μs |       - |  25.91 KB |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **3,835.9 μs** | **10.74 μs** | **5.62 μs** | **31.2500** | **706.87 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 3,900.7 μs |  7.70 μs | 4.58 μs |       - | 236.97 KB |
