```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio  | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|-------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **378.242 μs** |  **3.2405 μs** |  **1.9284 μs** | **154.26** |    **2.74** |       **-** |      **-** |  **73.57 KB** |        **9.43** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   367.210 μs |  1.3484 μs |  0.8024 μs | 149.76 |    2.58 |       - |      - |  25.91 KB |        3.32 |
| NativeSingle      | TaLib(...)AdOsc [21] | 1000  |     2.453 μs |  0.0674 μs |  0.0446 μs |   1.00 |    0.02 |  0.4730 |      - |    7.8 KB |        1.00 |
| NativeParallel    | TaLib(...)AdOsc [21] | 1000  |     6.375 μs |  0.1782 μs |  0.1179 μs |   2.60 |    0.06 |  1.8921 | 0.0610 |  27.56 KB |        3.53 |
|                   |                      |       |              |            |            |        |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **3,825.954 μs** | **30.3777 μs** | **20.0930 μs** | **174.26** |    **1.32** | **31.2500** |      **-** | **706.89 KB** |        **9.05** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 3,919.462 μs | 13.2522 μs |  7.8862 μs | 178.52 |    1.07 |       - |      - | 237.04 KB |        3.03 |
| NativeSingle      | TaLib(...)AdOsc [21] | 10000 |    21.956 μs |  0.2208 μs |  0.1314 μs |   1.00 |    0.01 |  4.7607 |      - |  78.12 KB |        1.00 |
| NativeParallel    | TaLib(...)AdOsc [21] | 10000 |    54.076 μs |  3.8116 μs |  2.2682 μs |   2.46 |    0.10 | 18.0664 | 4.3945 | 273.66 KB |        3.50 |
