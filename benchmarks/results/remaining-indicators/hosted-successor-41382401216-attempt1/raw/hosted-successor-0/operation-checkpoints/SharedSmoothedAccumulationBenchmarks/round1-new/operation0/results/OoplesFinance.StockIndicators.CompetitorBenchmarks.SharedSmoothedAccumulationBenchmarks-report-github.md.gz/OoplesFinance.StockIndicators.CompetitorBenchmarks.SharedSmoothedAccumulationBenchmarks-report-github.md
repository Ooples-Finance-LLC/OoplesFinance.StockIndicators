```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **386.0 μs** |  **4.29 μs** |  **2.55 μs** |       **-** |  **97.07 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   379.0 μs |  1.49 μs |  0.89 μs |  1.9531 |  49.42 KB |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **3,926.4 μs** | **68.09 μs** | **45.04 μs** | **31.2500** | **941.36 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 3,862.4 μs | 28.33 μs | 14.81 μs |       - | 471.47 KB |
