```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **385.3 μs** |  **4.81 μs** |  **2.86 μs** |       **-** |  **96.99 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   376.9 μs |  6.68 μs |  3.98 μs |       - |  49.43 KB |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **4,001.8 μs** | **13.07 μs** |  **6.84 μs** | **31.2500** | **941.24 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 3,942.5 μs | 42.37 μs | 22.16 μs |       - | 471.54 KB |
