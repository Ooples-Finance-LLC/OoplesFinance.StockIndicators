```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev  | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **362.5 μs** |  **2.81 μs** | **1.67 μs** |       **-** |  **73.52 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   367.1 μs |  2.21 μs | 1.16 μs |       - |  25.91 KB |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **3,831.3 μs** | **10.91 μs** | **5.70 μs** | **31.2500** | **706.88 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 3,712.1 μs |  7.68 μs | 4.02 μs |       - | 237.05 KB |
