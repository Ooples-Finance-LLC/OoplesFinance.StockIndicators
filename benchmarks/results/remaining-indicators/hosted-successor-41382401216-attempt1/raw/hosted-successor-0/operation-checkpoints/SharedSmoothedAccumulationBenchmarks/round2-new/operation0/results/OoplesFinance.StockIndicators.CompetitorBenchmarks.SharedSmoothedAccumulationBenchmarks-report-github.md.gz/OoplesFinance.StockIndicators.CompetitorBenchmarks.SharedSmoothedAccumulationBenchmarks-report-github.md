```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **388.54 μs** |  **2.694 μs** |  **1.603 μs** |  **5.79** |    **0.05** |        **-** |        **-** |       **-** |   **97.07 KB** |        **0.26** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   376.42 μs |  2.186 μs |  1.144 μs |  5.61 |    0.05 |   1.9531 |        - |       - |   49.42 KB |        0.13 |
| NativeSingle      | Skend(...)inOsc [21] | 1000  |    67.07 μs |  0.940 μs |  0.559 μs |  1.00 |    0.01 |  22.9492 |   6.8359 |       - |  379.71 KB |        1.00 |
| NativeParallel    | Skend(...)inOsc [21] | 1000  |   131.70 μs |  7.428 μs |  4.913 μs |  1.96 |    0.07 |  60.5469 |  20.5078 |       - |  958.68 KB |        2.52 |
|                   |                      |       |             |           |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **3,876.44 μs** | **17.979 μs** |  **9.403 μs** |  **4.11** |    **0.03** |  **31.2500** |        **-** |       **-** |  **941.34 KB** |        **0.25** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 3,925.38 μs | 48.948 μs | 29.128 μs |  4.16 |    0.04 |        - |        - |       - |   471.5 KB |        0.12 |
| NativeSingle      | Skend(...)inOsc [21] | 10000 |   943.12 μs | 10.822 μs |  6.440 μs |  1.00 |    0.01 | 242.1875 | 148.4375 | 46.8750 | 3790.27 KB |        1.00 |
| NativeParallel    | Skend(...)inOsc [21] | 10000 | 1,888.79 μs | 97.399 μs | 64.423 μs |  2.00 |    0.07 | 593.7500 | 515.6250 | 78.1250 | 9555.11 KB |        2.52 |
