```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **491.07 μs** |  **7.651 μs** |  **4.002 μs** | **37.13** |    **0.32** |       **-** |      **-** |  **66.72 KB** |        **4.45** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   457.56 μs |  8.783 μs |  5.227 μs | 34.59 |    0.40 |       - |      - |  19.12 KB |        1.28 |
| NativeSingle      | TaLib.Functions.Adxr | 1000  |    13.23 μs |  0.092 μs |  0.055 μs |  1.00 |    0.01 |  0.8545 |      - |  14.99 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 1000  |    23.97 μs |  0.967 μs |  0.640 μs |  1.81 |    0.05 |  3.1738 | 0.1221 |  45.43 KB |        3.03 |
|                   |                      |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **5,120.85 μs** | **13.452 μs** |  **7.035 μs** | **39.47** |    **0.18** | **31.2500** |      **-** | **638.67 KB** |        **4.10** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 5,106.29 μs | 33.950 μs | 20.203 μs | 39.35 |    0.23 |       - |      - | 168.88 KB |        1.09 |
| NativeSingle      | TaLib.Functions.Adxr | 10000 |   129.76 μs |  1.038 μs |  0.617 μs |  1.00 |    0.01 |  8.7891 | 0.9766 | 155.62 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 10000 |   194.41 μs | 11.957 μs |  7.909 μs |  1.50 |    0.06 | 30.2734 | 7.8125 | 467.31 KB |        3.00 |
