```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev  | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **220.2 μs** |  **3.59 μs** | **2.13 μs** |       **-** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   217.3 μs |  2.95 μs | 1.54 μs |       - |   17.4 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **2,513.0 μs** | **15.25 μs** | **7.97 μs** | **31.2500** | **627.93 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,473.6 μs |  7.18 μs | 3.76 μs |       - |  158.1 KB |
