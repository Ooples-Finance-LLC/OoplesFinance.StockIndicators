```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **122.538 μs** |  **1.6880 μs** |  **0.8829 μs** | **13.40** |    **0.11** |  **3.9063** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   120.146 μs |  1.0534 μs |  0.6269 μs | 13.14 |    0.09 |  0.9766 |      - |  17.39 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDM [23] | 1000  |     9.144 μs |  0.0665 μs |  0.0440 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 1000  |    12.185 μs |  0.8471 μs |  0.5603 μs |  1.33 |    0.06 |  1.7090 |      - |  27.23 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,400.167 μs** |  **3.2644 μs** |  **1.9426 μs** | **15.37** |    **0.04** | **31.2500** | **7.8125** | **627.89 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 1,387.288 μs | 20.7606 μs | 12.3543 μs | 15.23 |    0.13 |  7.8125 |      - | 158.07 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDM [23] | 10000 |    91.118 μs |  0.3989 μs |  0.2086 μs |  1.00 |    0.00 |  4.3945 |      - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 10000 |   131.273 μs |  3.0335 μs |  2.0065 μs |  1.44 |    0.02 | 17.5781 | 3.9063 | 273.33 KB |        3.50 |
