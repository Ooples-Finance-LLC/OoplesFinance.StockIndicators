```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error   | StdDev  | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |-----------:|--------:|--------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **127.6 μs** | **1.17 μs** | **0.70 μs** |       **-** |      **-** |  **65.04 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   121.8 μs | 0.68 μs | 0.41 μs |  0.9766 |      - |  17.39 KB |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,397.0 μs** | **4.49 μs** | **2.67 μs** | **31.2500** | **7.8125** | **627.89 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 1,384.6 μs | 5.43 μs | 3.23 μs |  7.8125 |      - | 158.07 KB |
