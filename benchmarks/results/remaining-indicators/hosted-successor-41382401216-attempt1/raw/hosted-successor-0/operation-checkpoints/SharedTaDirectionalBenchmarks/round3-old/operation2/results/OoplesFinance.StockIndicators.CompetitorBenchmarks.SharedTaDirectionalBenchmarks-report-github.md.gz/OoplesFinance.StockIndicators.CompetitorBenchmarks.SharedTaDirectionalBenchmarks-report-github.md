```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **230.0 μs** |  **3.88 μs** |  **2.03 μs** |       **-** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   215.4 μs |  2.99 μs |  1.56 μs |       - |  17.39 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **2,476.1 μs** | **19.44 μs** | **11.57 μs** | **31.2500** | **627.93 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,448.5 μs | 36.01 μs | 21.43 μs |       - | 158.08 KB |
