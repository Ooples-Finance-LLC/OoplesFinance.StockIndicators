```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **230.8 μs** |  **4.08 μs** |  **2.14 μs** |       **-** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   225.2 μs |  2.71 μs |  1.79 μs |       - |  17.39 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **2,600.8 μs** | **18.76 μs** |  **9.81 μs** | **31.2500** | **627.93 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,565.9 μs | 53.48 μs | 35.38 μs |       - | 158.13 KB |
