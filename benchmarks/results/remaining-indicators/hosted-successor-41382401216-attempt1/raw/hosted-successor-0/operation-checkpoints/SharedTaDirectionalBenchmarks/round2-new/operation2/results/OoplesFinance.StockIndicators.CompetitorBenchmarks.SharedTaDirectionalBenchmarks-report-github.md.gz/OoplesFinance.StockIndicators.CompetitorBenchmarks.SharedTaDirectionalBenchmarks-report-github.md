```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **220.104 μs** |  **2.8964 μs** | **1.5149 μs** | **35.16** |    **0.42** |       **-** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   228.841 μs |  2.1242 μs | 1.2641 μs | 36.55 |    0.41 |       - |      - |  17.39 KB |        2.25 |
| NativeSingle      | TaLib(...)lusDI [22] | 1000  |     6.261 μs |  0.1099 μs | 0.0654 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 1000  |     9.800 μs |  0.4084 μs | 0.2701 μs |  1.57 |    0.04 |  1.8311 | 0.0610 |  27.24 KB |        3.53 |
|                   |                      |       |              |            |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **2,600.270 μs** | **16.0822 μs** | **9.5702 μs** | **44.17** |    **0.17** | **31.2500** |      **-** | **627.93 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,581.856 μs | 11.9881 μs | 7.1339 μs | 43.86 |    0.14 |       - |      - | 158.13 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDI [22] | 10000 |    58.863 μs |  0.2032 μs | 0.1063 μs |  1.00 |    0.00 |  4.3945 |      - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 10000 |   102.928 μs |  5.3144 μs | 3.5151 μs |  1.75 |    0.06 | 18.5547 | 4.8828 | 273.34 KB |        3.50 |
