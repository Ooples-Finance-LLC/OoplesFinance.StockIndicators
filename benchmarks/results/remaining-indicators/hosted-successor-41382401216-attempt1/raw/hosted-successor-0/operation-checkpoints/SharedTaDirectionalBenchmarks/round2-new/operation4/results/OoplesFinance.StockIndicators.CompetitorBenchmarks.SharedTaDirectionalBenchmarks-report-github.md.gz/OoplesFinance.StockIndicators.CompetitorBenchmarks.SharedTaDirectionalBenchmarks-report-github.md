```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **516.32 μs** |  **5.588 μs** |  **3.325 μs** | **39.67** |    **0.31** |       **-** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   510.78 μs |  8.605 μs |  5.121 μs | 39.25 |    0.42 |       - |      - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib.Functions.Dx | 1000  |    13.02 μs |  0.103 μs |  0.068 μs |  1.00 |    0.01 |  0.3662 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 1000  |    19.95 μs |  1.066 μs |  0.634 μs |  1.53 |    0.05 |  1.7090 |      - |  27.24 KB |        3.53 |
|                   |                    |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **5,619.73 μs** | **86.837 μs** | **57.437 μs** | **42.57** |    **0.42** | **31.2500** |      **-** |    **628 KB** |        **8.05** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 5,582.15 μs | 91.349 μs | 60.421 μs | 42.28 |    0.44 |       - |      - | 158.24 KB |        2.03 |
| NativeSingle      | TaLib.Functions.Dx | 10000 |   132.02 μs |  0.518 μs |  0.271 μs |  1.00 |    0.00 |  3.9063 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 10000 |   188.21 μs |  8.283 μs |  5.479 μs |  1.43 |    0.04 | 17.5781 | 3.9063 | 273.34 KB |        3.50 |
