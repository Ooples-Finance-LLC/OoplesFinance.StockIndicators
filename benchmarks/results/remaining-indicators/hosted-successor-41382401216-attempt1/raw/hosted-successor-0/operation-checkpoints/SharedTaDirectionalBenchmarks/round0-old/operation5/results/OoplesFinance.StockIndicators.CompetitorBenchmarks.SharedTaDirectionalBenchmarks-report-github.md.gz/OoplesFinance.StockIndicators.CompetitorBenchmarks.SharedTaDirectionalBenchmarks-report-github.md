```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **462.8 μs** |  **7.11 μs** |  **4.23 μs** |       **-** |  **65.65 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   476.7 μs |  4.87 μs |  2.90 μs |       - |  18.06 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **5,157.2 μs** | **93.04 μs** | **61.54 μs** | **31.2500** | **637.64 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 4,963.0 μs |  9.92 μs |  5.91 μs |       - | 167.77 KB |
