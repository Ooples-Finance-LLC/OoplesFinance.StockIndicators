```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **522.8 μs** |  **9.66 μs** |  **5.75 μs** |       **-** |     **65 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   511.5 μs |  4.60 μs |  2.74 μs |       - |   17.4 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **5,763.1 μs** | **79.42 μs** | **52.53 μs** | **31.2500** | **628.06 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 5,583.5 μs |  8.84 μs |  4.62 μs |       - | 158.26 KB |
