```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **122.8 μs** |  **2.47 μs** |  **1.47 μs** |  **3.9063** |      **-** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   120.4 μs |  2.53 μs |  1.50 μs |  0.9766 |      - |  17.39 KB |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **1,441.6 μs** |  **3.45 μs** |  **2.05 μs** | **31.2500** | **7.8125** | **627.89 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 1,389.8 μs | 25.20 μs | 16.67 μs |  7.8125 |      - | 158.06 KB |
