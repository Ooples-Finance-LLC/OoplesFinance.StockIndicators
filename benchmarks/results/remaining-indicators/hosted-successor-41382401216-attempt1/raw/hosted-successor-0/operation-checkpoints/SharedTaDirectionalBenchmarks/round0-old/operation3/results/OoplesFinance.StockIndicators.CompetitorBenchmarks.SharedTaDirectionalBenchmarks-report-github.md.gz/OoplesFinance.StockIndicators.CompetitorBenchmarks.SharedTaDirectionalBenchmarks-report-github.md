```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **223.4 μs** |  **3.80 μs** |  **2.26 μs** |       **-** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   218.6 μs |  2.00 μs |  1.19 μs |       - |  17.39 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **2,490.8 μs** |  **7.18 μs** |  **4.27 μs** | **31.2500** | **627.97 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,476.5 μs | 60.90 μs | 40.28 μs |       - |  158.1 KB |
