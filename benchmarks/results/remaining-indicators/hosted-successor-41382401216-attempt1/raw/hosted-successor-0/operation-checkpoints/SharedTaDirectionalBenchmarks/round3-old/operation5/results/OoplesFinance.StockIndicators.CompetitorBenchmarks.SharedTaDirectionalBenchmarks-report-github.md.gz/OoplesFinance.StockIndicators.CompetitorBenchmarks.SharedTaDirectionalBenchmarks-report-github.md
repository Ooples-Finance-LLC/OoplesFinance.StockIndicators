```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **464.2 μs** |  **8.20 μs** |  **4.29 μs** |       **-** |  **65.62 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   458.6 μs |  7.40 μs |  3.87 μs |       - |  18.06 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **5,023.0 μs** | **96.61 μs** | **63.90 μs** | **31.2500** |  **637.5 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 4,941.7 μs | 29.95 μs | 15.66 μs |       - | 167.68 KB |
