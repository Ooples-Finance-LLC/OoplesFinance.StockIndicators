```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **224.063 μs** |  **2.5690 μs** |  **1.5288 μs** | **36.91** |    **0.38** |       **-** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   221.525 μs |  0.9399 μs |  0.5593 μs | 36.49 |    0.30 |       - |      - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDI [23] | 1000  |     6.071 μs |  0.0855 μs |  0.0509 μs |  1.00 |    0.01 |  0.4578 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 1000  |     9.532 μs |  0.3399 μs |  0.2248 μs |  1.57 |    0.04 |  1.8921 | 0.0610 |  27.24 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **2,472.267 μs** | **10.2482 μs** |  **5.3600 μs** | **41.79** |    **0.32** | **31.2500** |      **-** | **627.97 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,505.681 μs | 80.2744 μs | 53.0966 μs | 42.36 |    0.91 |       - |      - | 158.12 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDI [23] | 10000 |    59.158 μs |  0.7045 μs |  0.4660 μs |  1.00 |    0.01 |  4.3945 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 10000 |   102.313 μs |  3.5768 μs |  2.3658 μs |  1.73 |    0.04 | 18.5547 | 5.8594 | 273.34 KB |        3.50 |
