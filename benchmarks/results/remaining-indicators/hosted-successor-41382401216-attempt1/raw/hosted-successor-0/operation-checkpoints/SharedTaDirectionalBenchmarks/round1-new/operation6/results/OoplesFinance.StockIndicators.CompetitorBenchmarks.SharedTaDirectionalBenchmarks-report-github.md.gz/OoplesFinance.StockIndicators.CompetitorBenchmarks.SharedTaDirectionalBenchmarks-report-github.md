```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **465.9 μs** |  **5.02 μs** |  **2.62 μs** |       **-** |  **66.72 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   461.9 μs |  3.80 μs |  2.26 μs |       - |  19.13 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **5,170.6 μs** | **31.00 μs** | **18.45 μs** | **31.2500** | **638.69 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 5,104.5 μs | 40.93 μs | 21.41 μs |       - | 168.83 KB |
