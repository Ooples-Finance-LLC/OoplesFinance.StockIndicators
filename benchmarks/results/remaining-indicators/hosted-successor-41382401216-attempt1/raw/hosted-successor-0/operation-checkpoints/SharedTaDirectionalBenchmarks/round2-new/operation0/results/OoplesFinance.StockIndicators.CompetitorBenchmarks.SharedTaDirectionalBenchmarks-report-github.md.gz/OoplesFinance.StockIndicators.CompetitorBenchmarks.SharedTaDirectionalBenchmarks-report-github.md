```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **119.201 μs** |  **0.9597 μs** |  **0.5019 μs** | **13.02** |    **0.08** |  **3.9063** |      **-** |  **64.97 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   117.289 μs |  0.8844 μs |  0.5850 μs | 12.81 |    0.09 |  0.9766 |      - |  17.39 KB |        2.25 |
| NativeSingle      | TaLib(...)lusDM [22] | 1000  |     9.155 μs |  0.0677 μs |  0.0448 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 1000  |    12.236 μs |  0.7987 μs |  0.5283 μs |  1.34 |    0.06 |  1.8311 |      - |  27.23 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **1,395.645 μs** | **10.9516 μs** |  **6.5171 μs** | **15.45** |    **0.08** | **31.2500** | **7.8125** | **627.86 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 1,391.729 μs | 47.8560 μs | 31.6538 μs | 15.41 |    0.34 |  7.8125 |      - | 158.06 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDM [22] | 10000 |    90.332 μs |  0.3630 μs |  0.2160 μs |  1.00 |    0.00 |  4.3945 |      - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 10000 |   132.600 μs |  4.4106 μs |  2.6247 μs |  1.47 |    0.03 | 17.5781 | 3.9063 | 273.33 KB |        3.50 |
