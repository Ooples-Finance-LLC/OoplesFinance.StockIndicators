```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **475.20 μs** |  **3.770 μs** |  **1.972 μs** | **40.51** |    **0.27** |       **-** |      **-** |  **65.65 KB** |        **8.67** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   460.55 μs | 10.316 μs |  6.139 μs | 39.26 |    0.54 |       - |      - |  18.05 KB |        2.38 |
| NativeSingle      | TaLib.Functions.Adx | 1000  |    11.73 μs |  0.125 μs |  0.065 μs |  1.00 |    0.01 |  0.3662 |      - |   7.57 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 1000  |    21.82 μs |  1.891 μs |  1.125 μs |  1.86 |    0.09 |  1.7090 |      - |  26.71 KB |        3.53 |
|                   |                     |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **4,987.71 μs** |  **6.406 μs** |  **3.350 μs** | **43.45** |    **0.08** | **31.2500** |      **-** | **637.55 KB** |        **8.19** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 4,993.06 μs | 28.325 μs | 18.735 μs | 43.49 |    0.17 |       - |      - | 167.75 KB |        2.15 |
| NativeSingle      | TaLib.Functions.Adx | 10000 |   114.80 μs |  0.397 μs |  0.207 μs |  1.00 |    0.00 |  3.9063 |      - |  77.89 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 10000 |   170.26 μs | 11.293 μs |  7.470 μs |  1.48 |    0.06 | 17.5781 | 3.9063 | 272.81 KB |        3.50 |
