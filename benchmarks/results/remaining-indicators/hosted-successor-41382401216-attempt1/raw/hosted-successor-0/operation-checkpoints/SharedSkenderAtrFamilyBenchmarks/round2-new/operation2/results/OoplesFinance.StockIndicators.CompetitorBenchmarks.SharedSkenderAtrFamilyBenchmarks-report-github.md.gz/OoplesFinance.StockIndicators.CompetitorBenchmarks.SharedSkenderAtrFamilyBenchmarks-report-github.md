```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)Bands [21]** | **1000**  |   **206.69 μs** |   **1.682 μs** |  **0.880 μs** |  **2.15** |    **0.06** |        **-** |        **-** |       **-** |   **97.39 KB** |        **0.30** |
| BuilderLatestOnly | Skend(...)Bands [21] | 1000  |   207.81 μs |   1.411 μs |  0.840 μs |  2.16 |    0.06 |   1.9531 |        - |       - |   49.79 KB |        0.15 |
| NativeSingle      | Skend(...)Bands [21] | 1000  |    96.29 μs |   4.039 μs |  2.672 μs |  1.00 |    0.04 |  20.0195 |   5.3711 |       - |  329.24 KB |        1.00 |
| NativeParallel    | Skend(...)Bands [21] | 1000  |   163.04 μs |  16.320 μs | 10.795 μs |  1.69 |    0.12 |  52.7344 |  21.4844 |       - |  832.71 KB |        2.53 |
|                   |                      |       |             |            |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)Bands [21]** | **10000** | **2,261.72 μs** |  **38.233 μs** | **22.752 μs** |  **1.86** |    **0.02** |  **46.8750** |  **15.6250** |       **-** |  **941.57 KB** |        **0.29** |
| BuilderLatestOnly | Skend(...)Bands [21] | 10000 | 2,254.25 μs |  42.939 μs | 28.402 μs |  1.85 |    0.02 |  15.6250 |        - |       - |  471.76 KB |        0.14 |
| NativeSingle      | Skend(...)Bands [21] | 10000 | 1,218.86 μs |  11.693 μs |  6.958 μs |  1.00 |    0.01 | 195.3125 | 148.4375 | 46.8750 | 3282.78 KB |        1.00 |
| NativeParallel    | Skend(...)Bands [21] | 10000 | 2,378.46 μs | 102.645 μs | 61.082 μs |  1.95 |    0.05 | 515.6250 | 453.1250 | 78.1250 | 8286.56 KB |        2.52 |
