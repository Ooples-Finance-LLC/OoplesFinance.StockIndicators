```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)elier [21]** | **1000**  |   **149.57 μs** |  **1.300 μs** |  **0.680 μs** |  **2.40** |    **0.02** |        **-** |        **-** |   **73.28 KB** |        **0.33** |
| BuilderLatestOnly | Skend(...)elier [21] | 1000  |   150.11 μs |  6.322 μs |  4.182 μs |  2.41 |    0.07 |   0.9766 |        - |   25.67 KB |        0.12 |
| NativeSingle      | Skend(...)elier [21] | 1000  |    62.27 μs |  0.842 μs |  0.557 μs |  1.00 |    0.01 |  13.1836 |   2.9297 |  223.22 KB |        1.00 |
| NativeParallel    | Skend(...)elier [21] | 1000  |   119.77 μs |  5.078 μs |  3.022 μs |  1.92 |    0.05 |  36.1328 |  12.6953 |  566.85 KB |        2.54 |
|                   |                      |       |             |           |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skend(...)elier [21]** | **10000** | **1,758.06 μs** |  **5.189 μs** |  **3.088 μs** |  **1.69** |    **0.01** |  **31.2500** |        **-** |  **706.52 KB** |        **0.32** |
| BuilderLatestOnly | Skend(...)elier [21] | 10000 | 1,734.93 μs |  5.589 μs |  2.923 μs |  1.66 |    0.01 |        - |        - |  236.71 KB |        0.11 |
| NativeSingle      | Skend(...)elier [21] | 10000 | 1,042.89 μs | 13.906 μs |  8.275 μs |  1.00 |    0.01 | 132.8125 |  85.9375 | 2227.17 KB |        1.00 |
| NativeParallel    | Skend(...)elier [21] | 10000 | 1,728.30 μs | 50.102 μs | 26.204 μs |  1.66 |    0.03 | 343.7500 | 265.6250 | 5647.04 KB |        2.54 |
