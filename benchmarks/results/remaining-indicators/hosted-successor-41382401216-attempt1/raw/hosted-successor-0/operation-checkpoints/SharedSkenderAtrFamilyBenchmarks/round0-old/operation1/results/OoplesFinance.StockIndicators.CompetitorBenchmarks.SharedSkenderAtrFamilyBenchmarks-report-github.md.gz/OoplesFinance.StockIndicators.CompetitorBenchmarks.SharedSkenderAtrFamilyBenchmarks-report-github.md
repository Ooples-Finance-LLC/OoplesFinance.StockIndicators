```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated  |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetKeltner** | **1000**  |   **235.8 μs** |  **3.95 μs** |  **2.35 μs** |       **-** |       **-** |  **104.66 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 1000  |   236.1 μs |  2.40 μs |  1.43 μs |  1.9531 |       - |   57.06 KB |
| **BuilderFull**       | **Skender.GetKeltner** | **10000** | **2,496.8 μs** | **10.14 μs** |  **5.30 μs** | **46.8750** | **15.6250** | **1019.17 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 10000 | 2,496.4 μs | 17.87 μs | 10.64 μs | 31.2500 | 15.6250 |  549.39 KB |
