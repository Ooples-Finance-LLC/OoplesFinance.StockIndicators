```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error   | StdDev  | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)elier [21]** | **1000**  |   **158.4 μs** | **2.72 μs** | **1.62 μs** |       **-** |  **73.32 KB** |
| BuilderLatestOnly | Skend(...)elier [21] | 1000  |   148.2 μs | 2.57 μs | 1.53 μs |  0.9766 |  25.67 KB |
| **BuilderFull**       | **Skend(...)elier [21]** | **10000** | **1,752.2 μs** | **6.21 μs** | **3.25 μs** | **31.2500** | **706.54 KB** |
| BuilderLatestOnly | Skend(...)elier [21] | 10000 | 1,735.9 μs | 5.08 μs | 2.66 μs |       - | 236.71 KB |
