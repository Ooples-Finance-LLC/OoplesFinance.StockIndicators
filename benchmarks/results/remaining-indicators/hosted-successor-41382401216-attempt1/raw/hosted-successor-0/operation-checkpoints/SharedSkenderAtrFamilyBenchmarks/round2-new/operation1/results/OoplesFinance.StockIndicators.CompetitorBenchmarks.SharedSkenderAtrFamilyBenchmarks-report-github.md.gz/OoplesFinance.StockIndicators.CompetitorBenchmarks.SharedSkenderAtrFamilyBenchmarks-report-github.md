```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |------------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetKeltner** | **1000**  |   **235.83 μs** |  **2.713 μs** |  **1.419 μs** |  **2.93** |    **0.02** |        **-** |        **-** |       **-** |  **104.66 KB** |        **0.29** |
| BuilderLatestOnly | Skender.GetKeltner | 1000  |   236.91 μs |  1.464 μs |  0.765 μs |  2.95 |    0.01 |   1.9531 |        - |       - |   57.05 KB |        0.16 |
| NativeSingle      | Skender.GetKeltner | 1000  |    80.39 μs |  0.633 μs |  0.331 μs |  1.00 |    0.01 |  21.9727 |   6.3477 |       - |  360.53 KB |        1.00 |
| NativeParallel    | Skender.GetKeltner | 1000  |   139.93 μs |  3.345 μs |  1.750 μs |  1.74 |    0.02 |  57.6172 |  22.4609 |       - |  910.99 KB |        2.53 |
|                   |                    |       |             |           |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skender.GetKeltner** | **10000** | **2,612.37 μs** | **19.531 μs** | **11.623 μs** |  **2.31** |    **0.05** |  **46.8750** |  **15.6250** |       **-** | **1019.18 KB** |        **0.28** |
| BuilderLatestOnly | Skender.GetKeltner | 10000 | 2,530.97 μs | 25.417 μs | 13.293 μs |  2.24 |    0.05 |  31.2500 |  15.6250 |       - |  549.35 KB |        0.15 |
| NativeSingle      | Skender.GetKeltner | 10000 | 1,132.67 μs | 41.293 μs | 27.312 μs |  1.00 |    0.03 | 218.7500 | 164.0625 | 46.8750 |  3595.3 KB |        1.00 |
| NativeParallel    | Skender.GetKeltner | 10000 | 2,235.94 μs | 67.332 μs | 44.536 μs |  1.98 |    0.06 | 609.3750 | 468.7500 | 78.1250 | 9068.02 KB |        2.52 |
