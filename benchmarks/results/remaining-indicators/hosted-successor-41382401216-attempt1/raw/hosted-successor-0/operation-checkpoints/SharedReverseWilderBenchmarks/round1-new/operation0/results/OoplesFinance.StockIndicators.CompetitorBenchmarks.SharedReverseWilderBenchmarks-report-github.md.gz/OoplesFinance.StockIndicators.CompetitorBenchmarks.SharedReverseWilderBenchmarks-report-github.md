```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean        | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |------ |------------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **1000**  |    **71.21 μs** |  **0.513 μs** |  **0.268 μs** |   **3.9063** |        **-** |   **91.75 KB** |
| BuilderLatestOnly | 1000  |    81.84 μs |  1.179 μs |  0.701 μs |   2.4414 |        - |   43.87 KB |
| **BuilderFull**       | **10000** | **2,934.12 μs** | **31.443 μs** | **18.711 μs** | **296.8750** | **125.0000** | **5102.49 KB** |
| BuilderLatestOnly | 10000 | 2,913.98 μs | 29.108 μs | 15.224 μs | 281.2500 |  46.8750 | 4632.38 KB |
