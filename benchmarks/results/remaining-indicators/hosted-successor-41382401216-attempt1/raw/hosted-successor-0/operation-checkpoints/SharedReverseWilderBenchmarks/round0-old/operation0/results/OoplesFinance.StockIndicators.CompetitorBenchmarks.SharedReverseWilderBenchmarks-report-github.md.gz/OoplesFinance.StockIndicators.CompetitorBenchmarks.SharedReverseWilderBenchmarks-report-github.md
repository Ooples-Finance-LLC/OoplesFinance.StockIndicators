```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean        | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |------ |------------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **1000**  |    **66.85 μs** |  **1.030 μs** |  **0.539 μs** |   **3.9063** |        **-** |   **91.75 KB** |
| BuilderLatestOnly | 1000  |    64.76 μs |  0.694 μs |  0.363 μs |   2.4414 |        - |   43.87 KB |
| **BuilderFull**       | **10000** | **3,000.64 μs** | **28.221 μs** | **18.667 μs** | **296.8750** | **125.0000** | **5102.48 KB** |
| BuilderLatestOnly | 10000 | 3,023.18 μs | 40.475 μs | 26.772 μs | 281.2500 |  46.8750 | 4632.39 KB |
