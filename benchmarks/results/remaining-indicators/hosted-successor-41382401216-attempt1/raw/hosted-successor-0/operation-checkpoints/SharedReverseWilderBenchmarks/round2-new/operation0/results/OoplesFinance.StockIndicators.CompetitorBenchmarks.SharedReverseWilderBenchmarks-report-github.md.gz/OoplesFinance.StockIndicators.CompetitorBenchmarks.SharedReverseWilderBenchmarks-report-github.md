```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **1000**  |    **67.24 μs** |  **0.918 μs** |  **0.546 μs** |  **4.58** |    **0.08** |   **3.9063** |        **-** |   **91.72 KB** |        **1.94** |
| BuilderLatestOnly | 1000  |    64.36 μs |  1.342 μs |  0.799 μs |  4.39 |    0.09 |   2.4414 |        - |   43.87 KB |        0.93 |
| NativeSingle      | 1000  |    14.68 μs |  0.389 μs |  0.257 μs |  1.00 |    0.02 |   2.8076 |        - |    47.2 KB |        1.00 |
| NativeParallel    | 1000  |    19.24 μs |  0.728 μs |  0.481 μs |  1.31 |    0.04 |   6.5918 |   0.1221 |  106.85 KB |        2.26 |
|                   |       |             |           |           |       |         |          |          |            |             |
| **BuilderFull**       | **10000** | **2,977.95 μs** | **26.691 μs** | **13.960 μs** | **20.70** |    **0.26** | **296.8750** | **125.0000** | **5102.45 KB** |       **10.88** |
| BuilderLatestOnly | 10000 | 2,961.19 μs | 26.364 μs | 15.689 μs | 20.58 |    0.26 | 281.2500 |  46.8750 |  4632.4 KB |        9.88 |
| NativeSingle      | 10000 |   143.90 μs |  2.647 μs |  1.751 μs |  1.00 |    0.02 |  28.3203 |   4.8828 |  469.08 KB |        1.00 |
| NativeParallel    | 10000 |   162.02 μs | 10.044 μs |  6.643 μs |  1.13 |    0.05 |  64.4531 |  12.6953 | 1056.08 KB |        2.25 |
