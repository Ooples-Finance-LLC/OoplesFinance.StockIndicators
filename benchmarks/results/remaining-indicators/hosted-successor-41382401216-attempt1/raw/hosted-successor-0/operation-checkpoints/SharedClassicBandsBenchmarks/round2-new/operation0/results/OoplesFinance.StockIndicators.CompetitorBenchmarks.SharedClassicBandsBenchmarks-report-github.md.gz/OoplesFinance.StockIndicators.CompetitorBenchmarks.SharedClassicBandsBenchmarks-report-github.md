```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)bands [22]** | **1000**  |  **80.619 μs** |  **8.0120 μs** |  **4.7678 μs** | **12.12** |    **0.69** |  **3.9063** |       **-** |  **84.07 KB** |        **3.62** |
| BuilderLatestOnly | TaLib(...)bands [22] | 1000  |  68.801 μs |  5.3054 μs |  3.5092 μs | 10.34 |    0.51 |  1.9531 |       - |  36.46 KB |        1.57 |
| NativeSingle      | TaLib(...)bands [22] | 1000  |   6.652 μs |  0.1007 μs |  0.0599 μs |  1.00 |    0.01 |  1.4038 |  0.0610 |   23.2 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [22] | 1000  |   5.754 μs |  0.3800 μs |  0.2513 μs |  0.87 |    0.04 |  1.4038 |  0.0610 |  23.66 KB |        1.02 |
|                   |                      |       |            |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)bands [22]** | **10000** | **482.358 μs** | **75.6364 μs** | **50.0288 μs** |  **7.66** |    **0.76** | **46.8750** | **19.5313** | **787.59 KB** |        **3.36** |
| BuilderLatestOnly | TaLib(...)bands [22] | 10000 | 448.631 μs | 36.4176 μs | 21.6715 μs |  7.12 |    0.33 | 15.6250 |  3.9063 | 317.74 KB |        1.36 |
| NativeSingle      | TaLib(...)bands [22] | 10000 |  62.982 μs |  0.3490 μs |  0.1825 μs |  1.00 |    0.00 | 14.1602 |  4.3945 | 234.14 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [22] | 10000 |  42.339 μs |  3.2481 μs |  1.9329 μs |  0.67 |    0.03 | 14.1602 |  4.6387 |  234.6 KB |        1.00 |
