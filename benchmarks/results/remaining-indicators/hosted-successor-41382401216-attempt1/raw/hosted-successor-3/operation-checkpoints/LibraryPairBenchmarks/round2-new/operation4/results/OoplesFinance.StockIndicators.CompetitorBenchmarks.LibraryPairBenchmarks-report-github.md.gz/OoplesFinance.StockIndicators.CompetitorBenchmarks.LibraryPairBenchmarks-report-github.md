```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId              | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetElderRay** | **1,321.9 μs** |  **46.95 μs** |  **27.94 μs** |  **1.00** |    **0.03** |  **186.88 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetElderRay |   789.3 μs |  60.17 μs |  35.80 μs |  0.60 |    0.03 |  340.94 KB |        1.82 |
|            |       |                     |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetElderRay** | **8,402.0 μs** | **401.02 μs** | **265.25 μs** |  **1.00** |    **0.04** | **1838.92 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetElderRay | 2,268.5 μs |  39.88 μs |  23.73 μs |  0.27 |    0.01 | 3321.04 KB |        1.81 |
