```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId         | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetCmf** |  **1.796 ms** | **0.0576 ms** | **0.0381 ms** |  **1.00** |    **0.03** |  **189.89 KB** |        **1.00** |
|        |       |                |           |           |           |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetCmf** | **18.327 ms** | **2.9919 ms** | **1.9789 ms** |  **1.01** |    **0.14** | **1841.93 KB** |        **1.00** |
