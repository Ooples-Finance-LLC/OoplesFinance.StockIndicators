```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)elier [21]** |  **1,530.0 μs** |    **78.24 μs** |    **51.75 μs** |  **1.00** |    **0.05** |  **145.82 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)elier [21] |    497.8 μs |    11.36 μs |     5.94 μs |  0.33 |    0.01 |   256.3 KB |        1.76 |
|            |       |                      |             |             |             |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)elier [21]** | **17,287.8 μs** | **4,215.88 μs** | **2,788.54 μs** |  **1.03** |    **0.24** | **1428.72 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)elier [21] |  1,915.3 μs |   584.21 μs |   347.66 μs |  0.11 |    0.03 | 2479.94 KB |        1.74 |
