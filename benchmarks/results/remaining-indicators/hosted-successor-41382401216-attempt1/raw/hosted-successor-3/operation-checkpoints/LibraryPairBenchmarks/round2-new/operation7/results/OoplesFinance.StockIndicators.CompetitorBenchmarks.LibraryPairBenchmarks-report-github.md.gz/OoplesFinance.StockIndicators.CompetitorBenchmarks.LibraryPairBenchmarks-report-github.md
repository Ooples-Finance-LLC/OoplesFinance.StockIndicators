```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)oints [22]** |   **867.6 μs** | **24.72 μs** | **14.71 μs** |  **1.00** |    **0.02** |  **233.86 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)oints [22] | 1,402.3 μs | 51.28 μs | 30.51 μs |  1.62 |    0.04 |  512.79 KB |        2.19 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)oints [22]** | **2,259.6 μs** | **48.29 μs** | **28.73 μs** |  **1.00** |    **0.02** | **2312.98 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)oints [22] | 2,089.4 μs | 46.13 μs | 27.45 μs |  0.92 |    0.02 | 5021.58 KB |        2.17 |
