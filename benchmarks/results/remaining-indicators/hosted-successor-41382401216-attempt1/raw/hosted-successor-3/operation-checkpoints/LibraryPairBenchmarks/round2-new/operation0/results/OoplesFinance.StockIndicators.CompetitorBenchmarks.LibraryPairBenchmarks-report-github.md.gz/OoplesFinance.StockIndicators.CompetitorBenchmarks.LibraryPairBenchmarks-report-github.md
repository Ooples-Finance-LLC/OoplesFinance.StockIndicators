```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean       | Error       | StdDev      | Median     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------- |-----------:|------------:|------------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetCci** | **1,951.9 μs** |    **72.69 μs** |    **48.08 μs** | **1,931.6 μs** |  **1.00** |    **0.03** | **106.46 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetCci |   353.2 μs |    38.17 μs |    25.24 μs |   338.2 μs |  0.18 |    0.01 | 178.09 KB |        1.67 |
|            |       |                |            |             |             |            |       |         |           |             |
| **Ooples**     | **10000** | **Skender.GetCci** | **6,998.4 μs** | **7,099.24 μs** | **4,695.71 μs** | **4,865.6 μs** |  **1.49** |    **1.37** | **1037.8 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetCci | 1,089.8 μs |    99.21 μs |    51.89 μs | 1,078.7 μs |  0.23 |    0.13 | 1698.6 KB |        1.64 |
