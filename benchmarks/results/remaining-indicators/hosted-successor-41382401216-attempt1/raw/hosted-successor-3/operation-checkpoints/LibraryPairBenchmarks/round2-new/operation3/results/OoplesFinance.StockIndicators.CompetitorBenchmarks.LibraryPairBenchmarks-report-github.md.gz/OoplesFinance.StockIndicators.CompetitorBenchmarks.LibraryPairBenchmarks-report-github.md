```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetCmf** | **1,811.1 μs** |  **63.15 μs** | **41.77 μs** |  **1.00** |    **0.03** |  **189.89 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetCmf |   889.0 μs |  38.73 μs | 23.05 μs |  0.49 |    0.02 |  388.41 KB |        2.05 |
|            |       |                |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetCmf** | **4,806.2 μs** |  **82.04 μs** | **42.91 μs** |  **1.00** |    **0.01** | **1841.65 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetCmf | 1,811.0 μs | 109.06 μs | 57.04 μs |  0.38 |    0.01 | 3789.77 KB |        2.06 |
