```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId          | Mean       | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |-----------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetMacd** | **5,463.6 μs** |    **55.87 μs** |    **33.25 μs** |  **1.00** |    **0.01** |  **331.73 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetMacd |   964.6 μs |    51.85 μs |    30.85 μs |  0.18 |    0.01 |  456.73 KB |        1.38 |
|            |       |                 |            |             |             |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetMacd** | **7,158.1 μs** | **2,411.32 μs** | **1,261.16 μs** |  **1.02** |    **0.21** | **3266.98 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetMacd | 1,410.9 μs |    47.27 μs |    28.13 μs |  0.20 |    0.02 | 4672.18 KB |        1.43 |
