```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId             | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetKeltner** |  **2.753 ms** | **0.0527 ms** | **0.0313 ms** |  **1.00** |    **0.02** |  **267.62 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetKeltner |  1.133 ms | 0.0521 ms | 0.0310 ms |  0.41 |    0.01 |  475.82 KB |        1.78 |
|            |       |                    |           |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetKeltner** | **19.532 ms** | **0.1595 ms** | **0.1055 ms** |  **1.00** |    **0.01** | **2631.57 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetKeltner |  2.299 ms | 0.0819 ms | 0.0488 ms |  0.12 |    0.00 | 4659.74 KB |        1.77 |
