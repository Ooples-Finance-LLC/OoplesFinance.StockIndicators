```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId          | Mean      | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |---------------- |----------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetMacd** |  **5.587 ms** |  **0.0146 ms** |  **0.0077 ms** |  **1.00** |    **0.00** |  **331.73 KB** |        **1.00** |
|        |       |                 |           |            |            |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetMacd** | **43.260 ms** | **19.6611 ms** | **13.0046 ms** |  **1.12** |    **0.53** | **3266.37 KB** |        **1.00** |
