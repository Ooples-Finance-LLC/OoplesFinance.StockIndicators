```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean         | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |-------------:|-----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **136.522 μs** |  **4.2079 μs** | **2.2008 μs** | **58.14** |    **1.04** |  **3.9063** |      **-** |  **64.88 KB** |        **8.24** |
| BuilderLatestOnly | Ad        | 1000  |   132.632 μs |  0.8855 μs | 0.5857 μs | 56.48 |    0.59 |  0.9766 |      - |  17.27 KB |        2.19 |
| NativeSingle      | Ad        | 1000  |     2.348 μs |  0.0395 μs | 0.0235 μs |  1.00 |    0.01 |  0.4730 |      - |   7.88 KB |        1.00 |
| NativeParallel    | Ad        | 1000  |     5.900 μs |  0.5398 μs | 0.3571 μs |  2.51 |    0.15 |  0.4883 |      - |   8.16 KB |        1.04 |
|                   |           |       |              |            |           |       |         |         |        |           |             |
| **BuilderFull**       | **Ad**        | **10000** | **1,197.720 μs** | **15.5720 μs** | **8.1445 μs** | **55.97** |    **0.44** | **31.2500** | **7.8125** | **627.79 KB** |        **8.03** |
| BuilderLatestOnly | Ad        | 10000 | 1,193.047 μs |  1.8982 μs | 0.9928 μs | 55.75 |    0.26 |  7.8125 |      - | 157.96 KB |        2.02 |
| NativeSingle      | Ad        | 10000 |    21.402 μs |  0.1719 μs | 0.1023 μs |  1.00 |    0.01 |  4.7607 | 0.8545 |  78.19 KB |        1.00 |
| NativeParallel    | Ad        | 10000 |    42.715 μs |  3.7221 μs | 1.9467 μs |  2.00 |    0.09 |  4.3945 | 0.4883 |  78.48 KB |        1.00 |
