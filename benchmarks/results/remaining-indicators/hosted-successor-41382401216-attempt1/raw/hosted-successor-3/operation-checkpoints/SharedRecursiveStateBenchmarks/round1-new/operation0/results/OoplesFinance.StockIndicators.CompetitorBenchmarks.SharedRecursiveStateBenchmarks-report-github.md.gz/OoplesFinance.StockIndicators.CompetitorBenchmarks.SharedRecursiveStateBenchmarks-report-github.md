```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error   | StdDev  | Gen0    | Allocated |
|------------------ |---------- |------ |-----------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **135.1 μs** | **5.36 μs** | **2.81 μs** |  **3.9063** |  **64.88 KB** |
| BuilderLatestOnly | Ad        | 1000  |   128.8 μs | 1.25 μs | 0.74 μs |  0.9766 |  17.27 KB |
| **BuilderFull**       | **Ad**        | **10000** | **1,220.1 μs** | **9.62 μs** | **5.03 μs** | **31.2500** | **627.85 KB** |
| BuilderLatestOnly | Ad        | 10000 | 1,181.4 μs | 5.00 μs | 2.61 μs |  7.8125 | 157.96 KB |
