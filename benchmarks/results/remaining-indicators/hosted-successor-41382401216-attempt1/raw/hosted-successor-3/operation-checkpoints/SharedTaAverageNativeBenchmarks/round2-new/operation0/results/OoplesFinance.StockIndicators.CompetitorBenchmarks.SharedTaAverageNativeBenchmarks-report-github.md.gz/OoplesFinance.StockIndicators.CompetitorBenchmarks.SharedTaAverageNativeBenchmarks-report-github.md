```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error       | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |-----------:|------------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Ma** | **1000**  | **127.973 μs** |  **20.0714 μs** | **13.2760 μs** | **55.51** |    **5.55** |  **3.9063** |       **-** |  **78.23 KB** |        **9.84** |
| BuilderLatestOnly | TaLib.Functions.Ma | 1000  | 112.552 μs |   6.9543 μs |  4.1384 μs | 48.82 |    1.84 |  1.9531 |       - |  30.62 KB |        3.85 |
| NativeSingle      | TaLib.Functions.Ma | 1000  |   2.306 μs |   0.0574 μs |  0.0342 μs |  1.00 |    0.02 |  0.4730 |       - |   7.95 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ma | 1000  |   5.090 μs |   0.1674 μs |  0.1107 μs |  2.21 |    0.06 |  2.0142 |  0.0916 |  28.37 KB |        3.57 |
|                   |                    |       |            |             |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Ma** | **10000** | **925.902 μs** |  **10.5659 μs** |  **5.5261 μs** | **42.04** |    **0.32** | **39.0625** | **15.6250** | **641.14 KB** |        **8.19** |
| BuilderLatestOnly | TaLib.Functions.Ma | 10000 | 955.961 μs | 122.9109 μs | 81.2979 μs | 43.41 |    3.53 |  7.8125 |       - | 171.31 KB |        2.19 |
| NativeSingle      | TaLib.Functions.Ma | 10000 |  22.023 μs |   0.1999 μs |  0.1189 μs |  1.00 |    0.01 |  4.7607 |  0.7324 |  78.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ma | 10000 |  39.639 μs |   1.4028 μs |  0.8348 μs |  1.80 |    0.04 | 18.0664 |  5.6152 | 274.46 KB |        3.51 |
