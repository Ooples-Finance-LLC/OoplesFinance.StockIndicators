```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |-------------------- |------ |-------------:|------------:|------------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Apo** | **1000**  |   **400.076 μs** |  **16.6942 μs** |   **8.7314 μs** | **70.53** |    **1.77** |  **15.6250** |       **-** |   **355.3 KB** |       **22.72** |
| BuilderLatestOnly | TaLib.Functions.Apo | 1000  |   314.699 μs |  23.1551 μs |  13.7792 μs | 55.48 |    2.44 |  15.6250 |       - |  307.67 KB |       19.67 |
| NativeSingle      | TaLib.Functions.Apo | 1000  |     5.674 μs |   0.1416 μs |   0.0843 μs |  1.00 |    0.02 |   0.9460 |  0.0305 |   15.64 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Apo | 1000  |    10.209 μs |   0.1911 μs |   0.1264 μs |  1.80 |    0.03 |   3.3569 |  0.1831 |    47.7 KB |        3.05 |
|                   |                     |       |              |             |             |       |         |          |         |            |             |
| **BuilderFull**       | **TaLib.Functions.Apo** | **10000** | **2,963.628 μs** | **233.1579 μs** | **154.2195 μs** | **54.82** |    **2.86** | **187.5000** | **78.1250** | **3167.62 KB** |       **20.27** |
| BuilderLatestOnly | TaLib.Functions.Apo | 10000 | 2,875.412 μs | 130.9326 μs |  77.9159 μs | 53.19 |    1.61 | 156.2500 | 31.2500 | 2697.91 KB |       17.26 |
| NativeSingle      | TaLib.Functions.Apo | 10000 |    54.073 μs |   1.5125 μs |   0.9001 μs |  1.00 |    0.02 |   9.2773 |  1.4648 |  156.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Apo | 10000 |   107.200 μs |   6.1275 μs |   4.0530 μs |  1.98 |    0.08 |  30.2734 |  8.7891 |  469.59 KB |        3.00 |
