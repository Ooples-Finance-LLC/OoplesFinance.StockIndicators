```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean         | Error       | StdDev      | Ratio  | RatioSD | Gen0     | Gen1     | Allocated   | Alloc Ratio |
|------------------ |-------------------- |------ |-------------:|------------:|------------:|-------:|--------:|---------:|---------:|------------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Ppo** | **1000**  | **1,176.191 μs** | **257.3525 μs** | **170.2228 μs** | **188.11** |   **26.08** |  **62.5000** |        **-** |  **1487.41 KB** |       **95.10** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 1000  |   718.519 μs |  96.5397 μs |  63.8551 μs | 114.92 |    9.85 |  85.9375 |   7.8125 |  1439.82 KB |       92.06 |
| NativeSingle      | TaLib.Functions.Ppo | 1000  |     6.253 μs |   0.1364 μs |   0.0812 μs |   1.00 |    0.02 |   0.9155 |        - |    15.64 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ppo | 1000  |    12.546 μs |   0.9617 μs |   0.6361 μs |   2.01 |    0.10 |   3.2959 |   0.1221 |     47.7 KB |        3.05 |
|                   |                     |       |              |             |             |        |         |          |          |             |             |
| **BuilderFull**       | **TaLib.Functions.Ppo** | **10000** | **7,358.913 μs** | **467.6328 μs** | **278.2808 μs** | **119.71** |    **4.68** | **846.1538** | **384.6154** | **14748.82 KB** |       **94.38** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 10000 | 7,493.169 μs | 355.7418 μs | 211.6963 μs | 121.90 |    3.77 | 833.3333 | 250.0000 | 14279.06 KB |       91.37 |
| NativeSingle      | TaLib.Functions.Ppo | 10000 |    61.487 μs |   1.6945 μs |   1.0084 μs |   1.00 |    0.02 |   9.2773 |   1.4648 |   156.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ppo | 10000 |   115.707 μs |   3.1920 μs |   1.8995 μs |   1.88 |    0.04 |  30.2734 |  10.7422 |   469.59 KB |        3.00 |
