```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev    | Gen0     | Gen1    | Allocated  |
|------------------ |-------------------- |------ |-----------:|----------:|----------:|---------:|--------:|-----------:|
| **BuilderFull**       | **TaLib.Functions.Apo** | **1000**  |   **528.7 μs** |  **57.10 μs** |  **33.98 μs** |  **15.6250** |       **-** |  **355.22 KB** |
| BuilderLatestOnly | TaLib.Functions.Apo | 1000  |   311.2 μs |  24.02 μs |  14.29 μs |  15.6250 |       - |  307.67 KB |
| **BuilderFull**       | **TaLib.Functions.Apo** | **10000** | **2,963.2 μs** | **182.57 μs** | **120.76 μs** | **187.5000** | **93.7500** | **3167.58 KB** |
| BuilderLatestOnly | TaLib.Functions.Apo | 10000 | 2,978.0 μs | 261.99 μs | 155.90 μs | 156.2500 | 31.2500 | 2697.91 KB |
