```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev    | Gen0     | Gen1    | Allocated  |
|------------------ |-------------------- |------ |-----------:|----------:|----------:|---------:|--------:|-----------:|
| **BuilderFull**       | **TaLib.Functions.Apo** | **1000**  |   **346.6 μs** |  **52.83 μs** |  **27.63 μs** |  **15.6250** |       **-** |  **355.27 KB** |
| BuilderLatestOnly | TaLib.Functions.Apo | 1000  |   316.4 μs |  27.93 μs |  14.61 μs |  15.6250 |       - |  307.67 KB |
| **BuilderFull**       | **TaLib.Functions.Apo** | **10000** | **3,011.7 μs** | **237.54 μs** | **157.12 μs** | **187.5000** | **93.7500** | **3167.57 KB** |
| BuilderLatestOnly | TaLib.Functions.Apo | 10000 | 2,992.2 μs | 251.15 μs | 166.12 μs | 156.2500 | 46.8750 | 2697.77 KB |
