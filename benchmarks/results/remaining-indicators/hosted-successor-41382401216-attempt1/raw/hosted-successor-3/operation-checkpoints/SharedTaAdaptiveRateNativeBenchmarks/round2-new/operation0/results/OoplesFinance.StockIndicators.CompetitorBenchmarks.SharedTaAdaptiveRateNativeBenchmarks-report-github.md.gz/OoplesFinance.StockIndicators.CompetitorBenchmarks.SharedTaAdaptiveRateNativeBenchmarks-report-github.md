```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Mavp** | **1000**  | **103.48 μs** |  **2.116 μs** |  **1.259 μs** |  **3.75** |    **0.05** |  **3.9063** |       **-** |  **66.42 KB** |        **3.34** |
| BuilderLatestOnly | TaLib.Functions.Mavp | 1000  |  93.40 μs |  0.415 μs |  0.217 μs |  3.38 |    0.02 |  0.9766 |       - |  18.77 KB |        0.94 |
| NativeSingle      | TaLib.Functions.Mavp | 1000  |  27.61 μs |  0.207 μs |  0.123 μs |  1.00 |    0.01 |  0.9766 |       - |   19.9 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mavp | 1000  |  43.23 μs |  2.973 μs |  1.967 μs |  1.57 |    0.07 |  4.1504 |  0.2441 |   59.1 KB |        2.97 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Mavp** | **10000** | **910.56 μs** |  **7.368 μs** |  **4.873 μs** |  **2.78** |    **0.02** | **31.2500** |  **7.8125** |  **629.3 KB** |        **3.22** |
| BuilderLatestOnly | TaLib.Functions.Mavp | 10000 | 889.44 μs | 10.143 μs |  6.036 μs |  2.71 |    0.02 |  7.8125 |       - | 159.46 KB |        0.81 |
| NativeSingle      | TaLib.Functions.Mavp | 10000 | 328.11 μs |  2.286 μs |  1.360 μs |  1.00 |    0.01 | 11.7188 |  1.9531 | 195.69 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mavp | 10000 | 452.71 μs | 22.108 μs | 13.156 μs |  1.38 |    0.04 | 35.1563 | 11.7188 | 568.89 KB |        2.91 |
