```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mavp** | **1000**  | **104.21 μs** |  **5.344 μs** |  **3.180 μs** |  **3.9063** |      **-** |  **66.35 KB** |
| BuilderLatestOnly | TaLib.Functions.Mavp | 1000  |  94.36 μs |  1.692 μs |  0.885 μs |  0.9766 |      - |  18.77 KB |
| **BuilderFull**       | **TaLib.Functions.Mavp** | **10000** | **910.33 μs** |  **8.990 μs** |  **5.350 μs** | **31.2500** | **7.8125** | **629.27 KB** |
| BuilderLatestOnly | TaLib.Functions.Mavp | 10000 | 925.14 μs | 18.269 μs | 10.871 μs |  7.8125 |      - | 159.46 KB |
