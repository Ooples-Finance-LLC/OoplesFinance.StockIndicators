```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **524.9 μs** |  **2.86 μs** |  **1.70 μs** |       **-** |  **89.26 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   522.9 μs | 21.75 μs | 14.39 μs |       - |   41.6 KB |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **5,290.8 μs** | **15.52 μs** |  **8.12 μs** | **31.2500** | **863.22 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 5,182.4 μs | 25.85 μs | 17.10 μs |       - | 393.39 KB |
