```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **287.42 μs** |  **2.005 μs** |  **1.193 μs** | **26.89** |    **0.32** |       **-** |       **-** |  **89.24 KB** |        **5.76** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   294.77 μs |  3.511 μs |  2.089 μs | 27.58 |    0.36 |  1.9531 |       - |   41.6 KB |        2.69 |
| NativeSingle      | TaLib.Functions.Trix | 1000  |    10.69 μs |  0.190 μs |  0.126 μs |  1.00 |    0.02 |  0.9155 |       - |  15.48 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Trix | 1000  |    15.22 μs |  0.562 μs |  0.372 μs |  1.42 |    0.04 |  3.2959 |  0.1221 |   47.6 KB |        3.07 |
|                   |                      |       |             |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **3,005.96 μs** | **33.107 μs** | **21.898 μs** | **27.93** |    **0.40** | **46.8750** | **15.6250** | **863.12 KB** |        **5.53** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 3,011.55 μs | 61.831 μs | 40.897 μs | 27.98 |    0.50 | 15.6250 |       - | 393.29 KB |        2.52 |
| NativeSingle      | TaLib.Functions.Trix | 10000 |   107.66 μs |  2.146 μs |  1.419 μs |  1.00 |    0.02 |  8.7891 |  0.9766 | 156.12 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Trix | 10000 |   163.07 μs |  5.325 μs |  3.522 μs |  1.51 |    0.04 | 29.2969 |  9.7656 | 469.48 KB |        3.01 |
