```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |-------------------- |------ |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Cci** | **1000**  |   **263.6 μs** |  **83.18 μs** |  **55.02 μs** |       **-** |       **-** |  **66.79 KB** |
| BuilderLatestOnly | TaLib.Functions.Cci | 1000  |   241.3 μs |  29.38 μs |  19.43 μs |       - |       - |  19.13 KB |
| **BuilderFull**       | **TaLib.Functions.Cci** | **10000** | **2,183.5 μs** | **290.53 μs** | **192.17 μs** | **31.2500** | **15.6250** | **629.69 KB** |
| BuilderLatestOnly | TaLib.Functions.Cci | 10000 | 2,141.5 μs | 193.54 μs | 128.02 μs |       - |       - | 159.88 KB |
