```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Cci** | **1000**  |   **286.63 μs** |  **85.286 μs** |  **56.411 μs** |  **9.40** |    **1.77** |       **-** |       **-** |  **66.79 KB** |        **8.64** |
| BuilderLatestOnly | TaLib.Functions.Cci | 1000  |   249.46 μs |  37.668 μs |  24.915 μs |  8.18 |    0.78 |       - |       - |  19.13 KB |        2.48 |
| NativeSingle      | TaLib.Functions.Cci | 1000  |    30.49 μs |   0.062 μs |   0.032 μs |  1.00 |    0.00 |  0.2441 |       - |   7.73 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Cci | 1000  |    18.02 μs |   1.172 μs |   0.775 μs |  0.59 |    0.02 |  0.4883 |       - |   8.02 KB |        1.04 |
|                   |                     |       |             |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Cci** | **10000** | **2,099.61 μs** |  **24.829 μs** |  **12.986 μs** |  **6.83** |    **0.04** | **31.2500** | **15.6250** | **629.66 KB** |        **8.07** |
| BuilderLatestOnly | TaLib.Functions.Cci | 10000 | 2,166.66 μs | 216.885 μs | 143.456 μs |  7.05 |    0.45 |       - |       - | 159.88 KB |        2.05 |
| NativeSingle      | TaLib.Functions.Cci | 10000 |   307.21 μs |   1.760 μs |   0.920 μs |  1.00 |    0.00 |  3.9063 |       - |  78.05 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Cci | 10000 |   185.06 μs |   4.513 μs |   2.685 μs |  0.60 |    0.01 |  3.9063 |       - |  78.34 KB |        1.00 |
