```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Commo(...)Index [21]** | **1000**  |   **319.2 μs** |  **62.88 μs** |  **41.59 μs** |       **-** |       **-** |  **70.53 KB** |
| BuilderLatestOnly | Commo(...)Index [21] | 1000  |   245.3 μs |  32.36 μs |  21.41 μs |       - |       - |  22.88 KB |
| **BuilderFull**       | **Commo(...)Index [21]** | **10000** | **2,324.2 μs** | **213.29 μs** | **141.08 μs** | **31.2500** | **15.6250** | **633.41 KB** |
| BuilderLatestOnly | Commo(...)Index [21] | 10000 | 2,299.1 μs | 177.09 μs | 117.13 μs |       - |       - | 163.62 KB |
