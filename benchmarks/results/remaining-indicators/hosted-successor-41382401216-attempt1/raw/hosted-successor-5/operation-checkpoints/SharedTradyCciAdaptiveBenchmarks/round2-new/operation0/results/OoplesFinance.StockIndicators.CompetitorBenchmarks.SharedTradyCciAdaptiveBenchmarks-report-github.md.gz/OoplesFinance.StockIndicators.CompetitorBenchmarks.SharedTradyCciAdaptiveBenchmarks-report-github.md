```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|----------:|---------:|---------:|------------:|------------:|
| **BuilderFull**       | **Commo(...)Index [21]** | **1000**  |     **266.4 μs** |    **68.10 μs** |    **45.05 μs** |  **0.02** |    **0.00** |         **-** |        **-** |        **-** |    **70.53 KB** |       **0.016** |
| BuilderLatestOnly | Commo(...)Index [21] | 1000  |     241.3 μs |    19.85 μs |    13.13 μs |  0.02 |    0.00 |         - |        - |        - |    22.88 KB |       0.005 |
| NativeSingle      | Commo(...)Index [21] | 1000  |  13,080.4 μs |    92.91 μs |    55.29 μs |  1.00 |    0.01 |  250.0000 |        - |        - |   4398.1 KB |       1.000 |
| NativeParallel    | Commo(...)Index [21] | 1000  |   6,524.4 μs |   223.59 μs |   116.94 μs |  0.50 |    0.01 |  214.2857 |  71.4286 |        - |  4407.33 KB |       1.002 |
|                   |                      |       |              |             |             |       |         |           |          |          |             |             |
| **BuilderFull**       | **Commo(...)Index [21]** | **10000** |   **2,282.5 μs** |   **177.04 μs** |   **105.35 μs** |  **0.02** |    **0.00** |   **31.2500** |  **15.6250** |        **-** |   **633.46 KB** |       **0.014** |
| BuilderLatestOnly | Commo(...)Index [21] | 10000 |   2,282.0 μs |   169.37 μs |   112.03 μs |  0.02 |    0.00 |         - |        - |        - |   163.62 KB |       0.004 |
| NativeSingle      | Commo(...)Index [21] | 10000 | 145,212.9 μs |   982.29 μs |   584.55 μs |  1.00 |    0.01 | 2750.0000 | 500.0000 | 250.0000 |  45275.6 KB |       1.000 |
| NativeParallel    | Commo(...)Index [21] | 10000 |  81,024.2 μs | 4,337.92 μs | 2,869.26 μs |  0.56 |    0.02 | 2750.0000 | 500.0000 | 250.0000 | 45394.03 KB |       1.003 |
