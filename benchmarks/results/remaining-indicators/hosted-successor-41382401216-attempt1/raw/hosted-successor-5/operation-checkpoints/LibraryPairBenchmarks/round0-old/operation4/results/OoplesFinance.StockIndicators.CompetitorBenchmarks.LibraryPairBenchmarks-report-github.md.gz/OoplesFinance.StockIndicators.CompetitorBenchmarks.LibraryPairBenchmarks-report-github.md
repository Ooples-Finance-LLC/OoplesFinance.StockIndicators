```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId              | Mean      | Error      | StdDev     | Median    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |-------------------- |----------:|-----------:|-----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Adx** |  **3.408 ms** |  **0.0436 ms** |  **0.0259 ms** |  **3.413 ms** |  **1.00** |    **0.01** |  **106.36 KB** |        **1.00** |
|        |       |                     |           |            |            |           |       |         |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Adx** | **19.300 ms** | **16.0558 ms** | **10.6199 ms** | **12.955 ms** |  **1.23** |    **0.83** | **1046.59 KB** |        **1.00** |
