```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId            | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------ |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetZigZag** |  **1.107 ms** | **0.0411 ms** | **0.0215 ms** |  **1.00** |    **0.03** |  **479.98 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetZigZag |  1.879 ms | 0.0520 ms | 0.0309 ms |  1.70 |    0.04 |  430.16 KB |        0.90 |
|            |       |                   |           |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetZigZag** |  **8.329 ms** | **0.5429 ms** | **0.3231 ms** |  **1.00** |    **0.05** | **4850.73 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetZigZag | 13.403 ms | 4.5188 ms | 2.9889 ms |  1.61 |    0.35 | 4090.77 KB |        0.84 |
