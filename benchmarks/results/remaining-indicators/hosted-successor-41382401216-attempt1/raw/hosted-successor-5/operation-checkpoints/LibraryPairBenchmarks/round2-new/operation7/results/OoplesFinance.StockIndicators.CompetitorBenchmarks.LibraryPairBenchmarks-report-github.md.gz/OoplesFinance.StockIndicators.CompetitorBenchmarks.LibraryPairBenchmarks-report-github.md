```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)vgDev [22]** | **1,509.25 μs** |  **47.306 μs** |  **31.290 μs** |  **1.00** |    **0.03** |  **73.16 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)vgDev [22] |    53.45 μs |   4.870 μs |   2.547 μs |  0.04 |    0.00 |  23.84 KB |        0.33 |
|            |       |                      |             |            |            |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)vgDev [22]** | **1,183.10 μs** | **186.338 μs** | **123.251 μs** |  **1.01** |    **0.14** | **643.82 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)vgDev [22] |   320.21 μs |   6.890 μs |   3.604 μs |  0.27 |    0.03 | 164.47 KB |        0.26 |
