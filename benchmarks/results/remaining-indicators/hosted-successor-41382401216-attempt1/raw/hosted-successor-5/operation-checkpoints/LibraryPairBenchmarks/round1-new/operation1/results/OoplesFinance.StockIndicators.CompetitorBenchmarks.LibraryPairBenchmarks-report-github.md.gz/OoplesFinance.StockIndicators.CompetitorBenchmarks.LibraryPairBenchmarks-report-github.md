```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean      | Error      | StdDev     | Ratio | RatioSD | Gen0      | Gen1      | Allocated | Alloc Ratio |
|------- |------ |--------------------- |----------:|-----------:|-----------:|------:|--------:|----------:|----------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)bands [24]** |  **7.917 ms** |  **0.0545 ms** |  **0.0324 ms** |  **1.00** |    **0.01** |         **-** |         **-** |   **3.23 MB** |        **1.00** |
|        |       |                      |           |            |            |       |         |           |           |           |             |
| **Ooples** | **10000** | **TaLib(...)bands [24]** | **63.104 ms** | **34.0447 ms** | **22.5184 ms** |  **1.20** |    **0.81** | **2000.0000** | **1000.0000** |  **32.43 MB** |        **1.00** |
