```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adxr** | **3,602.8 μs** | **86.85 μs** | **57.44 μs** |  **1.00** |    **0.02** |  **107.43 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adxr |   272.1 μs | 25.00 μs | 16.54 μs |  0.08 |    0.00 |   48.45 KB |        0.45 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adxr** | **6,931.6 μs** | **69.26 μs** | **45.81 μs** |  **1.00** |    **0.01** | **1047.33 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adxr |   379.7 μs | 29.63 μs | 19.60 μs |  0.05 |    0.00 |  408.52 KB |        0.39 |
