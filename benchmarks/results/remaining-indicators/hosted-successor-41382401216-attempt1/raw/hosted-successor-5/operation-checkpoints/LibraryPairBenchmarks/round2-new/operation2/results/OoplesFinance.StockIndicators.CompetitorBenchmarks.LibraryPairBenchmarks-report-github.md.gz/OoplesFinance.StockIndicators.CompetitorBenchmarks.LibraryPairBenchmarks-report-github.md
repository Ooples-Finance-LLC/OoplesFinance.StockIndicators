```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId             | Mean        | Error      | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |------------:|-----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ad** |   **814.87 μs** |  **53.766 μs** | **35.563 μs** |  **1.00** |    **0.06** |  **160.84 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ad |    48.51 μs |   4.027 μs |  2.664 μs |  0.06 |    0.00 |    15.7 KB |        0.10 |
|            |       |                    |             |            |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ad** | **7,243.73 μs** | **165.154 μs** | **98.280 μs** |  **1.00** |    **0.02** | **2015.88 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ad |   114.06 μs |  17.145 μs | 11.340 μs |  0.02 |    0.00 |   86.29 KB |        0.04 |
