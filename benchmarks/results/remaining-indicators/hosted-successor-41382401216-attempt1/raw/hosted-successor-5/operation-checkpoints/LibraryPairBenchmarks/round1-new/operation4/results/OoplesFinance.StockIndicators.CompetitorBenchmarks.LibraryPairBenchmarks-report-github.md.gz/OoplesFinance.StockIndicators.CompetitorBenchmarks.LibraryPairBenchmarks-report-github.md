```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId              | Mean      | Error      | StdDev     | Median    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |-------------------- |----------:|-----------:|-----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Adx** |  **3.397 ms** |  **0.0608 ms** |  **0.0402 ms** |  **3.382 ms** |  **1.00** |    **0.02** |  **106.36 KB** |        **1.00** |
|        |       |                     |           |            |            |           |       |         |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Adx** | **18.933 ms** | **19.4936 ms** | **12.8938 ms** | **14.197 ms** |  **1.53** |    **1.45** | **1046.59 KB** |        **1.00** |
