```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)AdOsc [21]** | **5,948.7 μs** |    **47.49 μs** |  **28.26 μs** |  **1.00** |    **0.01** |  **209.12 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)AdOsc [21] |   144.6 μs |    12.72 μs |   8.41 μs |  0.02 |    0.00 |   41.18 KB |        0.20 |
|            |       |                      |            |             |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)AdOsc [21]** | **7,144.6 μs** | **1,648.64 μs** | **981.08 μs** |  **1.01** |    **0.17** | **2054.52 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)AdOsc [21] |   144.1 μs |    15.29 μs |   9.10 μs |  0.02 |    0.00 |  331.19 KB |        0.16 |
