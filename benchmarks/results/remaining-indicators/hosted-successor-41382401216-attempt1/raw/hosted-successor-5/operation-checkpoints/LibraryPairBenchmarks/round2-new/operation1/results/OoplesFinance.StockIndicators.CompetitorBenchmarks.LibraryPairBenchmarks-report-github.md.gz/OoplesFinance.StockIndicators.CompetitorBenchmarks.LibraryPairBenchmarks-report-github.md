```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error        | StdDev       | Median      | Ratio | RatioSD | Gen0      | Gen1      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-------------:|-------------:|------------:|------:|--------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)bands [24]** |  **7,469.7 μs** |    **150.60 μs** |     **78.77 μs** |  **7,464.1 μs** |  **1.00** |    **0.01** |         **-** |         **-** |  **3309.52 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)bands [24] |    281.6 μs |     27.24 μs |     18.02 μs |    276.1 μs |  0.04 |    0.00 |         - |         - |   121.84 KB |        0.04 |
|            |       |                      |             |              |              |             |       |         |           |           |             |             |
| **Ooples**     | **10000** | **TaLib(...)bands [24]** | **31,403.2 μs** | **41,973.62 μs** | **24,977.83 μs** | **20,095.4 μs** |  **1.42** |    **1.33** | **2000.0000** | **1000.0000** | **33205.68 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)bands [24] |    338.0 μs |     16.06 μs |      9.56 μs |    337.9 μs |  0.02 |    0.01 |         - |         - |  1132.91 KB |        0.03 |
