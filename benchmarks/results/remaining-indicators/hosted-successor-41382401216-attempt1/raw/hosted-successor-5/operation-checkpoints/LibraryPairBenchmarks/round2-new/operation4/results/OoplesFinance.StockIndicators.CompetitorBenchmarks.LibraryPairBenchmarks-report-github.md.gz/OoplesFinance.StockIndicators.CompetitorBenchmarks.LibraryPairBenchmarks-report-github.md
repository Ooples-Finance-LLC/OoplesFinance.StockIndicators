```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId              | Mean       | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adx** | **3,481.6 μs** |    **95.11 μs** |    **62.91 μs** |  **1.00** |    **0.02** |  **106.36 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adx |   254.8 μs |    14.96 μs |     8.90 μs |  0.07 |    0.00 |   40.88 KB |        0.38 |
|            |       |                     |            |             |             |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adx** | **8,182.3 μs** | **2,861.07 μs** | **1,892.42 μs** |  **1.04** |    **0.30** | **1046.26 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adx |   332.2 μs |    10.68 μs |     5.59 μs |  0.04 |    0.01 |  330.64 KB |        0.32 |
