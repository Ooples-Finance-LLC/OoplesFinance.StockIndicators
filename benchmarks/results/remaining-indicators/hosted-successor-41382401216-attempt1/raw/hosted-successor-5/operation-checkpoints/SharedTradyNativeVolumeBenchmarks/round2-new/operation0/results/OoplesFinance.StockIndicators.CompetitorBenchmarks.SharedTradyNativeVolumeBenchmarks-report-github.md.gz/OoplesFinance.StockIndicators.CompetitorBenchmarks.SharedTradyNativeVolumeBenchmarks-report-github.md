```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|----------:|----------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Accum(...)nLine [28]** | **1000**  |   **166.5 μs** |   **4.19 μs** |   **2.19 μs** |  **0.32** |    **0.00** |    **7.8125** |         **-** |        **-** |  **153.97 KB** |        **0.26** |
| BuilderLatestOnly | Accum(...)nLine [28] | 1000  |   163.3 μs |   1.37 μs |   0.71 μs |  0.32 |    0.00 |    5.8594 |         - |        - |  106.36 KB |        0.18 |
| NativeSingle      | Accum(...)nLine [28] | 1000  |   516.3 μs |   7.33 μs |   4.85 μs |  1.00 |    0.01 |   35.1563 |   11.7188 |        - |  594.33 KB |        1.00 |
| NativeParallel    | Accum(...)nLine [28] | 1000  |   489.0 μs |  22.98 μs |  13.67 μs |  0.95 |    0.03 |   54.6875 |   19.5313 |        - |  894.29 KB |        1.50 |
|                   |                      |       |            |           |           |       |         |           |           |          |            |             |
| **BuilderFull**       | **Accum(...)nLine [28]** | **10000** | **2,019.8 μs** |  **17.93 μs** |   **9.38 μs** |  **0.35** |    **0.00** |  **109.3750** |   **46.8750** |        **-** | **1931.54 KB** |        **0.33** |
| BuilderLatestOnly | Accum(...)nLine [28] | 10000 | 1,983.7 μs |  40.96 μs |  27.09 μs |  0.35 |    0.01 |   78.1250 |   15.6250 |        - | 1461.71 KB |        0.25 |
| NativeSingle      | Accum(...)nLine [28] | 10000 | 5,715.8 μs |  92.95 μs |  48.62 μs |  1.00 |    0.01 |  656.2500 |  468.7500 | 437.5000 | 5824.34 KB |        1.00 |
| NativeParallel    | Accum(...)nLine [28] | 10000 | 5,787.4 μs | 214.87 μs | 127.87 μs |  1.01 |    0.02 | 1250.0000 | 1062.5000 | 968.7500 | 8717.77 KB |        1.50 |
