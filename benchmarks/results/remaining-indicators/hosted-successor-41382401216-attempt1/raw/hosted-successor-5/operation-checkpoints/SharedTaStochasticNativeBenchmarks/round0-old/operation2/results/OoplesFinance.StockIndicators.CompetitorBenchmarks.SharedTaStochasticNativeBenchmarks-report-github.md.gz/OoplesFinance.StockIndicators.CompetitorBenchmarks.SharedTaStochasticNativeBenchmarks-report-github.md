```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|-----------:|
| **BuilderFull**       | **TaLib(...)chRsi [24]** | **1000**  |   **474.8 μs** |  **6.73 μs** |  **3.52 μs** |       **-** |       **-** |  **182.03 KB** |
| BuilderLatestOnly | TaLib(...)chRsi [24] | 1000  |   474.9 μs |  6.01 μs |  3.58 μs |  7.8125 |       - |  134.43 KB |
| **BuilderFull**       | **TaLib(...)chRsi [24]** | **10000** | **4,928.0 μs** | **32.71 μs** | **19.46 μs** | **93.7500** | **31.2500** |  **1799.9 KB** |
| BuilderLatestOnly | TaLib(...)chRsi [24] | 10000 | 4,908.6 μs | 46.60 μs | 27.73 μs | 62.5000 |       - | 1330.05 KB |
