```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)tochF [22]** | **1000**  |   **506.561 μs** | **179.1411 μs** | **118.4907 μs** | **63.51** |   **14.18** |  **15.6250** |       **-** |  **392.18 KB** |       **16.55** |
| BuilderLatestOnly | TaLib(...)tochF [22] | 1000  |   338.158 μs |  22.2324 μs |  11.6280 μs | 42.40 |    1.42 |  19.5313 |       - |  344.56 KB |       14.54 |
| NativeSingle      | TaLib(...)tochF [22] | 1000  |     7.976 μs |   0.1261 μs |   0.0750 μs |  1.00 |    0.01 |   1.4038 |  0.0610 |    23.7 KB |        1.00 |
| NativeParallel    | TaLib(...)tochF [22] | 1000  |    16.656 μs |   0.7916 μs |   0.5236 μs |  2.09 |    0.07 |   5.0049 |  0.6104 |   75.77 KB |        3.20 |
|                   |                      |       |              |             |             |       |         |          |         |            |             |
| **BuilderFull**       | **TaLib(...)tochF [22]** | **10000** | **3,458.900 μs** | **371.1120 μs** | **245.4676 μs** | **24.98** |    **1.74** | **218.7500** | **93.7500** | **3838.23 KB** |       **16.36** |
| BuilderLatestOnly | TaLib(...)tochF [22] | 10000 | 3,359.029 μs | 325.8987 μs | 193.9371 μs | 24.25 |    1.38 | 187.5000 | 62.5000 | 3368.38 KB |       14.36 |
| NativeSingle      | TaLib(...)tochF [22] | 10000 |   138.526 μs |   3.9033 μs |   2.3228 μs |  1.00 |    0.02 |  13.6719 |  2.9297 |  234.64 KB |        1.00 |
| NativeParallel    | TaLib(...)tochF [22] | 10000 |   188.589 μs |   6.0591 μs |   3.6057 μs |  1.36 |    0.03 |  46.8750 | 17.5781 |  743.75 KB |        3.17 |
