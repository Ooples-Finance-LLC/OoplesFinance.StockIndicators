```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **1000**  |   **551.94 μs** | **164.289 μs** | **108.667 μs** | **53.27** |   **10.23** |  **31.2500** |        **-** |  **645.94 KB** |       **27.22** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 1000  |   445.14 μs |  26.423 μs |  15.724 μs | 42.96 |    2.25 |  35.1563 |        - |  598.35 KB |       25.22 |
| NativeSingle      | TaLib(...)Stoch [21] | 1000  |    10.38 μs |   0.693 μs |   0.459 μs |  1.00 |    0.06 |   1.4038 |   0.0610 |   23.73 KB |        1.00 |
| NativeParallel    | TaLib(...)Stoch [21] | 1000  |    19.96 μs |   1.299 μs |   0.859 μs |  1.93 |    0.11 |   5.0049 |   0.6104 |   75.96 KB |        3.20 |
|                   |                      |       |             |            |            |       |         |          |          |            |             |
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **10000** | **4,547.44 μs** | **272.809 μs** | **180.446 μs** | **30.51** |    **1.22** | **375.0000** | **187.5000** | **6342.14 KB** |       **27.03** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 10000 | 4,517.14 μs | 395.256 μs | 261.437 μs | 30.30 |    1.72 | 343.7500 |  93.7500 | 5872.31 KB |       25.02 |
| NativeSingle      | TaLib(...)Stoch [21] | 10000 |   149.08 μs |   3.390 μs |   2.017 μs |  1.00 |    0.02 |  13.6719 |   2.9297 |  234.67 KB |        1.00 |
| NativeParallel    | TaLib(...)Stoch [21] | 10000 |   211.51 μs |  17.733 μs |  10.552 μs |  1.42 |    0.07 |  46.8750 |  17.5781 |  743.95 KB |        3.17 |
