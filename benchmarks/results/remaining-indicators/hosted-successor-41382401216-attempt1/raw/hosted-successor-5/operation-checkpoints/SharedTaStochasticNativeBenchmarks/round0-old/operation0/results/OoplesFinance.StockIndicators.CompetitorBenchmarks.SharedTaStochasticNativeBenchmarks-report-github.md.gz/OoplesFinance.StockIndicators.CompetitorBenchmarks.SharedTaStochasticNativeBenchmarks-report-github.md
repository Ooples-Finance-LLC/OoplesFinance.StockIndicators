```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **1000**  |   **519.6 μs** | **140.52 μs** |  **92.94 μs** |  **31.2500** |        **-** |  **645.94 KB** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 1000  |   435.8 μs |   5.50 μs |   2.87 μs |  35.1563 |        - |  598.35 KB |
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **10000** | **4,435.0 μs** |  **88.68 μs** |  **46.38 μs** | **375.0000** | **156.2500** | **6342.15 KB** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 10000 | 4,480.9 μs | 379.23 μs | 250.84 μs | 343.7500 |  93.7500 |  5872.3 KB |
