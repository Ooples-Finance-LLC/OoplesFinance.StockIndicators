```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)chRsi [24]** | **1000**  |   **483.67 μs** |   **3.883 μs** |  **2.311 μs** | **21.51** |    **0.18** |       **-** |       **-** |  **182.11 KB** |        **5.84** |
| BuilderLatestOnly | TaLib(...)chRsi [24] | 1000  |   481.32 μs |  10.056 μs |  6.652 μs | 21.41 |    0.32 |  7.8125 |       - |  134.44 KB |        4.31 |
| NativeSingle      | TaLib(...)chRsi [24] | 1000  |    22.48 μs |   0.274 μs |  0.163 μs |  1.00 |    0.01 |  1.8311 |  0.1221 |   31.16 KB |        1.00 |
| NativeParallel    | TaLib(...)chRsi [24] | 1000  |    33.13 μs |   0.805 μs |  0.532 μs |  1.47 |    0.02 |  6.1035 |  0.7324 |   94.43 KB |        3.03 |
|                   |                      |       |             |            |           |       |         |         |         |            |             |
| **BuilderFull**       | **TaLib(...)chRsi [24]** | **10000** | **5,010.54 μs** | **127.907 μs** | **84.603 μs** | **18.48** |    **0.31** | **93.7500** | **31.2500** |  **1799.9 KB** |        **5.76** |
| BuilderLatestOnly | TaLib(...)chRsi [24] | 10000 | 4,931.77 μs |  64.288 μs | 33.624 μs | 18.19 |    0.14 | 62.5000 |       - | 1330.05 KB |        4.26 |
| NativeSingle      | TaLib(...)chRsi [24] | 10000 |   271.11 μs |   2.213 μs |  1.157 μs |  1.00 |    0.01 | 17.5781 |  3.9063 |  312.42 KB |        1.00 |
| NativeParallel    | TaLib(...)chRsi [24] | 10000 |   381.42 μs |  15.126 μs | 10.005 μs |  1.41 |    0.04 | 58.5938 | 25.3906 |   938.2 KB |        3.00 |
