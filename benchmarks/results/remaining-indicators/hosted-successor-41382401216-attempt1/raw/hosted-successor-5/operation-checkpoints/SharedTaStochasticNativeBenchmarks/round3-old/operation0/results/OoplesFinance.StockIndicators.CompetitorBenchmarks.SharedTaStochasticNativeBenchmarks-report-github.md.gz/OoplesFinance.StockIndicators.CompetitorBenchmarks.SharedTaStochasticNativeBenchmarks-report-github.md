```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **1000**  |   **477.8 μs** | **101.59 μs** |  **60.46 μs** |  **31.2500** |        **-** |  **645.94 KB** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 1000  |   465.3 μs |  48.36 μs |  31.99 μs |  35.1563 |        - |  598.35 KB |
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **10000** | **4,561.2 μs** | **458.76 μs** | **303.44 μs** | **375.0000** | **156.2500** | **6342.13 KB** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 10000 | 4,432.6 μs | 396.33 μs | 262.15 μs | 343.7500 |  93.7500 | 5872.31 KB |
