```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean          | Error       | StdDev      | Ratio  | RatioSD | Gen0      | Gen1     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |--------------:|------------:|------------:|-------:|--------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **TaLib(...)bands [24]** | **1000**  |  **2,369.527 μs** | **183.9841 μs** | **121.6941 μs** | **243.59** |   **12.34** |  **142.8571** |        **-** |  **3187.67 KB** |       **81.56** |
| BuilderLatestOnly | TaLib(...)bands [24] | 1000  |  2,231.296 μs |  75.4032 μs |  49.8746 μs | 229.38 |    5.72 |  187.5000 |  31.2500 |   3140.2 KB |       80.34 |
| NativeSingle      | TaLib(...)bands [24] | 1000  |      9.729 μs |   0.2016 μs |   0.1334 μs |   1.00 |    0.02 |    2.3804 |   0.1831 |    39.09 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [24] | 1000  |     18.637 μs |   0.6414 μs |   0.3817 μs |   1.92 |    0.04 |    8.1787 |   1.2207 |   122.26 KB |        3.13 |
|                   |                      |       |               |             |             |        |         |           |          |             |             |
| **BuilderFull**       | **TaLib(...)bands [24]** | **10000** | **14,126.339 μs** | **336.0428 μs** | **175.7569 μs** | **142.81** |    **2.60** | **1857.1429** | **857.1429** | **32093.33 KB** |       **82.15** |
| BuilderLatestOnly | TaLib(...)bands [24] | 10000 | 14,248.006 μs | 490.8227 μs | 292.0807 μs | 144.04 |    3.44 | 1875.0000 | 875.0000 | 31623.41 KB |       80.95 |
| NativeSingle      | TaLib(...)bands [24] | 10000 |     98.934 μs |   2.4694 μs |   1.4695 μs |   1.00 |    0.02 |   23.4375 |   7.8125 |   390.66 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [24] | 10000 |    178.459 μs |   7.7775 μs |   5.1443 μs |   1.80 |    0.06 |   76.1719 |  35.1563 |  1212.11 KB |        3.10 |
