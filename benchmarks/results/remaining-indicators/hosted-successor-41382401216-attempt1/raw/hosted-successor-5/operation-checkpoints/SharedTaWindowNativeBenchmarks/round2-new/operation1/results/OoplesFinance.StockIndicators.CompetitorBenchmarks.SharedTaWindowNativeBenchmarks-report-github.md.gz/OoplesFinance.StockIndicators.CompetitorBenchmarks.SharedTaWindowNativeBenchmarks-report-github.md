```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **1000**  |   **157.44 μs** |  **27.036 μs** | **17.883 μs** |  **5.49** |    **0.60** |       **-** |       **-** |  **73.14 KB** |        **9.23** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 1000  |   139.63 μs |  12.354 μs |  8.171 μs |  4.87 |    0.28 |  0.9766 |       - |  25.22 KB |        3.18 |
| NativeSingle      | TaLib(...)vgDev [22] | 1000  |    28.69 μs |   0.468 μs |  0.279 μs |  1.00 |    0.01 |  0.2441 |       - |   7.92 KB |        1.00 |
| NativeParallel    | TaLib(...)vgDev [22] | 1000  |    17.70 μs |   1.201 μs |  0.794 μs |  0.62 |    0.03 |  1.0986 |       - |  16.76 KB |        2.11 |
|                   |                      |       |             |            |           |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **10000** | **1,086.45 μs** | **139.448 μs** | **92.236 μs** |  **3.76** |    **0.31** | **31.2500** | **15.6250** | **565.69 KB** |        **7.23** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 10000 | 1,050.25 μs | 123.231 μs | 81.510 μs |  3.63 |    0.27 |       - |       - |  95.59 KB |        1.22 |
| NativeSingle      | TaLib(...)vgDev [22] | 10000 |   289.02 μs |   4.124 μs |  2.157 μs |  1.00 |    0.01 |  3.9063 |       - |  78.25 KB |        1.00 |
| NativeParallel    | TaLib(...)vgDev [22] | 10000 |   184.81 μs |   7.536 μs |  4.984 μs |  0.64 |    0.02 | 10.7422 |  1.9531 | 157.39 KB |        2.01 |
