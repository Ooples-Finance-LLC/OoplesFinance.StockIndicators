"""Stage authenticated missing builder comparisons and explicit snapshot applicability."""
import copy,gzip,hashlib,html,json,os,re,sys
from pathlib import Path
ROOT=Path(__file__).parent
SNAPSHOTS={'Skender.GetDpo':'DetrendedPriceSnapshot','Skender.GetFcb':'FractalSnapshot.ChaosBands','Skender.GetHurst':'HurstSnapshot','Skender.GetIchimoku':'IchimokuCloudSnapshot','Skender.GetParabolicSar':'ParabolicStopSnapshots','Skender.GetPivotPoints':'PivotLevelSnapshots','Skender.GetPivots':'PivotTrendSnapshot','Skender.GetRenko':'RenkoSnapshot','Skender.GetRenkoAtr':'RenkoSnapshot','Skender.GetVolatilityStop':'VolatilityStopSnapshot','Skender.GetZigZag':'ZigZagSnapshot','TaLib.Functions.Sar':'ParabolicStopSnapshots','TaLib.Functions.SarExt':'ParabolicStopSnapshots','Trady.Indicator.IchimokuCloud':'IchimokuCloudSnapshot.Extended','Trady.Indicator.ParabolicStopAndReverse':'ParabolicStopSnapshots'}
def embedded(document,name):return json.loads(re.search(r'<script[^>]*id="'+re.escape(name)+r'"[^>]*>(.*?)</script>',document,re.S)[1])
def replace(document,name,value):
 payload=json.dumps(value,ensure_ascii=True).replace('<','\\u003c')
 result,count=re.subn(r'(<script[^>]*id="'+re.escape(name)+r'"[^>]*>).*?(</script>)',lambda m:m[1]+payload+m[2],document,flags=re.S);assert count==1;return result
def indexed(builder):
 rows={}
 for receipt in builder['receipts']:
  for row in receipt['comparisons']:
   key=row['pair'],row['bars'],row['mode'];assert key not in rows
   rows[key]=dict(row,run_id=str(receipt['run_id']),source_sha=receipt['source_sha'],measurement_url=receipt.get('measurement_url','https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/'+str(receipt['run_id'])))
 return rows
def stage(run,tooling,plan):
 tooling=tooling.resolve();plan=plan.resolve();assert plan.is_relative_to(tooling) and plan.is_file()
 os.environ["HOSTED_TIMING_PLAN"]=str(plan);sys.path.insert(0,str(tooling/"scripts"))
 from hosted_timing.pipeline import PLAN,digest,read,verify_inputs
 from hosted_timing.verify import collect
 base=ROOT/'hosted-runs'/run;raw=base/'evidence';inputs=base/'hosted-inputs';proof=verify_inputs(inputs);assert proof['run_id']==run;summary=collect(raw,'coverage');assert summary['coverage_complete'] and not summary['accepted'];assert (summary['case_count'],summary['decision_count'])==(40,8);assert summary['sources']['old']==summary['sources']['new'];assert summary['input_provenance_sha256']==digest(inputs/'provenance.json')
 policy=read(PLAN);assert policy['coverage_harness']['native_invocation_count']==1 and policy['measurement_policy']['operation_timeout_seconds']==10800
 source=summary['sources']['new'];url=f'https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/{run}'
 live=Path(r'C:\Users\cheat\Documents\OoplesFinance-Reports\competitor-performance.html');original=live.read_bytes();document=original.decode('utf-8');dataset=embedded(document,'dataset');builder=embedded(document,'current-competitor-data');status=embedded(document,'rollout-status-data');before=copy.deepcopy(builder);old=indexed(before);oldcounts=builder['verdicts'].copy();oldexpected=status['measurement_totals']['expected'];oldpairs=len({k[0] for k in old});assert len(dataset['rows'])==802
 allpairs={r['pair'] for r in dataset['rows']};assert len(allpairs)==401 and len(SNAPSHOTS)==15
 for pair,api in SNAPSHOTS.items():assert len([r for r in dataset['rows'] if r['pair']==pair and r['ooples_indicator']==api])==2,(pair,api)
 assert not set(SNAPSHOTS)&{k[0] for k in old}
 receipts=[]
 for folder in sorted(p.parent for p in raw.glob('*/provenance.json')):
  provenance,state=read(folder/'provenance.json'),read(folder/'status.json');host=provenance['host'];assert host['run_id']==run
  for record in state['rounds']:
   if record['index']!=2:continue
   fixture=record['fixture'];rows={(r['pair'],r['bars'],r['method']):r for r in summary['final_candidate_rows'][fixture]};pairs={k[0] for k in rows};comparisons=[]
   metadata=dict(measurement_location='GitHub-hosted Windows',measurement_machine=host['machine'],measurement_run_id=run,measurement_run_attempt=host['run_attempt'],measurement_shard=provenance["shard"],measurement_host_nonce=host['instance_nonce'],measurement_runner_image=host['runner_image'],warmup_count=10,measured_iterations=10,native_invocation_count=1,builder_invocations='adaptive',operation_timeout_seconds=10800,execution_timeout_minutes=120,plan_sha256=digest(PLAN))
   def stats(row):return {k:row[k] for k in ('mean_ns','lower_ns','upper_ns','samples','allocated_bytes')}
   for pair in sorted(pairs):
    for bars in (1000,10000):
     native={mode:stats(rows[pair,bars,mode]) for mode in ('NativeSingle','NativeParallel')}
     for mode in ('BuilderFull','BuilderLatestOnly'):
      ours=stats(rows[pair,bars,mode]);verdict='faster' if ours['upper_ns']<min(r['lower_ns'] for r in native.values()) else 'slower' if ours['lower_ns']>min(r['upper_ns'] for r in native.values()) else 'inconclusive'
      comparisons.append(dict(pair=pair,bars=bars,mode=mode,ooples=ours,native=native,fastest_native=min(native,key=lambda m:native[m]['mean_ns']),verdict=verdict,**metadata))
   report=Path(record['report']).name
   receipts.append(dict(fixture=fixture,source_sha=source,run_id=run,measurement_url=url,round=2,report_file=report,report_sha256=record['sha256'],complete=True,selection='Chronologically final repeated-control round on unchanged qualified source.',comparisons=comparisons,**metadata))
 assert {r['fixture'] for r in receipts}=={'SharedDynamicMomentumBenchmarks','SharedTradyNativeCandleBenchmarks'}
 builder['receipts']+=receipts;new=indexed(builder);added=set(new)-set(old);assert len(added)==8 and all(new[k]==v for k,v in old.items());assert {k[0] for k in added}=={'Trady.Indicator.DynamicMomentumIndex','Trady.Candlestick.RisingThreeMethods'}
 expected={(pair,bars,mode) for pair in allpairs-set(SNAPSHOTS) for bars in (1000,10000) for mode in ('BuilderFull','BuilderLatestOnly')};assert set(new)==expected and len(new)==1544
 counts={name:sum(r['verdict']==name for r in new.values()) for name in ('faster','slower','inconclusive')};coverage=dict(baseline_pairs=401,logical_slots=1604,applicable_pairs=386,applicable_slots=1544,measured_slots=1544,pending_slots=0,not_applicable_pairs=15,not_applicable_slots=60,snapshot_apis=SNAPSHOTS,reason='These mapped snapshot APIs do not expose Full/Latest history modes; their batch comparisons remain in the 802-row baseline.')
 builder.update(full_comparisons=len(new),verdicts=counts,coverage=coverage);builder['status']['completed']=sorted(set(builder['status']['completed'])|{r['fixture'] for r in receipts});builder['status']['coverage_run_url']=url;builder['status']['coverage_source_sha']=source
 status['measurement_totals'].update(counts,expected=1544,measured=1544,pending=0,not_applicable=60);status['builder_mode_applicability']=coverage
 # Change only builder counters in visible text; baseline measurement-arm counts stay intact.
 parts=re.split(r'(<script\b[^>]*>.*?</script>)',document,flags=re.S)
 oldverdict=f'{oldcounts["faster"]} faster, {oldcounts["slower"]} slower, {oldcounts["inconclusive"]} inconclusive'
 newverdict=f'{counts["faster"]} faster, {counts["slower"]} slower, {counts["inconclusive"]} inconclusive'
 for i in range(0,len(parts),2):
  parts[i]=parts[i].replace(f'{len(old)} / {oldexpected}','1544 / 1544').replace(f'{oldpairs} API pairs','386 API pairs').replace(oldverdict,newverdict).replace(f'and {oldexpected-len(old)} pending.','and 0 pending.').replace(f', {oldexpected-len(old)} pending.',', 0 pending.')
 document=''.join(parts)
 table=re.search(r'(<table\b[^>]*id="builder-current-results"[^>]*>.*?<tbody>)(.*?)(</tbody>.*?</table>)',document,re.S);assert table
 rowhtml={}
 for match in re.finditer(r'<tr\b([^>]*)>.*?</tr>',table[2],re.S):
  attrs=match[1];pair=html.unescape(re.search(r'data-builder-pair="([^"]+)"',attrs)[1]);bars=int(re.search(r'data-bars="([^"]+)"',attrs)[1]);mode=re.search(r'data-mode="([^"]+)"',attrs)[1];key=pair,bars,mode;assert key in old and key not in rowhtml;rowhtml[key]=match[0]
 assert set(rowhtml)==set(old)
 labels={'faster':'Faster than both','slower':'Slower than at least one','inconclusive':'Inconclusive'}
 for key in sorted(added):
  r=new[key];pair=html.escape(r['pair'],quote=True);mode=r['mode'];cells=[html.escape(r['pair']),f'{r["bars"]:,}','Full history' if mode=='BuilderFull' else 'Latest only',f'{r["ooples"]["mean_ns"]/1e6:.6f}',f'{r["native"]["NativeSingle"]["mean_ns"]/1e6:.6f}',f'{r["native"]["NativeParallel"]["mean_ns"]/1e6:.6f}',labels[r['verdict']],f'<a href="{url}">{source[:8]} / {html.escape(r["measurement_machine"])} / shard {r["measurement_shard"]}</a>'];rowhtml[key]=f'<tr data-builder-pair="{pair}" data-bars="{r["bars"]}" data-mode="{mode}">'+''.join('<td>'+c+'</td>' for c in cells)+'</tr>'
 document=document[:table.start(2)]+''.join(rowhtml[k] for k in sorted(rowhtml))+document[table.end(2):]
 note='<p id="builder-coverage-applicability">Full/Latest coverage is complete for 386 applicable API mappings. The 15 mapped snapshot APIs have 60 inapplicable history-mode slots; their batch comparisons remain in the 802-row baseline.</p>'
 note += '<p id="builder-coverage-invocations">Only the DynamicMomentumIndex and RisingThreeMethods native controls use one invocation per iteration; builders retain adaptive invocation counts. Both retain ten warmups and ten measured iterations. These coverage timings do not qualify a production source change.</p>'
 note += '<details id="builder-not-applicable"><summary>15 snapshot API mappings</summary><ul>'+''.join('<li data-snapshot-pair="'+html.escape(pair,quote=True)+'"><code>'+html.escape(pair)+'</code></li>' for pair in sorted(SNAPSHOTS))+'</ul></details>'
 document,count=re.subn(r'(<section\b[^>]*id="current-competitors"[^>]*>.*?)(</section>)',lambda m:m[1]+note+m[2],document,flags=re.S);assert count==1
 document=replace(document,'current-competitor-data',builder);document=replace(document,'rollout-status-data',status);assert embedded(document,'dataset')==dataset and all(indexed(embedded(document,'current-competitor-data'))[k]==v for k,v in old.items())
 out=ROOT/('report-builder-coverage-'+run);out.mkdir(exist_ok=True);assert not (out/'candidate.html').exists();(out/'before.html').write_bytes(original);(out/'candidate.html').write_bytes(document.encode());metadata=dict(run_id=run,source_sha=source,measurement_url=url,before_sha256=hashlib.sha256(original).hexdigest(),candidate_sha256=hashlib.sha256(document.encode()).hexdigest(),unchanged_baseline_rows=802,preserved_builder_slots=len(old),added_builder_slots=8,builder_slots=1544,coverage=coverage,verdicts=counts,added_keys=[list(k) for k in sorted(added)],all_cases_verified=True,coverage_complete=True,source_qualification_claimed=False);(out/'staged.json').write_bytes((json.dumps(metadata,indent=2)+'\n').encode());print(json.dumps(metadata))
if __name__=='__main__':stage(sys.argv[1],Path(sys.argv[2]),Path(sys.argv[3]))
