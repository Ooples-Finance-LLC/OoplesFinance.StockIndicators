"""Atomically import only an authenticated, browser-verified coverage candidate."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('coverage_stage', ROOT/'stage-builder-coverage-report-20261102.py')
stage = importlib.util.module_from_spec(spec)
spec.loader.exec_module(stage)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def import_report(run):
    directory = ROOT/('report-builder-coverage-'+run)
    metadata = json.loads((directory/'staged.json').read_text())
    browser = json.loads((directory/'browser-verification.json').read_text())
    before = (directory/'before.html').read_bytes()
    candidate = (directory/'candidate.html').read_bytes()
    assert metadata['run_id'] == browser['run_id'] == run
    assert digest(before) == metadata['before_sha256']
    assert digest(candidate) == metadata['candidate_sha256'] == browser['report_sha256']
    assert metadata['all_cases_verified'] and metadata['coverage_complete']
    assert not metadata['source_qualification_claimed']
    assert browser['all_values_and_provenance_verified'] and not browser['javascript_errors']
    old_document, document = before.decode('utf-8'), candidate.decode('utf-8')
    old_data = stage.embedded(old_document,'dataset')
    assert stage.embedded(document,'dataset') == old_data and len(old_data['rows']) == 802
    old = stage.indexed(stage.embedded(old_document,'current-competitor-data'))
    builder = stage.embedded(document,'current-competitor-data')
    new = stage.indexed(builder)
    assert len(old) == metadata['preserved_builder_slots'] == browser['preserved_builder_slots'] == 1536
    assert len(new) == browser['verified_builder_slots'] == 1544
    assert all(new[key] == row for key,row in old.items())
    assert set(new)-set(old) == {tuple(key) for key in metadata['added_keys']}
    assert len(set(new)-set(old)) == browser['added_builder_slots'] == 8
    assert builder['coverage']['pending_slots'] == 0 and builder['coverage']['not_applicable_slots'] == 60
    live = Path(r'C:\Users\cheat\Documents\OoplesFinance-Reports\competitor-performance.html')
    assert live.read_bytes() == before, 'Live report changed after staging; restage and verify.'
    temporary = live.with_name('.'+live.name+'.coverage-'+run+'.tmp')
    with temporary.open('xb') as handle:
        handle.write(candidate); handle.flush(); os.fsync(handle.fileno())
    assert temporary.read_bytes() == candidate
    assert live.read_bytes() == before, 'Live report changed before replacement.'
    os.replace(temporary,live)
    assert live.read_bytes() == candidate
    receipt = dict(run_id=run,live_report=str(live),before_sha256=digest(before),
        after_sha256=digest(candidate),baseline_rows_preserved=802,builder_slots_preserved=1536,
        builder_slots_added=8,builder_slots=1544,pending_slots=0,not_applicable_slots=60,
        source_qualification_claimed=False,atomic_import=True)
    (directory/'integration.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(receipt))


if __name__ == '__main__':
    import_report(sys.argv[1])
