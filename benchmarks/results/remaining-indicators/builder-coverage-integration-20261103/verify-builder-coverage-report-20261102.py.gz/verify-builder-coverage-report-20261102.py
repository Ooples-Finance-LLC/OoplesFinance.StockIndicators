"""Verify preserved baseline, every builder cell, coverage labels, and CSV before import."""
import csv,hashlib,io,json,re,sys
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).parent
sys.path.insert(0,str(ROOT))
from importlib.util import spec_from_file_location,module_from_spec
spec=spec_from_file_location('coverage_stage',ROOT/'stage-builder-coverage-report-20261102.py');stage=module_from_spec(spec);spec.loader.exec_module(stage)
def verify(run):
 out=ROOT/('report-builder-coverage-'+run);report=out/'candidate.html';before=(out/'before.html').read_text(encoding='utf-8');document=report.read_text(encoding='utf-8');s=json.loads((out/'staged.json').read_text());olddata=stage.embedded(before,'dataset');data=stage.embedded(document,'dataset');assert data==olddata and len(data['rows'])==802
 old=stage.indexed(stage.embedded(before,'current-competitor-data'));builder=stage.embedded(document,'current-competitor-data');rows=stage.indexed(builder);assert len(rows)==1544 and all(rows[k]==v for k,v in old.items());assert set(rows)-set(old)=={tuple(k) for k in s['added_keys']};coverage=builder['coverage'];assert coverage['pending_slots']==0 and coverage['not_applicable_slots']==60 and coverage['applicable_slots']==1544
 plan_hash=json.loads((ROOT/'hosted-runs'/run/'hosted-inputs/provenance.json').read_bytes())['plan_sha256']
 for key in set(rows)-set(old):
  row=rows[key];assert row['native_invocation_count']==1 and row['builder_invocations']=='adaptive' and row['warmup_count']==row['measured_iterations']==10 and row['operation_timeout_seconds']==10800 and row['execution_timeout_minutes']==120 and row['plan_sha256']==plan_hash
 expected_baseline={(r['pair'],r['bars']):r for r in data['rows']};errors=[]
 with sync_playwright() as pw:
  browser=pw.chromium.launch(channel='msedge',headless=True);page=browser.new_page(viewport={'width':1440,'height':1000},accept_downloads=True);page.on('pageerror',lambda e:errors.append(str(e)));page.goto(report.as_uri());page.wait_for_selector('#rows tr');assert page.locator('#builder-coverage-invocations').is_visible();assert 'one invocation per iteration' in page.locator('#builder-coverage-invocations').inner_text();page.locator('#size').select_option('all');assert page.locator('#resultcount').inner_text()=='802 size comparisons \u00b7 401 APIs'
  formatted=page.evaluate('rows => rows.map(r=>({pair:r.pair,bars:r.bars,values:[time(r.ooples_mean_ns),time(r.competitor_mean_ns),ratio(r.competitor_over_ooples)]}))',data['rows']);cells={(r['pair'],r['bars']):r['values'] for r in formatted};visited=set()
  while True:
   actual=page.locator('#rows tr').evaluate_all('rows=>rows.map(r=>({pair:r.querySelector("[data-pair]").dataset.pair,bars:Number(r.cells[1].textContent.replace(/[^0-9]/g,"")),values:[r.cells[2].textContent,r.cells[3].textContent,r.cells[4].textContent]}))')
   for r in actual:
    key=r['pair'],r['bars'];assert key not in visited and r['values']==cells[key];visited.add(key)
   if page.locator('#next').is_disabled():break
   page.locator('#next').click()
  assert visited==set(expected_baseline)
  with page.expect_download() as download:page.locator('#export').click()
  path=out/'verified-baseline.csv';download.value.save_as(path);exported=list(csv.DictReader(path.read_text(encoding='utf-8-sig').splitlines()));assert len(exported)==802
  for r in exported:
   expected=expected_baseline[r['pair'],int(r['bars'])]
   for key in ('ooples_mean_ns','competitor_mean_ns','competitor_over_ooples'):assert float(r[key])==expected[key]
   assert r['source_sha']==expected['source_sha'] and r['measurement_run_url']==expected['measurement_run_url']
  actual=page.locator('#builder-current-results tbody tr').evaluate_all('rows=>rows.map(r=>({pair:r.dataset.builderPair,bars:Number(r.dataset.bars),mode:r.dataset.mode,cells:[...r.cells].map(c=>c.textContent),url:r.querySelector("a").getAttribute("href")}))');assert len(actual)==1544;seen=set();labels={'faster':'Faster than both','slower':'Slower than at least one','inconclusive':'Inconclusive'}
  for r in actual:
   key=r['pair'],r['bars'],r['mode'];assert key in rows and key not in seen;seen.add(key);expected=rows[key];assert r['cells'][3:6]==[f'{expected["ooples"]["mean_ns"]/1e6:.6f}',f'{expected["native"]["NativeSingle"]["mean_ns"]/1e6:.6f}',f'{expected["native"]["NativeParallel"]["mean_ns"]/1e6:.6f}'];assert r['cells'][6]==labels[expected['verdict']] and r['url']==expected['measurement_url']
   if 'measurement_machine' in expected:assert expected['measurement_machine'] in r['cells'][7] and 'shard '+str(expected['measurement_shard']) in r['cells'][7]
  snapshots=page.locator('#builder-not-applicable [data-snapshot-pair]').evaluate_all('rows=>rows.map(r=>r.dataset.snapshotPair)');assert set(snapshots)==set(stage.SNAPSHOTS) and len(snapshots)==15;assert '1544 / 1544' in page.locator('#rollout-status').inner_text();assert '60 inapplicable' in page.locator('#builder-coverage-applicability').inner_text();assert not errors,errors
  first=s['added_keys'][0];page.locator(f'#builder-current-results tr[data-builder-pair="{first[0]}"]').first.scroll_into_view_if_needed();page.screenshot(path=str(out/'added-builder-comparisons.png'));browser.close()
 receipt=dict(run_id=run,report_sha256=hashlib.sha256(report.read_bytes()).hexdigest(),baseline_comparisons=802,exported_comparisons=802,verified_builder_slots=1544,preserved_builder_slots=len(old),added_builder_slots=8,not_applicable_slots=60,javascript_errors=errors,all_values_and_provenance_verified=True);(out/'browser-verification.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode());print(json.dumps(receipt))
if __name__=='__main__':verify(sys.argv[1])
