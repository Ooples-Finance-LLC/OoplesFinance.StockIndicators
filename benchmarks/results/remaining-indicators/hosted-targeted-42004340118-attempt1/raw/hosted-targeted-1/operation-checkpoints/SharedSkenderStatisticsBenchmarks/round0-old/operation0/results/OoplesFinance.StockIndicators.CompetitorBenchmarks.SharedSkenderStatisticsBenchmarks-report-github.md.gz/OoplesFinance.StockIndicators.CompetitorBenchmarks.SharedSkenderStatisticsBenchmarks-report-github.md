```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Gen0    | Allocated  |
|------------------ |---------------- |------ |----------:|----------:|----------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetBeta** | **1000**  |  **2.722 ms** | **0.4510 ms** | **0.2983 ms** |       **-** |  **171.61 KB** |
| BuilderLatestOnly | Skender.GetBeta | 1000  |  1.004 ms | 0.0364 ms | 0.0190 ms |       - |   123.8 KB |
| **BuilderFull**       | **Skender.GetBeta** | **10000** | **10.125 ms** | **0.2334 ms** | **0.1221 ms** | **90.9091** | **1578.65 KB** |
| BuilderLatestOnly | Skender.GetBeta | 10000 | 10.022 ms | 0.2096 ms | 0.1097 ms |       - |    1109 KB |
