```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error       | StdDev      | Median      | Ratio | RatioSD | Gen0      | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|------------------ |---------------- |------ |------------:|------------:|------------:|------------:|------:|--------:|----------:|---------:|---------:|------------:|------------:|
| **BuilderFull**       | **Skender.GetBeta** | **1000**  |  **3,734.2 μs** | **4,722.29 μs** | **3,123.50 μs** |  **1,946.7 μs** |  **6.66** |    **5.32** |         **-** |        **-** |        **-** |   **171.61 KB** |        **0.07** |
| BuilderLatestOnly | Skender.GetBeta | 1000  |  1,035.4 μs |   115.19 μs |    76.19 μs |    987.8 μs |  1.85 |    0.13 |         - |        - |        - |    123.8 KB |        0.05 |
| NativeSingle      | Skender.GetBeta | 1000  |    560.6 μs |    15.40 μs |     9.17 μs |    559.8 μs |  1.00 |    0.02 |  152.3438 |  42.9688 |        - |  2532.21 KB |        1.00 |
| NativeParallel    | Skender.GetBeta | 1000  |    365.9 μs |    11.26 μs |     5.89 μs |    365.4 μs |  0.65 |    0.01 |  158.2031 |  46.8750 |        - |  2557.05 KB |        1.01 |
|                   |                 |       |             |             |             |             |       |         |           |          |          |             |             |
| **BuilderFull**       | **Skender.GetBeta** | **10000** | **10,586.1 μs** | **1,479.87 μs** |   **978.84 μs** |  **9,986.4 μs** |  **1.31** |    **0.13** |         **-** |        **-** |        **-** |  **1578.95 KB** |        **0.06** |
| BuilderLatestOnly | Skender.GetBeta | 10000 | 10,352.2 μs | 1,157.52 μs |   688.82 μs | 10,025.2 μs |  1.28 |    0.10 |         - |        - |        - |     1109 KB |        0.04 |
| NativeSingle      | Skender.GetBeta | 10000 |  8,081.6 μs |   646.59 μs |   384.78 μs |  8,181.7 μs |  1.00 |    0.07 | 1615.3846 | 769.2308 | 153.8462 |  25737.2 KB |        1.00 |
| NativeParallel    | Skender.GetBeta | 10000 |  4,913.5 μs |   365.87 μs |   217.72 μs |  4,876.8 μs |  0.61 |    0.04 | 1593.7500 | 843.7500 |        - | 25830.73 KB |        1.00 |
