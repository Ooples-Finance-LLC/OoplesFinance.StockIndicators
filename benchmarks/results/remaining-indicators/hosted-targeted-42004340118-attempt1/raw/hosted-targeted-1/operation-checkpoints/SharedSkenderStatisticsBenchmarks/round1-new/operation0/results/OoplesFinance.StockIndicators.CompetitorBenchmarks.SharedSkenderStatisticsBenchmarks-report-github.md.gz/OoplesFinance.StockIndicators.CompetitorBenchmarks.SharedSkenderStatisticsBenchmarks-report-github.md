```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Median   | Allocated  |
|------------------ |---------------- |------ |----------:|----------:|----------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetBeta** | **1000**  |  **5.492 ms** | **8.3892 ms** | **5.5489 ms** | **2.549 ms** |  **171.61 KB** |
| BuilderLatestOnly | Skender.GetBeta | 1000  |  1.050 ms | 0.1182 ms | 0.0782 ms | 1.025 ms |   123.8 KB |
| **BuilderFull**       | **Skender.GetBeta** | **10000** |  **9.816 ms** | **0.0785 ms** | **0.0467 ms** | **9.803 ms** | **1578.95 KB** |
| BuilderLatestOnly | Skender.GetBeta | 10000 | 10.338 ms | 1.1037 ms | 0.7300 ms | 9.927 ms | 1108.95 KB |
