```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId          | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |---------------- |-----------:|----------:|----------:|------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetBeta** |   **928.6 μs** |  **56.22 μs** |  **33.45 μs** |  **1.00** |    **0.05** |   **450.35 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetBeta |   513.0 μs |  33.72 μs |  17.64 μs |  0.55 |    0.03 |  2722.01 KB |        6.04 |
|            |       |                 |            |           |           |       |         |             |             |
| **Ooples**     | **10000** | **Skender.GetBeta** | **8,618.5 μs** | **366.07 μs** | **217.84 μs** |  **1.00** |    **0.03** |  **4387.88 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetBeta | 6,259.1 μs | 316.92 μs | 188.59 μs |  0.73 |    0.03 | 27531.84 KB |        6.27 |
