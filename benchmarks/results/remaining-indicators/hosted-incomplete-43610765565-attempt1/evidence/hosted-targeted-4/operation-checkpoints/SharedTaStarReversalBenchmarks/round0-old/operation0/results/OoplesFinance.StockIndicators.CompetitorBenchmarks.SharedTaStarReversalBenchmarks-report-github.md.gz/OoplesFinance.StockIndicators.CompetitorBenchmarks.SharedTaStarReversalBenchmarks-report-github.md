```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation     | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |-------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **AbandonedBaby** | **1000**  | **117.6 μs** | **15.45 μs** | **10.22 μs** |  **3.9063** |       **-** |  **70.33 KB** |
| BuilderLatestOnly | AbandonedBaby | 1000  | 104.1 μs |  2.58 μs |  1.71 μs |  0.9766 |       - |  22.45 KB |
| **BuilderFull**       | **AbandonedBaby** | **10000** | **482.2 μs** | **98.50 μs** | **65.15 μs** | **33.2031** | **11.7188** | **562.88 KB** |
| BuilderLatestOnly | AbandonedBaby | 10000 | 360.7 μs | 52.46 μs | 34.70 μs |  3.9063 |       - |  92.78 KB |
