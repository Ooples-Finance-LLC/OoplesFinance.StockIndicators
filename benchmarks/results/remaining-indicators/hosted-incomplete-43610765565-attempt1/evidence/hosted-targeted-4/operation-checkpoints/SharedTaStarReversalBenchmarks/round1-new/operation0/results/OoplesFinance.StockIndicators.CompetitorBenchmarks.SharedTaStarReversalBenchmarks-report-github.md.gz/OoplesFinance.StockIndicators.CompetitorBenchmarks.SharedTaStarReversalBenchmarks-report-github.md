```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation     | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |-------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **AbandonedBaby** | **1000**  |  **84.78 μs** | **2.128 μs** | **1.407 μs** |  **2.9297** |       **-** |  **57.17 KB** |
| BuilderLatestOnly | AbandonedBaby | 1000  |  80.78 μs | 1.282 μs | 0.848 μs |  0.4883 |       - |   9.33 KB |
| **BuilderFull**       | **AbandonedBaby** | **10000** | **134.36 μs** | **3.242 μs** | **1.929 μs** | **33.2031** | **10.7422** |    **553 KB** |
| BuilderLatestOnly | AbandonedBaby | 10000 | 116.90 μs | 1.506 μs | 0.788 μs |  4.8828 |       - |  82.93 KB |
