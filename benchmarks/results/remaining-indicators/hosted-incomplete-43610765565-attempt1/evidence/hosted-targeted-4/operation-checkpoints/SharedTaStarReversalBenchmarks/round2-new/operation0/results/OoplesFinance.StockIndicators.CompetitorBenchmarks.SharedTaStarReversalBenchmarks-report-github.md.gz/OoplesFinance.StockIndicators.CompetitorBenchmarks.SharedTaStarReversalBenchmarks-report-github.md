```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation     | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |-------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **AbandonedBaby** | **1000**  |  **84.49 μs** |  **1.586 μs** |  **1.049 μs** |  **1.61** |    **0.02** |  **2.9297** |       **-** |  **57.21 KB** |       **14.40** |
| BuilderLatestOnly | AbandonedBaby | 1000  |  81.03 μs |  1.389 μs |  0.919 μs |  1.54 |    0.02 |  0.4883 |       - |   9.33 KB |        2.35 |
| NativeSingle      | AbandonedBaby | 1000  |  52.63 μs |  0.153 μs |  0.080 μs |  1.00 |    0.00 |       - |       - |   3.97 KB |        1.00 |
| NativeParallel    | AbandonedBaby | 1000  | 104.33 μs |  5.588 μs |  3.696 μs |  1.98 |    0.07 |       - |       - |    8.4 KB |        2.11 |
|                   |               |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **AbandonedBaby** | **10000** | **136.31 μs** |  **5.270 μs** |  **3.136 μs** |  **0.24** |    **0.01** | **33.2031** | **10.7422** | **553.03 KB** |       **14.13** |
| BuilderLatestOnly | AbandonedBaby | 10000 | 119.81 μs |  4.911 μs |  3.248 μs |  0.21 |    0.01 |  4.8828 |       - |  82.93 KB |        2.12 |
| NativeSingle      | AbandonedBaby | 10000 | 567.69 μs | 32.575 μs | 21.546 μs |  1.00 |    0.05 |       - |       - |  39.15 KB |        1.00 |
| NativeParallel    | AbandonedBaby | 10000 | 365.09 μs | 23.574 μs | 15.593 μs |  0.64 |    0.04 |  5.8594 |       - |  78.72 KB |        2.01 |
