```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation     | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |-------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **AbandonedBaby** | **1000**  | **119.7 μs** | **21.41 μs** | **14.16 μs** |  **3.9063** |       **-** |  **70.33 KB** |
| BuilderLatestOnly | AbandonedBaby | 1000  | 105.4 μs |  6.75 μs |  4.46 μs |  0.9766 |       - |  22.45 KB |
| **BuilderFull**       | **AbandonedBaby** | **10000** | **366.6 μs** | **13.26 μs** |  **6.94 μs** | **31.2500** | **11.7188** |  **562.9 KB** |
| BuilderLatestOnly | AbandonedBaby | 10000 | 335.9 μs |  7.68 μs |  4.02 μs |  3.9063 |       - |  92.79 KB |
