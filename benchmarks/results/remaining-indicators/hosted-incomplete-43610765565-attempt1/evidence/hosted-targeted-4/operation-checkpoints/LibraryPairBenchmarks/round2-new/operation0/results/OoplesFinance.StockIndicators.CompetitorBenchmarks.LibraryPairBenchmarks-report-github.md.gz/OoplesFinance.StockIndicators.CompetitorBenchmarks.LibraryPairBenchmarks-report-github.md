```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=20000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dBaby [27]** |  **19.98 μs** |  **1.700 μs** |  **0.889 μs** |  **1.00** |    **0.06** |  **65.11 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dBaby [27] |  78.52 μs | 23.331 μs | 15.432 μs |  3.94 |    0.76 |  12.08 KB |        0.19 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)dBaby [27]** | **104.18 μs** | **19.275 μs** | **11.470 μs** |  **1.01** |    **0.14** | **638.72 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dBaby [27] | 627.56 μs | 24.502 μs | 16.206 μs |  6.08 |    0.58 | 121.81 KB |        0.19 |
