```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=20000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)gStar [25]** |  **42.39 μs** |  **1.553 μs** |  **0.812 μs** |  **1.00** |    **0.03** |  **73.59 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)gStar [25] |  61.39 μs |  0.891 μs |  0.466 μs |  1.45 |    0.03 |   16.3 KB |        0.22 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)gStar [25]** | **290.94 μs** |  **4.148 μs** |  **2.169 μs** |  **1.00** |    **0.01** | **683.95 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)gStar [25] | 608.80 μs | 20.989 μs | 12.490 μs |  2.09 |    0.04 | 121.48 KB |        0.18 |
