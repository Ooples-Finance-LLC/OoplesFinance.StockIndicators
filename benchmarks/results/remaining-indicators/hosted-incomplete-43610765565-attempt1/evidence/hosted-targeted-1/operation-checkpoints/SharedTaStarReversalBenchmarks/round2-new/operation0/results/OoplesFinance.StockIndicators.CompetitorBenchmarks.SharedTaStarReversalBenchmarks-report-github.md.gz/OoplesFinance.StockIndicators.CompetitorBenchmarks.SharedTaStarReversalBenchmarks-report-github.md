```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------ |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **EveningStar** | **1000**  | **105.98 μs** |  **7.374 μs** |  **4.878 μs** |  **2.15** |    **0.09** |  **3.9063** |       **-** |  **69.48 KB** |       **17.49** |
| BuilderLatestOnly | EveningStar | 1000  |  98.84 μs |  1.390 μs |  0.727 μs |  2.00 |    0.01 |  0.9766 |       - |   21.6 KB |        5.44 |
| NativeSingle      | EveningStar | 1000  |  49.38 μs |  0.151 μs |  0.079 μs |  1.00 |    0.00 |       - |       - |   3.97 KB |        1.00 |
| NativeParallel    | EveningStar | 1000  | 101.85 μs |  2.450 μs |  1.281 μs |  2.06 |    0.02 |       - |       - |    8.4 KB |        2.11 |
|                   |             |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **EveningStar** | **10000** | **336.03 μs** | **35.694 μs** | **23.609 μs** |  **0.64** |    **0.05** | **35.1563** | **11.7188** | **602.36 KB** |       **15.39** |
| BuilderLatestOnly | EveningStar | 10000 | 323.06 μs | 36.351 μs | 24.044 μs |  0.61 |    0.05 |  7.8125 |       - | 132.24 KB |        3.38 |
| NativeSingle      | EveningStar | 10000 | 530.11 μs | 41.053 μs | 27.154 μs |  1.00 |    0.07 |       - |       - |  39.14 KB |        1.00 |
| NativeParallel    | EveningStar | 10000 | 346.96 μs | 22.029 μs | 14.571 μs |  0.66 |    0.04 |  5.8594 |       - |  78.72 KB |        2.01 |
