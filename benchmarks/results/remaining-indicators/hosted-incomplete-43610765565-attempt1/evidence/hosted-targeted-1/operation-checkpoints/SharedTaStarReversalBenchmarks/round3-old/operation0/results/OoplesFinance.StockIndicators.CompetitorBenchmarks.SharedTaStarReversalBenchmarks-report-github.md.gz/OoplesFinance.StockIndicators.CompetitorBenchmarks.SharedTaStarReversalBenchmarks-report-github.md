```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean     | Error    | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |------------ |------ |---------:|---------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **EveningStar** | **1000**  | **105.8 μs** |  **7.63 μs** | **5.05 μs** |  **3.9063** |       **-** |  **69.48 KB** |
| BuilderLatestOnly | EveningStar | 1000  | 102.4 μs |  4.66 μs | 3.08 μs |  0.9766 |       - |   21.6 KB |
| **BuilderFull**       | **EveningStar** | **10000** | **323.9 μs** | **10.25 μs** | **5.36 μs** | **35.1563** | **11.7188** | **602.36 KB** |
| BuilderLatestOnly | EveningStar | 10000 | 327.9 μs | 16.08 μs | 9.57 μs |  7.8125 |       - | 132.24 KB |
