```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------ |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **EveningStar** | **1000**  | **106.5 μs** |  **8.51 μs** |  **5.63 μs** |  **3.9063** |       **-** |  **69.45 KB** |
| BuilderLatestOnly | EveningStar | 1000  | 101.7 μs |  1.63 μs |  0.85 μs |  0.9766 |       - |   21.6 KB |
| **BuilderFull**       | **EveningStar** | **10000** | **322.3 μs** |  **6.26 μs** |  **3.27 μs** | **35.1563** | **11.7188** | **602.33 KB** |
| BuilderLatestOnly | EveningStar | 10000 | 321.2 μs | 19.68 μs | 13.01 μs |  7.8125 |       - | 132.24 KB |
