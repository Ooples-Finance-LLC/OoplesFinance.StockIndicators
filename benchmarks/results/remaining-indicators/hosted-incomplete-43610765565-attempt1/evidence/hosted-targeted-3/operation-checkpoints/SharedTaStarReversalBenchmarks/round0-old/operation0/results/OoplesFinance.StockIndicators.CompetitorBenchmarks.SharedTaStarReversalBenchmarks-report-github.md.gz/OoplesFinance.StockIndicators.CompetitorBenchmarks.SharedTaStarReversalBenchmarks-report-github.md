```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **EveningDojiStar** | **1000**  | **139.0 μs** | **23.33 μs** | **15.43 μs** |  **3.9063** |       **-** |  **71.27 KB** |
| BuilderLatestOnly | EveningDojiStar | 1000  | 130.2 μs |  4.62 μs |  3.05 μs |  0.9766 |       - |  23.39 KB |
| **BuilderFull**       | **EveningDojiStar** | **10000** | **504.7 μs** | **27.52 μs** | **16.38 μs** | **35.1563** | **11.7188** | **583.99 KB** |
| BuilderLatestOnly | EveningDojiStar | 10000 | 483.8 μs | 10.78 μs |  5.64 μs |  3.9063 |       - | 113.89 KB |
