```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |---------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **EveningDojiStar** | **1000**  | **134.23 μs** |  **8.371 μs** |  **4.378 μs** |  **2.17** |    **0.07** |  **3.9063** |       **-** |  **71.27 KB** |       **17.94** |
| BuilderLatestOnly | EveningDojiStar | 1000  | 132.34 μs |  7.477 μs |  4.945 μs |  2.14 |    0.08 |  0.9766 |       - |  23.39 KB |        5.89 |
| NativeSingle      | EveningDojiStar | 1000  |  61.78 μs |  0.733 μs |  0.485 μs |  1.00 |    0.01 |       - |       - |   3.97 KB |        1.00 |
| NativeParallel    | EveningDojiStar | 1000  | 124.83 μs |  5.721 μs |  3.784 μs |  2.02 |    0.06 |       - |       - |    8.4 KB |        2.11 |
|                   |                 |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **EveningDojiStar** | **10000** | **505.55 μs** |  **9.709 μs** |  **5.078 μs** |  **0.72** |    **0.01** | **35.1563** | **11.7188** | **583.99 KB** |       **14.92** |
| BuilderLatestOnly | EveningDojiStar | 10000 | 492.83 μs |  9.719 μs |  5.083 μs |  0.70 |    0.01 |  3.9063 |       - | 113.89 KB |        2.91 |
| NativeSingle      | EveningDojiStar | 10000 | 705.18 μs |  6.631 μs |  3.468 μs |  1.00 |    0.01 |       - |       - |  39.15 KB |        1.00 |
| NativeParallel    | EveningDojiStar | 10000 | 445.64 μs | 24.449 μs | 14.549 μs |  0.63 |    0.02 |  3.9063 |       - |  78.73 KB |        2.01 |
