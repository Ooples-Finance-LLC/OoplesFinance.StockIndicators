```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------------ |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **MorningStar** | **1000**  |  **82.63 μs** |  **3.000 μs** |  **1.785 μs** |  **3.9063** |       **-** |  **69.48 KB** |
| BuilderLatestOnly | MorningStar | 1000  |  79.23 μs |  1.008 μs |  0.600 μs |  0.9766 |       - |   21.6 KB |
| **BuilderFull**       | **MorningStar** | **10000** | **287.55 μs** | **17.455 μs** | **11.545 μs** | **35.1563** | **17.5781** | **607.03 KB** |
| BuilderLatestOnly | MorningStar | 10000 | 260.29 μs | 16.545 μs | 10.943 μs |  7.8125 |       - | 136.93 KB |
