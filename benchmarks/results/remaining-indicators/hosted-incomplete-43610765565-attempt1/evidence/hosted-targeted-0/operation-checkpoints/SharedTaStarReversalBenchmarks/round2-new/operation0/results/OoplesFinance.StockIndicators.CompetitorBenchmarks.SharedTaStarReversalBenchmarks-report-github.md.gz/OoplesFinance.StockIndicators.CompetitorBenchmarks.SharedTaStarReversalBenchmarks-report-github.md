```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------ |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **MorningStar** | **1000**  | **111.60 μs** |  **1.939 μs** |  **1.283 μs** |  **3.34** |    **0.28** |  **3.9063** |       **-** |  **69.48 KB** |       **17.50** |
| BuilderLatestOnly | MorningStar | 1000  | 107.52 μs |  0.859 μs |  0.449 μs |  3.21 |    0.26 |  0.9766 |       - |   21.6 KB |        5.44 |
| NativeSingle      | MorningStar | 1000  |  33.70 μs |  4.667 μs |  3.087 μs |  1.01 |    0.12 |       - |       - |   3.97 KB |        1.00 |
| NativeParallel    | MorningStar | 1000  | 106.07 μs |  1.397 μs |  0.831 μs |  3.17 |    0.26 |       - |       - |    8.4 KB |        2.12 |
|                   |             |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **MorningStar** | **10000** | **308.23 μs** |  **9.309 μs** |  **5.539 μs** |  **0.83** |    **0.01** | **35.1563** | **17.5781** | **607.03 KB** |       **15.51** |
| BuilderLatestOnly | MorningStar | 10000 | 285.79 μs |  7.074 μs |  3.700 μs |  0.77 |    0.01 |  7.8125 |       - | 136.93 KB |        3.50 |
| NativeSingle      | MorningStar | 10000 | 373.36 μs |  3.143 μs |  1.870 μs |  1.00 |    0.01 |  1.9531 |       - |  39.13 KB |        1.00 |
| NativeParallel    | MorningStar | 10000 | 307.00 μs | 19.326 μs | 12.783 μs |  0.82 |    0.03 |  5.8594 |       - |  78.72 KB |        2.01 |
