```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=20000  

```
| Method | Bars  | PairId               | Mean      | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)gStar [25]** |  **31.19 μs** | **4.262 μs** | **2.229 μs** |  **1.00** |    **0.09** |  **73.59 KB** |        **1.00** |
|        |       |                      |           |          |          |       |         |           |             |
| **Ooples** | **10000** | **TaLib(...)gStar [25]** | **198.86 μs** | **2.518 μs** | **1.317 μs** |  **1.00** |    **0.01** | **688.26 KB** |        **1.00** |
