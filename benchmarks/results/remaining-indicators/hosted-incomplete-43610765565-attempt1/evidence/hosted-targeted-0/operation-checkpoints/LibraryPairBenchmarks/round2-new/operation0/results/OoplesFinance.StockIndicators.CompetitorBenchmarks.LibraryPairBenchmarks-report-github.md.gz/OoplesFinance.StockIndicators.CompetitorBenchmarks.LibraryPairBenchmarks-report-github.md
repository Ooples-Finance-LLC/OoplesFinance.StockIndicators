```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=20000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)gStar [25]** |  **32.57 μs** |  **9.149 μs** | **5.444 μs** |  **1.02** |    **0.21** |  **73.59 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)gStar [25] |  41.31 μs |  0.361 μs | 0.215 μs |  1.30 |    0.17 |  12.08 KB |        0.16 |
|            |       |                      |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)gStar [25]** | **226.46 μs** | **11.490 μs** | **6.009 μs** |  **1.00** |    **0.04** | **683.43 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)gStar [25] | 406.77 μs |  1.185 μs | 0.705 μs |  1.80 |    0.05 | 117.55 KB |        0.17 |
