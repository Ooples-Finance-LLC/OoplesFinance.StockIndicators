```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Crows [29]** | **215.84 μs** |  **7.719 μs** |  **4.594 μs** |  **1.00** |    **0.03** |  **69.37 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Crows [29] |  51.28 μs |  0.455 μs |  0.301 μs |  0.24 |    0.00 |   16.3 KB |        0.23 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Crows [29]** | **283.89 μs** | **22.870 μs** | **13.610 μs** |  **1.00** |    **0.06** | **638.34 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Crows [29] | 504.92 μs | 19.016 μs | 12.578 μs |  1.78 |    0.09 | 122.75 KB |        0.19 |
