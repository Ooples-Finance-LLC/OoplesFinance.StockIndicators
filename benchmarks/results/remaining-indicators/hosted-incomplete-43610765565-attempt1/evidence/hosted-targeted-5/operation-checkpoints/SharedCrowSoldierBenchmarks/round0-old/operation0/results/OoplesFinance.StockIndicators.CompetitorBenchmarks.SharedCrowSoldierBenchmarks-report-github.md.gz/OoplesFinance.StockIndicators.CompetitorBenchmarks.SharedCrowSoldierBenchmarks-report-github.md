```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation            | Mean     | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |------ |--------------------- |---------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **1000**  | **TaLib(...)Crows [29]** | **107.0 μs** |  **5.36 μs** |  **3.19 μs** |  **3.9063** |      **-** |  **65.66 KB** |
| BuilderLatestOnly | 1000  | TaLib(...)Crows [29] | 102.4 μs |  4.67 μs |  3.09 μs |  0.9766 |      - |  17.78 KB |
| **BuilderFull**       | **10000** | **TaLib(...)Crows [29]** | **330.0 μs** |  **6.70 μs** |  **3.51 μs** | **31.2500** | **7.8125** | **558.22 KB** |
| BuilderLatestOnly | 10000 | TaLib(...)Crows [29] | 320.6 μs | 16.99 μs | 11.24 μs |  3.9063 |      - |   88.1 KB |
