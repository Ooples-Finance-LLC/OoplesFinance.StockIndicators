```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=20000  

```
| Method     | Bars  | PairId               | Mean      | Error      | StdDev     | Median    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|-----------:|-----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)iStar [29]** |  **68.11 μs** |   **5.441 μs** |   **2.846 μs** |  **67.40 μs** |  **1.00** |    **0.05** |  **73.08 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)iStar [29] |  81.64 μs |  13.480 μs |   8.022 μs |  77.70 μs |  1.20 |    0.12 |  19.25 KB |        0.26 |
|            |       |                      |           |            |            |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)iStar [29]** | **580.81 μs** | **299.308 μs** | **197.974 μs** | **442.95 μs** |  **1.10** |    **0.48** | **662.63 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)iStar [29] | 757.96 μs |  31.988 μs |  16.730 μs | 766.25 μs |  1.43 |    0.40 | 124.44 KB |        0.19 |
