```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **MorningDojiStar** | **1000**  | **131.8 μs** |  **5.77 μs** |  **3.02 μs** |  **3.9063** |       **-** |  **71.74 KB** |
| BuilderLatestOnly | MorningDojiStar | 1000  | 129.6 μs |  2.16 μs |  1.13 μs |  0.9766 |       - |  23.86 KB |
| **BuilderFull**       | **MorningDojiStar** | **10000** | **525.3 μs** | **51.38 μs** | **33.98 μs** | **35.1563** | **11.7188** | **583.52 KB** |
| BuilderLatestOnly | MorningDojiStar | 10000 | 534.2 μs | 61.56 μs | 40.72 μs |  3.9063 |       - | 113.42 KB |
