```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean     | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |---------------- |------ |---------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **MorningDojiStar** | **1000**  | **141.1 μs** | **23.94 μs** | **15.84 μs** |  **3.9063** |      **-** |  **71.74 KB** |
| BuilderLatestOnly | MorningDojiStar | 1000  | 127.0 μs |  2.57 μs |  1.34 μs |  0.9766 |      - |  23.86 KB |
| **BuilderFull**       | **MorningDojiStar** | **10000** | **493.5 μs** |  **7.03 μs** |  **3.68 μs** | **31.2500** | **7.8125** | **583.55 KB** |
| BuilderLatestOnly | MorningDojiStar | 10000 | 508.8 μs | 60.76 μs | 36.16 μs |  3.9063 |      - | 113.42 KB |
