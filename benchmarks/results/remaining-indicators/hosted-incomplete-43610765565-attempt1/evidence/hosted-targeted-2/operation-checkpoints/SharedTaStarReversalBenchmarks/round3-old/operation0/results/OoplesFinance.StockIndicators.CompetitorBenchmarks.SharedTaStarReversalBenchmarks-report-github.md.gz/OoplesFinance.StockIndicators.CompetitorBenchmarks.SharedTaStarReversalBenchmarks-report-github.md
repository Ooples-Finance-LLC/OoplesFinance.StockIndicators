```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **MorningDojiStar** | **1000**  | **142.4 μs** | **23.97 μs** | **15.85 μs** |  **3.9063** |       **-** |  **71.74 KB** |
| BuilderLatestOnly | MorningDojiStar | 1000  | 127.4 μs |  2.63 μs |  1.38 μs |  0.9766 |       - |  23.86 KB |
| **BuilderFull**       | **MorningDojiStar** | **10000** | **503.4 μs** |  **8.84 μs** |  **4.62 μs** | **35.1563** | **11.7188** | **583.52 KB** |
| BuilderLatestOnly | MorningDojiStar | 10000 | 507.4 μs | 47.54 μs | 31.45 μs |  3.9063 |       - | 113.42 KB |
