```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |---------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **MorningDojiStar** | **1000**  | **142.49 μs** | **19.717 μs** | **13.042 μs** |  **2.27** |    **0.20** |  **3.9063** |       **-** |   **71.7 KB** |       **18.05** |
| BuilderLatestOnly | MorningDojiStar | 1000  | 132.64 μs |  6.747 μs |  4.463 μs |  2.12 |    0.07 |  0.9766 |       - |  23.86 KB |        6.01 |
| NativeSingle      | MorningDojiStar | 1000  |  62.64 μs |  0.614 μs |  0.365 μs |  1.00 |    0.01 |       - |       - |   3.97 KB |        1.00 |
| NativeParallel    | MorningDojiStar | 1000  | 125.31 μs |  6.391 μs |  4.227 μs |  2.00 |    0.07 |       - |       - |    8.4 KB |        2.11 |
|                   |                 |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **MorningDojiStar** | **10000** | **498.61 μs** |  **5.957 μs** |  **3.116 μs** |  **0.70** |    **0.01** | **35.1563** | **11.7188** | **583.49 KB** |       **14.90** |
| BuilderLatestOnly | MorningDojiStar | 10000 | 507.48 μs | 55.247 μs | 36.543 μs |  0.71 |    0.05 |  3.9063 |       - | 113.42 KB |        2.90 |
| NativeSingle      | MorningDojiStar | 10000 | 713.59 μs | 15.719 μs | 10.397 μs |  1.00 |    0.02 |       - |       - |  39.16 KB |        1.00 |
| NativeParallel    | MorningDojiStar | 10000 | 441.63 μs | 13.008 μs |  6.803 μs |  0.62 |    0.01 |  3.9063 |       - |  78.73 KB |        2.01 |
