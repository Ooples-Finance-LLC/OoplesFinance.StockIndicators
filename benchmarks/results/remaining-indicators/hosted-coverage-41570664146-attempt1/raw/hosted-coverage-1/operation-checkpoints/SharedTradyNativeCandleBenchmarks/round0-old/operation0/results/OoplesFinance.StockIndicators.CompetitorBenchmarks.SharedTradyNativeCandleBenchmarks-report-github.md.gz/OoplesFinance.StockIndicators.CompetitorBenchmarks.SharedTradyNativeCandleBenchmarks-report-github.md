```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **RisingThreeMethods** | **1000**  |   **275.0 μs** |  **5.69 μs** |  **3.76 μs** |  **1.9531** |       **-** |  **61.06 KB** |
| BuilderLatestOnly | RisingThreeMethods | 1000  |   276.6 μs |  6.17 μs |  3.23 μs |       - |       - |  13.22 KB |
| **BuilderFull**       | **RisingThreeMethods** | **10000** | **2,981.2 μs** | **17.56 μs** |  **9.18 μs** | **31.2500** | **15.6250** | **553.64 KB** |
| BuilderLatestOnly | RisingThreeMethods | 10000 | 2,946.7 μs | 30.17 μs | 17.95 μs |       - |       - |  83.66 KB |
