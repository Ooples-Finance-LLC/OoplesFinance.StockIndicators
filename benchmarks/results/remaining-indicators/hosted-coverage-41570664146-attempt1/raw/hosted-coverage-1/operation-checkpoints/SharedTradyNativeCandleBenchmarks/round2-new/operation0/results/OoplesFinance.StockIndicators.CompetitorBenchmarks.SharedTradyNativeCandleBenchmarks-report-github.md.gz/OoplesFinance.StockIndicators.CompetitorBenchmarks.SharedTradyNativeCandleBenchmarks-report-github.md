```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | InvocationCount | Operation          | Count | Mean             | Error         | StdDev        | Ratio | RatioSD | Gen0          | Gen1         | Gen2         | Allocated       | Alloc Ratio |
|------------------ |---------------- |------------------- |------ |-----------------:|--------------:|--------------:|------:|--------:|--------------:|-------------:|-------------:|----------------:|------------:|
| **BuilderFull**       | **Default**         | **RisingThreeMethods** | **1000**  |         **272.9 μs** |       **3.62 μs** |       **2.15 μs** |     **?** |       **?** |             **-** |            **-** |            **-** |        **61.09 KB** |           **?** |
| BuilderLatestOnly | Default         | RisingThreeMethods | 1000  |         269.3 μs |       4.34 μs |       2.27 μs |     ? |       ? |             - |            - |            - |        13.22 KB |           ? |
|                   |                 |                    |       |                  |               |               |       |         |               |              |              |                 |             |
| NativeSingle      | 1               | RisingThreeMethods | 1000  |     867,180.0 μs |   6,841.93 μs |   4,525.51 μs |  1.00 |    0.01 |    91000.0000 |    1000.0000 |            - |   1497803.88 KB |        1.00 |
| NativeParallel    | 1               | RisingThreeMethods | 1000  |     355,651.1 μs |   9,818.76 μs |   6,494.50 μs |  0.41 |    0.01 |    58000.0000 |    1000.0000 |            - |    933075.59 KB |        0.62 |
|                   |                 |                    |       |                  |               |               |       |         |               |              |              |                 |             |
| **BuilderFull**       | **Default**         | **RisingThreeMethods** | **10000** |       **2,952.1 μs** |      **10.11 μs** |       **6.68 μs** |     **?** |       **?** |       **31.2500** |      **15.6250** |            **-** |       **553.63 KB** |           **?** |
| BuilderLatestOnly | Default         | RisingThreeMethods | 10000 |       4,113.5 μs |      12.63 μs |       7.52 μs |     ? |       ? |             - |            - |            - |        83.54 KB |           ? |
|                   |                 |                    |       |                  |               |               |       |         |               |              |              |                 |             |
| NativeSingle      | 1               | RisingThreeMethods | 10000 | 107,750,996.9 μs | 725,094.72 μs | 479,605.26 μs |  1.00 |    0.01 | 11347000.0000 | 2707000.0000 | 2571000.0000 | 154210801.84 KB |        1.00 |
| NativeParallel    | 1               | RisingThreeMethods | 10000 |  38,365,718.2 μs | 243,466.19 μs | 161,037.81 μs |  0.36 |    0.00 |  6360000.0000 |  787000.0000 |  780000.0000 |  95702430.39 KB |        0.62 |
