```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Trady(...)Index [36]** | **1000**  |  **1.151 ms** | **0.0161 ms** | **0.0096 ms** |  **84.75 KB** |
| BuilderLatestOnly | Trady(...)Index [36] | 1000  |  1.139 ms | 0.0059 ms | 0.0039 ms |   37.2 KB |
| **BuilderFull**       | **Trady(...)Index [36]** | **10000** | **11.202 ms** | **0.1338 ms** | **0.0796 ms** | **887.74 KB** |
| BuilderLatestOnly | Trady(...)Index [36] | 10000 | 11.169 ms | 0.0782 ms | 0.0465 ms | 418.47 KB |
