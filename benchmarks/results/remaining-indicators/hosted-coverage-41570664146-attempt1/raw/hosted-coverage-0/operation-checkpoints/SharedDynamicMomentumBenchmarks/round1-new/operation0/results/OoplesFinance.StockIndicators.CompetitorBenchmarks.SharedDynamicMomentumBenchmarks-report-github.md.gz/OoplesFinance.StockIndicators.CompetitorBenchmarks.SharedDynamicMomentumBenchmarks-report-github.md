```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Trady(...)Index [36]** | **1000**  |  **1.187 ms** | **0.0102 ms** | **0.0068 ms** |  **84.75 KB** |
| BuilderLatestOnly | Trady(...)Index [36] | 1000  |  1.260 ms | 0.1051 ms | 0.0695 ms |  37.21 KB |
| **BuilderFull**       | **Trady(...)Index [36]** | **10000** | **11.691 ms** | **0.0250 ms** | **0.0131 ms** | **887.74 KB** |
| BuilderLatestOnly | Trady(...)Index [36] | 10000 | 11.604 ms | 0.0762 ms | 0.0504 ms | 417.93 KB |
