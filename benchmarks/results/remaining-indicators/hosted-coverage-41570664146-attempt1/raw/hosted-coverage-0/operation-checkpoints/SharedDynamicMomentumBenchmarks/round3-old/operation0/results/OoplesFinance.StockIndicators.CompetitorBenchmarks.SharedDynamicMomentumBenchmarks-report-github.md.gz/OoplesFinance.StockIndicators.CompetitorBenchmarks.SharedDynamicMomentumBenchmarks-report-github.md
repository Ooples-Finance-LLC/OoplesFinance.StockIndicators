```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Trady(...)Index [36]** | **1000**  |  **1.183 ms** | **0.0159 ms** | **0.0095 ms** |  **84.75 KB** |
| BuilderLatestOnly | Trady(...)Index [36] | 1000  |  1.195 ms | 0.0243 ms | 0.0127 ms |  37.19 KB |
| **BuilderFull**       | **Trady(...)Index [36]** | **10000** | **11.620 ms** | **0.0632 ms** | **0.0376 ms** | **887.74 KB** |
| BuilderLatestOnly | Trady(...)Index [36] | 10000 | 11.523 ms | 0.0524 ms | 0.0347 ms | 417.93 KB |
