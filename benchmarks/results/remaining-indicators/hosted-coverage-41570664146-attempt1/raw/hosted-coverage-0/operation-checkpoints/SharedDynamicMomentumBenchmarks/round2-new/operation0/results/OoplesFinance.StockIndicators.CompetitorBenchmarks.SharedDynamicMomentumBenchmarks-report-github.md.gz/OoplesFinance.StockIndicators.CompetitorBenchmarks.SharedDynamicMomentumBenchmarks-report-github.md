```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | InvocationCount | Operation            | Count | Mean           | Error         | StdDev        | Ratio | RatioSD | Gen0          | Gen1          | Gen2          | Allocated       | Alloc Ratio |
|------------------ |---------------- |--------------------- |------ |---------------:|--------------:|--------------:|------:|--------:|--------------:|--------------:|--------------:|----------------:|------------:|
| **BuilderFull**       | **Default**         | **Trady(...)Index [36]** | **1000**  |       **1.183 ms** |     **0.0085 ms** |     **0.0051 ms** |     **?** |       **?** |             **-** |             **-** |             **-** |        **84.75 KB** |           **?** |
| BuilderLatestOnly | Default         | Trady(...)Index [36] | 1000  |       1.172 ms |     0.0083 ms |     0.0043 ms |     ? |       ? |             - |             - |             - |         37.2 KB |           ? |
|                   |                 |                      |       |                |               |               |       |         |               |               |               |                 |             |
| NativeSingle      | 1               | Trady(...)Index [36] | 1000  |     663.781 ms |     5.5619 ms |     3.6788 ms |  1.00 |    0.01 |    95000.0000 |    34000.0000 |             - |    1566892.1 KB |        1.00 |
| NativeParallel    | 1               | Trady(...)Index [36] | 1000  |     753.096 ms |     8.7841 ms |     5.2273 ms |  1.13 |    0.01 |   128000.0000 |     1000.0000 |             - |   2022986.11 KB |        1.29 |
|                   |                 |                      |       |                |               |               |       |         |               |               |               |                 |             |
| **BuilderFull**       | **Default**         | **Trady(...)Index [36]** | **10000** |      **11.696 ms** |     **0.1053 ms** |     **0.0551 ms** |     **?** |       **?** |             **-** |             **-** |             **-** |       **887.74 KB** |           **?** |
| BuilderLatestOnly | Default         | Trady(...)Index [36] | 10000 |      11.683 ms |     0.0300 ms |     0.0157 ms |     ? |       ? |             - |             - |             - |       417.93 KB |           ? |
|                   |                 |                      |       |                |               |               |       |         |               |               |               |                 |             |
| NativeSingle      | 1               | Trady(...)Index [36] | 10000 | 100,830.514 ms | 9,727.3373 ms | 6,434.0314 ms |  1.00 |    0.09 | 18899000.0000 | 15285000.0000 | 14093000.0000 | 158105874.91 KB |        1.00 |
| NativeParallel    | 1               | Trady(...)Index [36] | 10000 |  98,879.888 ms | 1,940.7457 ms | 1,154.9067 ms |  0.98 |    0.06 | 18470000.0000 | 10887000.0000 | 10668000.0000 | 202916165.05 KB |        1.28 |
