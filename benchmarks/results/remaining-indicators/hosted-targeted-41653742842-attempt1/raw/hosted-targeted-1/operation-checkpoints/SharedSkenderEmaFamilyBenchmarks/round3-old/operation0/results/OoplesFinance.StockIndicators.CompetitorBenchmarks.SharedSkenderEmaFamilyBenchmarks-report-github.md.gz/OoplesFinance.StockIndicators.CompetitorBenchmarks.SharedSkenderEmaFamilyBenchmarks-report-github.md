```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetPmo** | **1000**  |   **701.5 μs** |  **44.01 μs** | **29.11 μs** |  **80.96 KB** |
| BuilderLatestOnly | Skender.GetPmo | 1000  |   664.8 μs |  21.73 μs | 14.37 μs |  33.29 KB |
| **BuilderFull**       | **Skender.GetPmo** | **10000** | **6,920.8 μs** | **110.09 μs** | **57.58 μs** | **784.87 KB** |
| BuilderLatestOnly | Skender.GetPmo | 10000 | 6,803.7 μs |  21.35 μs | 11.17 μs | 314.97 KB |
