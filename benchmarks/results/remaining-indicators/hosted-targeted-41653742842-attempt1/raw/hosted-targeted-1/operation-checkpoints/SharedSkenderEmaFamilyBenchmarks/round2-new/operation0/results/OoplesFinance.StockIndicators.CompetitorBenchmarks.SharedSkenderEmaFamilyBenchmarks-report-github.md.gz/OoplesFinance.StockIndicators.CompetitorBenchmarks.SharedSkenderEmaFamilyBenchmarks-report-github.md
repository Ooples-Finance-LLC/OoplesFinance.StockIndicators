```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetPmo** | **1000**  |   **571.88 μs** |  **19.600 μs** |  **11.664 μs** |  **9.23** |    **0.27** |        **-** |        **-** |        **-** |   **80.98 KB** |        **0.38** |
| BuilderLatestOnly | Skender.GetPmo | 1000  |   552.12 μs |  17.129 μs |  11.330 μs |  8.91 |    0.26 |        - |        - |        - |   33.35 KB |        0.15 |
| NativeSingle      | Skender.GetPmo | 1000  |    61.97 μs |   2.488 μs |   1.481 μs |  1.00 |    0.03 |   8.7891 |   1.9531 |        - |  215.88 KB |        1.00 |
| NativeParallel    | Skender.GetPmo | 1000  |   128.77 μs |  11.531 μs |   7.627 μs |  2.08 |    0.13 |  24.4141 |   7.8125 |        - |  552.62 KB |        2.56 |
|                   |                |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetPmo** | **10000** | **5,840.32 μs** | **142.551 μs** |  **94.289 μs** |  **4.73** |    **0.61** |  **31.2500** |        **-** |        **-** |  **784.64 KB** |        **0.35** |
| BuilderLatestOnly | Skender.GetPmo | 10000 | 5,713.41 μs | 179.811 μs | 118.934 μs |  4.63 |    0.60 |        - |        - |        - |  314.83 KB |        0.14 |
| NativeSingle      | Skender.GetPmo | 10000 | 1,256.83 μs | 273.662 μs | 181.011 μs |  1.02 |    0.19 | 140.6250 | 140.6250 | 140.6250 |  2250.1 KB |        1.00 |
| NativeParallel    | Skender.GetPmo | 10000 | 2,743.13 μs | 264.769 μs | 175.128 μs |  2.22 |    0.32 | 343.7500 | 343.7500 | 203.1250 | 5639.98 KB |        2.51 |
