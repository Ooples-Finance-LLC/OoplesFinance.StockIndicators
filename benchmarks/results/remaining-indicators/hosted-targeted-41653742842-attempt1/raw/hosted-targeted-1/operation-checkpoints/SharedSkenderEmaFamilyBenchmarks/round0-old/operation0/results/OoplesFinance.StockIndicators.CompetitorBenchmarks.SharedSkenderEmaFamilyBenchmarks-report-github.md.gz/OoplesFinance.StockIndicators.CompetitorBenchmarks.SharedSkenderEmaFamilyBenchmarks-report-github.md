```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetPmo** | **1000**  |   **781.2 μs** |  **5.18 μs** |  **2.71 μs** |  **80.96 KB** |
| BuilderLatestOnly | Skender.GetPmo | 1000  |   761.7 μs |  7.31 μs |  4.35 μs |  33.33 KB |
| **BuilderFull**       | **Skender.GetPmo** | **10000** | **7,928.1 μs** | **91.85 μs** | **48.04 μs** | **784.93 KB** |
| BuilderLatestOnly | Skender.GetPmo | 10000 | 7,897.6 μs | 88.41 μs | 46.24 μs | 315.09 KB |
