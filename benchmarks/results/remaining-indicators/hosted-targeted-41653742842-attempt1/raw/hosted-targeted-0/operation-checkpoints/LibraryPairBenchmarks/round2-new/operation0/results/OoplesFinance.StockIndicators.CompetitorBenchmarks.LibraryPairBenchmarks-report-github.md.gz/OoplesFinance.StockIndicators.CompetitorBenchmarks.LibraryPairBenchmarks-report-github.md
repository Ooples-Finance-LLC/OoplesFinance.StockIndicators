```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetPmo** |   **746.88 μs** | **20.733 μs** | **12.338 μs** |  **1.00** |    **0.02** |  **162.38 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetPmo |    72.67 μs |  3.504 μs |  1.833 μs |  0.10 |    0.00 |  273.12 KB |        1.68 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetPmo** | **6,939.81 μs** | **40.020 μs** | **23.815 μs** |  **1.00** |    **0.00** | **1594.03 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetPmo |   763.77 μs | 61.114 μs | 36.368 μs |  0.11 |    0.00 | 2746.57 KB |        1.72 |
