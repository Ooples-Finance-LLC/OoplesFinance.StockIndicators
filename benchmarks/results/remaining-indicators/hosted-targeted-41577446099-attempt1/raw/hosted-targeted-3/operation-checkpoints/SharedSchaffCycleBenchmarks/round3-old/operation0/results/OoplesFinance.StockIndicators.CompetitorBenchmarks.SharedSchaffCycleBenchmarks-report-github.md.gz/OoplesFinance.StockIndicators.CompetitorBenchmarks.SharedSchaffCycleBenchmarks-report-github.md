```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Gen0   | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetStc** | **1000**  |   **660.1 μs** |  **14.07 μs** |   **8.38 μs** | **3.9063** |  **66.55 KB** |
| BuilderLatestOnly | Skender.GetStc | 1000  |   638.9 μs |  16.53 μs |  10.93 μs |      - |  18.96 KB |
| **BuilderFull**       | **Skender.GetStc** | **10000** | **6,771.3 μs** | **134.01 μs** |  **70.09 μs** |      **-** | **629.68 KB** |
| BuilderLatestOnly | Skender.GetStc | 10000 | 6,521.5 μs | 186.70 μs | 111.10 μs |      - | 159.97 KB |
