```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetStc** | **1000**  |   **631.0 μs** |  **17.92 μs** |  **11.85 μs** |  **3.9063** |  **66.55 KB** |
| BuilderLatestOnly | Skender.GetStc | 1000  |   633.6 μs |  20.61 μs |  13.63 μs |       - |  18.97 KB |
| **BuilderFull**       | **Skender.GetStc** | **10000** | **6,421.5 μs** | **173.50 μs** | **103.25 μs** | **31.2500** | **629.61 KB** |
| BuilderLatestOnly | Skender.GetStc | 10000 | 6,244.1 μs | 179.25 μs | 118.57 μs |       - | 159.61 KB |
