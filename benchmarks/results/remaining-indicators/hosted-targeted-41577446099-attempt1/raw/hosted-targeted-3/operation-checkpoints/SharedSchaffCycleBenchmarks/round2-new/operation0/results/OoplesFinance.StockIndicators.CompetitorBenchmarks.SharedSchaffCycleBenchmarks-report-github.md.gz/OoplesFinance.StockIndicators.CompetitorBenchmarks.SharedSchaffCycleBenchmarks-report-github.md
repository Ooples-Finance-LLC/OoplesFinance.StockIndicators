```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error        | StdDev     | Ratio | RatioSD | Gen0      | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-------------:|-----------:|------:|--------:|----------:|---------:|---------:|------------:|------------:|
| **BuilderFull**       | **Skender.GetStc** | **1000**  |   **367.61 μs** |     **2.726 μs** |   **1.426 μs** |  **4.94** |    **0.10** |         **-** |        **-** |        **-** |    **66.64 KB** |        **0.12** |
| BuilderLatestOnly | Skender.GetStc | 1000  |   337.56 μs |    11.458 μs |   7.579 μs |  4.53 |    0.13 |         - |        - |        - |    18.99 KB |        0.04 |
| NativeSingle      | Skender.GetStc | 1000  |    74.51 μs |     2.408 μs |   1.592 μs |  1.00 |    0.03 |   32.2266 |   9.2773 |        - |   534.43 KB |        1.00 |
| NativeParallel    | Skender.GetStc | 1000  |   139.97 μs |    12.475 μs |   7.424 μs |  1.88 |    0.10 |   85.9375 |  33.2031 |        - |   1338.3 KB |        2.50 |
|                   |                |       |             |              |            |       |         |           |          |          |             |             |
| **BuilderFull**       | **Skender.GetStc** | **10000** | **3,454.95 μs** |    **93.977 μs** |  **55.924 μs** |  **1.06** |    **0.07** |   **31.2500** |        **-** |        **-** |    **629.6 KB** |        **0.11** |
| BuilderLatestOnly | Skender.GetStc | 10000 | 3,509.12 μs |   151.156 μs |  99.980 μs |  1.08 |    0.08 |         - |        - |        - |   159.79 KB |        0.03 |
| NativeSingle      | Skender.GetStc | 10000 | 3,257.50 μs |   307.490 μs | 203.385 μs |  1.00 |    0.09 |  500.0000 | 437.5000 | 218.7500 |  5621.84 KB |        1.00 |
| NativeParallel    | Skender.GetStc | 10000 | 5,065.36 μs | 1,340.482 μs | 886.646 μs |  1.56 |    0.28 | 1066.6667 | 866.6667 | 333.3333 | 13992.42 KB |        2.49 |
