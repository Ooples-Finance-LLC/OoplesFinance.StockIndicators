```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1.461 ms** | **0.0289 ms** | **0.0191 ms** |  **71.66 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1.475 ms | 0.0207 ms | 0.0108 ms |     24 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **15.679 ms** | **0.4779 ms** | **0.2500 ms** | **635.07 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 15.192 ms | 0.5444 ms | 0.3240 ms | 164.99 KB |
