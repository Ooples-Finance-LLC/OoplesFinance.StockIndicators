```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1,084.6 μs** |  **37.72 μs** |  **24.95 μs** |  **2.72** |    **0.07** |  **71.63 KB** |       **15.13** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1,005.9 μs |  12.06 μs |   6.31 μs |  2.52 |    0.03 |  23.98 KB |        5.07 |
| NativeSingle      | TaLib(...)dMode [27] | 1000  |    399.0 μs |   8.67 μs |   5.16 μs |  1.00 |    0.02 |   4.73 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 1000  |    540.9 μs |  49.46 μs |  32.72 μs |  1.36 |    0.08 |   17.4 KB |        3.68 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **11,284.4 μs** |  **88.56 μs** |  **46.32 μs** |  **2.65** |    **0.02** | **634.92 KB** |       **15.86** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 11,117.0 μs |  73.84 μs |  38.62 μs |  2.61 |    0.01 | 165.18 KB |        4.13 |
| NativeSingle      | TaLib(...)dMode [27] | 10000 |  4,258.7 μs |  35.25 μs |  20.98 μs |  1.00 |    0.01 |  40.02 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 10000 |  5,608.6 μs | 381.16 μs | 252.11 μs |  1.32 |    0.06 | 140.64 KB |        3.51 |
