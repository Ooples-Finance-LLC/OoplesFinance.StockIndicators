```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |------------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |    **999.8 μs** |  **31.86 μs** |  **18.96 μs** |  **71.55 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |    987.0 μs |  39.12 μs |  25.88 μs |  23.97 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **11,034.5 μs** | **130.59 μs** |  **68.30 μs** | **634.86 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 10,920.6 μs | 668.48 μs | 442.16 μs | 164.89 KB |
