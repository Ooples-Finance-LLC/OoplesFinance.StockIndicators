```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1.488 ms** | **0.0461 ms** | **0.0305 ms** |  **71.62 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1.488 ms | 0.0752 ms | 0.0393 ms |  23.97 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **15.624 ms** | **0.3462 ms** | **0.2060 ms** | **634.71 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 15.511 ms | 0.3273 ms | 0.1948 ms | 165.43 KB |
