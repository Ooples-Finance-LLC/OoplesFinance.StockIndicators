```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev   | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|---------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dMode [27]** |  **1,017.5 μs** |  **14.61 μs** |  **8.70 μs** |  **1.00** |  **112.68 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dMode [27] |    414.5 μs |   9.50 μs |  6.28 μs |  0.41 |   32.32 KB |        0.29 |
|            |       |                      |             |           |          |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)dMode [27]** | **11,329.3 μs** | **110.16 μs** | **65.55 μs** |  **1.00** | **1035.86 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dMode [27] |  4,358.2 μs |  97.08 μs | 64.21 μs |  0.38 |  286.88 KB |        0.28 |
