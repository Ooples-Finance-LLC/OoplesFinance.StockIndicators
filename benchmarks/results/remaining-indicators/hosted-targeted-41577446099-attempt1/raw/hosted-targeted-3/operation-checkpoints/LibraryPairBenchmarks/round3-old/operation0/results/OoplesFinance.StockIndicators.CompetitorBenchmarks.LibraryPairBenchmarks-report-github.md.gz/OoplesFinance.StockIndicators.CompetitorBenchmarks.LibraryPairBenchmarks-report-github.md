```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |-----------:|----------:|---------:|------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)eriod [26]** |   **810.5 μs** |   **4.41 μs** |  **2.63 μs** |  **1.00** |  **107.65 KB** |        **1.00** |
|        |       |                      |            |           |          |       |            |             |
| **Ooples** | **10000** | **TaLib(...)eriod [26]** | **7,904.9 μs** | **123.51 μs** | **73.50 μs** |  **1.00** | **1030.83 KB** |        **1.00** |
