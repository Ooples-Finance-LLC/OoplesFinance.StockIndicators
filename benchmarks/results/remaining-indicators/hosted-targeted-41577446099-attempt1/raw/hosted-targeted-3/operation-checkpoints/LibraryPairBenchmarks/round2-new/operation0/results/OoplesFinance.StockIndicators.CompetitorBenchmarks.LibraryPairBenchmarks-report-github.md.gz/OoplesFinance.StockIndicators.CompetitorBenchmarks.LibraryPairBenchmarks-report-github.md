```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)eriod [26]** |   **358.09 μs** | **12.804 μs** |  **8.469 μs** |  **1.00** |    **0.03** | **107.65 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)eriod [26] |    79.65 μs |  1.491 μs |  0.887 μs |  0.22 |    0.01 |  33.84 KB |        0.31 |
|            |       |                      |             |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)eriod [26]** | **3,378.49 μs** | **60.755 μs** | **40.185 μs** |  **1.00** |    **0.02** | **1031.2 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)eriod [26] |   779.29 μs |  8.631 μs |  5.136 μs |  0.23 |    0.00 | 324.91 KB |        0.32 |
