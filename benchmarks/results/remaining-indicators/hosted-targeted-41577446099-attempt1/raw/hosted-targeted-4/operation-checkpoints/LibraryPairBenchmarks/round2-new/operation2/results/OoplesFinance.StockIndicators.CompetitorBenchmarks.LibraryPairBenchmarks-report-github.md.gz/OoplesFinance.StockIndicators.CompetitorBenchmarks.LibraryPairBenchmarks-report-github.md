```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Phase [25]** |  **1,160.7 μs** | **30.40 μs** | **20.11 μs** |  **1.00** |    **0.02** |  **110.06 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Phase [25] |    543.8 μs | 24.62 μs | 16.29 μs |  0.47 |    0.02 |    41.8 KB |        0.38 |
|            |       |                      |             |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)Phase [25]** | **11,662.2 μs** | **97.49 μs** | **58.02 μs** |  **1.00** |    **0.01** | **1040.74 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Phase [25] |  5,697.1 μs | 48.47 μs | 32.06 μs |  0.49 |    0.00 |  331.47 KB |        0.32 |
