```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean         | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-------------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetKvo** |  **1,076.63 μs** |  **43.851 μs** |  **29.005 μs** |  **1.00** |    **0.04** |  **162.95 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetKvo |     82.22 μs |   0.835 μs |   0.437 μs |  0.08 |    0.00 |   273.5 KB |        1.68 |
|            |       |                |              |            |            |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetKvo** | **10,746.18 μs** | **335.580 μs** | **221.966 μs** |  **1.00** |    **0.03** | **1594.93 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetKvo |    851.29 μs |  30.502 μs |  18.151 μs |  0.08 |    0.00 | 2646.27 KB |        1.66 |
