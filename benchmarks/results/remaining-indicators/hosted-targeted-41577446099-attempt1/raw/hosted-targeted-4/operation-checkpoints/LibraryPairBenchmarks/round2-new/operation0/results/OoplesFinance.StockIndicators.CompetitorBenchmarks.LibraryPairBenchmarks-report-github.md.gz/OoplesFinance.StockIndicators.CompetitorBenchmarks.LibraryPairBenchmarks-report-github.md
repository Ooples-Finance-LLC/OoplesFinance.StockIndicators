```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------- |-----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Mama** |   **732.9 μs** | **50.38 μs** | **33.32 μs** |  **1.00** |    **0.06** | **164.02 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Mama |   332.7 μs | 29.81 μs | 19.72 μs |  0.45 |    0.03 |  98.34 KB |        0.60 |
|            |       |                |            |          |          |       |         |           |             |
| **Ooples**     | **10000** | **QuanTAlib.Mama** | **6,858.3 μs** | **27.35 μs** | **16.28 μs** |  **1.00** |    **0.00** |   **1596 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Mama | 3,175.3 μs | 59.01 μs | 35.12 μs |  0.46 |    0.00 | 889.36 KB |        0.56 |
