```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  | **1,473.4 μs** | **449.89 μs** | **297.57 μs** | **100.91 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  |   991.6 μs |   6.07 μs |   4.01 μs |  53.26 KB |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **9,711.0 μs** |  **93.16 μs** |  **55.44 μs** | **945.58 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 9,805.0 μs | 111.38 μs |  66.28 μs | 475.76 KB |
