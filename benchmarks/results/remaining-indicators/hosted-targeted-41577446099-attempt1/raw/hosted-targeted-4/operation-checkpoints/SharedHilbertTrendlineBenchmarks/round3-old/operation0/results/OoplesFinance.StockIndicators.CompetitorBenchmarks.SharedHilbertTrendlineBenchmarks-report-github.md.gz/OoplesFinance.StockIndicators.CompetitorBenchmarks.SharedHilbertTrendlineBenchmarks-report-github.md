```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  |  **2.045 ms** | **0.0189 ms** | **0.0112 ms** | **100.98 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  |  1.724 ms | 0.0124 ms | 0.0065 ms |  53.33 KB |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **16.851 ms** | **0.0970 ms** | **0.0508 ms** | **946.19 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 16.751 ms | 0.0931 ms | 0.0487 ms | 476.38 KB |
