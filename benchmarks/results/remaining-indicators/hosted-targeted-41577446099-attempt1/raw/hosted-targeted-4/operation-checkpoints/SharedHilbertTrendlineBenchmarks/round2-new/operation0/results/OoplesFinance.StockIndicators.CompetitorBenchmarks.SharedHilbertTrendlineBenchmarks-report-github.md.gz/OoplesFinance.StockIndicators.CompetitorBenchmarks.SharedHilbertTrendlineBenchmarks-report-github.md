```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  |  **1,106.6 μs** |  **54.93 μs** |  **28.73 μs** |  **8.48** |    **0.21** |        **-** |        **-** |        **-** |  **100.86 KB** |        **0.49** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  |  1,021.3 μs |   5.94 μs |   3.53 μs |  7.82 |    0.05 |        - |        - |        - |   53.22 KB |        0.26 |
| NativeSingle      | Skend(...)dline [22] | 1000  |    130.6 μs |   1.49 μs |   0.78 μs |  1.00 |    0.01 |  12.6953 |   2.9297 |        - |  207.71 KB |        1.00 |
| NativeParallel    | Skend(...)dline [22] | 1000  |    192.2 μs |   8.25 μs |   4.32 μs |  1.47 |    0.03 |  33.2031 |  11.7188 |        - |  528.53 KB |        2.54 |
|                   |                      |       |             |           |           |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **10,125.6 μs** | **102.08 μs** |  **60.74 μs** |  **6.83** |    **0.07** |        **-** |        **-** |        **-** |   **945.6 KB** |        **0.46** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 10,223.9 μs |  41.70 μs |  24.81 μs |  6.89 |    0.06 |        - |        - |        - |  475.86 KB |        0.23 |
| NativeSingle      | Skend(...)dline [22] | 10000 |  1,483.3 μs |  25.64 μs |  13.41 μs |  1.00 |    0.01 | 187.5000 | 156.2500 |  85.9375 | 2072.14 KB |        1.00 |
| NativeParallel    | Skend(...)dline [22] | 10000 |  2,411.8 μs | 277.91 μs | 183.82 μs |  1.63 |    0.12 | 421.8750 | 328.1250 | 140.6250 | 5258.42 KB |        2.54 |
