```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)eriod [26]** | **1000**  | **1,088.5 μs** | **31.53 μs** | **18.76 μs** |  **66.63 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 1000  |   925.6 μs | 14.07 μs |  9.31 μs |  18.96 KB |
| **BuilderFull**       | **TaLib(...)eriod [26]** | **10000** | **9,050.7 μs** | **32.08 μs** | **16.78 μs** | **629.81 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 10000 | 9,013.9 μs | 29.68 μs | 19.63 μs | 159.96 KB |
