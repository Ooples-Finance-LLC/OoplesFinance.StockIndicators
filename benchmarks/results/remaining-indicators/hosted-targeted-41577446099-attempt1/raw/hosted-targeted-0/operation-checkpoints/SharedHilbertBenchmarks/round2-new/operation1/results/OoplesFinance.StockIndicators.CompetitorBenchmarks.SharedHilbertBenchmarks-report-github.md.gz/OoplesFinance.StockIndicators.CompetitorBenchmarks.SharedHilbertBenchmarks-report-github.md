```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)hasor [24]** | **1000**  |   **385.37 μs** |  **7.382 μs** |  **4.393 μs** |  **4.18** |    **0.05** |        **-** |        **-** |        **-** |  **82.42 KB** |        **5.30** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 1000  |   377.53 μs |  4.737 μs |  3.133 μs |  4.09 |    0.03 |        - |        - |        - |  34.83 KB |        2.24 |
| NativeSingle      | TaLib(...)hasor [24] | 1000  |    92.29 μs |  0.421 μs |  0.250 μs |  1.00 |    0.00 |   0.4883 |        - |        - |  15.55 KB |        1.00 |
| NativeParallel    | TaLib(...)hasor [24] | 1000  |   132.24 μs |  4.047 μs |  2.677 μs |  1.43 |    0.03 |   3.9063 |        - |        - |  54.83 KB |        3.53 |
|                   |                      |       |             |           |           |       |         |          |          |          |           |             |
| **BuilderFull**       | **TaLib(...)hasor [24]** | **10000** | **3,810.88 μs** | **33.710 μs** | **20.060 μs** |  **3.64** |    **0.03** |  **31.2500** |        **-** |        **-** | **786.09 KB** |        **5.02** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 10000 | 3,743.91 μs | 31.255 μs | 16.347 μs |  3.58 |    0.02 |        - |        - |        - | 316.22 KB |        2.02 |
| NativeSingle      | TaLib(...)hasor [24] | 10000 | 1,047.22 μs |  8.136 μs |  5.381 μs |  1.00 |    0.01 |  46.8750 |  46.8750 |  46.8750 | 156.58 KB |        1.00 |
| NativeParallel    | TaLib(...)hasor [24] | 10000 | 1,351.20 μs | 25.921 μs | 17.145 μs |  1.29 |    0.02 | 132.8125 | 132.8125 | 132.8125 | 548.11 KB |        3.50 |
