```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mama** | **1000**  | **1,146.2 μs** | **15.78 μs** |  **9.39 μs** |  **82.72 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 1000  |   999.6 μs |  4.34 μs |  2.27 μs |  35.04 KB |
| **BuilderFull**       | **TaLib.Functions.Mama** | **10000** | **9,830.5 μs** | **35.45 μs** | **18.54 μs** | **786.68 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 10000 | 9,680.5 μs | 42.71 μs | 22.34 μs | 316.72 KB |
