```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)eriod [26]** | **1000**  |   **369.03 μs** |  **3.541 μs** |  **1.852 μs** |  **3.86** |    **0.02** |       **-** |  **66.52 KB** |        **8.33** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 1000  |   369.59 μs |  2.138 μs |  1.272 μs |  3.86 |    0.01 |       - |  18.92 KB |        2.37 |
| NativeSingle      | TaLib(...)eriod [26] | 1000  |    95.64 μs |  0.118 μs |  0.062 μs |  1.00 |    0.00 |       - |   7.99 KB |        1.00 |
| NativeParallel    | TaLib(...)eriod [26] | 1000  |   130.62 μs |  4.527 μs |  2.995 μs |  1.37 |    0.03 |  1.9531 |  28.36 KB |        3.55 |
|                   |                      |       |             |           |           |       |         |         |           |             |
| **BuilderFull**       | **TaLib(...)eriod [26]** | **10000** | **3,682.34 μs** | **60.686 μs** | **36.113 μs** |  **3.72** |    **0.05** | **31.2500** | **629.53 KB** |        **8.04** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 10000 | 3,652.27 μs | 26.797 μs | 14.015 μs |  3.69 |    0.04 |       - | 159.76 KB |        2.04 |
| NativeSingle      | TaLib(...)eriod [26] | 10000 |   989.86 μs | 16.640 μs | 11.006 μs |  1.00 |    0.02 |       - |  78.34 KB |        1.00 |
| NativeParallel    | TaLib(...)eriod [26] | 10000 | 1,218.43 μs | 70.694 μs | 42.069 μs |  1.23 |    0.04 | 15.6250 | 274.51 KB |        3.50 |
