```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Mama** | **1000**  |   **447.47 μs** |  **40.109 μs** |  **23.868 μs** |  **4.68** |    **0.24** |        **-** |        **-** |        **-** |  **82.61 KB** |        **5.31** |
| BuilderLatestOnly | TaLib.Functions.Mama | 1000  |   468.17 μs |  36.107 μs |  21.487 μs |  4.89 |    0.21 |        - |        - |        - |  35.02 KB |        2.25 |
| NativeSingle      | TaLib.Functions.Mama | 1000  |    95.66 μs |   1.042 μs |   0.545 μs |  1.00 |    0.01 |        - |        - |        - |  15.55 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mama | 1000  |   150.83 μs |   9.621 μs |   6.364 μs |  1.58 |    0.06 |   3.9063 |        - |        - |  54.83 KB |        3.53 |
|                   |                      |       |             |            |            |       |         |          |          |          |           |             |
| **BuilderFull**       | **TaLib.Functions.Mama** | **10000** | **4,569.24 μs** | **282.183 μs** | **167.923 μs** |  **4.38** |    **0.15** |  **31.2500** |        **-** |        **-** | **786.34 KB** |        **5.02** |
| BuilderLatestOnly | TaLib.Functions.Mama | 10000 | 4,485.11 μs | 237.366 μs | 157.003 μs |  4.30 |    0.15 |        - |        - |        - | 316.51 KB |        2.02 |
| NativeSingle      | TaLib.Functions.Mama | 10000 | 1,043.39 μs |   9.690 μs |   5.767 μs |  1.00 |    0.01 |  46.8750 |  46.8750 |  46.8750 | 156.57 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mama | 10000 | 1,484.47 μs |  77.409 μs |  46.065 μs |  1.42 |    0.04 | 132.8125 | 132.8125 | 132.8125 |  548.1 KB |        3.50 |
