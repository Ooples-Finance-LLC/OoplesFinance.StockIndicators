```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)eriod [26]** | **1000**  |   **963.6 μs** | **31.07 μs** | **18.49 μs** |  **66.63 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 1000  |   924.8 μs |  4.49 μs |  2.35 μs |  18.95 KB |
| **BuilderFull**       | **TaLib(...)eriod [26]** | **10000** | **9,170.4 μs** | **45.15 μs** | **23.61 μs** | **629.79 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 10000 | 9,078.9 μs | 44.11 μs | 26.25 μs | 159.89 KB |
