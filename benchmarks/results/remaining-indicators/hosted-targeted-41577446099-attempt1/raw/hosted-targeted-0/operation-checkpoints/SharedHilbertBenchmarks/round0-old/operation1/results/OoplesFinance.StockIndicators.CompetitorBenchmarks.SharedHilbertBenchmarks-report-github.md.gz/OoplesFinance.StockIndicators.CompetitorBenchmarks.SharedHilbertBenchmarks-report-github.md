```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)hasor [24]** | **1000**  | **2,494.2 μs** | **246.70 μs** | **129.03 μs** |  **82.53 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 1000  |   958.5 μs |   8.07 μs |   4.81 μs |  34.84 KB |
| **BuilderFull**       | **TaLib(...)hasor [24]** | **10000** | **9,444.4 μs** |  **33.85 μs** |  **17.70 μs** | **786.48 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 10000 | 9,434.3 μs |  40.99 μs |  21.44 μs | 316.67 KB |
