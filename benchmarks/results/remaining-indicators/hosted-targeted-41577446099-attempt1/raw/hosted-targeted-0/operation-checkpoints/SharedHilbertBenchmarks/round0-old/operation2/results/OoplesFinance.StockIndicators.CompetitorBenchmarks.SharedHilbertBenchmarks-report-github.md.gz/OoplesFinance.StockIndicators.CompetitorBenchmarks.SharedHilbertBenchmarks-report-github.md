```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mama** | **1000**  |  **1.544 ms** | **0.0077 ms** | **0.0046 ms** |  **82.72 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 1000  |  1.007 ms | 0.0052 ms | 0.0027 ms |  35.02 KB |
| **BuilderFull**       | **TaLib.Functions.Mama** | **10000** | **10.323 ms** | **0.1653 ms** | **0.0984 ms** | **786.71 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 10000 |  9.813 ms | 0.0363 ms | 0.0216 ms | 316.68 KB |
