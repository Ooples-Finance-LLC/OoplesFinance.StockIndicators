```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)hasor [24]** | **1000**  |   **375.3 μs** |  **3.33 μs** |  **1.74 μs** |       **-** |  **82.41 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 1000  |   374.8 μs |  2.01 μs |  1.05 μs |       - |  34.81 KB |
| **BuilderFull**       | **TaLib(...)hasor [24]** | **10000** | **3,738.3 μs** | **43.71 μs** | **26.01 μs** | **31.2500** | **786.12 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 10000 | 3,713.9 μs | 54.84 μs | 28.68 μs |       - | 316.25 KB |
