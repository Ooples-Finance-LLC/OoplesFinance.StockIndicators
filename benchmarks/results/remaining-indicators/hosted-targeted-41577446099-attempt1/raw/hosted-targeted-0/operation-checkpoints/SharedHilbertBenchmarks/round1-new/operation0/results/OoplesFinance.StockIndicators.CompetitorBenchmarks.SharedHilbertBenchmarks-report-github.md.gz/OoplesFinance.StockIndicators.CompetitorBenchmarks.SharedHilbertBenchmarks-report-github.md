```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)eriod [26]** | **1000**  |   **365.5 μs** |  **3.41 μs** |  **1.78 μs** |       **-** |  **66.52 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 1000  |   365.5 μs |  1.47 μs |  0.77 μs |       - |  18.92 KB |
| **BuilderFull**       | **TaLib(...)eriod [26]** | **10000** | **3,615.8 μs** | **50.33 μs** | **26.32 μs** | **31.2500** | **629.52 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 10000 | 3,706.3 μs | 24.47 μs | 12.80 μs |       - | 159.79 KB |
