```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)hasor [24]** | **1000**  |   **976.2 μs** | **24.82 μs** | **16.42 μs** |  **82.53 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 1000  |   970.8 μs |  8.05 μs |  4.21 μs |  34.86 KB |
| **BuilderFull**       | **TaLib(...)hasor [24]** | **10000** | **9,286.8 μs** | **37.21 μs** | **19.46 μs** | **786.36 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 10000 | 9,174.3 μs | 67.07 μs | 35.08 μs | 316.58 KB |
