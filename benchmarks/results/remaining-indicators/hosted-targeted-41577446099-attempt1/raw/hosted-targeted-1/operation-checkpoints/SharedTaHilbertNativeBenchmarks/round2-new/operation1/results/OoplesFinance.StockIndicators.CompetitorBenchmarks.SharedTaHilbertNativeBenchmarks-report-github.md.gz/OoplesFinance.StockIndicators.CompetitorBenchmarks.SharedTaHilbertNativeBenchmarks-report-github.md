```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **1,100.3 μs** |  **22.24 μs** |  **13.23 μs** |  **2.02** |    **0.02** |      **-** |  **84.84 KB** |        **5.39** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1,104.3 μs |  32.98 μs |  21.82 μs |  2.03 |    0.04 |      - |  37.22 KB |        2.36 |
| NativeSingle      | TaLib(...)tSine [22] | 1000  |    543.5 μs |   3.43 μs |   2.04 μs |  1.00 |    0.01 |      - |  15.74 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 1000  |    737.1 μs |  49.94 μs |  33.03 μs |  1.36 |    0.06 | 3.9063 |  55.96 KB |        3.56 |
|                   |                      |       |             |           |           |       |         |        |           |             |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **11,408.9 μs** | **106.06 μs** |  **63.11 μs** |  **1.94** |    **0.01** |      **-** | **789.18 KB** |        **5.04** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 11,366.8 μs |  78.34 μs |  40.97 μs |  1.93 |    0.01 |      - |  319.4 KB |        2.04 |
| NativeSingle      | TaLib(...)tSine [22] | 10000 |  5,876.9 μs |  21.59 μs |  12.85 μs |  1.00 |    0.00 |      - | 156.57 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 10000 |  7,473.7 μs | 303.38 μs | 158.67 μs |  1.27 |    0.03 |      - | 548.68 KB |        3.50 |
