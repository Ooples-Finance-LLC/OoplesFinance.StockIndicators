```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **1.877 ms** | **0.0103 ms** | **0.0061 ms** |  **69.08 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1.839 ms | 0.0125 ms | 0.0066 ms |  21.45 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **19.014 ms** | **0.0588 ms** | **0.0350 ms** | **633.17 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 18.967 ms | 0.0963 ms | 0.0573 ms | 163.31 KB |
