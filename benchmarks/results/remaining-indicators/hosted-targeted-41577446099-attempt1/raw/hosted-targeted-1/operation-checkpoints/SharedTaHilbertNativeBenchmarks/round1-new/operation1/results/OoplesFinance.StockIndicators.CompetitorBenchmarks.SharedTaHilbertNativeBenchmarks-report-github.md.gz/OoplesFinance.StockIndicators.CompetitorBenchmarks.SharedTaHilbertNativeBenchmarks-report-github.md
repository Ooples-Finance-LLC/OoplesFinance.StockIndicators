```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **1.096 ms** | **0.0075 ms** | **0.0039 ms** |  **84.84 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1.086 ms | 0.0054 ms | 0.0028 ms |  37.27 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **11.413 ms** | **0.1224 ms** | **0.0728 ms** | **789.11 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 11.484 ms | 0.1122 ms | 0.0667 ms | 319.26 KB |
