```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **1.091 ms** | **0.0042 ms** | **0.0022 ms** |  **68.95 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1.087 ms | 0.0126 ms | 0.0066 ms |  21.38 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **11.346 ms** | **0.0645 ms** | **0.0337 ms** | **632.63 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 11.290 ms | 0.0248 ms | 0.0148 ms | 162.89 KB |
