```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dline [27]** | **1000**  |  **3.017 ms** | **0.0309 ms** | **0.0184 ms** |  **69.31 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 1000  |  1.961 ms | 0.0134 ms | 0.0080 ms |  21.66 KB |
| **BuilderFull**       | **TaLib(...)dline [27]** | **10000** | **20.001 ms** | **0.1587 ms** | **0.0944 ms** | **633.54 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 10000 | 23.471 ms | 0.1033 ms | 0.0615 ms | 163.78 KB |
