```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error    | StdDev   | Ratio | RatioSD | Gen0    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|---------:|---------:|------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dline [27]** | **1000**  |  **1,067.9 μs** |  **5.79 μs** |  **3.45 μs** |  **8.62** |    **0.03** |       **-** |  **69.23 KB** |        **8.70** |
| BuilderLatestOnly | TaLib(...)dline [27] | 1000  |  1,031.5 μs |  9.74 μs |  5.80 μs |  8.32 |    0.05 |       - |   21.6 KB |        2.72 |
| NativeSingle      | TaLib(...)dline [27] | 1000  |    123.9 μs |  0.31 μs |  0.16 μs |  1.00 |    0.00 |       - |   7.95 KB |        1.00 |
| NativeParallel    | TaLib(...)dline [27] | 1000  |    180.9 μs |  7.49 μs |  4.96 μs |  1.46 |    0.04 |  1.9531 |  28.51 KB |        3.59 |
|                   |                      |       |             |          |          |       |         |         |           |             |
| **BuilderFull**       | **TaLib(...)dline [27]** | **10000** | **10,628.4 μs** | **82.57 μs** | **43.19 μs** |  **7.81** |    **0.03** |       **-** | **632.75 KB** |        **8.08** |
| BuilderLatestOnly | TaLib(...)dline [27] | 10000 | 10,636.4 μs | 54.27 μs | 32.30 μs |  7.81 |    0.03 |       - | 162.94 KB |        2.08 |
| NativeSingle      | TaLib(...)dline [27] | 10000 |  1,361.1 μs |  5.54 μs |  3.30 μs |  1.00 |    0.00 |       - |  78.32 KB |        1.00 |
| NativeParallel    | TaLib(...)dline [27] | 10000 |  1,755.3 μs | 53.89 μs | 32.07 μs |  1.29 |    0.02 | 15.6250 | 274.72 KB |        3.51 |
