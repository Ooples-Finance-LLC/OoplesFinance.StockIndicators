```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **3.548 ms** | **0.9600 ms** | **0.5713 ms** |  **69.08 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1.835 ms | 0.0188 ms | 0.0098 ms |  21.45 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **18.812 ms** | **0.0733 ms** | **0.0383 ms** | **633.12 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 19.163 ms | 0.0762 ms | 0.0399 ms | 163.31 KB |
