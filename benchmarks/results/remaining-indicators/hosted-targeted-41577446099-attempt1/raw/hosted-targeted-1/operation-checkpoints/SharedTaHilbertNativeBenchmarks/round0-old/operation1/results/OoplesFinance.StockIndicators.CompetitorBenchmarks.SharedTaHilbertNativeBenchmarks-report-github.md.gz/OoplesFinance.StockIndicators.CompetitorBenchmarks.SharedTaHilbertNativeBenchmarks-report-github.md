```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **3.835 ms** | **2.8816 ms** | **1.9060 ms** |  **84.97 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1.860 ms | 0.0518 ms | 0.0308 ms |  37.33 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **19.161 ms** | **0.1204 ms** | **0.0630 ms** | **789.68 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 19.071 ms | 0.0972 ms | 0.0643 ms | 319.82 KB |
