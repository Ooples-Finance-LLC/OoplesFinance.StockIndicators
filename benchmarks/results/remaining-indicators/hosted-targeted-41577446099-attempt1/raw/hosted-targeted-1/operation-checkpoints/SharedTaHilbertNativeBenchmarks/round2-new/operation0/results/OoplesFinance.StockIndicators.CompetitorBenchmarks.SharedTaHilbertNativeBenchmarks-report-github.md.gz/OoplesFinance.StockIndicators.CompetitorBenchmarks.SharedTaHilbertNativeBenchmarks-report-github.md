```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **1,094.7 μs** |  **16.36 μs** |   **9.74 μs** |  **2.09** |    **0.03** |  **68.95 KB** |        **8.22** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1,087.2 μs |   3.00 μs |   1.57 μs |  2.08 |    0.03 |  21.38 KB |        2.55 |
| NativeSingle      | TaLib(...)Phase [25] | 1000  |    522.8 μs |  11.96 μs |   7.12 μs |  1.00 |    0.02 |   8.39 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 1000  |    701.7 μs |  51.02 μs |  33.74 μs |  1.34 |    0.06 |  30.19 KB |        3.60 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **11,308.0 μs** |  **68.80 μs** |  **40.94 μs** |  **2.01** |    **0.01** | **632.63 KB** |        **8.02** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 11,306.4 μs |  60.28 μs |  35.87 μs |  2.01 |    0.01 | 162.81 KB |        2.06 |
| NativeSingle      | TaLib(...)Phase [25] | 10000 |  5,632.7 μs |  25.68 μs |  13.43 μs |  1.00 |    0.00 |  78.92 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 10000 |  7,149.3 μs | 243.92 μs | 127.57 μs |  1.27 |    0.02 | 276.78 KB |        3.51 |
