```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dline [27]** | **1000**  |  **1.040 ms** | **0.0070 ms** | **0.0036 ms** |  **69.23 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 1000  |  1.022 ms | 0.0100 ms | 0.0059 ms |   21.6 KB |
| **BuilderFull**       | **TaLib(...)dline [27]** | **10000** | **10.628 ms** | **0.1632 ms** | **0.0854 ms** | **632.78 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 10000 | 10.522 ms | 0.0821 ms | 0.0429 ms |  162.9 KB |
