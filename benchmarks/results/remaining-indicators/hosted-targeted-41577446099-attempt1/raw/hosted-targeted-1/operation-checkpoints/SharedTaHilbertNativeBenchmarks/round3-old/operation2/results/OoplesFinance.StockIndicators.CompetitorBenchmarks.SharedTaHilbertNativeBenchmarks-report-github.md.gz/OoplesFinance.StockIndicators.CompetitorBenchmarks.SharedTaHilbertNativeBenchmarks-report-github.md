```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dline [27]** | **1000**  |  **3.007 ms** | **0.0245 ms** | **0.0146 ms** |  **69.31 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 1000  |  1.953 ms | 0.0150 ms | 0.0078 ms |  21.66 KB |
| **BuilderFull**       | **TaLib(...)dline [27]** | **10000** | **21.019 ms** | **0.1062 ms** | **0.0555 ms** | **633.61 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 10000 | 19.952 ms | 0.1554 ms | 0.0925 ms | 162.28 KB |
