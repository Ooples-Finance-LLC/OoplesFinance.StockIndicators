```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetKvo** | **1000**  |   **979.5 μs** |   **8.95 μs** |  **4.68 μs** |  **81.29 KB** |
| BuilderLatestOnly | Skender.GetKvo | 1000  |   967.0 μs |  15.64 μs |  9.31 μs |  33.66 KB |
| **BuilderFull**       | **Skender.GetKvo** | **10000** | **9,713.1 μs** | **103.13 μs** | **61.37 μs** | **785.37 KB** |
| BuilderLatestOnly | Skender.GetKvo | 10000 | 9,654.4 μs |  33.70 μs | 17.63 μs | 315.69 KB |
