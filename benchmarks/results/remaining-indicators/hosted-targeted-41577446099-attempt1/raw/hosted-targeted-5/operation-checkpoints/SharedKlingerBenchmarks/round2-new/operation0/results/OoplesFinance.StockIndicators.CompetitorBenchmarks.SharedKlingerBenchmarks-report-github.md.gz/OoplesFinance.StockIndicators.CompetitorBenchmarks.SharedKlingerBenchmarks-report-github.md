```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetKvo** | **1000**  | **1,291.59 μs** | **232.260 μs** | **153.626 μs** | **17.79** |    **2.03** |        **-** |        **-** |   **81.29 KB** |        **0.39** |
| BuilderLatestOnly | Skender.GetKvo | 1000  |   959.04 μs |   7.428 μs |   4.420 μs | 13.21 |    0.19 |        - |        - |   33.65 KB |        0.16 |
| NativeSingle      | Skender.GetKvo | 1000  |    72.62 μs |   1.543 μs |   1.020 μs |  1.00 |    0.02 |  12.6953 |   3.9063 |  207.63 KB |        1.00 |
| NativeParallel    | Skender.GetKvo | 1000  |   133.34 μs |   9.736 μs |   6.440 μs |  1.84 |    0.09 |  33.2031 |  10.7422 |  528.19 KB |        2.54 |
|                   |                |       |             |            |            |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetKvo** | **10000** | **9,854.20 μs** | **126.744 μs** |  **75.423 μs** | **11.77** |    **0.14** |        **-** |        **-** |   **785.4 KB** |        **0.38** |
| BuilderLatestOnly | Skender.GetKvo | 10000 | 9,713.73 μs |  86.075 μs |  51.222 μs | 11.60 |    0.12 |        - |        - |  315.59 KB |        0.15 |
| NativeSingle      | Skender.GetKvo | 10000 |   837.54 μs |  13.520 μs |   8.046 μs |  1.00 |    0.01 | 125.0000 |  85.9375 | 2070.96 KB |        1.00 |
| NativeParallel    | Skender.GetKvo | 10000 | 1,391.15 μs |  76.728 μs |  50.751 μs |  1.66 |    0.06 | 320.3125 | 257.8125 | 5256.76 KB |        2.54 |
