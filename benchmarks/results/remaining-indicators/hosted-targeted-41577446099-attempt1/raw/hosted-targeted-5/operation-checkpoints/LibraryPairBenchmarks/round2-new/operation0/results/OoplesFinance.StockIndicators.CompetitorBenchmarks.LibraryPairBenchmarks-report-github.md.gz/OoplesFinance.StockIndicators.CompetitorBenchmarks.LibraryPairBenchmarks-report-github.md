```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)dline [22]** |  **1,200.2 μs** | **27.54 μs** | **16.39 μs** |  **1.00** |    **0.02** |  **222.88 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)dline [22] |    180.9 μs |  1.56 μs |  0.81 μs |  0.15 |    0.00 |   290.2 KB |        1.30 |
|            |       |                      |             |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)dline [22]** | **11,783.9 μs** | **99.75 μs** | **52.17 μs** |  **1.00** |    **0.01** | **2156.16 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)dline [22] |  1,882.0 μs | 29.84 μs | 17.76 μs |  0.16 |    0.00 | 2812.33 KB |        1.30 |
