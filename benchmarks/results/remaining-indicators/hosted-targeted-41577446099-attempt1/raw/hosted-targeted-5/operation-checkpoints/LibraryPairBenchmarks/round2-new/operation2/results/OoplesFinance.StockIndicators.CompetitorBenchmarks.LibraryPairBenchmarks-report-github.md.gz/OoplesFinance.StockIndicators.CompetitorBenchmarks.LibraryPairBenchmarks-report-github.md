```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)hasor [24]** |   **651.8 μs** | **27.77 μs** | **16.52 μs** |  **1.00** |    **0.03** |  **164.05 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)hasor [24] |   111.5 μs |  0.46 μs |  0.24 μs |  0.17 |    0.00 |   73.49 KB |        0.45 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)hasor [24]** | **6,285.2 μs** | **63.87 μs** | **33.40 μs** |  **1.00** |    **0.01** | **1595.75 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)hasor [24] | 1,107.8 μs | 13.48 μs |  8.02 μs |  0.18 |    0.00 |  653.62 KB |        0.41 |
