```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **Skend(...)dline [22]** |  **2.086 ms** | **0.0283 ms** | **0.0169 ms** |  **1.00** |    **0.01** | **222.91 KB** |        **1.00** |
|        |       |                      |           |           |           |       |         |           |             |
| **Ooples** | **10000** | **Skend(...)dline [22]** | **21.177 ms** | **0.4258 ms** | **0.2534 ms** |  **1.00** |    **0.02** | **2156.2 KB** |        **1.00** |
