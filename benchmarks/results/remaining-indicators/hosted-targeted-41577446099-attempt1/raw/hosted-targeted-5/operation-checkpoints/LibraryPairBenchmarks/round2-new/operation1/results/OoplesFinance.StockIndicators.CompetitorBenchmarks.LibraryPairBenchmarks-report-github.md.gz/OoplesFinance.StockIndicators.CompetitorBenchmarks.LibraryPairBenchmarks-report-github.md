```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId          | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetMama** |  **1,130.1 μs** |  **41.45 μs** |  **27.42 μs** |  **1.00** |    **0.03** |  **164.02 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetMama |    163.4 μs |  34.15 μs |  22.59 μs |  0.14 |    0.02 |  249.61 KB |        1.52 |
|            |       |                 |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetMama** | **10,900.1 μs** | **212.69 μs** | **126.57 μs** |  **1.00** |    **0.02** | **1596.33 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetMama |  1,521.5 μs |  45.04 μs |  29.79 μs |  0.14 |    0.00 | 2410.36 KB |        1.51 |
