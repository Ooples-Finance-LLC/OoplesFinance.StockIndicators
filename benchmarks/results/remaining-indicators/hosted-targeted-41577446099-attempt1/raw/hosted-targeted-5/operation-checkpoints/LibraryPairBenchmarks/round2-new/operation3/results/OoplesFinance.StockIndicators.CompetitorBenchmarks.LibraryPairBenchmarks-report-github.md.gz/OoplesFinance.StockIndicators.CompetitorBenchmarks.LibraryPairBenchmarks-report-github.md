```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Mama** |   **746.4 μs** |  **55.12 μs** |  **32.80 μs** |  **1.00** |    **0.06** |  **164.02 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Mama |   129.5 μs |   2.00 μs |   1.04 μs |  0.17 |    0.01 |   74.11 KB |        0.45 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Mama** | **7,124.2 μs** | **220.29 μs** | **145.71 μs** |  **1.00** |    **0.03** | **1596.05 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Mama | 1,245.2 μs |  29.57 μs |  17.60 μs |  0.17 |    0.00 |  653.91 KB |        0.41 |
