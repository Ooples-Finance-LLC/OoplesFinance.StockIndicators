```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetStc** |   **679.3 μs** |  **33.61 μs** | **22.23 μs** |  **1.00** |    **0.04** |  **108.68 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetStc |   145.5 μs |  13.40 μs |  7.97 μs |  0.21 |    0.01 |  559.78 KB |        5.15 |
|            |       |                |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetStc** | **6,657.8 μs** |  **43.23 μs** | **25.72 μs** |  **1.00** |    **0.01** | **1040.02 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetStc | 1,518.7 μs | 102.86 μs | 61.21 μs |  0.23 |    0.01 |  5794.8 KB |        5.57 |
