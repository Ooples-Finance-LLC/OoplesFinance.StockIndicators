```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tSine [22]** |  **1,312.3 μs** | **127.30 μs** | **75.75 μs** |  **1.00** |    **0.08** |  **166.46 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tSine [22] |    573.4 μs |  29.75 μs | 19.67 μs |  0.44 |    0.03 |   74.23 KB |        0.45 |
|            |       |                      |             |           |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)tSine [22]** | **11,728.8 μs** |  **64.21 μs** | **33.58 μs** |  **1.00** |    **0.00** | **1598.77 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tSine [22] |  5,942.8 μs |  28.13 μs | 16.74 μs |  0.51 |    0.00 |  654.36 KB |        0.41 |
