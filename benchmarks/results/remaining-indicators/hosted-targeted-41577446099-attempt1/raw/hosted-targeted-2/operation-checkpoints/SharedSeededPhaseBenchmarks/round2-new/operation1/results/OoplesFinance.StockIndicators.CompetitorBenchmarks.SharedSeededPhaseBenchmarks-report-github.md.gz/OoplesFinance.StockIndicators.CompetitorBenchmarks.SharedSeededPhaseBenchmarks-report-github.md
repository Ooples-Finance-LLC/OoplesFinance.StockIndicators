```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |-----------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetMama** | **1000**  |   **636.1 μs** |   **4.57 μs** |   **2.39 μs** |  **5.07** |    **0.02** |        **-** |        **-** |        **-** |   **82.61 KB** |        **0.43** |
| BuilderLatestOnly | Skender.GetMama | 1000  |   634.2 μs |   5.57 μs |   3.31 μs |  5.05 |    0.03 |        - |        - |        - |   35.02 KB |        0.18 |
| NativeSingle      | Skender.GetMama | 1000  |   125.6 μs |   0.67 μs |   0.35 μs |  1.00 |    0.00 |  11.7188 |   1.9531 |        - |  192.06 KB |        1.00 |
| NativeParallel    | Skender.GetMama | 1000  |   192.4 μs |   8.70 μs |   5.75 μs |  1.53 |    0.04 |  31.2500 |  10.7422 |        - |  489.37 KB |        2.55 |
|                   |                 |       |            |           |           |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetMama** | **10000** | **6,220.8 μs** |  **34.49 μs** |  **18.04 μs** |  **4.24** |    **0.09** |  **31.2500** |        **-** |        **-** |  **786.33 KB** |        **0.41** |
| BuilderLatestOnly | Skender.GetMama | 10000 | 6,255.5 μs | 205.91 μs | 136.20 μs |  4.26 |    0.13 |        - |        - |        - |  316.51 KB |        0.17 |
| NativeSingle      | Skender.GetMama | 10000 | 1,468.3 μs |  50.16 μs |  33.18 μs |  1.00 |    0.03 | 179.6875 | 140.6250 |  85.9375 | 1915.61 KB |        1.00 |
| NativeParallel    | Skender.GetMama | 10000 | 2,285.9 μs | 158.05 μs | 104.54 μs |  1.56 |    0.08 | 406.2500 | 328.1250 | 140.6250 | 4867.54 KB |        2.54 |
