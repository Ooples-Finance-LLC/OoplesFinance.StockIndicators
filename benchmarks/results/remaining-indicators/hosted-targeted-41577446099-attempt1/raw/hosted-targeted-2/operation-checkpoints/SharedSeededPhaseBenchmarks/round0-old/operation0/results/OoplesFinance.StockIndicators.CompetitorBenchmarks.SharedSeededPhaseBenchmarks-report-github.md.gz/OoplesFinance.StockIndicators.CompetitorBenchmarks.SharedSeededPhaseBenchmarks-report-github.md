```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Median    | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|----------:|----------:|
| **BuilderFull**       | **QuanTAlib.Mama** | **1000**  |  **3.762 ms** | **2.7462 ms** | **1.8165 ms** |  **5.016 ms** |  **82.75 KB** |
| BuilderLatestOnly | QuanTAlib.Mama | 1000  |  1.313 ms | 0.0409 ms | 0.0270 ms |  1.298 ms |  35.06 KB |
| **BuilderFull**       | **QuanTAlib.Mama** | **10000** | **12.750 ms** | **0.0636 ms** | **0.0421 ms** | **12.755 ms** | **787.08 KB** |
| BuilderLatestOnly | QuanTAlib.Mama | 10000 | 12.871 ms | 0.0557 ms | 0.0291 ms | 12.867 ms | 317.27 KB |
