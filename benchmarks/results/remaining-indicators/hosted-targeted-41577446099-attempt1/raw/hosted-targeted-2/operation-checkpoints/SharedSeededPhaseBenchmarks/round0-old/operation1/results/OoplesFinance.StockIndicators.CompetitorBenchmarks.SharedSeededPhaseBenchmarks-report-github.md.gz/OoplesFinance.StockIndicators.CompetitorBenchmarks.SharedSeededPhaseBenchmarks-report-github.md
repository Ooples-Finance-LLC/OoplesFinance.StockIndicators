```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |---------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Skender.GetMama** | **1000**  |  **3.047 ms** | **1.2269 ms** | **0.8115 ms** |  **82.75 KB** |
| BuilderLatestOnly | Skender.GetMama | 1000  |  1.505 ms | 0.0265 ms | 0.0175 ms |  35.06 KB |
| **BuilderFull**       | **Skender.GetMama** | **10000** | **14.608 ms** | **0.1492 ms** | **0.0987 ms** | **787.18 KB** |
| BuilderLatestOnly | Skender.GetMama | 10000 | 14.496 ms | 0.0593 ms | 0.0310 ms | 317.45 KB |
