```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Mama** | **1000**  |   **603.4 μs** |  **3.59 μs** |  **1.88 μs** |       **-** |  **82.61 KB** |
| BuilderLatestOnly | QuanTAlib.Mama | 1000  |   615.2 μs |  3.94 μs |  2.06 μs |       - |  35.02 KB |
| **BuilderFull**       | **QuanTAlib.Mama** | **10000** | **5,994.7 μs** | **35.32 μs** | **21.02 μs** | **31.2500** | **786.33 KB** |
| BuilderLatestOnly | QuanTAlib.Mama | 10000 | 5,941.4 μs | 72.69 μs | 43.25 μs |       - |  316.5 KB |
