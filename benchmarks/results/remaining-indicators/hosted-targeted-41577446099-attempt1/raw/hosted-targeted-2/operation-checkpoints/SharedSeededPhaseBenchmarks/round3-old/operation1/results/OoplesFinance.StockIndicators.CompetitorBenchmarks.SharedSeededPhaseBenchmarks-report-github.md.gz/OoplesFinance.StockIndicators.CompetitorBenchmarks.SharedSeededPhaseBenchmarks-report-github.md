```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |---------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Skender.GetMama** | **1000**  |  **3.464 ms** | **0.6140 ms** | **0.4061 ms** |  **82.75 KB** |
| BuilderLatestOnly | Skender.GetMama | 1000  |  1.433 ms | 0.0109 ms | 0.0065 ms |  35.05 KB |
| **BuilderFull**       | **Skender.GetMama** | **10000** | **13.974 ms** | **0.0803 ms** | **0.0478 ms** | **787.11 KB** |
| BuilderLatestOnly | Skender.GetMama | 10000 | 14.000 ms | 0.0277 ms | 0.0145 ms | 317.27 KB |
