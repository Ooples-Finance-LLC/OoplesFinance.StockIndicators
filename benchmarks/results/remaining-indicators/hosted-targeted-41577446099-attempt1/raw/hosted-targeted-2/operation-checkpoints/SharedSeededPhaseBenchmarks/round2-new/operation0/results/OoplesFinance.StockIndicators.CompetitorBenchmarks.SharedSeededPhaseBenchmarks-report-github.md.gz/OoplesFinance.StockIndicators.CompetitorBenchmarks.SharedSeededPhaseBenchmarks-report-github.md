```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Ratio | RatioSD | Gen0    | Gen1    | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |-----------:|---------:|---------:|------:|--------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Mama** | **1000**  |   **614.9 μs** |  **4.05 μs** |  **2.12 μs** |  **2.25** |    **0.01** |       **-** |       **-** |       **-** |   **82.57 KB** |        **1.47** |
| BuilderLatestOnly | QuanTAlib.Mama | 1000  |   613.0 μs |  4.14 μs |  2.74 μs |  2.25 |    0.01 |       - |       - |       - |   35.02 KB |        0.62 |
| NativeSingle      | QuanTAlib.Mama | 1000  |   273.0 μs |  1.17 μs |  0.61 μs |  1.00 |    0.00 |  1.9531 |       - |       - |   56.23 KB |        1.00 |
| NativeParallel    | QuanTAlib.Mama | 1000  |   368.8 μs | 13.90 μs |  7.27 μs |  1.35 |    0.03 |  3.9063 |       - |       - |  119.62 KB |        2.13 |
|                   |                |       |            |          |          |       |         |         |         |         |            |             |
| **BuilderFull**       | **QuanTAlib.Mama** | **10000** | **6,044.7 μs** | **11.78 μs** |  **6.16 μs** |  **2.17** |    **0.01** | **31.2500** |       **-** |       **-** |   **786.3 KB** |        **1.43** |
| BuilderLatestOnly | QuanTAlib.Mama | 10000 | 6,109.5 μs | 24.90 μs | 16.47 μs |  2.20 |    0.01 |       - |       - |       - |  316.77 KB |        0.58 |
| NativeSingle      | QuanTAlib.Mama | 10000 | 2,782.8 μs | 21.15 μs | 12.59 μs |  1.00 |    0.01 | 46.8750 | 31.2500 | 31.2500 |  548.81 KB |        1.00 |
| NativeParallel    | QuanTAlib.Mama | 10000 | 3,564.2 μs | 68.81 μs | 35.99 μs |  1.28 |    0.01 | 31.2500 |       - |       - | 1139.37 KB |        2.08 |
