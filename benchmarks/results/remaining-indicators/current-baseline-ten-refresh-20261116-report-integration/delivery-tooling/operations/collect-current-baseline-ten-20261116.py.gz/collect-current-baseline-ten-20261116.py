"""Collect one frozen 100-case baseline run; archive ZIPs on Z, never import reports."""
import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import zipfile

OPS = Path(r'C:\Users\cheat\source\stock-indicators-operations')
BASELINE = OPS/'active-performance-evidence/hosted-runs/43880487485/inputs'
ARCHIVES = Path(r'Z:\StockIndicators-Archives\hosted-runs-20261116')
NETWORK_OUTPUTS = Path(r'Z:\StockIndicators-Archives\active-performance-evidence\hosted-runs')
REMOTE = 'Ooples-Finance-LLC/OoplesFinance.StockIndicators'
PLAN = 'benchmarks/plans/hosted-current-baseline-ten-refresh-20261116.json'
APPROVED_RUN = '43949686899'
APPROVED_HEAD = '2a1737f30e5e1164189d0209b39ea46bf38c1239'
TEXT = {'.json', '.log', '.txt', '.csv', '.md', '.html', '.xml', '.trx', '.gz', '.py', '.ps1'}
RESERVED = {'CON', 'PRN', 'AUX', 'NUL', 'CONIN$', 'CONOUT$',
    *(f'COM{i}' for i in range(1, 10)), *(f'LPT{i}' for i in range(1, 10)),
    *(p+n for p in ('COM', 'LPT') for n in ('\u00b9', '\u00b2', '\u00b3'))}


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, data):
    Path(path).write_bytes((json.dumps(data, indent=2, allow_nan=False)+'\n').encode())


def members(package):
    result, aliases = {}, set()
    for info in package.infolist():
        assert info.orig_filename == info.filename, 'ZIP member spelling was normalized'
        name = info.filename.rstrip('/')
        parts = PurePosixPath(name)
        assert name and not parts.is_absolute() and '\\' not in name and '\0' not in name
        assert all(p not in ('', '.', '..') and p.rstrip(' .') == p
            and not any(c in p for c in ':<>"|?*') and p.split('.')[0].rstrip(' ').upper() not in RESERVED
            for p in name.split('/')), name
        assert not stat.S_ISLNK(info.external_attr >> 16), 'ZIP symlink'
        if info.is_dir():
            continue
        assert name.casefold() not in aliases, 'Duplicate/case-aliased ZIP member'
        aliases.add(name.casefold()); result[name] = info
    return result


def target(folder, name):
    path = (folder/name).resolve()
    assert path.is_relative_to(folder.resolve()) and path != folder.resolve()
    return path


def manifest(folder):
    return {p.relative_to(folder).as_posix(): digest(p) for p in folder.rglob('*') if p.is_file()}


def runtime_files(proof):
    return {'common/'+p: sha for p, sha in proof['common_manifest'].items()} | {
        'production/'+label+'.dll': sha for label, sha in proof['production_sha256'].items()}


def protected_snapshot(baseline):
    return {section+'/'+name: sha for section in ('common', 'production')
            for name, sha in manifest(baseline/section).items()}


def reserve(path, added_bytes=0):
    existing = path
    while not existing.exists():
        assert existing.parent != existing, 'Output drive/root unavailable'
        existing = existing.parent
    assert shutil.disk_usage(existing).free > 2*1024**3 + added_bytes, 'Below output-drive evidence reserve'


def same_volume(source, destination):
    return source.resolve().drive.casefold() == destination.resolve().drive.casefold()


def link_verified(source, destination, sha):
    assert source.is_file() and digest(source) == sha
    assert not destination.exists(), 'Never overwrite a runtime target'
    destination.parent.mkdir(parents=True, exist_ok=True)
    if same_volume(source, destination):
        os.link(source, destination)
        mode = 'hardlink'
    else:
        reserve(destination.parent, source.stat().st_size)
        with source.open('rb') as incoming, destination.open('xb') as outgoing:
            shutil.copyfileobj(incoming, outgoing, 1024*1024)
        mode = 'verified-copy'
    assert digest(destination) == sha
    return mode


def extract_text(package, entries, names, folder):
    records = []
    for name in sorted(names):
        assert Path(name).suffix.lower() in TEXT, 'Unexpected non-text/evidence member: '+name
        path = target(folder, name)
        assert not path.exists()
        path.parent.mkdir(parents=True, exist_ok=True)
        reserve(folder, entries[name].file_size)
        with package.open(entries[name]) as source, path.open('xb') as out:
            shutil.copyfileobj(source, out, 1024*1024)
        records.append(dict(path=name, sha256=digest(path), bytes=path.stat().st_size))
    return records


def reconstruct_inputs(archive, folder, baseline, preflight_files):
    original = json.loads((baseline/'provenance.json').read_text())
    before = protected_snapshot(baseline)
    assert before == runtime_files(original), 'Protected baseline runtime changed'
    by_sha = {}
    for name, sha in before.items():
        by_sha.setdefault(sha, baseline/name)
    with zipfile.ZipFile(archive) as package:
        entries = members(package)
        assert 'provenance.json' in entries, 'Input ZIP must have flat root contents'
        proof = json.loads(package.read(entries['provenance.json']))
        expected = runtime_files(proof)
        assert proof['common_manifest'] == original['common_manifest']
        assert proof['production_sha256'] == original['production_sha256']
        actual = {n for n in entries if n.startswith(('common/', 'production/'))}
        assert actual == set(expected), 'Unexpected/missing runtime ZIP member'
        # Authenticate every archived runtime byte before materializing any runtime.
        for name, sha in expected.items():
            assert re.fullmatch('[a-f0-9]{64}', sha)
            with package.open(entries[name]) as stream:
                assert hashlib.file_digest(stream, 'sha256').hexdigest() == sha, name
            assert sha in by_sha, 'No verified protected baseline source for '+name
        metadata = {'provenance.json', 'origin-provenance.json', 'fixture-method-inventory.json'}
        metadata |= {'evidence/'+n for n in proof['evidence_manifest']}
        metadata |= {'consumer-preflight/'+n for n in preflight_files}
        assert set(entries) == set(expected) | metadata, 'Unexpected/missing input metadata'
        assert not folder.exists(); folder.mkdir(parents=True)
        selected = extract_text(package, entries, metadata, folder)
        modes = {link_verified(by_sha[sha], target(folder, name), sha) for name, sha in expected.items()}
    assert {n: digest(folder/n) for n in expected} == expected
    assert manifest(folder/'common') == proof['common_manifest']
    assert manifest(folder/'production') == {p+'.dll': sha for p, sha in proof['production_sha256'].items()}
    assert protected_snapshot(baseline) == before
    return before, selected, sorted(modes)


def extract_shard(archive, folder, index):
    with zipfile.ZipFile(archive) as package:
        entries = members(package)
        assert {'provenance.json', 'status.json'} <= set(entries), 'Shard ZIP must have flat root contents'
        proof = json.loads(package.read(entries['provenance.json']))
        assert proof['shard'] == index and proof['phase'] == 'baseline-refresh'
        assert not folder.exists(); folder.mkdir(parents=True)
        return extract_text(package, entries, set(entries), folder)


def verify_tooling(repo, head):
    def git(*args):
        return subprocess.check_output(['git', *args], cwd=repo)
    assert git('rev-parse', 'HEAD').decode().strip() == head
    assert not git('status', '--porcelain'), 'Tooling checkout changed'
    plan = repo/PLAN
    assert plan.read_bytes() == git('show', head+':'+PLAN), 'Frozen plan bytes changed'
    return digest(plan)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', required=True)
    parser.add_argument('--tooling-head', required=True)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    assert re.fullmatch(r'\d+', args.run) and re.fullmatch('[a-f0-9]{40}', args.tooling_head)
    assert args.run == APPROVED_RUN and args.tooling_head == APPROVED_HEAD, 'Only the approved frozen run may be collected'
    repo, out = args.repo.resolve(), args.out.resolve()
    assert any(out.is_relative_to(root.resolve()) and out != root.resolve() for root in (OPS, NETWORK_OUTPUTS))
    assert not out.exists()
    assert not out.is_relative_to(BASELINE) and not repo.is_relative_to(out)
    plan_sha = verify_tooling(repo, args.tooling_head)
    plan = json.loads((repo/PLAN).read_text())
    assert (plan['cases'], plan['decisions']) == (100, 20)
    reserve(out)
    def api(path):
        return json.loads(subprocess.check_output(['gh', 'api', 'repos/'+REMOTE+path]))
    run = api('/actions/runs/'+args.run)
    assert run['id'] == int(args.run) and run['head_sha'] == args.tooling_head
    assert (run['status'], run['conclusion']) == ('completed', 'success')
    artifacts, page = [], 1
    while True:
        response = api(f'/actions/runs/{args.run}/artifacts?per_page=100&page={page}')
        artifacts.extend(response['artifacts'])
        if len(artifacts) >= response['total_count']: break
        assert response['artifacts']; page += 1
    names = ['current-baseline-ten-inputs'] + [f'current-baseline-ten-shard-{i}' for i in range(10)] + ['current-baseline-ten-summary']
    assert ARCHIVES.is_dir(), 'Z: archive volume unavailable; never fall back to bulky C: ZIPs'
    archive_root = (ARCHIVES/args.run).resolve()
    assert archive_root.is_relative_to(ARCHIVES.resolve())
    archive_root.mkdir(parents=True, exist_ok=True)
    archives, receipts = {}, []
    for name in names:
        matches = [a for a in artifacts if a['name'] == name and not a['expired']]
        assert len(matches) == 1, 'Missing/duplicate artifact '+name
        item = matches[0]
        path = archive_root/f"{name}-attempt{run['run_attempt']}-artifact{item['id']}.zip"
        sidecar = path.with_suffix('.receipt.json')
        if path.exists():
            old = json.loads(sidecar.read_text())
            assert old['artifact']['id'] == item['id'] and old['run_id'] == args.run
            assert old['archive_sha256'] == digest(path)
        else:
            temporary = path.with_suffix('.zip.download')
            with temporary.open('xb') as stream:
                subprocess.run(['gh', 'api', f"repos/{REMOTE}/actions/artifacts/{item['id']}/zip"], stdout=stream, check=True)
            temporary.replace(path)
        sha = digest(path)
        if item.get('digest'): assert item['digest'] == 'sha256:'+sha
        receipt = dict(run_id=args.run, run_attempt=run['run_attempt'], tooling_head=args.tooling_head,
            plan_sha256=plan_sha, artifact=item, archive=str(path), archive_sha256=sha)
        write(sidecar, receipt); archives[name] = path; receipts.append(receipt)
    out.mkdir(parents=True)
    before, selected, materialization = reconstruct_inputs(archives[names[0]], out/'inputs', BASELINE, plan['consumer_preflight']['files'])
    for index in range(10):
        selected += [dict(shard=index, **r) for r in extract_shard(archives[f'current-baseline-ten-shard-{index}'], out/'evidence'/f'shard{index}', index)]
    with zipfile.ZipFile(archives['current-baseline-ten-summary']) as package:
        entries = members(package)
        assert set(entries) == {'verified-current-baseline-ten.json'}
        extract_text(package, entries, set(entries), out/'hosted-summary')
    os.environ['HOSTED_TIMING_PLAN'] = str(repo/PLAN)
    sys.path.insert(0, str(repo/'scripts'))
    p = importlib.import_module('hosted_timing.pipeline')
    refresh = importlib.import_module('hosted_timing.current_baseline_ten_refresh')
    assert p.REPO.resolve() == repo and p.PLAN.resolve() == (repo/PLAN).resolve()
    refresh.validate_scope(p.read(p.PLAN))
    proof = p.verify_inputs(out/'inputs')
    assert proof['run_id'] == args.run and proof['workflow_head'] == args.tooling_head
    assert proof['plan_sha256'] == plan_sha
    result = refresh.collect(out/'evidence')
    hosted = p.read(out/'hosted-summary/verified-current-baseline-ten.json')
    assert result == hosted, 'Independent collection differs from hosted summary'
    assert (result['case_count'], result['decision_count']) == (100, 20)
    assert result['baseline_refresh_verified'] and not result['accepted'] and not result['production_qualification'] and not result['report_imported']
    assert set(result['admitted_pairs']) | {r['pair'] for r in result['quarantined_pairs']} == set(refresh.PAIRS)
    assert protected_snapshot(BASELINE) == before
    assert verify_tooling(repo, args.tooling_head) == plan_sha
    reserve(out)
    write(out/'independently-collected.json', result)
    write(out/'collection-receipt.json', dict(status='verified', run_id=args.run, tooling_head=args.tooling_head,
        plan_sha256=plan_sha, collector_sha256=digest(Path(__file__)), artifacts=receipts,
        input_provenance_sha256=digest(out/'inputs/provenance.json'), selected_files=selected,
        local_hosted_collection_equal=True, protected_baseline_unchanged=True,
        runtime_materialization=materialization,
        runtime_authentication='Protected source and ZIP runtime bytes independently hashed before materialization; all destination hashes verified',
        cases=100, decisions=20, admitted_pairs=result['admitted_pairs'], quarantined_pairs=result['quarantined_pairs'],
        report_imported=False, production_qualification=False, source_imported=False, policy_changed=False))
    print(json.dumps(dict(run=args.run, cases=100, decisions=20, admitted=result['admitted_pairs'], quarantined=result['quarantined_pairs'])), flush=True)


if __name__ == '__main__':
    main()
