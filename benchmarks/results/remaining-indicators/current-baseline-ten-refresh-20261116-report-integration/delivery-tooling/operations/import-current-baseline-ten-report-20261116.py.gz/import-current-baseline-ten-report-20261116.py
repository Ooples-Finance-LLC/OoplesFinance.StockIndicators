from pathlib import Path
import datetime,hashlib,json,re,sys
EXPECTED_RUN = '43949686899'
EXPECTED_URL = 'https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/' + EXPECTED_RUN
CANONICAL = '5be1a81d02ad01393f3fa8ede764e914252d0e96'
HARNESS = '9a45372530e49718b01b6524f9a0db993514e1e8'
REPORT_BEFORE_SHA = '2e454a8bd0f51b83e827c7d44ed47d1c1597faa3bdc5e53b5c0afbb848752311'
TEN_PAIRS = {'QuanTAlib.Smma','TaLib.Candles.Stalled','TaLib.Candles.ThreeStarsInSouth',
    'TaLib.Candles.SeparatingLines','TaLib.Candles.UpsideGapTwoCrows','Skender.GetDynamic',
    'QuanTAlib.Qema','QuanTAlib.Skew','TaLib.Candles.LongLeggedDoji','Skender.GetSmma'}


def admitted_keys(data, stage, measurement):
    assert str(measurement['run_id']) == str(stage['run_id']) == EXPECTED_RUN
    assert measurement['measurement_url'] == EXPECTED_URL and measurement['source_sha'] == CANONICAL
    assert stage['before_sha256'] == REPORT_BEFORE_SHA
    records = [row for row in data['evidence']['harnessBaselineRefreshes'] if str(row['run_id']) == EXPECTED_RUN]
    assert len(records) == 1
    record = records[0]
    assert record['url'] == EXPECTED_URL and record['production_source_sha'] == CANONICAL
    assert record['benchmark_source_sha'] == HARNESS and not record['harness_changed']
    assert record['refresh_reason'] == 'current-source-remeasurement' and record['admission_is_not_equivalence']
    assert not record['production_optimization'] and (record['cases'],record['same_binary_comparisons']) == (100,20)
    assert len(record['measured_pairs']) == 10 and set(record['measured_pairs']) == TEN_PAIRS
    pairs = set(record['admitted_pairs'])
    quarantined = {row['pair'] for row in record['quarantined_pairs']}
    assert pairs and len(pairs) == len(record['admitted_pairs'])
    assert len(quarantined) == len(record['quarantined_pairs'])
    assert not pairs & quarantined and pairs | quarantined == TEN_PAIRS and set(record['pairs']) == pairs
    for row in record['quarantined_pairs']:
        assert set(row['sizes']) == {'1000','10000'}
        assert any(verdict != 'inconclusive' for verdict in row['sizes'].values())
    keys = {(pair,bars) for pair in pairs for bars in (1000,10000)}
    assert stage['changed_baseline_rows'] == len(keys) and stage['unchanged_baseline_rows'] == 802-len(keys)
    assert all(stage.get(key,0) == 0 for key in ('changed_builder_slots','added_builder_slots','replaced_builder_slots'))
    assert len(stage['builder_rows']) == 1544
    index = {(row['pair'],row['bars']):row for row in data['rows']}
    assert len(index) == len(data['rows']) == 802 and len({row['pair'] for row in data['rows']}) == 401
    tagged = {(row['pair'],row['bars']) for row in data['rows']
        if str(row.get('measurement_run_id')) == EXPECTED_RUN or row.get('measurement_run_url') == EXPECTED_URL}
    assert tagged == keys
    for key in keys:
        row = index[key]
        assert str(row['measurement_run_id']) == EXPECTED_RUN and row['measurement_run_url'] == EXPECTED_URL
        assert row['source_sha'] == row['canonical_gpu_source_sha'] == CANONICAL
        assert row['benchmark_source_sha'] == HARNESS and row['same_binary_verdict'] == 'inconclusive'
        assert row['measurement_kind'] == 'harness-baseline-refresh' and not row['production_optimization']
    return pairs, keys


assert len(sys.argv)==2, 'Usage: import-current-baseline-ten-report OUTPUT_DIRECTORY'
out=Path(sys.argv[1]).resolve()
measurement=json.loads((out/'measurement.json').read_text())
run=str(measurement['run_id']);assert run == EXPECTED_RUN
live=Path('C:/Users/cheat/Documents/OoplesFinance-Reports/competitor-performance.html')
stage=json.loads((out/'staged.json').read_text()); verified=json.loads((out/'browser-verification.json').read_text())
candidate=out/'candidate.html'
assert verified['comparisons']==verified['displayed_table_comparisons']==verified['exported_comparisons']==802
assert not verified['javascript_errors'] and verified['run_id']==run and verified['hosted_provenance_verified']
assert hashlib.sha256(candidate.read_bytes()).hexdigest()==stage['candidate_sha256']==verified['report_sha256']
assert hashlib.sha256(live.read_bytes()).hexdigest()==stage['before_sha256']
def rows(p):return json.loads(re.search(r'<script[^>]*id="dataset"[^>]*>(.*?)</script>',p.read_text(encoding='utf-8'),re.S)[1])['rows']
before=rows(live);after=rows(candidate)
after_data=json.loads(re.search(r'<script[^>]*id="dataset"[^>]*>(.*?)</script>',candidate.read_text(encoding='utf-8'),re.S)[1])
pairs,updated_keys=admitted_keys(after_data,stage,measurement)
assert len(before)==len(after)==802 and len({(r['pair'],r['bars']) for r in before})==802
assert set(verified['admitted_pairs'])==pairs
assert {(key[0],int(key[1])) for key in verified['updated_baseline_keys']}==updated_keys
assert verified['unchanged_baseline_rows']==802-len(updated_keys) and verified['unchanged_builder_comparisons']==1544
same=0
for a,b in zip(before,after,strict=True):
    assert (a['pair'],a['bars'])==(b['pair'],b['bars'])
    if (a['pair'],a['bars']) not in updated_keys:assert a==b;same+=1
    else:assert a!=b
assert same==stage['unchanged_baseline_rows']
def builder(p):return json.loads(re.search(r'<script[^>]*id="current-competitor-data"[^>]*>(.*?)</script>',p.read_text(encoding='utf-8'),re.S)[1])
def index(d):return {(r['pair'],r['bars'],r['mode']):{**r,'run_id':str(receipt['run_id']),'source_sha':receipt['source_sha'],'measurement_url':receipt.get('measurement_url','https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/'+str(receipt['run_id']))} for receipt in d['receipts'] for r in receipt['comparisons']}
assert builder(live)==builder(candidate)
a,b=index(builder(live)),index(builder(candidate));assert a==b and len(a)==len(b)==1544
assert len({(r['pair'],r['bars'],r['mode']) for r in stage['builder_rows']})==1544
assert list(sorted(b.values(),key=lambda r:(r['pair'],r['bars'],r['mode'])))==list(sorted(stage['builder_rows'],key=lambda r:(r['pair'],r['bars'],r['mode'])))
temporary=live.with_suffix('.current-baseline-ten.tmp');assert not temporary.exists()
assert hashlib.sha256(live.read_bytes()).hexdigest()==stage['before_sha256']
temporary.write_bytes(candidate.read_bytes());temporary.replace(live)
assert hashlib.sha256(live.read_bytes()).hexdigest()==stage['candidate_sha256']
(out/'imported.json').write_text(json.dumps({**stage,'unchanged_rows':same,'run_id':run,'imported_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'browser_verified':True},indent=2))
print('Updated actual measured rows; verified all802 comparisons and preserved',same,'other rows:',stage['candidate_sha256'])
