"""Small integrity fixtures; no network, production runtimes or measurements."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import tempfile
import unittest
from unittest import mock
import zipfile

spec = importlib.util.spec_from_file_location('baseline_collector', Path(__file__).with_name('collect-current-baseline-ten-20261116.py'))
c = importlib.util.module_from_spec(spec); spec.loader.exec_module(c)


def encoded(value): return (json.dumps(value)+'\n').encode()
def sha(data): return hashlib.sha256(data).hexdigest()


class CollectorIntegrityTests(unittest.TestCase):
    def baseline(self, root):
        folder = root/'protected'
        files = {'common/dependency.dll': b'dependency', 'common/OoplesFinance.StockIndicators.dll': b'variant',
            'production/old.dll': b'canonical', 'production/successor.dll': b'canonical', 'production/variants.dll': b'variant'}
        for name, data in files.items():
            path = folder/name; path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(data)
        proof = dict(common_manifest={n[7:]:sha(data) for n,data in files.items() if n.startswith('common/')},
            production_sha256={Path(n).stem:sha(data) for n,data in files.items() if n.startswith('production/')}, evidence_manifest={})
        (folder/'provenance.json').write_bytes(encoded(proof))
        return folder, proof, files

    def archive(self, root, files):
        path = root/'artifact.zip'
        with zipfile.ZipFile(path, 'w') as package:
            for name, data in files.items():
                item = zipfile.ZipInfo('placeholder')
                # ZipInfo's Windows constructor normalizes backslashes; retain the
                # literal archive spelling so the rejection fixture tests it.
                item.filename = name
                package.writestr(item, data)
        return path

    def inputs(self, proof, files):
        return files | {'provenance.json':encoded(proof), 'origin-provenance.json':encoded(proof),
            'fixture-method-inventory.json':encoded({})}

    def test_runtime_is_linked_only_after_all_zip_bytes_match_and_sources_stay_unchanged(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); base, proof, files = self.baseline(root)
            before = c.protected_snapshot(base)
            archive = self.archive(root, self.inputs(proof, files)); out = root/'result/inputs'
            observed, _, modes = c.reconstruct_inputs(archive, out, base, {})
            self.assertEqual(['hardlink'], modes)
            self.assertEqual(before, observed); self.assertEqual(before, c.protected_snapshot(base))
            self.assertEqual(c.runtime_files(proof), c.protected_snapshot(out))
            self.assertTrue(os.path.samefile(base/'common/dependency.dll', out/'common/dependency.dll'))
            self.assertTrue(os.path.samefile(out/'production/old.dll', out/'production/successor.dll'))
            copied = root/'copied/inputs'
            with mock.patch.object(c, 'same_volume', return_value=False):
                copied_before, _, copy_modes = c.reconstruct_inputs(archive, copied, base, {})
            self.assertEqual(['verified-copy'], copy_modes)
            self.assertEqual(before, copied_before)
            self.assertEqual(before, c.protected_snapshot(base))
            self.assertEqual(c.runtime_files(proof), c.protected_snapshot(copied))
            self.assertFalse(os.path.samefile(base/'common/dependency.dll', copied/'common/dependency.dll'))
            with mock.patch.object(c.Path, 'exists', return_value=False):
                with self.assertRaisesRegex(AssertionError, 'drive/root unavailable'):
                    c.reserve(Path('Q:/unavailable/output'))
            with mock.patch.object(c.shutil, 'disk_usage', return_value=mock.Mock(free=2*1024**3)):
                with self.assertRaisesRegex(AssertionError, 'output-drive evidence reserve'):
                    c.reserve(copied)

    def test_corrupt_archived_runtime_is_rejected_before_any_links(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); base, proof, files = self.baseline(root)
            payload = self.inputs(proof, files); payload['production/successor.dll'] = b'other candidate'
            out = root/'inputs'
            with self.assertRaises(AssertionError): c.reconstruct_inputs(self.archive(root, payload), out, base, {})
            self.assertFalse(out.exists()); self.assertEqual(b'canonical', (base/'production/successor.dll').read_bytes())

    def test_extra_or_missing_runtime_member_is_not_a_complete_composition(self):
        for extra in (False, True):
            with self.subTest(extra=extra), tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary); base, proof, files = self.baseline(root); payload = self.inputs(proof, files)
                if extra: payload['common/unlisted.dll'] = b'unlisted'
                else: del payload['common/dependency.dll']
                with self.assertRaises(AssertionError): c.reconstruct_inputs(self.archive(root, payload), root/'inputs', base, {})
                self.assertFalse((root/'inputs').exists())

    def test_existing_hardlink_destination_is_never_overwritten(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); source = root/'source'; source.write_bytes(b'protected')
            destination = root/'destination'; os.link(source, destination)
            with self.assertRaises(AssertionError): c.link_verified(source, destination, sha(b'protected'))
            self.assertEqual(b'protected', source.read_bytes()); self.assertTrue(os.path.samefile(source, destination))

    def test_flat_shard_contents_receive_exactly_one_local_shard_directory(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); out = root/'evidence/shard2'
            data = {'provenance.json':encoded(dict(shard=2, phase='baseline-refresh')), 'status.json':encoded({}),
                'operation-checkpoints/round2/report.json':encoded({'native':True})}
            c.extract_shard(self.archive(root, data), out, 2)
            self.assertTrue((out/'provenance.json').is_file()); self.assertFalse((out/'shard2').exists())
            self.assertTrue((out/'operation-checkpoints/round2/report.json').is_file())

    def test_outer_shard_folder_or_wrong_shard_cannot_be_collected(self):
        for outer in (False, True):
            with self.subTest(outer=outer), tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary); prefix = 'shard2/' if outer else ''
                data = {prefix+'provenance.json':encoded(dict(shard=3, phase='baseline-refresh')), prefix+'status.json':encoded({})}
                with self.assertRaises(AssertionError): c.extract_shard(self.archive(root, data), root/'out', 2)
                self.assertFalse((root/'out').exists())

    def test_unsafe_windows_names_and_zip_aliases_are_rejected(self):
        for name in ('../escape.json', '/absolute.json', 'folder\\file.json', 'CON.json', 'CON .txt', 'file:stream.json', 'file. /x.json'):
            with self.subTest(name=name), tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary); path = self.archive(root, {name:b'{}'})
                with zipfile.ZipFile(path) as package, self.assertRaises(AssertionError): c.members(package)
        with tempfile.TemporaryDirectory() as temporary:
            path = self.archive(Path(temporary), {'A.json':b'{}','a.json':b'{}'})
            with zipfile.ZipFile(path) as package, self.assertRaises(AssertionError): c.members(package)

    def test_zip_symlink_is_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary)/'link.zip'; item = zipfile.ZipInfo('proof.json')
            item.create_system = 3; item.external_attr = (stat.S_IFLNK|0o777)<<16
            with zipfile.ZipFile(path, 'w') as package: package.writestr(item, '../target')
            with zipfile.ZipFile(path) as package, self.assertRaises(AssertionError): c.members(package)


if __name__ == '__main__': unittest.main()
