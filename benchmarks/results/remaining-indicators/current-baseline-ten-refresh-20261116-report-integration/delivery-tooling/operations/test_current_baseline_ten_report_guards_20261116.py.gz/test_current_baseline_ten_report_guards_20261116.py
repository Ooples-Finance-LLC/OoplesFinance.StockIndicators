"""Exercise only pure AST guards; never import or execute report helper bodies."""
import ast
import copy
from pathlib import Path
import unittest

OPS = Path(__file__).parent
VERIFIER = OPS/'verify-current-baseline-ten-report-20261116.py'
IMPORTER = OPS/'import-current-baseline-ten-report-20261116.py'
CONSTANTS = {'EXPECTED_RUN','EXPECTED_URL','CANONICAL','HARNESS','REPORT_BEFORE_SHA','TEN_PAIRS'}


def tree(path):
    return ast.parse(path.read_text(encoding='utf-8'), filename=str(path))


def load_guard(path):
    selected = [node for node in tree(path).body if
        isinstance(node,ast.FunctionDef) and node.name == 'admitted_keys' or
        isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in CONSTANTS for t in node.targets)]
    namespace = {}
    exec(compile(ast.Module(body=selected,type_ignores=[]),str(path),'exec'),namespace)
    return namespace


def fixture(ns):
    pairs = sorted(ns['TEN_PAIRS']) + ['Unchanged.'+str(i) for i in range(391)]
    target = 'QuanTAlib.Smma'
    rows = [dict(pair=pair,bars=size,source_sha=ns['CANONICAL'],measurement_run_id='earlier-run',
        measurement_run_url='https://example.invalid/earlier') for pair in pairs for size in (1000,10000)]
    for row in rows:
        if row['pair'] == target:
            row.update(measurement_run_id=ns['EXPECTED_RUN'],measurement_run_url=ns['EXPECTED_URL'],
                canonical_gpu_source_sha=ns['CANONICAL'],benchmark_source_sha=ns['HARNESS'],
                same_binary_verdict='inconclusive',measurement_kind='harness-baseline-refresh',production_optimization=False)
    record = dict(run_id=ns['EXPECTED_RUN'],url=ns['EXPECTED_URL'],production_source_sha=ns['CANONICAL'],
        benchmark_source_sha=ns['HARNESS'],harness_changed=False,refresh_reason='current-source-remeasurement',
        admission_is_not_equivalence=True,production_optimization=False,cases=100,same_binary_comparisons=20,
        measured_pairs=sorted(ns['TEN_PAIRS']),admitted_pairs=[target],pairs=[target],
        quarantined_pairs=[dict(pair=pair,sizes={'1000':'faster','10000':'inconclusive'})
            for pair in sorted(ns['TEN_PAIRS']) if pair != target])
    data = dict(rows=rows,evidence=dict(harnessBaselineRefreshes=[dict(run_id='earlier-run'),record]))
    stage = dict(run_id=ns['EXPECTED_RUN'],before_sha256=ns['REPORT_BEFORE_SHA'],changed_baseline_rows=2,
        unchanged_baseline_rows=800,changed_builder_slots=0,added_builder_slots=0,replaced_builder_slots=0,
        builder_rows=[None]*1544)
    measurement = dict(run_id=ns['EXPECTED_RUN'],measurement_url=ns['EXPECTED_URL'],source_sha=ns['CANONICAL'])
    return data,stage,measurement


class CurrentBaselineReportGuardTests(unittest.TestCase):
    def test_both_clones_share_exact_guard_and_constant_definitions(self):
        guards = [next(n for n in tree(p).body if isinstance(n,ast.FunctionDef) and n.name=='admitted_keys') for p in (VERIFIER,IMPORTER)]
        self.assertEqual(ast.dump(guards[0],include_attributes=False),ast.dump(guards[1],include_attributes=False))
        left,right=load_guard(VERIFIER),load_guard(IMPORTER)
        self.assertEqual({k:left[k] for k in CONSTANTS},{k:right[k] for k in CONSTANTS})

    def test_older_rows_with_same_canonical_sha_do_not_expand_affected_keys(self):
        for path in (VERIFIER,IMPORTER):
            ns=load_guard(path);data,stage,measurement=fixture(ns)
            pairs,keys=ns['admitted_keys'](data,stage,measurement)
            self.assertEqual({'QuanTAlib.Smma'},pairs)
            self.assertEqual({('QuanTAlib.Smma',1000),('QuanTAlib.Smma',10000)},keys)
            self.assertEqual(802,sum(row['source_sha']==ns['CANONICAL'] for row in data['rows']))

    def test_quarantined_one_size_failure_retains_old_run_at_both_sizes(self):
        for path in (VERIFIER,IMPORTER):
            ns=load_guard(path);data,stage,measurement=fixture(ns)
            _,keys=ns['admitted_keys'](data,stage,measurement)
            old=[row for row in data['rows'] if row['pair']=='Skender.GetSmma']
            self.assertTrue(all((row['pair'],row['bars']) not in keys and row['measurement_run_id']=='earlier-run' for row in old))

    def test_zero_wrong_run_url_or_incomplete_admitted_size_is_rejected(self):
        for path in (VERIFIER,IMPORTER):
            for mutation in ('zero','measurement-run','stage-run','url','missing-size','quarantined-tag','duplicate-row','duplicate-record','mixed-verdict'):
                ns=load_guard(path);data,stage,measurement=fixture(ns)
                record=data['evidence']['harnessBaselineRefreshes'][-1]
                if mutation=='zero':record['admitted_pairs']=[]
                elif mutation=='measurement-run':measurement['run_id']='wrong-run'
                elif mutation=='stage-run':stage['run_id']='wrong-run'
                elif mutation=='url':measurement['measurement_url']='https://example.invalid/wrong'
                elif mutation=='duplicate-row':data['rows'][-1]=copy.deepcopy(data['rows'][-2])
                elif mutation=='duplicate-record':data['evidence']['harnessBaselineRefreshes'].append(copy.deepcopy(record))
                else:
                    if mutation=='quarantined-tag':row=next(row for row in data['rows'] if row['pair']=='Skender.GetSmma')
                    else:row=next(row for row in data['rows'] if row['pair']=='QuanTAlib.Smma' and row['bars']==10000)
                    if mutation=='missing-size':row.update(measurement_run_id='earlier-run',measurement_run_url='https://example.invalid/earlier')
                    elif mutation=='mixed-verdict':row['same_binary_verdict']='faster'
                    else:row.update(measurement_run_id=ns['EXPECTED_RUN'],measurement_run_url=ns['EXPECTED_URL'])
                with self.subTest(path=path.name,mutation=mutation),self.assertRaises(AssertionError):
                    ns['admitted_keys'](data,stage,measurement)

    def test_csv_guard_rejects_duplicate_or_missing_key_even_with_802_rows(self):
        parsed=tree(VERIFIER)
        assignment=next(n for n in ast.walk(parsed) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='exported_keys' for t in n.targets))
        assertion=next(n for n in ast.walk(parsed) if isinstance(n,ast.Assert) and any(isinstance(x,ast.Name) and x.id=='exported_keys' for x in ast.walk(n)))
        code=compile(ast.Module(body=[assignment,assertion],type_ignores=[]),str(VERIFIER),'exec')
        ns=load_guard(VERIFIER);data,_,_=fixture(ns)
        expected={(r['pair'],r['bars']):r for r in data['rows']}
        exported=[dict(pair=r['pair'],bars=str(r['bars'])) for r in data['rows']]
        exec(code,dict(exported=exported,expected=expected))
        exported[-1]=copy.deepcopy(exported[-2])
        with self.assertRaises(AssertionError):exec(code,dict(exported=exported,expected=expected))

    def test_deep_preservation_guards_reject_changes_outside_admitted_keys(self):
        assertions=[n for n in tree(VERIFIER).body if isinstance(n,ast.Assert)
            and {'before_rows','after_rows','updated_keys'} <= {x.id for x in ast.walk(n) if isinstance(x,ast.Name)}]
        self.assertEqual(2,len(assertions))
        code=compile(ast.Module(body=assertions,type_ignores=[]),str(VERIFIER),'exec')
        ns=load_guard(VERIFIER);data,stage,measurement=fixture(ns)
        _,keys=ns['admitted_keys'](data,stage,measurement)
        after={(r['pair'],r['bars']):r for r in data['rows']};before=copy.deepcopy(after)
        for key in keys:before[key]['measurement_run_id']='earlier-run'
        exec(code,dict(before_rows=before,after_rows=after,updated_keys=keys))
        outside=next(key for key in after if key not in keys);after[outside]['ooples_mean_ns']=999
        with self.assertRaises(AssertionError):exec(code,dict(before_rows=before,after_rows=after,updated_keys=keys))


if __name__=='__main__':unittest.main()
