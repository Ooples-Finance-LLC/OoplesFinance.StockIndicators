"""Prepare the approved report-only refresh; never import, commit or push.

--check-only validates the completed collection and publisher without writes.
Normal mode archives evidence and stages/verifies a candidate for parent review.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

OPS = Path(__file__).parent.resolve()
RECORD = 'current-baseline-ten-refresh-20261116'
RUN = '43949686899'
TOOLING_HEAD = '2a1737f30e5e1164189d0209b39ea46bf38c1239'
PUBLISHED = 'ab61b7eba91debdf481130c91a14e33d1a3e5888'
PLAN = 'benchmarks/plans/hosted-current-baseline-ten-refresh-20261116.json'
PLAN_SHA = '9e8c0a6200375d39f4c443e82b2797d67c4c91cfa25e7a18e56afd1fa345a68d'
REPORT_SHA = '2e454a8bd0f51b83e827c7d44ed47d1c1597faa3bdc5e53b5c0afbb848752311'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def git(repo, *args):
    return subprocess.check_output(['git', *args], cwd=repo, text=True).strip()


def embedded(path, name):
    text = Path(path).read_text(encoding='utf-8')
    return json.loads(re.search(r'<script[^>]*id="'+name+r'"[^>]*>(.*?)</script>', text, re.S)[1])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--collection', type=Path, required=True)
    parser.add_argument('--out', type=Path, default=OPS/(RECORD+'-report'))
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    collection, out = args.collection.resolve(), args.out.resolve()
    archive_root = Path(r'Z:\StockIndicators-Archives\active-performance-evidence\hosted-runs').resolve()
    assert ((collection.is_relative_to(OPS) and collection != OPS)
        or (collection.is_relative_to(archive_root) and collection != archive_root))
    assert out.is_relative_to(OPS) and out != OPS and not out.exists()
    assert not out.is_relative_to(collection) and not collection.is_relative_to(out)
    checkpoint = OPS/'continuation-latest-20261028.json'
    state = json.loads(checkpoint.read_text())
    q = state['performance_continuation_20261103'][RECORD]
    assert q['run_id'] == RUN and q['tooling_head'] == TOOLING_HEAD
    assert q['parent_reviewed'] and q['independent_reviewed']
    proposal = json.loads((OPS/'current-baseline-ten-pair-refresh-proposal-20261116.json').read_text())
    assert proposal['approved'] and not proposal['proposal_only'] and not proposal['source_qualification']
    publisher, tooling = Path(state['publishing_checkout']), Path(q['tooling_checkout'])
    assert git(publisher,'rev-parse','HEAD') == PUBLISHED and not git(publisher,'status','--porcelain')
    assert git(tooling,'rev-parse','HEAD') == TOOLING_HEAD and not git(tooling,'status','--porcelain')
    assert digest(tooling/PLAN) == PLAN_SHA
    assert (tooling/PLAN).read_bytes() == subprocess.check_output(['git','show',TOOLING_HEAD+':'+PLAN],cwd=tooling)
    os.environ['HOSTED_TIMING_PLAN'] = str(tooling/PLAN)
    sys.path.insert(0,str(tooling/'scripts'))
    from hosted_timing import pipeline as p, current_baseline_ten_refresh as refresh
    from hosted_timing.archive import archive
    from hosted_timing.report import stage
    assert p.REPO.resolve() == tooling.resolve() and p.PLAN.resolve() == (tooling/PLAN).resolve()
    # Source lookups/plan/approval reads use TOOLING. Publisher needs only ab61/5be for these diffs.
    assert not git(publisher,'diff',PUBLISHED,'HEAD','--','src','tests',p.BENCH,p.TESTS)
    assert not git(publisher,'diff',refresh.CANONICAL,'HEAD','--','src','tests',p.BENCH,p.TESTS)
    receipt = p.read(collection/'collection-receipt.json')
    assert receipt['status'] == 'verified' and receipt['run_id'] == RUN and receipt['tooling_head'] == TOOLING_HEAD
    assert receipt['plan_sha256'] == PLAN_SHA and (receipt['cases'],receipt['decisions']) == (100,20)
    assert receipt['local_hosted_collection_equal'] and receipt['protected_baseline_unchanged']
    collector_review = p.read(OPS/'current-baseline-ten-collector-review-receipt-20261116.json')
    assert collector_review['approved_run'] == RUN and collector_review['approved_tooling_head'] == TOOLING_HEAD
    assert digest(OPS/'collect-current-baseline-ten-20261116.py') == collector_review['collector']['sha256'] == receipt['collector_sha256']
    assert digest(OPS/'test_collect_current_baseline_ten_20261116.py') == collector_review['fixtures']['sha256']
    assert collector_review['fixtures']['passed'] == 8 and collector_review['fixtures']['failed'] == 0
    inputs, raw = collection/'inputs', collection/'evidence'
    proof = p.verify_inputs(inputs)
    assert proof['run_id'] == RUN and proof['workflow_head'] == TOOLING_HEAD and proof['plan_sha256'] == PLAN_SHA
    assert p.digest(inputs/'provenance.json') == receipt['input_provenance_sha256']
    result = refresh.collect(raw)
    assert result == p.read(collection/'independently-collected.json') == p.read(collection/'hosted-summary/verified-current-baseline-ten.json')
    assert result['baseline_refresh_verified'] and not result['accepted'] and not result['production_qualification']
    admitted = set(result['admitted_pairs'])
    assert admitted, 'Zero A/A-admitted pairs: retain collection evidence only; no report preparation/publication'
    assert admitted == set(receipt['admitted_pairs']) and result['quarantined_pairs'] == receipt['quarantined_pairs']
    changed_keys = {(pair,bars) for pair in admitted for bars in (1000,10000)}
    live = Path(r'C:\Users\cheat\Documents\OoplesFinance-Reports\competitor-performance.html')
    assert digest(live) == REPORT_SHA
    guards = p.read(OPS/'current-baseline-ten-report-guard-receipt-20261116.json')
    assert guards['measurement_run_id'] == RUN and guards['verification']['passed'] == 6
    assert all(digest(OPS/name) == sha for name,sha in guards['files'].items())
    if args.check_only:
        print(json.dumps(dict(check_only=True,run=RUN,tooling_head=TOOLING_HEAD,admitted_pairs=sorted(admitted),
            changed_baseline_rows=len(changed_keys),unchanged_baseline_rows=802-len(changed_keys),unchanged_builders=1544)))
        return
    destination = archive(raw,inputs,publisher,'baseline-refresh')
    candidate = stage(live,raw,publisher,out,phase='baseline-refresh',inputs=inputs)
    staged = p.read(out/'staged.json')
    assert (staged['changed_baseline_rows'],staged['unchanged_baseline_rows']) == (len(changed_keys),802-len(changed_keys))
    assert all(staged.get(key,0) == 0 for key in ('changed_builder_slots','added_builder_slots','replaced_builder_slots'))
    assert len(staged['builder_rows']) == 1544
    before, after = embedded(live,'dataset'), embedded(candidate,'dataset')
    assert embedded(live,'current-competitor-data') == embedded(candidate,'current-competitor-data')
    before_rows = {(row['pair'],row['bars']):row for row in before['rows']}
    after_rows = {(row['pair'],row['bars']):row for row in after['rows']}
    assert len(before_rows) == len(after_rows) == 802 and before_rows.keys() == after_rows.keys()
    assert {key for key in before_rows if before_rows[key] != after_rows[key]} == changed_keys
    assert all(str(after_rows[key]['measurement_run_id']) == RUN for key in changed_keys)
    delivery = out/'delivery-tooling'; delivery.mkdir()
    selected = {Path('.github/workflows/cpu-kernel-performance.yml'):tooling/'.github/workflows/cpu-kernel-performance.yml',
        Path('scripts/run-current-baseline-ten-refresh.py'):tooling/'scripts/run-current-baseline-ten-refresh.py'}
    for name in ('test_hosted_current_baseline_ten_refresh.py','test_current_baseline_archive.py',
                 'test_current_baseline_report_admission.py'):
        selected[Path('scripts')/name] = tooling/'scripts'/name
    for name in (Path(__file__).name,'collect-current-baseline-ten-20261116.py',
        'verify-current-baseline-ten-report-20261116.py','import-current-baseline-ten-report-20261116.py',
        'test_current_baseline_ten_report_guards_20261116.py','current-baseline-ten-report-guard-receipt-20261116.json',
        'current-baseline-ten-collector-review-receipt-20261116.json','test_collect_current_baseline_ten_20261116.py'):
        selected[Path('operations')/name] = OPS/name
    selected[Path('collection-receipt.json')] = collection/'collection-receipt.json'
    manifest = {}
    for relative, source in selected.items():
        target = delivery/relative; target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source,target); assert digest(target) == digest(source)
        manifest[relative.as_posix()] = digest(target)
    p.write(delivery/'manifest.json',manifest)
    p.write(delivery/'origin.json',dict(run_id=RUN,measurement_tooling=TOOLING_HEAD,delivery_tooling=TOOLING_HEAD,
        plan_sha256=PLAN_SHA,production_source=refresh.CANONICAL,harness_source=refresh.HARNESS,
        admitted_pairs=sorted(admitted),quarantined_pairs=result['quarantined_pairs'],production_optimization=False))
    with (out/'browser.log').open('wb') as log:
        subprocess.run([sys.executable,str(OPS/'verify-current-baseline-ten-report-20261116.py'),str(candidate),
            before['evidence']['baseSourceSha'],RUN,str(out)],stdout=log,stderr=subprocess.STDOUT,check=True)
    verified = p.read(out/'browser-verification.json')
    assert verified['comparisons'] == verified['displayed_table_comparisons'] == verified['exported_comparisons'] == 802
    assert verified['unchanged_builder_comparisons'] == 1544 and not verified['javascript_errors']
    assert digest(live) == REPORT_SHA, 'Staging must not import the report'
    # Fresh read: update only this record, preserving other agents' progress.
    latest = json.loads(checkpoint.read_text()); own = latest['performance_continuation_20261103'][RECORD]
    assert own['run_id'] == RUN and own['tooling_head'] == TOOLING_HEAD
    own.update(archive=str(destination),report_out=str(out),report_candidate_sha256=staged['candidate_sha256'],
        admitted_pairs=sorted(admitted),quarantined_pairs=result['quarantined_pairs'],baseline_refresh_verified=True,
        local_hosted_collection_equal=True,source_retention_verified=True,report_browser_verified=True,
        report_visual_verified=False,report_imported=False,production_qualification=False,production_integrated=False,
        accepted=False,status='Report-only candidate archived/staged/browser-verified; screenshot review and conditional import/publication remain')
    checkpoint.write_bytes((json.dumps(latest,indent=2)+'\n').encode())
    print(json.dumps(dict(run=RUN,archive=str(destination),candidate=str(candidate),candidate_sha256=staged['candidate_sha256'],
        admitted_pairs=sorted(admitted),changed_rows=len(changed_keys),report_imported=False)))


if __name__ == '__main__':
    main()
