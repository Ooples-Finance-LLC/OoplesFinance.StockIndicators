Repeated window replay and wide arithmetic make several indicators expensive. This rollout adds shared execution, rolling state and certified arithmetic while preserving exact values, presence, startup, input selection, overflow, reset and allocation contracts.

### Current canonical baseline refresh: nine admitted pairs

Nine pairs now have fresh report measurements for the current canonical production and the unchanged frozen comparison harness. This is a report-only baseline refresh: no production, test or benchmark-harness source changes, and zero source-optimization credit.

The [complete measurement run](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/43949686899) verified 100 cases / 20 identical-binary A/A comparisons across ten pairs and both sizes, with at most two measurement runners. The existing 1,000 unmeasured batch warmups, ten measured iterations, default runtime and CPU gates were retained. A/A outcomes were one faster, 19 inconclusive and zero slower. Both sizes had to be inconclusive to admit a whole pair: nine pairs / 18 report rows were admitted; ThreeStarsInSouth was quarantined at both sizes because its 1,000-bar A/A decision was faster. Independent collection matched CI exactly.

Fresh preflight passed 303 canonical comparator cases and 20 frozen-harness/canonical-production alignment checks. Existing actual GPU100 receipts for the unchanged canonical and frozen sources were authenticated and reused; this cycle did not run fresh GPU tests or compile new production binaries.

At 10,000 bars, Skew, Dynamic and LongLeggedDoji beat the native control with separated intervals in all four owned rounds. QuanTAlib Smma also has a round-two point win, but its four-round result is mixed. The one native control was measured in round two; these are not four independent native controls. There were no all-four separated native wins at 1,000 bars. These results refresh the baseline and do not establish source-optimization gains.

All 18 admitted baseline rows were refreshed; 784 other baseline rows and all 1,544 builder comparisons were retained. All 802 table/CSV comparisons and the unchanged builder comparisons were browser-verified, with screenshots reviewed before import. Publication CI remains pending and the overall performance task remains open.

The report shows **197/401 point wins at 1,000 bars and 236/401 at 10,000 bars**; 165 historical mixed-source batch gaps remain by point estimate at 10,000 bars. This is not a global current-source gap count. Work continues with this PR kept draft, targeting master, with auto-merge disabled.

### Complete named-output harness baseline refresh

Eight consumers across Awesome, Historical/Realized volatility, McGinley, Elder Ray and regression statistics now publish owned comparison columns directly from completed spans. Every required named column, output bit, presence flag and Full history is retained. Production algorithms are unchanged; this is a benchmark-harness baseline refresh.

Fresh canonical checks passed 37 history tests, 84 comparator tests and actual GPU100. The freshly rebuilt frozen harness passed 37 history tests, 97 comparator tests (including all 13 variant binding checks) and actual GPU100. The [complete measurement run](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/43880487485) covered all 80 cases / 16 identical-binary A/A comparisons, both sizes, with at most two measurement runners. Existing 1,000 unmeasured batch warmups, ten measured iterations, default runtime and CPU gates were retained.

A/A outcomes: 0 faster, 0 slower, 16 inconclusive. These describe timing variability and do not qualify production source. All four owned rounds were retained against one native control measured in round two: 0 confirmed native wins at 1,000 bars and 3 at 10,000 bars within these eight pairs. Mixed and inconclusive outcomes remain uncertain. Independent collection matched CI exactly.

All 16 affected report rows were refreshed with separate source, harness and GPU provenance. All 802 table/CSV comparisons and 1,544 unchanged builder comparisons were browser-verified, and screenshots inspected. Harness/report head: `ab61b7eba`. Publication checks passed, including SonarCloud; no review threads are open. Overall performance work remains open.

### Complete pointwise harness baseline refresh

The 19 pointwise benchmark adapters now project completed spans directly into owned comparison outputs, removing three intermediate arrays while preserving Full history, output bits and presence flags. Production indicator algorithms are unchanged. This is a benchmark-harness baseline refresh, not a production speedup qualification.

Fresh canonical verification passed 111 unit cases, 73 comparator cases and 100 actual local GPU contracts. The [complete measurement run](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/43800246247) covered 190 cases / 38 identical-binary A/A comparisons at both sizes, with at most two measurement runners. A/A outcomes were 1 faster, 1 slower and 36 inconclusive; all are retained as timing variability, not source improvement or regression. Independent collection matched CI exactly. Existing warmups, ten measured iterations, default runtime and CPU gates were preserved.

The report refreshes all 38 affected batch rows and identifies canonical production, benchmark and fresh GPU evidence separately. Four owned rounds are reviewed against each native control measured in round two: 16 pairs have separated native wins in all four rounds at 10,000 bars; Div and Mult are mixed, and Exp is inconclusive. No 1,000-bar pair has four-round confirmed native wins. All 802 table/CSV comparisons and 1,544 unchanged builder comparisons were browser-verified and screenshots inspected. Point-estimate report wins are separate from four-round confirmed native wins.

Harness/report published at `bde045026`. Required publication CI and SonarCloud passed. Overall performance work remains open.

### Run exact rolling log-volatility windows on tensor workers

Historical and Realized volatility now reuse their original exact rolling state in bounded tensor workers for sufficiently large positive-price batches. The executor records consumed closes; any nonpositive close replays the original whole-series state, preserving skipped returns and permanent Realized poisoning. Smaller batches, long periods, serial hosts and mixed roots retain their original path. The qualified change is about twice as fast at 10,000 bars but still trails native; these gaps remain open.

Fresh source-bound CI binaries passed 21 unit cases, 26 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/43673961720) covered 120 cases / 24 decisions: 6 faster, 18 inconclusive and zero slower. Independent local collection matched CI exactly; measured iterations, runtime, CPU and acceptance gates are unchanged.

The report refreshes 8 batch rows, 16 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `ce02581b1`. Publication CI passed, including SonarCloud. CodeRabbit did not post a status for this draft PR; its optional absence is recorded under the approved publication policy. Overall performance work remains open.

### Prefilter large upper-shadow candle batches before exact thresholds

Large Inverted Hammer and Shooting Star batches evaluate exact body and shadow comparisons before checking a necessary relation to the previous candle. Captured batches of at least 8,192 bars now check that price context first, then use the original exact comparisons and state updates. The factory selects this mode from the full batch length so worker partitioning cannot disable it. Smaller batches and streaming retain the existing comparison order.

Fresh source-bound CI binaries passed 16 unit cases, 147 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/43661486051) covered 120 cases / 24 decisions: 4 faster, 20 inconclusive and zero slower. Independent local collection matched CI exactly; measured iterations, runtime, CPU and acceptance gates are unchanged.

The report refreshes 8 batch rows, 16 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `e7112835a`. Publication CI passed, including SonarCloud. CodeRabbit did not post a status for this draft PR; its optional absence is recorded under the approved publication policy. Overall performance work remains open.

### Skip certified zero blocks in Abandoned Baby batches

Abandoned Baby CPU batches with periods at most64 certify blocks that cannot match from original structural price conditions,while preserving raw validation and owned history. Possible-match blocks reset and replay the original bounded exact state; dense input and unsupported periods retain ordinary updates. No threshold or arithmetic formula changes. Qualification also trials the approved20,000 unmeasured batch warmups for these five star APIs only; builder and Crow control policies stay unchanged. Fresh Crow builder-only control rows are retained separately; its historical builder/native comparisons preserve their original source and run provenance.

Fresh source-bound CI binaries passed 38 unit cases, 203 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/43641607785) covered 176 cases / 36 decisions: 6 faster, 30 inconclusive and zero slower. Independent local collection matched CI exactly; measured iterations, runtime, CPU and acceptance gates are unchanged.

The report refreshes 12 batch rows, 20 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `1225eed21`. Publication CI passed, including SonarCloud. CodeRabbit did not post a status for this draft PR; its optional absence is recorded under the approved publication policy. Overall performance work remains open.

### Reuse certified differences in star-reversal rolling sums

Star-reversal body and range windows add a certified exact price difference once instead of adding its two endpoints separately. Nonexact or overflowing differences and legacy-framework execution retain the original endpoint additions; thresholds, warmup, queues, ownership and worker dispatch are unchanged.

Fresh source-bound CI binaries passed 21 unit cases, 145 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/43590354236) covered 150 cases / 30 decisions: 9 faster, 21 inconclusive and zero slower. Independent local collection matched CI exactly; measured iterations, runtime, CPU and acceptance gates are unchanged.

The report refreshes 10 batch rows, 20 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `7f5290b20`. Publication CI passed, including SonarCloud. CodeRabbit did not post a status for this draft PR; its optional absence is recorded under the approved publication policy. Overall performance work remains open.

### Reuse exact word division for directional smoothing

Directional movement and range smoothing reuse the unchanged cached word divisor under exact significand and exponent guards. Unsupported inputs retain the original certificate and extended arithmetic; DI, DX, average and output contracts are unchanged. The complete qualification improves source performance but establishes no native gap closures; 198 nonwinning 10,000-bar report rows remain.

Fresh source-bound CI binaries passed 56 unit cases, 49 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/43562679883) covered 270 cases / 54 decisions: 37 faster, 17 inconclusive and zero slower. Independent local collection matched CI exactly; measured iterations, runtime, CPU and acceptance gates are unchanged.

The report refreshes 18 batch rows, 36 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `e6ceba9b5`. Publication CI passed, including SonarCloud. CodeRabbit did not post a status for this draft PR; its optional absence is recorded under the approved publication policy. Overall performance work remains open.

### Write directional batches through the original typed state

Single-root directional batches select the existing concrete state once, capture and validate each bar once, and write both output columns directly. Original state arithmetic, generic mixed fallback, deferred errors, cancellation and retained ownership are unchanged. The complete qualification improves source performance but establishes no native gap closures; 198 nonwinning 10,000-bar report rows remain.

Fresh source-bound CI binaries passed 46 unit cases, 49 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/43546521175) covered 270 cases / 54 decisions: 30 faster, 24 inconclusive and zero slower. Independent local collection matched CI exactly; measured iterations, runtime, CPU and acceptance gates are unchanged.

The report refreshes 18 batch rows, 36 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `e21708710`. Publication CI passed, including SonarCloud. CodeRabbit did not post a status for this draft PR; its optional absence is recorded under the approved publication policy. Overall performance work remains open.

### Verify exact T3 continuation state before retaining tensor worker regions

Large captured CascadedMeans T3 batches replay independent regions through the original state on the existing tensor worker pool. The coordinator retains a region only after its complete relevant continuation key matches the actual preceding state; every mismatch or speculative failure is replayed serially. Completed-seed index normalization preserves global suppression and presence. Original update, combination, smoothing, numerical fallbacks and unsupported seed paths remain unchanged.

Fresh source-bound CI binaries passed 20 unit cases, 26 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/43530847086) covered 30 cases / 6 decisions: 3 faster, 3 inconclusive and zero slower. Independent local collection matched CI exactly; measured iterations, runtime, CPU and acceptance gates are unchanged.

The report refreshes 2 batch rows, 4 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `8ab279c1e`. Publication CI passed, including SonarCloud. CodeRabbit did not post a status for this draft PR; its optional absence is recorded under the approved publication policy. Overall performance work remains open.

### Reuse certified pair prefixes for large Skender A/D batches

Large captured Skender A/D batches reuse the existing exact TA compensated-pair prefix writer only under its 103-bit normal-grid certificate. The existing 53-bit fast path stays first; small batches and uncertified grids keep their original paths. Flow, mean, streaming, owned history, cancellation and deferred exception behavior remain unchanged. At 10,000 bars the complete qualification measured about 30% lower batch time than the verified baseline. The candidate mean is about 3% faster than native, but confidence intervals overlap; this is a mean-based report win, not a demonstrated native win. The 1,000-bar native gap remains. Historical report ratios and same-run old/new source comparisons retain separate provenance.

Fresh source-bound CI binaries passed 23 unit cases, 25 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/43509389789) covered 30 cases / 6 decisions: 1 faster, 5 inconclusive and zero slower. Independent local collection matched CI exactly; measured iterations, runtime, CPU and acceptance gates are unchanged.

The report refreshes 2 batch rows, 4 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `3990552a2`. Publication CI passed, including SonarCloud. CodeRabbit did not post a status for this draft PR; its optional absence is recorded under the approved publication policy. Overall performance work remains open.

### Run exact range Doji state in bounded tensor worker regions

Captured CPU range Doji batches reuse the existing persistent tensor worker pool for independently seeded regions. Each region owns a fresh original state and replays WarmupBars preceding candles, including Dragonfly startup. The existing 8192-bar default parallel minimum, scheduler body, exact arithmetic, streaming path, ownership and validation remain unchanged. Maximum warmups retain the original fallback. At 10,000 bars, Dragonfly and Gravestone now beat native with separated intervals. Ordinary Doji has only an inconclusive mean win. LongLegged did not reproduce its historical native win on this host; its source comparison is inconclusive. The complete refresh yields two net additional report wins, leaving 199 mean-based gaps.

Fresh source-bound CI binaries passed 14 unit cases, 69 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/43486167503) covered 150 cases / 30 decisions: 17 faster, 13 inconclusive and zero slower. Independent local collection matched CI exactly; measured iterations, runtime, CPU and acceptance gates are unchanged.

The report refreshes 10 batch rows, 20 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `651a13ab5`. Publication CI passed, including SonarCloud. CodeRabbit did not post a status for this draft PR; its optional absence is recorded under the approved publication policy. Overall performance work remains open.

### Certify exact QEMA stage differences before final summation

QEMA captures its four unchanged normalized EMA stage outputs and tries a private difference-form certificate for the final 4,-6,4,-1 combination. Every intermediate difference and product must be exact, only the final addition rounds, and exact zero is canonicalized. Uncertified values retain the original coefficient order and exact accumulator fallback. Single EMA, stage arithmetic, startup, reset, validation and owned history are unchanged.

Fresh source-bound CI binaries passed 12 unit cases, 20 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/43382446422) covered 30 cases / 6 decisions: 3 faster, 3 inconclusive and zero slower. Independent local collection matched CI exactly; measured iterations, runtime, CPU and acceptance gates are unchanged.

The report refreshes 2 batch rows, 4 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `1b8a85f85`. Publication CI passed, including SonarCloud. CodeRabbit did not post a status for this draft PR; its optional absence is recorded under the approved publication policy. Overall performance work remains open.

### Select hyperbolic dispatch by physical-core fan-out

Sinh, Cosh and Tanh captured CPU batches now use the existing physical-core dispatch selector. Between 8,192 and 65,535 bars, it avoids parallel dispatch when configured workers exceed physical cores. The selector body, seven prior callers, Math results, overflow handling, validation, cancellation and owned history are unchanged.

Fresh source-bound CI binaries passed 52 unit cases, 27 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/43358532944) covered 90 cases / 18 decisions: 6 faster, 12 inconclusive and zero slower. Independent local collection matched CI exactly; measured iterations, runtime, CPU and acceptance gates are unchanged.

The report refreshes 6 batch rows, 12 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `6a2224fa1`. Publication CI passed, including SonarCloud. CodeRabbit did not post a status for this draft PR; its optional absence is recorded under the approved publication policy. Overall performance work remains open.

### Retain single-pass A/D for smaller captured batches

Captured fixed-grid A/D prefixes improved the larger batch but regressed the smaller one. Identity A/D batches below 8,192 bars retain the original single-pass loop and exact rounded-sum publisher; larger batches try the certified captured grid and original exact fallbacks. Flow arithmetic, streaming behavior, validation and owned history are preserved.

Fresh source-bound CI binaries passed 83 unit cases, 37 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/43345228740) covered 30 cases / 6 decisions: 1 faster, 5 inconclusive and zero slower. Independent local collection matched CI exactly; measured iterations, runtime, CPU and acceptance gates are unchanged.

The report refreshes 2 batch rows, 4 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `371161c12`. Publication CI passed, including SonarCloud. CodeRabbit did not post a status for this draft PR; its optional absence is recorded under the approved publication policy. Overall performance work remains open.

### Reuse cached word division in acceleration-band means

Acceleration-band rolling means use a general compact ratio publisher after summing their once-rounded inputs exactly. The private mean now caches the existing word divisor and tries bounded word publication for larger word-sized coefficients. Small, wide and unsupported scales retain the original mean. The transform, exact rolling sums, validation, owned history and shared helper source remain unchanged.

Fresh source-bound CI binaries passed 23 unit cases, 38 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/43330748040) covered 30 cases / 6 decisions: 1 faster, 5 inconclusive and zero slower. Independent local collection matched CI exactly; measured iterations, runtime, CPU and acceptance gates are unchanged.

The report refreshes 2 batch rows, 4 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `809884b9d`. Publication CI passed, including SonarCloud. CodeRabbit did not post a status for this draft PR; its optional absence is recorded under the approved publication policy. Overall performance work remains open.

### Reuse bounded word EMA updates in A/D oscillators

Smoothed A/D oscillator updates use a general floating certificate and dyadic fallback for non-power-of-two EMAs. The private mean now tries the existing bounded word-EMA certificate after the power-of-two fast path. Mean/first-value seeds, once-rounded stages, hidden extended values and original fallbacks are preserved.

Fresh source-bound CI binaries passed 25 unit cases, 20 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/43296691464) covered 60 cases / 12 decisions: 8 faster, 4 inconclusive and zero slower. Independent local collection matched CI exactly; measured iterations, runtime, CPU and acceptance gates are unchanged.

The report refreshes 4 batch rows, 8 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `dcea32a75`. Publication CI passed, including SonarCloud. CodeRabbit did not post a status for this draft PR; its optional absence is recorded under the approved publication policy. Overall performance work remains open.

### Excluded A/D fixed-grid prefix trial

The captured fixed-grid and guarded high/low-pair candidate passed 79 unit, 37 comparator and 100 actual GPU cases. Its [complete 30-case / 6-decision qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/43316489539) produced one faster, one slower and four inconclusive decisions; independent local collection matched CI exactly. At 10,000 bars the batch improved from about 0.884 ms to 0.257–0.262 ms, but at 1,000 bars it regressed from 0.115–0.143 ms to 0.181–0.202 ms. The unchanged Length20 builder controls were inconclusive; the proposed identity path requires Length1.

The candidate is rejected. Production source, GPU receipt and report values are preserved; the [complete exclusion evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/commit/aa5f18dc84e1db6c5980828e76fdc0886136c361) is retained separately. No unchanged retry or measurement-policy change is authorized by this result.

### Qualify arithmetic batch warmups on retained binaries

Identical arithmetic binaries showed separated timing ranges with 1,000 versus 20,000 unmeasured warmups. The approved policy now uses 20,000 warmups for Add/Sub/Mult/Div batch comparisons at both report sizes. This fresh qualification reuses the authenticated original source pair and retains ten measured iterations, default runtime and all CPU/acceptance gates. Each row keeps its historical source label.

The separate Beta return-reuse trial was rejected with four slower and two inconclusive decisions. Its [full rejection evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/7ebd7964332c4bfa95c69c4bfe7135168fc0aeb8/benchmarks/results/remaining-indicators/hosted-targeted-43239466605-attempt1) is published; its source and timings remain excluded.

Reused immutable source-bound binaries retain their verified 71 unit, 24 comparator and 100 actual GPU cases. Current production source and GPU evidence were preserved. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/43250857583) covered 120 cases / 24 decisions: 16 faster, 8 inconclusive and zero slower. Independent local collection matched CI exactly; measured iterations, runtime, CPU and acceptance gates are unchanged.

The report refreshes 8 batch rows, 16 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted report refresh published at `56fcb577c`. Publication CI passed, including SonarCloud. CodeRabbit did not post a status for this draft PR; its optional absence is recorded under the approved publication policy. Overall performance work remains open.

### Excluded Hilbert word-blend trial

The private exact word-blend candidate passed 58 unit, 167 comparator and 100 actual GPU cases. Its [complete 300-case / 60-decision qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/43271670056) produced 50 slower comparisons, 10 inconclusive and none faster; independent local collection matched CI exactly. The candidate is rejected, and production source and report values are preserved. [Exclusion evidence and directed rounding checks](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/commit/46ceffec810ad73f73fc22aca227d94268b97afa) are retained separately.

### Select default arithmetic fields once per captured batch

Default close/open arithmetic selects its fields once per captured batch and uses a private direct-field kernel. Other field choices retain the original selector; math operations, zero-divisor presence, overflow validation, owned history and cancellation use the unchanged shared executor. Source-bound Tier1 evidence shows two selector calls per bar becoming zero for all four operations. Qualified gains are against the previous implementation; native win totals remain unchanged.

Fresh source-bound CI binaries passed 71 unit cases, 24 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/43214078458) covered 120 cases / 24 decisions: 15 faster, 9 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 8 batch rows, 16 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `24df0f521`. Publication CI passed, including SonarCloud. CodeRabbit did not post a status for this draft PR; its optional absence is recorded under the approved publication policy. Overall performance work remains open.

### Use certified fixed-grid moments for captured return beta

Captured Beta previously rebuilt exact dyadic moments for each bar. It now certifies both return grids and maintains Int128 moments, retaining original exact fallbacks, owned history, startup, and deferred errors. At 10,000 bars, batch rounds improved from 3.30–3.40 ms to 2.18–2.28 ms against the previous implementation; native TA-Lib remains faster.

Fresh source-bound CI binaries passed 43 unit cases, 13 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/43153683698) covered 30 cases / 6 decisions: 6 faster, 0 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 2 batch rows, 4 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `d0a68355a`. Publication CI passed, including SonarCloud. CodeRabbit did not post a status for this draft PR; the optional absence is recorded under the approved publication policy. Overall performance work remains open.

### Keep scalar Hilbert state and compact exact batch updates

Finite Hilbert phase stages retain scalar rounded state with exact dyadic fallback. TSI uses directly rounded finite price differences, and identity A/D retains compact exact cumulative prefixes. Extended arithmetic, reset, signed-zero control, owned history and deferred validation remain preserved.

Fresh source-bound CI binaries passed 197 unit cases, 302 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/43132150094) covered 360 cases / 72 decisions: 55 faster, 17 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 24 batch rows, 48 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `d8e7cf76c`. Publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Reconcile master runtime and legacy JSON dependencies

Align AiDotNet.Tensors 0.150.0 and net461 System.Text.Json 11.0.0 with master. Indicator algorithms and historical performance rows are unchanged; the existing timings retain their original dependency/source labels.

Fresh source-bound baseline checks passed 161 unit cases, 292 comparator cases and all 100 actual GPU contracts. Frozen variants passed 54 unit cases, 13 comparator cases and GPU100. The [source-pinned net461 build](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/43106175412) passed; the JSON package's existing net461 support warning remains, and no legacy runtime coverage is claimed.

The captured CPU parallel-settings source is unchanged in this dependency release; fresh correctness/GPU checks cover the engine changes. No additional dependency timing qualification was required. The approved Hilbert qualification will use the reconciled runtime.

The [word-log/TSI combined qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42933740677) was rejected: 13 faster, four inconclusive and one slower (TSI BuilderFull, 1,000 bars). Its complete evidence is retained; none of that combination's production changes or timings were imported.

Reconciliation published at `54785ad20`. Publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Select captured inverse-circular dispatch by physical-core fan-out

Acos and Atan use the existing physical-core fan-out selector to avoid oversubscribed dispatch at intermediate input sizes; Math results, domains and the selector body remain unchanged.

Fresh source-bound CI binaries passed 47 unit cases, 27 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42922488475) covered 60 cases / 12 decisions: 4 faster, 8 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 4 batch rows, 8 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `73118b5eb`. Publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Use exact word arithmetic for primary TSI EMA stages

Four primary SeededTrueStrength EMA stages certify exact word quotients across signs and binades. The original same-binade path and extended/subnormal fallback remain; signal, percentage publication and shared helpers are unchanged.

Fresh source-bound CI binaries passed 68 unit cases, 98 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42909557184) covered 30 cases / 6 decisions: 3 faster, 3 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 2 batch rows, 4 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `255ae57c3`. Publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Reuse compact exact EMA for the TSI signal

SeededTrueStrength reuses the existing exact compact EMA kernel for its signal recurrence, retaining the original zero-publication path to preserve signed underflow. Seeds, primary stages, missing-value behavior and shared arithmetic kernels stay unchanged.

Fresh source-bound CI binaries passed 64 unit cases, 98 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42893400524) covered 30 cases / 6 decisions: 6 faster, 0 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 2 batch rows, 4 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `7dd78c8d8`. Publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Select captured circular dispatch by physical-core fan-out

Sin, Cos and Tan use the existing physical-core fan-out policy: defer parallel execution until 65,536 bars when configured workers exceed physical cores, retaining the 8,192-bar threshold otherwise. The shared selector preserves Ln/Log10 behavior; arithmetic, validation, cancellation and global CPU settings are unchanged.

Fresh source-bound CI binaries passed 45 unit cases, 27 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42859842246) covered 150 cases / 30 decisions: 8 faster, 22 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 10 batch rows, 20 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `3c8626783`. Publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Select captured logarithm dispatch by physical-core fan-out

Ln and Log10 defer parallel execution until 65,536 bars when the configured worker count exceeds detected physical cores. Other fan-out settings retain the 8,192-bar threshold. Arithmetic, validation, cancellation and global CPU settings are unchanged.

Fresh source-bound CI binaries passed 42 unit cases, 16 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42834812600) covered 60 cases / 12 decisions: 4 faster, 8 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 4 batch rows, 8 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `d1c8ac46c`. Publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Avoid parallel dispatch for small captured Exp batches

The private captured Exp path uses the existing 65,536-bar parallel minimum already used by ceiling, floor and square root. Smaller inputs run through the existing serial kernel; Math.Exp, validation, presence, cancellation, owned history, GPU behavior and all other operations remain unchanged.

Fresh source-bound CI binaries passed 40 unit cases, 16 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42714960149) covered 30 cases / 6 decisions: 2 faster, 4 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 2 batch rows, 4 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `7016890fd`. Publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Certify captured A/D price differences with the existing positive-price bounds

The private captured TA A/D path uses the existing positive-price ULP-grid proof to certify all four price differences together. Product certification, rounded division, cumulative publication and exact fallback remain unchanged; shared streaming Flow and Next are untouched.

Fresh source-bound CI binaries passed 71 unit cases, 37 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42685081255) covered 30 cases / 6 decisions: 2 faster, 4 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 2 batch rows, 4 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `670698d7d`. Publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Dependency/runtime alignment to AiDotNet.Tensors 0.149.0

Reconciled master's one-file 0.148.0 to 0.149.0 update. [Production CI](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42662982257) passed 78 focused unit cases, 45 comparator cases and all 100 actual local GPU contracts. The [frozen variant bridge](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42663134343) passed 54 unit cases, 13 comparator cases and GPU100 on the same verified 0.149.0 dependency image.

No indicator C# implementation or report value changed in this reconciliation. The existing performance measurements remain labeled 0.148.0. A selected review found 131 unchanged CPU method bodies and flags; this is not throughput equivalence or a new 0.149.0 performance claim. Subsequent performance batches require fresh qualification on matched 0.149.0 runtime closures.

Dependency reconciliation published at `f2275f461`. Publication CI passed, including SonarCloud and CodeRabbit. A new post-window title event passed; the historical startup failures are retained with this metadata-only verification refresh. Overall performance work remains open.

### Fill captured identity A/D columns with the existing exact state update

The private single-indicator Adl(1) batch route writes both output columns directly from the existing NextBatch publication. It removes per-bar state dispatch and scratch copying while preserving exact arithmetic, deferred failures, input validation and captured history. The 10,000-bar TA.Ad batch was the sole faster decision; the 1,000-bar batch and all four Adl(20) builder controls were inconclusive.

Fresh source-bound CI binaries passed 68 unit cases, 37 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42650703055) covered 30 cases / 6 decisions: 1 faster, 5 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 2 batch rows, 4 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Identity source/report first published at `3cc1cdb6a`. Its 0.148.0 qualification is preserved; delivery compatibility passed on 0.149.0 by the dependency reconciliation above. Overall performance work remains open.

### Cache exact word division for captured A/D means

Uncertified captured A/D mean windows cache one integer divisor per run. Recover the exact quotient with a corrected reciprocal, retain the original ties-to-even encoder and use the original Mean path for hardware-double, wide, extended and fractional-scale cases. The existing Mean implementation and OBV caller remain unchanged. The faster decision was BuilderLatestOnly at 1,000 bars; both batch and the other builder decisions remained inconclusive.

Fresh source-bound CI binaries passed 20 unit cases, 25 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42616750530) covered 30 cases / 6 decisions: 1 faster, 5 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 2 batch rows, 4 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `a1ab65d34`. Publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Certify bounded private A/D price differences

Use positive in-range price bounds to certify all four exact A/D differences together. Retain original certificates for unsupported inputs and preserve independent multiplier/flow rounding, product certification, exact fallback and deferred exceptions. All four faster decisions were builder comparisons; both batch comparisons remained inconclusive.

Fresh source-bound CI binaries passed 17 unit cases, 25 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42601193547) covered 30 cases / 6 decisions: 4 faster, 2 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 2 batch rows, 4 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `fc25ca171`. Publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Publish exact A/D prefixes without redundant decoding

Return the already rounded finite value when publishing captured Skender A/D prefixes. Preserve canonical zero, exact cumulative state, validation and the original wider/overflow path.

Fresh source-bound CI binaries passed 65 unit cases, 45 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42572319702) covered 30 cases / 6 decisions: 1 faster, 5 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 2 batch rows, 4 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `b120b9695`. Publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Certified triple-rate percentage arithmetic

Certify exact stage differences and correctly rounded percentage rates with existing arithmetic helpers; retain the original exact fallback and all seed, zero and signal conventions.

Fresh source-bound CI binaries passed 65 unit cases, 139 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42545873773) covered 60 cases / 12 decisions: 12 faster, 0 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 4 batch rows, 8 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `2c83abc0a`. Publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Scalar storage for rounded triple-rate EMA stages

Store rounded TRIX EMA stages directly as binary64 values, retaining exact seed sums, percentage/signal arithmetic, startup/reset conventions and the original exact smoothing fallback. Avoid copying general dyadic structs between already-rounded stages. An additional 121 native-fixture comparator cases passed locally from the same authenticated CI assembly, distinct from the 18 primary CI cases (139 total).

Fresh source-bound CI binaries passed 62 unit cases, 18 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42538747399) covered 60 cases / 12 decisions: 12 faster, 0 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 4 batch rows, 8 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `ac7df23df`. Publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Lazy exact factors for ordinary directional stages

Decode exact price factors only when a directional movement or true-range fallback needs them. Preserve eager finite-input rejection, original extended arithmetic, reset/startup/publication order and the unchanged framework path.

Fresh source-bound CI binaries passed 49 unit cases, 23 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42517850155) covered 210 cases / 42 decisions: 16 faster, 26 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 14 batch rows, 28 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `b2afb7edd`. Publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Compact exact publication for captured A/D identity outputs

Use compact exact wide-sum rounding only in the captured A/D identity-period route. Preserve unbounded accumulation, the original nonidentity/streaming publication path, both output columns and fallback/error order.

Fresh source-bound CI binaries passed 62 unit cases, 37 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42446630682) covered 90 cases / 18 decisions: 1 faster, 17 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 6 batch rows, 12 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `f23af32ad`. A tooling-only repair scopes three existing mutation entries to their original declaration; all 50 tooling self-tests passed and qualified production/test source is unchanged. Publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Compact retained candle price payloads

Retain certified exact body and range/shadow differences in a compact four-double price payload. Reconstruct original OHLC bits for uncertified history entries, preserving exact arithmetic, comparisons, eviction/reset and exception order. Qualification retains the approved Harami-only 20,000 batch warmups; other batches use 1,000, with ten builder warmups and ten measured iterations.

Fresh source-bound CI binaries passed 15 unit cases, 211 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42438691791) covered 240 cases / 48 decisions: 17 faster, 31 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 16 batch rows, 32 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `74ac792e9`. Publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Certified exact directional movement selection

Select directional movements directly when both raw price differences certify as exact finite doubles. Preserve strict ties, canonical zero, original exact fallbacks and state/exception order.

Fresh source-bound CI binaries passed 8 unit cases, 29 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42415866800) covered 30 cases / 6 decisions: 6 faster, 0 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 2 batch rows, 4 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `1d86df523`. Publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Bounded exact Hilbert residual summation

Replace four directed rounding steps per Hilbert projection term with an accumulated residual and a conservative error bound. Retain exact projection fallbacks and canonical zero publication.

Fresh source-bound CI binaries passed 6 unit cases, 97 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42360441758) covered 90 cases / 18 decisions: 17 faster, 1 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 6 batch rows, 12 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `c16d86d5e`. The approved metadata repair preserves all production, test and benchmark source; the original signed history is retained on `backup/pr266-before-commitlint-repair-20261107-e33679f65`. Full-range commitlint now checks all 1,656 PR commits, with unchanged rules and a passing 106-commit range regression test. Publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Exact finite Hilbert error steps

Step bounded finite projection-error intervals directly through adjacent binary64 encodings, preserving signed-zero/subnormal transitions and exact fallbacks. Extend the independent integer-product oracle to the certified exponent boundaries.

Fresh source-bound CI binaries passed 5 unit cases, 97 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42353522909) covered 90 cases / 18 decisions: 7 faster, 11 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 6 batch rows, 12 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `be194d9a9`. Publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Cached Hilbert certificates and phase-only calculations

Validate immutable sine/cosine coefficient residual bounds once per window length rather than for every projected price. Preserve all arithmetic, rounding and exact fallbacks. Skip two sine calculations when publishing phase-only Hilbert readings. Preserve phase arithmetic and all outputs; sine and trend modes retain their original expressions.

Fresh source-bound CI binaries passed 16 unit cases, 97 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42347569932) covered 90 cases / 18 decisions: 3 faster, 15 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 6 batch rows, 12 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `6414015a5`. Publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Exact cached Hilbert trend windows

Maintain an exact variable-length Hilbert trend-window sum by removing the outgoing price and adjusting only changed window lengths. Preserve null/zero startup behavior, resets, bounded history and the existing two rounding stages across seeded/delayed trendlines and trend mode.

Fresh source-bound CI binaries passed 14 unit cases, 120 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42333605830) covered 90 cases / 18 decisions: 6 faster, 12 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 6 batch rows, 12 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `28f95fce8`. Publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Accepted compact A/D Doji and MFI arithmetic

Combine independently accepted compact exact A/D cumulative totals, cached Doji comparison weights and certified wide MFI ratio publication. Preserve original fallbacks and rounding; freshly verify their complete combined consumer boundary and known Harami risk on the aligned0.148.0 runtime.

Fresh source-bound CI binaries passed 67 unit cases, 238 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42323565912) covered 270 cases / 54 decisions: 18 faster, 36 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 18 batch rows, 36 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `7bf90e881`. Publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Dependency/runtime alignment to AiDotNet.Tensors 0.148.0

Resolved the master package conflict with a dependency-only 0.147.0 to 0.148.0 update. Authenticated CI binaries passed 53 focused unit cases, 355 comparator cases and all 100 actual local GPU contracts. No indicator implementation or report value changed. Existing performance evidence used the frozen 0.144.0 timing runtime and remains applicable only to that recorded runtime; this dependency reconciliation makes no new performance claim. Future timing plans will verify the complete tested tensor runtime closure against their measurement runtime.

[Full publication CI](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42290877798) passed: 71 successful checks, seven intentional skips, SonarCloud and CodeRabbit successful. The published dependency-only head is `d38e32557`.

### Exact containment window and margin execution

Containment candles avoid maintaining unused range windows, cache ordinary integer comparison weights and combine exactly certified body differences before weighted comparisons, preserving fallback arithmetic, threshold inclusivity and lag order.

Fresh source-bound CI binaries passed 14 unit cases, 126 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42255018673) covered 120 cases / 24 decisions: 5 faster, 19 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 8 batch rows, 16 builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted containment source/report published at `847e61a86`; its master package conflict was resolved by the verified dependency reconciliation above. Overall performance work remains open.

### Normalized exact ZigZag coordinates

ZigZag cancels common binary powers before constructing exact price coordinates and reversal thresholds, reducing integer arithmetic while preserving pivots, ties, interpolation and all nullable retrospective outputs.

Fresh source-bound CI binaries passed 14 unit cases, 13 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42226929015) covered 20 cases / 4 decisions: 4 faster, 0 inconclusive and zero slower. Independent local collection matched CI exactly; sampling and acceptance gates are unchanged.

The report refreshes 2 batch rows, 2 snapshot rows with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; inventory checks passed and screenshots were inspected.

Accepted source/report published at `dc6100756`. Publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Shared A/D component arithmetic

The private captured A/D batch path shares its four certified exact price differences between the independently rounded multiplier and complete volume flow. Exact zero operands and underflowed zero flows preserve canonical publication; uncertain products, ranges and extended values retain the original exact fallbacks. Capture/validation order, cancellation, cumulative sums and optional averages are preserved. Shared money-flow, streaming state and GPU kernels are unchanged.

Fresh source-bound CI binaries passed 7 unit cases, 25 comparator cases and all 100 actual local GPU contracts. Four new directed cases cover the one-ULP difference between complete flow and rounded-multiplier multiplication, signed volumes, exact/underflowed zeros and both history modes. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42163827026) measured Skender.GetAdl batch and Full/LatestOnly consumers on `0.147.0`: 30 cases / 6 decisions, 5 faster, 1 inconclusive and zero slower. Independent collection matched CI exactly. The original measurement job passed; its collector artifact layout was recovered in [verification-only CI](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42169737391) using the original frozen collector. No timings were rerun, selected or pooled, and no gate changed.

The report refreshes two batch rows and four builder slots with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; eight inventory checks passed and screenshots were inspected.

Accepted source/report published at `7d695e243`; A/D component sharing publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Exact Renko price normalization

After the original decimal seed rounding, Renko cancels a certified common factor from the initial coordinate and decimal scale. Every later price and step contains that scale, preserving all threshold comparisons and integer counts. Price publication passes the scaled coordinate and binary exponent directly to the existing exact ScaledRatio helper. Volume sharing, deferred input guards, ownership and overflow behavior are preserved.

Fresh source-bound CI binaries passed 45 unit cases, 22 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42143562298) measured both fixed-size and ATR Renko batch/snapshot consumers on `0.147.0`: 44 cases / 8 decisions, 3 faster, 5 inconclusive and zero slower. Independent collection matched CI exactly; no timing rounds were selected or pooled.



The report refreshes four batch rows and four snapshot comparisons, retaining all 12 final snapshot/native measurements with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; eight inventory checks passed and screenshots were inspected.

Accepted source/report published at `613ab7510`; Renko price normalization publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Compact exact Renko volume

Renko now retains its exact volume sum in the existing compact accumulator between source bars, avoiding repeated full-grid integer additions. Sharing uses the same exact Ratio implementation with an unbounded positive brick-count divisor. Price coordinates, publication rounding, lazy reads and ownership retain their existing behavior. Deferred nonfinite volumes retain the original Units exception type, parameter name and message.

Fresh source-bound CI binaries passed 35 unit cases, 22 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42123318761) measured both fixed-size and ATR Renko batch/snapshot consumers on `0.147.0`: 44 cases / 8 decisions, 6 faster, 2 inconclusive and zero slower. Independent collection matched CI exactly; no timing rounds were selected or pooled.

At 10,000 bars, paired fixed-size batch/snapshot means improved 50.5%/50.3%; ATR-sized means improved 41.2%/42.2% over the accepted direct-coordinate baseline. Both snapshot decisions at 1,000 bars were inconclusive.


The report refreshes four batch rows and four snapshot comparisons, retaining all 12 final snapshot/native measurements with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; eight inventory checks passed and screenshots were inspected.

Accepted source/report published at `b99bf437c`; compact Renko volume publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Direct Renko scaled coordinates

Renko previously constructed full 2^-1074 price integers before shifting them onto its compressed grid. It now decodes each finite price directly onto that exact grid using the existing signed mantissa/scale representation. Original decimal seed rounding, grid expansion, exact counts, volume sharing and lazy reads are preserved. Mutations after validation retain the original deferred exception type, parameter name and message.

Fresh source-bound CI binaries passed 26 unit cases, 22 comparator cases and all 100 actual local GPU contracts. The [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42104684083) measured both fixed-size and ATR Renko batch/snapshot consumers on `0.147.0`: 44 cases / 8 decisions, 6 faster, 2 inconclusive and zero slower. Independent collection matched CI exactly; no historical `0.146.0` timings were reused or pooled.

At 10,000 bars, paired fixed-size batch/snapshot means improved 26.1%/25.1%; ATR-sized means improved 17.6%/18.3%. Fixed-size batch and ATR snapshot at 1,000 bars were inconclusive.

The report refreshes four batch rows and four snapshot comparisons, retaining all 12 final snapshot/native measurements with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; eight inventory checks passed and screenshots were inspected.

Accepted source/report published at `92fb9974a`; direct Renko publication CI passed, including SonarCloud and CodeRabbit. Overall performance work remains open.

### Tensor dependency reconciliation to 0.147.0

Reconciles master's `AiDotNet.Tensors` update from `0.146.0` to `0.147.0`, resolving the project-file conflict. Fresh [CI-built correctness](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42093814241) passed 53 unit and 56 comparator cases; the same source-bound binaries passed all 100 actual local GPU contracts. Package dependencies and `CpuParallelSettings` source are unchanged. Historical combined timing results below remain labeled with their original `0.146.0` source; no `0.147.0` timing claim is made.

Dependency-reconciled source and GPU receipt published at `ed2dfdfdd`; dependency reconciliation publication CI passed, including SonarCloud and CodeRabbit.

### Combined exact relative-strength mean and volatility-stop stages

Relative-strength means now retain exact rounded-ratio sums in the existing compact accumulator. Retrospective volatility stops certify finite normal width multiplication and finite stop addition/subtraction, retaining separate rounding stages and the exact fallback. Cached extremes reuse the original input reads. Masks, startup/reset, early overflow priority, retrospective prefix removal and legacy paths retain their original behavior.

Both changes qualified independently, then the complete composed source received fresh 53-unit / 56-comparator / actual GPU100 verification on source-matched CI binaries. The [fresh combined qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42075234237) covers all 96 cases / 18 decisions across both Renko controls, relative-strength batch/builders and volatility-stop batch/snapshots: 9 faster, 9 inconclusive, zero slower. Independent local collection exactly matched CI. No isolated timing rows were reused, selected or pooled.

At 10,000 bars, paired relative-strength batch/full/latest means improved 52.6%/68.0%/67.8%; volatility-stop batch/snapshot means improved 31.8%/38.2%. All eight Renko controls and relative-strength BuilderFull at 1,000 bars were inconclusive; no speedup is claimed for those decisions.

The report refreshes eight batch rows, four existing builder values and six snapshot comparisons, retaining all 18 final snapshot/native measurements with provenance. All 802 comparisons/CSV values and 1,544 builder values/provenance were browser-verified; eight inventory checks passed and screenshots were inspected.

Accepted combined source/report published at `ade366289`; fresh combined exact mean/stop publication CI passed, including SonarCloud; CodeRabbit was successful. Overall performance work remains open.

### Exact Renko price coordinates

Renko retained full 2^-1074 integer coordinates for ordinary prices. It now removes a proven common binary factor and expands the coordinates exactly when a later price needs a finer grid. Fixed and ATR-sized charts preserve decimal seed rounding, exact counts/thresholds, volume sharing, overflow behavior and deferred reads, including input changes after a yielded brick.

Validation: 15 unit cases, 22 comparator cases and 100 actual local GPU contracts on verified CI binaries. Fresh [qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42052502276) verified all 44 cases / 8 decisions: 4 faster, 4 inconclusive and zero slower. At 10,000 bars, paired fixed-size batch/snapshot means improved 14.3%/12.7%; ATR-sized means improved 11.0%/9.2%. All four 1,000-bar decisions were inconclusive. Independent collection matched CI; no rounds were pooled. Eight inventory checks passed.

The report refreshes four batch rows and retains all 12 final snapshot/native measurements with provenance, representing four snapshot comparisons. All 802 comparisons, CSV values and 1,544 unchanged builder values/provenance were browser-verified; screenshots were inspected.

Accepted source/report published at `56f2878af`; fresh exact Renko grid publication CI passed, including SonarCloud; CodeRabbit was successful. Overall performance work remains open.

### Finite deviation band position

Finite deviation-band position previously built exact accumulators on every bar to evaluate close minus center plus rounded half-width, divided by twice that half-width. A private path now certifies both numerator sums are exact and the doubled half-width is finite before one binary64 division. Uncertain intermediates, overflow and legacy frameworks retain exact arithmetic. Band rounding, percent width, ZScore, masks, startup/reset and validation priority remain unchanged.

Validation: 13 unit cases, 10 comparator cases and 100 actual local GPU contracts on verified CI binaries. Fresh [qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42026525060) covers all 90 cases / 18 decisions: 1 faster, 17 inconclusive, zero slower. No timing rounds were pooled. The report refreshes 6 baseline rows and 12 builder values; all 802 comparisons and 1,544 builder values/provenance were browser-verified.

The faster decision was Trady BollingerBandWidth BuilderLatestOnly at 1,000 bars (13.3%). The other 17 decisions were inconclusive; no broader speedup is claimed.


Accepted source/report published at `35e344001`; fresh deviation position certificate publication CI passed, including SonarCloud; CodeRabbit was successful. Overall performance work remains open.

### Finite published ATR width

ATR-band width previously built exact accumulators on every published value. A private path now certifies that subtraction of the published bands is exact before dividing by the nonzero center. Inexact or overflowing subtraction and legacy frameworks retain the original arithmetic. Existing band rounding, guards, masks, reset, startup and overflow priority are preserved.

Validation: 19 unit cases, 14 comparator cases and 100 actual local GPU contracts on verified CI binaries. Fresh [qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42013615363) covers all 90 cases / 18 decisions: 5 faster, 13 inconclusive, zero slower. No timing rounds were pooled. The report refreshes 6 baseline rows and 12 builder values; all 802 comparisons and 1,544 builder values/provenance were browser-verified.

At 10,000 bars, Keltner batch execution was 7.3% faster, BuilderFull was 11.0% faster and BuilderLatestOnly was 9.8% faster. The two disabled-width consumers remain controls; no regression was accepted.

Accepted source/report published at `eb6d2aba4`; fresh published ATR width publication CI passed, including SonarCloud; CodeRabbit was successful. Overall performance work remains open.

### Klinger qualification and dependency reconciliation

The Klinger batch certifies private Klinger EMA stages against the published directional-ratio baseline. Klinger retains its compact SMA seed and authoritative extended state, using the existing blend certificate for finite rounded stages. Uncertain, extended and legacy paths keep the original arithmetic. The full directional/Klinger consumer boundary is measured again to cover the earlier MinusDM regression.

The [fresh Klinger qualification against the ratio baseline](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/41901544931) passed **240 cases / 48 decisions: 6 faster, 42 inconclusive, zero slower**, covering all seven TA directional pairs and Skender Klinger batch/builder consumers. Independent collection exactly matched CI. Source and tests match measured source `376c0ef71e4dad1cef14330d3a6d989d19de729e`.

Validation:

- **64 unit, 38 comparator and 100 actual local GPU tests**, using verified source-bound CI binaries; all twelve new regression cases passed.
- Inventory generation/check and all eight inventory tests passed.
- Browser verification passed **802 displayed/CSV comparisons and 1,544 builder values/provenance**, with zero JavaScript errors. The import refreshed 16 baseline rows and 32 builder slots, preserving the other 786 rows and 1,512 slots.
- Source and report evidence are published at `f1ca2f18a`. Master’s AiDotNet.Tensors 0.146.0 dependency is reconciled at `4f9006987`, with fresh 64-unit / 38-comparator / 100 actual GPU checks; full publication CI passed, including SonarCloud; CodeRabbit was successful. The accepted timing evidence remains bound to its original 0.144.0 source; no timings are pooled or relabeled.

The earlier combined run41883056295 remains rejected evidence; no timings from it or the independent candidate runs are pooled into this import.

Timing retains SDK 10.0.403, default runtime settings, same-VM old/new/new/old rounds, build-free CPU samples at or below 15%, ten measured iterations, 1,000 warmups for fixed-invocation batch cases and ten for adaptive cases. The eight pair shards are capped at six concurrent runners. Independent and combined timing runs are never pooled. Complete samples, hashes, confidence intervals, allocations and runner identities are retained in [the qualification archives](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/perf/remaining-indicator-rollout/benchmarks/results/remaining-indicators).

### Classic PPO normalization

Percentage mode previously constructed a wide integer ratio for every rounded moving-average pair. A private modern fast path now certifies exact subtraction for same-sign averages within a factor of two, then certifies normalization using the unchanged arithmetic helper. Uncertain, wide, zero-denominator, and legacy cases retain the existing exact fallback; shared moving averages are unchanged.

Validation: 46 unit cases, 51 comparator cases, and 100 actual local GPU contracts on source-bound CI binaries. Fresh qualification against the reconciled 0.146.0 baseline covers all 60 cases / 12 decisions for APO and PPO: 6 faster, 6 inconclusive, zero slower. No timing rounds were pooled.

The report refreshes 4 baseline rows and 8 builder values; all 802 comparisons and 1,544 builder values/provenance were browser-verified. Source and report are published at `9b97c95e8`; fresh PPO publication CI passed, including SonarCloud; CodeRabbit was successful. Overall performance work remains open.

### Initial log-return certificate

Log-return calculation previously started with a 96-bit fixed interval. A private 72-bit interval now runs first and returns only when equal rounded endpoints certify the result. Its 36-bit product limbs and bounded scaled dividend fit UInt128; unresolved cases retain the unchanged 96-bit and adaptive fallbacks. Window moments, root rounding, presence, poisoning, reset, and legacy behavior are unchanged.

Validation: 18 unit cases, 10 comparator cases, and 100 actual local GPU contracts on source-bound CI binaries. Fresh qualification against the reconciled 0.146.0 baseline covers all 60 cases / 12 decisions for Historical and Realized: 7 faster, 5 inconclusive, zero slower. No timing rounds were pooled.

The report refreshes 4 baseline rows and 8 builder values; all 802 comparisons and 1,544 builder values/provenance were browser-verified. Source and report are published at `514b4e4b9`; fresh log-return publication CI passed, including SonarCloud; CodeRabbit was successful. Overall performance work remains open.

### Classic oscillator finite inputs

Oscillator states previously built a wide integer representation of every close before passing it to averages that already support finite inputs. Eligible modern SMA/WMA/TRIMA states now reuse that existing entry point. Other modes, both-period-one cases, rejected-close validation, and legacy execution retain the original shared exact-unit entry. Average rounding, normalization, presence, seeds, and reset are unchanged.

Validation: 49 unit cases, 51 comparator cases, and 100 actual local GPU contracts on source-bound CI binaries. Fresh qualification against the reconciled 0.146.0 baseline covers all 60 cases / 12 decisions for APO and PPO: 12 faster, 0 inconclusive, zero slower. No timing rounds were pooled.

The report refreshes 4 baseline rows and 8 builder values; all 802 comparisons and 1,544 builder values/provenance were browser-verified. Source and report are published at `5a48eae2c`; fresh finite-input publication CI passed, including SonarCloud; CodeRabbit was successful. Overall performance work remains open.

### Sum-seeded directional normalization

Sum-seeded ADX previously used compact integer multiplication and division for both DI stages on every mature bar. A private fast path now reuses the existing exact scaled-ratio certificate for finite stages. Uncertain rounding cells, extended exponents, seed/reset behavior, DI-before-DX rounding, and legacy arithmetic retain the original path.

Validation: 17 unit cases, 29 comparator cases, and 100 actual local GPU contracts on source-bound CI binaries. Fresh qualification against the fully green finite-input baseline covers all 30 cases / 6 decisions: four faster, two inconclusive, zero slower. The 10,000-bar batch decision was 12.3% faster. The report refreshes 2 baseline rows and 4 builder values; all 802 comparisons and 1,544 builder values/provenance were browser-verified.

The separate PVO normalization candidate is excluded in full. Its complete 120-case / 24-decision run had six faster, 17 inconclusive, and one slower: Trady MACD BuilderFull at 10,000 bars (+2.09%). Rejected evidence is retained; PVO source and report values were not imported. No timing rounds were pooled and no combined qualification was needed.

Accepted ADX source/report and both qualification records are published at `e9f710654`; fresh directional normalization publication CI passed, including SonarCloud; CodeRabbit was successful. Overall performance work remains open.

### Seeded Hilbert midpoint experiment

The private seeded-Hilbert midpoint experiment is excluded: its complete [30-case / 6-decision qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/41980456122) produced six inconclusive decisions and zero faster decisions. Independent local collection exactly matched CI. The source and report were not imported, and no timing rounds were pooled.

Correctness passed 19 unit cases, 15 comparator cases, and 100 actual local GPU contracts. The new boundary oracle was first characterized against the published binary to retain canonical zero at rounded stages; the failed and superseded attempts remain separate from passing evidence.

The [complete inconclusive evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/e837546a16be2873b2b94a66354bc81a4737267b/benchmarks/results/remaining-indicators/hosted-targeted-41980456122-attempt1) is published on `perf/seeded-hilbert-midpoint-inconclusive-evidence-20261105`. The accepted production head remains `e9f710654`, whose final receipt records 72 successful checks and seven skips, including successful SonarCloud/CodeRabbit checks. The live report remains on accepted results. Overall performance work remains open with 215 gaps at 10,000 bars.

### PVO adjacent-cell experiment

The adjacent-cell certificate remains excluded. Its [complete 120-case / 24-decision qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/41988339055) produced four faster, 19 inconclusive, and one slower decision. Trady MACD BuilderLatestOnly at 10,000 bars was 3.63% slower. Independent local collection exactly matched CI. The source and report were not imported; the four faster PVO decisions were not selected separately or pooled with other runs.

Correctness passed 36 unit cases, 138 comparator cases, and 100 actual local GPU contracts. Read-only binary inspection found identical IL, local types and stack requirements for the compared State and CompactAverage methods; this does not invalidate the measured regression or change the rejection.

The [complete rejected evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/95aadc022dab8ddfd35ca0744dfab40d12f6c932/benchmarks/results/remaining-indicators/hosted-targeted-41988339055-attempt1) is published on `perf/pvo-adjacent-certificate-rejected-evidence-20261105`. Accepted production source and the report remain on `e9f710654`. Overall performance work remains open with 215 gaps at 10,000 bars.

### Finite beta ratio experiment

The finite derived-ratio candidate remains excluded. Its [complete 30-case / 6-decision qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42004340118) produced 0 faster, 6 inconclusive and 0 slower decisions. Independent local collection exactly matched CI. Candidate source and report values were not imported, and no partial results were selected or pooled.

Correctness passed 20 unit cases, 13 comparator cases and 100 actual local GPU contracts. The first preparation run was cancelled before measurement because explanatory plan metadata was stale; the corrected immutable plan used fresh complete timing under unchanged gates.

[Complete excluded evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/0aae64c836be7af22af919b4ed1e02389b890ad9/benchmarks/results/remaining-indicators/hosted-targeted-42004340118-attempt1) is published on `perf/beta-derived-ratio-excluded-evidence-20261105`. Accepted source and report remain on `e9f710654`. Overall performance work remains open.

### Trady MACD control diagnostic

The approved [A/A diagnostic](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42040866424) completed all 30 cases / 6 comparisons; all six confidence intervals overlap. Both labels used the same verified old runtime binary from the complete original input artifact, with sampling and gates unchanged. Independent local collection exactly matched CI.

[Complete diagnostic evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/0e5e581bf70bf6b6ad2d32fda573b096f2d5d823/benchmarks/results/remaining-indicators/trady-macd-aa-42040866424-attempt1) is published on `perf/trady-macd-aa-diagnostic-evidence-20261105`. It includes raw results, the frozen plan, exact tooling and the excluded pre-measurement path failure. Measurement tooling provenance is distinguished from original input-build provenance. No source or report values were imported. Both PVO candidates remain rejected; this diagnostic authorizes no policy change or new qualification. Overall performance work remains open.

### Strict doji shadow comparison experiment

The strict doji shadow-comparison candidate remains excluded. Its [complete 150-case / 30-decision qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42044175057) produced 4 faster, 25 inconclusive and 1 slower decisions. Independent local collection exactly matched CI. Candidate source and report values were not imported, and no partial results were selected or pooled.

The slower decision was `TaLib.Candles.Doji` at 10,000 bars in `BuilderLatestOnly` (about 1.9% higher mean). The complete source remains rejected under the zero-slower gate.

Correctness passed 14 unit cases, 69 comparator cases and 100 actual local GPU contracts. Fresh complete timing retained unchanged measurement gates.

[Complete excluded evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/f404b37dc36c6aafc91d92cbf2fc089c38b16a18/benchmarks/results/remaining-indicators/hosted-targeted-42044175057-attempt1) is published on `perf/doji-shadow-comparison-excluded-evidence-20261105`. Accepted source and report remain on `35e344001`. Overall performance work remains open.

### Isolated compact relative-strength mean qualification

The private exact mean accumulator passed its [complete independent qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42056402544): all 30 cases / 6 decisions verified, all six faster, zero slower. At 10,000 bars the paired batch, BuilderFull and BuilderLatestOnly means improved 58.5%, 66.7% and 68.8%. Correctness passed 23 unit cases, 13 comparator cases and 100 actual local GPU contracts. Independent local collection exactly matched CI.

[Complete isolated evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/c30398745ef0906004a4f361e0516dec04f7c310/benchmarks/results/remaining-indicators/hosted-targeted-42056402544-attempt1) is published on `perf/price-relative-compact-mean-qualified-evidence-20261105`. This isolated source was qualified against `35e344001`; its accepted code is now included in the fresh combined-source qualification linked above. Its isolated timing rows were not imported or pooled.

### Independent finite volatility-stop stages

The [complete 22-case / 4-decision qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42066667293) produced 2 faster, 2 inconclusive and 0 slower decisions. Its disposition is **selected into the fresh combined-source qualification linked above**. Independent local collection exactly matched CI. Correctness passed 15 unit cases, 21 comparator cases and 100 actual local GPU contracts, including separate-stage rounding and original input-read ownership.

[Complete independent evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/3f658a0ea2ade9b4bb2d69fd6cb89d11154508e2/benchmarks/results/remaining-indicators/hosted-targeted-42066667293-attempt1) is published on `perf/volatility-stop-finite-stages-qualified-evidence-20261105`. The isolated result is retained for provenance; final source/report use the fresh combined measurements linked above. No independent timing rows were imported or pooled.

### Exact Renko endpoint cache experiment

The exact Renko endpoint cache candidate remains excluded. Its [complete 44-case / 8-decision qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42151898557) produced 0 faster, 8 inconclusive and 0 slower decisions. Independent local collection exactly matched CI. Candidate source and report values were not imported, and no partial results were selected or pooled.

Correctness passed 59 unit cases, 22 comparator cases and 100 actual local GPU contracts. Fresh complete timing retained all sampling and acceptance gates on the accepted price-normalization baseline.

[Complete excluded evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/3e61cd75097b75e9e7a13c5537ac53eb8ded62c8/benchmarks/results/remaining-indicators/hosted-targeted-42151898557-attempt1) is published on `perf/renko-endpoint-cache-excluded-evidence-20261105`. Accepted source and report remain on `613ab7510`. Overall performance work remains open.

### Exact A/D product-fallback experiment

The exact A/D product-fallback candidate remains excluded. Its [complete 30-case / 6-decision qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42177480771) produced 0 faster, 6 inconclusive and 0 slower decisions. Independent local collection exactly matched CI. Candidate source and report values were not imported, and no partial results were selected or pooled.

Correctness passed 7 unit cases, 25 comparator cases and 100 actual local GPU contracts. Fresh complete timing retained all sampling and acceptance gates on the accepted component-sharing baseline.

[Complete excluded evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/bb6bea604e1a0b8d72f5e34a6fd6a2a0a45d79b8/benchmarks/results/remaining-indicators/hosted-targeted-42177480771-attempt1) is published on `perf/adl-exact-product-fallback-excluded-evidence-20261106`. Accepted source and report remain on `7d695e243`. Overall performance work remains open.

Read-only fixture-path analysis found that both retained A/D timing fixtures bypass this cold exact-product fallback: dyadic prices and integer volumes take the ordinary certified-product return. The experiment remains excluded; the fixture model is archived with its evidence. Further performance work continues in separate bounded batches.

### Certified MFI conversion experiment

The certified MFI conversion candidate remains excluded. Its [complete 90-case / 18-decision qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42298436044) produced 0 faster, 18 inconclusive and 0 slower decisions. Independent local collection exactly matched CI. Candidate source and report values were not imported, and no partial results were selected or pooled.

Correctness passed 31 unit cases, 18 comparator cases and 100 actual local GPU contracts. Baseline, candidate and frozen harness used matching tested AiDotNet.Tensors 0.148.0 runtime assets. Sampling and acceptance gates were unchanged.

[Complete excluded evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/1c36c6d9a211553a721b0b3be838231e536ee5f3/benchmarks/results/remaining-indicators/hosted-targeted-42298436044-attempt1) is published on `perf/mfi-certified-conversions-excluded-evidence-20261106`. Accepted source and report remain on `d38e32557`. Overall performance work remains open.

### Body/shadow comparison experiment

The body/shadow comparison candidate remains excluded. Its [complete 240-case / 48-decision qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42298436560) produced 23 faster, 23 inconclusive and 2 slower decisions. Independent local collection exactly matched CI. Candidate source and report values were not imported, and no partial results were selected or pooled.

Marubozu BuilderFull at 1,000 bars regressed about 15.4%; Harami batch at 1,000 bars regressed about 4.54 times. Read-only inspection found all 31 containment/factory methods identical after metadata-token normalization, with matching optimized Debuggable modes. The cause is not established and the rejection remains unchanged.

Correctness passed 10 unit cases, 211 comparator cases and 100 actual local GPU contracts. Baseline, candidate and frozen harness used matching tested AiDotNet.Tensors 0.148.0 runtime assets. Sampling and acceptance gates were unchanged.

[Complete excluded evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/45cb7647608360021b45a5311c993353c174d075/benchmarks/results/remaining-indicators/hosted-targeted-42298436560-attempt1) is published on `perf/body-shadow-comparison-weights-excluded-evidence-20261106`. Accepted source and report remain on `d38e32557`. Overall performance work remains open.

### Certified shared A/D fallback experiment

The certified shared A/D fallback candidate remains excluded. Its [complete 240-case / 48-decision qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42312542200) produced 0 faster, 48 inconclusive and 0 slower decisions. Independent local collection exactly matched CI. Candidate source and report values were not imported, and no partial results were selected or pooled.

Correctness passed 51 unit cases, 34 comparator cases and 100 actual local GPU contracts. Baseline, candidate and frozen harness used matching tested AiDotNet.Tensors 0.148.0 runtime assets. Sampling and acceptance gates were unchanged.

[Complete excluded evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/e7171bb32f5191693f63cf9f68dc49add2c8cf6e/benchmarks/results/remaining-indicators/hosted-targeted-42312542200-attempt1) is published on `perf/shared-ad-certified-fallback-excluded-evidence-20261106`. Accepted source and report remain on `d38e32557`. Overall performance work remains open.

### Harami and Marubozu diagnostic

The [complete diagnostic evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/7f3e3da4bb2e9768a3d69db195b7042c24313889/benchmarks/results/remaining-indicators/harami-body-shadow-diagnostic-20261107) verifies all 30 cases / 6 comparisons, with exact local/CI collection equality. The old-profile Harami A/A control reproduced a separated 1,000-bar result using identical binaries: A means 0.1080/0.0921 ms versus B 0.3682/0.3970 ms. The new-profile controls overlapped at both sizes. This demonstrates measurement instability without a source change; it does not establish its cause or overturn the body/shadow rejection.

Both Marubozu profiles reached Tier1 in observational traces. Its instrumented 1,000-bar comparison overlapped, and the 10,000-bar comparison separated below baseline; these observations cannot qualify source. JIT text interrupted console warmup lines, so [collection-only CI](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42327644840) verified hash-bound retained BenchmarkDotNet logs while preserving original console hashes, complete numbered iterations and all existing gates. Tooling passed 339 orchestration / 5 package checks and actionlint. No measurement was repeated, no source or report was imported, and runtime/warmup policy remains unchanged.

### Harami warmup stability diagnostic

The approved [20-case / 4-comparison study](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42335244138) completed with exact local/CI collection equality. All four same-binary comparisons overlap with 20,000 unmeasured warmups and ten measured iterations under unchanged default runtime and CPU gates. This supports stability for the tested profiles; it does not establish JIT causality.

[Complete evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/b119122e3a7e5aa201aa540e3154af0699347805/benchmarks/results/remaining-indicators/harami-warmup-stability-20261107) retains raw results, authenticated original-input provenance, the frozen plan, tooling verification and the failed attempt with zero measured rounds. Qualification policy remains unchanged, body/shadow source remains excluded, and no report values were imported. Overall performance work remains open.

### Independent Hilbert follow-up qualifications

Caching immutable coefficient certificates and skipping unused phase-only sine calculations each completed an independent 90-case / 18-decision qualification: one faster, 17 inconclusive and zero slower. Both local collections exactly matched CI. The coefficient candidate passed 5 unit / 97 comparator cases; the phase-only candidate passed 11 unit / 97 comparator cases. Both passed all 100 actual local GPU contracts on source-bound CI binaries with Tensors 0.148.0.

Complete archived receipts:

- [hilbert-coefficient-certificates-20261107](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/1be124fe80c24662a98a473c5f69c6e44858603d/benchmarks/results/remaining-indicators/hosted-targeted-42340822414-attempt1)
- [hilbert-phase-only-trigonometry-20261107](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/1be124fe80c24662a98a473c5f69c6e44858603d/benchmarks/results/remaining-indicators/hosted-targeted-42342558959-attempt1)

Both changes subsequently passed the [fresh combined qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42347569932): 90 cases / 18 decisions, 3 faster, 15 inconclusive and zero slower, with exact local/CI equality. Combined source and the refreshed report were published at `6414015a5`; publication CI passed. Report values come from the fresh combined run. The independent receipts remain historical and their timings were not reused. Sampling, runtime policy and gates remain unchanged.

### Exact initial Hilbert projection seed experiment

The lag-zero projection seed candidate remains excluded. Its [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42453713383) covered 90 cases / 18 decisions: all 18 were inconclusive, so it did not meet the required at-least-one-faster gate. Independent local collection exactly matched CI. No candidate source or report values were imported, and sampling and acceptance gates were unchanged.

Source-bound correctness passed 7 unit cases, 97 comparator cases and all 100 actual local GPU contracts. Tooling passed 398 orchestration tests, 5 package tests and actionlint.

[Complete excluded evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/7cb9502debe0ed17fc3ed17d58bde25a2f923007/benchmarks/results/remaining-indicators/hosted-targeted-42453713383-attempt1) is retained on `perf/hilbert-lag-zero-seed-excluded-evidence-20261108`. Accepted production remains at `f23af32ad`. Overall performance work remains open.

### Magnitude-ordered exact Hilbert phase sum experiment

The ordered-sum candidate remains excluded. Its [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42492184064) covered 300 cases / 60 decisions: 57 inconclusive and 3 slower, with no faster decision. Independent local collection exactly matched CI. Source and report values were not imported; sampling and acceptance gates were unchanged.

The slower decisions were HtDcPhase at 10,000 bars in batch and BuilderLatestOnly, and QuanTAlib.Mama at 10,000 bars in batch. Source-bound correctness passed 42 unit cases, 160 comparator cases and 100 actual local GPU contracts; tooling passed 403 orchestration tests, 5 package tests and actionlint.

[Complete excluded evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/6afea39dbca4205e67cdd371d565c9e72ec42d35/benchmarks/results/remaining-indicators/hosted-targeted-42492184064-attempt1) is retained on `perf/hilbert-ordered-sum-excluded-evidence-20261108`. Accepted production remains at `f23af32ad`. Overall performance work remains open.

### Exact floating-grid eligibility experiment

The bit-ordered floating-grid guard candidate remains excluded. Its [complete qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42503775746) covered 90 cases / 18 decisions, all inconclusive. It did not meet the at-least-one-faster requirement. Independent local collection exactly matched CI; sampling and gates were unchanged. No candidate source or report values were imported.

Source-bound correctness passed 8 unit cases, 97 comparator cases and 100 actual local GPU contracts. Tooling passed 408 orchestration tests, 5 package tests and actionlint.

[Complete excluded evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/eb6e3b2c07668966c8274833a75d820bef5e2d23/benchmarks/results/remaining-indicators/hosted-targeted-42503775746-attempt1) is published on `perf/hilbert-floating-grid-guard-excluded-evidence-20261108`. Accepted production remains at `f23af32ad`. Overall performance work remains open.

### Directional single-node loop experiment

The [complete 270-case / 54-decision qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42511136990) produced 34 faster, 19 inconclusive and one slower decision. The slower result was the 1,000-bar EMA batch control. The candidate fails the unchanged zero-slower acceptance gate; all results are retained and no source or report values are imported. Independent local collection exactly matched CI.

Correctness passed 62 unit cases, 70 CI comparator cases, seven additional local comparator cases from the same authenticated CI assembly, and 100 actual local GPU contracts. The supplemental comparator receipt remains distinct from the primary CI receipt. Timing retained the frozen sampling, runtime and six-runner cap.

[Complete excluded evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/f8fd4f88ec6ee40a31f218a1588745be4e6aefd2/benchmarks/results/remaining-indicators/hosted-targeted-42511136990-attempt1) is published on `perf/prior-directional-single-loop-20261108-excluded-evidence`. Overall performance work remains open.

### Directional index ratio certificate experiment

The [complete 210-case / 42-decision qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42526812782) produced one faster, 40 inconclusive and one slower decision. MinusDM at 10,000 bars in BuilderLatestOnly was slower; DX at 1,000 bars in BuilderLatestOnly was faster. The candidate fails the unchanged zero-slower gate. Independent local collection exactly matched CI; no partial results were selected or pooled, and candidate source/report values remain excluded.

Final source-bound correctness passed 52 unit cases, 23 comparator cases and all 100 actual local GPU contracts. Earlier correctness runs were superseded before qualification: one was cancelled for final-source cleanup, and one exposed three new test setups requesting an unsupported period; the corrected tests retain independent exact references and use valid minimum periods. The failed logs remain retained. Timing used the final verified source and unchanged sampling/runtime policy.

[Complete excluded evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/a27c66f5c66ab7ed595be33829d8cbe72680e4d1/benchmarks/results/remaining-indicators/hosted-targeted-42526812782-attempt1) is published on `perf/prior-directional-dx-ratio-20261108-excluded-evidence`. Overall performance work remains open.

### Bounded T3 SIMD diagnostic study

The approved diagnostic study is complete. Independent BigInteger oracle checks passed for every supported period, endpoints/midpoints, full-width high products, and a six-EMA smoothing pipeline. AVX2 was exercised on Windows and Linux; AVX512F was exercised on Linux. The original scalar implementation and a separate scalar-inlining control were retained. All tested vector round means exceeded both matched scalar round means, so this prototype does not justify a production SIMD path.

[Complete code, raw results and verification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/2765159bfad49cd4a845330e7ac1b3fb37649fb5/benchmarks/results/remaining-indicators/t3-simd-study-20261108) are preserved separately. The initial Windows checkout failed before execution and was repaired with sparse checkout; runs remain separate. This measures only smoothing, excluding T3 polynomial, actual startup, validation, history and public API work. It is not production qualification; no source/report values were imported and no sampling/runtime policy changed. Overall performance work continues.

### Batch A/D balanced-product experiment

The [complete 30-case / 6-decision qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42553906718) produced six inconclusive decisions, zero faster and zero slower. The candidate does not meet the unchanged requirement for at least one faster decision. Independent local collection matched CI exactly; no partial results were selected or pooled. Candidate source and report values remain excluded.

Source-bound CI passed 65 unit cases and 37 comparator cases; all 100 actual local GPU contracts passed. A local disk-space interruption occurred during artifact installation before GPU execution; the same immutable CI artifact was authenticated and installation resumed without rebuilding or redispatching. All runtime hashes were verified before GPU tests.

[Complete excluded evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/5f1fa6c0e5efbe5d1b90e1d47e0abcc243e630d7/benchmarks/results/remaining-indicators/hosted-targeted-42553906718-attempt1) is published on `perf/adl-batch-balanced-product-20261109-excluded-evidence`. Overall performance work remains open.

### TRIX shared-stage loop experiment

The [complete 60-case / 12-decision qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42563308068) produced 12 inconclusive decisions, zero faster and zero slower. The candidate does not meet the unchanged requirement for at least one faster decision. Independent local collection matched CI exactly; no partial results were selected or pooled. Candidate source and report values remain excluded.

Final source-bound CI passed 65 unit cases and 139 comparator cases; all 100 actual local GPU contracts passed. An initial scratch-clear change failed one existing missing-value comparator and was reverted before qualification. The failed logs are retained with the [corrected source correctness evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/2e6d28426c180544848d4c05bdccfb74c302fc46/benchmarks/results/remaining-indicators/trix-private-update-work-20261109). Timing used only the corrected stage-unroll source with original clearing behavior.

[Complete excluded evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/6b7bb21dcd9b80d5d4cd47e5ca9425c5a314aa0b/benchmarks/results/remaining-indicators/hosted-targeted-42563308068-attempt1) is published on `perf/trix-private-update-work-20261109-excluded-evidence`. Overall performance work remains open.

### Batch A/D price-bounds experiment

The [complete 30-case / 6-decision qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42569711052) produced six inconclusive decisions, zero faster and zero slower. The candidate does not meet the unchanged requirement for at least one faster decision. Independent local collection matched CI exactly; no partial results were selected or pooled. Candidate source and report values remain excluded.

Source-bound CI passed 65 unit cases and 37 comparator cases; all 100 actual local GPU contracts passed. General price bounds preserve exact differences and original fallbacks; this qualification did not establish a performance gain.

[Complete excluded evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/d8956a6c455e907e2971bb2146e0942530fa33ff/benchmarks/results/remaining-indicators/hosted-targeted-42569711052-attempt1) is published on `perf/adl-price-bounds-20261109-excluded-evidence`. Overall performance work remains open.

### Beta return price-bounds experiment

The [complete 60-case / 12-decision qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42582308861) produced twelve inconclusive decisions, zero faster and zero slower. The candidate does not meet the unchanged requirement for at least one faster decision. Independent local collection matched CI exactly; no partial results were selected or pooled. Candidate source and report values remain excluded.

Source-bound CI passed 21 unique unit cases and 13 comparator cases; all 100 actual local GPU contracts passed. General price bounds preserve exact differences and original fallbacks; this qualification did not establish a performance gain.

[Complete excluded evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/653938263ed17929826b79bd231bef8f717d32f7/benchmarks/results/remaining-indicators/hosted-targeted-42582308861-attempt1) is published on `perf/beta-return-bounds-20261109-excluded-evidence`. Overall performance work remains open.

### Captured A/D fixed-grid experiment

The [complete 30-case / 6-decision qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42590795641) produced six inconclusive decisions, zero faster and zero slower. The candidate does not meet the unchanged requirement for at least one faster decision. Independent local collection matched CI exactly; no partial results were selected or pooled. Candidate source and report values remain excluded.

Source-bound CI passed 17 unit cases and 25 comparator cases; all 100 actual local GPU contracts passed. The certified fixed-grid prefix path preserved exact results and the original fallback; this qualification did not establish a performance gain.

[Complete excluded evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/ab437459f445d244659eaf67903ebeb512fde69a/benchmarks/results/remaining-indicators/hosted-targeted-42590795641-attempt1) is published on `perf/adl-fixed-grid-20261109-excluded-evidence`. Overall performance work remains open.

### A/D direct binary publication experiment

The [complete 30-case / 6-decision qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42640112080) produced four inconclusive and two slower decisions. The 10,000-bar Skender.GetAdl batch and BuilderFull decisions were slower. The direct binary publisher fails the unchanged zero-slower gate and is excluded; no candidate source or report values are imported. Independent local collection exactly matched CI.

Fresh source-bound checks passed 23 unit cases, 25 comparator cases and all 100 actual local GPU contracts. An initial GPU run aborted when C: filled; the successful rerun used the same authenticated CI binaries after storage recovered. Timing sampling, warmups and runtime policy were unchanged.

[Complete excluded evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/d8ef57d51d390b35a763f2711141a3f906870122/benchmarks/results/remaining-indicators/hosted-targeted-42640112080-attempt1) is published on `perf/adl-direct-binary-publication-20261109-excluded-evidence`. Overall performance work remains open.

### A/D binary publisher inline-hint experiment

The [complete 30-case / 6-decision qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42703042087) produced six inconclusive decisions. It fails the unchanged requirement for at least one faster result and is excluded. No candidate source or report values are imported; independent local collection exactly matched CI.

Fresh checks passed 23 unit cases, 25 comparator cases and all 100 actual local GPU contracts on matched 0.149.0 dependencies. The source-bound diagnostic confirmed three intended publisher inline successes with zero lost events under default runtime settings; this code-generation change did not establish a qualified speed improvement. Sampling and acceptance gates remain unchanged.

[Complete timing evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/d592d6c01005e5e2576966ce7c10c865b151b5d0/benchmarks/results/remaining-indicators/hosted-targeted-42703042087-attempt1) and [the authenticated JIT trace, parser and original/corrected attribution summaries](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/d592d6c01005e5e2576966ce7c10c865b151b5d0/benchmarks/results/remaining-indicators/adl-direct-binary-inline-hint-20261109-jit-confirmation) are retained on `perf/adl-direct-binary-inline-hint-20261109-excluded-evidence`. Overall performance work remains open.

### Captured Ln/Log10 parallel-minimum experiment

The [complete 60-case / 12-decision qualification](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42734662811) produced five faster, six inconclusive and one slower decision. Log10's 10,000-bar batch regressed by 14.29% (old rounds 0.16196/0.15824 ms; candidate rounds 0.18391/0.18206 ms). This fails the unchanged zero-regression gate, so both threshold changes are excluded. Candidate source and report values remain unimported; no winning subset is selected. Independent local collection matched CI exactly.

Fresh [source-bound correctness](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42731607946) passed 40 unit cases, 16 comparator cases and all 100 actual local GPU contracts on 0.149.0. Sampling, warmups, runtime and acceptance gates are unchanged. [Complete timing evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/6dfd463dc2c8452206e0df3b167de3b85d333569/benchmarks/results/remaining-indicators/hosted-targeted-42734662811-attempt1) is retained on `perf/log-parallel-minimum-20261109-excluded-evidence`. The publishing source remains `7016890fd`; overall performance work remains open.

### Log10 batch/builder dispatch diagnostic

The [bounded existing-binary diagnostic](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/42813611722) completed 20 paired BDN cases and eight separate unmeasured trace replays. Independent local verification matched all raw measurements and recomputed every sampled-stack summary; all artifact, input and binary hashes passed. Sampling, runtime, warmups and ten measured iterations are unchanged. [Full evidence](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/tree/decfdc16cd00b3910cb88faf11b0b827cb65dc33/benchmarks/results/remaining-indicators/log10-profile-diagnostic-20261110) includes compressed raw traces, logs, observations, identity receipts and the pinned dependency review.

The contrast reproduced: Log10's 10,000-bar batch was approximately 11.8% slower while BuilderFull was approximately 38.8% faster. Allocation changed by less than 0.1%. The batch worker recorded a parallelism limit of 2; builder recorded 8. Both VMs have two physical/four logical cores; the pinned 0.149.0 dependency defaults to physical cores, whereas the builder fixture explicitly sets 8. This supports examining fan-out relative to physical cores, without qualifying a replacement threshold. Different fixtures, warmup policies and CPU models remain relevant limitations; sampled waiting and PowerShell replay counters are not CPU-share or BDN latency evidence.

The first diagnostic attempt stopped at an exporter-discovery error; its partial data remains excluded. The repaired frozen run is complete. The blanket threshold candidate remains rejected, and no source or report values are imported. PR source remains `7016890fd`, draft/master/auto-merge-off. Overall performance work remains open.
