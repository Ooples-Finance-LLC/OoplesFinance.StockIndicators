"""Publish the reviewed report-only baseline refresh in separate bounded steps."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

OPS = Path(r'C:\Users\cheat\source\stock-indicators-operations')
NAME = 'current-baseline-ten-refresh-20261116'
BASE = 'ab61b7eba91debdf481130c91a14e33d1a3e5888'
RUN = '43949686899'
TOOLING = '2a1737f30e5e1164189d0209b39ea46bf38c1239'
PLAN = 'benchmarks/plans/hosted-current-baseline-ten-refresh-20261116.json'
PLAN_SHA = '9e8c0a6200375d39f4c443e82b2797d67c4c91cfa25e7a18e56afd1fa345a68d'
REMOTE = 'repos/Ooples-Finance-LLC/OoplesFinance.StockIndicators'
BRANCH = 'perf/remaining-indicator-rollout'
PACKAGES = ('benchmarks/results/remaining-indicators/hosted-baseline-refresh-43949686899-attempt1/',
    'benchmarks/results/remaining-indicators/current-baseline-ten-refresh-20261116-report-integration/')
BODY_SHA = 'e138b87dea710b8864ae91ee66fff113247efbb707d3a2853f657cc8486a42cf'
PAYLOAD_SHA = '067ffb76311d42a398d46c0ea31f2fafc72ff23460f277e82cb3a4c4d5df4d0e'
ORIGIN_SHA = '50455a84404af17c58971271894413512b9a990da3287400161f59a2963bc6d4'
ADMITTED = {'QuanTAlib.Smma', 'TaLib.Candles.Stalled', 'TaLib.Candles.SeparatingLines',
    'TaLib.Candles.UpsideGapTwoCrows', 'Skender.GetDynamic', 'QuanTAlib.Qema',
    'QuanTAlib.Skew', 'TaLib.Candles.LongLeggedDoji', 'Skender.GetSmma'}


def read(path): return json.loads(Path(path).read_text())
def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def api(path): return json.loads(subprocess.check_output(['gh', 'api', REMOTE+path]))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('step', choices=('check', 'push', 'apply-body'))
    args = parser.parse_args()
    checkpoint = OPS/'continuation-latest-20261028.json'
    state = read(checkpoint); q = state['performance_continuation_20261103'][NAME]
    repo = Path(state['publishing_checkout'])
    def git(*parts):
        return subprocess.check_output(['git', *parts], cwd=repo, text=True).strip()
    proposal = read(OPS/'current-baseline-ten-pair-refresh-proposal-20261116.json')
    assert proposal['approved'] and not proposal['proposal_only']
    assert proposal['published_pr_head'] == BASE
    assert (q['run_id'], q['tooling_head'], q['cases'], q['decisions']) == (RUN, TOOLING, 100, 20)
    assert all(q[key] for key in ('baseline_refresh_verified', 'local_hosted_collection_equal',
        'report_imported', 'report_browser_verified', 'report_visual_verified', 'source_retention_verified'))
    assert not any(q[key] for key in ('accepted', 'production_qualification', 'production_integrated'))
    assert not git('status', '--porcelain'), 'Publisher must be clean'
    head = git('rev-parse', 'HEAD')
    assert head == q['prepared_publication_head'] and re.fullmatch('[a-f0-9]{40}', head)
    assert head != BASE and git('merge-base', BASE, head) == BASE
    assert 'ooples-finance-llc/ooplesfinance.stockindicators' in git('remote', 'get-url', 'origin').lower()
    assert not git('diff', BASE, head, '--', 'src', 'tests',
        'benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks',
        'benchmarks/OoplesFinance.StockIndicators.CompetitorTests')
    changed = git('diff', '--name-only', BASE, head).splitlines()
    assert changed and all(name.startswith(PACKAGES) for name in changed), 'Only the report/evidence package may change'
    tooling = Path(q['tooling_checkout'])
    assert digest(tooling/PLAN) == PLAN_SHA
    assert (tooling/PLAN).read_bytes() == subprocess.check_output(['git', 'show', TOOLING+':'+PLAN], cwd=tooling)
    plan = read(tooling/PLAN); assert (plan['cases'], plan['decisions']) == (100, 20)
    proof = read(Path(q['collection'])/'independently-collected.json')
    assert proof['baseline_refresh_verified'] and not proof['accepted'] and not proof['production_qualification']
    assert (proof['case_count'], proof['decision_count']) == (100, 20)
    assert proof['verdicts'] == {'faster': 1, 'inconclusive': 19}
    assert set(proof['admitted_pairs']) == ADMITTED == set(q['admitted_pairs'])
    assert proof['quarantined_pairs'] == q['quarantined_pairs'] == [dict(pair='TaLib.Candles.ThreeStarsInSouth', sizes={'1000': 'faster', '10000': 'inconclusive'})]
    assert (proof['admitted_baseline_rows'], proof['unchanged_baseline_rows'], proof['unchanged_builder_comparisons']) == (18, 784, 1544)
    assert proof['native_review']['confirmed_native_wins'] == {'1000': 0, '10000': 3}
    out = Path(q['report_out']); imported = read(out/'imported.json'); browser = read(out/'browser-verification.json')
    assert (imported['changed_baseline_rows'], imported['unchanged_baseline_rows']) == (18, 784)
    assert all(imported.get(key, 0) == 0 for key in ('changed_builder_slots', 'added_builder_slots', 'replaced_builder_slots'))
    assert sum(imported['verdicts'].values()) == 1544
    live = Path(r'C:\Users\cheat\Documents\OoplesFinance-Reports\competitor-performance.html')
    assert digest(live) == imported['candidate_sha256'] == browser['report_sha256']
    assert browser['comparisons'] == browser['displayed_table_comparisons'] == browser['exported_comparisons'] == 802
    assert browser['unchanged_builder_comparisons'] == 1544 and not browser['javascript_errors']
    dataset = json.loads(re.search(r'<script id="dataset" type="application/json">(.*?)</script>', live.read_text(encoding='utf-8'), re.S)[1])
    wins = {str(size): sum(r['ooples_mean_ns'] < r['competitor_mean_ns'] for r in dataset['rows'] if r['bars'] == size) for size in (1000, 10000)}
    assert wins == {'1000': 197, '10000': 236}
    body = OPS/'pr266-current-baseline-ten-refresh-20261116-body.md'
    payload = body.with_suffix('.json'); origin = OPS/'pr266-current-baseline-ten-refresh-20261116-origin.json'
    assert digest(body) == BODY_SHA and digest(payload) == PAYLOAD_SHA and digest(origin) == ORIGIN_SHA
    assert read(payload)['body'] == body.read_text(encoding='utf-8')
    pr = api('/pulls/266')
    assert pr['state'] == 'open' and pr['draft'] and pr['auto_merge'] is None
    assert pr['base']['ref'] == 'master' and pr['head']['ref'] == BRANCH
    remote = git('ls-remote', 'origin', 'refs/heads/'+BRANCH).split()[0]
    expected_remote = head if args.step == 'apply-body' else BASE
    assert remote == pr['head']['sha'] == expected_remote
    assert hashlib.sha256(pr['body'].encode()).hexdigest() == read(origin)['original_pr_body_sha256'], 'PR body changed; reconcile before applying staged body'
    if args.step == 'check':
        print(json.dumps(dict(check_only=True, head=head, changed_files=len(changed), report_wins=wins)))
        return
    if args.step == 'push':
        subprocess.run(['git', 'push', 'origin', 'HEAD:refs/heads/'+BRANCH], cwd=repo, check=True)
    else:
        checks = api('/commits/'+head+'/check-runs?per_page=100')['check_runs']
        titles = [check for check in checks if check['name'] == 'Auto-Fix PR Title']
        assert titles and all(check['status'] == 'completed' and check['conclusion'] in ('success', 'skipped') for check in titles), 'Title metadata check pending; retry apply-body later'
        subprocess.run(['gh', 'api', REMOTE+'/pulls/266', '--method', 'PATCH', '--input', str(payload), '--silent'], check=True)
        after = api('/pulls/266')
        assert after['head']['sha'] == head and after['draft'] and after['auto_merge'] is None and after['base']['ref'] == 'master'
        assert after['body'] == read(payload)['body']
    # Fresh read, update only this bounded publication record; never mark goal complete.
    state = read(checkpoint); q = state['performance_continuation_20261103'][NAME]
    assert q['prepared_publication_head'] == head
    q.update(published_head=head, fresh_publication_ci_status='pending',
        pr_body_payload=str(payload), pr_body_applied=args.step == 'apply-body',
        status='Report-only baseline refresh published; publication CI pending')
    state.update(published_head=head, local_head=head, full_goal_complete=False,
        report_sha256=imported['candidate_sha256'], report_wins=wins, remaining_10000_bar_gaps=165,
        count_scope='mixed-source historical ledger; not a fully current-source gap count',
        updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        current_published_ci_pending=dict(head=head, reason=NAME))
    state['performance_continuation_20261103'].update(
        report_sha256=imported['candidate_sha256'], remaining_gaps={'1000': 204, '10000': 165},
        remaining_10000_bar_gaps=165, full_goal_complete=False,
        count_scope='mixed-source historical ledger; not a fully current-source gap count')
    temporary = checkpoint.with_suffix('.baseline-ten-publish.tmp')
    assert not temporary.exists()
    temporary.write_bytes((json.dumps(state, indent=2)+'\n').encode()); os.replace(temporary, checkpoint)
    print(json.dumps(dict(step=args.step, head=head, publication_ci='pending')))


if __name__ == '__main__':
    main()
