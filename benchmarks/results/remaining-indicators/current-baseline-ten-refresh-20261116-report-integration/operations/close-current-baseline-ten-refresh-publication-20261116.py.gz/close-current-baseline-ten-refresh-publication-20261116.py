"""Close one exact-head report-only publication; each step is bounded and explicit."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

OPS = Path(r'C:\Users\cheat\source\stock-indicators-operations')
BACKUP = Path(r'Z:\StockIndicators-Archives\active-operations\baseline-ten-20261116')
NAME = 'current-baseline-ten-refresh-20261116'
RUN = '43949686899'
REPORT = '7b3ad6b8829afa29d2d9b86143b088bf66cc3b28a6411d318d821bd049d6d67b'
REMOTE = 'repos/Ooples-Finance-LLC/OoplesFinance.StockIndicators'
OLD = 'Publication CI remains pending and the overall performance task remains open.'
NEW = 'Publication checks passed, including SonarCloud and review-thread checks; the overall performance task remains open.'


def read(path): return json.loads(Path(path).read_text())
def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def api(path): return json.loads(subprocess.check_output(['gh', 'api', REMOTE+path]))


def atomic_both(name, value):
    data = (json.dumps(value, indent=2)+'\n').encode()
    for folder in (BACKUP, OPS):
        temporary = folder/(name+'.tmp')
        assert not temporary.exists(), 'Inspect prior incomplete write before retrying'
        temporary.write_bytes(data); os.replace(temporary, folder/name)
    assert digest(BACKUP/name) == digest(OPS/name)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('step', choices=('check', 'apply-status', 'close'))
    args = parser.parse_args()
    checkpoint = OPS/'continuation-latest-20261028.json'
    state = read(checkpoint); q = state['performance_continuation_20261103'][NAME]
    assert q['run_id'] == RUN and q['report_sha256'] == REPORT
    assert q['report_wins'] == {'1000': 197, '10000': 236} and q['source_optimization_credit'] == 0
    assert q['baseline_refresh_verified'] and q['report_imported'] and q['report_visual_verified']
    assert not q['accepted'] and not q['production_qualification'] and not q['production_integrated']
    head = q['published_head']; assert re.fullmatch('[a-f0-9]{40}', head) and head == q['prepared_publication_head']
    repo = Path(state['publishing_checkout'])
    def git(*parts): return subprocess.check_output(['git', *parts], cwd=repo, text=True).strip()
    assert git('rev-parse', 'HEAD') == head and not git('status', '--porcelain')
    assert git('ls-remote', 'origin', 'refs/heads/perf/remaining-indicator-rollout').split()[0] == head
    assert digest(Path(r'C:\Users\cheat\Documents\OoplesFinance-Reports\competitor-performance.html')) == REPORT
    checks_response = api('/commits/'+head+'/check-runs?per_page=100&filter=latest')
    assert 0 < checks_response['total_count'] <= 100
    checks = checks_response['check_runs']; assert len(checks) == checks_response['total_count']
    assert all(c['head_sha'] == head and c['status'] == 'completed' and c['conclusion'] in ('success', 'skipped') for c in checks)
    assert any(c['name'] == 'SonarCloud Code Analysis' and c['conclusion'] == 'success' for c in checks)
    statuses = api('/commits/'+head+'/status?per_page=100')
    assert statuses['sha'] == head and statuses['total_count'] <= 100
    assert len(statuses['statuses']) == statuses['total_count']
    assert all(s['state'] == 'success' for s in statuses['statuses'])
    assert not statuses['total_count'] or statuses['state'] == 'success'
    workflows_response = api('/actions/runs?head_sha='+head+'&per_page=100')
    assert 0 < workflows_response['total_count'] <= 100
    workflows = workflows_response['workflow_runs']; assert len(workflows) == workflows_response['total_count']
    assert all(w['head_sha'] == head and w['status'] == 'completed' and w['conclusion'] in ('success', 'skipped') for w in workflows)
    pr = api('/pulls/266')
    assert pr['state'] == 'open' and pr['head']['sha'] == head and pr['head']['ref'] == 'perf/remaining-indicator-rollout'
    assert pr['draft'] and pr['auto_merge'] is None and pr['base']['ref'] == 'master'
    # The existing fetcher takes the PR number as argv; never repoint saved scripts.
    subprocess.run([sys.executable, str(OPS/'fetch-review-threads-20261029.py'), '266'], check=True)
    threads = read(OPS/'pr266-review-threads-20261029.json')
    assert threads['pr'] == 266 and threads['head'] == head and threads['target'] == 'master' and not threads['unresolved']
    summary = dict(head=head, measurement_run=RUN, checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        checks=checks, statuses=statuses, workflows=workflows, sonar_success=True,
        review_thread_count=threads['thread_count'], unresolved_review_threads=0,
        draft=True, target='master', auto_merge=False, report_sha256=REPORT,
        report_wins={'1000': 197, '10000': 236}, remaining_mean_based_historical_10000_gaps=165,
        count_scope='mixed-source historical ledger; not a fully current-source gap count',
        source_optimization_credit=0, production_optimization=False, overall_goal_complete=False)
    pre_name = 'pr266-current-baseline-ten-pre-status-20261116.json'
    if args.step == 'check':
        print(json.dumps(dict(head=head, checks=len(checks), statuses=len(statuses['statuses']), workflows=len(workflows), unresolved=0)))
        return
    if args.step == 'apply-status':
        assert pr['body'].count(OLD) == 1 and NEW not in pr['body']
        body = pr['body'].replace(OLD, NEW, 1)
        before = dict(summary, before_check_ids=[c['id'] for c in checks],
            before_workflow_ids=[w['id'] for w in workflows],
            expected_body_sha256=hashlib.sha256(body.encode()).hexdigest())
        atomic_both(pre_name, before)
        payload_name = 'pr266-current-baseline-ten-final-status-body-20261116.json'
        atomic_both(payload_name, dict(body=body))
        subprocess.run(['gh', 'api', REMOTE+'/pulls/266', '--method', 'PATCH', '--input', str(OPS/payload_name), '--silent'], check=True)
        after = api('/pulls/266')
        assert after['head']['sha'] == head and after['body'] == body and after['draft'] and after['auto_merge'] is None and after['base']['ref'] == 'master'
        print(json.dumps(dict(head=head, status_applied=True, post_metadata_verification_pending=True)))
        return
    before = read(OPS/pre_name)
    assert before['head'] == head and before['measurement_run'] == RUN and before['report_sha256'] == REPORT
    assert pr['body'].count(NEW) == 1 and OLD not in pr['body']
    assert hashlib.sha256(pr['body'].encode()).hexdigest() == before['expected_body_sha256']
    fresh_title = [c for c in checks if c['name'] == 'Auto-Fix PR Title' and c['id'] not in before['before_check_ids']]
    assert fresh_title and all(c['conclusion'] in ('success', 'skipped') for c in fresh_title), 'Fresh post-description title check pending; retry close later'
    assert any(w['id'] not in before['before_workflow_ids'] for w in workflows), 'Fresh post-description workflow pending'
    summary.update(publication_complete=True, post_description_metadata_verified=True,
        fresh_title_check_ids=[c['id'] for c in fresh_title], before_status_check_ids=before['before_check_ids'])
    receipt_name = 'pr266-current-baseline-ten-publication-closed-20261116.json'
    atomic_both(receipt_name, summary)
    # Fresh checkpoint read avoids replacing unrelated concurrent progress.
    state = read(checkpoint); q = state['performance_continuation_20261103'][NAME]
    assert q['published_head'] == head and q['report_sha256'] == REPORT
    q.update(publication_complete=True, fresh_publication_ci_status='success', ci_receipt=str(OPS/receipt_name),
        post_description_metadata_verified=True, unresolved_review_threads=0, review_thread_count=threads['thread_count'],
        source_optimization_credit=0, overall_goal_complete=False,
        status='Report-only baseline refresh publication closed; CI/Sonar/post-description checks passed; 165 historical mixed-source point gaps remain')
    pending = state.get('current_published_ci_pending')
    if pending:
        assert pending['head'] == head
        state.pop('current_published_ci_pending')
    state.update(updated_utc=summary['checked_utc'], full_goal_complete=False,
        report_sha256=REPORT, report_wins={'1000': 197, '10000': 236}, remaining_10000_bar_gaps=165,
        count_scope=summary['count_scope'])
    state['performance_continuation_20261103'].update(full_goal_complete=False,
        report_sha256=REPORT, remaining_gaps={'1000': 204, '10000': 165}, remaining_10000_bar_gaps=165,
        count_scope=summary['count_scope'])
    atomic_both(checkpoint.name, state)
    print(json.dumps(dict(head=head, publication_complete=True, checks=len(checks), workflows=len(workflows), remaining_historical_gaps=165, overall_goal_complete=False)))


if __name__ == '__main__':
    main()
