"""Package an actually imported report-only refresh; never import, commit or push."""
import argparse
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

OPS=Path(r'C:\Users\cheat\source\stock-indicators-operations')
BACKUP=Path(r'Z:\StockIndicators-Archives\active-operations\baseline-ten-20261116')
RUN='43949686899'
HEAD='2a1737f30e5e1164189d0209b39ea46bf38c1239'
BASE='ab61b7eba91debdf481130c91a14e33d1a3e5888'
CANONICAL='5be1a81d02ad01393f3fa8ede764e914252d0e96'
BEFORE='2e454a8bd0f51b83e827c7d44ed47d1c1597faa3bdc5e53b5c0afbb848752311'
REPORT='7b3ad6b8829afa29d2d9b86143b088bf66cc3b28a6411d318d821bd049d6d67b'
NAME='current-baseline-ten-refresh-20261116'


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def atomic(path,content):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_name(path.name+'.package.tmp');assert not temporary.exists()
    with temporary.open('xb') as stream:
        stream.write(content);stream.flush();os.fsync(stream.fileno())
    temporary.replace(path)
def save(path,value):atomic(path,(json.dumps(value,indent=2)+'\n').encode())
def embedded(path,key):
    return json.loads(re.search(r'<script[^>]*id="'+key+r'"[^>]*>(.*?)</script>',Path(path).read_text(encoding='utf-8'),re.S)[1])


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--check-only',action='store_true');args=parser.parse_args()
    checkpoint=OPS/'continuation-latest-20261028.json';state=read(checkpoint);q=state['performance_continuation_20261103'][NAME]
    assert q['run_id']==RUN and q['tooling_head']==HEAD
    publisher=Path(state['publishing_checkout']).resolve()
    git=lambda *argv:subprocess.check_output(['git',*argv],cwd=publisher,text=True).strip()
    assert git('rev-parse','HEAD')==BASE
    protected=['src','tests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks',
        'benchmarks/OoplesFinance.StockIndicators.CompetitorTests','benchmarks/results/remaining-indicators/inventory.json']
    assert not git('diff','--name-only',BASE,'--',*protected)
    assert not git('ls-files','--others','--exclude-standard','--',*protected)
    report=BACKUP/'verified-report-output';assert report.is_dir()
    imported,browser,staged,measurement=[read(report/name) for name in ('imported.json','browser-verification.json','staged.json','measurement.json')]
    assert str(imported['run_id'])==str(browser['run_id'])==str(measurement['run_id'])==RUN
    assert measurement['source_sha']==CANONICAL
    assert imported['before_sha256']==staged['before_sha256']==BEFORE
    assert imported['candidate_sha256']==staged['candidate_sha256']==browser['report_sha256']==REPORT
    assert imported['browser_verified'] and browser['hosted_provenance_verified'] and not browser['javascript_errors']
    assert browser['comparisons']==browser['displayed_table_comparisons']==browser['exported_comparisons']==802
    assert (imported['changed_baseline_rows'],imported['unchanged_rows'],browser['unchanged_baseline_rows'],browser['unchanged_builder_comparisons'])==(18,784,784,1544)
    assert all(imported.get(key,0)==0 for key in ('changed_builder_slots','added_builder_slots','replaced_builder_slots'))
    live=Path(r'C:\Users\cheat\Documents\OoplesFinance-Reports\competitor-performance.html')
    assert digest(live)==digest(report/'candidate.html')==REPORT and digest(report/'before.html')==BEFORE
    summary=read(Path(q['collection'])/'independently-collected.json')
    assert summary['case_count']==100 and summary['decision_count']==20 and summary['baseline_refresh_verified']
    assert not summary['accepted'] and not summary['production_qualification']
    pairs=set(summary['admitted_pairs']);assert len(pairs)==9 and pairs==set(browser['admitted_pairs'])
    quarantine=[dict(pair='TaLib.Candles.ThreeStarsInSouth',sizes={'1000':'faster','10000':'inconclusive'})]
    assert summary['quarantined_pairs']==quarantine
    keys={(pair,bars) for pair in pairs for bars in (1000,10000)}
    assert {(key[0],int(key[1])) for key in browser['updated_baseline_keys']}==keys
    before,after=embedded(report/'before.html','dataset'),embedded(report/'candidate.html','dataset')
    left={(r['pair'],r['bars']):r for r in before['rows']};right={(r['pair'],r['bars']):r for r in after['rows']}
    assert len(left)==len(right)==802 and left.keys()==right.keys()
    assert {key for key in left if left[key]!=right[key]}==keys
    assert embedded(report/'before.html','current-competitor-data')==embedded(report/'candidate.html','current-competitor-data')
    assert len(imported['builder_rows'])==1544
    wins={str(size):sum(r['bars']==size and r['competitor_over_ooples']>1 for r in after['rows']) for size in (1000,10000)}
    assert wins=={'1000':197,'10000':236}
    progress=BACKUP/'current-baseline-ten-refresh-progress-delta-20261116.json'
    delta=read(progress);assert delta['run']==RUN and set(delta['admitted_pairs'])==pairs and delta['quarantined_pairs']==quarantine
    assert delta['production_optimization_credit']==0 and not delta['source_changed']
    assert digest(delta['evidence']['path'])==delta['evidence']['sha256']
    existing=Path(q['archive']).resolve();assert existing.is_relative_to(publisher/'benchmarks/results/remaining-indicators')
    decision=read(existing/'decision.json');assert decision['run_id']==RUN and decision['baseline_refresh_verified'] and not decision['accepted']
    destination=publisher/'benchmarks/results/remaining-indicators'/(NAME+'-report-integration');assert not destination.exists()
    blobs={path.relative_to(report).as_posix():path for path in report.rglob('*') if path.is_file()}
    for name in ('current-baseline-ten-refresh-progress-delta-20261116.json','current-baseline-ten-collector-review-receipt-20261116.json',
        'current-baseline-ten-report-preparer-review-20261116.json','current-baseline-ten-report-guard-receipt-20261116.json'):
        blobs['operations/'+name]=BACKUP/name
    blobs['operations/'+Path(__file__).name]=Path(__file__)
    raw_bytes=sum(path.stat().st_size for path in blobs.values())
    required_free_bytes=2*raw_bytes+128*1024**2
    free_bytes=shutil.disk_usage(publisher).free
    assert free_bytes>required_free_bytes, ('Insufficient bounded package budget',free_bytes,required_free_bytes)
    if args.check_only:
        print(json.dumps(dict(check_only=True,run=RUN,destination=str(destination),changed_rows=18,unchanged_rows=784,
            builders=1544,wins=wins,mixed_historical_gaps_10000=165,package_source_raw_bytes=raw_bytes,
            required_free_bytes=required_free_bytes,available_free_bytes=free_bytes)));return
    destination.mkdir();atomic(destination/'.gitattributes',b'* -text\n')
    manifest={}
    for name,path in sorted(blobs.items()):
        raw=path.read_bytes();target=destination/(name+'.gz');atomic(target,gzip.compress(raw,mtime=0))
        assert gzip.decompress(target.read_bytes())==raw
        manifest[name]=dict(sha256=hashlib.sha256(raw).hexdigest(),archive=target.relative_to(publisher).as_posix())
    save(destination/'manifest.json',manifest)
    packaging=dict(status='report-only-integration-packaged',run_id=RUN,tooling_head=HEAD,report_sha256=REPORT,
        imported_json_sha256=digest(report/'imported.json'),browser_receipt_sha256=digest(report/'browser-verification.json'),
        admitted_pairs=sorted(pairs),quarantined_pairs=quarantine,changed_baseline_rows=18,unchanged_baseline_rows=784,
        unchanged_builder_comparisons=1544,report_point_wins=wins,mixed_historical_point_gaps_10000=165,
        package_source_raw_bytes=raw_bytes,required_free_bytes=required_free_bytes,available_free_bytes_at_start=free_bytes,
        full_current_gap_count_established=False,production_optimization_credit=0,production_qualification=False,
        source_and_harness_changed=False,committed=False,pushed=False)
    save(destination/'packaging.json',packaging)
    decision.update(report_imported=True,report_sha256=REPORT,report_archive=destination.relative_to(publisher).as_posix(),existing_production_retained=True)
    save(existing/'decision.json',decision)
    latest=read(checkpoint);own=latest['performance_continuation_20261103'][NAME];assert own['run_id']==RUN and own['tooling_head']==HEAD
    own.update(report_imported=True,report_sha256=REPORT,report_archive=str(destination),report_point_wins=wins,
        mixed_historical_point_gaps_10000=165,full_current_gap_count_established=False,production_optimization_credit=0,
        status='Actual18-row report import packaged; source/harness unchanged; parent commit/publication pending')
    save(checkpoint,latest);atomic(BACKUP/checkpoint.name,checkpoint.read_bytes())
    save(BACKUP/'current-baseline-ten-report-packaging-20261116.json',packaging)
    print(json.dumps(packaging))


if __name__=='__main__':main()
