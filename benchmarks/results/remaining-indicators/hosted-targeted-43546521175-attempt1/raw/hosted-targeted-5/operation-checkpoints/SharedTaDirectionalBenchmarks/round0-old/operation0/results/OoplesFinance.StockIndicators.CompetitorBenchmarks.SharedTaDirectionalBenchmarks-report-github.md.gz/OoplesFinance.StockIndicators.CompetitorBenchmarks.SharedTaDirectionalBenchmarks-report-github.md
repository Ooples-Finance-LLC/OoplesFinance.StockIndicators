```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **278.9 μs** | **11.85 μs** |  **7.05 μs** |       **-** |  **65.19 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   265.8 μs |  4.79 μs |  2.85 μs |       - |  17.59 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **3,311.1 μs** | **38.52 μs** | **22.92 μs** | **31.2500** | **630.74 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 3,264.7 μs | 10.99 μs |  5.75 μs |       - | 161.02 KB |
