```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **231.88 μs** |  **3.860 μs** |  **2.019 μs** | **19.70** |    **0.18** |       **-** |       **-** |  **65.08 KB** |        **8.60** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   227.15 μs |  3.456 μs |  2.286 μs | 19.29 |    0.20 |       - |       - |  17.48 KB |        2.31 |
| NativeSingle      | TaLib.Functions.Adx | 1000  |    11.77 μs |  0.080 μs |  0.047 μs |  1.00 |    0.01 |  0.4272 |       - |   7.57 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 1000  |    88.66 μs |  1.703 μs |  1.013 μs |  7.53 |    0.09 |  1.9531 |       - |  26.71 KB |        3.53 |
|                   |                     |       |             |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **3,023.15 μs** | **23.524 μs** | **13.999 μs** | **25.90** |    **0.27** | **31.2500** | **15.6250** | **630.62 KB** |        **8.10** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 3,003.26 μs | 84.702 μs | 50.405 μs | 25.73 |    0.48 |       - |       - | 160.79 KB |        2.06 |
| NativeSingle      | TaLib.Functions.Adx | 10000 |   116.74 μs |  1.777 μs |  1.175 μs |  1.00 |    0.01 |  3.9063 |       - |  77.89 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 10000 |   218.38 μs | 13.389 μs |  8.856 μs |  1.87 |    0.07 | 17.5781 |  3.9063 | 272.82 KB |        3.50 |
