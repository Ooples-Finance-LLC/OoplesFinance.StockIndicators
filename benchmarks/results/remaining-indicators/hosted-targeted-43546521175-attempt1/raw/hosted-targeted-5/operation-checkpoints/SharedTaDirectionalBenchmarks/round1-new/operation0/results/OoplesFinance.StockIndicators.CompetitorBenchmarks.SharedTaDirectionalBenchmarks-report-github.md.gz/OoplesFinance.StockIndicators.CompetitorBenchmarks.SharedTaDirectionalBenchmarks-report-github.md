```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |-------------------- |------ |-----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **228.1 μs** |   **2.46 μs** |  **1.28 μs** |       **-** |       **-** |  **65.08 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   222.3 μs |   0.68 μs |  0.36 μs |       - |       - |  17.48 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **3,023.9 μs** | **111.68 μs** | **73.87 μs** | **31.2500** | **15.6250** | **630.64 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 2,983.8 μs | 102.80 μs | 68.00 μs |       - |       - | 160.81 KB |
