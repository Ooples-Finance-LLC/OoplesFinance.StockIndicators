```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean        | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |------------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adx** |   **336.82 μs** |  **4.740 μs** |  **2.479 μs** |  **1.00** |  **105.76 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adx |    17.53 μs |  0.834 μs |  0.552 μs |  0.05 |   37.93 KB |        0.36 |
|            |       |                     |             |           |           |       |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adx** | **3,189.77 μs** | **24.022 μs** | **15.889 μs** |  **1.00** | **1036.74 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adx |   164.96 μs |  1.725 μs |  0.902 μs |  0.05 |  327.31 KB |        0.32 |
