```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Ema**       | **1000**  |  **55.32 μs** | **3.036 μs** | **1.588 μs** |  **1.9531** |       **-** |   **56.7 KB** |
| BuilderLatestOnly | Ema       | 1000  |  31.29 μs | 0.215 μs | 0.113 μs |  0.4883 |       - |   8.85 KB |
| **BuilderFull**       | **Ema**       | **10000** | **297.88 μs** | **1.182 μs** | **0.618 μs** | **33.2031** | **13.6719** | **549.25 KB** |
| BuilderLatestOnly | Ema       | 10000 | 283.24 μs | 0.721 μs | 0.377 μs |  3.9063 |       - |  79.18 KB |
