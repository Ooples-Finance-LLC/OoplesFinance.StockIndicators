```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |---------- |------ |-----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **Ema**       | **1000**  |  **58.180 μs** | **2.6698 μs** | **1.7659 μs** | **18.48** |    **0.55** |  **1.9531** |       **-** |  **56.78 KB** |        **7.36** |
| BuilderLatestOnly | Ema       | 1000  |  31.385 μs | 0.1558 μs | 0.0815 μs |  9.97 |    0.08 |  0.4883 |       - |   8.85 KB |        1.15 |
| NativeSingle      | Ema       | 1000  |   3.149 μs | 0.0375 μs | 0.0248 μs |  1.00 |    0.01 |  0.4578 |       - |   7.72 KB |        1.00 |
| NativeParallel    | Ema       | 1000  |  88.667 μs | 1.0591 μs | 0.7005 μs | 28.16 |    0.30 |  0.4883 |       - |   7.99 KB |        1.03 |
|                   |           |       |            |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **Ema**       | **10000** | **291.489 μs** | **2.4860 μs** | **1.4794 μs** |  **9.92** |    **0.05** | **33.2031** | **13.6719** | **549.29 KB** |        **7.04** |
| BuilderLatestOnly | Ema       | 10000 | 279.357 μs | 1.9334 μs | 1.0112 μs |  9.51 |    0.04 |  3.9063 |       - |  79.18 KB |        1.01 |
| NativeSingle      | Ema       | 10000 |  29.384 μs | 0.1435 μs | 0.0854 μs |  1.00 |    0.00 |  4.6387 |  0.7324 |  78.03 KB |        1.00 |
| NativeParallel    | Ema       | 10000 | 118.459 μs | 3.9090 μs | 2.5855 μs |  4.03 |    0.08 |  3.9063 |       - |   78.3 KB |        1.00 |
