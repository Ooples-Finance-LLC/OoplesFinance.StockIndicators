```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Ema**       | **1000**  |  **55.36 μs** | **2.327 μs** | **1.385 μs** |  **1.9531** |       **-** |  **56.74 KB** |
| BuilderLatestOnly | Ema       | 1000  |  31.40 μs | 0.243 μs | 0.127 μs |  0.4883 |       - |   8.85 KB |
| **BuilderFull**       | **Ema**       | **10000** | **297.63 μs** | **2.162 μs** | **1.287 μs** | **33.2031** | **13.6719** | **549.29 KB** |
| BuilderLatestOnly | Ema       | 10000 | 284.46 μs | 2.385 μs | 1.248 μs |  3.9063 |       - |  79.18 KB |
