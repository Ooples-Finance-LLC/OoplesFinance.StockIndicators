```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ema** | **309.962 μs** | **9.3449 μs** | **4.8876 μs** |  **1.00** |    **0.02** |  **64.84 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ema |   6.030 μs | 1.1111 μs | 0.7349 μs |  0.02 |    0.00 |  18.64 KB |        0.29 |
|            |       |                     |            |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ema** | **408.663 μs** | **1.7522 μs** | **0.9164 μs** |  **1.00** |    **0.00** |  **634.8 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ema |  37.250 μs | 0.5111 μs | 0.3041 μs |  0.09 |    0.00 | 164.47 KB |        0.26 |
