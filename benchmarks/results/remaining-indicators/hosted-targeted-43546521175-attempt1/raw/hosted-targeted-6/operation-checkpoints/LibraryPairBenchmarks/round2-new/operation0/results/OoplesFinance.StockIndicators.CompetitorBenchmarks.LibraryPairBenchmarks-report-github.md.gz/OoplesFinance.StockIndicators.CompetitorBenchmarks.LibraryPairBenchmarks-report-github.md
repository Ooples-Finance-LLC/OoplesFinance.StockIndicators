```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adxr** |   **466.44 μs** | **34.806 μs** | **23.022 μs** |  **1.00** |    **0.07** | **106.83 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adxr |    23.70 μs |  0.730 μs |  0.382 μs |  0.05 |    0.00 |  48.45 KB |        0.45 |
|            |       |                      |             |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adxr** | **4,405.82 μs** | **22.252 μs** | **13.242 μs** |  **1.00** |    **0.00** | **1039.5 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adxr |   233.03 μs |  9.907 μs |  5.895 μs |  0.05 |    0.00 | 408.48 KB |        0.39 |
