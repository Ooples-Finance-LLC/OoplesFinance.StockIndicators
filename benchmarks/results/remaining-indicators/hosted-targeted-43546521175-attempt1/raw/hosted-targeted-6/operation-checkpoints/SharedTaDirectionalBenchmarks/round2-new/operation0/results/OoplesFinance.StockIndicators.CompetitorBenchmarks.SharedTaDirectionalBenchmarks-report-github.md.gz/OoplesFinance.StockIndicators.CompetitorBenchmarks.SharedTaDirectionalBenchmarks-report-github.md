```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **396.65 μs** |  **9.586 μs** |  **5.705 μs** | **23.31** |    **0.39** |       **-** |      **-** |  **66.16 KB** |        **4.41** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   382.00 μs |  1.682 μs |  1.001 μs | 22.45 |    0.22 |       - |      - |  18.55 KB |        1.24 |
| NativeSingle      | TaLib.Functions.Adxr | 1000  |    17.02 μs |  0.288 μs |  0.172 μs |  1.00 |    0.01 |  0.8545 |      - |  14.99 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 1000  |   107.01 μs |  4.435 μs |  2.933 μs |  6.29 |    0.17 |  2.9297 |      - |  45.44 KB |        3.03 |
|                   |                      |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **4,066.71 μs** | **13.544 μs** |  **7.084 μs** | **23.58** |    **0.25** | **31.2500** |      **-** | **631.84 KB** |        **4.06** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 4,034.16 μs | 24.410 μs | 14.526 μs | 23.39 |    0.26 |       - |      - | 162.02 KB |        1.04 |
| NativeSingle      | TaLib.Functions.Adxr | 10000 |   172.49 μs |  3.238 μs |  1.927 μs |  1.00 |    0.01 |  8.7891 | 0.9766 | 155.63 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 10000 |   315.94 μs | 11.019 μs |  6.557 μs |  1.83 |    0.04 | 29.2969 | 9.7656 | 467.32 KB |        3.00 |
