```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **427.4 μs** |  **3.43 μs** |  **1.79 μs** |       **-** |  **66.26 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   428.9 μs | 17.88 μs | 11.83 μs |       - |  18.67 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **4,591.6 μs** | **28.89 μs** | **15.11 μs** | **31.2500** | **631.96 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 4,440.5 μs | 19.11 μs | 12.64 μs |       - | 162.12 KB |
