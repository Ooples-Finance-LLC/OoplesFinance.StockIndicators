```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **417.0 μs** |  **1.74 μs** |  **0.91 μs** |       **-** |  **66.16 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   396.2 μs |  2.70 μs |  1.61 μs |       - |  18.57 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **4,144.6 μs** | **29.91 μs** | **15.64 μs** | **31.2500** | **631.85 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 4,131.5 μs | 31.61 μs | 18.81 μs |       - | 162.02 KB |
