```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **448.2 μs** |   **6.70 μs** |  **3.50 μs** |       **-** |  **66.26 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   440.2 μs |   2.74 μs |  1.43 μs |       - |  18.67 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **4,702.5 μs** | **143.52 μs** | **94.93 μs** | **31.2500** | **631.92 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 4,601.9 μs |  27.81 μs | 14.55 μs |       - | 162.12 KB |
