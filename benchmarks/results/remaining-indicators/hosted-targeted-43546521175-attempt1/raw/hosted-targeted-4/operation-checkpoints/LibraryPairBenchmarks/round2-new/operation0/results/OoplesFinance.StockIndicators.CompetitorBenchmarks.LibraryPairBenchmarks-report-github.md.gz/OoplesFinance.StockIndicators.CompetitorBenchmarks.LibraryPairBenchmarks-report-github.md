```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean        | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |------------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Dx** |   **309.89 μs** |  **38.135 μs** |  **25.224 μs** |  **1.01** |    **0.11** |  **105.54 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Dx |    16.92 μs |   2.633 μs |   1.567 μs |  0.05 |    0.01 |   33.71 KB |        0.32 |
|            |       |                    |             |            |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Dx** | **2,883.45 μs** | **194.043 μs** | **128.348 μs** |  **1.00** |    **0.06** | **1033.31 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Dx |   130.59 μs |  10.486 μs |   5.484 μs |  0.05 |    0.00 |   328.3 KB |        0.32 |
