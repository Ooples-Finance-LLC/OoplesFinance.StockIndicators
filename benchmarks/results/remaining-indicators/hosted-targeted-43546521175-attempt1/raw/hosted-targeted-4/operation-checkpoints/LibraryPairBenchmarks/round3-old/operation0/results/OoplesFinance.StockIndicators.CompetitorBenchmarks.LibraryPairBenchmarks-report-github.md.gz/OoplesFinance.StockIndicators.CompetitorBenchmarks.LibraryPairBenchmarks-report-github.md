```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId             | Mean       | Error    | StdDev  | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |------------------- |-----------:|---------:|--------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Dx** |   **289.8 μs** | **15.93 μs** | **9.48 μs** |  **1.00** |    **0.04** |  **105.64 KB** |        **1.00** |
|        |       |                    |            |          |         |       |         |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Dx** | **2,789.7 μs** | **11.71 μs** | **6.97 μs** |  **1.00** |    **0.00** | **1029.48 KB** |        **1.00** |
