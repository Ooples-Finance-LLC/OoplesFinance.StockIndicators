```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **212.6 μs** |  **5.10 μs** |  **3.38 μs** |  **3.9063** |  **64.86 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   214.6 μs |  7.10 μs |  4.70 μs |       - |  17.26 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **2,414.0 μs** | **21.04 μs** | **13.92 μs** | **31.2500** | **627.84 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 2,500.4 μs | 81.13 μs | 53.66 μs |       - | 158.01 KB |
