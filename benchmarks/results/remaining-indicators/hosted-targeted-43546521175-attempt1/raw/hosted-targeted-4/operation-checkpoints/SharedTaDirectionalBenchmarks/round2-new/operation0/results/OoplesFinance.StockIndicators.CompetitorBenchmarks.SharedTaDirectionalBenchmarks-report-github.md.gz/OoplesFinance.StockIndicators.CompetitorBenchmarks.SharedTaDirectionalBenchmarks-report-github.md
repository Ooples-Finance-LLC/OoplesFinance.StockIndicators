```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **222.55 μs** | **17.457 μs** |  **9.130 μs** | **21.40** |    **0.85** |  **3.9063** |      **-** |  **64.86 KB** |        **8.40** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   221.37 μs |  6.324 μs |  4.183 μs | 21.28 |    0.43 |       - |      - |  17.26 KB |        2.24 |
| NativeSingle      | TaLib.Functions.Dx | 1000  |    10.40 μs |  0.153 μs |  0.101 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 1000  |    75.04 μs |  2.878 μs |  1.904 μs |  7.21 |    0.19 |  1.4648 |      - |  27.25 KB |        3.53 |
|                   |                    |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **2,472.24 μs** | **64.370 μs** | **38.306 μs** | **23.06** |    **0.56** | **31.2500** |      **-** | **627.78 KB** |        **8.05** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 2,424.29 μs | 76.214 μs | 45.354 μs | 22.61 |    0.59 |       - |      - | 157.93 KB |        2.02 |
| NativeSingle      | TaLib.Functions.Dx | 10000 |   107.25 μs |  3.251 μs |  2.150 μs |  1.00 |    0.03 |  3.9063 |      - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 10000 |   185.09 μs |  3.809 μs |  2.267 μs |  1.73 |    0.04 | 17.5781 | 3.9063 | 273.34 KB |        3.50 |
