```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **254.6 μs** |  **2.37 μs** |  **1.24 μs** |       **-** |  **64.97 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   249.9 μs |  3.32 μs |  1.74 μs |       - |  17.36 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **2,713.8 μs** | **44.91 μs** | **26.73 μs** | **31.2500** | **627.87 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 2,673.0 μs | 61.79 μs | 40.87 μs |       - | 158.03 KB |
