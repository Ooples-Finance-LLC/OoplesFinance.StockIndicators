```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |-----------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.T3** | **1000**  | **123.777 μs** |  **6.4932 μs** |  **4.2949 μs** | **38.61** |    **1.29** |  **3.9063** |       **-** |  **65.25 KB** |        **9.35** |
| BuilderLatestOnly | TaLib.Functions.T3 | 1000  | 121.243 μs |  0.8904 μs |  0.5299 μs | 37.82 |    0.21 |  0.9766 |       - |  17.64 KB |        2.53 |
| NativeSingle      | TaLib.Functions.T3 | 1000  |   3.206 μs |  0.0213 μs |  0.0127 μs |  1.00 |    0.01 |  0.3967 |       - |   6.98 KB |        1.00 |
| NativeParallel    | TaLib.Functions.T3 | 1000  |  80.090 μs |  0.6532 μs |  0.3887 μs | 24.99 |    0.15 |  1.4648 |       - |  24.66 KB |        3.53 |
|                   |                    |       |            |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.T3** | **10000** | **794.738 μs** | **40.5195 μs** | **26.8011 μs** | **24.23** |    **0.94** | **35.1563** | **11.7188** | **630.74 KB** |        **8.16** |
| BuilderLatestOnly | TaLib.Functions.T3 | 10000 | 784.176 μs | 30.3089 μs | 20.0475 μs | 23.91 |    0.78 | 35.1563 | 15.6250 | 630.06 KB |        8.15 |
| NativeSingle      | TaLib.Functions.T3 | 10000 |  32.818 μs |  1.3074 μs |  0.7780 μs |  1.00 |    0.03 |  4.6387 |       - |  77.29 KB |        1.00 |
| NativeParallel    | TaLib.Functions.T3 | 10000 | 119.280 μs |  4.4518 μs |  2.6492 μs |  3.64 |    0.11 | 17.5781 |  3.9063 | 270.76 KB |        3.50 |
