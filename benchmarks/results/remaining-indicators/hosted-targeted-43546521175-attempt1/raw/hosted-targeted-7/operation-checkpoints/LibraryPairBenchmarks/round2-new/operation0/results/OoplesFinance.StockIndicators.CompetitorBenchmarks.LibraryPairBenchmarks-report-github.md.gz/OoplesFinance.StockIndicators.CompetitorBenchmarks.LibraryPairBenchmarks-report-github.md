```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean         | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-------------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.T3** |   **200.700 μs** | **14.8422 μs** |  **9.8172 μs** |  **1.00** |    **0.07** |  **105.92 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.T3 |     6.850 μs |  0.5110 μs |  0.2673 μs |  0.03 |    0.00 |   39.19 KB |        0.37 |
|            |       |                    |              |            |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.T3** | **1,081.144 μs** | **30.2354 μs** | **17.9926 μs** |  **1.00** |    **0.02** | **1038.31 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.T3 |    53.663 μs |  3.2462 μs |  1.6978 μs |  0.05 |    0.00 |  329.32 KB |        0.32 |
