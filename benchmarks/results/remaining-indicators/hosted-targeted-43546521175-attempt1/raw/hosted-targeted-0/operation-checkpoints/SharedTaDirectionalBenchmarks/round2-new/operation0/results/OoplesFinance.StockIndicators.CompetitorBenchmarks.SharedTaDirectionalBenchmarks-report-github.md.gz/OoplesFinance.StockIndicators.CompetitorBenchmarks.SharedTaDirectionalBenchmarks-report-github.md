```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |  **64.841 μs** | **0.8879 μs** | **0.4644 μs** |  **6.96** |    **0.06** |  **3.9063** |       **-** |  **64.86 KB** |        **8.40** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |  62.354 μs | 0.2242 μs | 0.1173 μs |  6.69 |    0.03 |  0.9766 |       - |  17.25 KB |        2.24 |
| NativeSingle      | TaLib(...)lusDM [22] | 1000  |   9.323 μs | 0.0667 μs | 0.0442 μs |  1.00 |    0.01 |  0.4272 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 1000  |  86.587 μs | 1.7372 μs | 1.1491 μs |  9.29 |    0.12 |  1.9531 |       - |  27.23 KB |        3.53 |
|                   |                      |       |            |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **722.039 μs** | **4.0169 μs** | **2.3904 μs** |  **7.94** |    **0.03** | **35.1563** | **15.6250** | **627.73 KB** |        **8.04** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 696.957 μs | 3.4542 μs | 2.0556 μs |  7.67 |    0.03 |  7.8125 |       - | 157.91 KB |        2.02 |
| NativeSingle      | TaLib(...)lusDM [22] | 10000 |  90.909 μs | 0.4386 μs | 0.2610 μs |  1.00 |    0.00 |  4.3945 |       - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 10000 | 177.086 μs | 5.0566 μs | 3.3446 μs |  1.95 |    0.04 | 17.5781 |  2.9297 | 273.33 KB |        3.50 |
