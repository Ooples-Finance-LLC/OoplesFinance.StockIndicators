```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |  **92.88 μs** | **1.122 μs** | **0.587 μs** |  **3.9063** |      **-** |  **64.97 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |  88.70 μs | 1.825 μs | 1.086 μs |  0.9766 |      - |  17.35 KB |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **974.24 μs** | **6.197 μs** | **3.241 μs** | **31.2500** | **7.8125** | **627.85 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 947.17 μs | 7.264 μs | 3.799 μs |  7.8125 |      - | 158.04 KB |
