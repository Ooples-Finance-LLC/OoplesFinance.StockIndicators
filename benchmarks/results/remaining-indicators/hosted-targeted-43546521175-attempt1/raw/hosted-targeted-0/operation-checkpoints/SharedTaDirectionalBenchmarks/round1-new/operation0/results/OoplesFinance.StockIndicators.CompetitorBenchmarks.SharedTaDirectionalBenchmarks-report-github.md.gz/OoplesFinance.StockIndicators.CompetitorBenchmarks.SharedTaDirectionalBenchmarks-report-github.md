```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |  **64.68 μs** |  **3.185 μs** |  **2.107 μs** |  **3.9063** |       **-** |  **64.86 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |  61.79 μs |  0.702 μs |  0.418 μs |  0.9766 |       - |  17.25 KB |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **714.65 μs** | **19.294 μs** | **11.482 μs** | **35.1563** | **15.6250** | **627.72 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 694.67 μs |  6.070 μs |  3.175 μs |  7.8125 |       - |  157.9 KB |
