```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDM [22]** | **379.88 μs** |  **3.143 μs** |  **1.644 μs** |  **1.00** |    **0.01** |  **105.58 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDM [22] |  15.50 μs |  2.209 μs |  1.314 μs |  0.04 |    0.00 |   39.56 KB |        0.37 |
|            |       |                      |           |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDM [22]** | **910.38 μs** | **28.048 μs** | **16.691 μs** |  **1.00** |    **0.02** | **1035.28 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDM [22] | 139.86 μs |  3.369 μs |  1.762 μs |  0.15 |    0.00 |  328.99 KB |        0.32 |
