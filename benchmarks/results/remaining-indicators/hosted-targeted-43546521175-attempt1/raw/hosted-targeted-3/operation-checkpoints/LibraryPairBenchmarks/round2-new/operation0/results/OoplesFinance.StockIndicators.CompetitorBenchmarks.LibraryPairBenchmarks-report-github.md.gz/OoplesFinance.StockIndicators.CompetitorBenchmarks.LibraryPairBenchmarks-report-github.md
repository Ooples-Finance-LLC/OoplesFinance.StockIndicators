```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDI [23]** |   **186.44 μs** |  **4.065 μs** |  **2.126 μs** |  **1.00** |    **0.02** |  **105.54 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDI [23] |    13.12 μs |  2.781 μs |  1.655 μs |  0.07 |    0.01 |   39.24 KB |        0.37 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDI [23]** | **1,619.91 μs** | **21.153 μs** | **12.588 μs** |  **1.00** |    **0.01** | **1034.25 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDI [23] |   114.19 μs |  2.546 μs |  1.331 μs |  0.07 |    0.00 |  330.92 KB |        0.32 |
