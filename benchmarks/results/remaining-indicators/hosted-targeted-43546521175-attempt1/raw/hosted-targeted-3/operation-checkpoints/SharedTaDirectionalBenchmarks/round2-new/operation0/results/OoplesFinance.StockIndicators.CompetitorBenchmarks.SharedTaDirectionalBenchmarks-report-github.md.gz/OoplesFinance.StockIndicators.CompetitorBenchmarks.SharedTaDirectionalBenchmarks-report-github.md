```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **112.919 μs** |  **1.7559 μs** |  **1.0449 μs** | **18.29** |    **0.23** |  **3.9063** |      **-** |  **64.86 KB** |        **8.40** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   109.118 μs |  0.4301 μs |  0.2559 μs | 17.68 |    0.17 |  0.9766 |      - |  17.26 KB |        2.24 |
| NativeSingle      | TaLib(...)nusDI [23] | 1000  |     6.173 μs |  0.1006 μs |  0.0599 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 1000  |    83.526 μs |  0.9551 μs |  0.4995 μs | 13.53 |    0.15 |  1.4648 |      - |  27.25 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **1,435.737 μs** | **22.3841 μs** | **13.3204 μs** | **24.07** |    **0.25** | **31.2500** | **7.8125** | **627.75 KB** |        **8.04** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 1,422.705 μs |  3.3925 μs |  1.7743 μs | 23.85 |    0.13 |  7.8125 |      - | 157.93 KB |        2.02 |
| NativeSingle      | TaLib(...)nusDI [23] | 10000 |    59.652 μs |  0.5595 μs |  0.3330 μs |  1.00 |    0.01 |  4.3945 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 10000 |   146.786 μs |  4.8789 μs |  3.2271 μs |  2.46 |    0.05 | 17.5781 | 2.9297 | 273.34 KB |        3.50 |
