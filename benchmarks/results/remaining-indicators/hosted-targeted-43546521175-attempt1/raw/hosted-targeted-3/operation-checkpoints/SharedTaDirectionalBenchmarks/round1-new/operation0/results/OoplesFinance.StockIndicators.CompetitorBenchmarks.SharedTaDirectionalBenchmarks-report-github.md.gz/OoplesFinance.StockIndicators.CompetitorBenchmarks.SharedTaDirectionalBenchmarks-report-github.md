```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **112.4 μs** |  **1.07 μs** |  **0.64 μs** |  **3.9063** |      **-** |  **64.86 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   110.1 μs |  2.02 μs |  1.06 μs |  0.9766 |      - |  17.26 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **1,429.4 μs** |  **7.44 μs** |  **3.89 μs** | **31.2500** | **7.8125** | **627.75 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 1,417.2 μs | 22.09 μs | 14.61 μs |  7.8125 |      - | 157.93 KB |
