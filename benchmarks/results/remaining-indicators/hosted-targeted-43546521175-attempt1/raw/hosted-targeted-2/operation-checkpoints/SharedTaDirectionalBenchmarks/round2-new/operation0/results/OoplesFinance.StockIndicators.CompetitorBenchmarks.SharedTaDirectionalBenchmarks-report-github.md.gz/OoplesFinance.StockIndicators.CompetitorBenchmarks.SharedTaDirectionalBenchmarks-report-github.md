```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |  **84.727 μs** |  **1.5431 μs** |  **0.8071 μs** | **16.91** |    **0.33** |  **3.9063** |      **-** |  **64.86 KB** |        **8.40** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |  86.267 μs |  4.3930 μs |  2.6142 μs | 17.22 |    0.58 |  0.9766 |      - |  17.25 KB |        2.24 |
| NativeSingle      | TaLib(...)lusDI [22] | 1000  |   5.011 μs |  0.1391 μs |  0.0920 μs |  1.00 |    0.02 |  0.4578 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 1000  |  95.963 μs | 15.1274 μs | 10.0059 μs | 19.16 |    1.93 |  0.9766 |      - |  27.25 KB |        3.53 |
|                   |                      |       |            |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **970.936 μs** | **30.4416 μs** | **20.1353 μs** | **19.68** |    **0.62** | **31.2500** | **7.8125** | **627.73 KB** |        **8.04** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 975.208 μs | 21.5556 μs | 14.2577 μs | 19.76 |    0.56 |  7.8125 |      - | 157.92 KB |        2.02 |
| NativeSingle      | TaLib(...)lusDI [22] | 10000 |  49.372 μs |  2.1784 μs |  1.2963 μs |  1.00 |    0.03 |  4.3945 |      - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 10000 | 155.943 μs |  4.8389 μs |  2.5308 μs |  3.16 |    0.09 | 17.5781 | 2.9297 | 273.34 KB |        3.50 |
