```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |------------:|----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |    **86.64 μs** |  **1.881 μs** |  **1.119 μs** |  **3.9063** |      **-** |  **64.86 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |    86.54 μs |  3.309 μs |  2.189 μs |  0.9766 |      - |  17.25 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **1,046.68 μs** | **59.682 μs** | **39.476 μs** | **31.2500** | **7.8125** | **627.75 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 1,030.01 μs |  5.639 μs |  2.949 μs |  7.8125 |      - | 157.92 KB |
