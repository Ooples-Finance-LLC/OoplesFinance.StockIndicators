```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **125.1 μs** |  **2.81 μs** |  **1.47 μs** |  **3.9063** |      **-** |  **64.97 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   116.5 μs |  3.53 μs |  2.10 μs |  0.9766 |      - |  17.36 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **1,195.4 μs** | **22.35 μs** | **13.30 μs** | **31.2500** | **7.8125** | **627.85 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 1,175.8 μs | 24.10 μs | 15.94 μs |  7.8125 |      - |    158 KB |
