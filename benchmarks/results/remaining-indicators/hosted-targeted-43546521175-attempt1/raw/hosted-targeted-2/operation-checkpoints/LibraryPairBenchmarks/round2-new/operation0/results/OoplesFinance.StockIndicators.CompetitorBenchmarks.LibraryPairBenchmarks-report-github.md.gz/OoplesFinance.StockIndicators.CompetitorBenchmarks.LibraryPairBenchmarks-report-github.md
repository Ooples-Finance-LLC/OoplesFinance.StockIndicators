```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean         | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-------------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDI [22]** |   **133.525 μs** |  **4.9467 μs** |  **2.5872 μs** |  **1.00** |    **0.03** |  **105.55 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDI [22] |     9.811 μs |  0.9335 μs |  0.5555 μs |  0.07 |    0.00 |   38.96 KB |        0.37 |
|            |       |                      |              |            |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDI [22]** | **1,170.739 μs** | **21.5739 μs** | **12.8383 μs** |  **1.00** |    **0.01** | **1035.86 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDI [22] |   110.630 μs | 18.3033 μs | 12.1065 μs |  0.09 |    0.01 |  328.63 KB |        0.32 |
