```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev   | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|---------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |  **91.46 μs** |  **1.003 μs** | **0.525 μs** |  **9.06** |    **0.07** |  **3.9063** |      **-** |  **64.82 KB** |        **8.40** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |  88.89 μs |  1.129 μs | 0.591 μs |  8.81 |    0.07 |  0.9766 |      - |  17.26 KB |        2.24 |
| NativeSingle      | TaLib(...)nusDM [23] | 1000  |  10.09 μs |  0.092 μs | 0.061 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 1000  |  97.21 μs |  2.341 μs | 1.549 μs |  9.63 |    0.16 |  1.9531 |      - |  27.23 KB |        3.53 |
|                   |                      |       |           |           |          |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **976.95 μs** |  **4.725 μs** | **3.125 μs** |  **9.64** |    **0.06** | **31.2500** | **7.8125** | **627.73 KB** |        **8.04** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 957.22 μs | 11.520 μs | 6.856 μs |  9.45 |    0.08 |  7.8125 |      - | 157.95 KB |        2.02 |
| NativeSingle      | TaLib(...)nusDM [23] | 10000 | 101.33 μs |  0.859 μs | 0.568 μs |  1.00 |    0.01 |  3.9063 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 10000 | 202.28 μs |  8.206 μs | 5.428 μs |  2.00 |    0.05 | 17.5781 | 3.9063 | 273.34 KB |        3.50 |
