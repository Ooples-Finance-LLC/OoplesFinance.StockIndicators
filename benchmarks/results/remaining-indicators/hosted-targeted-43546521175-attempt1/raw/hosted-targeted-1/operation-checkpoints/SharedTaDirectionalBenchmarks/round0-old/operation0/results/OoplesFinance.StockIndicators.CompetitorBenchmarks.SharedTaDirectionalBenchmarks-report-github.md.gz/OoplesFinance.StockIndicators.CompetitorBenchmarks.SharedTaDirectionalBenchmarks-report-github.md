```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **142.9 μs** |  **7.45 μs** |  **4.93 μs** |  **3.9063** |      **-** |  **64.97 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   138.4 μs |  0.57 μs |  0.34 μs |       - |      - |  17.37 KB |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,346.0 μs** |  **5.51 μs** |  **3.65 μs** | **31.2500** | **7.8125** | **627.87 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 1,327.9 μs | 31.50 μs | 18.75 μs |  7.8125 |      - | 158.05 KB |
