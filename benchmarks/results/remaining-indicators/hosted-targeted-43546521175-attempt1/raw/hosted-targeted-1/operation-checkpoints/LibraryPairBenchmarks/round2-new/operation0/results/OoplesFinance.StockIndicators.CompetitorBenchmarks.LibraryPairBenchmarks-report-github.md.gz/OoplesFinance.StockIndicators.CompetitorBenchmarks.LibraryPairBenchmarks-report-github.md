```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDM [23]** |   **188.93 μs** | **16.117 μs** |  **9.591 μs** |  **1.00** |    **0.07** |  **105.54 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDM [23] |    15.72 μs |  1.850 μs |  1.101 μs |  0.08 |    0.01 |   40.27 KB |        0.38 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDM [23]** | **1,195.18 μs** | **29.812 μs** | **19.719 μs** |  **1.00** |    **0.02** | **1036.88 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDM [23] |   153.61 μs |  7.763 μs |  4.060 μs |  0.13 |    0.00 |  330.59 KB |        0.32 |
