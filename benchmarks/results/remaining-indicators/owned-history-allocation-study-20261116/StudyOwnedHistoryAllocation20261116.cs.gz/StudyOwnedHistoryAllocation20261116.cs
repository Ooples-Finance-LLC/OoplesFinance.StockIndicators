using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text.Json;

public static class StudyOwnedHistoryAllocation20261116
{
    private sealed class Snapshot<T> where T : struct
    {
        public readonly T[][] Chunks;
        public readonly double[] Values;
        public Snapshot(T[] source, int count, int layout)
        {
            int chunkSize = layout == 1 ? count : 1024;
            Chunks = new T[(count + chunkSize - 1) / chunkSize][];
            for (int i = 0, offset = 0; i < Chunks.Length; i++)
            {
                int length = Math.Min(chunkSize, count - offset);
                var chunk = GC.AllocateUninitializedArray<T>(length, pinned: layout == 2);
                Array.Copy(source, offset, chunk, 0, length);
                Chunks[i] = chunk;
                offset += length;
            }
            // Match one value column plus the independently owned comparison copy.
            var output = GC.AllocateUninitializedArray<double>(count);
            for (int i = 0; i < output.Length; i++) output[i] = i * .125;
            Values = GC.AllocateUninitializedArray<double>(count);
            output.AsSpan().CopyTo(Values);
        }
    }

    private static void RequireSnapshot<T>(Snapshot<T> snapshot, T[] expected, int count) where T : struct
    {
        int offset = 0;
        foreach (var chunk in snapshot.Chunks)
        {
            if (ReferenceEquals(chunk, expected)) throw new Exception("Source alias");
            var actual = MemoryMarshal.AsBytes(chunk.AsSpan());
            var original = MemoryMarshal.AsBytes(expected.AsSpan(offset, chunk.Length));
            if (!actual.SequenceEqual(original)) throw new Exception("History bytes changed");
            offset += chunk.Length;
        }
        if (offset != count || snapshot.Values.Length != count) throw new Exception("History/output count changed");
        for (int i = 0; i < count; i++)
            if (snapshot.Values[i] != i * .125) throw new Exception("Output changed");
    }

    private static object RunPhase<T>(T[] source, int count, int layout, int retained, int round) where T : struct
    {
        var keep = new Snapshot<T>[Math.Max(1, retained)];
        int generation = -1;
        for (int i = 0; i < 128; i++)
        {
            var snapshot = new Snapshot<T>(source, count, layout);
            generation = GC.GetGeneration(snapshot.Chunks[0]);
            keep[i % keep.Length] = snapshot;
        }
        int g0 = GC.CollectionCount(0), g1 = GC.CollectionCount(1), g2 = GC.CollectionCount(2);
        long allocated = GC.GetAllocatedBytesForCurrentThread();
        TimeSpan pause = GC.GetTotalPauseDuration();
        int iterations = 0;
        var clock = Stopwatch.StartNew();
        while (clock.Elapsed.TotalSeconds < 1)
        {
            keep[iterations % keep.Length] = new Snapshot<T>(source, count, layout);
            iterations++;
        }
        double elapsed = clock.Elapsed.TotalMilliseconds;
        long bytes = GC.GetAllocatedBytesForCurrentThread() - allocated;
        double paused = (GC.GetTotalPauseDuration() - pause).TotalMilliseconds;
        int gen0 = GC.CollectionCount(0) - g0, gen1 = GC.CollectionCount(1) - g1, gen2 = GC.CollectionCount(2) - g2;
        foreach (var snapshot in keep) RequireSnapshot(snapshot, source, count);
        var memory = GC.GetGCMemoryInfo();
        GC.KeepAlive(keep);
        return new { count, layout, retained, round, iterations, elapsed_ms = elapsed,
            diagnostic_us_per_iteration = elapsed * 1000 / iterations,
            allocated_bytes_per_iteration = bytes / (double)iterations,
            gen0, gen1, gen2, pause_ms = paused, pause_fraction = paused / elapsed,
            observed_first_chunk_generation = generation,
            heap_size_bytes = memory.HeapSizeBytes, fragmented_bytes = memory.FragmentedBytes,
            total_committed_bytes = memory.TotalCommittedBytes };
    }

    public static string Run<T>(T[] fixture) where T : struct
    {
        if (RuntimeHelpers.IsReferenceOrContainsReferences<T>()) throw new Exception("Pinned candidate requires reference-free bars");
        if (fixture.Length < 10000) throw new Exception("Fixture too short");
        var results = new List<object>();
        int bitwiseCases = 0;
        foreach (int count in new[] { 1, 1000, 1023, 1024, 1025, 10000 })
        {
            var input = fixture.AsSpan(0, count).ToArray();
            var expected = (T[])input.Clone();
            var histories = new List<Snapshot<T>>();
            for (int layout = 0; layout < 3; layout++)
            {
                var saved = new Snapshot<T>(input, count, layout);
                histories.Add(saved);
                RequireSnapshot(saved, expected, count);
                bitwiseCases++;
            }
            Array.Clear(input);
            // Hold earlier snapshots across later independent allocations/source mutation.
            for (int j = 0; j < 32; j++) _ = new Snapshot<T>(fixture, count, j % 3);
            foreach (var history in histories) RequireSnapshot(history, expected, count);
        }
        for (int round = 0; round < 3; round++)
            foreach (int count in new[] { 1000, 10000 })
                foreach (int retained in new[] { 1, 32 })
                    for (int step = 0; step < 3; step++)
                    {
                        int layout = round % 2 == 0 ? step : 2 - step;
                        results.Add(RunPhase(fixture, count, layout, retained, round));
                    }
        return JsonSerializer.Serialize(new { diagnostic_only = true, qualification = false,
            source_type = typeof(T).AssemblyQualifiedName, bar_bytes = Unsafe.SizeOf<T>(),
            reference_free = true, bitwise_cases = bitwiseCases, server_gc = GCSettings.IsServerGC,
            latency_mode = GCSettings.LatencyMode.ToString(), layouts = new[] { "existing-chunks", "contiguous-control", "pinned-chunks" },
            limits = "Component allocation/retention study only. Not full indicator execution, latency qualification, native-win evidence or authority to change history semantics. No forced GC or runtime policy overrides.", results });
    }
}
