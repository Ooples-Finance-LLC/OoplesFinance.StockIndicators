$ErrorActionPreference='Stop'
$taskOps='C:\Users\cheat\source\stock-indicators-operations'
$taskInputs=Join-Path $taskOps 'active-performance-evidence\hosted-runs\43800246247\inputs'
$taskProduction=Join-Path $taskInputs 'production\successor.dll'
$taskRuntime=Join-Path $taskInputs 'common'
$taskExpected='975b5f77568e440225567f6d2acc6e2b4e38e238b232bd1e9ae017513187147a'
if((Get-FileHash -LiteralPath $taskProduction -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskExpected){throw 'Production hash mismatch'}
$taskOut=Join-Path $taskOps 'owned-history-allocation-study-20261116'
[void][IO.Directory]::CreateDirectory($taskOut)
if(Test-Path -LiteralPath (Join-Path $taskOut 'component-results.json')){throw 'Inspect existing study before retrying'}
[Runtime.Loader.AssemblyLoadContext]::Default.add_Resolving([Func[Runtime.Loader.AssemblyLoadContext,Reflection.AssemblyName,Reflection.Assembly]]{param($ctx,$name)
    $candidate=Join-Path $taskRuntime ($name.Name+'.dll')
    if(Test-Path -LiteralPath $candidate){return $ctx.LoadFromAssemblyPath($candidate)}
    return $null
})
$taskProd=[Reflection.Assembly]::LoadFrom($taskProduction)
$taskBench=[Reflection.Assembly]::LoadFrom((Join-Path $taskRuntime 'OoplesFinance.StockIndicators.CompetitorBenchmarks.dll'))
$taskFixtureType=$taskBench.GetType('OoplesFinance.StockIndicators.CompetitorBenchmarks.LibraryPairBenchmarks',$true)
$taskFixture=[Activator]::CreateInstance($taskFixtureType)
$taskFixtureType.GetProperty('PairId').SetValue($taskFixture,'TaLib.Functions.MedPrice')
$taskFixtureType.GetProperty('Bars').SetValue($taskFixture,10000)
[void]$taskFixtureType.GetMethod('Setup').Invoke($taskFixture,@())
$taskFlags=[Reflection.BindingFlags]'Public,NonPublic,Instance'
$taskData=$taskFixtureType.GetField('_data',$taskFlags).GetValue($taskFixture)
$taskBars=$taskData.GetType().GetProperty('IndicatorBars',$taskFlags).GetValue($taskData)
Add-Type -Path (Join-Path $taskOps 'StudyOwnedHistoryAllocation20261116.cs')
$taskRun=[StudyOwnedHistoryAllocation20261116].GetMethod('Run').MakeGenericMethod($taskProd.GetType('OoplesFinance.StockIndicators.Indicators.Bar',$true))
$taskResult=$taskRun.Invoke($null,[object[]]@((,$taskBars)))
[IO.File]::WriteAllText((Join-Path $taskOut 'component-results.json'),$taskResult)
if((Get-FileHash -LiteralPath $taskProduction -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskExpected){throw 'Production changed'}
Write-Output 'Component allocation and retention study complete'
