"""Preserve a screened-out component study without checking out historical artifacts."""
import collections,datetime,gzip,hashlib,json,os,statistics,subprocess
from pathlib import Path
ops=Path(__file__).parent
checkpoint=ops/'continuation-latest-20261028.json';data=json.loads(checkpoint.read_text())
store=Path(data['stable_git_store_for_future_batches']);baseline='bde045026cb0a490dfdbd2f73a727547dc48cf29'
study=ops/'owned-history-allocation-study-20261116';results=json.loads((study/'component-results.json').read_text())
assert results['reference_free'] and results['bitwise_cases']==18 and len(results['results'])==36
grouped=collections.defaultdict(list)
for row in results['results']:grouped[row['count'],row['retained'],row['layout']].append(row)
summary=[]
for (count,retained,layout),rows in sorted(grouped.items()):
    assert len(rows)==3
    summary.append(dict(count=count,retained=retained,layout=results['layouts'][layout],
        median_diagnostic_us=statistics.median(row['diagnostic_us_per_iteration'] for row in rows),
        median_pause_fraction=statistics.median(row['pause_fraction'] for row in rows),
        gen2_collections=sum(row['gen2'] for row in rows),
        median_allocated_bytes=statistics.median(row['allocated_bytes_per_iteration'] for row in rows)))
decision=dict(status='screened-out-before-production-change',production_changes=False,qualification=False,
    correctness_or_gpu_build_started=False,hosted_timing_cases=0,report_changed=False,baseline=baseline,
    bar_size=results['bar_bytes'],bitwise_component_cases=18,retention_and_source_mutation_checks='passed',
    conclusion='Pinned chunks fail the short-lived allocation study gate. Contiguous control also loses at10000bars. Retained32 workloads favor alternatives, but future caller retention cannot be assumed for these APIs. Keep the existing chunk layout; do not run conditional hosted verification.',
    limitations='Local component experiment, not full indicator execution, qualified latency, production regression evidence or native-win evidence. Local noise exists, including differences between identical1000bar normal layouts. Results justify screening out, not a production performance claim.',
    historical_control='ceb45779d introduced chunked owned history to avoid LOH; this study does not overturn that accepted policy.',summary=summary)
(study/'decision.json').write_bytes((json.dumps(decision,indent=2)+'\n').encode())
portable=study/'portable';portable.mkdir(exist_ok=True)
relative='benchmarks/results/remaining-indicators/owned-history-allocation-study-20261116'
files={'component-results.json':study/'component-results.json','decision.json':study/'decision.json',
       'scope.json':ops/'owned-history-allocation-study-proposal-20261116.json',
       'StudyOwnedHistoryAllocation20261116.cs':ops/'StudyOwnedHistoryAllocation20261116.cs',
       'study-owned-history-allocation-20261116.ps1':ops/'study-owned-history-allocation-20261116.ps1',
       'archive-study.py':Path(__file__)}
manifest={};blobs={}
for name,path in files.items():
    raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw
    (portable/(name+'.gz')).write_bytes(packed)
    manifest[name]=dict(sha256=hashlib.sha256(raw).hexdigest(),archive=name+'.gz')
    blobs[relative+'/'+name+'.gz']=packed
blobs[relative+'/manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
blobs[relative+'/.gitattributes']=b'* -text\n'
index=study/'archive-index';assert not index.exists()
env=os.environ.copy();env['GIT_INDEX_FILE']=str(index.resolve())
def git(*args,input=None):return subprocess.check_output(['git','--git-dir='+str(store),*args],input=input,env=env)
git('read-tree',baseline)
for path,content in blobs.items():
    sha=git('hash-object','-w','--stdin',input=content).decode().strip()
    git('update-index','--add','--cacheinfo','100644,'+sha+','+path)
tree=git('write-tree').decode().strip()
commit=git('commit-tree',tree,'-p',baseline,'-m','perf: record screened out owned history allocation study').decode().strip()
changed=git('diff-tree','--no-commit-id','--name-only','-r',commit).decode().splitlines()
assert changed and all(path.startswith(relative+'/') for path in changed)
branch='refs/heads/perf/owned-history-allocation-study-20261116'
git('update-ref',branch,commit,'0'*40)
git('push','origin',branch+':'+branch)
index.unlink()
record=data['performance_continuation_20261103']['owned-history-allocation-20261116']
record.update(status='COMPLETE bounded study: screened out before source/build/GPU/hosted timing; current chunk policy retained.',
    study_result=str(study/'decision.json'),archive_commit=commit,archive_branch=branch,production_changes=False,hosted_timing_cases=0,
    bounded_batch_complete=True,full_goal_complete=False)
data['pending_scope_decision']=None
data['next_action']='Continue approved read-only native-closure triage from174-gap report; allocation alternatives screened out. No production or report change from study; do not run its conditional verification or repurpose its380case budget.'
data['active_task']={'description':data['next_action'],'remaining_10000_bar_gaps':174,'last_completed_record':'owned-history-allocation-20261116'}
data['active_continuation_20261115']['next_actions']=[data['next_action']]
data['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();data['full_goal_complete']=False
checkpoint.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(dict(commit=commit,files=len(changed),status=decision['status'])))
