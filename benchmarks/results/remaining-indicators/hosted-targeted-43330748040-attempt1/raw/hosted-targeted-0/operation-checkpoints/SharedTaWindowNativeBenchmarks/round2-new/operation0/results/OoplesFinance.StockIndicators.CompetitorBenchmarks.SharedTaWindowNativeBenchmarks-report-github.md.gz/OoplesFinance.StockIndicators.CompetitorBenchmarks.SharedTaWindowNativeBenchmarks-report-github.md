```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|-----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)bands [24]** | **1000**  |   **673.679 μs** |   **4.0351 μs** |  **2.4012 μs** | **73.57** |    **0.99** |       **-** |       **-** |   **99.56 KB** |        **2.55** |
| BuilderLatestOnly | TaLib(...)bands [24] | 1000  |   620.659 μs |   6.1757 μs |  4.0848 μs | 67.78 |    0.98 |       - |       - |    51.9 KB |        1.33 |
| NativeSingle      | TaLib(...)bands [24] | 1000  |     9.158 μs |   0.2124 μs |  0.1264 μs |  1.00 |    0.02 |  2.3804 |  0.1831 |   39.09 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [24] | 1000  |    99.816 μs |   2.2546 μs |  1.3417 μs | 10.90 |    0.20 |  7.8125 |  0.9766 |  122.27 KB |        3.13 |
|                   |                      |       |              |             |            |       |         |         |         |            |             |
| **BuilderFull**       | **TaLib(...)bands [24]** | **10000** | **3,421.538 μs** | **138.4711 μs** | **72.4230 μs** | **38.61** |    **0.85** | **31.2500** |       **-** |  **953.42 KB** |        **2.44** |
| BuilderLatestOnly | TaLib(...)bands [24] | 10000 | 3,405.235 μs |  39.6433 μs | 20.7342 μs | 38.43 |    0.42 |       - |       - |  483.58 KB |        1.24 |
| NativeSingle      | TaLib(...)bands [24] | 10000 |    88.625 μs |   1.2953 μs |  0.8567 μs |  1.00 |    0.01 | 23.4375 |  7.8125 |  390.65 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [24] | 10000 |   234.830 μs |   7.9974 μs |  5.2898 μs |  2.65 |    0.06 | 76.1719 | 31.2500 | 1212.12 KB |        3.10 |
