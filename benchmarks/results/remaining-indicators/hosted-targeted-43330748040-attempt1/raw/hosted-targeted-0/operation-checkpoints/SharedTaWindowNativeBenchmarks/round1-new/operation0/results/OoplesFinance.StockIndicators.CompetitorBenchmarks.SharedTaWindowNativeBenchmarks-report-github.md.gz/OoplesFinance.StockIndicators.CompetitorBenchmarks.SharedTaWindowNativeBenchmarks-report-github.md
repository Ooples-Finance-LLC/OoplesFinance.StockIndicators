```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)bands [24]** | **1000**  |   **666.1 μs** |   **6.43 μs** |   **3.82 μs** |       **-** |  **99.56 KB** |
| BuilderLatestOnly | TaLib(...)bands [24] | 1000  |   618.5 μs |   5.36 μs |   3.19 μs |       - |   51.9 KB |
| **BuilderFull**       | **TaLib(...)bands [24]** | **10000** | **3,522.2 μs** | **328.61 μs** | **217.35 μs** | **31.2500** | **953.42 KB** |
| BuilderLatestOnly | TaLib(...)bands [24] | 10000 | 3,375.6 μs |  76.40 μs |  39.96 μs |       - | 483.58 KB |
