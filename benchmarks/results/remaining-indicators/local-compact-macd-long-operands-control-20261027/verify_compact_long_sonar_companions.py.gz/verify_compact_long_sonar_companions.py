"""Account only for the three approved Sonar files between MACD timing sources.

Both timing arms retain the same benchmark assembly. Only the production DLL
is swapped. The two production edits are diagnostics directives; the Kaufman
oracle predicates are equivalent and that oracle is outside the eight selected
MACD/PVO/SMA pairs. No arbitrary source differences are waived.
"""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
SONAR_INPUTS = {'sonar-five-followups-draft-20261027/review.json': '0a39da9bb8df7131fbd6edb9ac0e249f95ebd0c9caa33a47fa438c9de632514a', 'sonar-five-followups-draft-20261027/exact-equality-review.json': 'a4d1cccb4d2f69a0b86b94c7e357d621a9af356d323fca3744f334120329cd84'}


def check_text(before, after, record, equality):
    before = before.replace('\r\n', '\n')
    after = after.replace('\r\n', '\n')
    assert hashlib.sha256(before.encode()).hexdigest() == record['before_lf_sha256']
    assert hashlib.sha256(after.encode()).hexdigest() == record['after_lf_sha256']
    if equality:
        restored = '\n'.join(line for line in after.split('\n') if not line.startswith('#pragma warning'))
        reason = 'Only two scoped S1244 diagnostic directives; executable source unchanged.'
    else:
        restored = after.replace('double.IsPositiveInfinity(min)', 'min == double.PositiveInfinity')
        restored = restored.replace('double.IsNegativeInfinity(max)', 'max == double.NegativeInfinity')
        restored = restored.replace(
            '// Preserved from 71c31b97: method/class names, access, and equivalent infinity predicates are changed.',
            '// Preserved from 71c31b97: only method/class names and access are changed.')
        reason = 'Equivalent infinity predicates and provenance comment in the unselected Kaufman oracle; benchmark DLL is identical in both arms.'
    assert restored == before, record['file']
    return {'before_lf_sha256': record['before_lf_sha256'],
            'after_lf_sha256': record['after_lf_sha256'], 'reason': reason}


def verify_sonar_source_delta(repo, old_head, new_head):
    review = json.loads((ROOT / 'compact-macd-long-operands-draft-20261027/measurement-review.json').read_text())
    assert review['sonar_inputs'] == SONAR_INPUTS
    for relative, expected in SONAR_INPUTS.items():
        assert hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() == expected, relative
    directory = ROOT / 'sonar-five-followups-draft-20261027'
    kaufman = json.loads((directory / 'review.json').read_text())
    equality = json.loads((directory / 'exact-equality-review.json').read_text())
    result = {}
    for record, is_equality in [(kaufman, False), *((record, True) for record in equality['files'])]:
        def source(head):
            return subprocess.check_output(['git', 'show', head + ':' + record['file']], cwd=repo).decode('utf-8')
        result[record['file']] = check_text(source(old_head), source(new_head), record, is_equality)
    assert len(result) == 3
    return result
