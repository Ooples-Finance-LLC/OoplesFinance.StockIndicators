```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tSine [22]** |   **930.5 μs** | **28.33 μs** | **18.74 μs** |  **1.00** |    **0.03** |  **166.42 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tSine [22] |   442.7 μs |  2.22 μs |  1.16 μs |  0.48 |    0.01 |   72.64 KB |        0.44 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)tSine [22]** | **9,093.0 μs** | **26.42 μs** | **13.82 μs** |  **1.00** |    **0.00** | **1594.84 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tSine [22] | 4,638.0 μs | 29.73 μs | 17.69 μs |  0.51 |    0.00 |  654.03 KB |        0.41 |
