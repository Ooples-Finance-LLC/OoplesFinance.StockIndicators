```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **824.5 μs** |   **6.73 μs** |   **3.52 μs** |  **84.83 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   824.5 μs |  11.03 μs |   6.56 μs |  37.26 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **9,143.1 μs** |  **61.37 μs** |  **36.52 μs** | **788.71 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 9,513.2 μs | 286.02 μs | 189.18 μs | 319.08 KB |
