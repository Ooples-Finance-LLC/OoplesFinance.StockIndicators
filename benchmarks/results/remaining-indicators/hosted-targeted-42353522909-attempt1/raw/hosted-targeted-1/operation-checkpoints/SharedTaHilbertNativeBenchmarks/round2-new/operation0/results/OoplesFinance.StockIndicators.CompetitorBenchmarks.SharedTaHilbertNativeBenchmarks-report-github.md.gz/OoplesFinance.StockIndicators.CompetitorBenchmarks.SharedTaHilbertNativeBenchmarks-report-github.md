```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **775.2 μs** |  **20.97 μs** |  **12.48 μs** |  **2.01** |    **0.03** |  **84.81 KB** |        **5.39** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   760.3 μs |  22.35 μs |  14.78 μs |  1.97 |    0.04 |  37.24 KB |        2.37 |
| NativeSingle      | TaLib(...)tSine [22] | 1000  |   386.5 μs |   1.75 μs |   1.04 μs |  1.00 |    0.00 |  15.73 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 1000  |   595.2 μs |  27.53 μs |  16.38 μs |  1.54 |    0.04 |  55.96 KB |        3.56 |
|                   |                      |       |            |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **8,644.5 μs** |  **48.80 μs** |  **29.04 μs** |  **1.89** |    **0.01** | **788.66 KB** |        **5.04** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 8,723.2 μs |  25.97 μs |  15.45 μs |  1.91 |    0.01 | 318.81 KB |        2.04 |
| NativeSingle      | TaLib(...)tSine [22] | 10000 | 4,574.7 μs |  18.93 μs |  12.52 μs |  1.00 |    0.00 | 156.48 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 10000 | 6,586.4 μs | 370.49 μs | 245.06 μs |  1.44 |    0.05 | 548.61 KB |        3.51 |
