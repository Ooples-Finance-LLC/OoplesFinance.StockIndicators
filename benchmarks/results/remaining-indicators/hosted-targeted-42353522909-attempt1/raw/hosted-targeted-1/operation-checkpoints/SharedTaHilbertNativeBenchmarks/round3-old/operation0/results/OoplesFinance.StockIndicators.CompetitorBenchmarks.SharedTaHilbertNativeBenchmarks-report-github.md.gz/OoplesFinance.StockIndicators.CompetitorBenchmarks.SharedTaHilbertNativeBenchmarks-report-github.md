```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **813.9 μs** | **18.12 μs** | **10.79 μs** |  **84.83 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   803.2 μs |  6.33 μs |  4.18 μs |  37.25 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **9,116.7 μs** | **42.93 μs** | **25.55 μs** | **788.86 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 9,140.5 μs | 18.47 μs |  9.66 μs | 318.96 KB |
