```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1.703 ms** | **0.0158 ms** | **0.0104 ms** |   **71.7 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1.661 ms | 0.0087 ms | 0.0046 ms |   24.1 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **17.358 ms** | **0.1264 ms** | **0.0836 ms** | **635.72 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 17.226 ms | 0.0464 ms | 0.0276 ms | 165.75 KB |
