```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **2,215.5 μs** |  **20.09 μs** |  **11.95 μs** |  **3.81** |    **0.02** |   **71.7 KB** |       **15.15** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1,608.5 μs |   7.59 μs |   5.02 μs |  2.77 |    0.01 |  24.12 KB |        5.10 |
| NativeSingle      | TaLib(...)dMode [27] | 1000  |    580.9 μs |   1.80 μs |   0.94 μs |  1.00 |    0.00 |   4.73 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 1000  |    826.1 μs |  24.86 μs |  16.45 μs |  1.42 |    0.03 |  17.43 KB |        3.68 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **16,646.2 μs** |  **85.52 μs** |  **50.89 μs** |  **2.63** |    **0.01** | **635.59 KB** |       **15.76** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 16,361.4 μs |  68.83 μs |  40.96 μs |  2.58 |    0.01 | 165.77 KB |        4.11 |
| NativeSingle      | TaLib(...)dMode [27] | 10000 |  6,337.4 μs |  14.72 μs |   9.74 μs |  1.00 |    0.00 |  40.33 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 10000 |  8,633.0 μs | 569.64 μs | 376.78 μs |  1.36 |    0.06 | 141.07 KB |        3.50 |
