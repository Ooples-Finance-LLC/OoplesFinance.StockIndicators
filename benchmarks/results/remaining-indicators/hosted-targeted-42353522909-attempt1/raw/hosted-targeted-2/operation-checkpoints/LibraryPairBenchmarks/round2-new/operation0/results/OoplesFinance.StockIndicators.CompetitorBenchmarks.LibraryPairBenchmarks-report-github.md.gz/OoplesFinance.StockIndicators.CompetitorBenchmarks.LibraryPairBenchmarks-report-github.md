```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dMode [27]** |  **1,680.3 μs** |   **7.35 μs** |   **4.86 μs** |  **1.00** |  **112.73 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dMode [27] |    618.4 μs |  27.37 μs |  18.10 μs |  0.37 |   37.85 KB |        0.34 |
|            |       |                      |             |           |           |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)dMode [27]** | **16,963.0 μs** | **173.07 μs** | **114.48 μs** |  **1.00** | **1044.06 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dMode [27] |  6,390.5 μs |  20.91 μs |  12.45 μs |  0.38 |  293.06 KB |        0.28 |
