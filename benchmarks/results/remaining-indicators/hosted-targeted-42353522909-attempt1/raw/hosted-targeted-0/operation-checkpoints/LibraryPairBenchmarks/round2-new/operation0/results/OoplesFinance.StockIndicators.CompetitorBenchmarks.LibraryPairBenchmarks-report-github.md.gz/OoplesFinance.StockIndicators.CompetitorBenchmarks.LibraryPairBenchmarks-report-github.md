```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Phase [25]** |   **637.7 μs** |   **6.35 μs** |  **3.78 μs** |  **1.00** |    **0.01** |  **110.06 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Phase [25] |   372.1 μs |   3.54 μs |  1.85 μs |  0.58 |    0.00 |   39.79 KB |        0.36 |
|            |       |                      |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)Phase [25]** | **6,719.3 μs** | **136.90 μs** | **90.55 μs** |  **1.00** |    **0.02** | **1033.24 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Phase [25] | 3,943.5 μs |  68.04 μs | 40.49 μs |  0.59 |    0.01 |  323.97 KB |        0.31 |
