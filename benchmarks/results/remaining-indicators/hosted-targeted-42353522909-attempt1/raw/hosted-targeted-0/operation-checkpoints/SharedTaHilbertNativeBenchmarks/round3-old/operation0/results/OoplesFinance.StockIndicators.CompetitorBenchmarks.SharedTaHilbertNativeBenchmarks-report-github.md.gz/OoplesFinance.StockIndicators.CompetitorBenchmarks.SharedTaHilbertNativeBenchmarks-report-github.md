```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **562.9 μs** |  **15.56 μs** |   **9.26 μs** |  **68.94 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   546.6 μs |  29.85 μs |  17.77 μs |  21.34 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **6,510.5 μs** | **217.29 μs** | **129.31 μs** |    **632 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 6,409.1 μs |  94.28 μs |  56.10 μs | 162.38 KB |
