```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **530.0 μs** |  **12.78 μs** |  **6.68 μs** |       **-** |  **68.94 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   521.0 μs |   6.25 μs |  3.27 μs |       - |  21.34 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **6,440.1 μs** | **132.84 μs** | **79.05 μs** | **31.2500** | **631.93 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 6,232.9 μs |  98.34 μs | 51.43 μs |       - | 162.15 KB |
