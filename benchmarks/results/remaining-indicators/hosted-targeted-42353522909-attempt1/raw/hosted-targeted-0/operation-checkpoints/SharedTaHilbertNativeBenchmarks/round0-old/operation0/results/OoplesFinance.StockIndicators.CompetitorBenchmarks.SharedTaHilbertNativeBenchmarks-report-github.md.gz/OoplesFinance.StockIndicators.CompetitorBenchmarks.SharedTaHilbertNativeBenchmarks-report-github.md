```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **562.5 μs** |  **26.08 μs** |  **13.64 μs** |  **68.94 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   567.1 μs |  22.70 μs |  15.02 μs |  21.34 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **6,555.5 μs** | **122.93 μs** |  **81.31 μs** | **632.23 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 6,746.9 μs | 185.30 μs | 110.27 μs | 162.09 KB |
