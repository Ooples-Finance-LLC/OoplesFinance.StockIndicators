```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **528.1 μs** |  **16.31 μs** |   **8.53 μs** |  **1.46** |    **0.02** |  **68.94 KB** |        **8.24** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   518.6 μs |  12.26 μs |   7.29 μs |  1.43 |    0.02 |  21.34 KB |        2.55 |
| NativeSingle      | TaLib(...)Phase [25] | 1000  |   362.3 μs |   5.84 μs |   3.05 μs |  1.00 |    0.01 |   8.37 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 1000  |   534.9 μs |  21.86 μs |  14.46 μs |  1.48 |    0.04 |  30.19 KB |        3.61 |
|                   |                      |       |            |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **6,381.9 μs** |  **61.41 μs** |  **32.12 μs** |  **1.65** |    **0.02** | **632.32 KB** |        **8.03** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 6,419.1 μs | 112.30 μs |  58.74 μs |  1.66 |    0.02 | 162.15 KB |        2.06 |
| NativeSingle      | TaLib(...)Phase [25] | 10000 | 3,859.2 μs |  69.59 μs |  36.40 μs |  1.00 |    0.01 |  78.79 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 10000 | 5,661.1 μs | 272.93 μs | 180.53 μs |  1.47 |    0.05 | 276.49 KB |        3.51 |
