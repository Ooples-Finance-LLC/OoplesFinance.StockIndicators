```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Gen0   | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetTsi** | **1000**  |   **667.3 μs** |  **21.98 μs** |  **13.08 μs** | **3.9063** |  **80.94 KB** |
| BuilderLatestOnly | Skender.GetTsi | 1000  |   673.3 μs |  22.57 μs |  14.93 μs |      - |  33.35 KB |
| **BuilderFull**       | **Skender.GetTsi** | **10000** | **6,951.7 μs** |  **59.39 μs** |  **31.06 μs** |      **-** | **784.67 KB** |
| BuilderLatestOnly | Skender.GetTsi | 10000 | 7,112.8 μs | 303.13 μs | 200.50 μs |      - |  314.9 KB |
