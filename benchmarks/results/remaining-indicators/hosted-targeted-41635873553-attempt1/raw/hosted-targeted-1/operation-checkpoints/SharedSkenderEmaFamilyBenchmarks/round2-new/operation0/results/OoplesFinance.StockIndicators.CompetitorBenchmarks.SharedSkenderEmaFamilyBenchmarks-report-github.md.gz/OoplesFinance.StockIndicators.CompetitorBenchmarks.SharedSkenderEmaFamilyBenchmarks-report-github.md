```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetTsi** | **1000**  |   **398.18 μs** |   **8.944 μs** |   **5.322 μs** | **18.89** |    **0.74** |        **-** |        **-** |        **-** |   **81.03 KB** |        **0.53** |
| BuilderLatestOnly | Skender.GetTsi | 1000  |   401.58 μs |   2.373 μs |   1.241 μs | 19.05 |    0.71 |        - |        - |        - |   33.38 KB |        0.22 |
| NativeSingle      | Skender.GetTsi | 1000  |    21.11 μs |   1.332 μs |   0.793 μs |  1.00 |    0.05 |   9.2773 |   1.9531 |        - |  152.88 KB |        1.00 |
| NativeParallel    | Skender.GetTsi | 1000  |    47.27 μs |   3.008 μs |   1.990 μs |  2.24 |    0.12 |  25.3906 |   7.3242 |        - |     391 KB |        2.56 |
|                   |                |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetTsi** | **10000** | **4,585.02 μs** | **108.328 μs** |  **64.465 μs** | **10.55** |    **0.84** |  **31.2500** |        **-** |        **-** |  **784.56 KB** |        **0.51** |
| BuilderLatestOnly | Skender.GetTsi | 10000 | 4,533.34 μs |  28.576 μs |  17.005 μs | 10.43 |    0.82 |        - |        - |        - |  314.79 KB |        0.21 |
| NativeSingle      | Skender.GetTsi | 10000 |   437.43 μs |  56.410 μs |  37.311 μs |  1.01 |    0.11 |  99.6094 |  99.6094 |  99.6094 | 1524.76 KB |        1.00 |
| NativeParallel    | Skender.GetTsi | 10000 | 1,554.74 μs | 451.727 μs | 298.790 μs |  3.58 |    0.72 | 359.3750 | 296.8750 | 156.2500 | 3892.08 KB |        2.55 |
