```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Gen0   | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetTsi** | **1000**  |   **681.0 μs** |  **21.00 μs** |  **13.89 μs** | **3.9063** |  **80.94 KB** |
| BuilderLatestOnly | Skender.GetTsi | 1000  |   668.0 μs |   4.26 μs |   2.54 μs |      - |  33.39 KB |
| **BuilderFull**       | **Skender.GetTsi** | **10000** | **7,155.8 μs** | **471.67 μs** | **280.68 μs** |      **-** | **784.62 KB** |
| BuilderLatestOnly | Skender.GetTsi | 10000 | 7,046.9 μs | 124.84 μs |  65.30 μs |      - | 315.14 KB |
