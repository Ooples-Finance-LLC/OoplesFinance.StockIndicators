```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetTsi** |   **893.85 μs** | **68.458 μs** | **45.281 μs** |  **1.00** |    **0.07** |  **162.42 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetTsi |    63.40 μs |  2.094 μs |  1.095 μs |  0.07 |    0.00 |  211.05 KB |        1.30 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetTsi** | **8,519.32 μs** | **39.738 μs** | **23.647 μs** |  **1.00** |    **0.00** | **1594.08 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetTsi |   665.88 μs | 40.162 μs | 23.900 μs |  0.08 |    0.00 | 2021.27 KB |        1.27 |
