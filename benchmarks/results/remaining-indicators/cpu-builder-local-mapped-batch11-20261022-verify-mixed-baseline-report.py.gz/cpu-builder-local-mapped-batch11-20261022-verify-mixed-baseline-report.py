import csv
import io
import json
from pathlib import Path
import re
import sys
import hashlib
from playwright.sync_api import sync_playwright

root = Path('C:/Users/cheat/Documents/OoplesFinance-Reports')
assert len(sys.argv) == 5, 'Usage: verify REPORT SOURCE_SHA RUN_ID OUTPUT_DIRECTORY'
report = Path(sys.argv[1]).resolve()
expected_source = sys.argv[2]
expected_run = sys.argv[3]
out = Path(sys.argv[4]).resolve()
out.mkdir(parents=True, exist_ok=True)
document = report.read_text(encoding='utf-8')
def embedded(name):
    return json.loads(re.search(r'<script[^>]*id="' + name + r'"[^>]*>(.*?)</script>', document, re.S)[1])
data, old = embedded('dataset'), embedded('archived-baseline-dataset')
new_source=data['evidence']['rowOverrides'][-1]['sourceSha']
assert data['evidence']['sourceSha'] is None
assert data['evidence']['baseSourceSha'] == expected_source
latest_override = data['evidence']['rowOverrides'][-1]
expected_suffix = '/' + expected_run
if latest_override.get('measurementLocation') == 'Local Windows':
    expected_suffix += '/decision.json'
assert latest_override['runUrl'].endswith(expected_suffix)
assert all(sum(r['pair']==o['pair'] and r['source_sha']==o['sourceSha'] and r['measurement_run_url']==o['runUrl'] for r in data['rows'])==2 for o in data['evidence']['rowOverrides'])
assert sum(r['source_sha']==expected_source for r in data['rows'])==802-2*len(data['evidence']['rowOverrides'])
assert len(data['rows']) == 802 and len({r['pair'] for r in data['rows']}) == 401
old_rows = {(r['pair'],r['bars']):r for r in old['rows']}
changed = {arm: sum(r[arm+'_mean_ns'] != old_rows[r['pair'],r['bars']][arm+'_mean_ns'] for r in data['rows'])
           for arm in ['ooples', 'competitor']}
assert all(changed.values())
summary = []
for library in sorted({r['library'] for r in data['rows']}):
    for bars in [1000,10000]:
        rows = [r for r in data['rows'] if r['library'] == library and r['bars'] == bars]
        lower = sum(r['competitor_over_ooples'] > 1 for r in rows)
        higher = sum(r['competitor_over_ooples'] < 1 for r in rows)
        equal = len(rows)-lower-higher
        summary.append(dict(library=library,bars=bars,comparisons=len(rows),lower=lower,higher=higher,equal=equal))
assert sum(r['comparisons'] for r in summary) == 802
with sync_playwright() as pw:
    browser = pw.chromium.launch(channel='msedge',headless=True)
    page = browser.new_page(viewport={'width':1440,'height':1000},accept_downloads=True)
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto(report.as_uri())
    page.wait_for_selector('#rows tr')
    for bars in [1000,10000]:
        page.locator(f'[data-size="{bars}"]').click()
        wins = sum(r['lower'] for r in summary if r['bars']==bars)
        assert page.locator('#wins').inner_text() == f'{wins} / 401'
        assert page.locator('#librarycards .libcard').count() == 4
    page.locator('#size').select_option('all')
    assert page.locator('#resultcount').inner_text() == '802 size comparisons · 401 APIs'
    # Traverse the complete paginated results table, not only the export or hero cards.
    formatted = page.evaluate("rows => rows.map(r => ({pair:r.pair,bars:r.bars,values:[time(r.ooples_mean_ns),time(r.competitor_mean_ns),ratio(r.competitor_over_ooples)]}))", data['rows'])
    expected_cells = {(r['pair'],r['bars']):r['values'] for r in formatted}
    table_keys = set()
    while True:
        visible = page.locator('#rows tr').evaluate_all("rows => rows.map(r => ({pair:r.querySelector('[data-pair]').dataset.pair,bars:Number(r.cells[1].textContent.replace(/[^0-9]/g,'')),values:[r.cells[2].textContent,r.cells[3].textContent,r.cells[4].textContent]}))")
        for row in visible:
            key = (row['pair'], row['bars'])
            assert key not in table_keys, key
            assert row['values'] == expected_cells[key], (key,row['values'],expected_cells[key])
            table_keys.add(key)
        if page.locator('#next').is_disabled(): break
        page.locator('#next').click()
    assert len(table_keys) == 802
    while not page.locator('#prev').is_disabled(): page.locator('#prev').click()
    with page.expect_download() as download:
        page.locator('#export').click()
    exported=list(csv.DictReader(Path(download.value.path()).read_text(encoding='utf-8').splitlines()))
    assert len(exported)==802
    expected={(r['pair'],r['bars']):r for r in data['rows']}
    for row in exported:
        actual=expected[row['pair'],int(row['bars'])]
        for key in ['ooples_mean_ns','competitor_mean_ns','competitor_over_ooples']:
            assert float(row[key])==actual[key]
        assert row['source_sha']==actual['source_sha'] and row['measurement_run_url']==actual['measurement_run_url']
    page.locator('#rows [data-pair]').first.click()
    assert page.locator('#detail').is_visible()
    assert 'Sample 3 (ns)' in page.locator('#detailbody').inner_text()
    page.locator('#close').click()
    page.evaluate('window.scrollTo(0,0)')
    page.screenshot(path=str(out/'refreshed-baseline.png'))
    page.locator('#query').fill(data['evidence']['rowOverrides'][-1]['pair'])
    assert page.locator('#rows tr').count()==2
    page.locator('#rows [data-pair]').first.click()
    body=page.locator('#detailbody').inner_text()
    assert new_source[:8] in body and 'Sample 7 (ns)' in body
    # Formula notes may explain native NaN behavior; measurement tables must not contain it.
    tables=page.locator('#detailbody table').all_inner_texts()
    assert tables
    assert all('NaN' not in t and 'undefined' not in t for t in tables)
    page.screenshot(path=str(out/'sma-details.png'))
    visible_html=re.sub(r'<script.*?</script>','',document,flags=re.S)
    assert f'{sum(r["lower"] for r in summary if r["bars"]==10000)} / 401 APIs at 10,000 bars' in visible_html
    assert not errors,errors
    browser.close()
receipt=dict(source=data['evidence']['sourceSha'],run_id=expected_run,report_sha256=hashlib.sha256(report.read_bytes()).hexdigest(),changed_means=changed,summary=summary,
    comparisons=802,displayed_table_comparisons=len(table_keys),exported_comparisons=len(exported),javascript_errors=errors)
(out/'browser-verification.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt))
