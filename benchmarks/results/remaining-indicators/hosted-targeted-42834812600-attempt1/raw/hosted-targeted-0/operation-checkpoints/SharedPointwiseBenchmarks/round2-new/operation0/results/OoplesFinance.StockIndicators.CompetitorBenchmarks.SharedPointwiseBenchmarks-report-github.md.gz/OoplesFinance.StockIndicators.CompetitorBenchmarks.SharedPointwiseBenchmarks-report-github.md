```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Ln**        |  **12.296 μs** | **0.1751 μs** | **0.0916 μs** |  **1.80** |    **0.02** |  **3.4180** |  **0.4883** |  **56.77 KB** |        **7.22** |
| BuilderLatestOnly | 1000  | Ln        |   9.253 μs | 0.1457 μs | 0.0964 μs |  1.36 |    0.02 |  0.5493 |       - |   9.16 KB |        1.16 |
| NativeSingle      | 1000  | Ln        |   6.827 μs | 0.0568 μs | 0.0376 μs |  1.00 |    0.01 |  0.4272 |       - |   7.87 KB |        1.00 |
| NativeParallel    | 1000  | Ln        |  89.190 μs | 1.7860 μs | 1.1814 μs | 13.06 |    0.18 |  0.4883 |       - |   8.14 KB |        1.03 |
|                   |       |           |            |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **10000** | **Ln**        | **109.263 μs** | **2.2231 μs** | **1.4705 μs** |  **1.67** |    **0.02** | **33.2031** | **13.6719** | **549.32 KB** |        **7.03** |
| BuilderLatestOnly | 10000 | Ln        |  81.871 μs | 0.5680 μs | 0.3757 μs |  1.25 |    0.01 |  4.3945 |  0.4883 |  79.48 KB |        1.02 |
| NativeSingle      | 10000 | Ln        |  65.468 μs | 0.3492 μs | 0.2078 μs |  1.00 |    0.00 |  4.3945 |  0.4883 |  78.18 KB |        1.00 |
| NativeParallel    | 10000 | Ln        | 123.273 μs | 4.3823 μs | 2.6078 μs |  1.88 |    0.04 |  3.9063 |       - |  78.45 KB |        1.00 |
