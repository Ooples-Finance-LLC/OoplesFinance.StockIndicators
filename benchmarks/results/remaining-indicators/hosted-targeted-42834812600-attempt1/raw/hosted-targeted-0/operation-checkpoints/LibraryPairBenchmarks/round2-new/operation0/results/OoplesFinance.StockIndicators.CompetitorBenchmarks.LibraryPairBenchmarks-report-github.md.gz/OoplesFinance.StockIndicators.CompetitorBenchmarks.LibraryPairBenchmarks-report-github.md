```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ln** | **266.70 μs** |  **2.909 μs** | **1.521 μs** |  **1.00** |    **0.01** |  **97.92 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ln |  19.44 μs |  0.249 μs | 0.130 μs |  0.07 |    0.00 |  39.99 KB |        0.41 |
|            |       |                    |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ln** | **287.19 μs** | **10.785 μs** | **6.418 μs** |  **1.00** |    **0.03** | **959.18 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ln | 175.01 μs |  4.931 μs | 2.934 μs |  0.61 |    0.02 | 331.02 KB |        0.35 |
