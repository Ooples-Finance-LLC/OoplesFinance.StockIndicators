```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId             | Mean     | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |------------------- |---------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Ln** | **148.7 μs** | **38.65 μs** | **25.56 μs** |  **1.02** |    **0.22** |   **97.9 KB** |        **1.00** |
|        |       |                    |          |          |          |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Ln** | **296.2 μs** | **10.64 μs** |  **6.33 μs** |  **1.00** |    **0.03** | **959.51 KB** |        **1.00** |
