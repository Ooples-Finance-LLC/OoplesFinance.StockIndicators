```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Log10 [21]** |  **46.33 μs** |  **3.525 μs** |  **1.844 μs** |  **1.00** |    **0.05** |  **97.86 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Log10 [21] |  17.39 μs |  1.220 μs |  0.638 μs |  0.38 |    0.02 |  40.27 KB |        0.41 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Log10 [21]** | **226.29 μs** | **19.354 μs** | **11.517 μs** |  **1.00** |    **0.07** | **959.18 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Log10 [21] | 140.31 μs |  7.061 μs |  4.670 μs |  0.62 |    0.04 |  331.3 KB |        0.35 |
