```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0   | Gen1   | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|-------:|-------:|----------:|
| **BuilderFull**       | **1000**  | **Log10**     |  **11.525 μs** | **1.4660 μs** | **0.9697 μs** | **0.4883** |      **-** |  **56.77 KB** |
| BuilderLatestOnly | 1000  | Log10     |   8.407 μs | 0.5161 μs | 0.3414 μs | 0.0610 |      - |   9.16 KB |
| **BuilderFull**       | **10000** | **Log10**     | **130.835 μs** | **4.5695 μs** | **2.3899 μs** | **5.8594** | **4.8828** | **549.73 KB** |
| BuilderLatestOnly | 10000 | Log10     | 109.567 μs | 2.4060 μs | 1.2584 μs | 0.9766 |      - |  79.91 KB |
