```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean      | Error     | StdDev    | Gen0   | Gen1   | Allocated |
|------------------ |------ |---------- |----------:|----------:|----------:|-------:|-------:|----------:|
| **BuilderFull**       | **1000**  | **Log10**     |  **9.900 μs** | **0.3534 μs** | **0.1848 μs** | **0.4883** |      **-** |  **56.77 KB** |
| BuilderLatestOnly | 1000  | Log10     |  7.983 μs | 0.6321 μs | 0.4181 μs | 0.0610 |      - |   9.16 KB |
| **BuilderFull**       | **10000** | **Log10**     | **80.054 μs** | **2.2242 μs** | **1.3236 μs** | **6.3477** | **3.9063** | **549.29 KB** |
| BuilderLatestOnly | 10000 | Log10     | 64.446 μs | 0.7635 μs | 0.3993 μs | 0.4883 |      - |  79.47 KB |
