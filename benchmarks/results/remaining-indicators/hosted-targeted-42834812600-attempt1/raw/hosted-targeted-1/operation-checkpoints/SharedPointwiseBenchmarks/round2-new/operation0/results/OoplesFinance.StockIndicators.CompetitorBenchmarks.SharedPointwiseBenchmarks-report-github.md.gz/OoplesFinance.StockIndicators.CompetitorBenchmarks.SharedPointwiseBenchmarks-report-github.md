```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0   | Gen1   | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-----------:|----------:|----------:|------:|--------:|-------:|-------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Log10**     |  **10.570 μs** | **0.9895 μs** | **0.5889 μs** |  **1.70** |    **0.10** | **0.4883** |      **-** |  **56.77 KB** |        **7.22** |
| BuilderLatestOnly | 1000  | Log10     |   7.902 μs | 0.1438 μs | 0.0856 μs |  1.27 |    0.03 | 0.0610 |      - |   9.16 KB |        1.16 |
| NativeSingle      | 1000  | Log10     |   6.214 μs | 0.2105 μs | 0.1252 μs |  1.00 |    0.03 | 0.0610 |      - |   7.87 KB |        1.00 |
| NativeParallel    | 1000  | Log10     |  74.215 μs | 0.8943 μs | 0.4678 μs | 11.95 |    0.24 |      - |      - |   8.14 KB |        1.03 |
|                   |       |           |            |           |           |       |         |        |        |           |             |
| **BuilderFull**       | **10000** | **Log10**     |  **79.917 μs** | **1.3134 μs** | **0.6869 μs** |  **1.34** |    **0.03** | **6.3477** | **3.9063** | **549.29 KB** |        **7.03** |
| BuilderLatestOnly | 10000 | Log10     |  65.170 μs | 1.3664 μs | 0.8131 μs |  1.10 |    0.03 | 0.4883 |      - |  79.47 KB |        1.02 |
| NativeSingle      | 10000 | Log10     |  59.518 μs | 2.3176 μs | 1.5330 μs |  1.00 |    0.03 | 0.4883 |      - |  78.18 KB |        1.00 |
| NativeParallel    | 10000 | Log10     | 100.849 μs | 1.8885 μs | 0.9877 μs |  1.70 |    0.04 |      - |      - |  78.45 KB |        1.00 |
