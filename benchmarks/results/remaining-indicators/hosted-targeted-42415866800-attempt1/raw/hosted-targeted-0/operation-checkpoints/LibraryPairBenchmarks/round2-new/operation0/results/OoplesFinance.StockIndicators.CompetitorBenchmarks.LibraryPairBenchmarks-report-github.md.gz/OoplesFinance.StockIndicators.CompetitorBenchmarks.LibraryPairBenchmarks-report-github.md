```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAdx** |   **535.60 μs** |  **28.44 μs** | **18.814 μs** |  **1.00** |    **0.05** |  **316.84 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAdx |    52.62 μs |  11.88 μs |  7.072 μs |  0.10 |    0.01 |  333.58 KB |        1.05 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAdx** | **5,171.54 μs** |  **65.28 μs** | **34.143 μs** |  **1.00** |    **0.01** | **3108.51 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAdx |   573.53 μs | 102.82 μs | 68.009 μs |  0.11 |    0.01 |  3301.4 KB |        1.06 |
