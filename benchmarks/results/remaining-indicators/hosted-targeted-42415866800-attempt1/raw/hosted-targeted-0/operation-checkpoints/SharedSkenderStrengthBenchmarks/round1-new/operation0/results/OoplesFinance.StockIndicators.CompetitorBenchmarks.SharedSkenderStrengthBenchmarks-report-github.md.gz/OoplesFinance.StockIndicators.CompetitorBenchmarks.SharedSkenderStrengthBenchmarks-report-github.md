```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated  |
|------------------ |--------------- |------ |-----------:|---------:|---------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetAdx** | **1000**  |   **407.0 μs** |  **3.70 μs** |  **1.93 μs** |  **3.9063** |       **-** |  **113.73 KB** |
| BuilderLatestOnly | Skender.GetAdx | 1000  |   405.2 μs |  3.96 μs |  2.07 μs |  3.9063 |       - |   66.14 KB |
| **BuilderFull**       | **Skender.GetAdx** | **10000** | **4,640.5 μs** | **68.78 μs** | **40.93 μs** | **62.5000** | **31.2500** | **1098.49 KB** |
| BuilderLatestOnly | Skender.GetAdx | 10000 | 4,544.4 μs | 46.51 μs | 27.68 μs | 31.2500 |       - |  628.66 KB |
