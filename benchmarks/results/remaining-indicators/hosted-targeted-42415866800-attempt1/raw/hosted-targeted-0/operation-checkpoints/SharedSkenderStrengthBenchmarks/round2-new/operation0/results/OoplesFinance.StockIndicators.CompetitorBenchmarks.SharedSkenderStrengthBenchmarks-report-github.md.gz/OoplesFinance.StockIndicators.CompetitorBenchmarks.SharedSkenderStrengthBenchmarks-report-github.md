```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAdx** | **1000**  |   **448.28 μs** |  **10.253 μs** |  **6.101 μs** | **13.64** |    **0.22** |   **3.9063** |        **-** |  **113.73 KB** |        **0.57** |
| BuilderLatestOnly | Skender.GetAdx | 1000  |   425.14 μs |  24.069 μs | 14.323 μs | 12.93 |    0.43 |   3.9063 |        - |   66.15 KB |        0.33 |
| NativeSingle      | Skender.GetAdx | 1000  |    32.87 μs |   0.599 μs |  0.356 μs |  1.00 |    0.01 |  12.2070 |   3.1738 |  199.67 KB |        1.00 |
| NativeParallel    | Skender.GetAdx | 1000  |   150.80 μs |  10.739 μs |  7.103 μs |  4.59 |    0.21 |  31.2500 |   9.7656 |  507.82 KB |        2.54 |
|                   |                |       |             |            |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetAdx** | **10000** | **4,983.67 μs** | **132.874 μs** | **79.071 μs** | **11.50** |    **0.22** |  **62.5000** |  **31.2500** | **1098.65 KB** |        **0.55** |
| BuilderLatestOnly | Skender.GetAdx | 10000 | 4,902.82 μs | 113.551 μs | 75.107 μs | 11.31 |    0.21 |  31.2500 |        - |   628.8 KB |        0.32 |
| NativeSingle      | Skender.GetAdx | 10000 |   433.60 μs |   8.616 μs |  5.127 μs |  1.00 |    0.02 | 121.0938 |  70.3125 | 1992.67 KB |        1.00 |
| NativeParallel    | Skender.GetAdx | 10000 | 1,068.93 μs |  51.497 μs | 34.062 μs |  2.47 |    0.08 | 312.5000 | 257.8125 | 5060.61 KB |        2.54 |
