```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |--------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetAdx** | **1000**  |   **483.5 μs** |  **3.31 μs** |  **1.97 μs** |  **3.9063** |  **113.73 KB** |
| BuilderLatestOnly | Skender.GetAdx | 1000  |   478.9 μs |  3.33 μs |  1.74 μs |  3.9063 |   66.14 KB |
| **BuilderFull**       | **Skender.GetAdx** | **10000** | **5,316.5 μs** | **89.69 μs** | **46.91 μs** | **66.6667** | **1098.84 KB** |
| BuilderLatestOnly | Skender.GetAdx | 10000 | 5,289.8 μs | 45.86 μs | 23.99 μs | 31.2500 |   628.8 KB |
