"""Require authenticated, intended inlining before the approved timing batch."""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path


def intended(events):
    return [event for event in events['matches']
            if event['event'] == 'Method/InliningSucceeded'
            and event['payload'].get('InlineeName') == 'RoundBinaryProduct'
            and event['payload'].get('InlineeNamespace') == 'OoplesFinance.StockIndicators.Helpers.JurikDyadic'
            and (event['payload'].get('InlinerNamespace'), event['payload'].get('InlinerName')) in (
                ('OoplesFinance.StockIndicators.Helpers.CompactMacdValue', 'PublishRoundedSum'),
                ('OoplesFinance.StockIndicators.Indicators.ValuesBarExecution', 'FillAccumulationDistribution'))
            and event['payload'].get('MethodBeingCompiledName') == 'FillAccumulationDistribution'
            and event['payload'].get('MethodBeingCompiledNamespace') == 'OoplesFinance.StockIndicators.Indicators.ValuesBarExecution']


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('record', nargs='?')
    parser.add_argument('--self-test', action='store_true')
    parser.add_argument('--recheck-existing', action='store_true')
    args = parser.parse_args()
    root = Path(__file__).parent
    if args.self_test:
        old = json.loads((root / 'adl-direct-binary-publication-inlining-read-only-20261109/publication-inlining-events.json').read_text(encoding='utf-8-sig'))
        assert old['events_lost'] == 0 and not intended(old)
        event = {'event': 'Method/InliningSucceeded', 'payload': dict(
            InlineeName='RoundBinaryProduct', InlineeNamespace='OoplesFinance.StockIndicators.Helpers.JurikDyadic',
            InlinerName='PublishRoundedSum', InlinerNamespace='OoplesFinance.StockIndicators.Helpers.CompactMacdValue',
            MethodBeingCompiledName='FillAccumulationDistribution',
            MethodBeingCompiledNamespace='OoplesFinance.StockIndicators.Indicators.ValuesBarExecution')}
        assert len(intended({'matches': [event]})) == 1
        event['payload']['InlinerName'] = 'UnrelatedCaller'
        assert not intended({'matches': [event]})
        current = root / 'adl-direct-binary-inline-hint-20261109-jit-proof/events.json'
        if current.exists():
            actual = json.loads(current.read_text(encoding='utf-8-sig'))
            assert actual['events_lost'] == 0 and len(intended(actual)) == 3
        print('Gate parser checks passed: archived rejection, synthetic intended/unrelated callers, actual consumer inlining')
        return
    assert args.record
    checkpoint = root / 'continuation-latest-20261028.json'
    records = json.loads(checkpoint.read_text())['performance_continuation_20261103']
    q = records[args.record]
    assert q['verification_scope_approved'] and q['runtime_tensor_version'] == '0.149.0'
    assert (q['unit_passed'], q['comparator_passed'], q['gpu_passed']) == (23, 25, 100)
    assert records[q['baseline_record']]['fresh_publication_ci_status'] == 'passed'
    assert 'timing_run' not in q
    repo = Path(q['repo'])
    manifest = json.loads((Path(q['out']) / 'ci-manifest.json').read_text())
    assert manifest['source'] == q['source'] and manifest['source_sha256'] == q['source_fingerprint']
    relative = 'benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks/bin/Release/net10.0'
    for name, expected in manifest['runtime_files'].items():
        if name.startswith(relative + '/'):
            assert hashlib.sha256((repo / name).read_bytes()).hexdigest() == expected
    out = root / (args.record + '-jit-proof')
    if not args.recheck_existing:
        out.mkdir()  # Existing evidence requires inspection, never a blind overwrite.
    trace, worker, events = (out / name for name in ('inlining.nettrace', 'worker.json', 'events.json'))
    commands = [
        ['dotnet-trace', 'collect', '--providers', 'Microsoft-Windows-DotNETRuntime:0x1000:5',
         '--output', str(trace), '--', 'pwsh', '-NoProfile', '-File', str(root / 'trace-adl-inlining-worker-20261109.ps1'),
         '-BenchmarkRoot', str(repo / relative), '-ProductionSha256', q['production_sha256'], '-Output', str(worker)],
        ['pwsh', '-NoProfile', '-File', str(root / 'read-adl-inlining-events-20261109.ps1'),
         '-Trace', str(trace), '-Output', str(events), '-Pattern', 'RoundBinaryProduct|PublishRoundedSum']]
    if not args.recheck_existing:
        for index, command in enumerate(commands):
            with (out / f'command-{index}.log').open('wb') as log:
                subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=300)
    w = json.loads(worker.read_text(encoding='utf-8-sig'))
    e = json.loads(events.read_text(encoding='utf-8-sig'))
    assert w['completed'] and w['runtime'] == '.NET 10.0.14'
    assert w['production_sha256'].lower() == q['production_sha256'].lower()
    assert w['benchmark_sha256'].lower() == hashlib.sha256((repo / relative / 'OoplesFinance.StockIndicators.CompetitorBenchmarks.dll').read_bytes()).hexdigest()
    assert e['trace_sha256'].lower() == hashlib.sha256(trace.read_bytes()).hexdigest()
    if args.recheck_existing:
        backup = out / 'summary-initial-attribution.json'
        assert not backup.exists(), 'Existing recheck evidence requires inspection'
        backup.write_bytes((out / 'summary.json').read_bytes())
    accepted = e['events_lost'] == 0 and bool(intended(e))
    summary = dict(kind='Source-bound local default-runtime codegen diagnostic; not timing or qualification',
                   source=q['source'], qualified_source=q['qualified_source'], worker=w,
                   events_lost=e['events_lost'], intended_inline_successes=len(intended(e)), accepted=accepted)
    if args.recheck_existing:
        summary['attribution_correction'] = 'JIT reports the final FillAccumulationDistribution consumer after wrapper inlining; original zero-success summary retained; same authenticated trace reprocessed, no new trace/build'
    (out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    data = json.loads(checkpoint.read_text())
    data['performance_continuation_20261103'][args.record].update(
        jit_gate_passed=accepted, jit_gate_evidence=str(out / 'summary.json'))
    checkpoint.write_text(json.dumps(data, indent=2) + '\n')
    print(json.dumps(summary))
    assert accepted, 'Intended inlining not proved; no timing is authorized by this diagnostic'


if __name__ == '__main__':
    main()
