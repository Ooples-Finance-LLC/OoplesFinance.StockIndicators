param([Parameter(Mandatory)][string]$Trace,[Parameter(Mandatory)][string]$Output,
    [string]$Pattern='TryBoundedAccumulationDifferences|AccumulationFlow|FillAccumulationDistribution')
$ErrorActionPreference='Stop'
$null=[Reflection.Assembly]::LoadFrom('C:\Users\cheat\.dotnet\tools\.store\dotnet-trace\10.0.750501\dotnet-trace\10.0.750501\tools\net8.0\any\Microsoft.Diagnostics.Tracing.TraceEvent.dll')
$traceSource=[Microsoft.Diagnostics.Tracing.EventPipeEventSource]::new($Trace)
$matchesList=[Collections.Generic.List[object]]::new()
$stats=@{all_inlining_events=0}
function Capture-Inlining($traceRecord) {
    $stats.all_inlining_events++
    $payload=@{}
    foreach($field in $traceRecord.PayloadNames){$payload[$field]=[string]$traceRecord.PayloadByName($field)}
    if(($payload.Values -join '|') -match $Pattern) {
        $matchesList.Add(@{event=$traceRecord.EventName;payload=$payload})
    }
}
$traceSource.Clr.add_MethodInliningSucceeded({param($traceRecord) Capture-Inlining $traceRecord})
$traceSource.Clr.add_MethodInliningFailed({param($traceRecord) Capture-Inlining $traceRecord})
$traceSource.Clr.add_MethodInliningFailedAnsi({param($traceRecord) Capture-Inlining $traceRecord})
try {
    $null=$traceSource.GetType().GetMethod('Process').Invoke($traceSource,[object[]]@())
    $lostProperty=$traceSource.GetType().GetProperty('EventsLost')
    $lost=if($null -ne $lostProperty){$lostProperty.GetValue($traceSource)}else{'unavailable'}
} finally {$traceSource.Dispose()}
@{kind='Local default-runtime JIT inlining event attribution; not host timing or qualification';trace=$Trace;trace_sha256=(Get-FileHash $Trace).Hash;events_lost=$lost;stats=$stats;matches=$matchesList} |
    ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $Output -Encoding utf8
@{stats=$stats;matching_events=$matchesList.Count;events_lost=$lost} | ConvertTo-Json -Compress
