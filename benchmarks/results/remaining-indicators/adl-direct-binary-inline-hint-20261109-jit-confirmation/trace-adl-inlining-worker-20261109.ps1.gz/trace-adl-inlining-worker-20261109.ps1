param([Parameter(Mandatory)][string]$BenchmarkRoot,[Parameter(Mandatory)][string]$ProductionSha256,[Parameter(Mandatory)][string]$Output)
$ErrorActionPreference='Stop'
if((Get-FileHash "$BenchmarkRoot/OoplesFinance.StockIndicators.dll").Hash -ne $ProductionSha256){throw 'Production hash mismatch'}
$assembly=[Reflection.Assembly]::LoadFrom("$BenchmarkRoot/OoplesFinance.StockIndicators.CompetitorBenchmarks.dll")
foreach($size in @(1000,10000)) {
    $benchmark=[Activator]::CreateInstance($assembly.GetType('OoplesFinance.StockIndicators.CompetitorBenchmarks.LibraryPairBenchmarks',$true))
    $benchmark.PairId='Skender.GetAdl';$benchmark.Bars=$size;$benchmark.Setup()
    for($i=0;$i -lt 1000;$i++){$null=$benchmark.Ooples()}
    for($i=0;$i -lt 1000;$i++){$null=$benchmark.Ooples()}
}
$loaded=@([AppDomain]::CurrentDomain.GetAssemblies() | Where-Object {$_.GetName().Name -eq 'OoplesFinance.StockIndicators'})
if($loaded.Count -ne 1 -or $loaded[0].Location -ne [IO.Path]::GetFullPath("$BenchmarkRoot/OoplesFinance.StockIndicators.dll")){throw 'Unexpected production assembly'}
if((Get-FileHash $loaded[0].Location).Hash -ne $ProductionSha256){throw 'Loaded production hash mismatch'}
@{kind='Local default-runtime JIT event diagnostic; not timing';production_sha256=$ProductionSha256;benchmark_sha256=(Get-FileHash "$BenchmarkRoot/OoplesFinance.StockIndicators.CompetitorBenchmarks.dll").Hash;runtime=[Runtime.InteropServices.RuntimeInformation]::FrameworkDescription;bars=@(1000,10000);warmups=1000;invocations=1000;completed=$true} |
    ConvertTo-Json | Set-Content -LiteralPath $Output -Encoding utf8
