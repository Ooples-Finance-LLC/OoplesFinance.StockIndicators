```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetTsi** | **1000**  |   **721.97 μs** |   **3.339 μs** |   **1.987 μs** | **18.68** |    **0.28** |        **-** |        **-** |        **-** |   **81.07 KB** |        **0.53** |
| BuilderLatestOnly | Skender.GetTsi | 1000  |   723.62 μs |  18.428 μs |  12.189 μs | 18.72 |    0.41 |        - |        - |        - |   33.41 KB |        0.22 |
| NativeSingle      | Skender.GetTsi | 1000  |    38.66 μs |   0.914 μs |   0.604 μs |  1.00 |    0.02 |   9.2773 |   1.9531 |        - |  152.88 KB |        1.00 |
| NativeParallel    | Skender.GetTsi | 1000  |   142.68 μs |   7.338 μs |   4.854 μs |  3.69 |    0.13 |  25.3906 |   6.8359 |        - |  391.01 KB |        2.56 |
|                   |                |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetTsi** | **10000** | **7,324.70 μs** |  **55.579 μs** |  **33.074 μs** | **11.34** |    **0.23** |        **-** |        **-** |        **-** |  **785.02 KB** |        **0.51** |
| BuilderLatestOnly | Skender.GetTsi | 10000 | 7,197.59 μs |  23.246 μs |  13.834 μs | 11.14 |    0.23 |        - |        - |        - |  315.25 KB |        0.21 |
| NativeSingle      | Skender.GetTsi | 10000 |   646.15 μs |  20.652 μs |  13.660 μs |  1.00 |    0.03 |  97.6563 |  97.6563 |  97.6563 | 1524.76 KB |        1.00 |
| NativeParallel    | Skender.GetTsi | 10000 | 1,849.42 μs | 196.916 μs | 130.248 μs |  2.86 |    0.20 | 359.3750 | 296.8750 | 156.2500 | 3891.66 KB |        2.55 |
