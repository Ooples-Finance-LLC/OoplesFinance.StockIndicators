```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetTsi** | **1000**  |   **729.8 μs** |  **7.77 μs** |  **5.14 μs** |  **81.07 KB** |
| BuilderLatestOnly | Skender.GetTsi | 1000  |   715.2 μs | 23.97 μs | 15.86 μs |  33.41 KB |
| **BuilderFull**       | **Skender.GetTsi** | **10000** | **7,264.7 μs** | **42.83 μs** | **22.40 μs** | **785.02 KB** |
| BuilderLatestOnly | Skender.GetTsi | 10000 | 7,167.4 μs | 17.50 μs |  9.15 μs | 315.11 KB |
