```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetTsi** | **1000**  |   **802.4 μs** |  **5.20 μs** |  **3.09 μs** |  **81.06 KB** |
| BuilderLatestOnly | Skender.GetTsi | 1000  |   775.5 μs |  8.07 μs |  4.80 μs |  33.43 KB |
| **BuilderFull**       | **Skender.GetTsi** | **10000** | **7,940.9 μs** | **82.82 μs** | **43.32 μs** | **784.99 KB** |
| BuilderLatestOnly | Skender.GetTsi | 10000 | 7,951.8 μs | 18.28 μs |  9.56 μs | 315.19 KB |
