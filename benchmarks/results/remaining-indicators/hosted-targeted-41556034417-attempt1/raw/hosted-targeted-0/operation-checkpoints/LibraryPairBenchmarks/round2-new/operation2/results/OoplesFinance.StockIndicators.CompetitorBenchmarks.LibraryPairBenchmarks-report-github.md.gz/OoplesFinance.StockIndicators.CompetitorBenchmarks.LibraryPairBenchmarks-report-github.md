```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)nLine [44]** |   **183.2 μs** |  **5.55 μs** |  **2.90 μs** |  **1.00** |    **0.02** |  **105.41 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)nLine [44] | 1,262.9 μs | 42.48 μs | 28.10 μs |  6.89 |    0.18 |  903.67 KB |        8.57 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Trady(...)nLine [44]** | **1,491.2 μs** | **35.51 μs** | **21.13 μs** |  **1.00** |    **0.02** | **1037.41 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)nLine [44] | 9,221.2 μs | 70.22 μs | 41.79 μs |  6.18 |    0.09 | 8810.77 KB |        8.49 |
