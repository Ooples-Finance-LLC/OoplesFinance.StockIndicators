```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAdl** |   **211.1 μs** | **11.05 μs** |  **5.78 μs** |  **1.00** |    **0.04** |     **159 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAdl |   103.1 μs | 13.96 μs |  8.31 μs |  0.49 |    0.04 |   273.7 KB |        1.72 |
|            |       |                |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAdl** | **1,708.7 μs** | **36.33 μs** | **21.62 μs** |  **1.00** |    **0.02** | **1512.37 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAdl | 1,037.3 μs | 19.09 μs |  9.98 μs |  0.61 |    0.01 | 2655.82 KB |        1.76 |
