```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean         | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |------------------- |-------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ad** |   **173.740 μs** |  **9.042 μs** |  **5.981 μs** |  **1.00** |    **0.05** |  **72.94 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ad |     5.417 μs |  1.742 μs |  1.037 μs |  0.03 |    0.01 |   8.15 KB |        0.11 |
|            |       |                    |              |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ad** | **1,333.022 μs** | **52.128 μs** | **31.020 μs** |  **1.00** |    **0.03** | **713.63 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ad |    28.611 μs |  1.842 μs |  1.096 μs |  0.02 |    0.00 |  86.29 KB |        0.12 |
