```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **198.013 μs** |  **9.7063 μs** |  **5.7761 μs** | **77.51** |    **2.46** |       **-** |      **-** |   **64.9 KB** |        **8.24** |
| BuilderLatestOnly | Ad        | 1000  |   193.463 μs |  3.2818 μs |  1.9530 μs | 75.73 |    1.39 |       - |      - |   17.3 KB |        2.20 |
| NativeSingle      | Ad        | 1000  |     2.555 μs |  0.0629 μs |  0.0416 μs |  1.00 |    0.02 |  0.4730 |      - |   7.88 KB |        1.00 |
| NativeParallel    | Ad        | 1000  |     5.687 μs |  0.4032 μs |  0.2399 μs |  2.23 |    0.10 |  0.4883 |      - |   8.16 KB |        1.04 |
|                   |           |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **Ad**        | **10000** | **1,832.232 μs** | **17.1914 μs** | **10.2303 μs** | **84.26** |    **0.54** | **31.2500** |      **-** | **627.87 KB** |        **8.03** |
| BuilderLatestOnly | Ad        | 10000 | 1,828.356 μs | 18.5286 μs |  9.6908 μs | 84.09 |    0.52 |       - |      - | 158.04 KB |        2.02 |
| NativeSingle      | Ad        | 10000 |    21.744 μs |  0.1620 μs |  0.0847 μs |  1.00 |    0.01 |  4.7607 | 0.8545 |  78.19 KB |        1.00 |
| NativeParallel    | Ad        | 10000 |    44.190 μs |  4.7631 μs |  3.1505 μs |  2.03 |    0.14 |  4.6387 | 0.7324 |  78.48 KB |        1.00 |
