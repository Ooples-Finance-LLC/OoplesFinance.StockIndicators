```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error    | StdDev  | Gen0    | Allocated |
|------------------ |---------- |------ |-----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **193.9 μs** |  **3.73 μs** | **1.95 μs** |       **-** |   **64.9 KB** |
| BuilderLatestOnly | Ad        | 1000  |   194.3 μs |  1.79 μs | 1.06 μs |       - |   17.3 KB |
| **BuilderFull**       | **Ad**        | **10000** | **1,860.1 μs** | **15.93 μs** | **8.33 μs** | **31.2500** | **627.87 KB** |
| BuilderLatestOnly | Ad        | 10000 | 1,831.1 μs | 11.91 μs | 6.23 μs |       - | 158.01 KB |
