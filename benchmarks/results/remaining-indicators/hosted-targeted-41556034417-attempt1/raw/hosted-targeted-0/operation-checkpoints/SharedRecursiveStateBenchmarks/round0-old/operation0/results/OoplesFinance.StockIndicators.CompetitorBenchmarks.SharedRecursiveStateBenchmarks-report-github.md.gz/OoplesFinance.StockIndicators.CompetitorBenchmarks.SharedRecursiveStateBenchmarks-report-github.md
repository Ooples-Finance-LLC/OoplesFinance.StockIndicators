```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |---------- |------ |-----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **135.9 μs** |  **3.54 μs** |  **1.85 μs** |  **3.9063** |      **-** |  **64.84 KB** |
| BuilderLatestOnly | Ad        | 1000  |   129.8 μs |  1.14 μs |  0.60 μs |  0.9766 |      - |  17.27 KB |
| **BuilderFull**       | **Ad**        | **10000** | **1,223.1 μs** | **27.45 μs** | **16.34 μs** | **31.2500** | **7.8125** | **627.75 KB** |
| BuilderLatestOnly | Ad        | 10000 | 1,189.8 μs |  6.51 μs |  3.87 μs |  7.8125 |      - | 157.96 KB |
