```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |----------:|-----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |  **34.68 μs** |   **2.034 μs** |  **1.064 μs** |  **1.01** |    **0.03** |   **5.3711** |   **0.9766** |   **88.31 KB** |        **0.50** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |  29.01 μs |   0.769 μs |  0.458 μs |  0.85 |    0.02 |   2.4414 |   0.2441 |    40.7 KB |        0.23 |
| NativeSingle      | Skender.GetAdl | 1000  |  34.19 μs |   0.915 μs |  0.605 μs |  1.00 |    0.02 |  10.7422 |   2.4414 |  176.21 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 1000  |  78.58 μs |  15.581 μs |  9.272 μs |  2.30 |    0.26 |  28.3203 |   8.7891 |   449.4 KB |        2.55 |
|                   |                |       |           |            |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetAdl** | **10000** | **302.88 μs** |  **12.805 μs** |  **7.620 μs** |  **0.75** |    **0.02** |  **50.7813** |  **17.5781** |  **862.11 KB** |        **0.49** |
| BuilderLatestOnly | Skender.GetAdl | 10000 | 295.64 μs |  15.040 μs |  8.950 μs |  0.73 |    0.02 |  23.4375 |   9.7656 |  392.28 KB |        0.22 |
| NativeSingle      | Skender.GetAdl | 10000 | 402.70 μs |  10.153 μs |  6.042 μs |  1.00 |    0.02 | 105.4688 |  66.4063 | 1758.25 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 10000 | 795.96 μs | 109.318 μs | 72.307 μs |  1.98 |    0.17 | 277.3438 | 203.1250 | 4474.81 KB |        2.55 |
