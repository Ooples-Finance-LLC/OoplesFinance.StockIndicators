```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Gen0     | Gen1    | Allocated  |
|------------------ |--------------------- |------ |------------:|----------:|----------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Accum(...)nLine [28]** | **1000**  |    **95.04 μs** |  **2.749 μs** |  **1.636 μs** |   **7.8125** |       **-** |  **153.97 KB** |
| BuilderLatestOnly | Accum(...)nLine [28] | 1000  |    92.43 μs |  2.760 μs |  1.826 μs |   6.3477 |       - |  106.36 KB |
| **BuilderFull**       | **Accum(...)nLine [28]** | **10000** | **1,138.20 μs** |  **7.102 μs** |  **3.714 μs** | **117.1875** | **54.6875** | **1931.43 KB** |
| BuilderLatestOnly | Accum(...)nLine [28] | 10000 | 1,120.18 μs | 23.765 μs | 12.430 μs |  85.9375 | 23.4375 | 1461.61 KB |
