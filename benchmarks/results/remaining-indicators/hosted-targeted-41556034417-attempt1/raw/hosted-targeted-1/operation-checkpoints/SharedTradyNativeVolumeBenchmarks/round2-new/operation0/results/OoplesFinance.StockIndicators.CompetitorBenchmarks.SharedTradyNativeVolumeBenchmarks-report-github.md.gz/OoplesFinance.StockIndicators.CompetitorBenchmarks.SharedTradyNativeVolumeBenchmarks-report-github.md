```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|----------:|----------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Accum(...)nLine [28]** | **1000**  |    **66.47 μs** |   **0.606 μs** |   **0.361 μs** |  **0.24** |    **0.00** |         **-** |         **-** |        **-** |   **64.78 KB** |        **0.11** |
| BuilderLatestOnly | Accum(...)nLine [28] | 1000  |    66.46 μs |   1.740 μs |   1.151 μs |  0.24 |    0.00 |    0.9766 |         - |        - |   17.13 KB |        0.03 |
| NativeSingle      | Accum(...)nLine [28] | 1000  |   277.52 μs |   3.446 μs |   2.279 μs |  1.00 |    0.01 |   35.1563 |   11.7188 |        - |   594.3 KB |        1.00 |
| NativeParallel    | Accum(...)nLine [28] | 1000  |   263.79 μs |  13.757 μs |   9.099 μs |  0.95 |    0.03 |   56.6406 |   19.5313 |        - |  894.27 KB |        1.50 |
|                   |                      |       |             |            |            |       |         |           |           |          |            |             |
| **BuilderFull**       | **Accum(...)nLine [28]** | **10000** |   **663.59 μs** |  **18.569 μs** |  **11.050 μs** |  **0.18** |    **0.00** |   **35.1563** |   **11.7188** |        **-** |  **627.62 KB** |        **0.11** |
| BuilderLatestOnly | Accum(...)nLine [28] | 10000 |   657.80 μs |  26.265 μs |  15.630 μs |  0.18 |    0.00 |    7.8125 |         - |        - |  157.78 KB |        0.03 |
| NativeSingle      | Accum(...)nLine [28] | 10000 | 3,720.26 μs |  70.073 μs |  46.349 μs |  1.00 |    0.02 |  656.2500 |  468.7500 | 437.5000 | 5824.02 KB |        1.00 |
| NativeParallel    | Accum(...)nLine [28] | 10000 | 3,925.67 μs | 286.694 μs | 170.607 μs |  1.06 |    0.05 | 1250.0000 | 1062.5000 | 968.7500 | 8717.47 KB |        1.50 |
