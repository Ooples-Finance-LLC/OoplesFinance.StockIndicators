```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Accum(...)nLine [28]** | **1000**  |  **69.19 μs** |  **2.164 μs** |  **1.288 μs** |  **3.9063** |  **0.4883** |  **64.74 KB** |
| BuilderLatestOnly | Accum(...)nLine [28] | 1000  |  67.71 μs |  2.147 μs |  1.420 μs |  0.9766 |       - |  17.13 KB |
| **BuilderFull**       | **Accum(...)nLine [28]** | **10000** | **682.40 μs** | **20.104 μs** | **13.297 μs** | **35.1563** | **11.7188** | **627.59 KB** |
| BuilderLatestOnly | Accum(...)nLine [28] | 10000 | 666.98 μs | 37.273 μs | 22.181 μs |  7.8125 |       - | 157.76 KB |
