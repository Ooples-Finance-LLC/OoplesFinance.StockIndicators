```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **395.0 μs** |  **1.30 μs** |  **0.68 μs** |       **-** |  **68.94 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   396.4 μs |  2.37 μs |  1.24 μs |       - |  21.35 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **4,332.3 μs** | **64.97 μs** | **38.66 μs** | **31.2500** | **631.97 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 4,316.0 μs | 11.88 μs |  7.07 μs |       - | 162.11 KB |
