```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **454.4 μs** |  **26.97 μs** | **17.84 μs** |       **-** |  **68.94 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   397.6 μs |   2.88 μs |  1.50 μs |       - |  21.34 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **4,440.0 μs** | **101.76 μs** | **67.31 μs** | **31.2500** | **632.03 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 4,354.0 μs |  15.51 μs |  9.23 μs |       - |  162.2 KB |
