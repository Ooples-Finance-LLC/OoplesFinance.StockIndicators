```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Ratio | RatioSD | Gen0    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **399.7 μs** |  **2.99 μs** |  **1.78 μs** |  **1.18** |    **0.01** |       **-** |  **68.94 KB** |        **8.24** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   395.9 μs |  2.97 μs |  1.77 μs |  1.17 |    0.01 |       - |  21.34 KB |        2.55 |
| NativeSingle      | TaLib(...)Phase [25] | 1000  |   337.6 μs |  1.42 μs |  0.74 μs |  1.00 |    0.00 |       - |   8.37 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 1000  |   489.7 μs | 16.44 μs | 10.88 μs |  1.45 |    0.03 |       - |  30.19 KB |        3.61 |
|                   |                      |       |            |          |          |       |         |         |           |             |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **4,368.2 μs** | **28.76 μs** | **19.02 μs** |  **1.21** |    **0.01** | **31.2500** | **631.96 KB** |        **8.02** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 4,348.7 μs | 16.09 μs |  9.58 μs |  1.21 |    0.00 |       - | 162.14 KB |        2.06 |
| NativeSingle      | TaLib(...)Phase [25] | 10000 | 3,598.4 μs | 15.04 μs |  8.95 μs |  1.00 |    0.00 |       - |   78.8 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 10000 | 5,117.1 μs | 98.75 μs | 58.77 μs |  1.42 |    0.02 |       - |  276.5 KB |        3.51 |
