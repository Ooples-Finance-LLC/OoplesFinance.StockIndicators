```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev  | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|--------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Phase [25]** |   **436.7 μs** |  **4.48 μs** | **2.34 μs** |  **1.00** |    **0.01** |  **110.06 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Phase [25] |   347.3 μs | 12.59 μs | 8.33 μs |  0.80 |    0.02 |   36.27 KB |        0.33 |
|            |       |                      |            |          |         |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)Phase [25]** | **4,498.6 μs** | **16.75 μs** | **8.76 μs** |  **1.00** |    **0.00** | **1035.26 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Phase [25] | 3,627.3 μs | 10.15 μs | 6.72 μs |  0.81 |    0.00 |  328.19 KB |        0.32 |
