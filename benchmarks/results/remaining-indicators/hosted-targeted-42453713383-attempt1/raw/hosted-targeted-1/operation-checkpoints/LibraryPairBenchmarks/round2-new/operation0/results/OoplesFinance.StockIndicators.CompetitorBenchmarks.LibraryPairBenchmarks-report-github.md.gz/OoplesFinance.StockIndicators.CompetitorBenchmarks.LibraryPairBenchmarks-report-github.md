```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tSine [22]** |   **903.6 μs** |  **41.63 μs** | **24.77 μs** |  **1.00** |    **0.04** | **166.42 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tSine [22] |   581.9 μs |  46.59 μs | 27.73 μs |  0.64 |    0.03 |  74.23 KB |        0.45 |
|            |       |                      |            |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)tSine [22]** | **8,761.9 μs** | **160.33 μs** | **95.41 μs** |  **1.00** |    **0.01** | **1594.8 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tSine [22] | 5,902.9 μs |  24.22 μs | 16.02 μs |  0.67 |    0.01 | 653.33 KB |        0.41 |
