```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **804.9 μs** |  **30.73 μs** | **20.33 μs** |  **84.83 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   785.7 μs |   9.13 μs |  4.77 μs |  37.28 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **8,410.3 μs** | **135.89 μs** | **71.07 μs** | **788.82 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 8,318.9 μs |  62.25 μs | 32.56 μs | 319.17 KB |
