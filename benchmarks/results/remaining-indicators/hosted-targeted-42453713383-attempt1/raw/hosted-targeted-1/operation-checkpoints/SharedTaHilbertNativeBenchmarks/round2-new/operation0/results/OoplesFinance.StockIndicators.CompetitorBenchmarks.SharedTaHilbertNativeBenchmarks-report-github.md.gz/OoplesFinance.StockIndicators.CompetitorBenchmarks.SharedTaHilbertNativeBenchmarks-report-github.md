```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|------------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **817.2 μs** |    **11.11 μs** |   **6.61 μs** |  **1.51** |    **0.01** |  **84.83 KB** |        **5.39** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   800.0 μs |    18.93 μs |  11.27 μs |  1.48 |    0.02 |  37.28 KB |        2.37 |
| NativeSingle      | TaLib(...)tSine [22] | 1000  |   541.9 μs |     4.87 μs |   2.90 μs |  1.00 |    0.01 |  15.74 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 1000  |   740.7 μs |    29.09 μs |  15.21 μs |  1.37 |    0.03 |  55.96 KB |        3.55 |
|                   |                      |       |            |             |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **8,763.9 μs** |   **314.74 μs** | **208.18 μs** |  **1.52** |    **0.03** | **789.04 KB** |        **5.04** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 9,194.5 μs | 1,444.59 μs | 859.65 μs |  1.59 |    0.14 | 319.17 KB |        2.04 |
| NativeSingle      | TaLib(...)tSine [22] | 10000 | 5,776.2 μs |    46.87 μs |  24.51 μs |  1.00 |    0.01 | 156.57 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 10000 | 8,137.7 μs |   282.28 μs | 167.98 μs |  1.41 |    0.03 | 548.72 KB |        3.50 |
