```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **796.3 μs** |  **11.75 μs** |  **6.99 μs** |  **84.83 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   779.8 μs |   4.69 μs |  2.46 μs |  37.24 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **8,405.8 μs** |  **44.34 μs** | **23.19 μs** | **788.89 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 8,295.2 μs | 100.09 μs | 52.35 μs | 318.96 KB |
