```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dMode [27]** |  **1,166.1 μs** | **37.28 μs** | **24.66 μs** |  **1.00** |    **0.03** |  **112.73 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dMode [27] |    489.1 μs | 12.49 μs |  8.26 μs |  0.42 |    0.01 |   35.88 KB |        0.32 |
|            |       |                      |             |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)dMode [27]** | **11,925.0 μs** | **91.40 μs** | **54.39 μs** |  **1.00** |    **0.01** | **1040.45 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dMode [27] |  5,016.9 μs | 35.30 μs | 23.35 μs |  0.42 |    0.00 |  289.45 KB |        0.28 |
