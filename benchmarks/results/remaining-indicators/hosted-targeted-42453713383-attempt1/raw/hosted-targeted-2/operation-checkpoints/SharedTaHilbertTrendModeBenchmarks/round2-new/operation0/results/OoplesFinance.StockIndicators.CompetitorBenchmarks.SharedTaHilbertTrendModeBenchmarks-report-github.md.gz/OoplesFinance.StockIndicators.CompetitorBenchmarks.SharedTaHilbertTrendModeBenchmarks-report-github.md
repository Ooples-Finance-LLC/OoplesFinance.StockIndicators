```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1,104.7 μs** |   **4.95 μs** |   **2.59 μs** |  **2.69** |    **0.01** |  **71.68 KB** |       **15.18** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1,117.9 μs |  12.30 μs |   6.43 μs |  2.72 |    0.02 |  24.03 KB |        5.09 |
| NativeSingle      | TaLib(...)dMode [27] | 1000  |    411.1 μs |   2.76 μs |   1.64 μs |  1.00 |    0.01 |   4.72 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 1000  |    630.9 μs |  30.23 μs |  20.00 μs |  1.53 |    0.05 |   17.4 KB |        3.69 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **11,434.0 μs** |  **45.10 μs** |  **23.59 μs** |  **2.31** |    **0.01** |    **635 KB** |       **15.87** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 11,480.3 μs |  34.33 μs |  20.43 μs |  2.32 |    0.01 | 165.55 KB |        4.14 |
| NativeSingle      | TaLib(...)dMode [27] | 10000 |  4,949.7 μs |  16.83 μs |   8.80 μs |  1.00 |    0.00 |  40.02 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 10000 |  6,834.9 μs | 412.25 μs | 272.68 μs |  1.38 |    0.05 |  140.9 KB |        3.52 |
