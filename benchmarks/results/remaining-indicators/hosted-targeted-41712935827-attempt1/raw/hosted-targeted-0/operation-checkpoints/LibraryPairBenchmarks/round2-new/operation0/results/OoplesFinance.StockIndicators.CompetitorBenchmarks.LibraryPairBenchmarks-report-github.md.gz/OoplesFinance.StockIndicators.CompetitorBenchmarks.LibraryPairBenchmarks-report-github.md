```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId           | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |----------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetStoch** |   **190.9 μs** |  **8.30 μs** |  **5.49 μs** |  **1.00** |    **0.04** |  **214.15 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetStoch |   116.2 μs |  7.86 μs |  4.68 μs |  0.61 |    0.03 |  272.27 KB |        1.27 |
|            |       |                  |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetStoch** | **1,907.6 μs** | **18.19 μs** | **10.82 μs** |  **1.00** |    **0.01** | **2073.52 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetStoch | 1,214.8 μs | 10.81 μs |  5.66 μs |  0.64 |    0.00 | 2650.87 KB |        1.28 |
