```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |----------------- |------ |-----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetStoch** | **1000**  |   **214.9 μs** |  **36.71 μs** | **24.28 μs** |       **-** |       **-** |  **95.53 KB** |
| BuilderLatestOnly | Skender.GetStoch | 1000  |   188.1 μs |  10.70 μs |  7.08 μs |  2.9297 |       - |  47.92 KB |
| **BuilderFull**       | **Skender.GetStoch** | **10000** | **2,021.2 μs** | **144.49 μs** | **95.57 μs** | **46.8750** | **15.6250** | **869.35 KB** |
| BuilderLatestOnly | Skender.GetStoch | 10000 | 1,972.4 μs |  79.13 μs | 47.09 μs | 15.6250 |       - | 399.57 KB |
