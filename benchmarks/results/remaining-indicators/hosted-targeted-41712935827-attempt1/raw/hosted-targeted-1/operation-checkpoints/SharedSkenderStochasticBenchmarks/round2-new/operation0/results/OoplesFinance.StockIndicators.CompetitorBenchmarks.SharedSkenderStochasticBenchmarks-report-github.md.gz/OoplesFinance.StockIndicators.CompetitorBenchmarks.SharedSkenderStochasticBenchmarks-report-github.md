```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Gen2    | Allocated  | Alloc Ratio |
|------------------ |----------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetStoch** | **1000**  |   **298.49 μs** |  **56.890 μs** | **37.629 μs** |  **4.49** |    **0.54** |        **-** |       **-** |       **-** |   **95.57 KB** |        **0.52** |
| BuilderLatestOnly | Skender.GetStoch | 1000  |   205.02 μs |  27.094 μs | 17.921 μs |  3.08 |    0.26 |   1.9531 |       - |       - |   47.93 KB |        0.26 |
| NativeSingle      | Skender.GetStoch | 1000  |    66.46 μs |   0.884 μs |  0.462 μs |  1.00 |    0.01 |  11.2305 |  2.4414 |       - |  184.07 KB |        1.00 |
| NativeParallel    | Skender.GetStoch | 1000  |    46.00 μs |   4.084 μs |  2.136 μs |  0.69 |    0.03 |  12.6953 |  2.9297 |       - |  202.83 KB |        1.10 |
|                   |                  |       |             |            |           |       |         |          |         |         |            |             |
| **BuilderFull**       | **Skender.GetStoch** | **10000** | **1,972.79 μs** | **128.814 μs** | **85.202 μs** |  **1.31** |    **0.05** |  **46.8750** | **15.6250** |       **-** |  **869.42 KB** |        **0.47** |
| BuilderLatestOnly | Skender.GetStoch | 10000 | 1,933.23 μs |  85.776 μs | 51.044 μs |  1.28 |    0.03 |  15.6250 |       - |       - |  399.58 KB |        0.22 |
| NativeSingle      | Skender.GetStoch | 10000 | 1,508.16 μs |  10.796 μs |  5.646 μs |  1.00 |    0.00 | 117.1875 | 93.7500 | 46.8750 | 1836.81 KB |        1.00 |
| NativeParallel    | Skender.GetStoch | 10000 |   744.42 μs |  43.586 μs | 28.829 μs |  0.49 |    0.02 | 117.1875 | 54.6875 |       - | 1925.54 KB |        1.05 |
