```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |----------------- |------ |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetStoch** | **1000**  |   **360.8 μs** |  **80.22 μs** |  **53.06 μs** |       **-** |       **-** |   **95.6 KB** |
| BuilderLatestOnly | Skender.GetStoch | 1000  |   204.6 μs |  18.64 μs |  12.33 μs |  1.9531 |       - |  47.96 KB |
| **BuilderFull**       | **Skender.GetStoch** | **10000** | **2,235.7 μs** | **174.44 μs** | **115.38 μs** | **46.8750** | **15.6250** | **869.46 KB** |
| BuilderLatestOnly | Skender.GetStoch | 10000 | 2,130.8 μs | 159.95 μs |  95.19 μs | 15.6250 |       - |  399.6 KB |
