"""Resume only the failed zero-case timing step; prior qualification is already committed."""
from pathlib import Path
import datetime,json,subprocess
root=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
repo=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-zigzag-compact-publication-20261028')
status=root/'zigzag-compact-publication-continuation-20261028.json'
def save(step,**extra):
    tmp=status.with_suffix('.tmp');tmp.write_text(json.dumps(dict(step=step,updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**extra),indent=2));tmp.replace(status);print(step,flush=True)
def run(name):
    save(name)
    with (root/(name+'.log')).open('wb') as log:
        subprocess.run(['python3.13.exe','-X','utf8',str(root/name)],stdout=log,stderr=subprocess.STDOUT,check=True)
try:
    qualified=json.loads((root/'zigzag-compact-publication/status.json').read_text())
    assert qualified['status']=='checks-passed-review-and-publication-pending'
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
    subprocess.run(['git','diff','--exit-code',qualified['input_head'],'HEAD','--','src','tests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','benchmarks/OoplesFinance.StockIndicators.CompetitorTests','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json'],cwd=repo,check=True)
    subprocess.run(['git','cat-file','-e','HEAD:benchmarks/results/remaining-indicators/publication-zigzag-compact-publication-certified-20261028-verification.json'],cwd=repo,check=True)
    run('measure-zigzag-compact-publication-control-20261028.py')
    run('verify-zigzag-compact-publication-control-20261028.py')
    save('qualified-awaiting-acceptance-and-publication-review')
except Exception as error:
    save('failed-needs-inspection',error=repr(error));raise
