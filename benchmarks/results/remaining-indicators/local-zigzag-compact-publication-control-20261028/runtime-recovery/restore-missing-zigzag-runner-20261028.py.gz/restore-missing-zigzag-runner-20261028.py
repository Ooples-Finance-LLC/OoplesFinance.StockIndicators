from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,psutil
root=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
repo=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-zigzag-exact-scale-20261028')
previous=root/'local-zigzag-exact-scale-control-20261028'
source=previous/'new'
target=repo/'benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks/bin/Release/net10.0'
recovery=root/'zigzag-missing-runner-recovery-20261028';recovery.mkdir(exist_ok=False)
manifest=json.loads((previous/'binary-manifest.json').read_text())['new']
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def actual(p):return {f.relative_to(p).as_posix():digest(f) for f in p.rglob('*') if f.is_file()}
assert actual(source)==manifest
proof=json.loads((previous/'provenance.json').read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head==proof['new_source']
qualified=json.loads((root/'zigzag-exact-scale/status.json').read_text())
assert manifest['OoplesFinance.StockIndicators.dll'] in qualified['production_dll_sha256'].values()
old=actual(target)
assert all(relative in manifest and digest_value==manifest[relative] for relative,digest_value in old.items())
assert 'OoplesFinance.StockIndicators.CompetitorBenchmarks.dll' in manifest
for p in psutil.process_iter(['name','cmdline']):
    assert not ((p.info['name'] or '').lower()=='dotnet.exe' and any('OoplesFinance.StockIndicators.CompetitorBenchmarks.dll' in a for a in (p.info['cmdline'] or [])))
for relative in manifest:
    dest=target/relative
    assert dest.resolve().is_relative_to(target.resolve())
    if not dest.exists():
        dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source/relative,dest)
assert actual(target)==manifest
receipt={'restored_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':str(source),'target':str(target),'qualified_source':head,'prior_manifest':old,'restored_manifest':manifest,'note':'Restored missing files from the byte-verified previously accepted16-case exact-scale ZigZag runtime. No production rebuild or changed binary; all restored bytes match prior accepted measurement manifest.'}
(recovery/'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
for filename in ['zigzag-compact-publication-continuation-20261028.json','accepted-arithmetic-integration-continuation-20261028.json','accepted-arithmetic-publication-continuation-20261028.json','compact-macd-unit-round-continuation-20261028.json','compact-macd-unit-round-timing-continuation-20261028.json','measure-zigzag-compact-publication-control-20261028.py.log']:
    shutil.copy2(root/filename,recovery/filename)
print('Restored',len(manifest)-len(old),'missing runtime files; all',len(manifest),'files byte-match accepted baseline.')
