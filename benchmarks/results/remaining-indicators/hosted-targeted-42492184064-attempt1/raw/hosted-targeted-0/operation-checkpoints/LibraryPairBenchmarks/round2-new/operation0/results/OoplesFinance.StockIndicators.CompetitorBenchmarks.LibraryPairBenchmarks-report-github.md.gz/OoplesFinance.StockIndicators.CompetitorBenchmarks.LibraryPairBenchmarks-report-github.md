```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error      | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)eriod [26]** |   **510.66 μs** |  **17.914 μs** | **10.660 μs** |  **1.00** |    **0.03** |  **107.65 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)eriod [26] |    96.75 μs |   1.940 μs |  1.283 μs |  0.19 |    0.00 |   39.42 KB |        0.37 |
|            |       |                      |             |            |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)eriod [26]** | **5,092.14 μs** | **129.398 μs** | **85.589 μs** |  **1.00** |    **0.02** | **1035.38 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)eriod [26] |   972.53 μs |  34.416 μs | 22.764 μs |  0.19 |    0.01 |  331.38 KB |        0.32 |
