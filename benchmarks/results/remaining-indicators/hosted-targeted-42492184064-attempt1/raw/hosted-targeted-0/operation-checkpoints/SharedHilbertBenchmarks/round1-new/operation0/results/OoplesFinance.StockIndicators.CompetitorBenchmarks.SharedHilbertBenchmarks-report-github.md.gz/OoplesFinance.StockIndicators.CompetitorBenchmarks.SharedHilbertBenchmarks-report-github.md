```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)eriod [26]** | **1000**  |   **405.9 μs** | **17.43 μs** | **11.53 μs** |       **-** |  **66.53 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 1000  |   400.7 μs |  6.85 μs |  4.08 μs |       - |  18.93 KB |
| **BuilderFull**       | **TaLib(...)eriod [26]** | **10000** | **4,010.4 μs** | **83.73 μs** | **49.83 μs** | **31.2500** | **629.53 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 10000 | 4,429.0 μs | 95.75 μs | 56.98 μs |       - | 159.71 KB |
