```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)eriod [26]** | **1000**  |   **421.7 μs** | **19.40 μs** | **10.14 μs** |       **-** |  **66.49 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 1000  |   417.6 μs |  5.83 μs |  3.05 μs |       - |  18.94 KB |
| **BuilderFull**       | **TaLib(...)eriod [26]** | **10000** | **4,057.9 μs** | **81.09 μs** | **42.41 μs** | **31.2500** | **629.48 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 10000 | 4,168.8 μs | 97.09 μs | 57.77 μs |       - | 159.74 KB |
