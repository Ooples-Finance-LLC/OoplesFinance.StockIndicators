```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)eriod [26]** | **1000**  |   **382.8 μs** |  **10.17 μs** |   **5.32 μs** |       **-** |  **66.52 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 1000  |   378.8 μs |  15.43 μs |  10.21 μs |       - |  18.92 KB |
| **BuilderFull**       | **TaLib(...)eriod [26]** | **10000** | **3,728.1 μs** | **160.12 μs** | **105.91 μs** | **31.2500** | **629.54 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 10000 | 3,804.6 μs | 123.09 μs |  64.38 μs |       - |  159.8 KB |
