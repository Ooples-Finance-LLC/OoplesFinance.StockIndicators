```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)eriod [26]** | **1000**  |   **415.3 μs** |   **7.24 μs** |   **4.31 μs** |  **3.93** |    **0.08** |       **-** |  **66.53 KB** |        **8.32** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 1000  |   406.4 μs |   5.54 μs |   3.30 μs |  3.85 |    0.07 |       - |  18.93 KB |        2.37 |
| NativeSingle      | TaLib(...)eriod [26] | 1000  |   105.6 μs |   2.74 μs |   1.81 μs |  1.00 |    0.02 |       - |   7.99 KB |        1.00 |
| NativeParallel    | TaLib(...)eriod [26] | 1000  |   181.3 μs |  17.42 μs |  11.52 μs |  1.72 |    0.11 |  1.9531 |  28.36 KB |        3.55 |
|                   |                      |       |            |           |           |       |         |         |           |             |
| **BuilderFull**       | **TaLib(...)eriod [26]** | **10000** | **4,191.3 μs** |  **60.91 μs** |  **31.85 μs** |  **4.01** |    **0.13** | **31.2500** | **629.63 KB** |        **8.04** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 10000 | 3,948.4 μs | 264.57 μs | 157.44 μs |  3.78 |    0.18 |       - |  159.7 KB |        2.04 |
| NativeSingle      | TaLib(...)eriod [26] | 10000 | 1,046.9 μs |  50.60 μs |  33.47 μs |  1.00 |    0.04 |       - |  78.36 KB |        1.00 |
| NativeParallel    | TaLib(...)eriod [26] | 10000 | 1,225.5 μs |  94.41 μs |  62.44 μs |  1.17 |    0.07 | 15.6250 | 274.51 KB |        3.50 |
