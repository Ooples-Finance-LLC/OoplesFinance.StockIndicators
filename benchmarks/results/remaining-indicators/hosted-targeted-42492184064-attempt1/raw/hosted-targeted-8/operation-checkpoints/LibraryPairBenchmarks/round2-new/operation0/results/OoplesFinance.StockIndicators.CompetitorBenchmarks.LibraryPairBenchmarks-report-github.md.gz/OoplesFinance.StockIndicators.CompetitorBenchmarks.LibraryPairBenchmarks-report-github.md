```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Mama** |   **580.4 μs** | **24.36 μs** | **14.49 μs** |  **1.00** |    **0.03** |  **164.02 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Mama |   271.4 μs | 10.75 μs |  7.11 μs |  0.47 |    0.02 |   96.33 KB |        0.59 |
|            |       |                |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Mama** | **5,476.4 μs** | **28.46 μs** | **16.94 μs** |  **1.00** |    **0.00** | **1593.42 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Mama | 2,627.6 μs | 25.71 μs | 15.30 μs |  0.48 |    0.00 |  888.33 KB |        0.56 |
