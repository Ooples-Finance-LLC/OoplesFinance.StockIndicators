```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Mama** | **1000**  |   **435.6 μs** | **39.71 μs** | **20.77 μs** |       **-** |  **82.61 KB** |
| BuilderLatestOnly | QuanTAlib.Mama | 1000  |   448.7 μs | 20.47 μs | 13.54 μs |       - |  35.01 KB |
| **BuilderFull**       | **QuanTAlib.Mama** | **10000** | **4,236.7 μs** | **48.13 μs** | **28.64 μs** | **31.2500** | **786.09 KB** |
| BuilderLatestOnly | QuanTAlib.Mama | 10000 | 4,156.7 μs | 37.24 μs | 22.16 μs |       - |  316.5 KB |
