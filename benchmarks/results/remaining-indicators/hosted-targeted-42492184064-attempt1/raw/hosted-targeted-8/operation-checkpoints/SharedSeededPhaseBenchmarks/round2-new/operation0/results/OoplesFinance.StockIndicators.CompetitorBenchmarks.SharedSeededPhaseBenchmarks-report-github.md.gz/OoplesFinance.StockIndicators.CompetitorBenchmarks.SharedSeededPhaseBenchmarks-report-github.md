```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |-----------:|----------:|----------:|------:|--------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Mama** | **1000**  |   **441.1 μs** |   **4.79 μs** |   **2.50 μs** |  **1.91** |    **0.01** |       **-** |       **-** |       **-** |   **82.57 KB** |        **1.47** |
| BuilderLatestOnly | QuanTAlib.Mama | 1000  |   435.5 μs |   0.88 μs |   0.46 μs |  1.89 |    0.00 |       - |       - |       - |   35.01 KB |        0.62 |
| NativeSingle      | QuanTAlib.Mama | 1000  |   230.4 μs |   0.65 μs |   0.39 μs |  1.00 |    0.00 |  1.9531 |       - |       - |   56.24 KB |        1.00 |
| NativeParallel    | QuanTAlib.Mama | 1000  |   616.6 μs |  87.72 μs |  58.02 μs |  2.68 |    0.24 |  3.9063 |       - |       - |  119.62 KB |        2.13 |
|                   |                |       |            |           |           |       |         |         |         |         |            |             |
| **BuilderFull**       | **QuanTAlib.Mama** | **10000** | **4,234.7 μs** |  **15.44 μs** |   **8.07 μs** |  **1.80** |    **0.01** | **31.2500** |       **-** |       **-** |  **786.23 KB** |        **1.43** |
| BuilderLatestOnly | QuanTAlib.Mama | 10000 | 4,201.2 μs |  16.52 μs |  10.93 μs |  1.79 |    0.01 |       - |       - |       - |   316.5 KB |        0.58 |
| NativeSingle      | QuanTAlib.Mama | 10000 | 2,349.0 μs |  26.42 μs |  13.82 μs |  1.00 |    0.01 | 46.8750 | 31.2500 | 31.2500 |  548.76 KB |        1.00 |
| NativeParallel    | QuanTAlib.Mama | 10000 | 4,434.6 μs | 356.23 μs | 186.31 μs |  1.89 |    0.08 | 31.2500 |       - |       - | 1139.37 KB |        2.08 |
