```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **474.7 μs** |  **13.66 μs** |   **9.04 μs** |  **1.21** |    **0.03** |       **-** |  **84.79 KB** |        **5.39** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   458.3 μs |  10.77 μs |   6.41 μs |  1.17 |    0.02 |       - |  37.23 KB |        2.37 |
| NativeSingle      | TaLib(...)tSine [22] | 1000  |   393.0 μs |   7.90 μs |   4.70 μs |  1.00 |    0.02 |       - |  15.72 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 1000  |   574.2 μs |  24.21 μs |  14.41 μs |  1.46 |    0.04 |  3.9063 |  55.96 KB |        3.56 |
|                   |                      |       |            |           |           |       |         |         |           |             |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **5,358.4 μs** | **172.37 μs** | **102.57 μs** |  **1.28** |    **0.03** | **31.2500** | **788.42 KB** |        **5.04** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 5,321.0 μs | 109.49 μs |  57.27 μs |  1.27 |    0.02 |       - |  318.6 KB |        2.04 |
| NativeSingle      | TaLib(...)tSine [22] | 10000 | 4,197.4 μs | 103.13 μs |  61.37 μs |  1.00 |    0.02 |       - | 156.41 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 10000 | 6,078.8 μs | 354.11 μs | 185.21 μs |  1.45 |    0.05 |       - | 548.61 KB |        3.51 |
