```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **463.8 μs** |  **5.58 μs** |  **2.92 μs** |       **-** |  **84.83 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   460.8 μs |  6.98 μs |  3.65 μs |       - |  37.23 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **5,122.6 μs** | **65.47 μs** | **38.96 μs** | **31.2500** | **788.45 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 5,049.0 μs | 45.52 μs | 23.81 μs |       - | 318.57 KB |
