```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **451.9 μs** |   **9.13 μs** |   **5.43 μs** |       **-** |   **84.8 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   451.1 μs |   3.09 μs |   1.62 μs |       - |  37.23 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **5,210.5 μs** | **116.08 μs** |  **60.71 μs** | **31.2500** | **788.49 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 5,583.9 μs | 779.24 μs | 515.42 μs |       - | 318.64 KB |
