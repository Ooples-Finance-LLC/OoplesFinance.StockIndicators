```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tSine [22]** |   **541.7 μs** | **15.17 μs** |  **9.03 μs** |  **1.00** |    **0.02** |  **166.46 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tSine [22] |   396.5 μs |  8.03 μs |  5.31 μs |  0.73 |    0.01 |   66.41 KB |        0.40 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)tSine [22]** | **5,531.0 μs** | **56.77 μs** | **33.78 μs** |  **1.00** |    **0.01** | **1591.27 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tSine [22] | 4,136.8 μs | 42.59 μs | 28.17 μs |  0.75 |    0.01 |  647.14 KB |        0.41 |
