```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)dline [22]** |   **894.5 μs** | **27.10 μs** | **16.13 μs** |  **1.00** |    **0.02** |  **222.95 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)dline [22] |   149.4 μs |  1.00 μs |  0.52 μs |  0.17 |    0.00 |  289.87 KB |        1.30 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)dline [22]** | **8,625.5 μs** | **22.77 μs** | **11.91 μs** |  **1.00** |    **0.00** | **2151.65 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)dline [22] | 1,496.0 μs | 25.82 μs | 13.50 μs |  0.17 |    0.00 |    2812 KB |        1.31 |
