```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|-------:|----------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  |   **774.8 μs** |  **6.95 μs** |  **4.13 μs** | **3.9063** | **100.86 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  |   757.0 μs |  3.06 μs |  1.82 μs |      - |  53.29 KB |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **7,406.8 μs** | **71.37 μs** | **37.33 μs** |      **-** |  **945.5 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 7,482.6 μs | 91.29 μs | 54.32 μs |      - | 475.47 KB |
