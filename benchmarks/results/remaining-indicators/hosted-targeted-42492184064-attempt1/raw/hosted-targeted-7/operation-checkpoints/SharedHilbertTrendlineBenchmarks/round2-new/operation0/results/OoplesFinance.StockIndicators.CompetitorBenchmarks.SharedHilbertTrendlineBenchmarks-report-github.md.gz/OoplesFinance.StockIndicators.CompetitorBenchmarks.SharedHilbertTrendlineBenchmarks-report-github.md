```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  |   **719.4 μs** |   **1.87 μs** |   **1.11 μs** |  **6.72** |    **0.02** |        **-** |        **-** |        **-** |  **100.94 KB** |        **0.49** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  |   711.4 μs |  18.80 μs |  12.43 μs |  6.65 |    0.11 |        - |        - |        - |   53.28 KB |        0.26 |
| NativeSingle      | Skend(...)dline [22] | 1000  |   107.0 μs |   0.62 μs |   0.37 μs |  1.00 |    0.00 |  12.6953 |   2.9297 |        - |  207.71 KB |        1.00 |
| NativeParallel    | Skend(...)dline [22] | 1000  |   206.6 μs |   9.67 μs |   5.06 μs |  1.93 |    0.04 |  33.2031 |  11.7188 |        - |  528.53 KB |        2.54 |
|                   |                      |       |            |           |           |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **6,937.8 μs** |  **34.18 μs** |  **17.88 μs** |  **5.63** |    **0.05** |        **-** |        **-** |        **-** |  **945.38 KB** |        **0.46** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 6,864.2 μs |  36.49 μs |  19.08 μs |  5.57 |    0.04 |        - |        - |        - |  475.52 KB |        0.23 |
| NativeSingle      | Skend(...)dline [22] | 10000 | 1,233.2 μs |  16.70 μs |   9.94 μs |  1.00 |    0.01 | 187.5000 | 156.2500 |  85.9375 | 2071.87 KB |        1.00 |
| NativeParallel    | Skend(...)dline [22] | 10000 | 2,392.3 μs | 214.00 μs | 141.55 μs |  1.94 |    0.11 | 421.8750 | 343.7500 | 140.6250 | 5258.64 KB |        2.54 |
