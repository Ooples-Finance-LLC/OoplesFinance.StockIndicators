```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|-------:|----------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  |   **729.2 μs** | **22.96 μs** | **15.19 μs** | **3.9063** | **100.86 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  |   725.9 μs | 13.56 μs |  8.97 μs |      - |  53.27 KB |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **6,947.6 μs** | **48.49 μs** | **28.86 μs** |      **-** | **945.28 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 6,990.3 μs | 77.55 μs | 46.15 μs |      - | 475.56 KB |
