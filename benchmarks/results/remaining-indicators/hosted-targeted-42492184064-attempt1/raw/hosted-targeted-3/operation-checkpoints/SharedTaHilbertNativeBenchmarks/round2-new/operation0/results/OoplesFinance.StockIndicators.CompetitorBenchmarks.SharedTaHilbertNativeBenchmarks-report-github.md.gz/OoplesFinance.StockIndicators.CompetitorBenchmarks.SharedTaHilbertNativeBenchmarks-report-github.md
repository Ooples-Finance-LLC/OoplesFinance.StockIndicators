```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **595.3 μs** |   **6.49 μs** |   **3.86 μs** |  **1.64** |    **0.01** |  **68.94 KB** |        **8.24** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   612.1 μs |  13.83 μs |   8.23 μs |  1.69 |    0.02 |  21.35 KB |        2.55 |
| NativeSingle      | TaLib(...)Phase [25] | 1000  |   362.3 μs |   1.51 μs |   0.90 μs |  1.00 |    0.00 |   8.37 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 1000  |   551.9 μs |  27.39 μs |  18.12 μs |  1.52 |    0.05 |  30.19 KB |        3.61 |
|                   |                      |       |            |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **6,622.0 μs** |  **61.58 μs** |  **36.64 μs** |  **1.52** |    **0.01** | **632.14 KB** |        **8.02** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 6,610.1 μs |  48.19 μs |  25.21 μs |  1.52 |    0.01 | 162.45 KB |        2.06 |
| NativeSingle      | TaLib(...)Phase [25] | 10000 | 4,345.6 μs |  26.37 μs |  15.70 μs |  1.00 |    0.00 |  78.87 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 10000 | 6,255.1 μs | 421.94 μs | 279.09 μs |  1.44 |    0.06 | 276.75 KB |        3.51 |
