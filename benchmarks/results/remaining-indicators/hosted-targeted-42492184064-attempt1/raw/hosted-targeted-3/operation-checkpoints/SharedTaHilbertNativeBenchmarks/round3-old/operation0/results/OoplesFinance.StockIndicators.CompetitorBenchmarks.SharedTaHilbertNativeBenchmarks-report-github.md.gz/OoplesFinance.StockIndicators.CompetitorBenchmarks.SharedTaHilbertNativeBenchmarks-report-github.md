```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **604.3 μs** | **23.73 μs** | **15.70 μs** |  **68.94 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   587.3 μs |  6.40 μs |  3.81 μs |  21.34 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **6,405.5 μs** | **82.48 μs** | **43.14 μs** | **632.14 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 6,416.9 μs | 19.25 μs | 10.07 μs | 162.37 KB |
