```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **601.5 μs** |  **20.45 μs** | **12.17 μs** |  **68.94 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   586.8 μs |   8.74 μs |  5.20 μs |  21.35 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **6,441.5 μs** | **122.25 μs** | **80.86 μs** | **632.17 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 6,428.0 μs |  41.85 μs | 21.89 μs | 162.29 KB |
