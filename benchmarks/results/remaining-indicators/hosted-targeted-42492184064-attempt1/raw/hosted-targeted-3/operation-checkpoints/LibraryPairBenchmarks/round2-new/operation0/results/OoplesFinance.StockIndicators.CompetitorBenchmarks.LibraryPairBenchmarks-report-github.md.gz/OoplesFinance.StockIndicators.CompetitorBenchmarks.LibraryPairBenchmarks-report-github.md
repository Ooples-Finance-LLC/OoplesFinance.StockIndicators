```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Phase [25]** |   **681.7 μs** | **23.67 μs** | **14.09 μs** |  **1.00** |    **0.03** | **110.06 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Phase [25] |   421.2 μs |  1.62 μs |  0.97 μs |  0.62 |    0.01 |  39.13 KB |        0.36 |
|            |       |                      |            |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Phase [25]** | **6,783.2 μs** | **57.54 μs** | **38.06 μs** |  **1.00** |    **0.01** | **1041.4 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Phase [25] | 4,415.3 μs | 22.77 μs | 13.55 μs |  0.65 |    0.00 | 327.91 KB |        0.31 |
