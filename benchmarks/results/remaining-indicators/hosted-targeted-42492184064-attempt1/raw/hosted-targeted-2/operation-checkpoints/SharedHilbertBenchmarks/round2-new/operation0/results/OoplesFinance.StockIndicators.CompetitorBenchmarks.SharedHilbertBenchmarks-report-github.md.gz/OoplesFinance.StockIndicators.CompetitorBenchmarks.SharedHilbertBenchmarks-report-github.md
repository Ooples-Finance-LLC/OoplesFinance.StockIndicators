```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Mama** | **1000**  |   **611.2 μs** |   **5.37 μs** |  **2.81 μs** |  **5.76** |    **0.03** |        **-** |        **-** |        **-** |  **82.61 KB** |        **5.31** |
| BuilderLatestOnly | TaLib.Functions.Mama | 1000  |   616.4 μs |  29.30 μs | 19.38 μs |  5.81 |    0.17 |        - |        - |        - |  35.02 KB |        2.25 |
| NativeSingle      | TaLib.Functions.Mama | 1000  |   106.1 μs |   0.37 μs |  0.22 μs |  1.00 |    0.00 |        - |        - |        - |  15.55 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mama | 1000  |   196.0 μs |  18.86 μs | 12.47 μs |  1.85 |    0.11 |   3.9063 |        - |        - |  54.84 KB |        3.53 |
|                   |                      |       |            |           |          |       |         |          |          |          |           |             |
| **BuilderFull**       | **TaLib.Functions.Mama** | **10000** | **6,068.8 μs** |  **46.45 μs** | **27.64 μs** |  **5.21** |    **0.07** |  **31.2500** |        **-** |        **-** | **786.33 KB** |        **5.02** |
| BuilderLatestOnly | TaLib.Functions.Mama | 10000 | 5,978.5 μs |  24.72 μs | 16.35 μs |  5.13 |    0.06 |        - |        - |        - | 316.51 KB |        2.02 |
| NativeSingle      | TaLib.Functions.Mama | 10000 | 1,165.7 μs |  25.30 μs | 15.05 μs |  1.00 |    0.02 |  46.8750 |  46.8750 |  46.8750 |  156.6 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mama | 10000 | 1,684.1 μs | 111.70 μs | 58.42 μs |  1.44 |    0.05 | 125.0000 | 125.0000 | 125.0000 |  548.1 KB |        3.50 |
