```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mama** | **1000**  |   **591.4 μs** |  **3.17 μs** |  **1.66 μs** |       **-** |  **82.61 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 1000  |   593.3 μs |  3.01 μs |  1.79 μs |       - |     35 KB |
| **BuilderFull**       | **TaLib.Functions.Mama** | **10000** | **5,901.0 μs** | **52.11 μs** | **31.01 μs** | **31.2500** | **786.31 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 10000 | 5,975.5 μs | 25.22 μs | 15.01 μs |       - |  316.5 KB |
