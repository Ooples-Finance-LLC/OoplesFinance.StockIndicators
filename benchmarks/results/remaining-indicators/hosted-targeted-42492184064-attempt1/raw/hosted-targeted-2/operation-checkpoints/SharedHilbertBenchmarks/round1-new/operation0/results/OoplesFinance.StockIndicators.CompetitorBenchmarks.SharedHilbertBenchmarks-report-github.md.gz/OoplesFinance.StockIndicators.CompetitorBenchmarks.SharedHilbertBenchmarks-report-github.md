```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error       | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|------------:|----------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mama** | **1000**  |   **750.8 μs** |   **177.76 μs** | **117.58 μs** |       **-** |  **82.61 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 1000  |   631.5 μs |    14.95 μs |   8.89 μs |       - |  35.03 KB |
| **BuilderFull**       | **TaLib.Functions.Mama** | **10000** | **6,967.8 μs** | **1,032.64 μs** | **683.03 μs** | **31.2500** | **786.34 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 10000 | 6,207.8 μs |   353.00 μs | 210.06 μs |       - | 316.75 KB |
