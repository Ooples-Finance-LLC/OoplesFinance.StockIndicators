```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mama** | **1000**  |   **618.4 μs** |  **3.03 μs** |  **1.58 μs** |       **-** |  **82.58 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 1000  |   618.2 μs |  6.58 μs |  3.44 μs |       - |  35.02 KB |
| **BuilderFull**       | **TaLib.Functions.Mama** | **10000** | **6,190.7 μs** | **45.88 μs** | **27.30 μs** | **31.2500** | **786.29 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 10000 | 6,109.2 μs | 27.52 μs | 16.38 μs |       - | 316.49 KB |
