```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Mama** |   **745.8 μs** | **35.33 μs** | **21.02 μs** |  **1.00** |    **0.04** |  **164.02 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Mama |   128.7 μs |  0.94 μs |  0.49 μs |  0.17 |    0.00 |   73.78 KB |        0.45 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Mama** | **7,067.0 μs** | **54.93 μs** | **32.69 μs** |  **1.00** |    **0.01** | **1595.72 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Mama | 1,253.5 μs | 40.34 μs | 26.68 μs |  0.18 |    0.00 |  654.19 KB |        0.41 |
