```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)dline [27]** | **1000**  |   **732.1 μs** |  **28.64 μs** |  **18.94 μs** | **3.9063** |  **69.19 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 1000  |   718.0 μs |   2.75 μs |   1.44 μs |      - |   21.6 KB |
| **BuilderFull**       | **TaLib(...)dline [27]** | **10000** | **7,612.2 μs** |  **55.38 μs** |  **32.95 μs** |      **-** | **632.41 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 10000 | 7,619.0 μs | 178.46 μs | 106.20 μs |      - | 162.79 KB |
