```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dline [27]** | **1000**  |   **723.09 μs** |  **5.796 μs** |  **3.032 μs** |  **7.60** |    **0.20** |  **3.9063** |  **69.19 KB** |        **8.71** |
| BuilderLatestOnly | TaLib(...)dline [27] | 1000  |   721.60 μs |  5.165 μs |  2.702 μs |  7.59 |    0.20 |       - |   21.6 KB |        2.72 |
| NativeSingle      | TaLib(...)dline [27] | 1000  |    95.15 μs |  4.029 μs |  2.665 μs |  1.00 |    0.04 |       - |   7.95 KB |        1.00 |
| NativeParallel    | TaLib(...)dline [27] | 1000  |   172.06 μs | 15.868 μs | 10.496 μs |  1.81 |    0.12 |  1.9531 |  28.52 KB |        3.59 |
|                   |                      |       |             |           |           |       |         |         |           |             |
| **BuilderFull**       | **TaLib(...)dline [27]** | **10000** | **7,978.76 μs** | **28.053 μs** | **16.694 μs** |  **7.48** |    **0.05** |       **-** | **632.48 KB** |        **8.08** |
| BuilderLatestOnly | TaLib(...)dline [27] | 10000 | 7,772.98 μs | 27.417 μs | 14.340 μs |  7.28 |    0.05 |       - | 162.68 KB |        2.08 |
| NativeSingle      | TaLib(...)dline [27] | 10000 | 1,067.05 μs | 11.926 μs |  7.097 μs |  1.00 |    0.01 |       - |  78.31 KB |        1.00 |
| NativeParallel    | TaLib(...)dline [27] | 10000 | 1,348.65 μs | 44.072 μs | 29.151 μs |  1.26 |    0.03 | 15.6250 | 274.66 KB |        3.51 |
