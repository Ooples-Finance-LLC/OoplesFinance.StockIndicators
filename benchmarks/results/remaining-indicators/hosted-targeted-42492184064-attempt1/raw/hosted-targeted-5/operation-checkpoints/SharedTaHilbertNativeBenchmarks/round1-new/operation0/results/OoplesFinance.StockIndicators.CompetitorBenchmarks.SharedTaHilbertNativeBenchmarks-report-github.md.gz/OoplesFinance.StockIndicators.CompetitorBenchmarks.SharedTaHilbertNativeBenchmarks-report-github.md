```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)dline [27]** | **1000**  |   **727.0 μs** |  **5.08 μs** |  **2.66 μs** |  **69.19 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 1000  |   718.9 μs |  6.38 μs |  3.80 μs |   21.6 KB |
| **BuilderFull**       | **TaLib(...)dline [27]** | **10000** | **7,842.2 μs** | **18.26 μs** |  **9.55 μs** | **632.57 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 10000 | 7,968.1 μs | 63.53 μs | 42.02 μs | 162.71 KB |
