```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dline [27]** |   **828.0 μs** | **29.52 μs** | **17.57 μs** |  **1.00** |    **0.03** |   **110.1 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dline [27] |   126.3 μs |  1.76 μs |  1.05 μs |  0.15 |    0.00 |   39.84 KB |        0.36 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)dline [27]** | **7,895.6 μs** | **36.89 μs** | **21.95 μs** |  **1.00** |    **0.00** | **1037.88 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dline [27] | 1,210.0 μs | 21.23 μs | 14.04 μs |  0.15 |    0.00 |  329.22 KB |        0.32 |
