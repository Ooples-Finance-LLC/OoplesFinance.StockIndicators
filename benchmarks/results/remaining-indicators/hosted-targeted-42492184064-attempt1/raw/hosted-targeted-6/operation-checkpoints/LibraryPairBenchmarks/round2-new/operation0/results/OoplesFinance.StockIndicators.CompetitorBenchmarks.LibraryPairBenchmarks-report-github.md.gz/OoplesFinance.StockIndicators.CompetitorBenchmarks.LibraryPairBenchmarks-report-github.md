```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dMode [27]** |  **1,488.4 μs** | **29.81 μs** | **17.74 μs** |  **1.00** |    **0.02** |  **112.73 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dMode [27] |    615.9 μs | 22.56 μs | 14.92 μs |  0.41 |    0.01 |   38.18 KB |        0.34 |
|            |       |                      |             |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)dMode [27]** | **14,958.9 μs** | **67.15 μs** | **35.12 μs** |  **1.00** |    **0.00** | **1043.78 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dMode [27] |  6,405.9 μs | 37.63 μs | 24.89 μs |  0.43 |    0.00 |  292.73 KB |        0.28 |
