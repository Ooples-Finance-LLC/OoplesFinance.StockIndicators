```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **2.060 ms** | **0.0073 ms** | **0.0048 ms** |   **71.7 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1.447 ms | 0.0090 ms | 0.0047 ms |  24.05 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **14.854 ms** | **0.0388 ms** | **0.0203 ms** | **635.42 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 14.830 ms | 0.0726 ms | 0.0432 ms | 165.73 KB |
