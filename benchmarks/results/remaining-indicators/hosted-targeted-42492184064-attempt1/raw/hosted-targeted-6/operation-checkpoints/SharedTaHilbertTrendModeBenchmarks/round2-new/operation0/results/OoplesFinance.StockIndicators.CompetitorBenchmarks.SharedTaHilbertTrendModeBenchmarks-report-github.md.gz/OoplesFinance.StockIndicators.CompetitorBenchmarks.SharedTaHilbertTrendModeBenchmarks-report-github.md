```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1,479.7 μs** |  **17.05 μs** |  **10.14 μs** |  **2.55** |    **0.02** |   **71.7 KB** |       **15.15** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1,446.7 μs |  14.97 μs |   8.91 μs |  2.49 |    0.02 |  24.12 KB |        5.10 |
| NativeSingle      | TaLib(...)dMode [27] | 1000  |    580.3 μs |   2.10 μs |   1.25 μs |  1.00 |    0.00 |   4.73 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 1000  |    816.0 μs |  28.15 μs |  18.62 μs |  1.41 |    0.03 |  17.43 KB |        3.68 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **14,903.5 μs** |  **75.91 μs** |  **50.21 μs** |  **2.36** |    **0.01** | **635.54 KB** |       **15.76** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 14,908.2 μs |  64.82 μs |  33.90 μs |  2.36 |    0.01 | 165.78 KB |        4.11 |
| NativeSingle      | TaLib(...)dMode [27] | 10000 |  6,325.8 μs |  14.50 μs |   9.59 μs |  1.00 |    0.00 |  40.33 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 10000 |  8,669.3 μs | 493.89 μs | 326.68 μs |  1.37 |    0.05 | 141.13 KB |        3.50 |
