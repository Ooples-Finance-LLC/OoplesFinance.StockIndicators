```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId          | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetMama** |  **1,130.8 μs** |  **34.95 μs** |  **23.12 μs** |  **1.00** |    **0.03** |  **163.98 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetMama |    144.5 μs |   0.74 μs |   0.39 μs |  0.13 |    0.00 |  249.94 KB |        1.52 |
|            |       |                 |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetMama** | **10,958.6 μs** | **248.79 μs** | **148.05 μs** |  **1.00** |    **0.02** | **1595.96 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetMama |  1,472.0 μs |  27.90 μs |  16.60 μs |  0.13 |    0.00 | 2412.05 KB |        1.51 |
