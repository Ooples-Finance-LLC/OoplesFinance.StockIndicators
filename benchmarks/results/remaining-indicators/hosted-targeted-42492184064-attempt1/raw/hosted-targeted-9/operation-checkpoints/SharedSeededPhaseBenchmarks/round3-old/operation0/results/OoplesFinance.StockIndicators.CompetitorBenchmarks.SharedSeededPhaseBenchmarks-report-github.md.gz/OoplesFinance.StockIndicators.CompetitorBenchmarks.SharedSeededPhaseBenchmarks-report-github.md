```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetMama** | **1000**  |   **635.6 μs** |  **9.17 μs** |  **5.46 μs** |       **-** |  **82.61 KB** |
| BuilderLatestOnly | Skender.GetMama | 1000  |   629.8 μs |  1.74 μs |  0.91 μs |       - |  35.02 KB |
| **BuilderFull**       | **Skender.GetMama** | **10000** | **6,192.7 μs** | **21.99 μs** | **13.09 μs** | **31.2500** | **786.32 KB** |
| BuilderLatestOnly | Skender.GetMama | 10000 | 6,193.1 μs | 37.07 μs | 19.39 μs |       - | 316.48 KB |
