```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev   | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |-----------:|----------:|---------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetMama** | **1000**  |   **632.6 μs** |   **5.47 μs** |  **3.25 μs** |  **4.99** |    **0.04** |        **-** |        **-** |        **-** |   **82.58 KB** |        **0.43** |
| BuilderLatestOnly | Skender.GetMama | 1000  |   636.5 μs |   7.00 μs |  4.16 μs |  5.02 |    0.04 |        - |        - |        - |      35 KB |        0.18 |
| NativeSingle      | Skender.GetMama | 1000  |   126.8 μs |   1.06 μs |  0.70 μs |  1.00 |    0.01 |  11.7188 |   1.9531 |        - |  192.06 KB |        1.00 |
| NativeParallel    | Skender.GetMama | 1000  |   237.8 μs |  12.31 μs |  7.33 μs |  1.88 |    0.06 |  31.2500 |   9.7656 |        - |  489.38 KB |        2.55 |
|                   |                 |       |            |           |          |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetMama** | **10000** | **6,220.5 μs** |  **45.79 μs** | **27.25 μs** |  **4.28** |    **0.07** |        **-** |        **-** |        **-** |  **786.55 KB** |        **0.41** |
| BuilderLatestOnly | Skender.GetMama | 10000 | 6,168.8 μs |  38.82 μs | 25.68 μs |  4.25 |    0.07 |        - |        - |        - |  316.51 KB |        0.17 |
| NativeSingle      | Skender.GetMama | 10000 | 1,452.9 μs |  42.24 μs | 25.13 μs |  1.00 |    0.02 | 179.6875 | 140.6250 |  85.9375 | 1915.73 KB |        1.00 |
| NativeParallel    | Skender.GetMama | 10000 | 2,472.1 μs | 122.71 μs | 73.02 μs |  1.70 |    0.05 | 406.2500 | 328.1250 | 140.6250 | 4869.34 KB |        2.54 |
