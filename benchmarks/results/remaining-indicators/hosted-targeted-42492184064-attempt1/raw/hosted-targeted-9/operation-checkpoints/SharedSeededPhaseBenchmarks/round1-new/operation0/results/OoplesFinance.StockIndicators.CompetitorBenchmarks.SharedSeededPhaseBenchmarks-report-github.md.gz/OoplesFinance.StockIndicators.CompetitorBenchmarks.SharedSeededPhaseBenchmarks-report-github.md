```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetMama** | **1000**  |   **628.5 μs** |  **7.19 μs** |  **4.28 μs** |       **-** |  **82.57 KB** |
| BuilderLatestOnly | Skender.GetMama | 1000  |   623.1 μs |  7.70 μs |  5.09 μs |       - |  35.02 KB |
| **BuilderFull**       | **Skender.GetMama** | **10000** | **6,212.4 μs** | **34.34 μs** | **20.44 μs** | **31.2500** |  **786.3 KB** |
| BuilderLatestOnly | Skender.GetMama | 10000 | 6,147.1 μs | 26.43 μs | 15.73 μs |       - |  316.5 KB |
