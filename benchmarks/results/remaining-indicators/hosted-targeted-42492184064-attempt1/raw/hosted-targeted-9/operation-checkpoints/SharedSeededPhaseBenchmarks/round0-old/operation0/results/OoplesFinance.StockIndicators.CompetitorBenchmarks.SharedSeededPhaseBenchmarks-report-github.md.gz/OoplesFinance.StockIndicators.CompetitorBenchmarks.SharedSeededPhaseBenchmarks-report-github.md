```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetMama** | **1000**  |   **626.0 μs** |  **2.44 μs** |  **1.45 μs** |       **-** |  **82.61 KB** |
| BuilderLatestOnly | Skender.GetMama | 1000  |   627.1 μs | 19.47 μs | 12.88 μs |       - |  35.01 KB |
| **BuilderFull**       | **Skender.GetMama** | **10000** | **6,161.0 μs** | **28.76 μs** | **17.11 μs** | **31.2500** | **786.34 KB** |
| BuilderLatestOnly | Skender.GetMama | 10000 | 6,099.3 μs | 16.49 μs |  8.62 μs |       - | 316.49 KB |
