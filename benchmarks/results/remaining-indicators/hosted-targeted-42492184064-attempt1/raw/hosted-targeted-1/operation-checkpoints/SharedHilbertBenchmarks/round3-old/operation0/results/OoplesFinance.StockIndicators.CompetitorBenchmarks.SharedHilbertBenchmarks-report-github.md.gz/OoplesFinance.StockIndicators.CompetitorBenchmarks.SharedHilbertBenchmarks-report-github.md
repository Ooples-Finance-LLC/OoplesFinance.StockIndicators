```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)hasor [24]** | **1000**  |   **512.0 μs** |  **5.43 μs** |  **3.23 μs** |  **82.38 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 1000  |   507.1 μs |  3.04 μs |  1.59 μs |  34.83 KB |
| **BuilderFull**       | **TaLib(...)hasor [24]** | **10000** | **5,091.5 μs** | **84.38 μs** | **55.81 μs** | **786.08 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 10000 | 4,996.5 μs | 29.00 μs | 15.17 μs | 316.31 KB |
