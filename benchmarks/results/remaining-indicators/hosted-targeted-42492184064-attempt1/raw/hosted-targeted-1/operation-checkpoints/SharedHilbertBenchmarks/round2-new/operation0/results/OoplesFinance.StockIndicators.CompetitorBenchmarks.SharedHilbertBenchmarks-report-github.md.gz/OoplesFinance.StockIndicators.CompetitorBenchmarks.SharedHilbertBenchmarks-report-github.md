```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)hasor [24]** | **1000**  |   **502.16 μs** |   **3.222 μs** |  **1.917 μs** |  **5.21** |    **0.03** |        **-** |        **-** |        **-** |  **82.41 KB** |        **5.30** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 1000  |   496.70 μs |   5.039 μs |  2.999 μs |  5.16 |    0.04 |        - |        - |        - |  34.83 KB |        2.24 |
| NativeSingle      | TaLib(...)hasor [24] | 1000  |    96.30 μs |   0.728 μs |  0.433 μs |  1.00 |    0.01 |        - |        - |        - |  15.55 KB |        1.00 |
| NativeParallel    | TaLib(...)hasor [24] | 1000  |   152.89 μs |  22.372 μs | 14.797 μs |  1.59 |    0.15 |        - |        - |        - |  54.83 KB |        3.52 |
|                   |                      |       |             |            |           |       |         |          |          |          |           |             |
| **BuilderFull**       | **TaLib(...)hasor [24]** | **10000** | **5,015.83 μs** | **109.136 μs** | **64.945 μs** |  **4.75** |    **0.06** |        **-** |        **-** |        **-** |  **786.1 KB** |        **5.02** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 10000 | 4,912.79 μs |  60.539 μs | 31.663 μs |  4.65 |    0.04 |        - |        - |        - |  316.3 KB |        2.02 |
| NativeSingle      | TaLib(...)hasor [24] | 10000 | 1,056.83 μs |   8.696 μs |  5.175 μs |  1.00 |    0.01 |  46.8750 |  46.8750 |  46.8750 |  156.6 KB |        1.00 |
| NativeParallel    | TaLib(...)hasor [24] | 10000 | 1,399.95 μs |  31.248 μs | 20.669 μs |  1.32 |    0.02 | 132.8125 | 132.8125 | 132.8125 | 548.11 KB |        3.50 |
