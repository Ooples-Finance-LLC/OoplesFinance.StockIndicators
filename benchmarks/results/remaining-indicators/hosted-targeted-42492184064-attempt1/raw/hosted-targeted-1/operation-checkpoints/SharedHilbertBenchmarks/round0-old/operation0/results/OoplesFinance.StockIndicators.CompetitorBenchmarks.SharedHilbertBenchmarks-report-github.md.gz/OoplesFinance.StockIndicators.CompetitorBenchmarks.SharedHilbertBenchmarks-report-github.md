```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)hasor [24]** | **1000**  |   **527.2 μs** |   **6.55 μs** |   **3.43 μs** |  **82.42 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 1000  |   519.9 μs |   6.68 μs |   3.49 μs |  34.83 KB |
| **BuilderFull**       | **TaLib(...)hasor [24]** | **10000** | **5,284.2 μs** | **180.60 μs** | **119.46 μs** | **786.11 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 10000 | 5,128.8 μs |  33.15 μs |  19.73 μs |  316.3 KB |
