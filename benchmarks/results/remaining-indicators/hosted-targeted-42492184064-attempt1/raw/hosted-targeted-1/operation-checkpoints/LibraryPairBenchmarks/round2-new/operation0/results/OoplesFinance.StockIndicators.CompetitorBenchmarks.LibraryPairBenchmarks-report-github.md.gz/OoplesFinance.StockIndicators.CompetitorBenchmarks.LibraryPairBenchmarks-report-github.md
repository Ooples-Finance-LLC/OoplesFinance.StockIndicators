```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)hasor [24]** |   **654.6 μs** | **41.32 μs** | **24.59 μs** |  **1.00** |    **0.05** |  **164.05 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)hasor [24] |   104.1 μs |  3.86 μs |  2.30 μs |  0.16 |    0.01 |   73.49 KB |        0.45 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)hasor [24]** | **6,024.7 μs** | **39.70 μs** | **20.76 μs** |  **1.00** |    **0.00** | **1592.75 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)hasor [24] |   997.8 μs | 21.89 μs | 14.48 μs |  0.17 |    0.00 |  650.62 KB |        0.41 |
