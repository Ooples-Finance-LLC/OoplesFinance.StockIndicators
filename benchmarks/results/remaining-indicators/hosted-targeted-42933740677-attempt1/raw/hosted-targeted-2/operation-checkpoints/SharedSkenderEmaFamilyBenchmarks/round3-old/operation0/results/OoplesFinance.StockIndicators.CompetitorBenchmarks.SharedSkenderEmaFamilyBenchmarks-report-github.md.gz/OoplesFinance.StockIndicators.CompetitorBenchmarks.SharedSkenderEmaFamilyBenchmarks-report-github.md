```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetTsi** | **1000**  |   **675.6 μs** |  **3.72 μs** |  **2.21 μs** |   **81.1 KB** |
| BuilderLatestOnly | Skender.GetTsi | 1000  |   643.2 μs | 11.12 μs |  6.62 μs |  33.47 KB |
| **BuilderFull**       | **Skender.GetTsi** | **10000** | **6,606.6 μs** | **39.73 μs** | **26.28 μs** |    **785 KB** |
| BuilderLatestOnly | Skender.GetTsi | 10000 | 6,594.3 μs | 26.26 μs | 13.73 μs | 315.17 KB |
