```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Gen0   | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetTsi** | **1000**  |   **674.0 μs** |  **12.99 μs** |   **6.79 μs** | **3.9063** |  **81.02 KB** |
| BuilderLatestOnly | Skender.GetTsi | 1000  |   740.1 μs |  83.57 μs |  49.73 μs |      - |  33.47 KB |
| **BuilderFull**       | **Skender.GetTsi** | **10000** | **7,328.3 μs** | **533.73 μs** | **317.61 μs** |      **-** | **785.03 KB** |
| BuilderLatestOnly | Skender.GetTsi | 10000 | 7,563.9 μs | 495.45 μs | 327.71 μs |      - | 315.22 KB |
