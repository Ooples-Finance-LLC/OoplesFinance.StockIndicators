```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetTsi** | **1000**  | **1,077.99 μs** |   **1.924 μs** |  **1.007 μs** | **27.75** |    **0.58** |        **-** |        **-** |        **-** |    **81.1 KB** |        **0.53** |
| BuilderLatestOnly | Skender.GetTsi | 1000  |   659.70 μs |  15.231 μs |  9.064 μs | 16.98 |    0.42 |        - |        - |        - |   33.44 KB |        0.22 |
| NativeSingle      | Skender.GetTsi | 1000  |    38.86 μs |   1.293 μs |  0.855 μs |  1.00 |    0.03 |   9.2773 |   1.9531 |        - |  152.88 KB |        1.00 |
| NativeParallel    | Skender.GetTsi | 1000  |   140.67 μs |   7.379 μs |  4.881 μs |  3.62 |    0.14 |  25.3906 |   6.8359 |        - |  391.01 KB |        2.56 |
|                   |                |       |             |            |           |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetTsi** | **10000** | **6,644.97 μs** |  **40.504 μs** | **24.103 μs** | **10.49** |    **0.15** |        **-** |        **-** |        **-** |  **784.98 KB** |        **0.51** |
| BuilderLatestOnly | Skender.GetTsi | 10000 | 6,661.17 μs |  45.732 μs | 27.214 μs | 10.52 |    0.15 |        - |        - |        - |  315.17 KB |        0.21 |
| NativeSingle      | Skender.GetTsi | 10000 |   633.30 μs |  15.439 μs |  9.188 μs |  1.00 |    0.02 |  97.6563 |  97.6563 |  97.6563 | 1524.76 KB |        1.00 |
| NativeParallel    | Skender.GetTsi | 10000 | 1,595.14 μs | 127.183 μs | 66.519 μs |  2.52 |    0.10 | 359.3750 | 281.2500 | 156.2500 |    3892 KB |        2.55 |
