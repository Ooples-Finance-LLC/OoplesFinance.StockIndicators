```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetTsi** |   **732.10 μs** | **37.809 μs** | **25.008 μs** |  **1.00** |    **0.05** |  **162.47 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetTsi |    62.73 μs |  2.405 μs |  1.258 μs |  0.09 |    0.00 |  210.73 KB |        1.30 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetTsi** | **7,093.73 μs** | **29.113 μs** | **19.257 μs** |  **1.00** |    **0.00** | **1594.13 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetTsi |   638.81 μs | 37.264 μs | 22.175 μs |  0.09 |    0.00 | 2021.32 KB |        1.27 |
