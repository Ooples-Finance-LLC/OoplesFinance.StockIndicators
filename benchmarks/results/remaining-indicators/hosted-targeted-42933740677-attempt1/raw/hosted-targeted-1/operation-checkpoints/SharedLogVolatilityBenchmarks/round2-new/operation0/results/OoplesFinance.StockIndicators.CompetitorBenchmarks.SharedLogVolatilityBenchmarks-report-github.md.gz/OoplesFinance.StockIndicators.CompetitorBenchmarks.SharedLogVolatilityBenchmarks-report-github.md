```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated  | Alloc Ratio |
|------------------ |------------------- |------ |------------:|-----------:|----------:|------:|--------:|--------:|-------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Realized** | **1000**  |   **496.25 μs** |  **13.736 μs** |  **8.174 μs** |  **8.01** |    **0.14** |  **3.9063** |      **-** |   **65.87 KB** |        **1.39** |
| BuilderLatestOnly | QuanTAlib.Realized | 1000  |   487.28 μs |   1.846 μs |  0.966 μs |  7.87 |    0.06 |       - |      - |   18.29 KB |        0.39 |
| NativeSingle      | QuanTAlib.Realized | 1000  |    61.93 μs |   0.856 μs |  0.509 μs |  1.00 |    0.01 |  2.4414 |      - |   47.47 KB |        1.00 |
| NativeParallel    | QuanTAlib.Realized | 1000  |   141.28 μs |   9.749 μs |  5.802 μs |  2.28 |    0.09 |  5.8594 |      - |  107.95 KB |        2.27 |
|                   |                    |       |             |            |           |       |         |         |        |            |             |
| **BuilderFull**       | **QuanTAlib.Realized** | **10000** | **4,953.76 μs** | **106.426 μs** | **70.394 μs** |  **7.92** |    **0.16** | **31.2500** |      **-** |  **628.95 KB** |        **1.34** |
| BuilderLatestOnly | QuanTAlib.Realized | 10000 | 4,869.34 μs |  16.596 μs |  8.680 μs |  7.79 |    0.12 |       - |      - |   158.9 KB |        0.34 |
| NativeSingle      | QuanTAlib.Realized | 10000 |   625.57 μs |  14.908 μs |  9.861 μs |  1.00 |    0.02 | 27.3438 | 3.9063 |  469.37 KB |        1.00 |
| NativeParallel    | QuanTAlib.Realized | 10000 |   973.26 μs |  12.210 μs |  6.386 μs |  1.56 |    0.03 | 62.5000 | 7.8125 | 1057.23 KB |        2.25 |
