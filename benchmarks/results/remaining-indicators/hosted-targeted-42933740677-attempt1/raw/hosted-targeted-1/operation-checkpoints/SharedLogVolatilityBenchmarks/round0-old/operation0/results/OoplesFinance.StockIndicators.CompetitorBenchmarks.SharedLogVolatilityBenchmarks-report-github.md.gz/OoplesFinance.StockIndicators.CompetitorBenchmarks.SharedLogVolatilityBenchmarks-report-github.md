```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **QuanTAlib.Realized** | **1000**  |  **1.754 ms** | **0.0482 ms** | **0.0287 ms** |  **66.01 KB** |
| BuilderLatestOnly | QuanTAlib.Realized | 1000  |  1.160 ms | 0.0260 ms | 0.0172 ms |  18.31 KB |
| **BuilderFull**       | **QuanTAlib.Realized** | **10000** | **11.501 ms** | **0.0767 ms** | **0.0401 ms** | **629.45 KB** |
| BuilderLatestOnly | QuanTAlib.Realized | 10000 | 11.321 ms | 0.0618 ms | 0.0368 ms |  159.5 KB |
