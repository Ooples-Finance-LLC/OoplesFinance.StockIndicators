```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **QuanTAlib.Realized** | **1000**  |  **1.903 ms** | **0.0184 ms** | **0.0096 ms** |  **66.01 KB** |
| BuilderLatestOnly | QuanTAlib.Realized | 1000  |  1.133 ms | 0.0052 ms | 0.0027 ms |  18.31 KB |
| **BuilderFull**       | **QuanTAlib.Realized** | **10000** | **11.314 ms** | **0.0932 ms** | **0.0488 ms** | **629.49 KB** |
| BuilderLatestOnly | QuanTAlib.Realized | 10000 | 11.308 ms | 0.0441 ms | 0.0230 ms | 159.46 KB |
