```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Realized** |   **489.5 μs** | **28.30 μs** | **16.84 μs** |  **1.00** |    **0.05** |  **106.81 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Realized |   110.0 μs |  0.68 μs |  0.35 μs |  0.22 |    0.01 |   69.48 KB |        0.65 |
|            |       |                    |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Realized** | **4,672.5 μs** | **31.76 μs** | **21.01 μs** |  **1.00** |    **0.01** | **1035.24 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Realized | 1,081.6 μs | 18.77 μs | 11.17 μs |  0.23 |    0.00 |  643.02 KB |        0.62 |
