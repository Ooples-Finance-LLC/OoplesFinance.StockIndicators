```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **QuanTAlib.Historical** | **1000**  |   **788.8 μs** | **46.96 μs** | **27.94 μs** |  **65.99 KB** |
| BuilderLatestOnly | QuanTAlib.Historical | 1000  |   772.3 μs | 12.04 μs |  7.96 μs |  18.28 KB |
| **BuilderFull**       | **QuanTAlib.Historical** | **10000** | **7,695.4 μs** | **89.20 μs** | **53.08 μs** | **629.17 KB** |
| BuilderLatestOnly | QuanTAlib.Historical | 10000 | 7,682.4 μs | 29.72 μs | 17.69 μs | 159.41 KB |
