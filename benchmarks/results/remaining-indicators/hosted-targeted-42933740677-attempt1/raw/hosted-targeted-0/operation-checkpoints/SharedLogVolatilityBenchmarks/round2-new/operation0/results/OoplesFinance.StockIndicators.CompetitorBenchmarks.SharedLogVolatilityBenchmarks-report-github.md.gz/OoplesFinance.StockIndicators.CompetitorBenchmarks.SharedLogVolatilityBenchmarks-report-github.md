```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Historical** | **1000**  |   **496.5 μs** |   **7.85 μs** |   **4.11 μs** |  **1.65** |    **0.11** |   **3.9063** |       **-** |   **65.87 KB** |        **0.16** |
| BuilderLatestOnly | QuanTAlib.Historical | 1000  |   490.6 μs |   4.30 μs |   2.56 μs |  1.63 |    0.11 |        - |       - |   18.28 KB |        0.04 |
| NativeSingle      | QuanTAlib.Historical | 1000  |   301.4 μs |  31.27 μs |  20.68 μs |  1.00 |    0.09 |  23.4375 |       - |  414.07 KB |        1.00 |
| NativeParallel    | QuanTAlib.Historical | 1000  |   257.3 μs |  14.17 μs |   8.43 μs |  0.86 |    0.06 |  25.3906 |       - |  418.64 KB |        1.01 |
|                   |                      |       |            |           |           |       |         |          |         |            |             |
| **BuilderFull**       | **QuanTAlib.Historical** | **10000** | **4,959.9 μs** | **187.00 μs** | **123.69 μs** |  **1.86** |    **0.05** |  **31.2500** |       **-** |  **628.85 KB** |        **0.15** |
| BuilderLatestOnly | QuanTAlib.Historical | 10000 | 4,779.5 μs | 127.93 μs |  84.62 μs |  1.79 |    0.03 |        - |       - |  159.02 KB |        0.04 |
| NativeSingle      | QuanTAlib.Historical | 10000 | 2,672.6 μs |  36.90 μs |  21.96 μs |  1.00 |    0.01 | 250.0000 | 46.8750 | 4200.43 KB |        1.00 |
| NativeParallel    | QuanTAlib.Historical | 10000 | 1,777.7 μs | 205.17 μs | 135.71 μs |  0.67 |    0.05 | 250.0000 | 46.8750 | 4205.43 KB |        1.00 |
