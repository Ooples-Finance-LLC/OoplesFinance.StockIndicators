```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **QuanTAlib.Historical** | **1000**  |   **781.3 μs** |  **16.04 μs** | **10.61 μs** |  **65.87 KB** |
| BuilderLatestOnly | QuanTAlib.Historical | 1000  |   780.7 μs |  16.46 μs |  9.79 μs |  18.28 KB |
| **BuilderFull**       | **QuanTAlib.Historical** | **10000** | **7,723.5 μs** | **115.62 μs** | **60.47 μs** | **629.15 KB** |
| BuilderLatestOnly | QuanTAlib.Historical | 10000 | 7,692.1 μs |  85.61 μs | 44.77 μs | 159.29 KB |
