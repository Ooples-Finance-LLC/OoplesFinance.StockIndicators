```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Historical** | **1000**  |   **497.3 μs** |  **5.26 μs** |  **2.75 μs** |  **3.9063** |  **65.87 KB** |
| BuilderLatestOnly | QuanTAlib.Historical | 1000  |   496.7 μs |  6.35 μs |  4.20 μs |       - |  18.29 KB |
| **BuilderFull**       | **QuanTAlib.Historical** | **10000** | **5,064.9 μs** | **92.99 μs** | **61.51 μs** | **31.2500** | **628.89 KB** |
| BuilderLatestOnly | QuanTAlib.Historical | 10000 | 5,126.2 μs | 95.90 μs | 63.44 μs |       - | 159.05 KB |
