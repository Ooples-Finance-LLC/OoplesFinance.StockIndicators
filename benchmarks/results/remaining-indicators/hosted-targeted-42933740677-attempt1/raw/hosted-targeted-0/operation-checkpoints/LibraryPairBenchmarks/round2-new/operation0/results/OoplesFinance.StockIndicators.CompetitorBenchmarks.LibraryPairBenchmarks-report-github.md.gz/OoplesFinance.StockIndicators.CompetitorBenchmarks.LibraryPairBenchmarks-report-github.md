```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Historical** |   **531.1 μs** |  **16.70 μs** |   **9.94 μs** |  **1.00** |    **0.02** |  **106.81 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Historical |   349.1 μs |   3.65 μs |   1.91 μs |  0.66 |    0.01 |  434.38 KB |        4.07 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Historical** | **5,112.8 μs** |  **16.41 μs** |  **10.86 μs** |  **1.00** |    **0.00** | **1032.62 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Historical | 3,595.1 μs | 205.49 μs | 107.47 μs |  0.70 |    0.02 | 4370.45 KB |        4.23 |
