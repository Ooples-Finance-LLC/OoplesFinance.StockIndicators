"""Reuse qualification only when all executable/build inputs match exactly."""
from pathlib import Path
import gzip, hashlib, importlib.util, json, subprocess
from compact_macd_acceptance import qualifies

root = Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
repo = Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
candidate = repo.parent / 'si-compact-macd-unit-round-20261028'
kind = 'compact-macd-unit-round'
state = json.loads((root / kind / 'status.json').read_text())
summary = json.loads((root / ('local-' + kind + '-control-20261028') / 'verified-summary.json').read_text())
assert state['status'] == 'checks-passed-review-and-publication-pending'
assert state['unit']['passed'] == 239 and state['parity']['passed'] == 119
assert state['gpu_passed'] == 100 and state['checks']['inventory-tests'] == 'passed'
assert summary['all_384_cases_verified'] and qualifies(summary['decisions'])
paths = ['src', 'tests', 'benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks',
         'benchmarks/OoplesFinance.StockIndicators.CompetitorTests', 'Directory.Build.props',
         'Directory.Build.targets', 'Directory.Packages.props', 'global.json', 'NuGet.Config',
         'nuget.config', 'scripts/run-competitor-contracts.py',
         'scripts/verify-competitor-local-gpu.py', 'scripts/competitor-gpu-methods.json']
def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo, text=True).strip()
head = git('rev-parse', 'HEAD')
assert not git('status', '--porcelain', '--', *paths)
for source in [state['input_head'], summary['sources']['new']]:
    assert not git('diff', '--name-only', source, head, '--', *paths)
for path, digest in state['production_dll_sha256'].items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest
spec = importlib.util.spec_from_file_location('gpu', repo / 'scripts/verify-competitor-local-gpu.py')
gpu = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gpu)
receipt = json.loads((gpu.EVIDENCE / 'receipt.json').read_text())
raw = gzip.decompress((gpu.EVIDENCE / 'gpu.trx.gz').read_bytes())
assert receipt == json.loads((candidate / 'benchmarks/results/shared-rollout/local-gpu-contracts/receipt.json').read_text())
gpu.verify_evidence(receipt, raw, json.loads(gpu.METHODS.read_text()), gpu.source_fingerprint(repo))
proof = dict(combined_code_source=head, individual_qualified_source=summary['sources']['new'],
             qualification_code_source=state['input_head'],
             source_fingerprint_sha256=receipt['source_sha256'],
             fresh_combined_tree_checks=dict(unit=239, parity=119, gpu=100, inventory=8),
             production_dll_sha256=state['production_dll_sha256'], matched_source_files=paths,
             note='Reused actual candidate qualification: every executable/build input matches the integration tree. Original GPU receipt and binary provenance are preserved; no new run is claimed.')
target = repo / ('benchmarks/results/remaining-indicators/' + kind + '-integration-source-proof-20261028.json')
target.write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8')
print('Verified exact integration source and original qualification:', head)
