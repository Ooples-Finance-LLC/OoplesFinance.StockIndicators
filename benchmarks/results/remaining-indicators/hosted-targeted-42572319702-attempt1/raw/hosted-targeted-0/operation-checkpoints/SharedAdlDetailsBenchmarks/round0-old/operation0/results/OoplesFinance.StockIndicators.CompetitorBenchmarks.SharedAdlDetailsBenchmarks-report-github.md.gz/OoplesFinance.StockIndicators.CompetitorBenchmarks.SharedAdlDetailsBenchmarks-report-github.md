```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |  **31.46 μs** | **0.576 μs** | **0.381 μs** |  **5.3711** |  **0.9766** |  **88.31 KB** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |  28.82 μs | 0.273 μs | 0.143 μs |  2.4414 |  0.2441 |   40.7 KB |
| **BuilderFull**       | **Skender.GetAdl** | **10000** | **296.30 μs** | **3.761 μs** | **1.967 μs** | **50.7813** | **17.5781** | **862.11 KB** |
| BuilderLatestOnly | Skender.GetAdl | 10000 | 276.42 μs | 2.157 μs | 1.283 μs | 23.4375 |  9.7656 | 392.28 KB |
