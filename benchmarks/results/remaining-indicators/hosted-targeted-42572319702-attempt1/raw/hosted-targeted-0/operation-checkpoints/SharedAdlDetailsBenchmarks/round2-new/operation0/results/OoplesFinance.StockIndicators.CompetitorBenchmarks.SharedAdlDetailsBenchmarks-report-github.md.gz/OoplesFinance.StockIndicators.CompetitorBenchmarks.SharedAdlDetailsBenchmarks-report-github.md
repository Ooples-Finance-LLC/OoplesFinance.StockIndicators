```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |    **31.60 μs** |  **0.616 μs** |  **0.366 μs** |  **0.57** |    **0.01** |   **4.8828** |   **0.9766** |   **88.31 KB** |        **0.50** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |    36.69 μs |  0.210 μs |  0.125 μs |  0.67 |    0.01 |   2.4414 |   0.2441 |    40.7 KB |        0.23 |
| NativeSingle      | Skender.GetAdl | 1000  |    54.99 μs |  0.944 μs |  0.562 μs |  1.00 |    0.01 |  10.7422 |   2.4414 |  176.21 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 1000  |   148.17 μs | 10.318 μs |  6.140 μs |  2.69 |    0.11 |  28.3203 |   8.7891 |   449.4 KB |        2.55 |
|                   |                |       |             |           |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetAdl** | **10000** |   **297.91 μs** |  **2.325 μs** |  **1.216 μs** |  **0.48** |    **0.00** |  **50.7813** |  **17.5781** |  **862.12 KB** |        **0.49** |
| BuilderLatestOnly | Skender.GetAdl | 10000 |   277.12 μs |  2.176 μs |  1.295 μs |  0.45 |    0.00 |  23.4375 |   9.7656 |  392.28 KB |        0.22 |
| NativeSingle      | Skender.GetAdl | 10000 |   617.27 μs |  7.723 μs |  4.039 μs |  1.00 |    0.01 | 105.4688 |  66.4063 | 1758.26 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 10000 | 1,354.27 μs | 57.818 μs | 38.243 μs |  2.19 |    0.06 | 273.4375 | 187.5000 | 4474.84 KB |        2.55 |
