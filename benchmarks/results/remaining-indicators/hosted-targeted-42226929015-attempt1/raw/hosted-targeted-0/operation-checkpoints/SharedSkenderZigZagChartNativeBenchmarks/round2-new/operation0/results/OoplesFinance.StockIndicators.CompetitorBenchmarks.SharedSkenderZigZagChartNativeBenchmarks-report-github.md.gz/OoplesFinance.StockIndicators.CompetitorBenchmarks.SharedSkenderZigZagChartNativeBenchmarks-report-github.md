```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method       | Count | Operation         | Mean       | Error    | StdDev   | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------- |------ |------------------ |-----------:|---------:|---------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **Snapshot**     | **1000**  | **Skender.GetZigZag** |   **116.7 μs** | **18.20 μs** | **12.04 μs** |  **0.61** |    **0.06** |        **-** |        **-** |        **-** |  **149.64 KB** |        **0.61** |
| NativeSingle | 1000  | Skender.GetZigZag |   191.5 μs |  3.80 μs |  1.99 μs |  1.00 |    0.01 |   1.9531 |        - |        - |  244.25 KB |        1.00 |
|              |       |                   |            |          |          |       |         |          |          |          |            |             |
| **Snapshot**     | **10000** | **Skender.GetZigZag** | **1,710.7 μs** | **73.39 μs** | **43.67 μs** |  **0.75** |    **0.02** | **187.5000** | **187.5000** | **187.5000** | **1495.14 KB** |        **0.64** |
| NativeSingle | 10000 | Skender.GetZigZag | 2,292.0 μs | 54.61 μs | 32.50 μs |  1.00 |    0.02 |  15.6250 |        - |        - | 2323.25 KB |        1.00 |
