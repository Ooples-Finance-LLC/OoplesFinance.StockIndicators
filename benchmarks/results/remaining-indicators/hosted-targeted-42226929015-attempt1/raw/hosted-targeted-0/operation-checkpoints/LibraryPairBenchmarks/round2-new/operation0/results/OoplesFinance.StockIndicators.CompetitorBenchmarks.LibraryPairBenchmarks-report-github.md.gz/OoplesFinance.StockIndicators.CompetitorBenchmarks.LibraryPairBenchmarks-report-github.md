```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId            | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------ |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetZigZag** |   **137.2 μs** |  **12.83 μs** |  **6.71 μs** |  **1.00** |    **0.07** |  **256.95 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetZigZag |   281.8 μs |  38.31 μs | 22.80 μs |  2.06 |    0.18 |  428.49 KB |        1.67 |
|            |       |                   |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetZigZag** | **1,728.5 μs** |  **57.57 μs** | **38.08 μs** |  **1.00** |    **0.03** | **2554.71 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetZigZag | 2,475.9 μs | 111.00 μs | 66.06 μs |  1.43 |    0.05 | 4089.05 KB |        1.60 |
