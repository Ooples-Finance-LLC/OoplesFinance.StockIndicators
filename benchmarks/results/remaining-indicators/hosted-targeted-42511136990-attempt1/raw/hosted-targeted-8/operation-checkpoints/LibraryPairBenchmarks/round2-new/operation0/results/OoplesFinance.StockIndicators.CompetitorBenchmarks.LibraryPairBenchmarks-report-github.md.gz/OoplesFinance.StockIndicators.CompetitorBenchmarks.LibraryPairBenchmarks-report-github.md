```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tSine [22]** |   **706.1 μs** | **18.73 μs** | **11.15 μs** |  **1.00** |    **0.02** |  **166.46 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tSine [22] |   447.0 μs | 10.14 μs |  6.03 μs |  0.63 |    0.01 |   72.64 KB |        0.44 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)tSine [22]** | **7,007.1 μs** | **32.03 μs** | **21.19 μs** |  **1.00** |    **0.00** | **1595.49 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tSine [22] | 4,638.2 μs | 23.16 μs | 13.78 μs |  0.66 |    0.00 |  649.77 KB |        0.41 |
