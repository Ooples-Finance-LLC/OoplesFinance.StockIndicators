```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **624.7 μs** |   **7.33 μs** |   **3.83 μs** |  **1.61** |    **0.01** |  **84.83 KB** |        **5.39** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   617.6 μs |   7.73 μs |   4.60 μs |  1.60 |    0.01 |  37.24 KB |        2.37 |
| NativeSingle      | TaLib(...)tSine [22] | 1000  |   386.9 μs |   1.91 μs |   1.00 μs |  1.00 |    0.00 |  15.74 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 1000  |   600.5 μs |  13.77 μs |   9.11 μs |  1.55 |    0.02 |  55.96 KB |        3.56 |
|                   |                      |       |            |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **6,724.4 μs** |  **43.28 μs** |  **22.64 μs** |  **1.46** |    **0.02** | **788.84 KB** |        **5.04** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 6,729.5 μs |  26.45 μs |  13.83 μs |  1.46 |    0.02 | 319.01 KB |        2.04 |
| NativeSingle      | TaLib(...)tSine [22] | 10000 | 4,606.2 μs | 106.21 μs |  70.25 μs |  1.00 |    0.02 | 156.54 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 10000 | 6,660.6 μs | 502.03 μs | 332.06 μs |  1.45 |    0.07 | 548.61 KB |        3.50 |
