```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDM [22]** | **122.31 μs** | **10.118 μs** |  **5.292 μs** |  **1.00** |    **0.06** | **105.55 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDM [22] |  18.52 μs |  1.092 μs |  0.722 μs |  0.15 |    0.01 |  39.23 KB |        0.37 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)lusDM [22]** | **950.24 μs** | **48.068 μs** | **31.794 μs** |  **1.00** |    **0.05** | **1032.3 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDM [22] | 155.09 μs | 15.009 μs |  9.927 μs |  0.16 |    0.01 | 328.66 KB |        0.32 |
