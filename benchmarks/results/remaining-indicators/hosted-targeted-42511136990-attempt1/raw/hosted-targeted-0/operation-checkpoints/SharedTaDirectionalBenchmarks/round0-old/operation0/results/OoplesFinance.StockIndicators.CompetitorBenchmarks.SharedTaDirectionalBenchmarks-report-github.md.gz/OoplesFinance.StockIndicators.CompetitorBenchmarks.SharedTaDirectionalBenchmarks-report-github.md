```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error   | StdDev  | Allocated |
|------------------ |--------------------- |------ |-----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **114.5 μs** | **5.87 μs** | **3.49 μs** |  **65.01 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   107.6 μs | 1.83 μs | 1.09 μs |  17.41 KB |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **1,102.8 μs** | **6.03 μs** | **3.16 μs** | **627.88 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 1,031.8 μs | 3.74 μs | 1.96 μs | 158.06 KB |
