```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **117.4 μs** |  **1.98 μs** |  **1.18 μs** |  **65.05 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   105.5 μs |  2.04 μs |  1.35 μs |  17.41 KB |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **1,078.4 μs** | **20.95 μs** | **13.86 μs** |  **627.9 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 1,020.0 μs | 35.33 μs | 23.37 μs | 158.07 KB |
