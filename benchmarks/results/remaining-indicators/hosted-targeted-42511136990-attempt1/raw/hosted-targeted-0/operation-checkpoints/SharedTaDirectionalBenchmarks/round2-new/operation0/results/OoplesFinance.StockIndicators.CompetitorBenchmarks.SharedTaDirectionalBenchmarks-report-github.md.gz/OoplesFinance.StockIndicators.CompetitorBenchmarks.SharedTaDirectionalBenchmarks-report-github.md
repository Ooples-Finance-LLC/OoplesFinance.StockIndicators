```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |  **70.149 μs** | **0.6746 μs** | **0.4015 μs** |  **7.29** |    **0.05** |      **-** |  **64.91 KB** |        **8.41** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |  64.747 μs | 0.8099 μs | 0.4236 μs |  6.73 |    0.05 |      - |   17.3 KB |        2.24 |
| NativeSingle      | TaLib(...)lusDM [22] | 1000  |   9.619 μs | 0.0773 μs | 0.0511 μs |  1.00 |    0.01 | 0.0610 |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 1000  |  90.767 μs | 5.2499 μs | 3.4725 μs |  9.44 |    0.35 |      - |  27.23 KB |        3.53 |
|                   |                      |       |            |           |           |       |         |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **769.099 μs** | **6.4003 μs** | **3.8087 μs** |  **8.19** |    **0.05** |      **-** | **627.79 KB** |        **8.04** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 711.844 μs | 7.6785 μs | 4.5693 μs |  7.58 |    0.05 |      - | 157.95 KB |        2.02 |
| NativeSingle      | TaLib(...)lusDM [22] | 10000 |  93.920 μs | 0.5958 μs | 0.3116 μs |  1.00 |    0.00 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 10000 | 184.053 μs | 6.1561 μs | 3.6634 μs |  1.96 |    0.04 | 2.9297 | 273.33 KB |        3.50 |
