```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |  **70.26 μs** | **0.603 μs** | **0.359 μs** |  **64.88 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |  64.39 μs | 1.668 μs | 0.993 μs |   17.3 KB |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **775.95 μs** | **7.961 μs** | **4.164 μs** | **627.75 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 712.02 μs | 2.820 μs | 1.475 μs | 157.94 KB |
