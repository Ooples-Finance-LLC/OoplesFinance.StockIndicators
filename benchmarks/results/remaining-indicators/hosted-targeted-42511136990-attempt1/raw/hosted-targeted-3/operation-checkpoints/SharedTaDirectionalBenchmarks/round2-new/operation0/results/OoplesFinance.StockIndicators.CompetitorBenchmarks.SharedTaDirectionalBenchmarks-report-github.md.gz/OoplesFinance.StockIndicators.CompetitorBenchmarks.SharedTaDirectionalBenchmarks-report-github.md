```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |    **86.601 μs** |  **1.5515 μs** |  **1.0262 μs** | **18.91** |    **0.23** |  **3.9063** |      **-** |  **64.91 KB** |        **8.41** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |    85.337 μs |  2.1395 μs |  1.4152 μs | 18.63 |    0.30 |  0.9766 |      - |   17.3 KB |        2.24 |
| NativeSingle      | TaLib(...)nusDI [23] | 1000  |     4.580 μs |  0.0318 μs |  0.0189 μs |  1.00 |    0.01 |  0.4578 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 1000  |    66.311 μs |  0.8755 μs |  0.4579 μs | 14.48 |    0.11 |  1.9531 |      - |  27.25 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **1,052.392 μs** | **38.4351 μs** | **25.4224 μs** | **22.38** |    **0.71** | **31.2500** | **7.8125** | **627.79 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 1,032.831 μs | 21.1258 μs | 12.5716 μs | 21.96 |    0.54 |  7.8125 |      - | 157.98 KB |        2.02 |
| NativeSingle      | TaLib(...)nusDI [23] | 10000 |    47.049 μs |  1.6221 μs |  1.0729 μs |  1.00 |    0.03 |  4.6387 |      - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 10000 |   117.260 μs |  3.1460 μs |  2.0809 μs |  2.49 |    0.07 | 17.5781 | 3.9063 | 273.34 KB |        3.50 |
