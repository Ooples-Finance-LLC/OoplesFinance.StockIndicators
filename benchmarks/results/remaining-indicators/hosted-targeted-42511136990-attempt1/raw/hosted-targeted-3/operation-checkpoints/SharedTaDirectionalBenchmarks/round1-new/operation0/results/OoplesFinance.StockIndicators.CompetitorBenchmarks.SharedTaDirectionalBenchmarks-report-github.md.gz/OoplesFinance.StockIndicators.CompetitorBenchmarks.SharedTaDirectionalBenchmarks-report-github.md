```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |------------:|----------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |    **88.91 μs** |  **0.721 μs** | **0.377 μs** |  **3.9063** |      **-** |  **64.91 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |    87.06 μs |  3.301 μs | 2.183 μs |  0.9766 |      - |   17.3 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **1,081.63 μs** |  **9.259 μs** | **4.843 μs** | **31.2500** | **7.8125** |  **627.8 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 1,075.70 μs | 16.036 μs | 9.543 μs |  7.8125 |      - | 157.94 KB |
