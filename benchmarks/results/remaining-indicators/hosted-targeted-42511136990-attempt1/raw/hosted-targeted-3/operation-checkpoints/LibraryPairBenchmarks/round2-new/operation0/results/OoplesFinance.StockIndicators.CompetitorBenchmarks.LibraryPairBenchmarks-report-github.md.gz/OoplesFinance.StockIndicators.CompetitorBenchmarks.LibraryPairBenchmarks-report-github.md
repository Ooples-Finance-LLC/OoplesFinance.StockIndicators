```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean         | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-------------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDI [23]** |   **176.550 μs** |  **3.1234 μs** |  **1.6336 μs** |  **1.00** |    **0.01** |  **105.63 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDI [23] |     8.175 μs |  0.7281 μs |  0.3808 μs |  0.05 |    0.00 |   39.95 KB |        0.38 |
|            |       |                      |              |            |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDI [23]** | **1,210.744 μs** | **23.7120 μs** | **14.1106 μs** |  **1.00** |    **0.02** | **1030.13 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDI [23] |    75.033 μs |  1.2575 μs |  0.7483 μs |  0.06 |    0.00 |  323.09 KB |        0.31 |
