```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |---------- |------ |-----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **Ema**       | **1000**  |  **27.735 μs** | **0.3273 μs** | **0.1948 μs** |  **9.78** |    **0.10** |  **2.9297** |       **-** |  **56.74 KB** |        **7.35** |
| BuilderLatestOnly | Ema       | 1000  |  23.284 μs | 0.1324 μs | 0.0788 μs |  8.21 |    0.07 |  0.4883 |       - |   8.85 KB |        1.15 |
| NativeSingle      | Ema       | 1000  |   2.837 μs | 0.0368 μs | 0.0244 μs |  1.00 |    0.01 |  0.4578 |       - |   7.72 KB |        1.00 |
| NativeParallel    | Ema       | 1000  |  78.091 μs | 0.4911 μs | 0.3248 μs | 27.53 |    0.25 |  0.4883 |       - |   7.99 KB |        1.03 |
|                   |           |       |            |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **Ema**       | **10000** | **228.652 μs** | **2.0456 μs** | **1.3531 μs** |  **8.89** |    **0.06** | **33.2031** | **13.6719** | **549.28 KB** |        **7.04** |
| BuilderLatestOnly | Ema       | 10000 | 210.812 μs | 1.4978 μs | 0.8913 μs |  8.19 |    0.05 |  3.9063 |       - |  79.18 KB |        1.01 |
| NativeSingle      | Ema       | 10000 |  25.731 μs | 0.2065 μs | 0.1229 μs |  1.00 |    0.01 |  4.6387 |  0.7324 |  78.03 KB |        1.00 |
| NativeParallel    | Ema       | 10000 | 105.166 μs | 2.3796 μs | 1.5739 μs |  4.09 |    0.06 |  3.9063 |       - |   78.3 KB |        1.00 |
