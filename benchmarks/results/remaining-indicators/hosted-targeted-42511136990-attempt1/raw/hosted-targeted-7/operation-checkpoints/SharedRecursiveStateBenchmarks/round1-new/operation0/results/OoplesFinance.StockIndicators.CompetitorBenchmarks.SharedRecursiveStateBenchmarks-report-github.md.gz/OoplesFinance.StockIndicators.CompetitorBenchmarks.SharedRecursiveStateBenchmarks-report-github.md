```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Ema**       | **1000**  |  **26.84 μs** | **0.575 μs** | **0.342 μs** |  **2.9297** |       **-** |  **56.74 KB** |
| BuilderLatestOnly | Ema       | 1000  |  23.44 μs | 0.075 μs | 0.045 μs |  0.4883 |       - |   8.85 KB |
| **BuilderFull**       | **Ema**       | **10000** | **226.72 μs** | **3.457 μs** | **1.808 μs** | **33.2031** | **13.6719** | **549.28 KB** |
| BuilderLatestOnly | Ema       | 10000 | 209.35 μs | 4.195 μs | 2.496 μs |  3.9063 |       - |  79.18 KB |
