```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Ema**       | **1000**  |  **26.67 μs** | **0.455 μs** | **0.238 μs** |  **2.9297** |       **-** |  **56.74 KB** |
| BuilderLatestOnly | Ema       | 1000  |  23.38 μs | 0.081 μs | 0.048 μs |  0.4883 |       - |   8.85 KB |
| **BuilderFull**       | **Ema**       | **10000** | **229.53 μs** | **1.741 μs** | **1.036 μs** | **33.2031** | **13.6719** | **549.28 KB** |
| BuilderLatestOnly | Ema       | 10000 | 209.18 μs | 1.156 μs | 0.604 μs |  3.9063 |       - |  79.18 KB |
