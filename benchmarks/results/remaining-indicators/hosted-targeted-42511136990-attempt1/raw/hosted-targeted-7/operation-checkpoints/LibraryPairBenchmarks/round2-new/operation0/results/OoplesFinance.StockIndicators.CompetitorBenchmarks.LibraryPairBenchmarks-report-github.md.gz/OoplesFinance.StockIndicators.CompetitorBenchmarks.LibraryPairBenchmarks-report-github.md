```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean       | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ema** | **239.956 μs** |  **3.0907 μs** |  **1.8392 μs** |  **1.00** |    **0.01** |  **64.84 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ema |   4.594 μs |  0.6123 μs |  0.3644 μs |  0.02 |    0.00 |  19.91 KB |        0.31 |
|            |       |                     |            |            |            |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ema** | **334.656 μs** | **20.6646 μs** | **12.2972 μs** |  **1.00** |    **0.05** | **630.83 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ema |  32.222 μs |  0.4507 μs |  0.2682 μs |  0.10 |    0.00 | 159.88 KB |        0.25 |
