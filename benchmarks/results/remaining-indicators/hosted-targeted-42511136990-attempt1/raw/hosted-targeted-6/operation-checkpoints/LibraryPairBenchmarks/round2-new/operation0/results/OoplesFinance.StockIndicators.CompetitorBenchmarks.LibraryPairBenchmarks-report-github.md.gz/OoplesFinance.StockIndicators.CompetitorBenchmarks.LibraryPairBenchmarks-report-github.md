```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adxr** |   **472.14 μs** | **20.973 μs** | **12.480 μs** |  **1.00** |    **0.03** |  **106.88 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adxr |    24.99 μs |  1.330 μs |  0.696 μs |  0.05 |    0.00 |   47.47 KB |        0.44 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adxr** | **4,490.80 μs** | **31.233 μs** | **18.586 μs** |  **1.00** |    **0.01** | **1040.16 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adxr |   233.32 μs |  5.922 μs |  3.097 μs |  0.05 |    0.00 |   408.2 KB |        0.39 |
