```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **475.2 μs** |  **11.20 μs** |   **6.66 μs** |       **-** |  **66.31 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   466.3 μs |   6.08 μs |   3.62 μs |       - |  18.72 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **5,071.6 μs** | **325.90 μs** | **215.56 μs** | **31.2500** |    **632 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 4,981.1 μs | 257.82 μs | 170.53 μs |       - | 162.18 KB |
