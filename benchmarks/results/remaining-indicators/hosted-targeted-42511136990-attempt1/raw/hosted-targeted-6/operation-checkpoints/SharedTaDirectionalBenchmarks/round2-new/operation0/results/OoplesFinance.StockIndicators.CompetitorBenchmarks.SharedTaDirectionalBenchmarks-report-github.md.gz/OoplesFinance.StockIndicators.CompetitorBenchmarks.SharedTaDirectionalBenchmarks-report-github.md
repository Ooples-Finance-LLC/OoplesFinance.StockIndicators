```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **431.88 μs** |  **3.601 μs** |  **1.884 μs** | **25.65** |    **0.13** |       **-** |      **-** |  **66.24 KB** |        **4.42** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   391.08 μs |  2.442 μs |  1.453 μs | 23.22 |    0.11 |       - |      - |  18.62 KB |        1.24 |
| NativeSingle      | TaLib.Functions.Adxr | 1000  |    16.84 μs |  0.093 μs |  0.055 μs |  1.00 |    0.00 |  0.8545 |      - |  14.99 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 1000  |   106.55 μs |  2.578 μs |  1.705 μs |  6.33 |    0.10 |  2.9297 |      - |  45.44 KB |        3.03 |
|                   |                      |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **4,165.06 μs** | **23.117 μs** | **13.756 μs** | **24.29** |    **0.22** | **31.2500** |      **-** | **631.91 KB** |        **4.06** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 4,141.02 μs | 40.229 μs | 23.940 μs | 24.15 |    0.24 |       - |      - | 162.07 KB |        1.04 |
| NativeSingle      | TaLib.Functions.Adxr | 10000 |   171.47 μs |  2.280 μs |  1.508 μs |  1.00 |    0.01 |  8.7891 | 0.9766 | 155.63 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 10000 |   315.03 μs | 19.378 μs | 12.817 μs |  1.84 |    0.07 | 29.2969 | 9.7656 | 467.32 KB |        3.00 |
