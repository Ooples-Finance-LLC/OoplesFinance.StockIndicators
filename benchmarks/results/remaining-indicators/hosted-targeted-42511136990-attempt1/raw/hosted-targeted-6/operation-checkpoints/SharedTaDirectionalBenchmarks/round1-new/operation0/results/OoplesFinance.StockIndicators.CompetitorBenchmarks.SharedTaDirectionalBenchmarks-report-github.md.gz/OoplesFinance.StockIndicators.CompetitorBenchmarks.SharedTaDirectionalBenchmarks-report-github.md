```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **408.1 μs** |  **4.98 μs** |  **2.60 μs** |       **-** |  **66.21 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   405.0 μs |  2.31 μs |  1.21 μs |       - |  18.62 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **4,278.6 μs** | **27.13 μs** | **16.15 μs** | **31.2500** | **631.87 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 4,260.1 μs | 35.73 μs | 21.26 μs |       - | 162.03 KB |
