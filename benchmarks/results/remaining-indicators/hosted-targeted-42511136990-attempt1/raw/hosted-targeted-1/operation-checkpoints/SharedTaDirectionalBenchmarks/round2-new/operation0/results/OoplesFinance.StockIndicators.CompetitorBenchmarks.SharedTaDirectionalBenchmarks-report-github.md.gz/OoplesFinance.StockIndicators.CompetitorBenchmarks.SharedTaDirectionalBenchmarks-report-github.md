```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error    | StdDev   | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|---------:|---------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |    **95.41 μs** | **0.999 μs** | **0.594 μs** |  **9.33** |    **0.08** |  **3.9063** |      **-** |  **64.91 KB** |        **8.41** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |    88.00 μs | 0.414 μs | 0.246 μs |  8.60 |    0.06 |  0.9766 |      - |   17.3 KB |        2.24 |
| NativeSingle      | TaLib(...)nusDM [23] | 1000  |    10.23 μs | 0.095 μs | 0.063 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 1000  |    96.68 μs | 1.738 μs | 1.034 μs |  9.45 |    0.11 |  1.9531 |      - |  27.23 KB |        3.53 |
|                   |                      |       |             |          |          |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,035.63 μs** | **6.962 μs** | **4.143 μs** | **10.02** |    **0.05** | **31.2500** | **7.8125** | **627.81 KB** |        **8.04** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 |   970.53 μs | 8.195 μs | 4.877 μs |  9.39 |    0.06 |  7.8125 |      - | 157.98 KB |        2.02 |
| NativeSingle      | TaLib(...)nusDM [23] | 10000 |   103.33 μs | 0.687 μs | 0.409 μs |  1.00 |    0.01 |  3.9063 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 10000 |   207.38 μs | 5.896 μs | 3.900 μs |  2.01 |    0.04 | 17.5781 | 3.9063 | 273.34 KB |        3.50 |
