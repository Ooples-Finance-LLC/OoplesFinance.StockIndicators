```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDM [23]** |   **220.66 μs** |  **6.290 μs** |  **3.290 μs** |  **1.00** |    **0.02** |  **105.63 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDM [23] |    15.43 μs |  1.452 μs |  0.759 μs |  0.07 |    0.00 |   40.55 KB |        0.38 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDM [23]** | **1,241.68 μs** | **25.927 μs** | **15.429 μs** |  **1.00** |    **0.02** | **1036.31 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDM [23] |   154.89 μs | 11.064 μs |  7.318 μs |  0.12 |    0.01 |   330.3 KB |        0.32 |
