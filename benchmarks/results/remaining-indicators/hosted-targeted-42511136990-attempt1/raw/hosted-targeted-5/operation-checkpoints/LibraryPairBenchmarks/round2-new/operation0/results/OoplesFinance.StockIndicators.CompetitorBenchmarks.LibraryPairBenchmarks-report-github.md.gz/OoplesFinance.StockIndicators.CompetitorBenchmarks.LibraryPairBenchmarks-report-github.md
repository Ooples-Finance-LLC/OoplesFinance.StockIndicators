```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean        | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |------------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adx** |   **416.64 μs** |  **2.979 μs** |  **1.558 μs** |  **1.00** |   **105.8 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adx |    22.96 μs |  1.539 μs |  1.018 μs |  0.06 |   40.23 KB |        0.38 |
|            |       |                     |             |           |           |       |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adx** | **3,995.14 μs** | **24.564 μs** | **14.618 μs** |  **1.00** | **1039.41 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adx |   221.48 μs | 14.330 μs |  9.479 μs |  0.06 |  330.64 KB |        0.32 |
