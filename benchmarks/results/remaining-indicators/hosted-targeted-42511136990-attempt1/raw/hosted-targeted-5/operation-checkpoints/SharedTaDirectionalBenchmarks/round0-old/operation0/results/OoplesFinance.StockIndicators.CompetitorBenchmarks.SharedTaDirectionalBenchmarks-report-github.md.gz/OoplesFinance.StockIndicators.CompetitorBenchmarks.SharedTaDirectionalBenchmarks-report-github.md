```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **409.4 μs** |  **3.09 μs** |  **1.61 μs** |       **-** |  **65.24 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   403.9 μs |  3.25 μs |  1.93 μs |       - |  17.65 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **4,297.5 μs** | **36.66 μs** | **21.81 μs** | **31.2500** | **630.93 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 4,222.6 μs | 14.09 μs |  7.37 μs |       - | 161.11 KB |
