```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **411.8 μs** |  **3.84 μs** |  **2.01 μs** |       **-** |  **65.24 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   405.8 μs |  2.34 μs |  1.22 μs |       - |  17.65 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **4,337.9 μs** | **10.77 μs** |  **5.63 μs** | **31.2500** | **630.92 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 4,291.7 μs | 37.11 μs | 22.08 μs |       - | 161.09 KB |
