```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **403.13 μs** | **13.284 μs** |  **7.905 μs** | **26.83** |    **0.50** |       **-** |      **-** |  **65.14 KB** |        **8.60** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   379.50 μs | 49.016 μs | 32.421 μs | 25.25 |    2.06 |       - |      - |  17.53 KB |        2.32 |
| NativeSingle      | TaLib.Functions.Adx | 1000  |    15.03 μs |  0.077 μs |  0.041 μs |  1.00 |    0.00 |  0.3662 |      - |   7.57 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 1000  |   104.51 μs |  3.227 μs |  2.134 μs |  6.95 |    0.14 |  1.9531 |      - |  26.72 KB |        3.53 |
|                   |                     |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **3,824.86 μs** | **41.376 μs** | **24.622 μs** | **25.09** |    **0.27** | **31.2500** |      **-** |  **630.8 KB** |        **8.10** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 3,847.95 μs | 27.997 μs | 14.643 μs | 25.24 |    0.24 |       - |      - | 160.99 KB |        2.07 |
| NativeSingle      | TaLib.Functions.Adx | 10000 |   152.45 μs |  2.438 μs |  1.451 μs |  1.00 |    0.01 |  3.9063 |      - |  77.89 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 10000 |   281.54 μs | 22.966 μs | 15.190 μs |  1.85 |    0.10 | 17.5781 | 3.9063 | 272.82 KB |        3.50 |
