```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **279.63 μs** |  **5.971 μs** |  **3.553 μs** | **21.17** |    **0.27** |       **-** |      **-** |  **64.91 KB** |        **8.41** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   285.62 μs | 11.562 μs |  7.648 μs | 21.62 |    0.56 |       - |      - |  17.31 KB |        2.24 |
| NativeSingle      | TaLib.Functions.Dx | 1000  |    13.21 μs |  0.095 μs |  0.056 μs |  1.00 |    0.01 |  0.3662 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 1000  |    90.76 μs |  1.658 μs |  1.097 μs |  6.87 |    0.08 |  1.9531 |      - |  27.25 KB |        3.53 |
|                   |                    |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **3,462.64 μs** | **38.073 μs** | **25.183 μs** | **26.71** |    **0.19** | **31.2500** |      **-** | **627.94 KB** |        **8.05** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 3,434.56 μs | 34.348 μs | 17.965 μs | 26.49 |    0.14 |       - |      - | 158.09 KB |        2.03 |
| NativeSingle      | TaLib.Functions.Dx | 10000 |   129.63 μs |  0.442 μs |  0.231 μs |  1.00 |    0.00 |  3.9063 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 10000 |   220.53 μs | 12.051 μs |  7.171 μs |  1.70 |    0.05 | 17.5781 | 1.9531 | 273.35 KB |        3.50 |
