```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **321.1 μs** |  **8.21 μs** |  **4.89 μs** |       **-** |  **64.97 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   315.0 μs |  4.36 μs |  2.59 μs |       - |  17.41 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **3,719.2 μs** | **15.11 μs** |  **7.90 μs** | **31.2500** | **628.08 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 3,721.1 μs | 29.44 μs | 15.40 μs |       - | 158.21 KB |
