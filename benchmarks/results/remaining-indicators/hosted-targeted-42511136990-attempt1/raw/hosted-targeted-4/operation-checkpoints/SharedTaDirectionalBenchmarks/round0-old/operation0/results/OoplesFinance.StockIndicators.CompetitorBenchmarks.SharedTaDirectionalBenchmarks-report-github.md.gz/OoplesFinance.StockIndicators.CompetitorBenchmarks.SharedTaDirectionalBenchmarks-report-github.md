```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **313.8 μs** |  **5.92 μs** |  **3.52 μs** |       **-** |  **65.01 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   309.5 μs |  6.34 μs |  3.77 μs |       - |  17.41 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **3,692.4 μs** | **41.08 μs** | **21.48 μs** | **31.2500** | **628.02 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 3,648.7 μs | 13.39 μs |  7.01 μs |       - | 158.21 KB |
