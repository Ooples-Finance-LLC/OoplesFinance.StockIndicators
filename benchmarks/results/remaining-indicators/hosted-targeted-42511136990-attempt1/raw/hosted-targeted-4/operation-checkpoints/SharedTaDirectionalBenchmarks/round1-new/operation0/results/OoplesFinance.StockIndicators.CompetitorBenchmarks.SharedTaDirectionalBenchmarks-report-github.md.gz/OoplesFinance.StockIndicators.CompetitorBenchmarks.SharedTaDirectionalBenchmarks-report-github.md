```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **350.5 μs** | **13.39 μs** |  **7.97 μs** |       **-** |  **64.96 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   277.3 μs |  8.38 μs |  5.55 μs |       - |   17.3 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **3,512.9 μs** | **76.56 μs** | **50.64 μs** | **31.2500** | **627.98 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 3,415.6 μs | 43.46 μs | 25.86 μs |       - | 158.14 KB |
