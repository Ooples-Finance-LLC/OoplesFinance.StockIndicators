```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Dx** |   **392.50 μs** | **12.974 μs** |  **7.720 μs** |  **1.00** |    **0.03** |  **105.59 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Dx |    19.64 μs |  2.553 μs |  1.519 μs |  0.05 |    0.00 |   32.73 KB |        0.31 |
|            |       |                    |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Dx** | **3,649.14 μs** | **30.804 μs** | **18.331 μs** |  **1.00** |    **0.01** | **1036.31 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Dx |   156.49 μs |  0.351 μs |  0.209 μs |  0.04 |    0.00 |  329.94 KB |        0.32 |
