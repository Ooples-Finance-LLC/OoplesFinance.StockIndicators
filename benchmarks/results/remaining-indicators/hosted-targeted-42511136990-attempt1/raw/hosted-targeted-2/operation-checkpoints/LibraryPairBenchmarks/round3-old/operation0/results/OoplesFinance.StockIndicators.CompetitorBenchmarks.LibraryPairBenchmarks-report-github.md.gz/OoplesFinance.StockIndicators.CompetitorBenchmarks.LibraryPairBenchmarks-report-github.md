```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean       | Error    | StdDev  | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |-----------:|---------:|--------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)lusDI [22]** |   **255.0 μs** |  **8.98 μs** | **4.70 μs** |  **1.00** |    **0.02** |  **105.69 KB** |        **1.00** |
|        |       |                      |            |          |         |       |         |            |             |
| **Ooples** | **10000** | **TaLib(...)lusDI [22]** | **2,308.7 μs** | **12.63 μs** | **7.52 μs** |  **1.00** |    **0.00** | **1036.41 KB** |        **1.00** |
