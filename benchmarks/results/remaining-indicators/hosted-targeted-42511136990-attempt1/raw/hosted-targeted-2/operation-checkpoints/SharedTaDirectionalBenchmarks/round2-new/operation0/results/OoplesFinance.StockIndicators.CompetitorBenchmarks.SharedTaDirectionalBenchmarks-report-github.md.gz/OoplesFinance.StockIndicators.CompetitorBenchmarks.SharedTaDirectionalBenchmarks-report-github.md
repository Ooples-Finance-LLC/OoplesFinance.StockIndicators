```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **167.113 μs** |  **1.2916 μs** | **0.7686 μs** | **23.32** |    **0.17** |  **3.9063** |      **-** |  **64.91 KB** |        **8.41** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   162.847 μs |  1.3820 μs | 0.9141 μs | 22.73 |    0.18 |  0.9766 |      - |  17.31 KB |        2.24 |
| NativeSingle      | TaLib(...)lusDI [22] | 1000  |     7.165 μs |  0.0720 μs | 0.0428 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 1000  |    94.015 μs |  1.8147 μs | 1.2003 μs | 13.12 |    0.18 |  0.9766 |      - |  27.25 KB |        3.53 |
|                   |                      |       |              |            |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **1,769.506 μs** | **10.0496 μs** | **5.2561 μs** | **24.82** |    **0.23** | **31.2500** |      **-** | **627.89 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 1,753.007 μs |  9.5563 μs | 5.6868 μs | 24.59 |    0.23 |       - |      - | 158.05 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDI [22] | 10000 |    71.307 μs |  1.1057 μs | 0.6580 μs |  1.00 |    0.01 |  4.3945 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 10000 |   172.102 μs |  3.6479 μs | 2.1708 μs |  2.41 |    0.04 | 17.5781 | 2.9297 | 273.34 KB |        3.50 |
