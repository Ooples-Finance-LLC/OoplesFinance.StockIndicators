```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **213.9 μs** |   **1.13 μs** |  **0.67 μs** |       **-** |  **65.01 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   213.2 μs |   2.01 μs |  1.20 μs |       - |  17.41 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **2,105.2 μs** |  **12.61 μs** |  **6.60 μs** | **31.2500** | **627.98 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,126.9 μs | 128.51 μs | 85.00 μs |       - | 158.15 KB |
