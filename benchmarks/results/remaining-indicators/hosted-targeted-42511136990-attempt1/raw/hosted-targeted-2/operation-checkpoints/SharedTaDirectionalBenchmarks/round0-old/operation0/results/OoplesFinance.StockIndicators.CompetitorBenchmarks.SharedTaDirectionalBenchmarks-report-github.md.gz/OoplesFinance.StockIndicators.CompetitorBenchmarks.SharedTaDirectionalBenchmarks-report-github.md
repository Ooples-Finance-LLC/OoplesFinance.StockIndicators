```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **215.2 μs** |  **6.73 μs** |  **4.00 μs** |       **-** |  **65.01 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   210.6 μs |  1.73 μs |  1.03 μs |       - |  17.41 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **2,098.6 μs** | **20.88 μs** | **12.43 μs** | **31.2500** | **627.98 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,064.0 μs | 11.83 μs |  7.04 μs |       - | 158.15 KB |
