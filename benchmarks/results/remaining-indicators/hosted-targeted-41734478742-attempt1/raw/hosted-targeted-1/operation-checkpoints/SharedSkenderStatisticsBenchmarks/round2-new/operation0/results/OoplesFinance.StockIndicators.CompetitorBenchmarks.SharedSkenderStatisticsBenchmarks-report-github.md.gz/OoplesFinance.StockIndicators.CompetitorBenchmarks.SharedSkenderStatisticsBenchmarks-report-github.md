```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error       | StdDev      | Median     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|------------------ |---------------- |------ |-----------:|------------:|------------:|-----------:|------:|--------:|---------:|---------:|---------:|------------:|------------:|
| **BuilderFull**       | **Skender.GetBeta** | **1000**  | **5,361.7 μs** | **6,935.40 μs** | **4,587.34 μs** | **2,292.6 μs** | **10.36** |    **8.48** |        **-** |        **-** |        **-** |   **171.64 KB** |        **0.07** |
| BuilderLatestOnly | Skender.GetBeta | 1000  |   733.8 μs |    16.12 μs |     8.43 μs |   730.9 μs |  1.42 |    0.07 |        - |        - |        - |    123.8 KB |        0.05 |
| NativeSingle      | Skender.GetBeta | 1000  |   518.6 μs |    42.06 μs |    27.82 μs |   506.7 μs |  1.00 |    0.07 |  27.3438 |   7.8125 |        - |  2532.21 KB |        1.00 |
| NativeParallel    | Skender.GetBeta | 1000  |   359.7 μs |     6.95 μs |     4.60 μs |   359.3 μs |  0.70 |    0.04 |  31.2500 |  13.6719 |        - |  2557.05 KB |        1.01 |
|                   |                 |       |            |             |             |            |       |         |          |          |          |             |             |
| **BuilderFull**       | **Skender.GetBeta** | **10000** | **7,713.8 μs** | **1,054.78 μs** |   **627.68 μs** | **7,412.2 μs** |  **1.19** |    **0.14** |        **-** |        **-** |        **-** |  **1578.77 KB** |        **0.06** |
| BuilderLatestOnly | Skender.GetBeta | 10000 | 7,765.0 μs | 1,332.86 μs |   793.17 μs | 7,428.7 μs |  1.20 |    0.16 |        - |        - |        - |     1109 KB |        0.04 |
| NativeSingle      | Skender.GetBeta | 10000 | 6,522.0 μs |   946.66 μs |   626.15 μs | 6,272.1 μs |  1.01 |    0.13 | 375.0000 | 312.5000 | 125.0000 | 25737.29 KB |        1.00 |
| NativeParallel    | Skender.GetBeta | 10000 | 3,755.5 μs |    99.13 μs |    58.99 μs | 3,769.8 μs |  0.58 |    0.05 | 312.5000 | 281.2500 |        - | 25830.73 KB |        1.00 |
