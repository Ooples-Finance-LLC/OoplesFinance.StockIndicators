```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev    | Allocated  |
|------------------ |---------------- |------ |-----------:|----------:|----------:|-----------:|
| **BuilderFull**       | **Skender.GetBeta** | **1000**  | **1,252.6 μs** | **447.02 μs** | **295.68 μs** |  **171.64 KB** |
| BuilderLatestOnly | Skender.GetBeta | 1000  |   737.8 μs |   8.61 μs |   4.50 μs |  123.81 KB |
| **BuilderFull**       | **Skender.GetBeta** | **10000** | **7,428.5 μs** | **121.90 μs** |  **63.76 μs** | **1578.64 KB** |
| BuilderLatestOnly | Skender.GetBeta | 10000 | 7,637.3 μs | 657.11 μs | 343.68 μs |  1108.8 KB |
