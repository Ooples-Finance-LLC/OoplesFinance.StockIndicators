```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId          | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Allocated   | Alloc Ratio |
|----------- |------ |---------------- |------------:|------------:|------------:|------:|--------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetBeta** |  **1,201.6 μs** |    **28.62 μs** |    **17.03 μs** |  **1.00** |    **0.02** |         **-** |   **450.38 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetBeta |    525.7 μs |    25.44 μs |    15.14 μs |  0.44 |    0.01 |         - |  2722.01 KB |        6.04 |
|            |       |                 |             |             |             |       |         |           |             |             |
| **Ooples**     | **10000** | **Skender.GetBeta** | **12,939.9 μs** | **3,294.71 μs** | **2,179.24 μs** |  **1.02** |    **0.22** |         **-** |  **4387.91 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetBeta |  7,643.3 μs |   286.77 μs |   170.65 μs |  0.60 |    0.09 | 1000.0000 | 27533.81 KB |        6.27 |
