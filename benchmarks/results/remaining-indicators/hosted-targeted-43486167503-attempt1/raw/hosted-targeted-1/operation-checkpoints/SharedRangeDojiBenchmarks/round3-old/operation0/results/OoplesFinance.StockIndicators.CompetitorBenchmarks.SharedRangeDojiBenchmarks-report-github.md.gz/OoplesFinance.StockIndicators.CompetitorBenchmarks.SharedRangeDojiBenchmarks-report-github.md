```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)yDoji [27]** | **1000**  |  **47.33 μs** | **0.257 μs** | **0.153 μs** |  **1.9531** |       **-** |  **57.27 KB** |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 1000  |  45.71 μs | 1.128 μs | 0.671 μs |  0.4883 |       - |   9.39 KB |
| **BuilderFull**       | **TaLib(...)yDoji [27]** | **10000** | **434.30 μs** | **3.042 μs** | **1.810 μs** | **31.2500** | **11.7188** | **549.82 KB** |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 10000 | 412.86 μs | 1.264 μs | 0.661 μs |  3.9063 |       - |  79.72 KB |
