```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)yDoji [27]** | **1000**  |  **51.38 μs** |  **0.362 μs** | **0.215 μs** |  **1.9531** |       **-** |  **57.35 KB** |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 1000  |  42.39 μs |  1.483 μs | 0.981 μs |  0.4883 |       - |   9.46 KB |
| **BuilderFull**       | **TaLib(...)yDoji [27]** | **10000** | **305.63 μs** |  **4.929 μs** | **2.578 μs** | **31.2500** | **11.7188** | **552.32 KB** |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 10000 | 314.59 μs | 13.713 μs | 9.070 μs |  3.9063 |       - |   82.2 KB |
