```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)yDoji [27]** | **1000**  |  **44.65 μs** |  **0.110 μs** |  **0.065 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)yDoji [27] | 1000  |  98.17 μs |  1.036 μs |  0.542 μs |  2.20 |    0.01 |       - |       - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib(...)yDoji [27] | 1000  |  46.11 μs |  1.077 μs |  0.713 μs |  1.03 |    0.02 |  3.4180 |  0.4883 |  57.35 KB |       14.45 |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 1000  |  50.86 μs |  0.377 μs |  0.224 μs |  1.14 |    0.01 |  0.4883 |       - |   9.46 KB |        2.38 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)yDoji [27]** | **10000** | **455.92 μs** |  **4.057 μs** |  **2.122 μs** |  **1.00** |    **0.01** |       **-** |       **-** |  **39.16 KB** |        **1.00** |
| NativeParallel    | TaLib(...)yDoji [27] | 10000 | 318.11 μs | 18.706 μs | 12.373 μs |  0.70 |    0.03 |  5.8594 |       - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib(...)yDoji [27] | 10000 | 322.30 μs | 29.179 μs | 19.300 μs |  0.71 |    0.04 | 33.2031 | 11.7188 |  552.3 KB |       14.11 |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 10000 | 297.02 μs | 14.314 μs |  8.518 μs |  0.65 |    0.02 |  3.9063 |       - |   82.2 KB |        2.10 |
