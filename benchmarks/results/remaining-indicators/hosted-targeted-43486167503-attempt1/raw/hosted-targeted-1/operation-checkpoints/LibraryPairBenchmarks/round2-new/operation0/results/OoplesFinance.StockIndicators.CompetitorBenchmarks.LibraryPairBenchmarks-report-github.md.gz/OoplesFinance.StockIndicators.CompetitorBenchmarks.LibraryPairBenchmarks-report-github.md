```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)yDoji [27]** |  **74.67 μs** | **1.041 μs** | **0.544 μs** |  **1.00** |    **0.01** |  **65.45 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)yDoji [27] |  43.54 μs | 0.708 μs | 0.370 μs |  0.58 |    0.01 |  17.33 KB |        0.26 |
|            |       |                      |           |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)yDoji [27]** | **247.11 μs** | **6.783 μs** | **3.547 μs** |  **1.00** |    **0.02** |  **636.7 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)yDoji [27] | 420.73 μs | 3.378 μs | 1.767 μs |  1.70 |    0.02 | 121.77 KB |        0.19 |
