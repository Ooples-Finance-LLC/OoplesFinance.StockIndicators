```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean     | Error    | StdDev  | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |---------:|---------:|--------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)iLine [24]** | **107.6 μs** | **13.62 μs** | **8.11 μs** |  **1.01** |    **0.10** |  **65.45 KB** |        **1.00** |
|        |       |                      |          |          |         |       |         |           |             |
| **Ooples** | **10000** | **TaLib(...)iLine [24]** | **351.1 μs** | **13.43 μs** | **7.02 μs** |  **1.00** |    **0.03** | **637.03 KB** |        **1.00** |
