```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)iLine [24]** |  **97.55 μs** |  **7.940 μs** |  **4.725 μs** |  **1.00** |    **0.06** |  **65.45 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)iLine [24] |  68.09 μs |  2.556 μs |  1.337 μs |  0.70 |    0.03 |  18.97 KB |        0.29 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)iLine [24]** | **399.48 μs** | **52.353 μs** | **34.629 μs** |  **1.01** |    **0.12** | **637.03 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)iLine [24] | 674.20 μs | 34.123 μs | 22.570 μs |  1.70 |    0.15 | 125.05 KB |        0.20 |
