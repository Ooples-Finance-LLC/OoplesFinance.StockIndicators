```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)iLine [24]** | **1000**  |  **91.42 μs** |  **0.984 μs** |  **0.586 μs** |  **1.00** |    **0.01** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)iLine [24] | 1000  | 129.35 μs |  6.966 μs |  4.608 μs |  1.41 |    0.05 |       - |       - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib(...)iLine [24] | 1000  |  65.99 μs |  0.758 μs |  0.451 μs |  0.72 |    0.01 |  3.4180 |  0.4883 |  57.35 KB |       14.45 |
| BuilderLatestOnly | TaLib(...)iLine [24] | 1000  |  63.15 μs |  0.281 μs |  0.186 μs |  0.69 |    0.00 |  0.4883 |       - |   9.46 KB |        2.38 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)iLine [24]** | **10000** | **716.29 μs** |  **5.463 μs** |  **3.251 μs** |  **1.00** |    **0.01** |       **-** |       **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)iLine [24] | 10000 | 474.57 μs | 57.689 μs | 34.330 μs |  0.66 |    0.05 |  3.9063 |       - |  78.72 KB |        2.01 |
| BuilderFull       | TaLib(...)iLine [24] | 10000 | 418.16 μs |  8.012 μs |  4.190 μs |  0.58 |    0.01 | 31.2500 | 11.7188 | 552.32 KB |       14.11 |
| BuilderLatestOnly | TaLib(...)iLine [24] | 10000 | 404.09 μs | 17.504 μs |  9.155 μs |  0.56 |    0.01 |  3.9063 |       - |  82.21 KB |        2.10 |
