```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)iLine [24]** | **1000**  |  **79.96 μs** |  **0.622 μs** |  **0.370 μs** |       **-** |       **-** |  **57.39 KB** |
| BuilderLatestOnly | TaLib(...)iLine [24] | 1000  |  69.22 μs |  0.274 μs |  0.163 μs |  0.4883 |       - |   9.46 KB |
| **BuilderFull**       | **TaLib(...)iLine [24]** | **10000** | **414.49 μs** | **17.078 μs** |  **8.932 μs** | **31.2500** | **11.7188** | **552.32 KB** |
| BuilderLatestOnly | TaLib(...)iLine [24] | 10000 | 400.60 μs | 30.786 μs | 20.363 μs |  3.9063 |       - |   82.2 KB |
