```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)iLine [24]** | **1000**  |  **84.50 μs** | **0.835 μs** | **0.437 μs** |       **-** |       **-** |  **57.31 KB** |
| BuilderLatestOnly | TaLib(...)iLine [24] | 1000  |  61.30 μs | 0.407 μs | 0.213 μs |  0.4883 |       - |   9.39 KB |
| **BuilderFull**       | **TaLib(...)iLine [24]** | **10000** | **629.98 μs** | **5.035 μs** | **2.634 μs** | **31.2500** | **11.7188** | **549.83 KB** |
| BuilderLatestOnly | TaLib(...)iLine [24] | 10000 | 574.20 μs | 2.612 μs | 1.728 μs |  3.9063 |       - |  79.73 KB |
