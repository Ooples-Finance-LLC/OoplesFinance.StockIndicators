```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean      | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |------------------- |----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Candles.Doji** |  **73.36 μs** | **5.001 μs** | **2.976 μs** |  **1.00** |    **0.05** |  **65.45 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Candles.Doji |  25.88 μs | 0.691 μs | 0.362 μs |  0.35 |    0.01 |  12.08 KB |        0.18 |
|            |       |                    |           |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Candles.Doji** | **238.62 μs** | **4.901 μs** | **2.563 μs** |  **1.00** |    **0.01** |  **636.7 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Candles.Doji | 242.83 μs | 1.418 μs | 0.844 μs |  1.02 |    0.01 | 121.16 KB |        0.19 |
