```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error     | StdDev   | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |----------:|----------:|---------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib.Candles.Doji** | **1000**  |  **23.18 μs** |  **0.560 μs** | **0.293 μs** |  **1.00** |    **0.02** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Doji | 1000  |  87.73 μs |  2.334 μs | 1.544 μs |  3.79 |    0.08 |  0.4883 |       - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib.Candles.Doji | 1000  |  38.07 μs |  0.540 μs | 0.357 μs |  1.64 |    0.02 |  3.4180 |  0.4883 |  57.35 KB |       14.45 |
| BuilderLatestOnly | TaLib.Candles.Doji | 1000  |  33.49 μs |  0.202 μs | 0.106 μs |  1.45 |    0.02 |  0.4883 |       - |   9.46 KB |        2.38 |
|                   |                    |       |           |           |          |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib.Candles.Doji** | **10000** | **210.83 μs** |  **2.617 μs** | **1.557 μs** |  **1.00** |    **0.01** |  **1.9531** |       **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Doji | 10000 | 202.41 μs |  8.597 μs | 5.116 μs |  0.96 |    0.02 |  5.8594 |       - |   78.7 KB |        2.01 |
| BuilderFull       | TaLib.Candles.Doji | 10000 | 270.93 μs | 13.996 μs | 8.329 μs |  1.29 |    0.04 | 33.2031 | 11.7188 |  552.3 KB |       14.11 |
| BuilderLatestOnly | TaLib.Candles.Doji | 10000 | 252.17 μs | 14.070 μs | 9.307 μs |  1.20 |    0.04 |  3.9063 |       - |   82.2 KB |        2.10 |
