```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------------- |------ |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Candles.Doji** | **1000**  |  **49.01 μs** |  **2.532 μs** | **1.507 μs** |  **1.9531** |       **-** |  **57.35 KB** |
| BuilderLatestOnly | TaLib.Candles.Doji | 1000  |  45.05 μs |  0.636 μs | 0.420 μs |  0.4883 |       - |   9.46 KB |
| **BuilderFull**       | **TaLib.Candles.Doji** | **10000** | **275.54 μs** | **12.822 μs** | **8.481 μs** | **33.2031** | **11.7188** |  **552.3 KB** |
| BuilderLatestOnly | TaLib.Candles.Doji | 10000 | 247.20 μs |  4.357 μs | 2.279 μs |  3.9063 |       - |   82.2 KB |
