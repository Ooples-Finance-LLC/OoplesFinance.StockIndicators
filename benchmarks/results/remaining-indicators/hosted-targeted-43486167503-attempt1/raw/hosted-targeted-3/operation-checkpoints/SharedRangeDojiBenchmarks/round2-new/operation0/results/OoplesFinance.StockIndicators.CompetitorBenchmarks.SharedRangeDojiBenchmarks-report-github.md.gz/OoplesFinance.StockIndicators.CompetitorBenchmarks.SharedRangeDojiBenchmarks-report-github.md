```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|-------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)dDoji [28]** | **1000**  |  **48.77 μs** |  **0.750 μs** |  **0.446 μs** |  **1.00** |    **0.01** |      **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)dDoji [28] | 1000  | 106.65 μs |  1.699 μs |  1.011 μs |  2.19 |    0.03 |      - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib(...)dDoji [28] | 1000  |  63.40 μs |  0.757 μs |  0.396 μs |  1.30 |    0.01 | 0.4883 |  57.35 KB |       14.45 |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 1000  |  54.11 μs |  0.425 μs |  0.253 μs |  1.11 |    0.01 |      - |   9.46 KB |        2.38 |
|                   |                      |       |           |           |           |       |         |        |           |             |
| **NativeSingle**      | **TaLib(...)dDoji [28]** | **10000** | **487.98 μs** |  **1.969 μs** |  **1.172 μs** |  **1.00** |    **0.00** |      **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)dDoji [28] | 10000 | 338.76 μs |  6.991 μs |  3.656 μs |  0.69 |    0.01 |      - |  78.72 KB |        2.01 |
| BuilderFull       | TaLib(...)dDoji [28] | 10000 | 404.12 μs | 28.243 μs | 16.807 μs |  0.83 |    0.03 | 3.9063 |  552.3 KB |       14.11 |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 10000 | 364.59 μs |  9.956 μs |  5.207 μs |  0.75 |    0.01 |      - |  82.21 KB |        2.10 |
