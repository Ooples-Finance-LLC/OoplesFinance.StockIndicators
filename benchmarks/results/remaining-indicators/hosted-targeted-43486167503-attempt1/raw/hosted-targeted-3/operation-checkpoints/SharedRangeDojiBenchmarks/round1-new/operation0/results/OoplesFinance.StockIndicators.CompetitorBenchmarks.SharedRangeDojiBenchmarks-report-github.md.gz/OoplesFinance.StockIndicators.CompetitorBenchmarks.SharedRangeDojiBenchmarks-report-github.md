```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)dDoji [28]** | **1000**  |  **80.39 μs** |  **0.989 μs** |  **0.517 μs** |      **-** |  **57.34 KB** |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 1000  |  56.14 μs |  0.421 μs |  0.220 μs |      - |   9.46 KB |
| **BuilderFull**       | **TaLib(...)dDoji [28]** | **10000** | **408.31 μs** | **26.213 μs** | **15.599 μs** | **3.9063** |  **552.3 KB** |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 10000 | 381.29 μs | 27.324 μs | 18.073 μs |      - |   82.2 KB |
