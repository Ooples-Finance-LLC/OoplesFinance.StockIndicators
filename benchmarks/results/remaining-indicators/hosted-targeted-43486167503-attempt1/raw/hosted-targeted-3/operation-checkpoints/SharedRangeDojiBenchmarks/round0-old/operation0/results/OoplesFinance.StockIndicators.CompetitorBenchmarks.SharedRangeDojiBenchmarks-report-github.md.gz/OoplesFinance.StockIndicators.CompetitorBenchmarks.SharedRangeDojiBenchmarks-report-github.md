```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0   | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)dDoji [28]** | **1000**  |  **65.59 μs** | **1.059 μs** | **0.630 μs** |      **-** |  **57.24 KB** |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 1000  |  59.67 μs | 0.546 μs | 0.325 μs |      - |   9.39 KB |
| **BuilderFull**       | **TaLib(...)dDoji [28]** | **10000** | **610.07 μs** | **6.483 μs** | **3.858 μs** | **3.9063** | **549.78 KB** |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 10000 | 551.36 μs | 6.437 μs | 3.830 μs |      - |  79.73 KB |
