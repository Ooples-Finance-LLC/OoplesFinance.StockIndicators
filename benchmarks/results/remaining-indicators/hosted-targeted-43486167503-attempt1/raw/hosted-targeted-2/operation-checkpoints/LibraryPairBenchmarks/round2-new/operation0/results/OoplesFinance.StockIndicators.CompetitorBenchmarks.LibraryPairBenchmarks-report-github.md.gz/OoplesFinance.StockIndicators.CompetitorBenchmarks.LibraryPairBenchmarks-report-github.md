```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)eDoji [28]** | **109.65 μs** |  **1.505 μs** |  **0.787 μs** |  **1.00** |    **0.01** |  **65.41 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)eDoji [28] |  53.69 μs |  2.781 μs |  1.454 μs |  0.49 |    0.01 |  19.58 KB |        0.30 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)eDoji [28]** | **383.74 μs** | **84.550 μs** | **55.925 μs** |  **1.02** |    **0.19** | **636.66 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)eDoji [28] | 520.81 μs | 28.294 μs | 14.798 μs |  1.38 |    0.18 | 124.11 KB |        0.19 |
