```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)eDoji [28]** | **1000**  |  **78.07 μs** |  **0.882 μs** |  **0.525 μs** |       **-** |       **-** |  **57.39 KB** |
| BuilderLatestOnly | TaLib(...)eDoji [28] | 1000  |  60.12 μs |  0.409 μs |  0.243 μs |  0.4883 |       - |   9.46 KB |
| **BuilderFull**       | **TaLib(...)eDoji [28]** | **10000** | **398.76 μs** | **49.096 μs** | **32.474 μs** | **31.2500** | **11.7188** | **552.32 KB** |
| BuilderLatestOnly | TaLib(...)eDoji [28] | 10000 | 366.05 μs | 15.240 μs |  9.069 μs |  3.9063 |       - |  82.21 KB |
