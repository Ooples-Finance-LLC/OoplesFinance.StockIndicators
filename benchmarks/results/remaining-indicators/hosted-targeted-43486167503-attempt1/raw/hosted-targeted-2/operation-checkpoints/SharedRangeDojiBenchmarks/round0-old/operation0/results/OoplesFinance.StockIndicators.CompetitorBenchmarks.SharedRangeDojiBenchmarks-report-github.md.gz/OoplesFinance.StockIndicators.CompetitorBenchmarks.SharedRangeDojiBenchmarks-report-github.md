```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)eDoji [28]** | **1000**  |  **77.44 μs** | **10.525 μs** | **5.505 μs** |       **-** |       **-** |  **57.27 KB** |
| BuilderLatestOnly | TaLib(...)eDoji [28] | 1000  |  57.94 μs |  0.210 μs | 0.110 μs |  0.4883 |       - |   9.39 KB |
| **BuilderFull**       | **TaLib(...)eDoji [28]** | **10000** | **600.99 μs** | **13.387 μs** | **7.966 μs** | **31.2500** | **11.7188** | **549.83 KB** |
| BuilderLatestOnly | TaLib(...)eDoji [28] | 10000 | 542.17 μs |  4.887 μs | 2.908 μs |  3.9063 |       - |  79.72 KB |
