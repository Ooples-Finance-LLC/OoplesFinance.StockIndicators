```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)eDoji [28]** | **1000**  |  **77.80 μs** |  **0.525 μs** |  **0.312 μs** |  **1.00** |    **0.01** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)eDoji [28] | 1000  | 116.73 μs |  1.228 μs |  0.642 μs |  1.50 |    0.01 |       - |       - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib(...)eDoji [28] | 1000  |  60.63 μs |  0.352 μs |  0.210 μs |  0.78 |    0.00 |  3.4180 |  0.4883 |  57.35 KB |       14.45 |
| BuilderLatestOnly | TaLib(...)eDoji [28] | 1000  |  58.36 μs |  0.393 μs |  0.260 μs |  0.75 |    0.00 |  0.4883 |       - |   9.46 KB |        2.38 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)eDoji [28]** | **10000** | **527.87 μs** |  **4.822 μs** |  **2.522 μs** |  **1.00** |    **0.01** |       **-** |       **-** |  **39.16 KB** |        **1.00** |
| NativeParallel    | TaLib(...)eDoji [28] | 10000 | 392.63 μs | 34.493 μs | 22.815 μs |  0.74 |    0.04 |  5.8594 |       - |   78.7 KB |        2.01 |
| BuilderFull       | TaLib(...)eDoji [28] | 10000 | 387.57 μs | 12.792 μs |  6.690 μs |  0.73 |    0.01 | 31.2500 | 11.7188 | 552.32 KB |       14.11 |
| BuilderLatestOnly | TaLib(...)eDoji [28] | 10000 | 374.33 μs |  6.191 μs |  3.684 μs |  0.71 |    0.01 |  3.9063 |       - |  82.21 KB |        2.10 |
