from pathlib import Path
import collections,datetime,hashlib,html,json,re,shutil
ROOT=Path('C:/Users/cheat/StockIndicators-Recovery-20261021');REPO=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
live=Path('C:/Users/cheat/Documents/OoplesFinance-Reports/competitor-performance.html');out=live.parent/'fibonacci-builder-refresh-39729425476';out.mkdir(exist_ok=True)
assert not (out/'before.html').exists()
original=live.read_bytes();s=original.decode('utf-8')
def embedded(name):return json.loads(re.search(r'<script[^>]*id="'+name+r'"[^>]*>(.*?)</script>',s,re.S)[1])
def replace(name,value):
 global s
 s,n=re.subn(r'(<script[^>]*id="'+name+r'"[^>]*>).*?(</script>)',lambda m:m[1]+json.dumps(value,ensure_ascii=True).replace('<','\\u003c')+m[2],s,flags=re.S);assert n==1
baseline=embedded('dataset');archive=embedded('archived-baseline-dataset');builder=embedded('current-competitor-data');status=embedded('rollout-status-data')
assert not builder['receipts'] and sum(builder['verdicts'].values())==0
receipt=json.loads((REPO/'benchmarks/results/remaining-indicators/fibonacci-builder-39729425476.json').read_text());assert receipt['complete'] and len(receipt['comparisons'])==4 and all(r['verdict']=='faster' for r in receipt['comparisons'])
url='https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/39729425476'
now=datetime.datetime.now(datetime.timezone.utc).isoformat();counts={'faster':4,'slower':0,'inconclusive':0}
builder.update(receipts=[receipt],full_comparisons=4,verdicts=counts,status={'commit':receipt['source_sha'],'status':'one-fixture-measured','updated_utc':now,'completed':['SharedFibonacciWeightedBenchmarks'],'failed':[],'qualification':receipt['qualification'],'run_url':url})
replace('current-competitor-data',builder)
assert status['measurement_totals']['expected']==1604
oldhead=status['published_head'];head='93ddb11ceac0fec33262c28a7467e5f2761f8452'
status.update(updated_utc=now,published_head=head,inventory_commit=head,builder_measurement_sources=[{'source_sha':receipt['source_sha'],'run_url':url,'comparisons':4,'current_component_paths':receipt['verified_current_component_paths']}])
status['measurement_totals'].update(**counts,measured=4,pending=1600);replace('rollout-status-data',status)
m=re.search(r'<section id="rollout-status".*?</section>',s,re.S);assert m
panel=m[0];assert '<b>0 / 1604</b>' in panel;panel=panel.replace('<b>0 / 1604</b>','<b>4 / 1604</b>')
old='Builder-mode timing: 0 faster, 0 slower, 0 inconclusive, and 1604 pending.';assert old in panel
panel=panel.replace(old,'Builder-mode timing: 4 faster, 0 slower, 0 inconclusive, and 1600 pending. Fibonacci has matched measurements at period 20 in both history modes; its public batch snapshot is a separate, slower path.')
panel=panel.replace(oldhead[:8],head[:8]);s=s[:m.start()]+panel+s[m.end():]
rows=[]
for r in receipt['comparisons']:
 values=[r['pair'],f"{r['bars']:,}",'Full history' if r['mode']=='BuilderFull' else 'Latest only',f"{r['ooples']['mean_ns']/1e6:.6f}",f"{r['native']['NativeSingle']['mean_ns']/1e6:.6f}",f"{r['native']['NativeParallel']['mean_ns']/1e6:.6f}",'Faster than both']
 rows.append('<tr data-bars="'+str(r['bars'])+'" data-mode="'+r['mode']+'">'+''.join('<td>'+html.escape(x)+'</td>' for x in values)+'</tr>')
headers=['API','Bars','Builder history','Ooples ms','Native serial ms','Native parallel ms','Confidence verdict']
section='<section id="current-competitors" class="section"><h2>Builder-mode qualification progress</h2><p>4 / 1604 matched slots measured: 4 faster, 0 slower, 0 inconclusive, 1600 pending. These count API pair × input size × history mode and are separate from the 802 batch comparisons above.</p><p>Fibonacci builder at period 20 uses an exact rolling recurrence. Its public batch snapshot rescans each window; that different path remains slow. All four builder confidence intervals are below both native intervals on the same runner. Ten warmups and ten requested iterations; the raw report retains samples and intervals.</p><div class="panel tablewrap"><table id="builder-current-results"><thead><tr>'+''.join('<th>'+x+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join(rows)+'</tbody></table></div><p>Measured source <code>'+receipt['source_sha']+'</code>. The Fibonacci implementation, exact accumulator, and benchmark fixture match the published code; the later SMA change is separate. <a href="'+url+'">Measurement run and raw evidence</a>. This qualifies one API at these two sizes and history modes, not every period or universal superiority.</p></section>'
s,n=re.subn(r'<section id="current-competitors".*?</section>',lambda _:section,s,flags=re.S);assert n==1
s,n=re.subn(r'<tr><td>Current matched candidate</td>.*?</tr>',lambda _:'<tr><td>Current matched candidate</td><td>4 / 1604</td><td>API pair × two sizes × two history modes</td><td>Only qualified same-run measurements; pending is not a win</td></tr>',s,count=1,flags=re.S)
assert embedded('dataset')==baseline and embedded('archived-baseline-dataset')==archive
(out/'before.html').write_bytes(original);(out/'candidate.html').write_text(s,encoding='utf-8')
shutil.copyfile(live.parent/'sma-refresh-39727929133/measurement.json',out/'measurement.json')
(out/'staged.json').write_text(json.dumps({'before_sha256':hashlib.sha256(original).hexdigest(),'candidate_sha256':hashlib.sha256((out/'candidate.html').read_bytes()).hexdigest(),'builder_run_id':'39729425476','builder_comparisons':4,'unchanged_baseline_comparisons':802,'receipt':receipt},indent=2))
print('Staged four matched builder wins; all802 batch comparisons unchanged.')
