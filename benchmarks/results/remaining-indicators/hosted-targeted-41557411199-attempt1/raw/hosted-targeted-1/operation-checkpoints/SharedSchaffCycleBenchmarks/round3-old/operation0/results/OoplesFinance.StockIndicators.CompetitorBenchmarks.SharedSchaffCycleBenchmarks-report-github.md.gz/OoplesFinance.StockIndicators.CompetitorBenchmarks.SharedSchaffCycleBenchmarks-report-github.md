```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetStc** | **1000**  |   **945.9 μs** |  **6.65 μs** |  **3.96 μs** |  **66.63 KB** |
| BuilderLatestOnly | Skender.GetStc | 1000  |   928.7 μs |  7.96 μs |  4.16 μs |  18.99 KB |
| **BuilderFull**       | **Skender.GetStc** | **10000** | **9,326.2 μs** | **66.11 μs** | **39.34 μs** | **629.97 KB** |
| BuilderLatestOnly | Skender.GetStc | 10000 | 9,430.3 μs | 52.08 μs | 30.99 μs | 160.24 KB |
