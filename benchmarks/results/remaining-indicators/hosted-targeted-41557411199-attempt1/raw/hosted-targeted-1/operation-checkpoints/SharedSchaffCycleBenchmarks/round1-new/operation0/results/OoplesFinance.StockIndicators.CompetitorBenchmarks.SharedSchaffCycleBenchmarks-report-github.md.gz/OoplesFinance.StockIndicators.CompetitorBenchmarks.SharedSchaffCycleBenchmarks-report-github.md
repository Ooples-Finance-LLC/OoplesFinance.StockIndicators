```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetStc** | **1000**  |   **511.7 μs** |  **6.87 μs** |  **4.09 μs** |       **-** |  **66.65 KB** |
| BuilderLatestOnly | Skender.GetStc | 1000  |   502.8 μs |  4.37 μs |  2.60 μs |       - |  19.01 KB |
| **BuilderFull**       | **Skender.GetStc** | **10000** | **5,043.2 μs** | **66.33 μs** | **39.47 μs** | **31.2500** | **629.68 KB** |
| BuilderLatestOnly | Skender.GetStc | 10000 | 4,964.2 μs | 31.46 μs | 16.46 μs |       - | 159.78 KB |
