```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|----------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **Skender.GetStc** | **1000**  |   **533.97 μs** |  **21.698 μs** |  **11.349 μs** |  **5.59** |    **0.12** |         **-** |         **-** |        **-** |    **66.65 KB** |        **0.12** |
| BuilderLatestOnly | Skender.GetStc | 1000  |   506.85 μs |   2.775 μs |   1.452 μs |  5.31 |    0.04 |         - |         - |        - |    19.01 KB |        0.04 |
| NativeSingle      | Skender.GetStc | 1000  |    95.50 μs |   1.253 μs |   0.655 μs |  1.00 |    0.01 |   32.2266 |    8.7891 |        - |   534.44 KB |        1.00 |
| NativeParallel    | Skender.GetStc | 1000  |   173.96 μs |   4.404 μs |   2.303 μs |  1.82 |    0.03 |   85.9375 |   35.1563 |        - |  1338.31 KB |        2.50 |
|                   |                |       |             |            |            |       |         |           |           |          |             |             |
| **BuilderFull**       | **Skender.GetStc** | **10000** | **5,337.89 μs** |  **42.617 μs** |  **25.361 μs** |  **1.63** |    **0.11** |   **31.2500** |         **-** |        **-** |   **629.64 KB** |        **0.11** |
| BuilderLatestOnly | Skender.GetStc | 10000 | 5,189.76 μs |  30.952 μs |  16.189 μs |  1.58 |    0.11 |         - |         - |        - |   159.82 KB |        0.03 |
| NativeSingle      | Skender.GetStc | 10000 | 3,296.01 μs | 407.544 μs | 213.153 μs |  1.00 |    0.09 |  500.0000 |  437.5000 | 218.7500 |  5621.94 KB |        1.00 |
| NativeParallel    | Skender.GetStc | 10000 | 5,759.17 μs | 437.432 μs | 289.334 μs |  1.75 |    0.15 | 1125.0000 | 1031.2500 | 375.0000 | 13992.97 KB |        2.49 |
