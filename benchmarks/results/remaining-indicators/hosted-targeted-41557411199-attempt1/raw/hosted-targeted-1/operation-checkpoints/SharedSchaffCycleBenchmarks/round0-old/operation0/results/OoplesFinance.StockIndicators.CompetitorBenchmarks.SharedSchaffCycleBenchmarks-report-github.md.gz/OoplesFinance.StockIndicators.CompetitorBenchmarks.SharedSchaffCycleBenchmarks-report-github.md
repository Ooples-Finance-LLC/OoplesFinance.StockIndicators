```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetStc** | **1000**  |   **985.6 μs** |  **3.71 μs** |  **2.21 μs** |  **66.63 KB** |
| BuilderLatestOnly | Skender.GetStc | 1000  |   969.5 μs |  8.48 μs |  4.44 μs |  18.99 KB |
| **BuilderFull**       | **Skender.GetStc** | **10000** | **9,693.7 μs** | **65.27 μs** | **38.84 μs** | **630.06 KB** |
| BuilderLatestOnly | Skender.GetStc | 10000 | 9,519.3 μs | 30.81 μs | 16.11 μs | 160.15 KB |
