```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetKvo** | **1000**  |   **984.1 μs** |  **3.75 μs** |  **1.96 μs** |  **81.29 KB** |
| BuilderLatestOnly | Skender.GetKvo | 1000  |   987.4 μs | 22.16 μs | 11.59 μs |  33.65 KB |
| **BuilderFull**       | **Skender.GetKvo** | **10000** | **9,784.9 μs** | **29.97 μs** | **15.67 μs** | **785.37 KB** |
| BuilderLatestOnly | Skender.GetKvo | 10000 | 9,889.6 μs | 64.87 μs | 38.60 μs | 315.66 KB |
