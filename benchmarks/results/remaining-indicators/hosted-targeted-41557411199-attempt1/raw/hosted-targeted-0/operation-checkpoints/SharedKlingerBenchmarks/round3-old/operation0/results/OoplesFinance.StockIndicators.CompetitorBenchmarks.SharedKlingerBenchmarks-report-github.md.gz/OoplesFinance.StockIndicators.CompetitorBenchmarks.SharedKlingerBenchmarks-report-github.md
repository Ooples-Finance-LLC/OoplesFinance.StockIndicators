```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Skender.GetKvo** | **1000**  |  **1.629 ms** | **0.0076 ms** | **0.0045 ms** |  **81.25 KB** |
| BuilderLatestOnly | Skender.GetKvo | 1000  |  1.466 ms | 0.0112 ms | 0.0067 ms |  33.65 KB |
| **BuilderFull**       | **Skender.GetKvo** | **10000** | **15.105 ms** | **0.0612 ms** | **0.0364 ms** | **785.76 KB** |
| BuilderLatestOnly | Skender.GetKvo | 10000 | 15.244 ms | 0.0763 ms | 0.0454 ms | 315.94 KB |
