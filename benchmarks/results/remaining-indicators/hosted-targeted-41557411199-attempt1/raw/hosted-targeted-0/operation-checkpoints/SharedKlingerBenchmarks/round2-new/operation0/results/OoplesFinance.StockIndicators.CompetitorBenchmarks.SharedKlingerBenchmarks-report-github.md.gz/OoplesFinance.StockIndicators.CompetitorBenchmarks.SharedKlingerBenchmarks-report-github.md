```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetKvo** | **1000**  | **1,208.19 μs** | **83.502 μs** | **49.691 μs** | **15.79** |    **1.22** |        **-** |        **-** |   **81.29 KB** |        **0.39** |
| BuilderLatestOnly | Skender.GetKvo | 1000  |   926.51 μs | 16.676 μs |  9.924 μs | 12.11 |    0.82 |        - |        - |   33.66 KB |        0.16 |
| NativeSingle      | Skender.GetKvo | 1000  |    76.89 μs | 11.254 μs |  5.886 μs |  1.00 |    0.10 |  11.7188 |        - |  207.65 KB |        1.00 |
| NativeParallel    | Skender.GetKvo | 1000  |   199.59 μs |  9.594 μs |  6.346 μs |  2.61 |    0.19 |  33.2031 |  11.7188 |   528.2 KB |        2.54 |
|                   |                |       |             |           |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetKvo** | **10000** | **9,335.68 μs** | **33.651 μs** | **17.600 μs** | **11.44** |    **0.13** |        **-** |        **-** |  **785.43 KB** |        **0.38** |
| BuilderLatestOnly | Skender.GetKvo | 10000 | 9,310.42 μs | 22.370 μs | 11.700 μs | 11.41 |    0.13 |        - |        - |  315.59 KB |        0.15 |
| NativeSingle      | Skender.GetKvo | 10000 |   816.32 μs | 15.953 μs |  9.493 μs |  1.00 |    0.02 | 125.0000 |  85.9375 | 2070.96 KB |        1.00 |
| NativeParallel    | Skender.GetKvo | 10000 | 1,396.30 μs | 79.271 μs | 52.433 μs |  1.71 |    0.06 | 320.3125 | 250.0000 | 5256.76 KB |        2.54 |
