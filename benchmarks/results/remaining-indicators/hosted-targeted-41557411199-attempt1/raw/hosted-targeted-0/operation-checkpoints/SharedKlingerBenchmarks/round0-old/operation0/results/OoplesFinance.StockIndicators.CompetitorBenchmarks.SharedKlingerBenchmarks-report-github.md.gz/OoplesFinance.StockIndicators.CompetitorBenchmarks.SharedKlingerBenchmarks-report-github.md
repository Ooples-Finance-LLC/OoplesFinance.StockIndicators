```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Skender.GetKvo** | **1000**  |  **2.474 ms** | **1.0490 ms** | **0.6939 ms** |  **81.25 KB** |
| BuilderLatestOnly | Skender.GetKvo | 1000  |  1.492 ms | 0.0082 ms | 0.0043 ms |  33.58 KB |
| **BuilderFull**       | **Skender.GetKvo** | **10000** | **15.059 ms** | **0.0756 ms** | **0.0450 ms** | **785.76 KB** |
| BuilderLatestOnly | Skender.GetKvo | 10000 | 15.300 ms | 0.0617 ms | 0.0367 ms | 315.94 KB |
