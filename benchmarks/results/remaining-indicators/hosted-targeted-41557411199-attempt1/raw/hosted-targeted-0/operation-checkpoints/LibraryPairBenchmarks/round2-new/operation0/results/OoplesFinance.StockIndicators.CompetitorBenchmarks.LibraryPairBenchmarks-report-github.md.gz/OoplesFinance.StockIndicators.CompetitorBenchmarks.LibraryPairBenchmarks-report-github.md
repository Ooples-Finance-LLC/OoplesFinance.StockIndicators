```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean         | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetKvo** |  **1,085.50 μs** | **40.242 μs** | **21.047 μs** |  **1.00** |    **0.03** |  **162.95 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetKvo |     84.62 μs |  5.177 μs |  2.708 μs |  0.08 |    0.00 |  272.89 KB |        1.67 |
|            |       |                |              |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetKvo** | **10,527.84 μs** | **46.289 μs** | **27.546 μs** |  **1.00** |    **0.00** | **1594.65 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetKvo |    885.32 μs | 56.819 μs | 37.582 μs |  0.08 |    0.00 | 2646.55 KB |        1.66 |
