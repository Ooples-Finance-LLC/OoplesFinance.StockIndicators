```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetStc** |   **664.1 μs** | **32.80 μs** | **21.70 μs** |  **1.00** |    **0.04** |  **108.68 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetStc |   140.6 μs |  6.24 μs |  3.26 μs |  0.21 |    0.01 |  559.78 KB |        5.15 |
|            |       |                |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetStc** | **6,617.9 μs** | **42.62 μs** | **28.19 μs** |  **1.00** |    **0.01** | **1038.75 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetStc | 1,401.4 μs | 35.39 μs | 21.06 μs |  0.21 |    0.00 | 5794.76 KB |        5.58 |
