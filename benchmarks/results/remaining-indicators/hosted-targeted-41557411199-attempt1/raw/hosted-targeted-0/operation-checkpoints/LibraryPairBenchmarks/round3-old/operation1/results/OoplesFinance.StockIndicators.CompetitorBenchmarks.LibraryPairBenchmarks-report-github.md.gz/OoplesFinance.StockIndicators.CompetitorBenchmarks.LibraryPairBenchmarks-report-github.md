```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId         | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetStc** |  **1.127 ms** | **0.0353 ms** | **0.0210 ms** |  **1.00** |    **0.03** |  **108.63 KB** |        **1.00** |
|        |       |                |           |           |           |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetStc** | **11.396 ms** | **0.1691 ms** | **0.1119 ms** |  **1.00** |    **0.01** | **1039.64 KB** |        **1.00** |
