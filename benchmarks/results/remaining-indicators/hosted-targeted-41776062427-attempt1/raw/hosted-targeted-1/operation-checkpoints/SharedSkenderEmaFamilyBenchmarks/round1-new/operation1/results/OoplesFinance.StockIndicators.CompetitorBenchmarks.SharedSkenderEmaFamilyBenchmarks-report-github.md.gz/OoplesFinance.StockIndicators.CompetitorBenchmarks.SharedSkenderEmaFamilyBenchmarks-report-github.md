```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |--------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **612.9 μs** |  **2.49 μs** |  **1.30 μs** |       **-** |  **105.08 KB** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   591.8 μs |  4.30 μs |  2.56 μs |       - |   57.42 KB |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **5,979.4 μs** | **39.17 μs** | **23.31 μs** | **31.2500** | **1019.67 KB** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 6,049.4 μs | 31.09 μs | 18.50 μs | 31.2500 |  549.84 KB |
