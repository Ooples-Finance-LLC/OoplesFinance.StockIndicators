```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **631.10 μs** |   **5.232 μs** |   **3.114 μs** |  **8.83** |    **0.14** |        **-** |        **-** |        **-** |  **105.08 KB** |        **0.37** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   612.98 μs |   3.357 μs |   1.756 μs |  8.58 |    0.13 |        - |        - |        - |   57.42 KB |        0.20 |
| NativeSingle      | Skender.GetPvo | 1000  |    71.49 μs |   1.863 μs |   1.109 μs |  1.00 |    0.02 |  17.0898 |   3.4180 |        - |  285.61 KB |        1.00 |
| NativeParallel    | Skender.GetPvo | 1000  |   137.16 μs |   6.293 μs |   3.745 μs |  1.92 |    0.06 |  46.8750 |  16.6016 |        - |  729.53 KB |        2.55 |
|                   |                |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **6,182.76 μs** |  **53.425 μs** |  **35.337 μs** |  **5.18** |    **0.14** |  **31.2500** |        **-** |        **-** | **1019.65 KB** |        **0.33** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 6,181.98 μs |  27.609 μs |  16.430 μs |  5.18 |    0.14 |        - |        - |        - |  550.09 KB |        0.18 |
| NativeSingle      | Skender.GetPvo | 10000 | 1,193.51 μs |  50.139 μs |  33.164 μs |  1.00 |    0.04 | 164.0625 | 164.0625 | 164.0625 | 3052.14 KB |        1.00 |
| NativeParallel    | Skender.GetPvo | 10000 | 3,708.85 μs | 372.041 μs | 221.396 μs |  3.11 |    0.19 | 625.0000 | 500.0000 | 250.0000 | 7581.23 KB |        2.48 |
