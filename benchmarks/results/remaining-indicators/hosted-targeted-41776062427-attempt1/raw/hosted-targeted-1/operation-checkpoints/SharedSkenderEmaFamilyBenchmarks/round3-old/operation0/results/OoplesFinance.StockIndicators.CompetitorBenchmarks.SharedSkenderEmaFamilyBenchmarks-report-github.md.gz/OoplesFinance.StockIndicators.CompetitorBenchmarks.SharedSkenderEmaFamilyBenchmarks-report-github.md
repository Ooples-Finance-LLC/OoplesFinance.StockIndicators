```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **554.7 μs** |  **2.16 μs** |  **1.13 μs** |       **-** |  **128.54 KB** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   546.6 μs |  5.96 μs |  3.55 μs |  3.9063 |    80.9 KB |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **5,624.3 μs** | **73.66 μs** | **48.72 μs** | **62.5000** | **1254.06 KB** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 5,571.2 μs | 40.49 μs | 26.78 μs | 31.2500 |  784.26 KB |
