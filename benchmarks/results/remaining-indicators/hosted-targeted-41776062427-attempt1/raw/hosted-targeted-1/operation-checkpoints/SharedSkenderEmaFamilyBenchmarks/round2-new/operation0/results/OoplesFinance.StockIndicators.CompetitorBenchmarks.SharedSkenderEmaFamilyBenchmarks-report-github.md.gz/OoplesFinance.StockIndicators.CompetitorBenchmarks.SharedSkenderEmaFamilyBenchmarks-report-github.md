```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **558.71 μs** |   **1.433 μs** |   **0.853 μs** |  **8.22** |    **0.11** |        **-** |        **-** |        **-** |  **128.55 KB** |        **0.40** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   550.94 μs |   4.858 μs |   2.891 μs |  8.10 |    0.12 |   3.9063 |        - |        - |   80.92 KB |        0.25 |
| NativeSingle      | Skender.GetMacd | 1000  |    67.99 μs |   1.604 μs |   0.955 μs |  1.00 |    0.02 |  19.5313 |   6.3477 |        - |  324.54 KB |        1.00 |
| NativeParallel    | Skender.GetMacd | 1000  |   138.82 μs |  17.248 μs |  10.264 μs |  2.04 |    0.15 |  53.7109 |  18.5547 |        - |  826.63 KB |        2.55 |
|                   |                 |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **5,588.54 μs** | **101.204 μs** |  **66.940 μs** |  **4.13** |    **0.11** |  **62.5000** |        **-** |        **-** | **1254.08 KB** |        **0.36** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 5,635.44 μs |  33.510 μs |  22.165 μs |  4.16 |    0.10 |  31.2500 |        - |        - |  784.28 KB |        0.23 |
| NativeSingle      | Skender.GetMacd | 10000 | 1,355.22 μs |  51.857 μs |  34.301 μs |  1.00 |    0.03 | 218.7500 | 218.7500 | 218.7500 | 3443.12 KB |        1.00 |
| NativeParallel    | Skender.GetMacd | 10000 | 4,318.55 μs | 676.270 μs | 447.311 μs |  3.19 |    0.32 | 750.0000 | 625.0000 | 312.5000 | 8557.34 KB |        2.49 |
