```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev   | Allocated  |
|------------------ |--------------- |------ |-----------:|----------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **696.5 μs** |  **43.52 μs** | **25.90 μs** |  **105.05 KB** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   660.5 μs |   1.94 μs |  1.15 μs |   57.39 KB |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **6,765.0 μs** |  **14.63 μs** |  **7.65 μs** | **1019.92 KB** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 6,777.1 μs | 117.66 μs | 70.02 μs |  550.11 KB |
