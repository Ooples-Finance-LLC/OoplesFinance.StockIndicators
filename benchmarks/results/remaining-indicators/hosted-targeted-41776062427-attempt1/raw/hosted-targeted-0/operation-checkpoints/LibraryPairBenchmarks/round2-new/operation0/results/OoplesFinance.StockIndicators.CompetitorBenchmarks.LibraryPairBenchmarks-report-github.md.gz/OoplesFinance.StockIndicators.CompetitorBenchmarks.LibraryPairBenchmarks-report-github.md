```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId          | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetMacd** |   **674.34 μs** | **21.599 μs** | **14.286 μs** |  **1.00** |    **0.03** |  **331.71 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetMacd |    99.34 μs |  9.518 μs |  5.664 μs |  0.15 |    0.01 |  456.36 KB |        1.38 |
|            |       |                 |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetMacd** | **6,495.39 μs** | **33.081 μs** | **21.881 μs** |  **1.00** |    **0.00** | **3266.67 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetMacd | 1,103.27 μs | 29.384 μs | 17.486 μs |  0.17 |    0.00 |  4671.2 KB |        1.43 |
