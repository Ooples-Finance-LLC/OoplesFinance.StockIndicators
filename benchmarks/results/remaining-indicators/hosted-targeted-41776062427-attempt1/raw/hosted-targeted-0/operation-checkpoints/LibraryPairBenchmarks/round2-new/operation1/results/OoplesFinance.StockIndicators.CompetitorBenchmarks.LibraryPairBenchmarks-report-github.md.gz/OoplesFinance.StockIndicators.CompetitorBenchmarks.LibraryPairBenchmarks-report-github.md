```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetPvo** |   **735.31 μs** | **25.212 μs** | **15.003 μs** |  **1.00** |    **0.03** |  **290.12 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetPvo |    82.12 μs |  3.017 μs |  1.578 μs |  0.11 |    0.00 |  375.59 KB |        1.29 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetPvo** | **7,124.40 μs** | **63.325 μs** | **41.885 μs** |  **1.00** |    **0.01** | **2855.56 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetPvo |   890.74 μs | 49.554 μs | 29.489 μs |  0.13 |    0.00 | 3870.66 KB |        1.36 |
