```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error        | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-------------:|------------:|------:|--------:|----------:|----------:|----------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)gence [50]** |    **647.5 μs** |      **6.63 μs** |     **3.47 μs** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |   **290.1 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)gence [50] |  2,354.5 μs |     53.94 μs |    35.68 μs |  3.64 |    0.06 |         - |         - |         - | 3515.23 KB |       12.12 |
|            |       |                      |             |              |             |       |         |           |           |           |            |             |
| **Ooples**     | **10000** | **Trady(...)gence [50]** |  **6,396.8 μs** |    **101.92 μs** |    **60.65 μs** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** | **2856.86 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)gence [50] | 35,997.5 μs | 10,354.76 μs | 6,849.03 μs |  5.63 |    1.02 | 2000.0000 | 1000.0000 | 1000.0000 |   34695 KB |       12.14 |
