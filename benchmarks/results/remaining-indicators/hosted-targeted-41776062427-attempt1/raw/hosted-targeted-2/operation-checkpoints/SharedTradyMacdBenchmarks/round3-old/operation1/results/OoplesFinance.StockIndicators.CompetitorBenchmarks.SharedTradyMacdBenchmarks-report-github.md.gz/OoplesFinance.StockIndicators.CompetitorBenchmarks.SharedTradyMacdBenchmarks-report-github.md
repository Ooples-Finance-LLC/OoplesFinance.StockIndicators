```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |   **410.7 μs** |  **5.55 μs** |  **3.30 μs** |  **73.68 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |   399.7 μs |  4.34 μs |  2.58 μs |  26.05 KB |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** | **4,128.5 μs** | **71.69 μs** | **47.42 μs** | **707.02 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 | 4,018.8 μs | 98.16 μs | 58.41 μs | 237.18 KB |
