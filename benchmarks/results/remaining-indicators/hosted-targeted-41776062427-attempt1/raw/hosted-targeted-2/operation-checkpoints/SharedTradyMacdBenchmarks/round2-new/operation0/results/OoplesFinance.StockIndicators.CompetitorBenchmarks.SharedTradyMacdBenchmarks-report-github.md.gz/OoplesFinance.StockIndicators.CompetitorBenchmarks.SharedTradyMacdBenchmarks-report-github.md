```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |    **456.5 μs** |    **28.50 μs** |    **18.85 μs** |  **0.22** |    **0.01** |         **-** |         **-** |         **-** |   **104.96 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |    441.1 μs |    12.05 μs |     7.17 μs |  0.21 |    0.01 |         - |         - |         - |    57.41 KB |        0.02 |
| NativeSingle      | Movin(...)gence [34] | 1000  |  2,094.1 μs |    69.28 μs |    45.82 μs |  1.00 |    0.03 |   46.8750 |   46.8750 |   46.8750 |  3232.14 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 1000  |  1,698.3 μs |    90.70 μs |    60.00 μs |  0.81 |    0.03 |   62.5000 |   46.8750 |         - |   5670.9 KB |        1.75 |
|                   |                      |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** |  **4,469.6 μs** |    **94.54 μs** |    **62.53 μs** |  **0.16** |    **0.02** |         **-** |         **-** |         **-** |   **1019.6 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 |  4,492.1 μs |   135.27 μs |    89.47 μs |  0.17 |    0.02 |         - |         - |         - |   549.84 KB |        0.02 |
| NativeSingle      | Movin(...)gence [34] | 10000 | 27,509.2 μs | 4,515.21 μs | 2,986.53 μs |  1.01 |    0.16 | 1250.0000 | 1250.0000 | 1250.0000 | 31914.79 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 10000 | 28,848.8 μs | 5,797.99 μs | 3,835.01 μs |  1.06 |    0.18 | 1750.0000 | 1500.0000 | 1500.0000 | 56068.75 KB |        1.76 |
