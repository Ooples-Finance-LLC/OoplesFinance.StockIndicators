```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|-----------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |   **450.6 μs** |   **8.87 μs** |  **4.64 μs** |  **105.03 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |   431.3 μs |   2.91 μs |  1.52 μs |   57.39 KB |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** | **4,559.7 μs** | **109.80 μs** | **72.63 μs** | **1019.61 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 | 4,355.6 μs |  81.64 μs | 54.00 μs |  549.71 KB |
