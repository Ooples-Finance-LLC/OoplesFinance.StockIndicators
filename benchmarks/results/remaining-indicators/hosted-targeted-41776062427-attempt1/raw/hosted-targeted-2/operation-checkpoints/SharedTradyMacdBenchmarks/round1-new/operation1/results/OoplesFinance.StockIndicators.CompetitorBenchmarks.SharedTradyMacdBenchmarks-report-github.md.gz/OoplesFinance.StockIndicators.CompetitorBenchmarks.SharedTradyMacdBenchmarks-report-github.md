```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |   **445.1 μs** |  **5.95 μs** |  **3.93 μs** |   **73.6 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |   415.6 μs |  2.20 μs |  1.31 μs |  26.03 KB |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** | **4,189.8 μs** | **32.10 μs** | **19.10 μs** | **707.02 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 | 4,211.6 μs | 26.07 μs | 13.64 μs | 237.24 KB |
