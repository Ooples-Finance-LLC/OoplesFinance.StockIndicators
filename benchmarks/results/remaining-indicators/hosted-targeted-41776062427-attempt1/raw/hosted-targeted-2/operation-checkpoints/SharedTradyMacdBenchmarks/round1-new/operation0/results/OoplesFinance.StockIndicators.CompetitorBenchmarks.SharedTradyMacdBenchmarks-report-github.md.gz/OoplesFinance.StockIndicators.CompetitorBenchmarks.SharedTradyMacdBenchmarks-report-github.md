```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |   **445.8 μs** |  **9.09 μs** |  **5.41 μs** |     **105 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |   433.2 μs |  6.30 μs |  3.75 μs |   57.41 KB |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** | **4,500.9 μs** | **97.87 μs** | **64.74 μs** | **1019.57 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 | 4,471.6 μs | 88.99 μs | 52.96 μs |  549.82 KB |
