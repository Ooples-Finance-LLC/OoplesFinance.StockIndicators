```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |    **435.2 μs** |    **33.52 μs** |    **22.17 μs** |  **0.20** |    **0.01** |         **-** |         **-** |         **-** |     **73.7 KB** |       **0.022** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |    420.6 μs |     7.28 μs |     4.81 μs |  0.19 |    0.01 |         - |         - |         - |    26.06 KB |       0.008 |
| NativeSingle      | Movin(...)ogram [43] | 1000  |  2,168.4 μs |    85.45 μs |    56.52 μs |  1.00 |    0.04 |   46.8750 |   46.8750 |   46.8750 |  3389.09 KB |       1.000 |
| NativeParallel    | Movin(...)ogram [43] | 1000  |  1,688.6 μs |    35.22 μs |    18.42 μs |  0.78 |    0.02 |   62.5000 |   46.8750 |         - |   5597.5 KB |       1.652 |
|                   |                      |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** |  **4,145.2 μs** |    **58.90 μs** |    **30.81 μs** |  **0.15** |    **0.01** |         **-** |         **-** |         **-** |   **707.02 KB** |       **0.021** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 |  4,079.9 μs |    12.32 μs |     7.33 μs |  0.15 |    0.01 |         - |         - |         - |   237.22 KB |       0.007 |
| NativeSingle      | Movin(...)ogram [43] | 10000 | 28,185.5 μs | 3,680.87 μs | 2,434.66 μs |  1.01 |    0.12 | 1250.0000 | 1250.0000 | 1250.0000 | 33360.21 KB |       1.000 |
| NativeParallel    | Movin(...)ogram [43] | 10000 | 28,393.1 μs | 3,759.93 μs | 2,486.96 μs |  1.01 |    0.12 | 1750.0000 | 1500.0000 | 1500.0000 | 55285.12 KB |       1.657 |
