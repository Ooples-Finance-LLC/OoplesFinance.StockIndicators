```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |   **419.8 μs** |  **7.46 μs** |  **4.44 μs** |  **73.68 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |   413.8 μs | 15.11 μs | 10.00 μs |  26.05 KB |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** | **4,124.1 μs** | **39.57 μs** | **20.70 μs** | **707.01 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 | 4,030.9 μs | 71.39 μs | 42.48 μs | 237.22 KB |
