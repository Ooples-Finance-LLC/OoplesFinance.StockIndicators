```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean       | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |------------------- |-----------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ad** | **181.410 μs** | **20.9123 μs** | **13.8322 μs** |  **1.00** |    **0.10** |  **72.92 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ad |   4.150 μs |  0.5959 μs |  0.3117 μs |  0.02 |    0.00 |  14.99 KB |        0.21 |
|            |       |                    |            |            |            |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ad** | **261.967 μs** | **16.7798 μs** |  **9.9854 μs** |  **1.00** |    **0.05** |  **713.2 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ad |  28.033 μs | 11.5929 μs |  6.8987 μs |  0.11 |    0.03 |  86.01 KB |        0.12 |
