```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean         | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |-------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **141.234 μs** | **3.2640 μs** | **1.9424 μs** | **59.72** |    **1.59** |  **3.9063** |      **-** |  **64.89 KB** |        **8.24** |
| BuilderLatestOnly | Ad        | 1000  |   136.832 μs | 8.3121 μs | 5.4979 μs | 57.86 |    2.59 |  0.9766 |      - |  17.28 KB |        2.19 |
| NativeSingle      | Ad        | 1000  |     2.366 μs | 0.0993 μs | 0.0591 μs |  1.00 |    0.03 |  0.4730 |      - |   7.88 KB |        1.00 |
| NativeParallel    | Ad        | 1000  |    89.051 μs | 1.5437 μs | 1.0210 μs | 37.65 |    0.97 |  0.4883 |      - |   8.17 KB |        1.04 |
|                   |           |       |              |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **Ad**        | **10000** | **1,209.875 μs** | **8.8534 μs** | **5.2685 μs** | **56.58** |    **0.38** | **31.2500** | **7.8125** | **627.79 KB** |        **8.03** |
| BuilderLatestOnly | Ad        | 10000 | 1,233.313 μs | 9.7553 μs | 5.8052 μs | 57.67 |    0.40 |  7.8125 |      - | 157.97 KB |        2.02 |
| NativeSingle      | Ad        | 10000 |    21.386 μs | 0.2007 μs | 0.1194 μs |  1.00 |    0.01 |  4.7607 | 0.8545 |  78.19 KB |        1.00 |
| NativeParallel    | Ad        | 10000 |   111.981 μs | 2.3849 μs | 1.2473 μs |  5.24 |    0.06 |  3.9063 |      - |  78.48 KB |        1.00 |
