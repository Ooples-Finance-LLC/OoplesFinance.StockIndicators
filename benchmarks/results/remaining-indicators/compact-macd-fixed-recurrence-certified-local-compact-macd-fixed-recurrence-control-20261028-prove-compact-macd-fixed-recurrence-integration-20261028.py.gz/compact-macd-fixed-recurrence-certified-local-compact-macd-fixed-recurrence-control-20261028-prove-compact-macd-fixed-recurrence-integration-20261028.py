from pathlib import Path
import gzip,hashlib,importlib.util,json,subprocess
from compact_macd_acceptance import qualifies
root=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
repo=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
kind='compact-macd-fixed-recurrence'
state=json.loads((root/'accepted-arithmetic-integration-20261028/status.json').read_text())
assert state['status']=='checks-passed-review-and-publication-pending'
assert kind in state['qualified_batches']
assert state['gpu_passed']==100 and state['checks']['inventory-tests']=='passed'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==state['input_head']
summary=json.loads((root/('local-'+kind+'-control-20261028')/'verified-summary.json').read_text())
assert summary['all_384_cases_verified'] and qualifies(summary['decisions'])
qualified=json.loads((root/kind/'status.json').read_text())
paths=set(qualified['reviewed_source_changes'])
if kind=='compact-macd-fixed-recurrence':
    paths.update(json.loads((root/'compact-macd-fused-recurrence/status.json').read_text())['reviewed_source_changes'])
subprocess.run(['git','diff','--exit-code',summary['sources']['new'],'HEAD','--',*sorted(paths)],cwd=repo,check=True)
for path,digest in state['production_dll_sha256'].items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
spec=importlib.util.spec_from_file_location('gpu',repo/'scripts/verify-competitor-local-gpu.py')
gpu=importlib.util.module_from_spec(spec);spec.loader.exec_module(gpu)
receipt=json.loads((gpu.EVIDENCE/'receipt.json').read_text())
raw=gzip.decompress((gpu.EVIDENCE/'gpu.trx.gz').read_bytes())
gpu.verify_evidence(receipt,raw,json.loads(gpu.METHODS.read_text()),gpu.source_fingerprint(repo))
proof={'combined_code_source':state['input_head'],'individual_qualified_source':summary['sources']['new'],'source_fingerprint_sha256':receipt['source_sha256'],'fresh_combined_tree_checks':{'unit':state['unit']['passed'],'parity':state['parity']['passed'],'gpu':100,'inventory':8},'production_dll_sha256':state['production_dll_sha256'],'matched_source_files':sorted(paths),'note':'Fresh combined-tree correctness evidence. Timing rows retain the individually measured source commit; no individual GPU receipt is relabeled as combined evidence.'}
(repo/('benchmarks/results/remaining-indicators/'+kind+'-integration-source-proof-20261028.json')).write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print('Verified source and fresh combined-tree qualification:',kind)
