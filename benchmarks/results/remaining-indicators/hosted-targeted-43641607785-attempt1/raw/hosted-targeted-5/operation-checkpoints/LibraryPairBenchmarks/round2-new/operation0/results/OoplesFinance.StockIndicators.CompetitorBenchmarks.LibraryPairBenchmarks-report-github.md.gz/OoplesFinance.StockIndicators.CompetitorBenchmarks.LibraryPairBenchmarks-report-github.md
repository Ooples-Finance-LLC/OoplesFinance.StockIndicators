```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Crows [29]** |  **81.28 μs** | **10.145 μs** |  **5.306 μs** |  **1.00** |    **0.08** |  **69.37 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Crows [29] |  52.07 μs |  0.545 μs |  0.324 μs |  0.64 |    0.04 |  17.94 KB |        0.26 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Crows [29]** | **283.14 μs** | **14.387 μs** |  **8.562 μs** |  **1.00** |    **0.04** | **638.72 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Crows [29] | 505.15 μs | 17.924 μs | 11.856 μs |  1.79 |    0.06 | 120.83 KB |        0.19 |
