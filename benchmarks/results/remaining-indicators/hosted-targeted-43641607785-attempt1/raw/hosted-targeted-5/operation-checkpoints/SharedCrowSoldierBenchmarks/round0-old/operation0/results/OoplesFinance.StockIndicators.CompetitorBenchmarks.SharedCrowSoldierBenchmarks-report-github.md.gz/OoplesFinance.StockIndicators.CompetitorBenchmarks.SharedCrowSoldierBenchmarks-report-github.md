```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation            | Mean     | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |------ |--------------------- |---------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **1000**  | **TaLib(...)Crows [29]** | **105.4 μs** |  **5.76 μs** |  **3.81 μs** |  **3.9063** |      **-** |  **65.62 KB** |
| BuilderLatestOnly | 1000  | TaLib(...)Crows [29] | 102.3 μs |  1.57 μs |  0.82 μs |  0.9766 |      - |  17.78 KB |
| **BuilderFull**       | **10000** | **TaLib(...)Crows [29]** | **343.1 μs** | **18.24 μs** | **12.06 μs** | **33.2031** | **9.7656** | **558.17 KB** |
| BuilderLatestOnly | 10000 | TaLib(...)Crows [29] | 321.6 μs | 17.25 μs | 11.41 μs |  3.9063 |      - |  88.11 KB |
