```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation            | Mean     | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |------ |--------------------- |---------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **1000**  | **TaLib(...)Crows [29]** | **104.1 μs** |  **2.70 μs** |  **1.41 μs** |  **3.9063** |      **-** |  **65.62 KB** |
| BuilderLatestOnly | 1000  | TaLib(...)Crows [29] | 100.7 μs |  1.21 μs |  0.63 μs |  0.9766 |      - |  17.78 KB |
| **BuilderFull**       | **10000** | **TaLib(...)Crows [29]** | **333.5 μs** | **10.88 μs** |  **5.69 μs** | **31.2500** | **7.8125** | **558.18 KB** |
| BuilderLatestOnly | 10000 | TaLib(...)Crows [29] | 316.6 μs | 21.08 μs | 13.94 μs |  3.9063 |      - |   88.1 KB |
