```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=20000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)iStar [29]** |  **36.27 μs** |  **3.367 μs** | **2.004 μs** |  **1.00** |    **0.07** |  **73.08 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)iStar [29] |  45.98 μs |  0.454 μs | 0.238 μs |  1.27 |    0.06 |  15.69 KB |        0.21 |
|            |       |                      |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)iStar [29]** | **261.84 μs** | **11.442 μs** | **6.809 μs** |  **1.00** |    **0.03** | **662.02 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)iStar [29] | 454.21 μs | 14.320 μs | 9.472 μs |  1.74 |    0.05 | 122.47 KB |        0.18 |
