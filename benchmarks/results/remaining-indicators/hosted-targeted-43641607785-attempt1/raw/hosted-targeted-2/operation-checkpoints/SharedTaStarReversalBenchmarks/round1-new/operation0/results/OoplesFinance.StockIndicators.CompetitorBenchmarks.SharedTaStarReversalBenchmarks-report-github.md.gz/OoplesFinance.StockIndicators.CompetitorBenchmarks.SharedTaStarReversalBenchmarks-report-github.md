```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **MorningDojiStar** | **1000**  | **114.3 μs** |  **3.25 μs** |  **2.15 μs** |  **3.9063** |       **-** |  **71.74 KB** |
| BuilderLatestOnly | MorningDojiStar | 1000  | 117.4 μs |  4.65 μs |  2.77 μs |  0.9766 |       - |  23.86 KB |
| **BuilderFull**       | **MorningDojiStar** | **10000** | **357.5 μs** | **18.64 μs** | **12.33 μs** | **35.1563** | **13.6719** | **583.51 KB** |
| BuilderLatestOnly | MorningDojiStar | 10000 | 340.8 μs | 18.41 μs | 12.18 μs |  5.8594 |       - |  113.4 KB |
