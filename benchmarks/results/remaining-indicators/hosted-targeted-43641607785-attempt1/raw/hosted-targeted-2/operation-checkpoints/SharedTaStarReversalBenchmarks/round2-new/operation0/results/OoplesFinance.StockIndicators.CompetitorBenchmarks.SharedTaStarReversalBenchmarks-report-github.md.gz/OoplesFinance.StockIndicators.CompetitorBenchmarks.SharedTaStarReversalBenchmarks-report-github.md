```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |---------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **MorningDojiStar** | **1000**  |  **96.56 μs** |  **6.330 μs** |  **3.767 μs** |  **2.54** |    **0.11** |  **3.9063** |       **-** |  **71.74 KB** |       **18.07** |
| BuilderLatestOnly | MorningDojiStar | 1000  |  94.45 μs |  6.290 μs |  3.743 μs |  2.48 |    0.11 |  0.9766 |       - |  23.86 KB |        6.01 |
| NativeSingle      | MorningDojiStar | 1000  |  38.07 μs |  1.307 μs |  0.864 μs |  1.00 |    0.03 |       - |       - |   3.97 KB |        1.00 |
| NativeParallel    | MorningDojiStar | 1000  |  86.55 μs |  2.059 μs |  1.362 μs |  2.27 |    0.06 |  0.4883 |       - |   8.39 KB |        2.11 |
|                   |                 |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **MorningDojiStar** | **10000** | **341.89 μs** | **26.323 μs** | **17.411 μs** |  **0.77** |    **0.04** | **35.1563** | **13.6719** | **583.51 KB** |       **14.91** |
| BuilderLatestOnly | MorningDojiStar | 10000 | 321.49 μs | 14.813 μs |  9.798 μs |  0.72 |    0.03 |  5.8594 |       - |  113.4 KB |        2.90 |
| NativeSingle      | MorningDojiStar | 10000 | 446.31 μs | 22.397 μs | 14.814 μs |  1.00 |    0.04 |       - |       - |  39.14 KB |        1.00 |
| NativeParallel    | MorningDojiStar | 10000 | 300.93 μs | 17.279 μs | 11.429 μs |  0.67 |    0.03 |  5.8594 |       - |  78.72 KB |        2.01 |
