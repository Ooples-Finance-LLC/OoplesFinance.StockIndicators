```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=20000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)iStar [29]** |  **52.30 μs** | **13.085 μs** | **7.787 μs** |  **1.02** |    **0.19** |  **72.61 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)iStar [29] |  61.90 μs |  0.751 μs | 0.393 μs |  1.20 |    0.14 |  17.28 KB |        0.24 |
|            |       |                      |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)iStar [29]** | **342.63 μs** | **14.263 μs** | **8.488 μs** |  **1.00** |    **0.03** | **662.48 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)iStar [29] | 605.04 μs |  3.934 μs | 2.058 μs |  1.77 |    0.04 | 123.13 KB |        0.19 |
