```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean     | Error    | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |---------:|---------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **EveningDojiStar** | **1000**  | **126.9 μs** | **13.74 μs** | **9.09 μs** |  **3.9063** |       **-** |  **71.31 KB** |
| BuilderLatestOnly | EveningDojiStar | 1000  | 107.0 μs |  1.88 μs | 0.98 μs |  0.9766 |       - |  23.39 KB |
| **BuilderFull**       | **EveningDojiStar** | **10000** | **382.0 μs** |  **6.62 μs** | **3.46 μs** | **35.1563** | **11.7188** | **583.95 KB** |
| BuilderLatestOnly | EveningDojiStar | 10000 | 391.7 μs | 10.45 μs | 5.47 μs |  3.9063 |       - | 113.89 KB |
