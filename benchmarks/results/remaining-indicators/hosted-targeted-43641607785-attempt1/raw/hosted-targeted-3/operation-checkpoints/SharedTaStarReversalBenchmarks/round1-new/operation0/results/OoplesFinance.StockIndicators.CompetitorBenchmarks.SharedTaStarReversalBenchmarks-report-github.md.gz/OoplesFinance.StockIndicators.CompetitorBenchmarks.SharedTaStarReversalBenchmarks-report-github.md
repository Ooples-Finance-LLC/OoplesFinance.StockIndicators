```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **EveningDojiStar** | **1000**  | **121.2 μs** | **17.65 μs** | **11.67 μs** |  **3.9063** |       **-** |  **71.23 KB** |
| BuilderLatestOnly | EveningDojiStar | 1000  | 108.6 μs |  2.55 μs |  1.34 μs |  0.9766 |       - |  23.39 KB |
| **BuilderFull**       | **EveningDojiStar** | **10000** | **393.4 μs** |  **6.43 μs** |  **3.37 μs** | **35.1563** | **11.7188** | **583.95 KB** |
| BuilderLatestOnly | EveningDojiStar | 10000 | 391.1 μs | 29.28 μs | 19.37 μs |  5.8594 |       - | 113.87 KB |
