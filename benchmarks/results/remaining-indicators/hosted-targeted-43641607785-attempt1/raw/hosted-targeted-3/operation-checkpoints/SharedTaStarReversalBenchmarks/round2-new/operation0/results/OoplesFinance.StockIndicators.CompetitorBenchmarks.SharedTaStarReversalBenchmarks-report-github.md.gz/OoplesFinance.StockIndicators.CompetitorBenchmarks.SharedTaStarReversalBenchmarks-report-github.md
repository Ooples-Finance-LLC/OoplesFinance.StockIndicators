```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |---------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **EveningDojiStar** | **1000**  | **125.86 μs** | **21.239 μs** | **14.048 μs** |  **2.48** |    **0.26** |  **3.9063** |       **-** |  **71.27 KB** |       **17.94** |
| BuilderLatestOnly | EveningDojiStar | 1000  | 106.48 μs |  1.380 μs |  0.722 μs |  2.09 |    0.02 |  0.9766 |       - |  23.39 KB |        5.89 |
| NativeSingle      | EveningDojiStar | 1000  |  50.84 μs |  0.507 μs |  0.265 μs |  1.00 |    0.01 |       - |       - |   3.97 KB |        1.00 |
| NativeParallel    | EveningDojiStar | 1000  | 103.05 μs |  5.012 μs |  2.983 μs |  2.03 |    0.06 |       - |       - |    8.4 KB |        2.11 |
|                   |                 |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **EveningDojiStar** | **10000** | **406.12 μs** | **19.481 μs** | **10.189 μs** |  **0.77** |    **0.02** | **35.1563** | **11.7188** | **583.96 KB** |       **14.92** |
| BuilderLatestOnly | EveningDojiStar | 10000 | 394.65 μs | 19.106 μs | 11.369 μs |  0.75 |    0.03 |  3.9063 |       - | 113.89 KB |        2.91 |
| NativeSingle      | EveningDojiStar | 10000 | 528.93 μs | 16.402 μs | 10.849 μs |  1.00 |    0.03 |       - |       - |  39.15 KB |        1.00 |
| NativeParallel    | EveningDojiStar | 10000 | 354.72 μs | 21.345 μs | 14.118 μs |  0.67 |    0.03 |  5.8594 |       - |  78.72 KB |        2.01 |
