```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation     | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |-------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **AbandonedBaby** | **1000**  |  **84.18 μs** |  **2.525 μs** |  **1.670 μs** |  **1.60** |    **0.03** |  **2.9297** |       **-** |  **57.21 KB** |       **14.40** |
| BuilderLatestOnly | AbandonedBaby | 1000  |  80.43 μs |  0.855 μs |  0.509 μs |  1.53 |    0.01 |  0.4883 |       - |   9.33 KB |        2.35 |
| NativeSingle      | AbandonedBaby | 1000  |  52.58 μs |  0.154 μs |  0.092 μs |  1.00 |    0.00 |       - |       - |   3.97 KB |        1.00 |
| NativeParallel    | AbandonedBaby | 1000  | 102.23 μs |  1.285 μs |  0.672 μs |  1.94 |    0.01 |       - |       - |    8.4 KB |        2.11 |
|                   |               |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **AbandonedBaby** | **10000** | **133.76 μs** |  **0.805 μs** |  **0.421 μs** |  **0.25** |    **0.00** | **33.2031** | **11.7188** | **553.04 KB** |       **14.13** |
| BuilderLatestOnly | AbandonedBaby | 10000 | 118.54 μs |  2.738 μs |  1.629 μs |  0.22 |    0.00 |  4.8828 |       - |  82.93 KB |        2.12 |
| NativeSingle      | AbandonedBaby | 10000 | 544.30 μs | 10.528 μs |  6.265 μs |  1.00 |    0.02 |       - |       - |  39.15 KB |        1.00 |
| NativeParallel    | AbandonedBaby | 10000 | 368.50 μs | 27.558 μs | 18.228 μs |  0.68 |    0.03 |  5.8594 |       - |  78.72 KB |        2.01 |
