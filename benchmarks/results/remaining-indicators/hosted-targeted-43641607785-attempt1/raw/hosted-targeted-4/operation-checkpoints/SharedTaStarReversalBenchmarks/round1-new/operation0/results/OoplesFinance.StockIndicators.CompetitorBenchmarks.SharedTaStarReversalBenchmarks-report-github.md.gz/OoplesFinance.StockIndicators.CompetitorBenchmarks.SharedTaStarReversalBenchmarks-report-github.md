```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation     | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |-------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **AbandonedBaby** | **1000**  |  **84.40 μs** | **2.229 μs** | **1.475 μs** |  **2.9297** |       **-** |  **57.21 KB** |
| BuilderLatestOnly | AbandonedBaby | 1000  |  80.72 μs | 1.382 μs | 0.914 μs |  0.4883 |       - |   9.33 KB |
| **BuilderFull**       | **AbandonedBaby** | **10000** | **135.41 μs** | **6.593 μs** | **3.924 μs** | **33.2031** | **10.7422** | **553.03 KB** |
| BuilderLatestOnly | AbandonedBaby | 10000 | 119.67 μs | 5.255 μs | 3.476 μs |  4.8828 |  0.9766 |  82.92 KB |
