```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=20000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dBaby [27]** |  **22.02 μs** |  **5.698 μs** |  **3.391 μs** |  **1.02** |    **0.20** |  **65.11 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dBaby [27] |  62.66 μs |  0.351 μs |  0.209 μs |  2.90 |    0.36 |  17.61 KB |        0.27 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)dBaby [27]** | **102.52 μs** | **12.950 μs** |  **7.706 μs** |  **1.00** |    **0.10** | **638.06 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dBaby [27] | 629.00 μs | 23.240 μs | 15.372 μs |  6.16 |    0.43 | 122.75 KB |        0.19 |
