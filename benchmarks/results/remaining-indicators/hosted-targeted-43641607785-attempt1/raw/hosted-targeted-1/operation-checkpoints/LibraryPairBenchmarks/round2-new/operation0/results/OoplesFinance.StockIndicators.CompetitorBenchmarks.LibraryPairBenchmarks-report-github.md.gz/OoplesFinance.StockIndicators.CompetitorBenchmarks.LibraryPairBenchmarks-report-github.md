```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=20000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)gStar [25]** |  **65.44 μs** |  **6.460 μs** |  **3.379 μs** |  **1.00** |    **0.07** |  **73.59 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)gStar [25] |  71.56 μs |  4.080 μs |  2.428 μs |  1.10 |    0.06 |  19.25 KB |        0.26 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)gStar [25]** | **377.48 μs** | **26.753 μs** | **15.920 μs** |  **1.00** |    **0.06** | **683.95 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)gStar [25] | 700.00 μs |  4.963 μs |  2.953 μs |  1.86 |    0.07 | 125.38 KB |        0.18 |
