```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=20000  

```
| Method | Bars  | PairId               | Mean      | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |----------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)gStar [25]** |  **82.40 μs** |   **7.476 μs** |   **4.449 μs** |  **1.00** |    **0.07** |  **73.59 KB** |        **1.00** |
|        |       |                      |           |            |            |       |         |           |             |
| **Ooples** | **10000** | **TaLib(...)gStar [25]** | **559.33 μs** | **205.755 μs** | **122.441 μs** |  **1.05** |    **0.34** | **684.55 KB** |        **1.00** |
