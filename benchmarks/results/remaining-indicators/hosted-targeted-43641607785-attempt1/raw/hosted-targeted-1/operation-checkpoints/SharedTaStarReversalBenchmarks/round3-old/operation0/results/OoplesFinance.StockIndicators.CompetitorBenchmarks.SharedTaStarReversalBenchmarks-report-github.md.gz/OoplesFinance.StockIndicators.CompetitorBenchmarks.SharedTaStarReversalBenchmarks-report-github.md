```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean     | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |------------ |------ |---------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **EveningStar** | **1000**  | **154.4 μs** | **21.24 μs** | **14.05 μs** |  **3.9063** |      **-** |  **69.48 KB** |
| BuilderLatestOnly | EveningStar | 1000  | 125.9 μs |  5.98 μs |  3.96 μs |  0.9766 |      - |   21.6 KB |
| **BuilderFull**       | **EveningStar** | **10000** | **429.8 μs** |  **5.95 μs** |  **3.11 μs** | **31.2500** | **7.8125** | **602.39 KB** |
| BuilderLatestOnly | EveningStar | 10000 | 445.3 μs | 44.93 μs | 26.74 μs |  7.8125 |      - | 132.26 KB |
