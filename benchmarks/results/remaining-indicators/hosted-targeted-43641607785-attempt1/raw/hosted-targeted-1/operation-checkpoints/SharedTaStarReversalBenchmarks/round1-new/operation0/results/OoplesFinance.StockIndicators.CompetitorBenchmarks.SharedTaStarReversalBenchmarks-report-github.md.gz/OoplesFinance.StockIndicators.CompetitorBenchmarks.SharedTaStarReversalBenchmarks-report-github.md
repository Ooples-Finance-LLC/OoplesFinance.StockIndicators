```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean     | Error     | StdDev    | Median   | Gen0    | Gen1    | Allocated |
|------------------ |------------ |------ |---------:|----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **EveningStar** | **1000**  | **229.2 μs** | **173.47 μs** | **114.74 μs** | **168.4 μs** |  **3.9063** |       **-** |  **69.52 KB** |
| BuilderLatestOnly | EveningStar | 1000  | 123.3 μs |   2.11 μs |   1.10 μs | 123.0 μs |  0.9766 |       - |   21.6 KB |
| **BuilderFull**       | **EveningStar** | **10000** | **439.0 μs** |  **29.90 μs** |  **17.79 μs** | **430.0 μs** | **35.1563** | **11.7188** | **602.33 KB** |
| BuilderLatestOnly | EveningStar | 10000 | 421.0 μs |   6.24 μs |   3.27 μs | 419.2 μs |  7.8125 |       - | 132.26 KB |
