```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------ |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **EveningStar** | **1000**  | **155.3 μs** | **23.12 μs** | **15.29 μs** |  **3.9063** |       **-** |  **69.48 KB** |
| BuilderLatestOnly | EveningStar | 1000  | 123.6 μs |  5.99 μs |  3.96 μs |  0.9766 |       - |   21.6 KB |
| **BuilderFull**       | **EveningStar** | **10000** | **462.3 μs** | **72.93 μs** | **48.24 μs** | **35.1563** | **11.7188** | **602.36 KB** |
| BuilderLatestOnly | EveningStar | 10000 | 453.1 μs | 77.98 μs | 51.58 μs |  7.8125 |       - | 132.26 KB |
