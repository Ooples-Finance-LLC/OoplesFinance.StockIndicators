```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------ |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **EveningStar** | **1000**  | **154.17 μs** | **29.696 μs** | **19.642 μs** |  **2.61** |    **0.32** |  **3.9063** |       **-** |  **69.52 KB** |       **17.50** |
| BuilderLatestOnly | EveningStar | 1000  | 125.84 μs |  4.730 μs |  2.474 μs |  2.13 |    0.04 |  0.9766 |       - |   21.6 KB |        5.44 |
| NativeSingle      | EveningStar | 1000  |  59.15 μs |  0.397 μs |  0.208 μs |  1.00 |    0.00 |       - |       - |   3.97 KB |        1.00 |
| NativeParallel    | EveningStar | 1000  | 121.10 μs |  1.575 μs |  0.824 μs |  2.05 |    0.01 |       - |       - |    8.4 KB |        2.11 |
|                   |             |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **EveningStar** | **10000** | **436.40 μs** |  **9.780 μs** |  **5.115 μs** |  **0.73** |    **0.01** | **35.1563** | **11.7188** | **602.36 KB** |       **15.38** |
| BuilderLatestOnly | EveningStar | 10000 | 420.55 μs |  9.932 μs |  5.195 μs |  0.70 |    0.01 |  7.8125 |       - | 132.26 KB |        3.38 |
| NativeSingle      | EveningStar | 10000 | 601.21 μs |  3.069 μs |  2.030 μs |  1.00 |    0.00 |       - |       - |  39.16 KB |        1.00 |
| NativeParallel    | EveningStar | 10000 | 418.38 μs | 50.173 μs | 29.857 μs |  0.70 |    0.05 |  3.9063 |       - |  78.73 KB |        2.01 |
