```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------------ |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **MorningStar** | **1000**  | **101.75 μs** |  **3.669 μs** |  **2.184 μs** |  **3.9063** |       **-** |  **69.48 KB** |
| BuilderLatestOnly | MorningStar | 1000  |  98.48 μs |  1.702 μs |  0.890 μs |  0.9766 |       - |   21.6 KB |
| **BuilderFull**       | **MorningStar** | **10000** | **350.68 μs** | **21.126 μs** | **11.049 μs** | **35.1563** | **17.5781** | **607.03 KB** |
| BuilderLatestOnly | MorningStar | 10000 | 325.68 μs | 30.385 μs | 18.081 μs |  7.8125 |       - | 136.94 KB |
