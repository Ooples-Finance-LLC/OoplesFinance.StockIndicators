```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------ |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **MorningStar** | **1000**  | **106.28 μs** |  **6.705 μs** |  **4.435 μs** |  **2.13** |    **0.08** |  **3.9063** |       **-** |  **69.45 KB** |       **17.49** |
| BuilderLatestOnly | MorningStar | 1000  | 100.63 μs |  4.813 μs |  2.864 μs |  2.01 |    0.05 |  0.9766 |       - |   21.6 KB |        5.44 |
| NativeSingle      | MorningStar | 1000  |  49.95 μs |  0.068 μs |  0.036 μs |  1.00 |    0.00 |       - |       - |   3.97 KB |        1.00 |
| NativeParallel    | MorningStar | 1000  | 104.31 μs |  7.791 μs |  5.153 μs |  2.09 |    0.10 |       - |       - |    8.4 KB |        2.11 |
|                   |             |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **MorningStar** | **10000** | **361.80 μs** | **25.166 μs** | **16.646 μs** |  **0.67** |    **0.04** | **35.1563** | **17.5781** |    **607 KB** |       **15.50** |
| BuilderLatestOnly | MorningStar | 10000 | 325.19 μs | 23.342 μs | 15.439 μs |  0.60 |    0.04 |  7.8125 |       - | 136.93 KB |        3.50 |
| NativeSingle      | MorningStar | 10000 | 539.22 μs | 34.654 μs | 22.921 μs |  1.00 |    0.06 |       - |       - |  39.15 KB |        1.00 |
| NativeParallel    | MorningStar | 10000 | 353.24 μs | 38.755 μs | 23.062 μs |  0.66 |    0.05 |  3.9063 |       - |  78.73 KB |        2.01 |
