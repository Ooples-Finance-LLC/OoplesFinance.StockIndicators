```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=20000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)gStar [25]** |  **43.92 μs** |  **1.647 μs** |  **0.861 μs** |  **1.00** |    **0.03** |  **73.59 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)gStar [25] |  62.00 μs |  0.785 μs |  0.411 μs |  1.41 |    0.03 |   14.7 KB |        0.20 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)gStar [25]** | **281.99 μs** | **16.265 μs** |  **9.679 μs** |  **1.00** |    **0.05** | **688.63 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)gStar [25] | 692.84 μs | 23.381 μs | 15.465 μs |  2.46 |    0.09 | 118.58 KB |        0.17 |
