```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |   **465.0 μs** |  **3.13 μs** |  **1.64 μs** |       **-** |  **104.99 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |   445.2 μs |  3.89 μs |  2.32 μs |       - |   57.41 KB |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** | **4,614.0 μs** | **35.50 μs** | **23.48 μs** | **31.2500** | **1019.66 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 | 4,521.6 μs | 72.11 μs | 42.91 μs |       - |  549.83 KB |
