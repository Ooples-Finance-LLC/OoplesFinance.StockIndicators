```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |   **461.6 μs** |  **9.49 μs** |  **5.65 μs** |       **-** |  **104.99 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |   453.2 μs |  3.94 μs |  2.06 μs |       - |   57.41 KB |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** | **4,606.3 μs** | **52.02 μs** | **27.21 μs** | **31.2500** | **1019.67 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 | 4,573.8 μs | 33.29 μs | 22.02 μs |       - |  549.82 KB |
