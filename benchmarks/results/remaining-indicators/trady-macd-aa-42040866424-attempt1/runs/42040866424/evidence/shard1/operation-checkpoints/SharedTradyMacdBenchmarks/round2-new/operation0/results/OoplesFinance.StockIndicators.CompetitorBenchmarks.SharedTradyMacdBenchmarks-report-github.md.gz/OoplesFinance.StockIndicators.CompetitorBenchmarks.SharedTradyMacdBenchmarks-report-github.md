```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |    **472.2 μs** |     **3.73 μs** |     **1.95 μs** |  **0.23** |    **0.00** |         **-** |         **-** |         **-** |   **104.99 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |    458.7 μs |     3.82 μs |     2.00 μs |  0.22 |    0.00 |         - |         - |         - |    57.41 KB |        0.02 |
| NativeSingle      | Movin(...)gence [34] | 1000  |  2,056.5 μs |    42.71 μs |    25.42 μs |  1.00 |    0.02 |  140.6250 |   93.7500 |   46.8750 |  3232.15 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 1000  |  1,851.9 μs |    35.86 μs |    18.76 μs |  0.90 |    0.01 |  234.3750 |  109.3750 |         - |  5670.92 KB |        1.75 |
|                   |                      |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** |  **4,756.6 μs** |    **25.02 μs** |    **16.55 μs** |  **0.19** |    **0.01** |   **31.2500** |         **-** |         **-** |  **1019.66 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 |  4,601.2 μs |    41.97 μs |    21.95 μs |  0.18 |    0.01 |         - |         - |         - |   549.83 KB |        0.02 |
| NativeSingle      | Movin(...)gence [34] | 10000 | 25,174.7 μs | 1,823.40 μs |   953.67 μs |  1.00 |    0.05 | 1750.0000 | 1500.0000 | 1250.0000 | 31914.92 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 10000 | 28,020.7 μs | 3,707.64 μs | 2,452.37 μs |  1.11 |    0.10 | 2500.0000 | 1750.0000 | 1250.0000 | 56067.61 KB |        1.76 |
