```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-----------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)gence [50]** |    **796.5 μs** |   **134.6 μs** |  **89.05 μs** |  **1.01** |    **0.16** |         **-** |         **-** |         **-** |    **290.1 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)gence [50] |  2,853.9 μs |   554.6 μs | 366.86 μs |  3.63 |    0.61 |         - |         - |         - |  3521.46 KB |       12.14 |
|            |       |                      |             |            |           |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)gence [50]** |  **7,695.7 μs** | **1,086.9 μs** | **718.92 μs** |  **1.01** |    **0.13** |         **-** |         **-** |         **-** |  **2857.19 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)gence [50] | 27,428.1 μs | 1,001.8 μs | 662.65 μs |  3.59 |    0.33 | 2000.0000 | 1000.0000 | 1000.0000 | 34696.11 KB |       12.14 |
