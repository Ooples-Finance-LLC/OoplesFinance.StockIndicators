"""Retain complete approved diagnostic artifacts and independently verify them."""
import io,json,subprocess,sys,time,zipfile
from pathlib import Path

r=Path(__file__).parent
repo=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-trady-macd-aa-diagnostic-20261105')
run=sys.argv[1]
once='--once' in sys.argv
root=r/'hosted-runs'/run
root.mkdir(parents=True,exist_ok=True)
def gh(*args):
    return subprocess.check_output(['gh',*args],cwd=repo)
previous=None
while True:
    state=json.loads(gh('run','view',run,'--json','status,conclusion,jobs'))
    active=[(j['name'],j['status'],j['conclusion']) for j in state['jobs'] if j['status']!='completed' or j['conclusion']=='failure']
    if active!=previous: print(run,active,flush=True);previous=active
    artifacts=json.loads(gh('api',f'repos/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/{run}/artifacts'))['artifacts']
    for artifact in artifacts:
        name=artifact['name']
        folders={'aa-input-verification':root/name,'trady-macd-aa-0':root/'evidence/shard0',
                 'trady-macd-aa-1':root/'evidence/shard1','trady-macd-aa-verified':root/name}
        if name not in folders: continue
        marker=root/(name+'.artifact.json')
        if marker.exists(): continue
        folder=folders[name];folder.mkdir(parents=True,exist_ok=True)
        raw=gh('api',f"repos/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/artifacts/{artifact['id']}/zip")
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            assert all((folder/p).resolve().is_relative_to(folder.resolve()) for p in z.namelist())
            z.extractall(folder)
        marker.write_text(json.dumps(artifact,indent=2)+'\n')
        print(run,'downloaded',name,flush=True)
    if state['status']=='completed':
        (root/'run.json').write_text(json.dumps(state,indent=2)+'\n')
        assert state['conclusion']=='success','Diagnostic failed; partial evidence retained, no pooling or automatic new preparation'
        output=root/'verified-aa-local.json'
        subprocess.run([sys.executable,'scripts/run-trady-macd-aa-diagnostic.py','collect',
            '--inputs',str(r/'hosted-runs/41988339055/hosted-inputs'),
            '--evidence',str(root/'evidence'),'--out',str(output)],cwd=repo,check=True)
        hosted=root/'trady-macd-aa-verified/aa-verified.json'
        assert json.loads(output.read_text())==json.loads(hosted.read_text())
        print(run,'COMPLETE LOCAL/HOSTED DIAGNOSTIC EQUALITY VERIFIED',flush=True)
        break
    if once: break
    time.sleep(30)
