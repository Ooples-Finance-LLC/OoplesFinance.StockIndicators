```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)River [30]** | **104.20 μs** | **21.058 μs** | **12.531 μs** |  **1.01** |    **0.15** |  **68.66 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)River [30] |  59.84 μs | 16.796 μs | 11.109 μs |  0.58 |    0.12 |  18.64 KB |        0.27 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)River [30]** | **161.19 μs** | **14.984 μs** |  **8.917 μs** |  **1.00** |    **0.07** | **639.28 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)River [30] | 531.49 μs |  9.385 μs |  5.585 μs |  3.31 |    0.17 | 125.38 KB |        0.20 |
