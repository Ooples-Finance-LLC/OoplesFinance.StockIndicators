```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nside [25]** | **412.65 μs** | **20.186 μs** | **13.352 μs** |  **1.00** |    **0.04** |  **68.66 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nside [25] |  59.37 μs |  1.143 μs |  0.680 μs |  0.14 |    0.00 |  19.63 KB |        0.29 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)nside [25]** | **507.36 μs** | **17.450 μs** | **10.384 μs** |  **1.00** |    **0.03** | **639.28 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nside [25] | 607.79 μs | 28.696 μs | 18.981 μs |  1.20 |    0.04 | 122.42 KB |        0.19 |
