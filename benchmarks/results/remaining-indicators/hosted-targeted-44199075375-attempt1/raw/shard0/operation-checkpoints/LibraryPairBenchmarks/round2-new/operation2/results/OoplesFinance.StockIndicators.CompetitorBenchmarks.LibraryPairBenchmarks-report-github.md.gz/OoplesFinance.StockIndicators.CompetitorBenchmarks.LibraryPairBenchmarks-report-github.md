```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Crows [31]** |  **63.83 μs** | **16.290 μs** | **10.775 μs** |  **1.02** |    **0.22** |  **65.13 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Crows [31] |  49.12 μs |  2.930 μs |  1.532 μs |  0.79 |    0.11 |  19.91 KB |        0.31 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Crows [31]** | **122.69 μs** | **24.873 μs** | **13.009 μs** |  **1.01** |    **0.14** | **637.52 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Crows [31] | 513.59 μs | 19.780 μs | 13.084 μs |  4.23 |    0.44 | 124.72 KB |        0.20 |
