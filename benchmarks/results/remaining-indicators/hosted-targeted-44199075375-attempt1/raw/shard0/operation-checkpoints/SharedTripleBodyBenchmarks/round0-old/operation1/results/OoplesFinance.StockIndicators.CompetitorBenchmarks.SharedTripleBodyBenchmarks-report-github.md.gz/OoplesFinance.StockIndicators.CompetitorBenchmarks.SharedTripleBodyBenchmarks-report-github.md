```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)Crows [22]** | **1000**  | **142.9 μs** | **20.02 μs** | **13.24 μs** |  **3.9063** |       **-** |  **64.25 KB** |
| BuilderLatestOnly | TaLib(...)Crows [22] | 1000  | 128.0 μs |  1.71 μs |  0.89 μs |  0.9766 |       - |  16.38 KB |
| **BuilderFull**       | **TaLib(...)Crows [22]** | **10000** | **510.6 μs** | **35.33 μs** | **23.37 μs** | **31.2500** | **11.7188** | **556.82 KB** |
| BuilderLatestOnly | TaLib(...)Crows [22] | 10000 | 490.8 μs | 11.77 μs |  6.16 μs |  3.9063 |       - |  86.71 KB |
