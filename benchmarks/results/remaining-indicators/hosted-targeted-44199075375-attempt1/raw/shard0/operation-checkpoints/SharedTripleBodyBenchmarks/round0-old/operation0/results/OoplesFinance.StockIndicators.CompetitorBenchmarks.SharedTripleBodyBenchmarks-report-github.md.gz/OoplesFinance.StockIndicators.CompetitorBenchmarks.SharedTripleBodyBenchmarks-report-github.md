```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nside [25]** | **1000**  | **149.7 μs** | **22.78 μs** | **15.07 μs** |  **3.9063** |       **-** |  **64.25 KB** |
| BuilderLatestOnly | TaLib(...)nside [25] | 1000  | 133.3 μs |  6.63 μs |  3.95 μs |  0.9766 |       - |  16.38 KB |
| **BuilderFull**       | **TaLib(...)nside [25]** | **10000** | **556.0 μs** | **48.07 μs** | **31.80 μs** | **31.2500** | **11.7188** | **556.82 KB** |
| BuilderLatestOnly | TaLib(...)nside [25] | 10000 | 545.0 μs | 51.71 μs | 34.20 μs |  3.9063 |       - |  86.71 KB |
