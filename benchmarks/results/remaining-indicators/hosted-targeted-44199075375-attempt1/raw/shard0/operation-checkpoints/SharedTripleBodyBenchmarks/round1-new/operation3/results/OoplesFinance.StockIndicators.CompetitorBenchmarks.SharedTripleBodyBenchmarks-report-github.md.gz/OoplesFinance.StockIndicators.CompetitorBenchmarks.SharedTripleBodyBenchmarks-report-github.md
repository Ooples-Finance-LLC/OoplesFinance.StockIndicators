```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)River [30]** | **1000**  | **107.5 μs** |  **5.45 μs** |  **3.61 μs** |  **2.9297** |       **-** |  **62.49 KB** |
| BuilderLatestOnly | TaLib(...)River [30] | 1000  | 100.6 μs |  2.40 μs |  1.26 μs |       - |       - |  14.61 KB |
| **BuilderFull**       | **TaLib(...)River [30]** | **10000** | **284.5 μs** | **20.98 μs** | **12.48 μs** | **33.2031** | **13.6719** |  **556.8 KB** |
| BuilderLatestOnly | TaLib(...)River [30] | 10000 | 275.4 μs | 25.45 μs | 16.84 μs |  3.9063 |       - |   86.7 KB |
