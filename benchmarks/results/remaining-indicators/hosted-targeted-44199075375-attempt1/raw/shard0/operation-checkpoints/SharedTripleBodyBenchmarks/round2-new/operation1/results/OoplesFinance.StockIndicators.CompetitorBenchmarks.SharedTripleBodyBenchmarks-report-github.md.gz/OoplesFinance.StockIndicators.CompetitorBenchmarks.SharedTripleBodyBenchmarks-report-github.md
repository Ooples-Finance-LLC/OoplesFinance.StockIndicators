```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)Crows [22]** | **1000**  |  **24.46 μs** |  **0.109 μs** |  **0.065 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)Crows [22] | 1000  | 100.91 μs |  1.450 μs |  0.758 μs |  4.13 |    0.03 |       - |       - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib(...)Crows [22] | 1000  | 106.48 μs |  2.947 μs |  1.754 μs |  4.35 |    0.07 |  1.9531 |       - |   62.5 KB |       15.75 |
| BuilderLatestOnly | TaLib(...)Crows [22] | 1000  | 103.94 μs |  2.580 μs |  1.535 μs |  4.25 |    0.06 |       - |       - |  14.61 KB |        3.68 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)Crows [22]** | **10000** | **249.22 μs** |  **1.536 μs** |  **0.803 μs** |  **1.00** |    **0.00** |  **1.9531** |       **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib(...)Crows [22] | 10000 | 238.07 μs | 34.952 μs | 23.119 μs |  0.96 |    0.09 |  5.8594 |       - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib(...)Crows [22] | 10000 | 248.84 μs | 19.759 μs | 13.069 μs |  1.00 |    0.05 | 33.2031 | 13.6719 |  556.8 KB |       14.23 |
| BuilderLatestOnly | TaLib(...)Crows [22] | 10000 | 237.02 μs | 24.041 μs | 15.902 μs |  0.95 |    0.06 |  3.9063 |       - |   86.7 KB |        2.22 |
