```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nside [25]** | **1000**  | **147.7 μs** | **19.61 μs** | **12.97 μs** |  **3.9063** |       **-** |  **64.25 KB** |
| BuilderLatestOnly | TaLib(...)nside [25] | 1000  | 136.4 μs |  7.88 μs |  5.22 μs |  0.9766 |       - |  16.38 KB |
| **BuilderFull**       | **TaLib(...)nside [25]** | **10000** | **562.0 μs** | **53.07 μs** | **35.10 μs** | **31.2500** | **11.7188** | **556.82 KB** |
| BuilderLatestOnly | TaLib(...)nside [25] | 10000 | 529.6 μs | 16.54 μs |  8.65 μs |  3.9063 |       - |  86.71 KB |
