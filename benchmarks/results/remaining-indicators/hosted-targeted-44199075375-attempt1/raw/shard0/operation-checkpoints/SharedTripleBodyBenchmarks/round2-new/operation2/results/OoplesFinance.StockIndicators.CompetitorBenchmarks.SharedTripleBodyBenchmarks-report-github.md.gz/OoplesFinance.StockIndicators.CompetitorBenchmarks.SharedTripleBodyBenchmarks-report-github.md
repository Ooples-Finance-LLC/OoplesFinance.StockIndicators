```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)Crows [31]** | **1000**  |  **41.61 μs** |  **0.199 μs** |  **0.118 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)Crows [31] | 1000  | 112.09 μs |  3.573 μs |  2.363 μs |  2.69 |    0.05 |       - |       - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib(...)Crows [31] | 1000  | 104.65 μs |  2.704 μs |  1.609 μs |  2.52 |    0.04 |  1.9531 |       - |   62.5 KB |       15.75 |
| BuilderLatestOnly | TaLib(...)Crows [31] | 1000  | 102.78 μs |  4.203 μs |  2.780 μs |  2.47 |    0.06 |       - |       - |  14.61 KB |        3.68 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)Crows [31]** | **10000** | **417.97 μs** |  **2.399 μs** |  **1.255 μs** |  **1.00** |    **0.00** |       **-** |       **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)Crows [31] | 10000 | 318.76 μs | 21.519 μs | 14.233 μs |  0.76 |    0.03 |  5.8594 |       - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib(...)Crows [31] | 10000 | 249.16 μs |  6.380 μs |  3.337 μs |  0.60 |    0.01 | 33.2031 | 13.6719 |  556.8 KB |       14.22 |
| BuilderLatestOnly | TaLib(...)Crows [31] | 10000 | 236.14 μs |  7.651 μs |  4.002 μs |  0.56 |    0.01 |  3.9063 |       - |   86.7 KB |        2.21 |
