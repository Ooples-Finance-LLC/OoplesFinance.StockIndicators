```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)Crows [31]** | **1000**  | **111.4 μs** | **10.12 μs** |  **6.02 μs** |  **1.9531** |       **-** |  **62.49 KB** |
| BuilderLatestOnly | TaLib(...)Crows [31] | 1000  | 103.7 μs |  6.19 μs |  4.09 μs |       - |       - |  14.61 KB |
| **BuilderFull**       | **TaLib(...)Crows [31]** | **10000** | **259.6 μs** |  **5.00 μs** |  **2.61 μs** | **33.2031** | **13.6719** |  **556.8 KB** |
| BuilderLatestOnly | TaLib(...)Crows [31] | 10000 | 250.1 μs | 20.30 μs | 13.43 μs |  3.9063 |       - |   86.7 KB |
