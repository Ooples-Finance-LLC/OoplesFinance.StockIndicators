```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)River [30]** | **1000**  |  **43.45 μs** |  **1.622 μs** |  **0.965 μs** |  **1.00** |    **0.03** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)River [30] | 1000  | 110.53 μs |  1.249 μs |  0.654 μs |  2.55 |    0.05 |       - |       - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib(...)River [30] | 1000  | 105.19 μs |  2.118 μs |  1.260 μs |  2.42 |    0.06 |  2.9297 |       - |  62.49 KB |       15.75 |
| BuilderLatestOnly | TaLib(...)River [30] | 1000  | 100.62 μs |  2.451 μs |  1.458 μs |  2.32 |    0.06 |       - |       - |  14.61 KB |        3.68 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)River [30]** | **10000** | **434.75 μs** |  **2.947 μs** |  **1.542 μs** |  **1.00** |    **0.00** |       **-** |       **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)River [30] | 10000 | 324.00 μs | 21.380 μs | 12.723 μs |  0.75 |    0.03 |  5.8594 |       - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib(...)River [30] | 10000 | 281.42 μs |  9.100 μs |  4.759 μs |  0.65 |    0.01 | 33.2031 | 11.7188 |  556.8 KB |       14.22 |
| BuilderLatestOnly | TaLib(...)River [30] | 10000 | 272.31 μs | 23.242 μs | 13.831 μs |  0.63 |    0.03 |  3.9063 |       - |   86.7 KB |        2.21 |
