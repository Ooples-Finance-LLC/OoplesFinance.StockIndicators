```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)nside [25]** | **1000**  |  **43.97 μs** |  **0.310 μs** |  **0.162 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)nside [25] | 1000  | 113.76 μs |  4.223 μs |  2.793 μs |  2.59 |    0.06 |       - |       - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib(...)nside [25] | 1000  | 138.71 μs |  5.808 μs |  3.842 μs |  3.15 |    0.08 |  3.9063 |       - |  64.23 KB |       16.18 |
| BuilderLatestOnly | TaLib(...)nside [25] | 1000  | 137.28 μs | 13.385 μs |  8.853 μs |  3.12 |    0.19 |  0.9766 |       - |  16.38 KB |        4.13 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)nside [25]** | **10000** | **442.27 μs** |  **1.645 μs** |  **0.861 μs** |  **1.00** |    **0.00** |       **-** |       **-** |  **39.16 KB** |        **1.00** |
| NativeParallel    | TaLib(...)nside [25] | 10000 | 340.10 μs | 27.225 μs | 18.008 μs |  0.77 |    0.04 |  5.8594 |       - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib(...)nside [25] | 10000 | 564.45 μs | 61.731 μs | 40.831 μs |  1.28 |    0.09 | 31.2500 | 11.7188 | 556.79 KB |       14.22 |
| BuilderLatestOnly | TaLib(...)nside [25] | 10000 | 542.58 μs | 48.772 μs | 32.259 μs |  1.23 |    0.07 |  3.9063 |       - |  86.71 KB |        2.21 |
