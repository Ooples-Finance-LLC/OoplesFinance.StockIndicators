"""Stage the complete approved harness refresh; never claim source qualification."""
import gzip, hashlib, json, os, re, subprocess, sys
from pathlib import Path

ops=Path(__file__).parent
checkpoint=ops/'continuation-latest-20261028.json'
name='named-output-projection-refresh-20261116'
d=json.loads(checkpoint.read_text());q=d['performance_continuation_20261103'][name]
assert q['baseline_refresh_verified'] and q['local_hosted_collection_equal']
assert q['publication_if_verified_approved'] and not q['production_qualification']
assert (q['unit_passed'],q['comparator_passed'],q['gpu_passed'])==(37,84,100)
repo=Path(d['publishing_checkout']);tooling=Path(q['tooling_checkout'])
plan=tooling/'benchmarks/plans'/q['plan']
assert hashlib.sha256(plan.read_bytes()).hexdigest()==q['plan_sha256']
os.environ['HOSTED_TIMING_PLAN']=str(plan)
sys.path.insert(0,str(tooling/'scripts'))
from hosted_timing import pipeline as p, named_projection_refresh as refresh
from hosted_timing.archive import archive
from hosted_timing.report import stage
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
assert not subprocess.check_output(['git','diff',refresh.PUBLISHED,'HEAD','--','src','tests'],cwd=repo)
assert not subprocess.check_output(['git','diff',refresh.CANONICAL,'HEAD','--',p.BENCH,p.TESTS],cwd=repo)
raw=Path(q['raw_evidence']);inputs=Path(q['refresh_inputs'])
summary=refresh.collect(raw)
assert summary==p.read(Path(q['refresh_result']))
assert summary['baseline_refresh_verified'] and not summary['accepted']
destination=archive(raw,inputs,repo,'baseline-refresh')
live=Path('C:/Users/cheat/Documents/OoplesFinance-Reports/competitor-performance.html')
assert hashlib.sha256(live.read_bytes()).hexdigest()==d['report_sha256']
embedded=lambda path,key:json.loads(re.search(r'<script[^>]*id="'+key+r'"[^>]*>(.*?)</script>',path.read_text(encoding='utf-8'),re.S)[1])
out=ops/(name+'-report')
candidate=stage(live,raw,repo,out,phase='baseline-refresh',inputs=inputs)
staged=p.read(out/'staged.json')
assert (staged['changed_baseline_rows'],staged['changed_builder_slots'],staged['added_builder_slots'])==(16,0,0)
assert len(staged['builder_rows'])==1544
before=embedded(live,'dataset');after=embedded(candidate,'dataset')
assert embedded(live,'current-competitor-data')['receipts']==embedded(candidate,'current-competitor-data')['receipts']
changed=[row for row in after['rows'] if row['pair'] in refresh.PAIRS]
assert len(changed)==16
for row in changed:
    assert row['measurement_kind']=='harness-baseline-refresh' and not row['production_optimization']
    assert row['benchmark_source_sha']==refresh.HARNESS
    assert row['production_assembly_sha256']==q['production_sha256']
    assert row['source_sha']==row['canonical_gpu_source_sha']==refresh.CANONICAL
    assert len(row['native_round_classifications'])==4
delivery=out/'delivery-tooling';delivery.mkdir()
for filename in ('scripts/test_hosted_named_projection_refresh.py','benchmarks/plans/.gitattributes'):
    (delivery/('named-refresh-'+Path(filename).name)).write_bytes((tooling/filename).read_bytes())
for failure in q.get('superseded_preparation_runs',[]):
    assert failure['timing_cases']==0
    source_log=Path(failure['log'])
    (delivery/source_log.name).write_bytes(source_log.read_bytes())
(delivery/'superseded-preparation-runs.json').write_bytes((json.dumps(q.get('superseded_preparation_runs',[]),indent=2)+'\n').encode())
for relative in ('scripts/hosted_timing/report.py','scripts/hosted_timing/archive.py','scripts/test_hosted_report.py'):
    (delivery/Path(relative).name).write_bytes((tooling/relative).read_bytes())
for filename in ('stage-named-projection-refresh-20261116.py','import-named-projection-refresh-20261116.py',
                 'publish-named-projection-refresh-20261116.py','verify-hosted-certified-report-20261101.py',
                 'import-hosted-certified-report-20261101.py'):
    (delivery/filename).write_bytes((ops/filename).read_bytes())
p.write(delivery/'origin.json',dict(measurement_tooling=q['tooling_head'],delivery_tooling=subprocess.check_output(['git','rev-parse','HEAD'],cwd=tooling,text=True).strip(),plan_sha256=q['plan_sha256']))
with (out/'browser.log').open('wb') as log:
    subprocess.run(['python',str(ops/'verify-hosted-certified-report-20261101.py'),str(candidate),before['evidence']['baseSourceSha'],str(q['timing_run']),str(out)],stdout=log,stderr=subprocess.STDOUT,check=True)
verified=p.read(out/'browser-verification.json')
assert verified['comparisons']==verified['displayed_table_comparisons']==verified['exported_comparisons']==802
assert not verified['javascript_errors']
q.update(archive=str(destination),report_out=str(out),report_refresh_only=True,accepted=False,
    source_retention_verified=True,production_integrated=False,report_imported=False,
    delivery_tooling_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=tooling,text=True).strip(),
    status='Complete harness refresh staged and browser-verified; screenshot inspection then import/publication pending')
checkpoint.write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(dict(out=str(out),archive=str(destination),candidate_sha256=staged['candidate_sha256'])))
