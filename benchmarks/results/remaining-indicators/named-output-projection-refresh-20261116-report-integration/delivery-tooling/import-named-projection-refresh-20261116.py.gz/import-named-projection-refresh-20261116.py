"""Import after browser checks and human-agent screenshot inspection."""
import datetime,gzip,hashlib,json,re,subprocess
from pathlib import Path
ops=Path(__file__).parent;checkpoint=ops/'continuation-latest-20261028.json'
name='named-output-projection-refresh-20261116'
d=json.loads(checkpoint.read_text());q=d['performance_continuation_20261103'][name]
assert q['baseline_refresh_verified'] and q['report_visual_verified'] and not q['report_imported']
assert not q['accepted'] and not q['production_qualification'] and q['source_retention_verified']
out=Path(q['report_out']);repo=Path(d['publishing_checkout'])
with (out/'import.log').open('wb') as log:
    subprocess.run(['python',str(ops/'import-hosted-certified-report-20261101.py'),str(out)],stdout=log,stderr=subprocess.STDOUT,check=True)
imported=json.loads((out/'imported.json').read_text())
assert (imported['changed_baseline_rows'],imported['changed_builder_slots'],imported['unchanged_rows'])==(16,0,786)
live=Path('C:/Users/cheat/Documents/OoplesFinance-Reports/competitor-performance.html')
sha=hashlib.sha256(live.read_bytes()).hexdigest();assert sha==imported['candidate_sha256']
archive=repo/'benchmarks/results/remaining-indicators'/(name+'-report-integration');archive.mkdir()
(archive/'.gitattributes').write_bytes(b'* -text\n');manifest={}
for path in sorted(out.rglob('*')):
    if not path.is_file():continue
    content=path.read_bytes();target=archive/(path.relative_to(out).as_posix()+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(gzip.compress(content,mtime=0));assert gzip.decompress(target.read_bytes())==content
    manifest[path.relative_to(out).as_posix()]=dict(sha256=hashlib.sha256(content).hexdigest(),archive=target.relative_to(repo).as_posix())
(archive/'manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode('utf-8'))
decision_path=Path(q['archive'])/'decision.json';decision=json.loads(decision_path.read_text())
assert decision['baseline_refresh_verified'] and not decision['accepted'] and not decision['production_integrated']
decision.update(report_imported=True,report_sha256=sha,report_archive=archive.relative_to(repo).as_posix(),existing_production_retained=True)
decision_path.write_bytes((json.dumps(decision,indent=2)+'\n').encode('utf-8'))
rows=json.loads(re.search(r'<script[^>]*id="dataset"[^>]*>(.*?)</script>',live.read_text(encoding='utf-8'),re.S)[1])['rows']
wins={str(n):sum(r['bars']==n and r['competitor_over_ooples']>1 for r in rows) for n in (1000,10000)}
subprocess.run(['git','add','--sparse','benchmarks/results/remaining-indicators'],cwd=repo,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=repo,check=True)
subprocess.run(['git','commit','-m','perf: publish complete named-output harness baseline refresh evidence'],cwd=repo,check=True)
q.update(report_imported=True,report_sha256=sha,report_wins=wins,report_archive=str(archive),
    prepared_publication_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
    status='Complete harness baseline refresh imported and verified; draft publication pending')
checkpoint.write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(dict(report_sha256=sha,wins=wins,head=q['prepared_publication_head'])))
