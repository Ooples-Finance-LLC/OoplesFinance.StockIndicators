"""Publish only the independently completed approved harness/report batch to draft266."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

ops = Path(__file__).parent
checkpoint = ops/'continuation-latest-20261028.json'
name = 'named-output-projection-refresh-20261116'
data = json.loads(checkpoint.read_text())
q = data['performance_continuation_20261103'][name]
repo = Path(data['publishing_checkout'])
endpoint = 'repos/Ooples-Finance-LLC/OoplesFinance.StockIndicators/pulls/266'
def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo, text=True).strip()
assert q['publication_if_verified_approved'] and q['baseline_refresh_verified'] and q['local_hosted_collection_equal']
assert q['report_imported'] and q['report_visual_verified'] and q['source_retention_verified']
assert not q['accepted'] and not q['production_qualification'] and not q['production_integrated']
assert not git('status', '--porcelain')
head = git('rev-parse', 'HEAD')
assert head == q['prepared_publication_head']
assert not git('diff', q['baseline'], head, '--', 'src', 'tests')
assert not git('diff', q['source'], head, '--',
    'benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks',
    'benchmarks/OoplesFinance.StockIndicators.CompetitorTests')
assert git('ls-remote', 'origin', 'refs/heads/perf/remaining-indicator-rollout').split()[0] == q['baseline']
live = Path('C:/Users/cheat/Documents/OoplesFinance-Reports/competitor-performance.html')
assert hashlib.sha256(live.read_bytes()).hexdigest() == q['report_sha256']
imported = json.loads((Path(q['report_out'])/'imported.json').read_text())
assert imported['candidate_sha256'] == q['report_sha256']
assert (imported['changed_baseline_rows'], imported['changed_builder_slots']) == (16, 0)
assert sum(imported['verdicts'].values()) == 1544
proof = json.loads(Path(q['refresh_result']).read_text())
assert proof['baseline_refresh_verified'] and not proof['accepted'] and not proof['production_qualification']
assert (proof['case_count'], proof['decision_count']) == (80, 16)
assert proof['verdicts'] == q['verdicts']
pr = json.loads(subprocess.check_output(['gh', 'api', endpoint]))
assert pr['head']['sha'] == q['baseline'] and pr['draft'] and pr['auto_merge'] is None and pr['base']['ref'] == 'master'
marker = '### Complete named-output harness baseline refresh'
assert marker not in pr['body']
v = proof['verdicts']
native = proof['native_review']['confirmed_native_wins']
wins = q['report_wins']
section = f'''{marker}

Eight consumers across Awesome, Historical/Realized volatility, McGinley, Elder Ray and regression statistics now publish owned comparison columns directly from completed spans. Every required named column, output bit, presence flag and Full history is retained. Production algorithms are unchanged; this is a benchmark-harness baseline refresh.

Fresh canonical checks passed 37 history tests, 84 comparator tests and actual GPU100. The freshly rebuilt frozen harness passed 37 history tests, 97 comparator tests (including all 13 variant binding checks) and actual GPU100. The [complete measurement run](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/{q['timing_run']}) covered all 80 cases / 16 identical-binary A/A comparisons, both sizes, with at most two measurement runners. Existing 1,000 unmeasured batch warmups, ten measured iterations, default runtime and CPU gates were retained.

A/A outcomes: {v.get('faster',0)} faster, {v.get('slower',0)} slower, {v.get('inconclusive',0)} inconclusive. These describe timing variability and do not qualify production source. All four owned rounds were retained against one native control measured in round two: {native['1000']} confirmed native wins at 1,000 bars and {native['10000']} at 10,000 bars within these eight pairs. Mixed and inconclusive outcomes remain uncertain. Independent collection matched CI exactly.

All 16 affected report rows were refreshed with separate source, harness and GPU provenance. All 802 table/CSV comparisons and 1,544 unchanged builder comparisons were browser-verified, and screenshots inspected. Harness/report head: `{head[:9]}`. Publication CI is pending; overall performance work remains open.
'''
intro, history = pr['body'].split('\n\n', 1)
history, count = re.subn(r'The report shows \*\*.*?auto-merge disabled\.\s*', '', history, count=1, flags=re.S)
assert count == 1
report = f"The report shows **{wins['1000']}/401 wins at 1,000 bars and {wins['10000']}/401 at 10,000 bars**; {401-wins['10000']} batch gaps remain by point estimate at 10,000 bars. Work continues with this PR kept draft, targeting master, with auto-merge disabled."
payload = ops/('pr266-'+name+'-body.json')
payload.write_bytes((json.dumps(dict(body=intro+'\n\n'+section+'\n'+report+'\n\n'+history.rstrip()+'\n'))+'\n').encode())
subprocess.run(['git', 'push', 'origin', 'HEAD:refs/heads/perf/remaining-indicator-rollout'], cwd=repo, check=True)
q.update(published_head=head, fresh_publication_ci_status='running', pr_body_payload=str(payload),
    status='Complete named-output harness/report refresh published; publication CI pending')
data.update(published_head=head, local_head=head, working_tree='clean', report_sha256=q['report_sha256'],
    report_wins=wins, remaining_10000_bar_gaps=401-wins['10000'],
    updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), full_goal_complete=False,
    current_published_ci_pending=dict(head=head, reason=name))
data['builder_totals'].update(imported['verdicts'])
data['performance_continuation_20261103'].update(report_sha256=q['report_sha256'],
    remaining_gaps={size:401-count for size,count in wins.items()},
    remaining_10000_bar_gaps=401-wins['10000'], full_goal_complete=False)
if 'active_continuation_20261113' in data:
    data['active_continuation_20261113'].update(published_head=head, remaining_mean_based_10000_gaps=401-wins['10000'])
checkpoint.write_text(json.dumps(data, indent=2)+'\n')
for attempt in range(90):
    current = json.loads(subprocess.check_output(['gh', 'api', endpoint]))
    assert current['draft'] and current['auto_merge'] is None and current['base']['ref'] == 'master'
    checks = json.loads(subprocess.check_output(['gh', 'api', 'repos/Ooples-Finance-LLC/OoplesFinance.StockIndicators/commits/'+head+'/check-runs?per_page=100']))['check_runs']
    titles = [check for check in checks if check['name'] == 'Auto-Fix PR Title']
    if current['head']['sha'] == head and titles and all(check['status'] == 'completed' for check in titles):
        assert all(check['conclusion'] in ('success', 'skipped') for check in titles)
        break
    time.sleep(2)
else:
    raise RuntimeError('Published; metadata checks pending; prepared PR body not applied yet')
subprocess.run(['gh', 'api', endpoint, '--method', 'PATCH', '--input', str(payload), '--silent'], check=True)
print(head)
