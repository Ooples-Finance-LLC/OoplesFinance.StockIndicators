```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error      | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|-----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)lopes [22]** | **1000**  | **130.70 μs** |  **33.075 μs** | **21.877 μs** |  **3.9063** |       **-** |  **83.49 KB** |
| BuilderLatestOnly | Skend(...)lopes [22] | 1000  |  93.86 μs |   6.024 μs |  3.985 μs |  1.9531 |       - |  35.89 KB |
| **BuilderFull**       | **Skend(...)lopes [22]** | **10000** | **696.93 μs** | **112.103 μs** | **74.149 μs** | **46.8750** | **19.5313** | **787.01 KB** |
| BuilderLatestOnly | Skend(...)lopes [22] | 10000 | 658.19 μs |  70.798 μs | 46.829 μs | 15.6250 |  3.9063 | 317.17 KB |
