```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)lopes [22]** | **1000**  | **133.74 μs** | **29.902 μs** | **19.779 μs** |  **3.9063** |       **-** |  **83.69 KB** |
| BuilderLatestOnly | Skend(...)lopes [22] | 1000  |  81.28 μs |  5.327 μs |  3.170 μs |  1.9531 |       - |  36.04 KB |
| **BuilderFull**       | **Skend(...)lopes [22]** | **10000** | **617.60 μs** | **60.391 μs** | **39.945 μs** | **46.8750** | **19.5313** | **787.17 KB** |
| BuilderLatestOnly | Skend(...)lopes [22] | 10000 | 606.18 μs | 76.751 μs | 50.766 μs | 15.6250 |  3.9063 | 317.33 KB |
