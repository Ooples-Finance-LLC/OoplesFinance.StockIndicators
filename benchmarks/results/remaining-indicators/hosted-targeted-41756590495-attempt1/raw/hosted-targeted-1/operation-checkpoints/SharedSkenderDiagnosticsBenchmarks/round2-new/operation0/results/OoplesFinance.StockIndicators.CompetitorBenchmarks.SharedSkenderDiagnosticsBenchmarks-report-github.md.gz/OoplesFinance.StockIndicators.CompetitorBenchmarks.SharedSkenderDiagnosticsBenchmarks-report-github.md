```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)lopes [22]** | **1000**  |    **91.82 μs** |   **8.973 μs** |   **5.935 μs** |  **1.37** |    **0.09** |   **3.9063** |        **-** |        **-** |   **83.65 KB** |        **0.39** |
| BuilderLatestOnly | Skend(...)lopes [22] | 1000  |    87.05 μs |   4.473 μs |   2.959 μs |  1.30 |    0.04 |   1.9531 |        - |        - |   36.04 KB |        0.17 |
| NativeSingle      | Skend(...)lopes [22] | 1000  |    66.94 μs |   1.189 μs |   0.708 μs |  1.00 |    0.01 |  12.6953 |   1.9531 |        - |  211.88 KB |        1.00 |
| NativeParallel    | Skend(...)lopes [22] | 1000  |    46.23 μs |   3.138 μs |   1.867 μs |  0.69 |    0.03 |  15.1367 |   3.4180 |        - |  234.75 KB |        1.11 |
|                   |                      |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skend(...)lopes [22]** | **10000** |   **644.29 μs** |  **71.624 μs** |  **47.375 μs** |  **0.41** |    **0.05** |  **46.8750** |  **19.5313** |        **-** |  **787.17 KB** |        **0.37** |
| BuilderLatestOnly | Skend(...)lopes [22] | 10000 |   604.55 μs |  64.123 μs |  42.413 μs |  0.39 |    0.05 |  15.6250 |   3.9063 |        - |  317.33 KB |        0.15 |
| NativeSingle      | Skend(...)lopes [22] | 10000 | 1,578.46 μs | 273.281 μs | 162.625 μs |  1.01 |    0.14 | 250.0000 | 226.5625 | 164.0625 | 2112.62 KB |        1.00 |
| NativeParallel    | Skend(...)lopes [22] | 10000 |   511.89 μs |  39.203 μs |  25.930 μs |  0.33 |    0.04 | 140.6250 |  66.4063 |        - | 2203.53 KB |        1.04 |
