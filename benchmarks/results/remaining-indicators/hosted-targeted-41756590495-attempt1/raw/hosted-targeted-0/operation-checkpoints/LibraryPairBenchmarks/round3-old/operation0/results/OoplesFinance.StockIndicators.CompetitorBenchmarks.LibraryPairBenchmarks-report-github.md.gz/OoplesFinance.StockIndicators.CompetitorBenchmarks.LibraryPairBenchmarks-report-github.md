```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean     | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |---------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skend(...)lopes [22]** | **140.1 μs** |  **5.90 μs** |  **3.09 μs** |  **1.00** |    **0.03** |  **188.72 KB** |        **1.00** |
|        |       |                      |          |          |          |       |         |            |             |
| **Ooples** | **10000** | **Skend(...)lopes [22]** | **980.3 μs** | **28.39 μs** | **16.89 μs** |  **1.00** |    **0.02** | **1840.76 KB** |        **1.00** |
