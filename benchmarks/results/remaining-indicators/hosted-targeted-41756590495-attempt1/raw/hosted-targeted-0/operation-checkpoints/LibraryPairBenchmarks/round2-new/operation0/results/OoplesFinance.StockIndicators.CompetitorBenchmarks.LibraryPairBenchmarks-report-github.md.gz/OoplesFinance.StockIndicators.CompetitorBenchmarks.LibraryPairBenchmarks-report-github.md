```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)lopes [22]** | **146.52 μs** | **20.668 μs** | **13.670 μs** |  **1.01** |    **0.12** |  **188.84 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)lopes [22] |  83.76 μs |  3.319 μs |  1.975 μs |  0.58 |    0.05 |  285.56 KB |        1.51 |
|            |       |                      |           |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)lopes [22]** | **927.89 μs** | **28.441 μs** | **16.925 μs** |  **1.00** |    **0.02** | **1840.23 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)lopes [22] | 942.80 μs | 46.316 μs | 30.635 μs |  1.02 |    0.04 | 2771.18 KB |        1.51 |
