```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Sin** | **114.28 μs** | **26.623 μs** | **13.924 μs** |  **1.01** |    **0.15** |   **66.3 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Sin |  20.20 μs |  0.421 μs |  0.220 μs |  0.18 |    0.02 |  39.34 KB |        0.59 |
|            |       |                     |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Sin** | **109.36 μs** | **10.652 μs** |  **6.339 μs** |  **1.00** |    **0.08** | **645.66 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Sin | 190.28 μs |  3.045 μs |  1.593 μs |  1.74 |    0.09 | 328.06 KB |        0.51 |
