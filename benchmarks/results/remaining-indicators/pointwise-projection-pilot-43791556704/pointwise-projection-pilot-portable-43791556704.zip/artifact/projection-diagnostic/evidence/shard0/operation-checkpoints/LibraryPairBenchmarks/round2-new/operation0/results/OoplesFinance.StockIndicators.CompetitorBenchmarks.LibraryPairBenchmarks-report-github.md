```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean      | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Add** | **109.59 μs** | **9.920 μs** | **5.188 μs** |  **1.00** |    **0.06** |  **66.64 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Add |  11.12 μs | 0.602 μs | 0.315 μs |  0.10 |    0.01 |  37.32 KB |        0.56 |
|            |       |                     |           |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Add** |  **50.41 μs** | **2.544 μs** | **1.330 μs** |  **1.00** |    **0.04** | **646.27 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Add |  88.23 μs | 1.280 μs | 0.762 μs |  1.75 |    0.05 | 328.72 KB |        0.51 |
