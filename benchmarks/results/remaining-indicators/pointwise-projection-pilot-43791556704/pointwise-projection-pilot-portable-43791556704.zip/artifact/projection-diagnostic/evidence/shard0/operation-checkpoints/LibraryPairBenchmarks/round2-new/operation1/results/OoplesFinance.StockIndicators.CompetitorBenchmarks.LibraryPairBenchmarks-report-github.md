```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Floor [21]** | **112.50 μs** | **15.871 μs** | **9.444 μs** |  **1.01** |    **0.11** |   **66.3 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Floor [21] |  11.47 μs |  0.529 μs | 0.276 μs |  0.10 |    0.01 |  36.66 KB |        0.55 |
|            |       |                      |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Floor [21]** |  **70.10 μs** |  **4.386 μs** | **2.610 μs** |  **1.00** |    **0.05** | **645.35 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Floor [21] |  90.37 μs |  2.979 μs | 1.773 μs |  1.29 |    0.05 | 330.36 KB |        0.51 |
