```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)iLine [24]** | **190.44 μs** |  **5.237 μs** |  **2.739 μs** |  **1.00** |    **0.02** |  **65.36 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)iLine [24] |  39.96 μs |  0.728 μs |  0.433 μs |  0.21 |    0.00 |  16.95 KB |        0.26 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)iLine [24]** | **321.56 μs** |  **4.314 μs** |  **2.256 μs** |  **1.00** |    **0.01** | **632.09 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)iLine [24] | 415.08 μs | 16.755 μs | 11.082 μs |  1.29 |    0.03 | 122.14 KB |        0.19 |
