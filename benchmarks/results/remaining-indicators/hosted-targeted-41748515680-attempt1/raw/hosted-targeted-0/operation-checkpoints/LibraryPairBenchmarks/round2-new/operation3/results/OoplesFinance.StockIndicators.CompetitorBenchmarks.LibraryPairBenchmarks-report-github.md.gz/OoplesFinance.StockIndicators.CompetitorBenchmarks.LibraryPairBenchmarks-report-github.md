```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dDoji [28]** | **193.97 μs** |  **7.292 μs** | **4.339 μs** |  **1.00** |    **0.03** |  **65.36 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dDoji [28] |  33.29 μs |  0.666 μs | 0.348 μs |  0.17 |    0.00 |  16.63 KB |        0.25 |
|            |       |                      |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)dDoji [28]** | **338.79 μs** | **15.488 μs** | **9.217 μs** |  **1.00** |    **0.04** | **632.41 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dDoji [28] | 322.68 μs |  0.797 μs | 0.417 μs |  0.95 |    0.02 | 121.48 KB |        0.19 |
