```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)eDoji [28]** | **271.73 μs** | **11.846 μs** | **7.049 μs** |  **1.00** |    **0.03** |  **65.36 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)eDoji [28] |  33.89 μs |  0.666 μs | 0.441 μs |  0.12 |    0.00 |  13.39 KB |        0.20 |
|            |       |                      |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)eDoji [28]** | **325.51 μs** | **16.158 μs** | **9.616 μs** |  **1.00** |    **0.04** | **629.13 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)eDoji [28] | 310.73 μs |  0.994 μs | 0.592 μs |  0.96 |    0.03 | 119.89 KB |        0.19 |
