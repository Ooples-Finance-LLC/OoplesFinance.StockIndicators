```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Candles.Doji** | **186.63 μs** |  **8.017 μs** | **4.771 μs** |  **1.00** |    **0.03** |  **65.36 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Candles.Doji |  19.85 μs |  0.646 μs | 0.428 μs |  0.11 |    0.00 |  16.67 KB |        0.26 |
|            |       |                    |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Candles.Doji** | **339.12 μs** | **14.289 μs** | **8.503 μs** |  **1.00** |    **0.03** | **630.08 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Candles.Doji | 187.21 μs |  1.202 μs | 0.629 μs |  0.55 |    0.01 | 121.16 KB |        0.19 |
