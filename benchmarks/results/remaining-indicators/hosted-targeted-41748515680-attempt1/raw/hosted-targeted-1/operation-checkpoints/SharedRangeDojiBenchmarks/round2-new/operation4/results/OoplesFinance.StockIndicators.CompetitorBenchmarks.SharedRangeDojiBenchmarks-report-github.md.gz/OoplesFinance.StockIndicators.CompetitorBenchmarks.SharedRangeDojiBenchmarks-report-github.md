```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)iLine [24]** | **1000**  |  **82.47 μs** |  **2.839 μs** |  **1.878 μs** |  **1.00** |    **0.03** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)iLine [24] | 1000  |  55.46 μs |  0.633 μs |  0.331 μs |  0.67 |    0.02 |  0.4883 |       - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib(...)iLine [24] | 1000  |  60.01 μs |  0.524 μs |  0.312 μs |  0.73 |    0.02 |  3.4180 |  0.4883 |  57.26 KB |       14.43 |
| BuilderLatestOnly | TaLib(...)iLine [24] | 1000  |  54.99 μs |  0.607 μs |  0.361 μs |  0.67 |    0.02 |  0.4883 |       - |   9.38 KB |        2.36 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)iLine [24]** | **10000** | **567.95 μs** |  **3.051 μs** |  **1.596 μs** |  **1.00** |    **0.00** |       **-** |       **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib(...)iLine [24] | 10000 | 449.08 μs | 49.295 μs | 32.605 μs |  0.79 |    0.05 |  3.9063 |       - |  78.71 KB |        2.01 |
| BuilderFull       | TaLib(...)iLine [24] | 10000 | 546.03 μs |  2.570 μs |  1.530 μs |  0.96 |    0.00 | 31.2500 | 11.7188 | 549.82 KB |       14.05 |
| BuilderLatestOnly | TaLib(...)iLine [24] | 10000 | 509.29 μs |  2.048 μs |  1.219 μs |  0.90 |    0.00 |  3.9063 |       - |  79.72 KB |        2.04 |
