```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)dDoji [28]** | **1000**  |  **50.75 μs** |  **0.356 μs** |  **0.212 μs** |  **1.00** |    **0.01** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)dDoji [28] | 1000  |  47.03 μs |  4.152 μs |  2.746 μs |  0.93 |    0.05 |  0.4883 |       - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib(...)dDoji [28] | 1000  |  56.41 μs |  4.914 μs |  3.250 μs |  1.11 |    0.06 |  3.4180 |  0.4883 |  57.26 KB |       14.43 |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 1000  |  55.65 μs |  7.816 μs |  5.170 μs |  1.10 |    0.10 |  0.4883 |       - |   9.38 KB |        2.36 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)dDoji [28]** | **10000** | **523.83 μs** | **46.600 μs** | **30.823 μs** |  **1.00** |    **0.08** |       **-** |       **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)dDoji [28] | 10000 | 454.00 μs | 42.791 μs | 28.304 μs |  0.87 |    0.07 |  3.9063 |       - |  78.71 KB |        2.01 |
| BuilderFull       | TaLib(...)dDoji [28] | 10000 | 527.10 μs | 46.155 μs | 30.529 μs |  1.01 |    0.08 | 31.2500 | 11.7188 | 549.83 KB |       14.04 |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 10000 | 534.59 μs | 82.429 μs | 54.522 μs |  1.02 |    0.11 |  3.9063 |       - |  79.72 KB |        2.04 |
