```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)dDoji [28]** | **1000**  |  **68.17 μs** | **4.402 μs** | **2.620 μs** |       **-** |       **-** |  **57.26 KB** |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 1000  |  49.06 μs | 0.185 μs | 0.110 μs |  0.4883 |       - |   9.38 KB |
| **BuilderFull**       | **TaLib(...)dDoji [28]** | **10000** | **477.22 μs** | **1.782 μs** | **0.932 μs** | **31.2500** | **11.7188** | **549.82 KB** |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 10000 | 449.32 μs | 2.415 μs | 1.437 μs |  3.9063 |       - |  79.72 KB |
