```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)iLine [24]** | **1000**  |  **69.30 μs** | **0.318 μs** | **0.166 μs** |       **-** |       **-** |  **57.26 KB** |
| BuilderLatestOnly | TaLib(...)iLine [24] | 1000  |  54.14 μs | 0.536 μs | 0.319 μs |  0.4883 |       - |   9.38 KB |
| **BuilderFull**       | **TaLib(...)iLine [24]** | **10000** | **537.73 μs** | **3.189 μs** | **1.668 μs** | **31.2500** | **11.7188** | **549.81 KB** |
| BuilderLatestOnly | TaLib(...)iLine [24] | 10000 | 571.94 μs | 1.199 μs | 0.793 μs |  3.9063 |       - |  79.71 KB |
