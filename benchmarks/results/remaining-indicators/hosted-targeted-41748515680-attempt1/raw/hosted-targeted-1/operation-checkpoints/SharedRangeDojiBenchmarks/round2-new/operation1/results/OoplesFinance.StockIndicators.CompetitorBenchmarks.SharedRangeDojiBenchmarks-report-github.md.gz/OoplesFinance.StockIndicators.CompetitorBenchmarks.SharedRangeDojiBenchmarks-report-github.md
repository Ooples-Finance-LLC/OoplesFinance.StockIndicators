```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)yDoji [27]** | **1000**  |  **45.68 μs** |  **0.136 μs** |  **0.081 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)yDoji [27] | 1000  |  36.42 μs |  3.929 μs |  2.599 μs |  0.80 |    0.05 |  0.4883 |       - |    8.4 KB |        2.12 |
| BuilderFull       | TaLib(...)yDoji [27] | 1000  |  58.75 μs |  1.451 μs |  0.759 μs |  1.29 |    0.02 |  3.4180 |  0.4883 |  57.26 KB |       14.43 |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 1000  |  56.34 μs |  2.790 μs |  1.846 μs |  1.23 |    0.04 |  0.4883 |       - |   9.38 KB |        2.36 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)yDoji [27]** | **10000** | **472.96 μs** | **34.485 μs** | **20.521 μs** |  **1.00** |    **0.06** |       **-** |       **-** |  **39.16 KB** |        **1.00** |
| NativeParallel    | TaLib(...)yDoji [27] | 10000 | 392.86 μs | 60.371 μs | 39.932 μs |  0.83 |    0.09 |  3.9063 |       - |  78.74 KB |        2.01 |
| BuilderFull       | TaLib(...)yDoji [27] | 10000 | 538.21 μs | 12.008 μs |  6.280 μs |  1.14 |    0.05 | 31.2500 | 11.7188 | 549.81 KB |       14.04 |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 10000 | 533.66 μs | 65.155 μs | 43.096 μs |  1.13 |    0.10 |  3.9063 |       - |  79.72 KB |        2.04 |
