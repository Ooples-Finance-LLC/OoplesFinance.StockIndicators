```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)yDoji [27]** | **1000**  |  **69.94 μs** | **2.944 μs** | **1.752 μs** |       **-** |       **-** |  **57.23 KB** |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 1000  |  52.80 μs | 1.133 μs | 0.674 μs |  0.4883 |       - |   9.38 KB |
| **BuilderFull**       | **TaLib(...)yDoji [27]** | **10000** | **517.87 μs** | **2.932 μs** | **1.533 μs** | **31.2500** | **11.7188** | **549.79 KB** |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 10000 | 485.67 μs | 3.441 μs | 2.048 μs |  3.9063 |       - |  79.72 KB |
