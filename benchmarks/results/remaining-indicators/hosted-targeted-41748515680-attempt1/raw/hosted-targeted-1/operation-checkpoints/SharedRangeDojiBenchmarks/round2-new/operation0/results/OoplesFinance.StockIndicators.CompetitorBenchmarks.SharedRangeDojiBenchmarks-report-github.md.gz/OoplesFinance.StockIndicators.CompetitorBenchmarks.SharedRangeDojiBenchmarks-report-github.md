```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error     | StdDev   | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |----------:|----------:|---------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib.Candles.Doji** | **1000**  |  **21.01 μs** |  **0.126 μs** | **0.075 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Doji | 1000  |  17.46 μs |  3.464 μs | 2.291 μs |  0.83 |    0.10 |  0.4883 |       - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib.Candles.Doji | 1000  |  40.93 μs |  0.723 μs | 0.430 μs |  1.95 |    0.02 |  3.4180 |  0.4883 |  57.26 KB |       14.43 |
| BuilderLatestOnly | TaLib.Candles.Doji | 1000  |  38.37 μs |  0.432 μs | 0.257 μs |  1.83 |    0.01 |  0.4883 |       - |   9.38 KB |        2.36 |
|                   |                    |       |           |           |          |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib.Candles.Doji** | **10000** | **210.59 μs** |  **2.318 μs** | **1.379 μs** |  **1.00** |    **0.01** |  **1.9531** |       **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Doji | 10000 | 155.13 μs | 12.013 μs | 7.946 μs |  0.74 |    0.04 |  5.8594 |       - |  78.69 KB |        2.01 |
| BuilderFull       | TaLib.Candles.Doji | 10000 | 370.65 μs | 13.982 μs | 9.248 μs |  1.76 |    0.04 | 33.2031 | 11.7188 | 549.81 KB |       14.05 |
| BuilderLatestOnly | TaLib.Candles.Doji | 10000 | 347.12 μs |  8.794 μs | 5.233 μs |  1.65 |    0.03 |  3.9063 |       - |  79.71 KB |        2.04 |
