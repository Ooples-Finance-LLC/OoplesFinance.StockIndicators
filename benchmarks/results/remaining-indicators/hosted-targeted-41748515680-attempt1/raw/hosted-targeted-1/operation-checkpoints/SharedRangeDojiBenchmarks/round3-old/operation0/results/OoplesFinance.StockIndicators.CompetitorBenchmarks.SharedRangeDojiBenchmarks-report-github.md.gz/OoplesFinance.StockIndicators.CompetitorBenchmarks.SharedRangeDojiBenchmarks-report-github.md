```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Candles.Doji** | **1000**  |  **39.30 μs** | **0.455 μs** | **0.271 μs** |  **1.9531** |       **-** |  **57.23 KB** |
| BuilderLatestOnly | TaLib.Candles.Doji | 1000  |  36.34 μs | 0.195 μs | 0.102 μs |  0.4883 |       - |   9.38 KB |
| **BuilderFull**       | **TaLib.Candles.Doji** | **10000** | **420.67 μs** | **2.552 μs** | **1.519 μs** | **31.2500** | **11.7188** | **549.79 KB** |
| BuilderLatestOnly | TaLib.Candles.Doji | 10000 | 405.83 μs | 0.858 μs | 0.449 μs |  3.9063 |       - |  79.71 KB |
