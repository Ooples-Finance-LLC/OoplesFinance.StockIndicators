```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Candles.Doji** | **1000**  |  **47.09 μs** | **9.617 μs** | **6.361 μs** |  **1.9531** |       **-** |  **57.26 KB** |
| BuilderLatestOnly | TaLib.Candles.Doji | 1000  |  36.44 μs | 0.156 μs | 0.082 μs |  0.4883 |       - |   9.38 KB |
| **BuilderFull**       | **TaLib.Candles.Doji** | **10000** | **404.54 μs** | **5.117 μs** | **2.676 μs** | **31.2500** | **11.7188** | **549.83 KB** |
| BuilderLatestOnly | TaLib.Candles.Doji | 10000 | 329.79 μs | 3.177 μs | 1.662 μs |  3.9063 |       - |   79.7 KB |
