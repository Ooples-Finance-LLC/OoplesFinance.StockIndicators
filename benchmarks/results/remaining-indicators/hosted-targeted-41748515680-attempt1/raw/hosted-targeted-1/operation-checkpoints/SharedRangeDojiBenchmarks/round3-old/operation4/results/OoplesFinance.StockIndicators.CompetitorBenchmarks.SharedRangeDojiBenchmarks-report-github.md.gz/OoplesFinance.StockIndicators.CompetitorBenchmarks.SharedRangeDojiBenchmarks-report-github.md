```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)iLine [24]** | **1000**  |  **70.37 μs** | **5.853 μs** | **3.483 μs** |       **-** |       **-** |  **57.22 KB** |
| BuilderLatestOnly | TaLib(...)iLine [24] | 1000  |  52.92 μs | 0.391 μs | 0.233 μs |  0.4883 |       - |   9.38 KB |
| **BuilderFull**       | **TaLib(...)iLine [24]** | **10000** | **526.29 μs** | **5.930 μs** | **3.101 μs** | **31.2500** | **11.7188** | **549.78 KB** |
| BuilderLatestOnly | TaLib(...)iLine [24] | 10000 | 621.74 μs | 1.554 μs | 0.813 μs |  3.9063 |       - |   79.7 KB |
