```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)yDoji [27]** | **1000**  |  **67.50 μs** | **0.675 μs** | **0.402 μs** |       **-** |       **-** |  **57.26 KB** |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 1000  |  52.38 μs | 0.291 μs | 0.152 μs |  0.4883 |       - |   9.38 KB |
| **BuilderFull**       | **TaLib(...)yDoji [27]** | **10000** | **523.57 μs** | **7.086 μs** | **4.217 μs** | **31.2500** | **11.7188** | **549.83 KB** |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 10000 | 486.71 μs | 1.809 μs | 1.196 μs |  3.9063 |       - |  79.71 KB |
