```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)eDoji [28]** | **1000**  |  **57.70 μs** |  **0.267 μs** |  **0.159 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)eDoji [28] | 1000  |  37.87 μs |  2.885 μs |  1.717 μs |  0.66 |    0.03 |  0.4883 |       - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib(...)eDoji [28] | 1000  |  56.32 μs |  1.186 μs |  0.706 μs |  0.98 |    0.01 |  3.4180 |  0.4883 |  57.23 KB |       14.42 |
| BuilderLatestOnly | TaLib(...)eDoji [28] | 1000  |  51.89 μs |  0.412 μs |  0.245 μs |  0.90 |    0.00 |  0.4883 |       - |   9.38 KB |        2.36 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)eDoji [28]** | **10000** | **468.11 μs** | **11.402 μs** |  **6.785 μs** |  **1.00** |    **0.02** |       **-** |       **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib(...)eDoji [28] | 10000 | 293.77 μs | 37.148 μs | 19.429 μs |  0.63 |    0.04 |  5.8594 |       - |   78.7 KB |        2.01 |
| BuilderFull       | TaLib(...)eDoji [28] | 10000 | 514.11 μs |  4.967 μs |  2.598 μs |  1.10 |    0.02 | 31.2500 | 11.7188 | 549.79 KB |       14.05 |
| BuilderLatestOnly | TaLib(...)eDoji [28] | 10000 | 478.01 μs | 15.497 μs |  8.105 μs |  1.02 |    0.02 |  3.9063 |       - |  79.72 KB |        2.04 |
