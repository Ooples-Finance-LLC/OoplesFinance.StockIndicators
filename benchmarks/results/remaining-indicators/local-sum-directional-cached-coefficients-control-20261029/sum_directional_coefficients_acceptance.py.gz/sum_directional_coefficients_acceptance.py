"""Require a repeatable gain in the changed Sum directional smoothing path, with no loss."""
def qualifies(decisions):
    rows = list(decisions)
    assert len(rows) == 6
    assert {(r['pair'], r['bars'], r['method']) for r in rows} == {
        ('Skender.GetAdx', n, method)
        for n in (1000, 10000) for method in ('BuilderFull', 'BuilderLatestOnly', 'Ooples')}
    assert all(r['verdict'] in ('faster', 'slower', 'inconclusive') for r in rows)
    return any(r['verdict'] == 'faster' for r in rows) and not any(r['verdict'] == 'slower' for r in rows)

if __name__ == '__main__':
    rows = [dict(pair='Skender.GetAdx', bars=n, method=m, verdict='inconclusive')
            for n in (1000, 10000) for m in ('BuilderFull', 'BuilderLatestOnly', 'Ooples')]
    assert not qualifies(rows)
    rows[0]['verdict'] = 'faster'
    assert qualifies(rows)
    rows[-1]['verdict'] = 'slower'
    assert not qualifies(rows)
    try:
        qualifies(rows[:-1])
        raise RuntimeError('Missing comparison was accepted')
    except AssertionError:
        pass
    rows[-1]['pair'] = 'unrelated'
    try:
        qualifies(rows)
        raise RuntimeError('Unrelated comparison was accepted')
    except AssertionError:
        pass
    print('5 Sum directional acceptance checks passed')
