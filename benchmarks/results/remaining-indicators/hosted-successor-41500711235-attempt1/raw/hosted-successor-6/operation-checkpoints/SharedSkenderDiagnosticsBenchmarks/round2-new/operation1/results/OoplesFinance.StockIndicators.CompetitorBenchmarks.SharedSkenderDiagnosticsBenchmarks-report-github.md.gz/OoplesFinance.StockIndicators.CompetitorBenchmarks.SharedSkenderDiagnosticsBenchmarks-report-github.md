```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)lysis [22]** | **1000**  |   **303.86 μs** |   **5.428 μs** |   **2.839 μs** |  **3.63** |    **0.10** |        **-** |        **-** |       **-** |  **144.21 KB** |        **0.78** |
| BuilderLatestOnly | Skend(...)lysis [22] | 1000  |   269.80 μs |   6.356 μs |   3.324 μs |  3.23 |    0.09 |   3.9063 |        - |       - |   96.58 KB |        0.52 |
| NativeSingle      | Skend(...)lysis [22] | 1000  |    83.66 μs |   3.429 μs |   2.268 μs |  1.00 |    0.04 |  11.2305 |   2.4414 |       - |  184.11 KB |        1.00 |
| NativeParallel    | Skend(...)lysis [22] | 1000  |    60.24 μs |   7.977 μs |   5.277 μs |  0.72 |    0.06 |  13.1836 |   2.9297 |       - |  204.15 KB |        1.11 |
|                   |                      |       |             |            |            |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)lysis [22]** | **10000** | **2,720.55 μs** | **288.378 μs** | **190.744 μs** |  **2.27** |    **0.17** |  **62.5000** |  **31.2500** |       **-** | **1272.62 KB** |        **0.69** |
| BuilderLatestOnly | Skend(...)lysis [22] | 10000 | 2,720.56 μs | 326.110 μs | 215.701 μs |  2.27 |    0.19 |  46.8750 |  15.6250 |       - |   802.8 KB |        0.44 |
| NativeSingle      | Skend(...)lysis [22] | 10000 | 1,198.78 μs |  66.616 μs |  39.642 μs |  1.00 |    0.05 | 171.8750 | 117.1875 | 85.9375 | 1837.37 KB |        1.00 |
| NativeParallel    | Skend(...)lysis [22] | 10000 |   565.64 μs |  43.743 μs |  26.031 μs |  0.47 |    0.03 | 121.0938 |  62.5000 |       - | 1926.84 KB |        1.05 |
