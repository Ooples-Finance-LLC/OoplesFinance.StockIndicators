```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Skend(...)lysis [22]** | **1000**  |   **436.6 μs** |  **91.86 μs** |  **54.66 μs** |       **-** |       **-** |  **144.21 KB** |
| BuilderLatestOnly | Skend(...)lysis [22] | 1000  |   304.5 μs |  36.36 μs |  24.05 μs |  5.8594 |       - |   96.56 KB |
| **BuilderFull**       | **Skend(...)lysis [22]** | **10000** | **2,693.9 μs** | **259.26 μs** | **171.48 μs** | **62.5000** | **31.2500** | **1272.76 KB** |
| BuilderLatestOnly | Skend(...)lysis [22] | 10000 | 2,703.1 μs | 317.42 μs | 209.95 μs | 46.8750 | 15.6250 |   802.8 KB |
