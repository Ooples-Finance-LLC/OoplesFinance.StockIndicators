```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetPrs** | **1000**  |   **426.94 μs** |  **56.437 μs** |  **33.585 μs** |  **8.26** |    **0.63** |  **46.8750** |        **-** |        **-** |  **991.03 KB** |        **6.01** |
| BuilderLatestOnly | Skender.GetPrs | 1000  |   431.27 μs |  52.763 μs |  34.899 μs |  8.35 |    0.66 |  54.6875 |   7.8125 |        - |  943.45 KB |        5.73 |
| NativeSingle      | Skender.GetPrs | 1000  |    51.67 μs |   1.407 μs |   0.837 μs |  1.00 |    0.02 |   9.7656 |   1.4648 |        - |  164.79 KB |        1.00 |
| NativeParallel    | Skender.GetPrs | 1000  |    39.11 μs |   4.445 μs |   2.940 μs |  0.76 |    0.06 |  12.6953 |   2.6855 |        - |  184.81 KB |        1.12 |
|                   |                |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetPrs** | **10000** | **4,122.42 μs** | **346.471 μs** | **229.169 μs** |  **5.35** |    **0.29** | **562.5000** | **281.2500** |        **-** | **9429.56 KB** |        **5.74** |
| BuilderLatestOnly | Skender.GetPrs | 10000 | 4,061.68 μs | 214.620 μs | 127.717 μs |  5.27 |    0.18 | 531.2500 | 250.0000 |        - | 8959.73 KB |        5.45 |
| NativeSingle      | Skender.GetPrs | 10000 |   770.65 μs |  20.236 μs |  12.042 μs |  1.00 |    0.02 | 203.1250 | 156.2500 | 148.4375 | 1643.29 KB |        1.00 |
| NativeParallel    | Skender.GetPrs | 10000 |   412.80 μs |  22.149 μs |  13.181 μs |  0.54 |    0.02 | 113.2813 |  50.7813 |        - | 1731.72 KB |        1.05 |
