```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error      | StdDev     | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|-----------:|-----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetCmf** | **1000**  |  **99.72 μs** |  **11.722 μs** |   **7.753 μs** |  **3.9063** |       **-** |  **85.73 KB** |
| BuilderLatestOnly | Skender.GetCmf | 1000  |  88.04 μs |   3.290 μs |   1.721 μs |  1.9531 |       - |  38.13 KB |
| **BuilderFull**       | **Skender.GetCmf** | **10000** | **827.71 μs** |  **11.942 μs** |   **7.106 μs** | **46.8750** | **15.6250** | **789.28 KB** |
| BuilderLatestOnly | Skender.GetCmf | 10000 | 876.87 μs | 166.969 μs | 110.440 μs | 15.6250 |       - | 319.44 KB |
