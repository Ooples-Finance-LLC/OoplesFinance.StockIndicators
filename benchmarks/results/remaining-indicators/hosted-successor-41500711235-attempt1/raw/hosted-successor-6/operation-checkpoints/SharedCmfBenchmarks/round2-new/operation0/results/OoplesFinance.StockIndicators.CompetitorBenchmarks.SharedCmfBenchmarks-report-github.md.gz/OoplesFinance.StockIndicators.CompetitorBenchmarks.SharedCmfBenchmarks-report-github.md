```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetCmf** | **1000**  |    **86.59 μs** |  **9.395 μs** |  **6.214 μs** |  **0.68** |    **0.05** |   **3.9063** |        **-** |       **-** |   **85.73 KB** |        **0.29** |
| BuilderLatestOnly | Skender.GetCmf | 1000  |    73.96 μs |  6.437 μs |  4.258 μs |  0.58 |    0.03 |   1.9531 |        - |       - |   38.12 KB |        0.13 |
| NativeSingle      | Skender.GetCmf | 1000  |   127.45 μs |  2.315 μs |  1.211 μs |  1.00 |    0.01 |  17.5781 |   4.8828 |       - |   297.9 KB |        1.00 |
| NativeParallel    | Skender.GetCmf | 1000  |    89.04 μs | 13.530 μs |  8.950 μs |  0.70 |    0.07 |  20.5078 |   5.8594 |       - |   326.3 KB |        1.10 |
|                   |                |       |             |           |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skender.GetCmf** | **10000** |   **537.98 μs** | **93.776 μs** | **62.027 μs** |  **0.33** |    **0.04** |  **46.8750** |  **19.5313** |       **-** |  **789.24 KB** |        **0.27** |
| BuilderLatestOnly | Skender.GetCmf | 10000 |   519.04 μs | 72.664 μs | 48.063 μs |  0.32 |    0.03 |  15.6250 |   3.9063 |       - |  319.41 KB |        0.11 |
| NativeSingle      | Skender.GetCmf | 10000 | 1,609.35 μs | 31.122 μs | 16.278 μs |  1.00 |    0.01 | 187.5000 | 140.6250 | 46.8750 | 2970.25 KB |        1.00 |
| NativeParallel    | Skender.GetCmf | 10000 |   878.71 μs | 37.961 μs | 22.590 μs |  0.55 |    0.01 | 195.3125 | 125.0000 |       - | 3068.54 KB |        1.03 |
