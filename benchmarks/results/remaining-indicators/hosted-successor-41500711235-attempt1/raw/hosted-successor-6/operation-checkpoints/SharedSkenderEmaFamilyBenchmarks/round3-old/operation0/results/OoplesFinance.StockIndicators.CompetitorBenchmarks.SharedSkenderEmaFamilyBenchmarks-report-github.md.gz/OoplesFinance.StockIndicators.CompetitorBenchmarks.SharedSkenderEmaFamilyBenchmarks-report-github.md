```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **559.0 μs** |  **3.13 μs** |  **1.86 μs** |       **-** | **128.54 KB** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   549.7 μs |  7.86 μs |  4.68 μs |  3.9063 |   80.9 KB |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **5,585.7 μs** | **32.33 μs** | **16.91 μs** | **62.5000** | **1254.1 KB** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 5,530.4 μs | 15.17 μs |  7.93 μs | 31.2500 | 784.27 KB |
