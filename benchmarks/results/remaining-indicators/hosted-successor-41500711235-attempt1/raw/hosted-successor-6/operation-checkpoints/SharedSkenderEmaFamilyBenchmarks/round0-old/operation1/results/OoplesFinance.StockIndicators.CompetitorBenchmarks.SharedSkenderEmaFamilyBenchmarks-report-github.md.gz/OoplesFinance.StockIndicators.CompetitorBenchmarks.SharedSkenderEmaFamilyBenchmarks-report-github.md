```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error       | StdDev    | Median     | Allocated  |
|------------------ |--------------- |------ |-----------:|------------:|----------:|-----------:|-----------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  | **1,313.8 μs** | **1,104.01 μs** | **730.23 μs** |   **924.4 μs** |  **105.06 KB** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   661.9 μs |     8.52 μs |   5.07 μs |   659.1 μs |   57.43 KB |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **6,604.0 μs** |    **79.05 μs** |  **47.04 μs** | **6,582.3 μs** | **1019.92 KB** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 6,685.2 μs |    28.48 μs |  16.95 μs | 6,690.1 μs |  550.13 KB |
