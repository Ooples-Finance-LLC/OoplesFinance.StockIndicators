```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **551.33 μs** |   **3.414 μs** |   **1.786 μs** |  **9.13** |    **0.29** |        **-** |        **-** |        **-** |  **128.54 KB** |        **0.40** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   537.00 μs |   9.286 μs |   5.526 μs |  8.89 |    0.30 |   3.9063 |        - |        - |    80.9 KB |        0.25 |
| NativeSingle      | Skender.GetMacd | 1000  |    60.44 μs |   3.024 μs |   2.000 μs |  1.00 |    0.04 |  19.5313 |   6.3477 |        - |  324.54 KB |        1.00 |
| NativeParallel    | Skender.GetMacd | 1000  |   125.28 μs |   6.164 μs |   4.077 μs |  2.07 |    0.09 |  53.7109 |  20.5078 |        - |  826.62 KB |        2.55 |
|                   |                 |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **5,492.77 μs** |  **27.056 μs** |  **17.896 μs** |  **4.55** |    **0.11** |  **62.5000** |        **-** |        **-** | **1254.06 KB** |        **0.36** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 5,428.21 μs |  20.113 μs |  13.303 μs |  4.50 |    0.11 |  31.2500 |        - |        - |  784.27 KB |        0.23 |
| NativeSingle      | Skender.GetMacd | 10000 | 1,207.35 μs |  47.256 μs |  31.257 μs |  1.00 |    0.03 | 218.7500 | 218.7500 | 218.7500 | 3443.12 KB |        1.00 |
| NativeParallel    | Skender.GetMacd | 10000 | 4,500.41 μs | 582.539 μs | 385.313 μs |  3.73 |    0.32 | 750.0000 | 656.2500 | 312.5000 |  8556.6 KB |        2.49 |
