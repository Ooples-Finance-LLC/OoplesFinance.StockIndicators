```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **975.5 μs** | **103.33 μs** | **68.35 μs** |       **-** |  **89.27 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   525.0 μs |  14.95 μs |  7.82 μs |       - |   41.6 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **5,275.5 μs** | **134.00 μs** | **79.74 μs** | **31.2500** | **863.23 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 5,225.3 μs | 131.83 μs | 78.45 μs |       - | 393.62 KB |
