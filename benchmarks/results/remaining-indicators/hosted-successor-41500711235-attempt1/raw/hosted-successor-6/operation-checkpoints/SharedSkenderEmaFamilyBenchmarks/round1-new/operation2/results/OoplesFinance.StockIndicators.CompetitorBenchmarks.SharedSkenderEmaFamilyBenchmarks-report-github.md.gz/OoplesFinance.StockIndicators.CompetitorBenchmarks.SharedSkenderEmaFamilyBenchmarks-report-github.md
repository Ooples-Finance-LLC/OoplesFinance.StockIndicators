```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **292.0 μs** |  **3.30 μs** |  **1.73 μs** |       **-** |       **-** |  **89.21 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   296.9 μs |  1.22 μs |  0.64 μs |  1.9531 |       - |   41.6 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **3,084.7 μs** | **21.89 μs** | **13.03 μs** | **46.8750** | **15.6250** | **863.12 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 3,096.8 μs | 11.17 μs |  6.65 μs |       - |       - | 393.41 KB |
