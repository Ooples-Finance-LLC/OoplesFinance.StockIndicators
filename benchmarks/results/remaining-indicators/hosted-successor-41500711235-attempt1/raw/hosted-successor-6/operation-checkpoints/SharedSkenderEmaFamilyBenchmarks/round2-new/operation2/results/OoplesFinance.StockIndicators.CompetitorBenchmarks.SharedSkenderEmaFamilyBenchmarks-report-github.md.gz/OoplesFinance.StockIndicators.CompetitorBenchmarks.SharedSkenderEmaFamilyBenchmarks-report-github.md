```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **304.29 μs** |   **2.404 μs** |   **1.431 μs** |  **9.62** |    **0.15** |        **-** |        **-** |        **-** |   **89.21 KB** |        **0.73** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   312.05 μs |   1.429 μs |   0.945 μs |  9.87 |    0.15 |   1.9531 |        - |        - |    41.6 KB |        0.34 |
| NativeSingle      | Skender.GetTrix | 1000  |    31.62 μs |   0.810 μs |   0.482 μs |  1.00 |    0.02 |   7.3242 |   1.7090 |        - |  121.49 KB |        1.00 |
| NativeParallel    | Skender.GetTrix | 1000  |    64.83 μs |   1.395 μs |   0.730 μs |  2.05 |    0.04 |  20.5078 |   5.8594 |        - |  312.32 KB |        2.57 |
|                   |                 |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **3,226.19 μs** |  **10.705 μs** |   **6.370 μs** |  **5.77** |    **0.09** |  **31.2500** |        **-** |        **-** |  **863.24 KB** |        **0.71** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 3,152.55 μs |  14.079 μs |   7.364 μs |  5.64 |    0.09 |        - |        - |        - |   393.4 KB |        0.32 |
| NativeSingle      | Skender.GetTrix | 10000 |   558.97 μs |  15.227 μs |   9.061 μs |  1.00 |    0.02 |  97.6563 |  97.6563 |  97.6563 | 1212.12 KB |        1.00 |
| NativeParallel    | Skender.GetTrix | 10000 | 1,885.67 μs | 356.612 μs | 235.876 μs |  3.37 |    0.41 | 296.8750 | 234.3750 | 156.2500 | 3109.25 KB |        2.57 |
