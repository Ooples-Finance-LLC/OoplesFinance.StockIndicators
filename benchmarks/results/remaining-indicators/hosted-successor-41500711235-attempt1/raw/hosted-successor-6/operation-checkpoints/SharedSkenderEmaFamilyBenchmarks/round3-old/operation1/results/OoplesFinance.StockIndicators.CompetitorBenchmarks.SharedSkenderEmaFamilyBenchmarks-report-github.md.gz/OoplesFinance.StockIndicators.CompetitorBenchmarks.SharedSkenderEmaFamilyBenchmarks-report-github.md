```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **682.1 μs** |  **4.66 μs** |  **2.77 μs** | **105.05 KB** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   662.1 μs |  2.95 μs |  1.95 μs |  57.39 KB |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **6,753.1 μs** | **56.39 μs** | **33.56 μs** | **1019.9 KB** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 6,728.0 μs | 57.36 μs | 34.13 μs | 550.08 KB |
