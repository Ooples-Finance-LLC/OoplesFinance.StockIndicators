```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **735.75 μs** |   **5.915 μs** |   **3.520 μs** | **10.36** |    **0.16** |        **-** |        **-** |        **-** |  **105.05 KB** |        **0.37** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   704.31 μs |   3.227 μs |   1.920 μs |  9.91 |    0.15 |        - |        - |        - |   57.39 KB |        0.20 |
| NativeSingle      | Skender.GetPvo | 1000  |    71.06 μs |   1.662 μs |   1.100 μs |  1.00 |    0.02 |  17.0898 |   3.4180 |        - |  285.61 KB |        1.00 |
| NativeParallel    | Skender.GetPvo | 1000  |   136.23 μs |   9.555 μs |   6.320 μs |  1.92 |    0.09 |  46.8750 |  16.6016 |        - |  729.53 KB |        2.55 |
|                   |                |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **6,960.45 μs** |  **67.752 μs** |  **44.814 μs** |  **6.25** |    **0.13** |        **-** |        **-** |        **-** | **1019.91 KB** |        **0.33** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 7,124.48 μs |  21.668 μs |  11.333 μs |  6.40 |    0.12 |        - |        - |        - |  550.18 KB |        0.18 |
| NativeSingle      | Skender.GetPvo | 10000 | 1,113.65 μs |  33.522 μs |  22.172 μs |  1.00 |    0.03 | 164.0625 | 164.0625 | 164.0625 | 3052.21 KB |        1.00 |
| NativeParallel    | Skender.GetPvo | 10000 | 3,475.31 μs | 510.573 μs | 337.713 μs |  3.12 |    0.30 | 625.0000 | 500.0000 | 250.0000 | 7581.56 KB |        2.48 |
