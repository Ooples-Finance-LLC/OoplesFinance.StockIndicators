```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **3,355.1 μs** | **121.58 μs** |  **63.59 μs** |  **5.76** |    **0.10** |  **71.75 KB** |       **15.16** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  2,539.1 μs |  14.66 μs |   7.67 μs |  4.36 |    0.01 |  24.07 KB |        5.09 |
| NativeSingle      | TaLib(...)dMode [27] | 1000  |    582.2 μs |   1.86 μs |   1.11 μs |  1.00 |    0.00 |   4.73 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 1000  |    782.6 μs |  46.87 μs |  31.00 μs |  1.34 |    0.05 |   17.4 KB |        3.68 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **26,447.5 μs** |  **90.36 μs** |  **53.77 μs** |  **4.12** |    **0.10** | **636.41 KB** |       **15.77** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 26,145.5 μs | 131.12 μs |  78.03 μs |  4.07 |    0.10 | 166.61 KB |        4.13 |
| NativeSingle      | TaLib(...)dMode [27] | 10000 |  6,429.9 μs | 294.59 μs | 175.31 μs |  1.00 |    0.04 |  40.35 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 10000 |  8,171.0 μs | 427.57 μs | 254.44 μs |  1.27 |    0.05 | 141.07 KB |        3.50 |
