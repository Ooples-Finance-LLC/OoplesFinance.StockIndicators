```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)bands [22]** |   **202.59 μs** | **24.711 μs** | **16.345 μs** |  **1.01** |    **0.11** |  **205.02 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)bands [22] |    24.64 μs |  8.719 μs |  5.188 μs |  0.12 |    0.03 |  106.13 KB |        0.52 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)bands [22]** | **1,196.58 μs** | **30.715 μs** | **18.278 μs** |  **1.00** |    **0.02** | **1997.69 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)bands [22] |   181.35 μs |  6.887 μs |  3.602 μs |  0.15 |    0.00 |  976.58 KB |        0.49 |
