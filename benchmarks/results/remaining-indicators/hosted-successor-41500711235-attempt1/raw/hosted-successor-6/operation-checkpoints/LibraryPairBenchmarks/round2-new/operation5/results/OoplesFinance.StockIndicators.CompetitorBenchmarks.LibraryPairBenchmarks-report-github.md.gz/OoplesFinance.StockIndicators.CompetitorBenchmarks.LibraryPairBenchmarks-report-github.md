```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tSine [22]** |  **1,973.6 μs** |   **7.31 μs** |   **3.82 μs** |  **1.00** |    **0.00** |  **166.46 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tSine [22] |    579.5 μs |  26.39 μs |  17.46 μs |  0.29 |    0.01 |   73.91 KB |        0.44 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)tSine [22]** | **19,944.3 μs** |  **90.93 μs** |  **54.11 μs** |  **1.00** |    **0.00** | **1598.45 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tSine [22] |  6,219.1 μs | 697.97 μs | 415.35 μs |  0.31 |    0.02 |  654.64 KB |        0.41 |
