```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean         | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-------------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ma** |   **148.270 μs** | **35.0180 μs** | **23.1622 μs** |  **1.02** |    **0.20** |  **112.59 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ma |     7.970 μs |  0.3495 μs |  0.2312 μs |  0.05 |    0.01 |   38.28 KB |        0.34 |
|            |       |                    |              |            |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ma** | **1,137.690 μs** | **25.2972 μs** | **16.7325 μs** |  **1.00** |    **0.02** | **1043.93 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ma |    57.487 μs |  1.8634 μs |  0.9746 μs |  0.05 |    0.00 |  330.66 KB |        0.32 |
