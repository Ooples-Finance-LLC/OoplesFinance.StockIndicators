```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dMode [27]** |  **2,694.5 μs** |  **14.31 μs** |   **8.52 μs** |  **1.00** |  **112.68 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dMode [27] |    627.1 μs |  28.05 μs |  18.55 μs |  0.23 |    37.9 KB |        0.34 |
|            |       |                      |             |           |           |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)dMode [27]** | **27,478.0 μs** | **205.02 μs** | **135.61 μs** |  **1.00** | **1043.36 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dMode [27] |  6,420.9 μs |  34.12 μs |  22.57 μs |  0.23 |  292.73 KB |        0.28 |
