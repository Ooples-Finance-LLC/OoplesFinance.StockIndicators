```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Beta** |   **490.40 μs** | **28.975 μs** | **17.243 μs** |  **1.00** |    **0.05** |  **108.38 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Beta |    17.07 μs |  0.592 μs |  0.392 μs |  0.03 |    0.00 |   39.17 KB |        0.36 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Beta** | **4,269.61 μs** | **28.779 μs** | **15.052 μs** |  **1.00** |    **0.00** | **1039.72 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Beta |   101.47 μs |  0.841 μs |  0.440 μs |  0.02 |    0.00 |   330.9 KB |        0.32 |
