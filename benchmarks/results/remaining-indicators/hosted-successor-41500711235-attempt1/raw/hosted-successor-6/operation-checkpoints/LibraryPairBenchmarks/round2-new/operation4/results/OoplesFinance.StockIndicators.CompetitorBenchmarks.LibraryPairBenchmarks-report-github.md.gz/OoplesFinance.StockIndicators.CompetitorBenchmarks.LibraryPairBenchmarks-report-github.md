```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error    | StdDev   | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|---------:|---------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Phase [25]** |  **1,913.0 μs** | **10.21 μs** |  **6.08 μs** |  **1.00** |  **110.06 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Phase [25] |    550.5 μs | 32.44 μs | 21.46 μs |  0.29 |    41.8 KB |        0.38 |
|            |       |                      |             |          |          |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)Phase [25]** | **19,299.4 μs** | **67.83 μs** | **35.48 μs** |  **1.00** | **1040.74 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Phase [25] |  5,698.9 μs | 36.99 μs | 22.01 μs |  0.30 |  331.84 KB |        0.32 |
