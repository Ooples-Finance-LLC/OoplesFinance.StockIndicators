```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0     | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Accum(...)nLine [28]** | **1000**  |   **156.3 μs** |  **1.73 μs** |  **1.03 μs** |   **7.8125** |       **-** |  **153.97 KB** |
| BuilderLatestOnly | Accum(...)nLine [28] | 1000  |   155.1 μs |  1.32 μs |  0.78 μs |   5.8594 |       - |  106.36 KB |
| **BuilderFull**       | **Accum(...)nLine [28]** | **10000** | **1,899.4 μs** | **34.91 μs** | **20.78 μs** | **109.3750** | **46.8750** | **1931.53 KB** |
| BuilderLatestOnly | Accum(...)nLine [28] | 10000 | 1,914.8 μs | 49.03 μs | 32.43 μs |  78.1250 | 15.6250 | 1461.69 KB |
