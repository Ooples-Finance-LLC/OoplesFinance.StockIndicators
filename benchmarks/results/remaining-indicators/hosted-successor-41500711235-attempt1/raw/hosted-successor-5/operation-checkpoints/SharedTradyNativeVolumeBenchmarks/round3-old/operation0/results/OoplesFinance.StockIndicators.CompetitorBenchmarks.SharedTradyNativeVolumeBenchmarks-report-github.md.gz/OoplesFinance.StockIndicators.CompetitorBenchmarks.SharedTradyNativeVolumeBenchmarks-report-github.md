```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0     | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Accum(...)nLine [28]** | **1000**  |   **163.2 μs** |  **9.00 μs** |  **5.35 μs** |   **7.8125** |       **-** |  **154.01 KB** |
| BuilderLatestOnly | Accum(...)nLine [28] | 1000  |   150.2 μs |  2.32 μs |  1.21 μs |   5.8594 |       - |  106.36 KB |
| **BuilderFull**       | **Accum(...)nLine [28]** | **10000** | **1,867.8 μs** | **19.37 μs** | **10.13 μs** | **109.3750** | **46.8750** | **1931.53 KB** |
| BuilderLatestOnly | Accum(...)nLine [28] | 10000 | 1,830.6 μs | 11.05 μs |  5.78 μs |  78.1250 | 15.6250 |  1461.7 KB |
