```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0     | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Accum(...)nLine [28]** | **1000**  |   **156.1 μs** |  **1.50 μs** |  **0.78 μs** |   **7.8125** |       **-** |  **153.97 KB** |
| BuilderLatestOnly | Accum(...)nLine [28] | 1000  |   153.8 μs |  1.16 μs |  0.60 μs |   5.8594 |       - |  106.36 KB |
| **BuilderFull**       | **Accum(...)nLine [28]** | **10000** | **1,861.9 μs** | **17.90 μs** | **10.65 μs** | **109.3750** | **46.8750** | **1931.52 KB** |
| BuilderLatestOnly | Accum(...)nLine [28] | 10000 | 1,845.9 μs | 22.73 μs | 13.53 μs |  78.1250 | 15.6250 |  1461.7 KB |
