```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error       | StdDev    | Ratio | RatioSD | Gen0      | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|------------:|----------:|------:|--------:|----------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Accum(...)nLine [28]** | **1000**  |   **167.5 μs** |     **5.44 μs** |   **2.85 μs** |  **0.30** |    **0.01** |    **7.8125** |        **-** |        **-** |  **153.98 KB** |        **0.26** |
| BuilderLatestOnly | Accum(...)nLine [28] | 1000  |   158.7 μs |     3.23 μs |   2.14 μs |  0.29 |    0.00 |    5.8594 |        - |        - |  106.36 KB |        0.18 |
| NativeSingle      | Accum(...)nLine [28] | 1000  |   549.3 μs |     5.91 μs |   3.91 μs |  1.00 |    0.01 |   35.1563 |  11.7188 |        - |  594.33 KB |        1.00 |
| NativeParallel    | Accum(...)nLine [28] | 1000  |   480.7 μs |    18.48 μs |   9.67 μs |  0.88 |    0.02 |   54.6875 |  15.6250 |        - |  894.29 KB |        1.50 |
|                   |                      |       |            |             |           |       |         |           |          |          |            |             |
| **BuilderFull**       | **Accum(...)nLine [28]** | **10000** | **1,894.3 μs** |    **21.24 μs** |  **11.11 μs** |  **0.31** |    **0.01** |  **109.3750** |  **46.8750** |        **-** | **1931.51 KB** |        **0.33** |
| BuilderLatestOnly | Accum(...)nLine [28] | 10000 | 1,924.6 μs |    21.33 μs |  12.69 μs |  0.31 |    0.01 |   78.1250 |  15.6250 |        - |  1461.7 KB |        0.25 |
| NativeSingle      | Accum(...)nLine [28] | 10000 | 6,175.1 μs |   191.59 μs | 114.01 μs |  1.00 |    0.02 |  625.0000 | 437.5000 | 437.5000 | 5824.37 KB |        1.00 |
| NativeParallel    | Accum(...)nLine [28] | 10000 | 6,808.2 μs | 1,506.06 μs | 896.23 μs |  1.10 |    0.14 | 1142.8571 | 928.5714 | 857.1429 | 8717.71 KB |        1.50 |
