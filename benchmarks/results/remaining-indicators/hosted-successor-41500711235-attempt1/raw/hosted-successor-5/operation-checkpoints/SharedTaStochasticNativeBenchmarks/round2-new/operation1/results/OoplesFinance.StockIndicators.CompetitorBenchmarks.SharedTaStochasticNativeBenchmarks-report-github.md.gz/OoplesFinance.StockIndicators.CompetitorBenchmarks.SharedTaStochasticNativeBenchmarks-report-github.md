```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)tochF [22]** | **1000**  |   **692.409 μs** | **206.5042 μs** | **136.5898 μs** | **84.06** |   **15.96** |  **15.6250** |       **-** |  **392.11 KB** |       **16.55** |
| BuilderLatestOnly | TaLib(...)tochF [22] | 1000  |   337.092 μs |  21.8288 μs |  12.9899 μs | 40.92 |    1.82 |  19.5313 |  1.9531 |  344.54 KB |       14.54 |
| NativeSingle      | TaLib(...)tochF [22] | 1000  |     8.243 μs |   0.3353 μs |   0.2218 μs |  1.00 |    0.04 |   1.4038 |  0.0610 |    23.7 KB |        1.00 |
| NativeParallel    | TaLib(...)tochF [22] | 1000  |    17.594 μs |   0.4777 μs |   0.3159 μs |  2.14 |    0.07 |   5.0049 |  0.4883 |   75.77 KB |        3.20 |
|                   |                      |       |              |             |             |       |         |          |         |            |             |
| **BuilderFull**       | **TaLib(...)tochF [22]** | **10000** | **3,269.011 μs** |  **77.3928 μs** |  **40.4779 μs** | **24.87** |    **0.97** | **218.7500** | **93.7500** |  **3838.2 KB** |       **16.36** |
| BuilderLatestOnly | TaLib(...)tochF [22] | 10000 | 3,218.630 μs | 137.1473 μs |  71.7307 μs | 24.48 |    1.04 | 187.5000 | 62.5000 | 3368.38 KB |       14.36 |
| NativeSingle      | TaLib(...)tochF [22] | 10000 |   131.641 μs |   7.6694 μs |   5.0728 μs |  1.00 |    0.05 |  13.6719 |  2.9297 |  234.64 KB |        1.00 |
| NativeParallel    | TaLib(...)tochF [22] | 10000 |   186.093 μs |  13.4980 μs |   8.9281 μs |  1.42 |    0.08 |  46.8750 | 15.6250 |  743.75 KB |        3.17 |
