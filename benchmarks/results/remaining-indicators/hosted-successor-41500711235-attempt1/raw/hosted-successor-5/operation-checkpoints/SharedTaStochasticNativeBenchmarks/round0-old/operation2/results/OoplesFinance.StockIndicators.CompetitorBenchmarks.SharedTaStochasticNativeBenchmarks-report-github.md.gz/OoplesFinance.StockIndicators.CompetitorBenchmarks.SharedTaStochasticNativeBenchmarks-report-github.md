```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|-----------:|
| **BuilderFull**       | **TaLib(...)chRsi [24]** | **1000**  |   **468.1 μs** |  **2.97 μs** |  **1.56 μs** |       **-** |       **-** |  **182.03 KB** |
| BuilderLatestOnly | TaLib(...)chRsi [24] | 1000  |   475.1 μs |  5.92 μs |  3.52 μs |  7.8125 |       - |  134.44 KB |
| **BuilderFull**       | **TaLib(...)chRsi [24]** | **10000** | **4,904.7 μs** | **54.03 μs** | **28.26 μs** | **93.7500** | **31.2500** | **1799.91 KB** |
| BuilderLatestOnly | TaLib(...)chRsi [24] | 10000 | 4,892.8 μs | 31.12 μs | 18.52 μs | 62.5000 |       - | 1330.06 KB |
