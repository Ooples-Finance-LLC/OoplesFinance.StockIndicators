```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **1000**  |   **536.7 μs** | **167.15 μs** | **110.56 μs** |  **31.2500** |        **-** |  **645.94 KB** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 1000  |   441.4 μs |  13.57 μs |   7.10 μs |  35.1563 |        - |  598.35 KB |
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **10000** | **4,540.2 μs** | **357.24 μs** | **236.30 μs** | **375.0000** | **187.5000** | **6342.15 KB** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 10000 | 4,570.9 μs | 317.39 μs | 209.94 μs | 343.7500 |  93.7500 | 5872.28 KB |
