```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio  | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|-------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **1000**  | **1,168.56 μs** | **415.588 μs** | **274.886 μs** | **115.75** |   **26.00** |  **31.2500** |        **-** |  **645.99 KB** |       **27.23** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 1000  |   468.88 μs |  51.825 μs |  34.279 μs |  46.44 |    3.25 |  35.1563 |        - |  598.36 KB |       25.22 |
| NativeSingle      | TaLib(...)Stoch [21] | 1000  |    10.10 μs |   0.078 μs |   0.041 μs |   1.00 |    0.01 |   1.4038 |   0.0610 |   23.73 KB |        1.00 |
| NativeParallel    | TaLib(...)Stoch [21] | 1000  |    19.47 μs |   0.679 μs |   0.404 μs |   1.93 |    0.04 |   5.0049 |   0.4883 |   75.96 KB |        3.20 |
|                   |                      |       |             |            |            |        |         |          |          |            |             |
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **10000** | **4,759.42 μs** | **386.771 μs** | **255.825 μs** |  **30.83** |    **1.59** | **375.0000** | **187.5000** | **6342.11 KB** |       **27.03** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 10000 | 4,542.90 μs | 291.009 μs | 192.484 μs |  29.43 |    1.20 | 343.7500 |  93.7500 | 5872.31 KB |       25.02 |
| NativeSingle      | TaLib(...)Stoch [21] | 10000 |   154.39 μs |   1.427 μs |   0.849 μs |   1.00 |    0.01 |  13.6719 |   2.9297 |  234.67 KB |        1.00 |
| NativeParallel    | TaLib(...)Stoch [21] | 10000 |   202.20 μs |  11.297 μs |   5.909 μs |   1.31 |    0.04 |  46.8750 |  17.5781 |  743.95 KB |        3.17 |
