```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)chRsi [24]** | **1000**  |   **470.89 μs** |  **5.349 μs** |  **3.183 μs** | **21.09** |    **0.33** |       **-** |       **-** |  **182.03 KB** |        **5.84** |
| BuilderLatestOnly | TaLib(...)chRsi [24] | 1000  |   470.42 μs |  5.880 μs |  3.075 μs | 21.07 |    0.33 |  7.8125 |       - |  134.44 KB |        4.31 |
| NativeSingle      | TaLib(...)chRsi [24] | 1000  |    22.33 μs |  0.505 μs |  0.334 μs |  1.00 |    0.02 |  1.8311 |  0.1221 |   31.16 KB |        1.00 |
| NativeParallel    | TaLib(...)chRsi [24] | 1000  |    32.64 μs |  0.922 μs |  0.549 μs |  1.46 |    0.03 |  6.1035 |  0.7324 |   94.43 KB |        3.03 |
|                   |                      |       |             |           |           |       |         |         |         |            |             |
| **BuilderFull**       | **TaLib(...)chRsi [24]** | **10000** | **4,909.18 μs** | **49.538 μs** | **29.479 μs** | **18.02** |    **0.26** | **93.7500** | **31.2500** | **1799.89 KB** |        **5.76** |
| BuilderLatestOnly | TaLib(...)chRsi [24] | 10000 | 4,870.25 μs | 57.317 μs | 29.978 μs | 17.88 |    0.26 | 62.5000 |       - | 1330.05 KB |        4.26 |
| NativeSingle      | TaLib(...)chRsi [24] | 10000 |   272.48 μs |  5.807 μs |  3.841 μs |  1.00 |    0.02 | 17.5781 |  3.9063 |  312.42 KB |        1.00 |
| NativeParallel    | TaLib(...)chRsi [24] | 10000 |   377.06 μs | 14.059 μs |  9.299 μs |  1.38 |    0.04 | 58.5938 | 25.3906 |   938.2 KB |        3.00 |
