```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **1000**  |   **179.37 μs** |  **45.642 μs** | **27.161 μs** |  **6.29** |    **0.90** |       **-** |       **-** |  **73.24 KB** |        **9.24** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 1000  |   146.44 μs |   5.176 μs |  3.424 μs |  5.13 |    0.12 |  0.9766 |       - |  25.22 KB |        3.18 |
| NativeSingle      | TaLib(...)vgDev [22] | 1000  |    28.52 μs |   0.292 μs |  0.174 μs |  1.00 |    0.01 |  0.2441 |       - |   7.92 KB |        1.00 |
| NativeParallel    | TaLib(...)vgDev [22] | 1000  |    17.35 μs |   1.056 μs |  0.628 μs |  0.61 |    0.02 |  1.0986 |       - |  16.76 KB |        2.11 |
|                   |                      |       |             |            |           |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **10000** | **1,043.69 μs** | **101.311 μs** | **60.288 μs** |  **3.61** |    **0.20** | **31.2500** | **15.6250** | **565.69 KB** |        **7.23** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 10000 | 1,044.14 μs | 125.551 μs | 83.044 μs |  3.62 |    0.27 |       - |       - |  95.59 KB |        1.22 |
| NativeSingle      | TaLib(...)vgDev [22] | 10000 |   288.78 μs |   2.069 μs |  1.368 μs |  1.00 |    0.01 |  3.9063 |       - |  78.25 KB |        1.00 |
| NativeParallel    | TaLib(...)vgDev [22] | 10000 |   187.03 μs |   8.717 μs |  5.766 μs |  0.65 |    0.02 | 10.7422 |  1.9531 | 157.39 KB |        2.01 |
