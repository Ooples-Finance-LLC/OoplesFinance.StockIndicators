```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **1000**  |   **183.5 μs** |   **6.56 μs** |   **3.90 μs** |       **-** |       **-** |  **73.24 KB** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 1000  |   149.7 μs |  14.55 μs |   9.62 μs |  0.9766 |       - |  25.22 KB |
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **10000** | **1,555.0 μs** |  **28.59 μs** |  **17.01 μs** | **31.2500** | **15.6250** | **565.76 KB** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 10000 | 1,228.0 μs | 247.05 μs | 163.41 μs |       - |       - |  95.59 KB |
