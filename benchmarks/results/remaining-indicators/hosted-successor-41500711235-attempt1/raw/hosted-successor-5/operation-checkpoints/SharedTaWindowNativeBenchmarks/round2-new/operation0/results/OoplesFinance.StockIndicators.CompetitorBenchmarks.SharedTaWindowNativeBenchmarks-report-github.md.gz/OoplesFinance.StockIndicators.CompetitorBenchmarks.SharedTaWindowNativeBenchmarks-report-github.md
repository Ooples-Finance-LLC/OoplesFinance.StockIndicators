```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean          | Error       | StdDev      | Ratio  | RatioSD | Gen0      | Gen1     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |--------------:|------------:|------------:|-------:|--------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **TaLib(...)bands [24]** | **1000**  |  **2,231.758 μs** |  **31.3870 μs** |  **16.4160 μs** | **231.69** |    **4.54** |  **133.3333** |        **-** |  **3187.69 KB** |       **81.56** |
| BuilderLatestOnly | TaLib(...)bands [24] | 1000  |  2,250.402 μs |  28.9406 μs |  17.2221 μs | 233.63 |    4.61 |  187.5000 |  31.2500 |   3140.2 KB |       80.34 |
| NativeSingle      | TaLib(...)bands [24] | 1000  |      9.636 μs |   0.2847 μs |   0.1883 μs |   1.00 |    0.03 |    2.3804 |   0.1831 |    39.09 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [24] | 1000  |     18.508 μs |   0.5056 μs |   0.3009 μs |   1.92 |    0.05 |    8.0566 |   1.2207 |   122.26 KB |        3.13 |
|                   |                      |       |               |             |             |        |         |           |          |             |             |
| **BuilderFull**       | **TaLib(...)bands [24]** | **10000** | **14,407.176 μs** | **432.4091 μs** | **257.3197 μs** | **154.50** |    **3.11** | **1857.1429** | **857.1429** | **32093.36 KB** |       **82.15** |
| BuilderLatestOnly | TaLib(...)bands [24] | 10000 | 14,463.165 μs | 588.2424 μs | 389.0859 μs | 155.10 |    4.32 | 1875.0000 | 875.0000 | 31623.45 KB |       80.95 |
| NativeSingle      | TaLib(...)bands [24] | 10000 |     93.262 μs |   1.8057 μs |   1.0745 μs |   1.00 |    0.02 |   23.4375 |   7.8125 |   390.65 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [24] | 10000 |    174.214 μs |  11.0672 μs |   7.3202 μs |   1.87 |    0.08 |   76.1719 |  35.1563 |  1212.11 KB |        3.10 |
