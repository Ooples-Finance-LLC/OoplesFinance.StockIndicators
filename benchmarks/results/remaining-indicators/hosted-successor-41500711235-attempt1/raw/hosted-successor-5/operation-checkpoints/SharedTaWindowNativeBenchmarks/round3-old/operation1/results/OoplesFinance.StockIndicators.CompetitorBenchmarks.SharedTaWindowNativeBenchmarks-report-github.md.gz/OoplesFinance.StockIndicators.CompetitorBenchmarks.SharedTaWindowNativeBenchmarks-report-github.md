```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **1000**  |   **157.2 μs** |  **30.70 μs** | **20.31 μs** |       **-** |       **-** |  **73.14 KB** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 1000  |   142.3 μs |  11.90 μs |  7.87 μs |  0.9766 |       - |  25.22 KB |
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **10000** | **1,058.2 μs** |  **70.54 μs** | **46.66 μs** | **31.2500** | **15.6250** | **565.69 KB** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 10000 | 1,060.6 μs | 140.45 μs | 92.90 μs |       - |       - |  95.59 KB |
