```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|----------:|---------:|---------:|------------:|------------:|
| **BuilderFull**       | **Commo(...)Index [21]** | **1000**  |     **307.1 μs** |    **74.64 μs** |    **49.37 μs** |  **0.02** |    **0.00** |         **-** |        **-** |        **-** |    **70.53 KB** |       **0.016** |
| BuilderLatestOnly | Commo(...)Index [21] | 1000  |     281.2 μs |    48.46 μs |    32.05 μs |  0.02 |    0.00 |         - |        - |        - |    22.88 KB |       0.005 |
| NativeSingle      | Commo(...)Index [21] | 1000  |  13,692.6 μs |    74.09 μs |    38.75 μs |  1.00 |    0.00 |  142.8571 |        - |        - |  4398.24 KB |       1.000 |
| NativeParallel    | Commo(...)Index [21] | 1000  |   8,731.8 μs |   407.54 μs |   269.56 μs |  0.64 |    0.02 |  214.2857 |        - |        - |  4407.36 KB |       1.002 |
|                   |                      |       |              |             |             |       |         |           |          |          |             |             |
| **BuilderFull**       | **Commo(...)Index [21]** | **10000** |   **2,621.9 μs** |   **412.23 μs** |   **272.67 μs** |  **0.02** |    **0.00** |   **31.2500** |  **15.6250** |        **-** |   **633.45 KB** |       **0.014** |
| BuilderLatestOnly | Commo(...)Index [21] | 10000 |   2,462.2 μs |   304.20 μs |   201.21 μs |  0.02 |    0.00 |         - |        - |        - |   163.63 KB |       0.004 |
| NativeSingle      | Commo(...)Index [21] | 10000 | 141,018.8 μs | 1,868.84 μs | 1,236.12 μs |  1.00 |    0.01 | 2750.0000 | 500.0000 | 250.0000 |  45275.6 KB |       1.000 |
| NativeParallel    | Commo(...)Index [21] | 10000 |  82,137.0 μs | 1,962.82 μs | 1,298.28 μs |  0.58 |    0.01 | 2750.0000 | 500.0000 | 250.0000 | 45393.99 KB |       1.003 |
