```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)AdOsc [21]** |   **670.24 μs** | **26.313 μs** | **17.405 μs** |  **1.00** |    **0.03** |  **209.05 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)AdOsc [21] |    10.67 μs |  3.531 μs |  2.335 μs |  0.02 |    0.00 |   40.21 KB |        0.19 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)AdOsc [21]** | **6,499.22 μs** | **60.679 μs** | **36.109 μs** | **1.000** |    **0.01** | **2053.13 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)AdOsc [21] |    62.75 μs |  1.907 μs |  0.997 μs | 0.010 |    0.00 |  330.91 KB |        0.16 |
