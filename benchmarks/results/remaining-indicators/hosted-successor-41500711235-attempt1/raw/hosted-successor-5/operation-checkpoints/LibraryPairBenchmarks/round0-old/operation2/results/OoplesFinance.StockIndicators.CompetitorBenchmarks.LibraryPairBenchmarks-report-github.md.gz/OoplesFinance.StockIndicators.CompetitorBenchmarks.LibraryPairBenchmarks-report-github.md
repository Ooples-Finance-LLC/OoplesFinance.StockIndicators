```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId             | Mean       | Error    | StdDev   | Ratio | Allocated  | Alloc Ratio |
|------- |------ |------------------- |-----------:|---------:|---------:|------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Ad** |   **190.0 μs** |  **3.53 μs** |  **1.85 μs** |  **1.00** |  **160.84 KB** |        **1.00** |
|        |       |                    |            |          |          |       |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Ad** | **1,952.4 μs** | **23.57 μs** | **14.03 μs** |  **1.00** | **2015.19 KB** |        **1.00** |
