```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Apo** |   **356.27 μs** | **32.739 μs** | **19.483 μs** |  **1.00** |    **0.07** |  **373.16 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Apo |    10.85 μs |  0.490 μs |  0.256 μs |  0.03 |    0.00 |   47.24 KB |        0.13 |
|            |       |                     |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Apo** | **2,905.14 μs** | **62.539 μs** | **37.216 μs** |  **1.00** |    **0.02** | **3553.74 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Apo |    92.64 μs |  3.244 μs |  1.931 μs |  0.03 |    0.00 |  409.19 KB |        0.12 |
