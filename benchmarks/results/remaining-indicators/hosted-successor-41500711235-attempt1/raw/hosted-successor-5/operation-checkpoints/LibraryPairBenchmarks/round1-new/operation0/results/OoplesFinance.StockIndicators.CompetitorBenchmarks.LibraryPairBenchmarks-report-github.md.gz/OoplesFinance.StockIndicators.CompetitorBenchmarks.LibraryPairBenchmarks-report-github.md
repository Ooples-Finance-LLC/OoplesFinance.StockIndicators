```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId            | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |------------------ |-----------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetZigZag** |   **277.8 μs** |    **18.35 μs** |  **10.92 μs** |  **1.00** |    **0.05** |  **479.95 KB** |        **1.00** |
|        |       |                   |            |             |           |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetZigZag** | **4,065.7 μs** | **1,187.69 μs** | **785.58 μs** |  **1.03** |    **0.27** | **4850.98 KB** |        **1.00** |
