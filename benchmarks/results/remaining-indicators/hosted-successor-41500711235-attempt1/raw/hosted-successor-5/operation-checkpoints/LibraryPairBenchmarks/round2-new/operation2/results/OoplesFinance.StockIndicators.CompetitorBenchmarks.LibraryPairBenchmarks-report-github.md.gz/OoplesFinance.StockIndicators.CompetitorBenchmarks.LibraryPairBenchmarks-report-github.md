```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean         | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-------------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ad** |   **185.250 μs** | **17.0098 μs** | **10.1223 μs** |  **1.00** |    **0.07** |   **160.8 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ad |     4.513 μs |  0.9051 μs |  0.4734 μs |  0.02 |    0.00 |     8.2 KB |        0.05 |
|            |       |                    |              |            |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ad** | **1,903.567 μs** | **24.5555 μs** | **14.6126 μs** |  **1.00** |    **0.01** | **2015.23 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ad |    24.938 μs |  1.4826 μs |  0.7754 μs |  0.01 |    0.00 |   86.01 KB |        0.04 |
