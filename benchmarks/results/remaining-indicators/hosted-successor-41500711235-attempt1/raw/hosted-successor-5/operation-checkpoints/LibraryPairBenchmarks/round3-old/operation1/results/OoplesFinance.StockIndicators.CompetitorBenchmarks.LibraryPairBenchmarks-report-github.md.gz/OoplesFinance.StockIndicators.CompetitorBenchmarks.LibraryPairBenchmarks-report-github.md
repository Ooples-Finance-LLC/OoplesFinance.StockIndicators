```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Allocated | Alloc Ratio |
|------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)bands [24]** |  **2.227 ms** | **0.0934 ms** | **0.0617 ms** |  **1.00** |    **0.04** |         **-** |         **-** |   **3.23 MB** |        **1.00** |
|        |       |                      |           |           |           |       |         |           |           |           |             |
| **Ooples** | **10000** | **TaLib(...)bands [24]** | **13.497 ms** | **0.9918 ms** | **0.5187 ms** |  **1.00** |    **0.05** | **2000.0000** | **1000.0000** |  **32.43 MB** |        **1.00** |
