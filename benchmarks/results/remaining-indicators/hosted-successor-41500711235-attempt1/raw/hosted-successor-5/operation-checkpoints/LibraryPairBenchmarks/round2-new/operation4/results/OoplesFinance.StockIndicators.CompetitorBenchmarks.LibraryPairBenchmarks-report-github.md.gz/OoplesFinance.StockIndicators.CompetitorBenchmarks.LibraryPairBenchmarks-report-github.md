```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adx** |   **695.28 μs** | **31.551 μs** | **20.869 μs** |  **1.00** |    **0.04** |  **106.32 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adx |    35.15 μs |  1.317 μs |  0.871 μs |  0.05 |    0.00 |   40.88 KB |        0.38 |
|            |       |                     |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adx** | **6,621.09 μs** | **40.452 μs** | **24.072 μs** |  **1.00** |    **0.00** | **1045.28 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adx |   229.30 μs | 16.981 μs | 11.232 μs |  0.03 |    0.00 |  330.92 KB |        0.32 |
