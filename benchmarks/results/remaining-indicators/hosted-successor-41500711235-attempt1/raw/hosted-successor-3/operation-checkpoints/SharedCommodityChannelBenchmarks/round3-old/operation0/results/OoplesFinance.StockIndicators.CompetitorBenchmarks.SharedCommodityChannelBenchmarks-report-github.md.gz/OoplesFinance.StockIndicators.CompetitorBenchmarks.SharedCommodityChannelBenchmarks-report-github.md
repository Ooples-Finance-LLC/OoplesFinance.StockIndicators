```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Cci** | **1000**  |   **234.8 μs** |  **7.25 μs** |  **3.79 μs** |       **-** |       **-** |  **66.79 KB** |
| BuilderLatestOnly | TaLib.Functions.Cci | 1000  |   238.4 μs | 30.76 μs | 20.35 μs |       - |       - |  19.13 KB |
| **BuilderFull**       | **TaLib.Functions.Cci** | **10000** | **2,050.4 μs** | **34.29 μs** | **17.94 μs** | **31.2500** | **15.6250** | **629.71 KB** |
| BuilderLatestOnly | TaLib.Functions.Cci | 10000 | 2,033.9 μs | 30.15 μs | 15.77 μs |       - |       - | 159.85 KB |
