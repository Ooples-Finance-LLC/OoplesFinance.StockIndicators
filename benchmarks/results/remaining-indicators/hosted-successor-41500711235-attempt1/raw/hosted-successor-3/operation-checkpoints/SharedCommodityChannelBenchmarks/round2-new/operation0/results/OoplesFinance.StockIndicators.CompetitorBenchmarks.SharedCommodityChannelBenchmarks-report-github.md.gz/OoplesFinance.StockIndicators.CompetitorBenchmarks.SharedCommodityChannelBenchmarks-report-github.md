```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error      | StdDev     | Median      | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|-----------:|-----------:|------------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Cci** | **1000**  |   **737.79 μs** | **582.132 μs** | **385.044 μs** |   **950.38 μs** | **22.17** |   **11.04** |       **-** |       **-** |  **66.79 KB** |        **8.64** |
| BuilderLatestOnly | TaLib.Functions.Cci | 1000  |   242.37 μs |  24.964 μs |  16.512 μs |   239.41 μs |  7.28 |    0.47 |       - |       - |  19.12 KB |        2.47 |
| NativeSingle      | TaLib.Functions.Cci | 1000  |    33.28 μs |   0.189 μs |   0.113 μs |    33.23 μs |  1.00 |    0.00 |  0.2441 |       - |   7.73 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Cci | 1000  |    18.11 μs |   1.081 μs |   0.715 μs |    17.90 μs |  0.54 |    0.02 |  0.4883 |       - |   8.02 KB |        1.04 |
|                   |                     |       |             |            |            |             |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Cci** | **10000** | **2,148.35 μs** | **283.155 μs** | **187.290 μs** | **2,041.69 μs** |  **6.43** |    **0.53** | **31.2500** | **15.6250** | **629.71 KB** |        **8.07** |
| BuilderLatestOnly | TaLib.Functions.Cci | 10000 | 1,994.85 μs |  32.009 μs |  16.741 μs | 1,992.38 μs |  5.97 |    0.05 |       - |       - | 159.88 KB |        2.05 |
| NativeSingle      | TaLib.Functions.Cci | 10000 |   334.34 μs |   0.891 μs |   0.466 μs |   334.48 μs |  1.00 |    0.00 |  3.9063 |       - |  78.05 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Cci | 10000 |   187.17 μs |   9.455 μs |   6.254 μs |   187.13 μs |  0.56 |    0.02 |  3.9063 |       - |  78.34 KB |        1.00 |
