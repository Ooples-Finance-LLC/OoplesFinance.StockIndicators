```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|---------:|---------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Mavp** | **1000**  | **101.48 μs** | **1.184 μs** | **0.705 μs** |  **3.69** |    **0.04** |  **3.9063** |       **-** |  **66.38 KB** |        **3.34** |
| BuilderLatestOnly | TaLib.Functions.Mavp | 1000  |  93.77 μs | 0.611 μs | 0.404 μs |  3.41 |    0.03 |  0.9766 |       - |  18.77 KB |        0.94 |
| NativeSingle      | TaLib.Functions.Mavp | 1000  |  27.52 μs | 0.353 μs | 0.210 μs |  1.00 |    0.01 |  0.9766 |       - |   19.9 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mavp | 1000  |  43.83 μs | 1.322 μs | 0.874 μs |  1.59 |    0.03 |  4.1504 |  0.2441 |   59.1 KB |        2.97 |
|                   |                      |       |           |          |          |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Mavp** | **10000** | **900.04 μs** | **5.650 μs** | **3.362 μs** |  **2.84** |    **0.03** | **31.2500** |  **7.8125** |  **629.3 KB** |        **3.22** |
| BuilderLatestOnly | TaLib.Functions.Mavp | 10000 | 909.65 μs | 5.689 μs | 2.975 μs |  2.87 |    0.03 |  7.8125 |       - | 159.47 KB |        0.81 |
| NativeSingle      | TaLib.Functions.Mavp | 10000 | 316.74 μs | 5.757 μs | 3.808 μs |  1.00 |    0.02 | 11.7188 |  1.9531 |  195.7 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mavp | 10000 | 427.13 μs | 8.537 μs | 4.465 μs |  1.35 |    0.02 | 35.1563 | 11.7188 | 568.89 KB |        2.91 |
