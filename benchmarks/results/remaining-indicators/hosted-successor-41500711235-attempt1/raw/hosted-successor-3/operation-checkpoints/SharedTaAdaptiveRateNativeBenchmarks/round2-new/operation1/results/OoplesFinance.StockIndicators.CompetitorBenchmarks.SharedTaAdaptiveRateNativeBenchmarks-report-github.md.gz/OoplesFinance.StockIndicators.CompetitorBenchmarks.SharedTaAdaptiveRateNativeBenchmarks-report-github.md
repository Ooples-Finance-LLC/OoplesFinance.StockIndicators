```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **306.23 μs** |  **1.660 μs** |  **0.868 μs** | **28.82** |    **0.09** |       **-** |      **-** |  **89.21 KB** |        **5.76** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   318.38 μs |  1.306 μs |  0.864 μs | 29.97 |    0.09 |  1.9531 |      - |   41.6 KB |        2.69 |
| NativeSingle      | TaLib.Functions.Trix | 1000  |    10.62 μs |  0.039 μs |  0.020 μs |  1.00 |    0.00 |  0.9155 |      - |  15.48 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Trix | 1000  |    15.14 μs |  0.719 μs |  0.476 μs |  1.42 |    0.04 |  3.2959 | 0.2441 |   47.6 KB |        3.07 |
|                   |                      |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **3,181.48 μs** | **33.680 μs** | **17.615 μs** | **29.78** |    **0.24** | **31.2500** |      **-** | **863.24 KB** |        **5.53** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 3,181.55 μs |  6.389 μs |  3.341 μs | 29.79 |    0.18 |       - |      - |  393.4 KB |        2.52 |
| NativeSingle      | TaLib.Functions.Trix | 10000 |   106.82 μs |  1.039 μs |  0.687 μs |  1.00 |    0.01 |  8.7891 | 0.9766 | 156.12 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Trix | 10000 |   165.02 μs |  5.099 μs |  3.373 μs |  1.54 |    0.03 | 29.2969 | 9.7656 | 469.48 KB |        3.01 |
