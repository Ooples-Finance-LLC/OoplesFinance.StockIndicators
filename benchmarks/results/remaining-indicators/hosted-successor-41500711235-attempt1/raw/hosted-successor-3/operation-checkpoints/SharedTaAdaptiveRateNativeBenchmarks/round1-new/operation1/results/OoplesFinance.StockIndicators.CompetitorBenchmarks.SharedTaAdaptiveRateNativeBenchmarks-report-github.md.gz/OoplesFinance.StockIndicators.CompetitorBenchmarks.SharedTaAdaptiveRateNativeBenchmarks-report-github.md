```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **311.2 μs** |  **1.05 μs** |  **0.55 μs** |       **-** |  **89.21 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   309.7 μs |  3.30 μs |  2.18 μs |  1.9531 |   41.6 KB |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **3,216.6 μs** | **23.19 μs** | **13.80 μs** | **31.2500** | **863.24 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 3,177.6 μs |  7.24 μs |  3.79 μs |       - |  393.4 KB |
