```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mavp** | **1000**  | **103.70 μs** |  **4.136 μs** | **2.461 μs** |  **3.9063** |      **-** |  **66.38 KB** |
| BuilderLatestOnly | TaLib.Functions.Mavp | 1000  |  97.39 μs |  1.435 μs | 0.854 μs |  0.9766 |      - |  18.77 KB |
| **BuilderFull**       | **TaLib.Functions.Mavp** | **10000** | **897.61 μs** |  **4.856 μs** | **2.889 μs** | **31.2500** | **7.8125** |  **629.3 KB** |
| BuilderLatestOnly | TaLib.Functions.Mavp | 10000 | 908.79 μs | 10.022 μs | 5.964 μs |  7.8125 |      - | 159.46 KB |
