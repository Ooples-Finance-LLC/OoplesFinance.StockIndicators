```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean         | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |-------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **138.337 μs** | **4.0101 μs** | **2.0974 μs** | **58.45** |    **1.17** |  **3.9063** |      **-** |  **64.88 KB** |        **8.24** |
| BuilderLatestOnly | Ad        | 1000  |   128.843 μs | 1.0938 μs | 0.6509 μs | 54.44 |    0.80 |  0.9766 |      - |  17.27 KB |        2.19 |
| NativeSingle      | Ad        | 1000  |     2.367 μs | 0.0596 μs | 0.0355 μs |  1.00 |    0.02 |  0.4730 |      - |   7.88 KB |        1.00 |
| NativeParallel    | Ad        | 1000  |     5.545 μs | 0.0681 μs | 0.0405 μs |  2.34 |    0.04 |  0.4883 |      - |   8.16 KB |        1.04 |
|                   |           |       |              |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **Ad**        | **10000** | **1,199.372 μs** | **7.4855 μs** | **4.9512 μs** | **57.06** |    **0.25** | **31.2500** | **7.8125** | **627.79 KB** |        **8.03** |
| BuilderLatestOnly | Ad        | 10000 | 1,202.562 μs | 2.8561 μs | 1.4938 μs | 57.21 |    0.13 |  7.8125 |      - | 157.96 KB |        2.02 |
| NativeSingle      | Ad        | 10000 |    21.020 μs | 0.0858 μs | 0.0449 μs |  1.00 |    0.00 |  4.7607 | 0.8545 |  78.19 KB |        1.00 |
| NativeParallel    | Ad        | 10000 |    44.294 μs | 6.1720 μs | 4.0824 μs |  2.11 |    0.19 |  4.3945 | 0.4883 |  78.48 KB |        1.00 |
