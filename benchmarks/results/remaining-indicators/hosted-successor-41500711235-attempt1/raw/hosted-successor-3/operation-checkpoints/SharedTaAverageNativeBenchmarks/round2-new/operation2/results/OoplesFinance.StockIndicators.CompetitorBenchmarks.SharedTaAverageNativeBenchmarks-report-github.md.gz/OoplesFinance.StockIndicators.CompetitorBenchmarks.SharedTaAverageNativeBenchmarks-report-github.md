```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean         | Error       | StdDev      | Ratio  | RatioSD | Gen0     | Gen1     | Allocated   | Alloc Ratio |
|------------------ |-------------------- |------ |-------------:|------------:|------------:|-------:|--------:|---------:|---------:|------------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Ppo** | **1000**  |   **822.859 μs** | **155.1382 μs** |  **92.3203 μs** | **130.72** |   **13.96** |  **62.5000** |        **-** |  **1487.41 KB** |       **95.10** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 1000  |   681.803 μs |  42.3516 μs |  22.1507 μs | 108.32 |    3.46 |  85.9375 |   7.8125 |  1439.82 KB |       92.06 |
| NativeSingle      | TaLib.Functions.Ppo | 1000  |     6.295 μs |   0.0925 μs |   0.0612 μs |   1.00 |    0.01 |   0.9155 |        - |    15.64 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ppo | 1000  |    12.179 μs |   0.5102 μs |   0.3375 μs |   1.93 |    0.05 |   3.2959 |   0.2441 |     47.7 KB |        3.05 |
|                   |                     |       |              |             |             |        |         |          |          |             |             |
| **BuilderFull**       | **TaLib.Functions.Ppo** | **10000** | **7,525.140 μs** | **516.2387 μs** | **341.4599 μs** | **119.58** |    **5.23** | **857.1429** | **428.5714** | **14748.78 KB** |       **94.38** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 10000 | 7,575.675 μs | 605.4807 μs | 360.3118 μs | 120.38 |    5.48 | 846.1538 | 230.7692 | 14279.05 KB |       91.37 |
| NativeSingle      | TaLib.Functions.Ppo | 10000 |    62.933 μs |   0.6982 μs |   0.4155 μs |   1.00 |    0.01 |   9.2773 |   1.4648 |   156.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ppo | 10000 |   116.814 μs |   7.8877 μs |   5.2173 μs |   1.86 |    0.08 |  30.2734 |   7.8125 |   469.59 KB |        3.00 |
