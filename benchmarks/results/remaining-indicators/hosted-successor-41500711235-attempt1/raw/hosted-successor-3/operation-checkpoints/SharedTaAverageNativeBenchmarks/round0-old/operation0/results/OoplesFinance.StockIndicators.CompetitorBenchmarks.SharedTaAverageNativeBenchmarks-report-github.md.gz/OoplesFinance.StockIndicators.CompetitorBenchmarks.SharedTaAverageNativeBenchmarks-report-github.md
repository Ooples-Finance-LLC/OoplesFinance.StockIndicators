```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean     | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------------- |------ |---------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Ma** | **1000**  | **127.2 μs** |  **16.35 μs** | **10.82 μs** |  **3.9063** |       **-** |  **78.23 KB** |
| BuilderLatestOnly | TaLib.Functions.Ma | 1000  | 115.9 μs |   6.37 μs |  3.79 μs |  1.9531 |       - |  30.62 KB |
| **BuilderFull**       | **TaLib.Functions.Ma** | **10000** | **974.1 μs** | **117.18 μs** | **77.50 μs** | **39.0625** | **15.6250** | **641.14 KB** |
| BuilderLatestOnly | TaLib.Functions.Ma | 10000 | 898.2 μs |  14.81 μs |  7.75 μs |  7.8125 |       - | 171.31 KB |
