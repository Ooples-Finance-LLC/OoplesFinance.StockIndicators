```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |-----------:|-----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Ma** | **1000**  | **130.239 μs** | **12.1213 μs** | **7.2132 μs** | **57.22** |    **3.04** |  **3.9063** |       **-** |  **78.23 KB** |        **9.84** |
| BuilderLatestOnly | TaLib.Functions.Ma | 1000  | 115.848 μs |  6.2108 μs | 4.1081 μs | 50.90 |    1.76 |  1.9531 |       - |  30.62 KB |        3.85 |
| NativeSingle      | TaLib.Functions.Ma | 1000  |   2.276 μs |  0.0302 μs | 0.0180 μs |  1.00 |    0.01 |  0.4730 |       - |   7.95 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ma | 1000  |   5.064 μs |  0.1878 μs | 0.1242 μs |  2.23 |    0.05 |  1.9836 |  0.0916 |  28.37 KB |        3.57 |
|                   |                    |       |            |            |           |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Ma** | **10000** | **929.070 μs** |  **9.2420 μs** | **4.8337 μs** | **41.86** |    **0.37** | **39.0625** | **15.6250** | **641.14 KB** |        **8.19** |
| BuilderLatestOnly | TaLib.Functions.Ma | 10000 | 904.101 μs | 17.3685 μs | 9.0841 μs | 40.73 |    0.49 |  7.8125 |       - | 171.31 KB |        2.19 |
| NativeSingle      | TaLib.Functions.Ma | 10000 |  22.198 μs |  0.2644 μs | 0.1749 μs |  1.00 |    0.01 |  4.7607 |  0.7324 |  78.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ma | 10000 |  41.108 μs |  1.9816 μs | 1.3107 μs |  1.85 |    0.06 | 18.0664 |  5.3711 | 274.46 KB |        3.51 |
