```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |-------------------- |------ |-------------:|------------:|------------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Apo** | **1000**  |   **398.400 μs** | **105.3326 μs** |  **69.6710 μs** | **71.04** |   **11.86** |  **15.6250** |       **-** |   **355.3 KB** |       **22.72** |
| BuilderLatestOnly | TaLib.Functions.Apo | 1000  |   323.241 μs |  38.3184 μs |  25.3452 μs | 57.64 |    4.32 |  15.6250 |       - |  307.67 KB |       19.67 |
| NativeSingle      | TaLib.Functions.Apo | 1000  |     5.608 μs |   0.0436 μs |   0.0259 μs |  1.00 |    0.01 |   0.9460 |  0.0305 |   15.64 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Apo | 1000  |    10.212 μs |   0.2467 μs |   0.1468 μs |  1.82 |    0.03 |   3.2959 |  0.2441 |    47.7 KB |        3.05 |
|                   |                     |       |              |             |             |       |         |          |         |            |             |
| **BuilderFull**       | **TaLib.Functions.Apo** | **10000** | **2,957.554 μs** | **241.8541 μs** | **159.9715 μs** | **54.18** |    **2.83** | **187.5000** | **93.7500** | **3167.61 KB** |       **20.27** |
| BuilderLatestOnly | TaLib.Functions.Apo | 10000 | 2,963.574 μs | 255.0048 μs | 168.6699 μs | 54.29 |    2.98 | 156.2500 | 46.8750 | 2697.77 KB |       17.26 |
| NativeSingle      | TaLib.Functions.Apo | 10000 |    54.590 μs |   0.7872 μs |   0.4684 μs |  1.00 |    0.01 |   9.2773 |  1.4648 |  156.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Apo | 10000 |   107.085 μs |   8.1722 μs |   5.4054 μs |  1.96 |    0.10 |  30.2734 |  8.7891 |  469.59 KB |        3.00 |
