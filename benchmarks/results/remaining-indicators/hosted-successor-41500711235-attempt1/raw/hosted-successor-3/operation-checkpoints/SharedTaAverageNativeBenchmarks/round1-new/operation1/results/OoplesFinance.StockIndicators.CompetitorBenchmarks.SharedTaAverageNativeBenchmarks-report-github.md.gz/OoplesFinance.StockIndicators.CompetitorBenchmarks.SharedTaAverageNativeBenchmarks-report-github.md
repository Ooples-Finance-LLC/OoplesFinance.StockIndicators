```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev    | Gen0     | Gen1    | Allocated  |
|------------------ |-------------------- |------ |-----------:|----------:|----------:|---------:|--------:|-----------:|
| **BuilderFull**       | **TaLib.Functions.Apo** | **1000**  |   **370.1 μs** |   **6.39 μs** |   **3.34 μs** |  **15.6250** |       **-** |   **355.3 KB** |
| BuilderLatestOnly | TaLib.Functions.Apo | 1000  |   342.0 μs |  68.04 μs |  45.01 μs |  15.6250 |       - |  307.67 KB |
| **BuilderFull**       | **TaLib.Functions.Apo** | **10000** | **2,981.9 μs** | **166.21 μs** |  **98.91 μs** | **187.5000** | **93.7500** | **3167.61 KB** |
| BuilderLatestOnly | TaLib.Functions.Apo | 10000 | 2,980.7 μs | 213.86 μs | 141.45 μs | 156.2500 | 46.8750 | 2697.77 KB |
