```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId              | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |-------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetElderRay** |   **178.0 μs** |  **1.15 μs** |  **0.60 μs** |  **1.00** |    **0.00** |  **186.84 KB** |        **1.00** |
|        |       |                     |            |          |          |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetElderRay** | **1,604.4 μs** | **52.93 μs** | **31.50 μs** |  **1.00** |    **0.03** | **1838.27 KB** |        **1.00** |
