```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId         | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetCci** |   **200.4 μs** | **14.53 μs** |  **9.61 μs** |  **1.00** |    **0.06** |  **106.42 KB** |        **1.00** |
|        |       |                |            |          |          |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetCci** | **1,788.6 μs** | **29.73 μs** | **17.69 μs** |  **1.00** |    **0.01** | **1037.76 KB** |        **1.00** |
