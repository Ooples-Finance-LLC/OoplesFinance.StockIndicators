```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |-----------:|---------:|---------:|------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skend(...)elier [21]** |   **269.6 μs** |  **2.42 μs** |  **1.26 μs** |  **1.00** |  **145.78 KB** |        **1.00** |
|        |       |                      |            |          |          |       |            |             |
| **Ooples** | **10000** | **Skend(...)elier [21]** | **2,529.5 μs** | **42.58 μs** | **25.34 μs** |  **1.00** | **1428.07 KB** |        **1.00** |
