```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId          | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetMacd** |   **664.68 μs** | **29.803 μs** | **19.713 μs** |  **1.00** |    **0.04** |  **331.66 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetMacd |    99.33 μs |  5.999 μs |  3.138 μs |  0.15 |    0.01 |  456.69 KB |        1.38 |
|            |       |                 |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetMacd** | **6,592.60 μs** | **30.091 μs** | **17.906 μs** |  **1.00** |    **0.00** | **3266.91 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetMacd | 1,005.58 μs | 38.254 μs | 22.764 μs |  0.15 |    0.00 | 4671.85 KB |        1.43 |
