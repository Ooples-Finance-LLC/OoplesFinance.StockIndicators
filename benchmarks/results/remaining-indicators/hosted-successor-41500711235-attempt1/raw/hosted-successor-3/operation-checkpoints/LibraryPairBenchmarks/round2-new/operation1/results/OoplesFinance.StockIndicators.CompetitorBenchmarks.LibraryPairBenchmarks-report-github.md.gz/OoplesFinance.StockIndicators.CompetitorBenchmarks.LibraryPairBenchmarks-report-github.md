```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)inOsc [21]** |   **691.5 μs** |  **33.90 μs** | **20.17 μs** |  **1.00** |    **0.04** |  **259.67 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)inOsc [21] |   109.8 μs |   3.47 μs |  1.82 μs |  0.16 |    0.00 |  495.14 KB |        1.91 |
|            |       |                      |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)inOsc [21]** | **6,623.6 μs** | **129.07 μs** | **76.81 μs** |  **1.00** |    **0.02** | **2553.03 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)inOsc [21] | 1,162.7 μs |  52.21 μs | 31.07 μs |  0.18 |    0.00 | 4854.19 KB |        1.90 |
