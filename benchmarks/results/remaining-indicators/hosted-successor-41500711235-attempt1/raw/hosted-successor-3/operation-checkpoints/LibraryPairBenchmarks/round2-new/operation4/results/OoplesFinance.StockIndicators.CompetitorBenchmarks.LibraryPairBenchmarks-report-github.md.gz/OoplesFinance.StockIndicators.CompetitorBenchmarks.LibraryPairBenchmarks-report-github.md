```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetElderRay** |   **178.2 μs** |  **1.55 μs** |  **0.81 μs** |  **1.00** |    **0.01** |  **186.84 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetElderRay |   119.9 μs | 11.23 μs |  5.87 μs |  0.67 |    0.03 |  341.22 KB |        1.83 |
|            |       |                     |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetElderRay** | **1,597.4 μs** | **26.06 μs** | **15.51 μs** |  **1.00** |    **0.01** | **1838.27 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetElderRay | 1,161.1 μs | 25.69 μs | 15.29 μs |  0.73 |    0.01 | 3320.43 KB |        1.81 |
