```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetCmf** |   **200.3 μs** |  **12.54 μs** |   **6.56 μs** |  **1.00** |    **0.04** |  **189.85 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetCmf |   135.7 μs |   2.63 μs |   1.37 μs |  0.68 |    0.02 |   387.8 KB |        2.04 |
|            |       |                |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetCmf** | **1,988.3 μs** | **545.56 μs** | **360.85 μs** |  **1.03** |    **0.24** | **1841.56 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetCmf | 1,475.3 μs |  45.98 μs |  27.36 μs |  0.76 |    0.12 | 3789.45 KB |        2.06 |
