```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)oints [22]** |    **61.79 μs** |  **1.786 μs** |  **0.934 μs** |  **1.00** |    **0.02** |  **233.83 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)oints [22] |   188.09 μs | 19.283 μs | 11.475 μs |  3.04 |    0.18 |  512.27 KB |        2.19 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)oints [22]** |   **828.74 μs** |  **8.620 μs** |  **5.129 μs** |  **1.00** |    **0.01** | **2312.62 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)oints [22] | 1,817.06 μs | 47.362 μs | 24.771 μs |  2.19 |    0.03 | 5021.67 KB |        2.17 |
