```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetCci** |   **216.51 μs** | **51.389 μs** | **33.991 μs** |  **1.02** |    **0.20** |  **106.39 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetCci |    87.03 μs |  1.731 μs |  0.905 μs |  0.41 |    0.05 |  177.77 KB |        1.67 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetCci** | **1,794.46 μs** | **21.549 μs** | **11.271 μs** |  **1.00** |    **0.01** | **1037.73 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetCci |   935.23 μs | 36.283 μs | 21.591 μs |  0.52 |    0.01 | 1698.32 KB |        1.64 |
