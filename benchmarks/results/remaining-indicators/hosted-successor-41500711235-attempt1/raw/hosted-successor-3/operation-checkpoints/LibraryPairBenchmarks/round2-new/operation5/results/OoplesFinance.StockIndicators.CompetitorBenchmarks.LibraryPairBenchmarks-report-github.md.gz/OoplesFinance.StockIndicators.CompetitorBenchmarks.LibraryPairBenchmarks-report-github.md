```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetKeltner** |   **439.6 μs** | **22.02 μs** | **13.10 μs** |  **1.00** |    **0.04** |  **267.47 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetKeltner |   129.2 μs |  3.52 μs |  2.10 μs |  0.29 |    0.01 |  475.77 KB |        1.78 |
|            |       |                    |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetKeltner** | **4,234.7 μs** | **24.86 μs** | **14.79 μs** |  **1.00** |    **0.00** | **2631.14 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetKeltner | 1,361.0 μs | 44.43 μs | 26.44 μs |  0.32 |    0.01 | 4659.41 KB |        1.77 |
