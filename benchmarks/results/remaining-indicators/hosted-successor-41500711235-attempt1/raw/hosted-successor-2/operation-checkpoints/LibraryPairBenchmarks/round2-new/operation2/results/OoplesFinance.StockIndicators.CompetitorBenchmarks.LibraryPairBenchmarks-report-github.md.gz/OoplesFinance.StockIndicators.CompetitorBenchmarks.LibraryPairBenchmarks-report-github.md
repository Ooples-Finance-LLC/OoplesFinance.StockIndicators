```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Fwma** |    **55.45 μs** |  **1.017 μs** |  **0.532 μs** |  **1.00** |    **0.01** |   **15.95 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Fwma |   117.91 μs |  3.178 μs |  1.891 μs |  2.13 |    0.04 |  261.75 KB |       16.42 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Fwma** |   **776.08 μs** | **28.433 μs** | **18.807 μs** |  **1.00** |    **0.03** |  **163.13 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Fwma | 1,160.69 μs | 38.019 μs | 22.625 μs |  1.50 |    0.04 | 2572.17 KB |       15.77 |
