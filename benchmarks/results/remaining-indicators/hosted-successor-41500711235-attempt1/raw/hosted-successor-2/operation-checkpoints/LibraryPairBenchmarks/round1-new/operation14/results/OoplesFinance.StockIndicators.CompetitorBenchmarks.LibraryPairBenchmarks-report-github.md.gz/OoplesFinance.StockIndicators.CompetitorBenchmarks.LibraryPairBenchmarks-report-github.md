```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean     | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |---------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Trady(...)lator [45]** | **162.2 μs** | **45.93 μs** | **30.38 μs** |  **1.03** |    **0.25** |  **107.84 KB** |        **1.00** |
|        |       |                      |          |          |          |       |         |            |             |
| **Ooples** | **10000** | **Trady(...)lator [45]** | **597.9 μs** | **54.32 μs** | **32.32 μs** |  **1.00** |    **0.07** | **1040.16 KB** |        **1.00** |
