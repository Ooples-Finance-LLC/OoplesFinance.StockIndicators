```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)lator [50]** |    **185.0 μs** |    **19.85 μs** |    **11.81 μs** |  **1.00** |    **0.08** |         **-** |         **-** |         **-** |    **105.6 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)lator [50] |  1,810.9 μs |    18.69 μs |    11.12 μs |  9.82 |    0.57 |         - |         - |         - |  2510.77 KB |       23.78 |
|            |       |                      |             |             |             |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)lator [50]** |  **1,105.6 μs** |    **26.15 μs** |    **15.56 μs** |  **1.00** |    **0.02** |         **-** |         **-** |         **-** |  **1036.98 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)lator [50] | 21,512.6 μs | 2,040.65 μs | 1,067.30 μs | 19.46 |    0.95 | 1000.0000 | 1000.0000 | 1000.0000 | 24968.15 KB |       24.08 |
