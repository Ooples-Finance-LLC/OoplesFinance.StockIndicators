```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId        | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Wma** |   **105.2 μs** |  **1.64 μs** |  **0.86 μs** |  **1.00** |    **0.01** |   **65.77 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Wma |   106.3 μs |  3.23 μs |  1.69 μs |  1.01 |    0.02 |   261.9 KB |        3.98 |
|            |       |               |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Wma** |   **118.6 μs** | **14.43 μs** |  **7.55 μs** |  **1.00** |    **0.08** |  **636.06 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Wma | 1,062.6 μs | 57.55 μs | 34.25 μs |  8.99 |    0.59 | 2571.71 KB |        4.04 |
