```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Dwma** |    **70.99 μs** |  **9.462 μs** |  **5.631 μs** |  **1.01** |    **0.10** |   **66.41 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Dwma |   202.88 μs |  5.351 μs |  2.799 μs |  2.87 |    0.20 |  541.22 KB |        8.15 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Dwma** |   **381.50 μs** | **38.288 μs** | **25.325 μs** |  **1.00** |    **0.09** |   **636.7 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Dwma | 2,036.10 μs | 57.511 μs | 34.224 μs |  5.36 |    0.33 | 5448.84 KB |        8.56 |
