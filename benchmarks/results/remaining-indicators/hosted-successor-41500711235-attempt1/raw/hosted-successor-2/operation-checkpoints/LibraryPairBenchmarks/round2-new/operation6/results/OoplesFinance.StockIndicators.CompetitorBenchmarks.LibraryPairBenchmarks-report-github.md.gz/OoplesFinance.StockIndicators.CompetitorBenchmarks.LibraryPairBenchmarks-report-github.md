```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAdl** |   **312.22 μs** | **27.659 μs** | **16.460 μs** |  **1.00** |    **0.07** |  **246.84 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAdl |    89.56 μs |  1.629 μs |  0.852 μs |  0.29 |    0.01 |  274.31 KB |        1.11 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAdl** | **2,336.62 μs** | **34.281 μs** | **20.400 μs** |  **1.00** |    **0.01** | **2814.28 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAdl | 1,015.88 μs | 65.890 μs | 39.210 μs |  0.43 |    0.02 |  2656.2 KB |        0.94 |
