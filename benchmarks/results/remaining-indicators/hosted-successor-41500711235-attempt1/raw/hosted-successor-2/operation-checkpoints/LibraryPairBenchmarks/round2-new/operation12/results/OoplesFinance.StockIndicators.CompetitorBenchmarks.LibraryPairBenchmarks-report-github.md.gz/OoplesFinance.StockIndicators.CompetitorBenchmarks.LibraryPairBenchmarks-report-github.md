```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error        | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)gence [50]** |    **678.9 μs** |     **30.11 μs** |    **17.92 μs** |  **1.00** |    **0.04** |         **-** |         **-** |         **-** |   **290.09 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)gence [50] |  2,342.0 μs |     27.92 μs |    16.62 μs |  3.45 |    0.09 |         - |         - |         - |  3514.29 KB |       12.11 |
|            |       |                      |             |              |             |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)gence [50]** |  **6,335.6 μs** |    **100.82 μs** |    **66.69 μs** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |  **2855.53 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)gence [50] | 32,792.8 μs | 12,310.62 μs | 8,142.71 μs |  5.18 |    1.23 | 2000.0000 | 1000.0000 | 1000.0000 | 34688.72 KB |       12.15 |
