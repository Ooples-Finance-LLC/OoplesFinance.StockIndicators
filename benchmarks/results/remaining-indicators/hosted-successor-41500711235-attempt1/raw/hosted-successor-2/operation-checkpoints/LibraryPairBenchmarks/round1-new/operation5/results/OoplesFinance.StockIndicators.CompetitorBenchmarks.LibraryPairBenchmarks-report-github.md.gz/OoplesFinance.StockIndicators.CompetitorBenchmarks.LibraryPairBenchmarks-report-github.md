```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId        | Mean     | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |-------------- |---------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **QuanTAlib.Wma** | **191.5 μs** | **26.00 μs** | **17.20 μs** |  **1.01** |    **0.12** |  **65.77 KB** |        **1.00** |
|        |       |               |          |          |          |       |         |           |             |
| **Ooples** | **10000** | **QuanTAlib.Wma** | **121.7 μs** | **23.31 μs** | **12.19 μs** |  **1.01** |    **0.12** | **636.39 KB** |        **1.00** |
