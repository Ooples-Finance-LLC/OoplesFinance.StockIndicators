```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)nnels [31]** |    **364.6 μs** |     **4.98 μs** |   **2.96 μs** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |   **218.88 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)nnels [31] |  2,164.1 μs |    73.10 μs |  48.35 μs |  5.94 |    0.13 |         - |         - |         - |  3215.06 KB |       14.69 |
|            |       |                      |             |             |           |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)nnels [31]** |  **3,592.4 μs** |    **53.06 μs** |  **27.75 μs** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |  **2153.15 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)nnels [31] | 26,156.3 μs | 1,368.64 μs | 905.27 μs |  7.28 |    0.25 | 2000.0000 | 1000.0000 | 1000.0000 | 31311.07 KB |       14.54 |
