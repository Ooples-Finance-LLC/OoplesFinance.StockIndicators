```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean          | Error         | StdDev        | Ratio  | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |--------------:|--------------:|--------------:|-------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)erage [40]** |      **89.95 μs** |      **0.931 μs** |      **0.487 μs** |   **1.00** |    **0.01** |    **64.76 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)erage [40] |   3,725.54 μs |    364.724 μs |    241.242 μs |  41.42 |    2.57 |  1363.34 KB |       21.05 |
|            |       |                      |               |               |               |        |         |             |             |
| **Ooples**     | **10000** | **Trady(...)erage [40]** |     **418.58 μs** |     **63.721 μs** |     **37.919 μs** |   **1.01** |    **0.12** |   **635.38 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)erage [40] | 252,650.40 μs | 20,411.984 μs | 13,501.264 μs | 607.51 |   55.69 | 13284.71 KB |       20.91 |
