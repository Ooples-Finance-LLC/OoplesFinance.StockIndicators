```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId           | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |----------------- |-----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Afirma** |   **108.9 μs** |  **0.73 μs** |  **0.44 μs** |  **1.00** |    **0.01** |  **24.59 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Afirma |   179.2 μs | 11.09 μs |  5.80 μs |  1.65 |    0.05 |  55.73 KB |        2.27 |
|            |       |                  |            |          |          |       |         |           |             |
| **Ooples**     | **10000** | **QuanTAlib.Afirma** |   **986.3 μs** | **31.40 μs** | **20.77 μs** |  **1.00** |    **0.03** | **243.36 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Afirma | 1,775.3 μs | 24.10 μs | 14.34 μs |  1.80 |    0.04 | 477.65 KB |        1.96 |
