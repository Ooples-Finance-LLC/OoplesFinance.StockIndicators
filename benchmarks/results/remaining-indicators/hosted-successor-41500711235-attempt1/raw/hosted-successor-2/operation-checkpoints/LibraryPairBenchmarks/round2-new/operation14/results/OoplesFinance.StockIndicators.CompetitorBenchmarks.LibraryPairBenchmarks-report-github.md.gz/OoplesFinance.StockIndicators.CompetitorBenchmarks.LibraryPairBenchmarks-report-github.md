```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev   | Ratio | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|---------:|------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)lator [45]** |    **153.7 μs** |   **4.67 μs** |  **2.44 μs** |  **1.00** |    **0.02** |   **107.88 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)lator [45] |  1,455.0 μs |  39.56 μs | 26.17 μs |  9.47 |    0.22 |  1389.63 KB |       12.88 |
|            |       |                      |             |           |          |       |         |             |             |
| **Ooples**     | **10000** | **Trady(...)lator [45]** |    **537.4 μs** |  **37.78 μs** | **24.99 μs** |  **1.00** |    **0.06** |  **1040.16 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)lator [45] | 12,680.3 μs | 128.18 μs | 76.28 μs | 23.64 |    1.07 | 13491.27 KB |       12.97 |
