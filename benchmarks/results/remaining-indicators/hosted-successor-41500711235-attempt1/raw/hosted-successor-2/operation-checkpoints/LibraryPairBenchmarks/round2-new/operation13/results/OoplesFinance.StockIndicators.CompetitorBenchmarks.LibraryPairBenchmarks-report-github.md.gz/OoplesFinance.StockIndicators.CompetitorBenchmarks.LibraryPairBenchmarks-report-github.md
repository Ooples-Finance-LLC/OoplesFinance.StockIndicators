```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)ogram [59]** |    **635.5 μs** |    **14.83 μs** |     **8.83 μs** |  **1.00** |    **0.02** |         **-** |         **-** |         **-** |   **240.73 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)ogram [59] |  2,475.9 μs |    67.46 μs |    44.62 μs |  3.90 |    0.08 |         - |         - |         - |  3698.97 KB |       15.37 |
|            |       |                      |             |             |             |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)ogram [59]** |  **6,211.4 μs** |   **115.43 μs** |    **68.69 μs** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |  **2368.36 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)ogram [59] | 35,741.2 μs | 7,495.87 μs | 4,958.05 μs |  5.75 |    0.76 | 2000.0000 | 1000.0000 | 1000.0000 | 36346.91 KB |       15.35 |
