```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean         | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |-------------:|----------:|----------:|------:|--------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)Index [37]** |     **333.8 μs** |  **66.28 μs** |  **39.44 μs** |  **1.01** |    **0.17** |         **-** |         **-** |    **108.3 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)Index [37] |  13,807.9 μs | 128.24 μs |  84.82 μs | 41.93 |    5.07 |         - |         - |  4704.77 KB |       43.44 |
|            |       |                      |              |           |           |       |         |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)Index [37]** |   **2,526.1 μs** |  **24.37 μs** |  **14.50 μs** |  **1.00** |    **0.01** |         **-** |         **-** |  **1040.29 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)Index [37] | 144,273.8 μs | 612.94 μs | 320.58 μs | 57.12 |    0.33 | 2000.0000 | 1000.0000 | 48253.94 KB |       46.39 |
