```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId       | Mean        | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------- |------------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.T3** |   **229.57 μs** |  **1.981 μs** | **1.179 μs** |  **1.00** |    **0.01** |  **105.85 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.T3 |    78.47 μs |  6.424 μs | 3.823 μs |  0.34 |    0.02 |   73.67 KB |        0.70 |
|            |       |              |             |           |          |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.T3** | **2,155.42 μs** |  **9.181 μs** | **6.072 μs** |  **1.00** |    **0.00** | **1036.58 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.T3 |   634.24 μs | 12.296 μs | 7.317 μs |  0.29 |    0.00 |  645.01 KB |        0.62 |
