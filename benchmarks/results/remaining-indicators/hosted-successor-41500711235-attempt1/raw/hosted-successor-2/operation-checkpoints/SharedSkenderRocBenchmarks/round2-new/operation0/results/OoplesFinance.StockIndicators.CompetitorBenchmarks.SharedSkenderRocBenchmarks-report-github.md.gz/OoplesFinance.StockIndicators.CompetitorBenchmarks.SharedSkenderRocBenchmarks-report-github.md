```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |----------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetRocWb** | **1000**  |   **437.95 μs** |   **3.185 μs** |   **1.895 μs** |  **7.63** |    **0.25** |        **-** |        **-** |        **-** |  **105.36 KB** |        **0.46** |
| BuilderLatestOnly | Skender.GetRocWb | 1000  |   428.94 μs |   1.301 μs |   0.774 μs |  7.48 |    0.25 |        - |        - |        - |   57.72 KB |        0.25 |
| NativeSingle      | Skender.GetRocWb | 1000  |    57.45 μs |   3.009 μs |   1.990 μs |  1.00 |    0.05 |  13.6719 |   3.4180 |        - |  231.09 KB |        1.00 |
| NativeParallel    | Skender.GetRocWb | 1000  |   107.53 μs |   8.413 μs |   5.565 μs |  1.87 |    0.11 |  37.1094 |  11.7188 |        - |  586.66 KB |        2.54 |
|                   |                  |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetRocWb** | **10000** | **4,362.05 μs** |  **40.916 μs** |  **24.348 μs** |  **4.48** |    **0.10** |  **31.2500** |        **-** |        **-** | **1019.92 KB** |        **0.44** |
| BuilderLatestOnly | Skender.GetRocWb | 10000 | 4,358.10 μs |  21.197 μs |  12.614 μs |  4.48 |    0.10 |  31.2500 |        - |        - |  550.13 KB |        0.24 |
| NativeSingle      | Skender.GetRocWb | 10000 |   973.87 μs |  36.891 μs |  21.954 μs |  1.00 |    0.03 | 148.4375 | 148.4375 | 148.4375 | 2306.52 KB |        1.00 |
| NativeParallel    | Skender.GetRocWb | 10000 | 2,917.23 μs | 390.474 μs | 258.274 μs |  3.00 |    0.26 | 515.6250 | 453.1250 | 234.3750 | 5845.26 KB |        2.53 |
