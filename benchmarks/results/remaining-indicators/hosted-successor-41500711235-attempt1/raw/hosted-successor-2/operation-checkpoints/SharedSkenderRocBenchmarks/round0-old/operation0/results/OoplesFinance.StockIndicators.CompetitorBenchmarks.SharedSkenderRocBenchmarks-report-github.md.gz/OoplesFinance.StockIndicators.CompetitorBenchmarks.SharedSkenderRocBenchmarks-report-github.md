```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |----------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetRocWb** | **1000**  |   **438.1 μs** |  **0.70 μs** |  **0.37 μs** |       **-** |  **105.36 KB** |
| BuilderLatestOnly | Skender.GetRocWb | 1000  |   425.2 μs |  3.86 μs |  2.30 μs |       - |   57.72 KB |
| **BuilderFull**       | **Skender.GetRocWb** | **10000** | **4,311.3 μs** | **34.70 μs** | **18.15 μs** | **31.2500** | **1019.95 KB** |
| BuilderLatestOnly | Skender.GetRocWb | 10000 | 4,334.4 μs | 18.96 μs |  9.92 μs | 31.2500 |  550.14 KB |
