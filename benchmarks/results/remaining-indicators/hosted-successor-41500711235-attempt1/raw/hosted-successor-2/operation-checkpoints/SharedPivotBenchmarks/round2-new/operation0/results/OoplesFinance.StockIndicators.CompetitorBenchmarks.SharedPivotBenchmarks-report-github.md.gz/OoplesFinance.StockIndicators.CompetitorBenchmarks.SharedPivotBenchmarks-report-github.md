```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |------ |-----------:|----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **1000**  |   **276.0 μs** |  **83.50 μs** |  **55.23 μs** |  **0.44** |    **0.08** |   **7.8125** |        **-** |  **128.46 KB** |        **0.26** |
| BuilderLatestOnly | 1000  |   237.9 μs |  24.66 μs |  14.67 μs |  0.38 |    0.02 |   3.9063 |        - |   80.85 KB |        0.16 |
| NativeSingle      | 1000  |   627.8 μs |   8.34 μs |   4.96 μs |  1.00 |    0.01 |  27.3438 |   7.8125 |  499.64 KB |        1.00 |
| NativeParallel    | 1000  |   351.6 μs |  20.55 μs |  13.59 μs |  0.56 |    0.02 |  31.2500 |   9.7656 |  525.33 KB |        1.05 |
|                   |       |            |           |           |       |         |          |          |            |             |
| **BuilderFull**       | **10000** | **1,602.5 μs** | **102.12 μs** |  **53.41 μs** |  **0.24** |    **0.01** |  **62.5000** |  **31.2500** | **1183.62 KB** |        **0.24** |
| BuilderLatestOnly | 10000 | 1,676.3 μs | 239.76 μs | 158.59 μs |  0.25 |    0.02 |  39.0625 |  15.6250 |  713.74 KB |        0.14 |
| NativeSingle      | 10000 | 6,607.3 μs |  94.15 μs |  56.03 μs |  1.00 |    0.01 | 266.6667 | 200.0000 | 5035.35 KB |        1.00 |
| NativeParallel    | 10000 | 3,556.6 μs | 113.52 μs |  59.37 μs |  0.54 |    0.01 | 312.5000 | 218.7500 |  5131.1 KB |        1.02 |
