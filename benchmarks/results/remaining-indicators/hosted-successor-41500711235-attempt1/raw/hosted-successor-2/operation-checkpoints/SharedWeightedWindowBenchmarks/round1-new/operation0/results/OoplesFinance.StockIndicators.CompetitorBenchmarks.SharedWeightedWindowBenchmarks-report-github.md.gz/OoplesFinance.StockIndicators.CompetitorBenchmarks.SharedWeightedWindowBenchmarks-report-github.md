```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Wma**       | **1000**  |  **17.75 μs** |  **3.493 μs** |  **2.310 μs** |  **2.9297** |       **-** |  **58.42 KB** |
| BuilderLatestOnly | Wma       | 1000  |  12.03 μs |  1.932 μs |  1.278 μs |  0.6104 |       - |  10.56 KB |
| **BuilderFull**       | **Wma**       | **10000** | **113.37 μs** | **16.571 μs** |  **9.861 μs** | **33.2031** | **11.7188** | **550.95 KB** |
| BuilderLatestOnly | Wma       | 10000 |  98.21 μs | 15.164 μs | 10.030 μs |  4.8828 |       - |  80.88 KB |
