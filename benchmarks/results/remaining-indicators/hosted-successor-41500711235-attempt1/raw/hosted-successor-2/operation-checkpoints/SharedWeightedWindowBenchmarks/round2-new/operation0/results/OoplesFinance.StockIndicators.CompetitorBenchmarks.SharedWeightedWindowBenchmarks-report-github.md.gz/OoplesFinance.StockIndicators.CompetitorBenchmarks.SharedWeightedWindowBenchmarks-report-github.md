```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |---------- |------ |----------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Wma**       | **1000**  |  **22.34 μs** |  **2.314 μs** |  **1.531 μs** |  **0.28** |    **0.02** |   **2.9297** |       **-** |   **58.49 KB** |        **0.23** |
| BuilderLatestOnly | Wma       | 1000  |  11.54 μs |  1.181 μs |  0.703 μs |  0.15 |    0.01 |   0.6104 |       - |   10.56 KB |        0.04 |
| NativeSingle      | Wma       | 1000  |  78.56 μs |  2.168 μs |  1.434 μs |  1.00 |    0.02 |  15.1367 |  0.4883 |  254.32 KB |        1.00 |
| NativeParallel    | Wma       | 1000  |  69.63 μs |  6.766 μs |  4.475 μs |  0.89 |    0.06 |  16.1133 |  0.4883 |  261.98 KB |        1.03 |
|                   |           |       |           |           |           |       |         |          |         |            |             |
| **BuilderFull**       | **Wma**       | **10000** | **110.15 μs** | **13.246 μs** |  **6.928 μs** |  **0.14** |    **0.01** |  **33.2031** | **11.7188** |  **550.98 KB** |        **0.21** |
| BuilderLatestOnly | Wma       | 10000 | 101.46 μs | 13.549 μs |  8.962 μs |  0.13 |    0.01 |   4.8828 |       - |   80.88 KB |        0.03 |
| NativeSingle      | Wma       | 10000 | 776.53 μs | 39.694 μs | 26.255 μs |  1.00 |    0.05 | 156.2500 | 31.2500 | 2564.12 KB |        1.00 |
| NativeParallel    | Wma       | 10000 | 471.00 μs | 17.501 μs | 10.414 μs |  0.61 |    0.02 | 156.2500 | 31.2500 | 2571.95 KB |        1.00 |
