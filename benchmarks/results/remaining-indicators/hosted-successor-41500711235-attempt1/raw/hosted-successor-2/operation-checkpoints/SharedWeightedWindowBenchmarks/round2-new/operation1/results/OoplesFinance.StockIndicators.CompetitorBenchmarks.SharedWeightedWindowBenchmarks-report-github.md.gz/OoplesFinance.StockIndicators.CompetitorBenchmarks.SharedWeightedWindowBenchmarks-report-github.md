```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error     | StdDev   | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |---------- |------ |-----------:|----------:|---------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Dwma**      | **1000**  |   **151.3 μs** |   **9.37 μs** |  **6.20 μs** |  **0.78** |    **0.05** |   **7.8125** |       **-** |  **173.26 KB** |        **0.32** |
| BuilderLatestOnly | Dwma      | 1000  |   140.8 μs |   5.94 μs |  3.93 μs |  0.73 |    0.04 |   6.8359 |       - |  125.64 KB |        0.23 |
| NativeSingle      | Dwma      | 1000  |   194.2 μs |  15.07 μs |  9.96 μs |  1.00 |    0.07 |  32.2266 |  0.9766 |  540.12 KB |        1.00 |
| NativeParallel    | Dwma      | 1000  |   170.2 μs |   4.74 μs |  3.13 μs |  0.88 |    0.04 |  36.1328 |  0.9766 |  588.75 KB |        1.09 |
|                   |           |       |            |           |          |       |         |          |         |            |             |
| **BuilderFull**       | **Dwma**      | **10000** |   **855.9 μs** | **101.05 μs** | **66.84 μs** |  **0.46** |    **0.03** |  **93.7500** | **39.0625** | **1609.04 KB** |        **0.30** |
| BuilderLatestOnly | Dwma      | 10000 |   839.6 μs | 107.59 μs | 64.02 μs |  0.45 |    0.03 |  62.5000 |  7.8125 |  1139.2 KB |        0.21 |
| NativeSingle      | Dwma      | 10000 | 1,854.4 μs |  32.12 μs | 19.11 μs |  1.00 |    0.01 | 328.1250 | 62.5000 |    5441 KB |        1.00 |
| NativeParallel    | Dwma      | 10000 | 1,106.2 μs |  52.48 μs | 31.23 μs |  0.60 |    0.02 | 335.9375 | 62.5000 | 5489.94 KB |        1.01 |
