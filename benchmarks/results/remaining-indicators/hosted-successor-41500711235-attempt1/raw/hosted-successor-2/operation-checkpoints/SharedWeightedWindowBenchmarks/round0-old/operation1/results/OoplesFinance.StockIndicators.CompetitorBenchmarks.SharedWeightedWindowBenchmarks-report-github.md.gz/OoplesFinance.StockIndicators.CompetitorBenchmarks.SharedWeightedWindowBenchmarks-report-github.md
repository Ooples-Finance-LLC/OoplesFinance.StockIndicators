```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean     | Error     | StdDev   | Gen0    | Gen1    | Allocated  |
|------------------ |---------- |------ |---------:|----------:|---------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Dwma**      | **1000**  | **143.7 μs** |   **3.74 μs** |  **2.47 μs** |  **7.8125** |       **-** |  **173.26 KB** |
| BuilderLatestOnly | Dwma      | 1000  | 142.4 μs |   1.95 μs |  1.29 μs |  6.8359 |       - |  125.64 KB |
| **BuilderFull**       | **Dwma**      | **10000** | **885.3 μs** | **101.66 μs** | **67.24 μs** | **93.7500** | **39.0625** | **1609.04 KB** |
| BuilderLatestOnly | Dwma      | 10000 | 794.1 μs |  15.05 μs |  7.87 μs | 62.5000 |  7.8125 |  1139.2 KB |
