```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |   **528.8 μs** | **22.15 μs** | **13.18 μs** |       **-** |  **73.68 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |   520.4 μs | 14.40 μs |  8.57 μs |       - |  26.05 KB |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** | **5,128.6 μs** | **79.76 μs** | **47.47 μs** | **31.2500** | **707.05 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 | 5,100.3 μs | 41.40 μs | 21.65 μs |       - | 237.22 KB |
