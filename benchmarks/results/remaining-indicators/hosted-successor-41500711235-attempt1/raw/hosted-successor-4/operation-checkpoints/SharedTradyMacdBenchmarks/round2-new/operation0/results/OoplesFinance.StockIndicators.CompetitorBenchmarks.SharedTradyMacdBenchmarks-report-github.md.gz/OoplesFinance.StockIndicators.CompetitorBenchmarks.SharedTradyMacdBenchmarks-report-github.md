```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |    **545.3 μs** |     **3.36 μs** |     **1.76 μs** |  **0.27** |    **0.00** |         **-** |         **-** |         **-** |   **104.99 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |    543.0 μs |     3.59 μs |     2.13 μs |  0.27 |    0.00 |         - |         - |         - |    57.39 KB |        0.02 |
| NativeSingle      | Movin(...)gence [34] | 1000  |  2,018.7 μs |    47.03 μs |    31.11 μs |  1.00 |    0.02 |  203.1250 |  140.6250 |   46.8750 |  3232.15 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 1000  |  1,786.8 μs |    52.94 μs |    27.69 μs |  0.89 |    0.02 |  359.3750 |  171.8750 |         - |  5670.92 KB |        1.75 |
|                   |                      |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** |  **5,287.0 μs** |    **33.11 μs** |    **17.32 μs** |  **0.24** |    **0.02** |   **31.2500** |         **-** |         **-** |  **1019.63 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 |  5,277.0 μs |    22.51 μs |    14.89 μs |  0.23 |    0.02 |   31.2500 |         - |         - |   549.84 KB |        0.02 |
| NativeSingle      | Movin(...)gence [34] | 10000 | 22,737.3 μs | 3,955.82 μs | 2,616.53 μs |  1.01 |    0.15 | 2250.0000 | 1500.0000 | 1250.0000 | 31914.93 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 10000 | 24,046.2 μs | 1,648.30 μs | 1,090.25 μs |  1.07 |    0.12 | 3200.0000 | 2200.0000 | 1400.0000 | 56070.54 KB |        1.76 |
