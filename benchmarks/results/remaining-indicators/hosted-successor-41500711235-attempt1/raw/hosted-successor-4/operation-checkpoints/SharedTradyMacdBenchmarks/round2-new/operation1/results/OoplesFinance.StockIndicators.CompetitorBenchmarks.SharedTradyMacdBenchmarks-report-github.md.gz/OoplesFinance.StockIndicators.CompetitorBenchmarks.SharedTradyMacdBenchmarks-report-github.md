```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |    **521.3 μs** |     **2.61 μs** |     **1.55 μs** |  **0.24** |    **0.01** |         **-** |         **-** |         **-** |    **73.68 KB** |       **0.022** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |    531.4 μs |     3.26 μs |     1.94 μs |  0.25 |    0.01 |         - |         - |         - |    26.05 KB |       0.008 |
| NativeSingle      | Movin(...)ogram [43] | 1000  |  2,134.3 μs |    95.89 μs |    63.42 μs |  1.00 |    0.04 |  203.1250 |  109.3750 |   46.8750 |  3389.09 KB |       1.000 |
| NativeParallel    | Movin(...)ogram [43] | 1000  |  1,891.6 μs |   144.38 μs |    95.50 μs |  0.89 |    0.05 |  359.3750 |  171.8750 |         - |  5597.42 KB |       1.652 |
|                   |                      |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** |  **5,169.2 μs** |    **46.86 μs** |    **24.51 μs** |  **0.23** |    **0.01** |   **31.2500** |         **-** |         **-** |   **707.03 KB** |       **0.021** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 |  5,144.3 μs |    20.63 μs |    12.28 μs |  0.23 |    0.01 |         - |         - |         - |   236.97 KB |       0.007 |
| NativeSingle      | Movin(...)ogram [43] | 10000 | 22,293.7 μs | 1,538.14 μs | 1,017.38 μs |  1.00 |    0.06 | 2000.0000 | 1400.0000 | 1000.0000 | 33358.72 KB |       1.000 |
| NativeParallel    | Movin(...)ogram [43] | 10000 | 23,906.5 μs | 1,682.67 μs | 1,112.98 μs |  1.07 |    0.07 | 3000.0000 | 2200.0000 | 1200.0000 |  55280.6 KB |       1.657 |
