```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |   **513.8 μs** |  **1.04 μs** |  **0.54 μs** |       **-** |  **73.68 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |   513.4 μs |  4.59 μs |  2.73 μs |       - |  26.05 KB |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** | **5,069.9 μs** | **35.16 μs** | **18.39 μs** | **31.2500** | **707.04 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 | 5,147.9 μs | 53.94 μs | 32.10 μs |       - | 237.21 KB |
