```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetCci** | **1000**  |   **227.35 μs** |  **56.619 μs** |  **37.450 μs** |  **2.63** |    **0.42** |       **-** |       **-** |   **66.78 KB** |        **0.46** |
| BuilderLatestOnly | Skender.GetCci | 1000  |   211.75 μs |  22.516 μs |  14.893 μs |  2.45 |    0.17 |       - |       - |   19.13 KB |        0.13 |
| NativeSingle      | Skender.GetCci | 1000  |    86.45 μs |   3.153 μs |   2.085 μs |  1.00 |    0.03 |  8.7891 |  1.9531 |  145.01 KB |        1.00 |
| NativeParallel    | Skender.GetCci | 1000  |    76.60 μs |   7.240 μs |   4.789 μs |  0.89 |    0.06 |  9.7656 |  1.9531 |  162.64 KB |        1.12 |
|                   |                |       |             |            |            |       |         |         |         |            |             |
| **BuilderFull**       | **Skender.GetCci** | **10000** | **1,707.97 μs** | **187.216 μs** | **123.832 μs** |  **1.79** |    **0.12** | **31.2500** | **15.6250** |  **629.71 KB** |        **0.44** |
| BuilderLatestOnly | Skender.GetCci | 10000 | 1,609.50 μs |  25.537 μs |  13.357 μs |  1.69 |    0.02 |       - |       - |  159.85 KB |        0.11 |
| NativeSingle      | Skender.GetCci | 10000 |   952.31 μs |   7.746 μs |   5.124 μs |  1.00 |    0.01 | 85.9375 | 39.0625 | 1445.85 KB |        1.00 |
| NativeParallel    | Skender.GetCci | 10000 |   580.05 μs |  59.259 μs |  39.196 μs |  0.61 |    0.04 | 97.6563 | 46.8750 | 1533.76 KB |        1.06 |
