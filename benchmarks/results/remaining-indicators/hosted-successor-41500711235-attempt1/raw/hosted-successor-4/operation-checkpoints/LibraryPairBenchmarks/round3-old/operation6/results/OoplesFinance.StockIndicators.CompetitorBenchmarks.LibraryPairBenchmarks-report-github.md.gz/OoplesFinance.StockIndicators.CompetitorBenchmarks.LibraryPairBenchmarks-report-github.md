```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId        | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |-------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetT3** |   **283.9 μs** | **20.36 μs** | **13.47 μs** |  **1.00** |    **0.06** |  **105.89 KB** |        **1.00** |
|        |       |               |            |          |          |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetT3** | **2,145.2 μs** |  **7.72 μs** |  **4.59 μs** |  **1.00** |    **0.00** | **1036.91 KB** |        **1.00** |
