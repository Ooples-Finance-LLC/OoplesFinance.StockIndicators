```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)ivots [24]** |   **331.9 μs** |  **35.93 μs** |  **21.38 μs** |  **1.00** |    **0.08** |  **388.09 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)ivots [24] |   823.5 μs |  29.60 μs |  17.61 μs |  2.49 |    0.15 |  738.16 KB |        1.90 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)ivots [24]** | **3,514.0 μs** |  **58.87 μs** |  **35.03 μs** |  **1.00** |    **0.01** | **3849.74 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)ivots [24] | 8,689.1 μs | 263.43 μs | 156.76 μs |  2.47 |    0.05 | 7321.55 KB |        1.90 |
