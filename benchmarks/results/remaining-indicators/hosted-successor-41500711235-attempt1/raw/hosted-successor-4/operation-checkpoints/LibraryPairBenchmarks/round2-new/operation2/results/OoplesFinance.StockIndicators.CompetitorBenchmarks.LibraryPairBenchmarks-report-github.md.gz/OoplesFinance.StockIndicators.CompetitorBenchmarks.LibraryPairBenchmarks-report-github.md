```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId           | Mean        | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |----------------- |------------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetRocWb** |   **462.74 μs** |  **2.545 μs** |  **1.331 μs** |  **1.00** |  **172.57 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetRocWb |    92.60 μs |  3.631 μs |  1.899 μs |  0.20 |   275.7 KB |        1.60 |
|            |       |                  |             |           |           |       |            |             |
| **Ooples**     | **10000** | **Skender.GetRocWb** | **4,549.61 μs** | **39.340 μs** | **23.410 μs** |  **1.00** | **1691.51 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetRocWb |   968.83 μs | 44.369 μs | 26.403 μs |  0.21 | 2666.65 KB |        1.58 |
