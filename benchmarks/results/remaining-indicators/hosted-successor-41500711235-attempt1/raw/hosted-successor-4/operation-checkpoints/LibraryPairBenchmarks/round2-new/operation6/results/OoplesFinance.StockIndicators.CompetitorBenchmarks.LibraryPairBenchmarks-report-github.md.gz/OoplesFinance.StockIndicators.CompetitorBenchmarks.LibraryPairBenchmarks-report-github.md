```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId        | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetT3** |   **237.33 μs** | **26.751 μs** | **15.919 μs** |  **1.00** |    **0.09** |  **105.81 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetT3 |    49.58 μs |  1.320 μs |  0.690 μs |  0.21 |    0.01 |  115.32 KB |        1.09 |
|            |       |               |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetT3** | **2,155.21 μs** |  **7.974 μs** |  **5.274 μs** |  **1.00** |    **0.00** | **1036.49 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetT3 |   538.77 μs | 35.294 μs | 21.003 μs |  0.25 |    0.01 |    1073 KB |        1.04 |
