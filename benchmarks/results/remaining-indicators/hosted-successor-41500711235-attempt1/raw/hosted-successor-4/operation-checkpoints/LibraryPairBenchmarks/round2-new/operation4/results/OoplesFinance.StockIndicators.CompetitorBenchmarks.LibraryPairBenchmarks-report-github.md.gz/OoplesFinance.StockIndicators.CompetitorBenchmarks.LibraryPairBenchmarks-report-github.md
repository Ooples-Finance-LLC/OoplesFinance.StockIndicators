```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)lysis [22]** |   **427.0 μs** |  **33.39 μs** | **19.87 μs** |  **1.00** |    **0.06** |  **298.78 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)lysis [22] |   115.9 μs |   3.40 μs |  2.02 μs |  0.27 |    0.01 |  284.68 KB |        0.95 |
|            |       |                      |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)lysis [22]** | **3,460.4 μs** | **142.24 μs** | **74.39 μs** |  **1.00** |    **0.03** | **2876.64 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)lysis [22] | 1,283.1 μs |  49.23 μs | 32.56 μs |  0.37 |    0.01 | 2822.45 KB |        0.98 |
