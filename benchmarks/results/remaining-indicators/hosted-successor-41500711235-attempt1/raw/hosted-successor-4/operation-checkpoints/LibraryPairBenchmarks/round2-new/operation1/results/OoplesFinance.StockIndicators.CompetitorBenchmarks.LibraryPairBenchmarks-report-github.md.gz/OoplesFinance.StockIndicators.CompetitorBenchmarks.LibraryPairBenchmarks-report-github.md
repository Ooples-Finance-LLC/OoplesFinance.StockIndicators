```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error    | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|---------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetPvo** |   **791.68 μs** | **32.28 μs** | **19.212 μs** |  **1.00** |    **0.03** |  **290.09 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetPvo |    87.41 μs | 13.00 μs |  7.737 μs |  0.11 |    0.01 |  374.98 KB |        1.29 |
|            |       |                |             |          |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetPvo** | **7,785.82 μs** | **59.17 μs** | **30.949 μs** |  **1.00** |    **0.01** | **2852.25 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetPvo |   854.90 μs | 31.74 μs | 18.890 μs |  0.11 |    0.00 | 3870.98 KB |        1.36 |
