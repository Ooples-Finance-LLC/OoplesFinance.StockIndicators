```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetPrs** |   **516.1 μs** | **30.22 μs** | **17.98 μs** |  **1.00** |    **0.05** | **1079.56 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetPrs |   104.9 μs |  9.85 μs |  5.86 μs |  0.20 |    0.01 |     255 KB |        0.24 |
|            |       |                |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetPrs** | **4,208.1 μs** | **95.99 μs** | **57.12 μs** |  **1.00** |    **0.02** | **10606.6 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetPrs | 1,089.8 μs | 55.05 μs | 32.76 μs |  0.26 |    0.01 | 2461.66 KB |        0.23 |
