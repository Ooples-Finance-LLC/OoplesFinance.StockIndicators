```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |  **59.73 μs** | **2.413 μs** | **1.436 μs** |  **3.9063** |       **-** |  **88.31 KB** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |  54.88 μs | 0.347 μs | 0.182 μs |  2.4414 |       - |   40.7 KB |
| **BuilderFull**       | **Skender.GetAdl** | **10000** | **570.89 μs** | **9.084 μs** | **5.406 μs** | **50.7813** | **15.6250** | **862.13 KB** |
| BuilderLatestOnly | Skender.GetAdl | 10000 | 546.47 μs | 7.928 μs | 5.244 μs | 23.4375 |  7.8125 |  392.3 KB |
