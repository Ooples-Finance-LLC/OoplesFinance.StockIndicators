```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |    **58.69 μs** |   **0.804 μs** |  **0.420 μs** |  **0.74** |    **0.01** |   **3.9063** |        **-** |   **88.31 KB** |        **0.50** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |    56.19 μs |   0.584 μs |  0.305 μs |  0.71 |    0.00 |   2.4414 |        - |    40.7 KB |        0.23 |
| NativeSingle      | Skender.GetAdl | 1000  |    79.03 μs |   0.745 μs |  0.390 μs |  1.00 |    0.01 |  10.7422 |   2.4414 |  176.21 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 1000  |   148.07 μs |  14.526 μs |  9.608 μs |  1.87 |    0.12 |  28.3203 |   8.7891 |   449.4 KB |        2.55 |
|                   |                |       |             |            |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetAdl** | **10000** |   **578.64 μs** |   **6.943 μs** |  **3.631 μs** |  **0.62** |    **0.01** |  **50.7813** |  **15.6250** |  **862.13 KB** |        **0.49** |
| BuilderLatestOnly | Skender.GetAdl | 10000 |   553.91 μs |   8.406 μs |  5.002 μs |  0.60 |    0.01 |  23.4375 |   7.8125 |   392.3 KB |        0.22 |
| NativeSingle      | Skender.GetAdl | 10000 |   927.37 μs |  23.859 μs | 15.781 μs |  1.00 |    0.02 | 101.5625 |  62.5000 |  1758.3 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 10000 | 1,528.07 μs | 134.103 μs | 88.701 μs |  1.65 |    0.10 | 273.4375 | 187.5000 | 4474.84 KB |        2.54 |
