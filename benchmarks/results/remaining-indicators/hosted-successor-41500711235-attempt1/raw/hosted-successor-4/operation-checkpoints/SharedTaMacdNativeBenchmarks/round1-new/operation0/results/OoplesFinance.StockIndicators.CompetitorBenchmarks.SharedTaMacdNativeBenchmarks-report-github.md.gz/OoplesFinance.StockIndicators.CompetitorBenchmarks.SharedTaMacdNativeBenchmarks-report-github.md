```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error       | StdDev      | Median     | Gen0     | Gen1     | Allocated  |
|------------------ |--------------------- |------ |-----------:|------------:|------------:|-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **1000**  | **1,415.8 μs** | **1,658.90 μs** | **1,097.26 μs** |   **860.4 μs** |  **31.2500** |        **-** |   **665.1 KB** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 1000  |   510.1 μs |    15.83 μs |     8.28 μs |   507.2 μs |  31.2500 |        - |  617.49 KB |
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **10000** | **5,230.7 μs** |   **603.41 μs** |   **399.12 μs** | **5,005.0 μs** | **375.0000** | **187.5000** | **6140.94 KB** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 10000 | 5,045.9 μs |   366.26 μs |   242.26 μs | 4,944.0 μs | 343.7500 | 156.2500 | 5671.09 KB |
