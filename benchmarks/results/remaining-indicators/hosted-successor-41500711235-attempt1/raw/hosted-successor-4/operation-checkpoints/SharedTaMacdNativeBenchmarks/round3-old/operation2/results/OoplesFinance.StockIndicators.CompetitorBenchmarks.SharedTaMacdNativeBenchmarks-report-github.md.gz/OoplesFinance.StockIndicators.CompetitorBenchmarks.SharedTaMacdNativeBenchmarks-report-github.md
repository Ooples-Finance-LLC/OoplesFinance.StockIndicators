```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **1000**  |   **439.4 μs** |  **1.41 μs** |  **0.84 μs** |       **-** |  **81.36 KB** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 1000  |   427.6 μs |  1.19 μs |  0.71 μs |       - |  33.69 KB |
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **10000** | **4,355.2 μs** | **23.36 μs** | **13.90 μs** | **31.2500** | **785.03 KB** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 10000 | 4,324.6 μs | 10.78 μs |  6.41 μs |       - | 315.19 KB |
