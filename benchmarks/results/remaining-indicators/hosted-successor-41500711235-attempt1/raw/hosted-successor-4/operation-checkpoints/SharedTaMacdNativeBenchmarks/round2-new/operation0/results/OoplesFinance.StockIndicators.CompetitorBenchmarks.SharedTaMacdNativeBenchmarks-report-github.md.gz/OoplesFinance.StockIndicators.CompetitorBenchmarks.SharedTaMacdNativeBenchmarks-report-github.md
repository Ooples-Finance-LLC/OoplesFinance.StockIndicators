```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **1000**  |   **985.02 μs** |  **88.119 μs** |  **46.088 μs** | **98.33** |    **6.32** |  **31.2500** |        **-** |   **665.1 KB** |       **17.30** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 1000  |   519.61 μs |   7.979 μs |   4.173 μs | 51.87 |    2.45 |  31.2500 |        - |   617.5 KB |       16.06 |
| NativeSingle      | TaLib(...)cdExt [23] | 1000  |    10.04 μs |   0.745 μs |   0.493 μs |  1.00 |    0.07 |   2.3193 |   0.1221 |   38.45 KB |        1.00 |
| NativeParallel    | TaLib(...)cdExt [23] | 1000  |    19.25 μs |   0.527 μs |   0.348 μs |  1.92 |    0.10 |   8.1787 |   1.3428 |  120.22 KB |        3.13 |
|                   |                      |       |             |            |            |       |         |          |          |            |             |
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **10000** | **5,178.67 μs** | **402.601 μs** | **266.296 μs** | **52.80** |    **3.21** | **375.0000** | **187.5000** | **6140.94 KB** |       **15.75** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 10000 | 5,423.10 μs | 947.131 μs | 626.469 μs | 55.29 |    6.41 | 312.5000 | 125.0000 | 5671.36 KB |       14.54 |
| NativeSingle      | TaLib(...)cdExt [23] | 10000 |    98.22 μs |   5.708 μs |   3.776 μs |  1.00 |    0.05 |  23.4375 |   7.8125 |  390.02 KB |        1.00 |
| NativeParallel    | TaLib(...)cdExt [23] | 10000 |   184.63 μs |  10.980 μs |   7.263 μs |  1.88 |    0.10 |  76.1719 |  34.1797 | 1210.07 KB |        3.10 |
