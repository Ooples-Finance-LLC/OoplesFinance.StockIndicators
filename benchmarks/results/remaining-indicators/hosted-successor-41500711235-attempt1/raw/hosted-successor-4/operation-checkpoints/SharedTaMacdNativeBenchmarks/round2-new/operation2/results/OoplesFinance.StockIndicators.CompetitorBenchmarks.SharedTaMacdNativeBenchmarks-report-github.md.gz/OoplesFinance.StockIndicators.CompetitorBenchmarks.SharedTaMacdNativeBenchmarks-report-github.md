```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **1000**  |   **446.68 μs** | **17.074 μs** | **10.160 μs** | **34.40** |    **0.87** |       **-** |       **-** |   **81.36 KB** |        **2.13** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 1000  |   427.36 μs |  2.605 μs |  1.723 μs | 32.91 |    0.45 |       - |       - |   33.72 KB |        0.88 |
| NativeSingle      | TaLib(...)cdFix [23] | 1000  |    12.99 μs |  0.297 μs |  0.177 μs |  1.00 |    0.02 |  2.3193 |  0.1221 |   38.27 KB |        1.00 |
| NativeParallel    | TaLib(...)cdFix [23] | 1000  |    20.21 μs |  0.977 μs |  0.646 μs |  1.56 |    0.05 |  7.8125 |  1.2207 |  119.47 KB |        3.12 |
|                   |                      |       |             |           |           |       |         |         |         |            |             |
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **10000** | **4,358.02 μs** | **32.242 μs** | **21.326 μs** | **35.32** |    **0.57** | **31.2500** |       **-** |  **785.03 KB** |        **2.01** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 10000 | 4,338.27 μs | 74.722 μs | 44.466 μs | 35.16 |    0.65 |       - |       - |  315.19 KB |        0.81 |
| NativeSingle      | TaLib(...)cdFix [23] | 10000 |   123.43 μs |  3.096 μs |  2.048 μs |  1.00 |    0.02 | 23.4375 |       - |  389.84 KB |        1.00 |
| NativeParallel    | TaLib(...)cdFix [23] | 10000 |   213.10 μs |  9.276 μs |  5.520 μs |  1.73 |    0.05 | 74.2188 | 31.2500 | 1209.33 KB |        3.10 |
