```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Macd** | **1000**  |   **425.2 μs** |  **2.04 μs** |  **1.07 μs** |       **-** |  **81.29 KB** |
| BuilderLatestOnly | TaLib.Functions.Macd | 1000  |   421.9 μs |  5.72 μs |  3.79 μs |       - |  33.63 KB |
| **BuilderFull**       | **TaLib.Functions.Macd** | **10000** | **4,308.6 μs** | **41.71 μs** | **24.82 μs** | **31.2500** | **784.94 KB** |
| BuilderLatestOnly | TaLib.Functions.Macd | 10000 | 4,219.2 μs | 20.25 μs | 12.05 μs |       - | 315.13 KB |
