```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev   | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|---------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Macd** | **1000**  |   **432.66 μs** |  **2.088 μs** | **1.092 μs** | **32.35** |    **0.30** |       **-** |       **-** |   **81.29 KB** |        **2.12** |
| BuilderLatestOnly | TaLib.Functions.Macd | 1000  |   417.38 μs |  2.600 μs | 1.360 μs | 31.21 |    0.29 |       - |       - |   33.66 KB |        0.88 |
| NativeSingle      | TaLib.Functions.Macd | 1000  |    13.38 μs |  0.186 μs | 0.123 μs |  1.00 |    0.01 |  2.3193 |  0.1221 |   38.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Macd | 1000  |    20.68 μs |  1.279 μs | 0.846 μs |  1.55 |    0.06 |  7.8125 |  1.2207 |  119.47 KB |        3.12 |
|                   |                      |       |             |           |          |       |         |         |         |            |             |
| **BuilderFull**       | **TaLib.Functions.Macd** | **10000** | **4,243.65 μs** |  **9.773 μs** | **5.111 μs** | **32.82** |    **0.72** | **31.2500** |       **-** |  **784.95 KB** |        **2.01** |
| BuilderLatestOnly | TaLib.Functions.Macd | 10000 | 4,255.20 μs | 15.923 μs | 8.328 μs | 32.91 |    0.73 |       - |       - |  315.08 KB |        0.81 |
| NativeSingle      | TaLib.Functions.Macd | 10000 |   129.38 μs |  4.571 μs | 3.023 μs |  1.00 |    0.03 | 23.4375 |       - |  389.83 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Macd | 10000 |   210.52 μs |  6.566 μs | 4.343 μs |  1.63 |    0.05 | 74.2188 | 29.2969 | 1209.33 KB |        3.10 |
