```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Macd** | **1000**  |   **431.4 μs** |  **1.49 μs** |  **0.89 μs** |       **-** |  **81.29 KB** |
| BuilderLatestOnly | TaLib.Functions.Macd | 1000  |   422.9 μs |  1.39 μs |  0.73 μs |       - |  33.66 KB |
| **BuilderFull**       | **TaLib.Functions.Macd** | **10000** | **4,273.4 μs** | **11.53 μs** |  **6.03 μs** | **31.2500** | **784.84 KB** |
| BuilderLatestOnly | TaLib.Functions.Macd | 10000 | 4,251.0 μs | 23.71 μs | 15.68 μs |       - | 315.13 KB |
