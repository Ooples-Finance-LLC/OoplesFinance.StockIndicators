```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **1000**  |   **432.3 μs** |  **1.57 μs** |  **0.93 μs** |       **-** |  **81.36 KB** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 1000  |   427.9 μs |  6.03 μs |  3.59 μs |       - |  33.72 KB |
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **10000** | **4,311.5 μs** | **21.67 μs** | **11.33 μs** | **31.2500** | **785.02 KB** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 10000 | 4,343.0 μs | 15.06 μs |  8.96 μs |       - | 315.19 KB |
