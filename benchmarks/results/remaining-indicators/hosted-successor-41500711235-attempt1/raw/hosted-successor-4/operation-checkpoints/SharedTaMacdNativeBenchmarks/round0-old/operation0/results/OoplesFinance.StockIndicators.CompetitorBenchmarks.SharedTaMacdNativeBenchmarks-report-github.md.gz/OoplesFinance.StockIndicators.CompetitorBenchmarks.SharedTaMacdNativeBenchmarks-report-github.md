```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **1000**  |   **664.4 μs** |  **42.85 μs** |  **22.41 μs** |  **31.2500** |        **-** |   **665.1 KB** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 1000  |   513.6 μs |  59.00 μs |  35.11 μs |  31.2500 |        - |  617.49 KB |
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **10000** | **5,014.2 μs** | **333.68 μs** | **198.57 μs** | **375.0000** | **187.5000** | **6140.93 KB** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 10000 | 5,159.5 μs | 412.85 μs | 245.68 μs | 343.7500 | 156.2500 | 5671.11 KB |
