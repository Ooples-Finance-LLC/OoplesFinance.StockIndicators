```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error       | StdDev    | Ratio | RatioSD | Gen0      | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------------ |---------------- |------ |------------:|------------:|----------:|------:|--------:|----------:|---------:|---------:|----------:|------------:|
| **BuilderFull**       | **Skender.GetBeta** | **1000**  |  **1,246.0 μs** |   **308.55 μs** | **204.08 μs** |  **4.57** |    **0.72** |   **76.9231** |        **-** |        **-** |   **1.29 MB** |        **0.52** |
| BuilderLatestOnly | Skender.GetBeta | 1000  |  1,063.3 μs |    58.39 μs |  38.62 μs |  3.90 |    0.17 |   78.1250 |  15.6250 |        - |   1.24 MB |        0.50 |
| NativeSingle      | Skender.GetBeta | 1000  |    273.0 μs |    10.56 μs |   6.99 μs |  1.00 |    0.03 |  154.2969 |  42.9688 |        - |   2.47 MB |        1.00 |
| NativeParallel    | Skender.GetBeta | 1000  |    195.2 μs |     8.91 μs |   4.66 μs |  0.72 |    0.02 |  158.2031 |  46.8750 |        - |    2.5 MB |        1.01 |
|                   |                 |       |             |             |           |       |         |           |          |          |           |             |
| **BuilderFull**       | **Skender.GetBeta** | **10000** | **11,695.4 μs** | **1,366.47 μs** | **813.16 μs** |  **2.23** |    **0.37** |  **750.0000** | **625.0000** |        **-** |  **12.96 MB** |        **0.52** |
| BuilderLatestOnly | Skender.GetBeta | 10000 | 10,981.7 μs |   505.77 μs | 334.53 μs |  2.10 |    0.32 |  700.0000 | 500.0000 |        - |   12.5 MB |        0.50 |
| NativeSingle      | Skender.GetBeta | 10000 |  5,353.4 μs | 1,264.17 μs | 836.17 μs |  1.02 |    0.22 | 1718.7500 | 843.7500 | 187.5000 |  25.13 MB |        1.00 |
| NativeParallel    | Skender.GetBeta | 10000 |  2,844.9 μs |   171.65 μs |  89.78 μs |  0.54 |    0.08 | 1640.6250 | 765.6250 |  46.8750 |  25.23 MB |        1.00 |
