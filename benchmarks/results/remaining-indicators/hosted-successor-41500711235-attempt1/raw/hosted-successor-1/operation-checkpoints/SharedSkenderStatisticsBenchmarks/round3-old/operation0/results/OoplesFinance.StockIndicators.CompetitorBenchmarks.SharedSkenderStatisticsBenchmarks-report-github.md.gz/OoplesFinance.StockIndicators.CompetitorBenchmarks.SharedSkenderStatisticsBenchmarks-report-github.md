```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Gen0     | Gen1     | Allocated |
|------------------ |---------------- |------ |----------:|----------:|----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetBeta** | **1000**  |  **1.376 ms** | **0.3345 ms** | **0.2213 ms** |  **71.4286** |        **-** |   **1.29 MB** |
| BuilderLatestOnly | Skender.GetBeta | 1000  |  1.034 ms | 0.0400 ms | 0.0264 ms |  78.1250 |  15.6250 |   1.24 MB |
| **BuilderFull**       | **Skender.GetBeta** | **10000** | **11.291 ms** | **0.5024 ms** | **0.3323 ms** | **777.7778** | **666.6667** |  **12.96 MB** |
| BuilderLatestOnly | Skender.GetBeta | 10000 | 11.571 ms | 0.8815 ms | 0.5830 ms | 777.7778 | 555.5556 |   12.5 MB |
