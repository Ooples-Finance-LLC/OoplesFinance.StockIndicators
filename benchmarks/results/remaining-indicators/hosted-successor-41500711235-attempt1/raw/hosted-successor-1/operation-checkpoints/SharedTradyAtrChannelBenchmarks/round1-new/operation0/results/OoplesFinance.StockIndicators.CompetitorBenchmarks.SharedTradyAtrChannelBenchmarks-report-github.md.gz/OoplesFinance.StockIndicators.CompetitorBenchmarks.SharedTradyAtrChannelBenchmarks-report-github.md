```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **ChandelierExit** | **1000**  |   **125.6 μs** |  **3.62 μs** |  **2.15 μs** |  **3.9063** |       **-** |  **73.65 KB** |
| BuilderLatestOnly | ChandelierExit | 1000  |   124.8 μs |  3.13 μs |  1.86 μs |  0.9766 |       - |  26.04 KB |
| **BuilderFull**       | **ChandelierExit** | **10000** | **1,491.4 μs** | **30.99 μs** | **16.21 μs** | **39.0625** | **15.6250** | **706.85 KB** |
| BuilderLatestOnly | ChandelierExit | 10000 | 1,472.7 μs | 41.08 μs | 27.17 μs |  7.8125 |       - | 237.01 KB |
