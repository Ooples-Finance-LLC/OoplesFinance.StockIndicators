```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **KeltnerChannels** | **1000**  |   **169.3 μs** |  **6.76 μs** |  **4.47 μs** |       **-** |       **-** |  **96.83 KB** |
| BuilderLatestOnly | KeltnerChannels | 1000  |   163.0 μs |  8.91 μs |  5.30 μs |  1.9531 |       - |  49.23 KB |
| **BuilderFull**       | **KeltnerChannels** | **10000** | **1,705.1 μs** | **52.64 μs** | **34.82 μs** | **46.8750** | **15.6250** |    **941 KB** |
| BuilderLatestOnly | KeltnerChannels | 10000 | 1,685.6 μs | 82.77 μs | 49.25 μs | 15.6250 |       - | 471.21 KB |
