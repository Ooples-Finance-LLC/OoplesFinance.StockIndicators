```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |---------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **KeltnerChannels** | **1000**  |    **165.5 μs** |     **1.80 μs** |     **0.94 μs** |  **0.17** |    **0.00** |    **3.9063** |         **-** |         **-** |    **96.79 KB** |        **0.04** |
| BuilderLatestOnly | KeltnerChannels | 1000  |    165.3 μs |     6.84 μs |     3.58 μs |  0.17 |    0.00 |    2.9297 |         - |         - |    49.22 KB |        0.02 |
| NativeSingle      | KeltnerChannels | 1000  |    988.7 μs |    20.87 μs |    10.92 μs |  1.00 |    0.01 |  156.2500 |  101.5625 |   46.8750 |  2743.21 KB |        1.00 |
| NativeParallel    | KeltnerChannels | 1000  |    736.1 μs |    25.47 μs |    15.16 μs |  0.74 |    0.02 |  281.2500 |  125.0000 |         - |  4354.09 KB |        1.59 |
|                   |                 |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **KeltnerChannels** | **10000** |  **1,660.0 μs** |    **80.70 μs** |    **53.38 μs** |  **0.14** |    **0.01** |   **46.8750** |   **15.6250** |         **-** |   **940.97 KB** |        **0.04** |
| BuilderLatestOnly | KeltnerChannels | 10000 |  1,641.6 μs |    26.64 μs |    13.93 μs |  0.13 |    0.01 |   15.6250 |         - |         - |   471.18 KB |        0.02 |
| NativeSingle      | KeltnerChannels | 10000 | 12,248.1 μs | 1,445.66 μs |   956.21 μs |  1.01 |    0.11 | 1555.5556 | 1000.0000 |  777.7778 |  26652.4 KB |        1.00 |
| NativeParallel    | KeltnerChannels | 10000 | 13,199.2 μs | 2,350.76 μs | 1,554.88 μs |  1.08 |    0.15 | 2428.5714 | 1714.2857 | 1142.8571 | 42682.89 KB |        1.60 |
