```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **ChandelierExit** | **1000**  |    **131.5 μs** |     **2.93 μs** |     **1.94 μs** |  **0.12** |    **0.00** |    **3.9063** |         **-** |        **-** |    **73.65 KB** |       **0.028** |
| BuilderLatestOnly | ChandelierExit | 1000  |    127.5 μs |     2.29 μs |     1.20 μs |  0.12 |    0.00 |    0.9766 |         - |        - |    26.04 KB |       0.010 |
| NativeSingle      | ChandelierExit | 1000  |  1,066.9 μs |    43.79 μs |    26.06 μs |  1.00 |    0.03 |  148.4375 |   93.7500 |  31.2500 |  2630.98 KB |       1.000 |
| NativeParallel    | ChandelierExit | 1000  |    712.6 μs |    19.71 μs |    13.04 μs |  0.67 |    0.02 |  250.0000 |  125.0000 |        - |  3937.14 KB |       1.496 |
|                   |                |       |             |             |             |       |         |           |           |          |             |             |
| **BuilderFull**       | **ChandelierExit** | **10000** |  **1,523.2 μs** |    **43.98 μs** |    **29.09 μs** |  **0.11** |    **0.01** |   **39.0625** |   **15.6250** |        **-** |   **706.85 KB** |       **0.028** |
| BuilderLatestOnly | ChandelierExit | 10000 |  1,485.2 μs |    39.69 μs |    26.25 μs |  0.10 |    0.01 |    7.8125 |         - |        - |   237.02 KB |       0.009 |
| NativeSingle      | ChandelierExit | 10000 | 14,226.4 μs | 1,462.13 μs |   967.11 μs |  1.00 |    0.09 | 1625.0000 | 1000.0000 | 750.0000 | 25626.82 KB |       1.000 |
| NativeParallel    | ChandelierExit | 10000 | 12,355.8 μs | 2,892.77 μs | 1,913.39 μs |  0.87 |    0.14 | 2333.3333 | 1555.5556 | 888.8889 | 38819.28 KB |       1.515 |
