```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **KeltnerChannels** | **1000**  |   **168.1 μs** |  **3.11 μs** |  **1.85 μs** |  **5.8594** |  **0.9766** |  **96.82 KB** |
| BuilderLatestOnly | KeltnerChannels | 1000  |   164.1 μs |  2.66 μs |  1.76 μs |  2.9297 |       - |  49.21 KB |
| **BuilderFull**       | **KeltnerChannels** | **10000** | **1,637.0 μs** | **19.70 μs** | **11.72 μs** | **46.8750** | **15.6250** | **941.02 KB** |
| BuilderLatestOnly | KeltnerChannels | 10000 | 1,617.2 μs | 22.51 μs | 13.39 μs | 15.6250 |       - | 471.11 KB |
