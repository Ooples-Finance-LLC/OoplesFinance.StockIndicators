```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **KeltnerChannels** | **1000**  |   **164.4 μs** |  **3.92 μs** |  **2.34 μs** |  **3.9063** |       **-** |  **96.83 KB** |
| BuilderLatestOnly | KeltnerChannels | 1000  |   164.6 μs |  2.41 μs |  1.60 μs |  2.9297 |       - |  49.22 KB |
| **BuilderFull**       | **KeltnerChannels** | **10000** | **1,636.7 μs** | **43.43 μs** | **22.71 μs** | **46.8750** | **15.6250** | **940.99 KB** |
| BuilderLatestOnly | KeltnerChannels | 10000 | 1,582.1 μs | 53.21 μs | 31.67 μs | 15.6250 |       - | 471.17 KB |
