```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Simpl(...)lator [29]** | **1000**  |  **26.67 μs** |  **4.233 μs** |  **2.800 μs** |  **4.1504** |  **0.4883** |  **69.52 KB** |
| BuilderLatestOnly | Simpl(...)lator [29] | 1000  |  26.32 μs |  1.704 μs |  1.014 μs |  1.2207 |       - |  21.94 KB |
| **BuilderFull**       | **Simpl(...)lator [29]** | **10000** | **186.59 μs** | **14.801 μs** |  **9.790 μs** | **38.0859** | **15.6250** | **632.37 KB** |
| BuilderLatestOnly | Simpl(...)lator [29] | 10000 | 222.63 μs | 55.060 μs | 36.419 μs |  9.7656 |  1.9531 | 162.57 KB |
