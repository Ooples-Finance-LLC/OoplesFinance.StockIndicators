```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Expon(...)lator [34]** | **1000**  |  **47.08 μs** |  **0.550 μs** |  **0.288 μs** |  **3.9063** |       **-** |  **64.93 KB** |
| BuilderLatestOnly | Expon(...)lator [34] | 1000  |  44.70 μs |  0.723 μs |  0.478 μs |  0.9766 |       - |  17.31 KB |
| **BuilderFull**       | **Expon(...)lator [34]** | **10000** | **579.62 μs** | **19.772 μs** | **13.078 μs** | **35.1563** | **11.7188** |  **627.8 KB** |
| BuilderLatestOnly | Expon(...)lator [34] | 10000 | 551.14 μs | 10.246 μs |  5.359 μs |  7.8125 |       - | 157.96 KB |
