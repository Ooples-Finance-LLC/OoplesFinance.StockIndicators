```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean          | Error      | StdDev      | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |--------------:|-----------:|------------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Weigh(...)erage [21]** | **1000**  |     **14.904 μs** |   **3.991 μs** |   **2.6396 μs** | **0.013** |    **0.00** |   **3.4180** |   **0.4883** |        **-** |   **58.44 KB** |        **0.10** |
| BuilderLatestOnly | Weigh(...)erage [21] | 1000  |      6.169 μs |   1.105 μs |   0.7312 μs | 0.005 |    0.00 |   0.6104 |        - |        - |   10.59 KB |        0.02 |
| NativeSingle      | Weigh(...)erage [21] | 1000  |  1,153.690 μs |  14.928 μs |   9.8738 μs | 1.000 |    0.01 |  31.2500 |   7.8125 |        - |  559.51 KB |        1.00 |
| NativeParallel    | Weigh(...)erage [21] | 1000  |    560.150 μs |  55.742 μs |  36.8696 μs | 0.486 |    0.03 |  35.1563 |   7.8125 |        - |  565.08 KB |        1.01 |
|                   |                      |       |               |            |             |       |         |          |          |          |            |             |
| **BuilderFull**       | **Weigh(...)erage [21]** | **10000** |     **72.676 μs** |  **12.393 μs** |   **8.1970 μs** | **0.006** |    **0.00** |  **33.2031** |  **11.7188** |        **-** |  **550.98 KB** |        **0.10** |
| BuilderLatestOnly | Weigh(...)erage [21] | 10000 |     57.259 μs |   4.942 μs |   2.5848 μs | 0.005 |    0.00 |   4.8828 |   0.9766 |        - |    80.9 KB |        0.01 |
| NativeSingle      | Weigh(...)erage [21] | 10000 | 11,935.123 μs | 364.168 μs | 240.8746 μs | 1.000 |    0.03 | 666.6667 | 444.4444 | 444.4444 | 5508.16 KB |        1.00 |
| NativeParallel    | Weigh(...)erage [21] | 10000 |  6,417.962 μs | 269.704 μs | 160.4963 μs | 0.538 |    0.02 | 500.0000 | 375.0000 | 250.0000 | 5620.93 KB |        1.02 |
