```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Expon(...)erage [24]** | **1000**  |  **20.56 μs** | **0.355 μs** | **0.211 μs** |  **3.4180** |  **0.4883** |  **56.66 KB** |
| BuilderLatestOnly | Expon(...)erage [24] | 1000  |  19.53 μs | 0.370 μs | 0.245 μs |  0.4883 |       - |   8.77 KB |
| **BuilderFull**       | **Expon(...)erage [24]** | **10000** | **180.59 μs** | **3.983 μs** | **2.634 μs** | **33.2031** | **13.6719** |  **549.2 KB** |
| BuilderLatestOnly | Expon(...)erage [24] | 10000 | 174.88 μs | 1.681 μs | 1.000 μs |  3.9063 |       - |  79.09 KB |
