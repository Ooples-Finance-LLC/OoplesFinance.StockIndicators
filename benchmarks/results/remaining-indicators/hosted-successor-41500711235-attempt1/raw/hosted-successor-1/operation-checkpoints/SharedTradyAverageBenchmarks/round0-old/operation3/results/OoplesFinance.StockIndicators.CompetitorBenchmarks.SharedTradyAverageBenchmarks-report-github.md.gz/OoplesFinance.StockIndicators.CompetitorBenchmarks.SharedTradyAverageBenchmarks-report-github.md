```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Expon(...)lator [34]** | **1000**  |  **50.18 μs** |  **4.386 μs** | **2.901 μs** |  **3.9063** |       **-** |  **64.89 KB** |
| BuilderLatestOnly | Expon(...)lator [34] | 1000  |  44.10 μs |  0.554 μs | 0.367 μs |  0.9766 |       - |  17.31 KB |
| **BuilderFull**       | **Expon(...)lator [34]** | **10000** | **556.97 μs** | **10.536 μs** | **6.270 μs** | **35.1563** | **11.7188** | **627.75 KB** |
| BuilderLatestOnly | Expon(...)lator [34] | 10000 | 549.25 μs | 15.234 μs | 9.065 μs |  7.8125 |       - | 157.97 KB |
