```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0      | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|----------:|---------:|---------:|------------:|------------:|
| **BuilderFull**       | **Simpl(...)lator [29]** | **1000**  |    **34.99 μs** |   **1.641 μs** |   **1.086 μs** |  **0.06** |    **0.00** |    **3.9063** |        **-** |        **-** |    **69.55 KB** |        **0.06** |
| BuilderLatestOnly | Simpl(...)lator [29] | 1000  |    24.71 μs |   4.015 μs |   2.655 μs |  0.04 |    0.00 |    1.2207 |        - |        - |    21.94 KB |        0.02 |
| NativeSingle      | Simpl(...)lator [29] | 1000  |   581.72 μs |  18.720 μs |  12.382 μs |  1.00 |    0.03 |   62.5000 |  19.5313 |        - |  1081.45 KB |        1.00 |
| NativeParallel    | Simpl(...)lator [29] | 1000  |   276.50 μs |  23.133 μs |  15.301 μs |  0.48 |    0.03 |   68.3594 |  21.4844 |        - |  1055.79 KB |        0.98 |
|                   |                      |       |             |            |            |       |         |           |          |          |             |             |
| **BuilderFull**       | **Simpl(...)lator [29]** | **10000** |   **212.57 μs** |  **28.028 μs** |  **18.539 μs** |  **0.03** |    **0.00** |   **38.0859** |  **16.6016** |        **-** |    **632.4 KB** |        **0.06** |
| BuilderLatestOnly | Simpl(...)lator [29] | 10000 |   232.40 μs |  45.228 μs |  29.915 μs |  0.03 |    0.00 |    9.7656 |   1.9531 |        - |   162.58 KB |        0.02 |
| NativeSingle      | Simpl(...)lator [29] | 10000 | 7,208.77 μs | 662.743 μs | 438.363 μs |  1.00 |    0.08 | 1133.3333 | 866.6667 | 800.0000 | 10509.11 KB |        1.00 |
| NativeParallel    | Simpl(...)lator [29] | 10000 | 4,645.01 μs | 384.347 μs | 201.021 μs |  0.65 |    0.05 | 1062.5000 | 875.0000 | 562.5000 | 10387.94 KB |        0.99 |
