```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error        | StdDev       | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-------------:|-------------:|------:|--------:|----------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **Expon(...)erage [24]** | **1000**  |    **20.16 μs** |     **0.641 μs** |     **0.335 μs** |  **0.07** |    **0.00** |    **3.4180** |    **0.4883** |        **-** |    **56.66 KB** |       **0.062** |
| BuilderLatestOnly | Expon(...)erage [24] | 1000  |    19.29 μs |     0.464 μs |     0.243 μs |  0.06 |    0.00 |    0.4883 |         - |        - |     8.77 KB |       0.010 |
| NativeSingle      | Expon(...)erage [24] | 1000  |   298.33 μs |     5.578 μs |     3.690 μs |  1.00 |    0.02 |   54.6875 |   19.5313 |        - |   915.27 KB |       1.000 |
| NativeParallel    | Expon(...)erage [24] | 1000  |   285.35 μs |    10.506 μs |     6.949 μs |  0.96 |    0.02 |   83.9844 |   29.2969 |        - |  1328.63 KB |       1.452 |
|                   |                      |       |             |              |              |       |         |           |           |          |             |             |
| **BuilderFull**       | **Expon(...)erage [24]** | **10000** |   **176.78 μs** |     **3.044 μs** |     **1.812 μs** |  **0.05** |    **0.00** |   **33.2031** |   **13.6719** |        **-** |    **549.2 KB** |       **0.062** |
| BuilderLatestOnly | Expon(...)erage [24] | 10000 |   171.69 μs |     5.103 μs |     3.376 μs |  0.05 |    0.00 |    3.9063 |         - |        - |    79.09 KB |       0.009 |
| NativeSingle      | Expon(...)erage [24] | 10000 | 3,599.78 μs |   225.535 μs |   149.177 μs |  1.00 |    0.06 | 1312.5000 | 1031.2500 | 968.7500 |  8914.36 KB |       1.000 |
| NativeParallel    | Expon(...)erage [24] | 10000 | 7,393.85 μs | 2,195.478 μs | 1,452.173 μs |  2.06 |    0.39 | 1384.6154 | 1076.9231 | 923.0769 | 13011.48 KB |       1.460 |
