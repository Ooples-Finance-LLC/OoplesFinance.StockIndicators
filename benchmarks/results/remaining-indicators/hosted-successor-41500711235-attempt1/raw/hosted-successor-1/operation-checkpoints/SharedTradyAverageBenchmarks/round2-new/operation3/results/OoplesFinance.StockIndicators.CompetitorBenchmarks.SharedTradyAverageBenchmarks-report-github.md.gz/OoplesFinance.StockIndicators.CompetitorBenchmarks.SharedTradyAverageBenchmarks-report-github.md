```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error        | StdDev       | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-------------:|-------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Expon(...)lator [34]** | **1000**  |     **48.56 μs** |     **0.958 μs** |     **0.570 μs** |  **0.07** |    **0.00** |    **3.9063** |         **-** |         **-** |    **64.93 KB** |       **0.030** |
| BuilderLatestOnly | Expon(...)lator [34] | 1000  |     44.41 μs |     0.989 μs |     0.654 μs |  0.06 |    0.00 |    0.9766 |         - |         - |    17.31 KB |       0.008 |
| NativeSingle      | Expon(...)lator [34] | 1000  |    713.35 μs |     9.388 μs |     5.586 μs |  1.00 |    0.01 |  132.8125 |   54.6875 |         - |   2200.7 KB |       1.000 |
| NativeParallel    | Expon(...)lator [34] | 1000  |    631.29 μs |    14.182 μs |     8.440 μs |  0.89 |    0.01 |  210.9375 |   93.7500 |         - |  3332.43 KB |       1.514 |
|                   |                      |       |              |              |              |       |         |           |           |           |             |             |
| **BuilderFull**       | **Expon(...)lator [34]** | **10000** |    **562.87 μs** |     **6.035 μs** |     **3.156 μs** |  **0.05** |    **0.00** |   **35.1563** |   **11.7188** |         **-** |   **627.81 KB** |       **0.029** |
| BuilderLatestOnly | Expon(...)lator [34] | 10000 |    548.51 μs |     2.666 μs |     1.394 μs |  0.05 |    0.00 |    7.8125 |         - |         - |   157.96 KB |       0.007 |
| NativeSingle      | Expon(...)lator [34] | 10000 | 11,411.29 μs | 1,084.530 μs |   717.350 μs |  1.00 |    0.08 | 1500.0000 | 1000.0000 |  750.0000 | 21973.71 KB |       1.000 |
| NativeParallel    | Expon(...)lator [34] | 10000 | 12,136.22 μs | 2,540.780 μs | 1,680.569 μs |  1.07 |    0.15 | 2571.4286 | 1857.1429 | 1285.7143 | 33532.33 KB |       1.526 |
