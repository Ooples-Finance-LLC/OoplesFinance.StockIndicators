```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Simpl(...)lator [29]** | **1000**  |  **26.59 μs** |  **3.836 μs** |  **2.537 μs** |  **4.1504** |  **0.4883** |  **69.55 KB** |
| BuilderLatestOnly | Simpl(...)lator [29] | 1000  |  24.19 μs |  1.767 μs |  1.052 μs |  1.2207 |       - |  21.94 KB |
| **BuilderFull**       | **Simpl(...)lator [29]** | **10000** | **203.56 μs** | **26.799 μs** | **17.726 μs** | **38.0859** | **16.6016** |  **632.4 KB** |
| BuilderLatestOnly | Simpl(...)lator [29] | 10000 | 227.23 μs | 36.772 μs | 24.322 μs |  9.7656 |  1.9531 | 162.57 KB |
