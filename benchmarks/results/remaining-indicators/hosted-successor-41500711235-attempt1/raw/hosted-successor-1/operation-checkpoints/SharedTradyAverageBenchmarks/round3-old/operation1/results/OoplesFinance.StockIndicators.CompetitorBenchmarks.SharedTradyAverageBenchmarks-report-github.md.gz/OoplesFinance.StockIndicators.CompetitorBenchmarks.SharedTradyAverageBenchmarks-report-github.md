```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error      | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|-----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Weigh(...)erage [21]** | **1000**  | **12.145 μs** |  **4.0391 μs** | **2.6716 μs** |  **3.4180** |  **0.4883** |  **58.47 KB** |
| BuilderLatestOnly | Weigh(...)erage [21] | 1000  |  6.191 μs |  0.3445 μs | 0.1802 μs |  0.6104 |       - |  10.59 KB |
| **BuilderFull**       | **Weigh(...)erage [21]** | **10000** | **72.760 μs** | **10.1824 μs** | **6.7350 μs** | **33.2031** | **12.6953** | **551.01 KB** |
| BuilderLatestOnly | Weigh(...)erage [21] | 10000 | 57.327 μs |  9.0056 μs | 5.9567 μs |  4.8828 |  0.4883 |  80.91 KB |
