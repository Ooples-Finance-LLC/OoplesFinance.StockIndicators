```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean       | Error   | StdDev  | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |-----------:|--------:|--------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Trady(...)nLine [44]** |   **112.7 μs** | **4.00 μs** | **2.38 μs** |  **1.00** |    **0.03** |  **194.64 KB** |        **1.00** |
|        |       |                      |            |         |         |       |         |            |             |
| **Ooples** | **10000** | **Trady(...)nLine [44]** | **1,170.0 μs** | **9.03 μs** | **4.72 μs** |  **1.00** |    **0.01** | **2334.34 KB** |        **1.00** |
