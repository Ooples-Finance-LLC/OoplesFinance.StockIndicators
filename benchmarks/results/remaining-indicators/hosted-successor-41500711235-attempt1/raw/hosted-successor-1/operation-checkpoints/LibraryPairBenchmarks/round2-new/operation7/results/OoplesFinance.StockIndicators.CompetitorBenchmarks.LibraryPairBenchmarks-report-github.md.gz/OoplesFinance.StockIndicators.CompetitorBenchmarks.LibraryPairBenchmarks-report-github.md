```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)rExit [30]** |    **185.0 μs** |     **5.51 μs** |   **3.28 μs** |  **1.00** |    **0.02** |         **-** |         **-** |         **-** |    **155.1 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)rExit [30] |  1,429.2 μs |    12.99 μs |   7.73 μs |  7.73 |    0.13 |         - |         - |         - |  3028.32 KB |       19.52 |
|            |       |                      |             |             |           |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)rExit [30]** |  **1,749.4 μs** |    **17.72 μs** |  **10.55 μs** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |   **1510.3 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)rExit [30] | 18,082.4 μs | 1,167.15 μs | 610.44 μs | 10.34 |    0.33 | 2000.0000 | 1000.0000 | 1000.0000 | 29563.52 KB |       19.57 |
