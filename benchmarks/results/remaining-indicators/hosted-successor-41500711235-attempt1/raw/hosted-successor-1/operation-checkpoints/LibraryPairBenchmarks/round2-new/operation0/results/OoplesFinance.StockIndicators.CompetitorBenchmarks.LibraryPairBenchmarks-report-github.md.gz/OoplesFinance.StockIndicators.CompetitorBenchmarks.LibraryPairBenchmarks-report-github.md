```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean         | Error      | StdDev     | Ratio | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |-------------------- |-------------:|-----------:|-----------:|------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ppo** |   **383.540 μs** | **17.1790 μs** | **11.3628 μs** |  **1.00** |    **0.04** |  **1505.21 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ppo |     5.344 μs |  0.2924 μs |  0.1740 μs |  0.01 |    0.00 |    45.84 KB |        0.03 |
|            |       |                     |              |            |            |       |         |             |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ppo** | **3,785.700 μs** | **78.3222 μs** | **46.6083 μs** |  **1.00** |    **0.02** | **15132.94 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ppo |    45.825 μs |  1.5457 μs |  0.8084 μs |  0.01 |    0.00 |   405.25 KB |        0.03 |
