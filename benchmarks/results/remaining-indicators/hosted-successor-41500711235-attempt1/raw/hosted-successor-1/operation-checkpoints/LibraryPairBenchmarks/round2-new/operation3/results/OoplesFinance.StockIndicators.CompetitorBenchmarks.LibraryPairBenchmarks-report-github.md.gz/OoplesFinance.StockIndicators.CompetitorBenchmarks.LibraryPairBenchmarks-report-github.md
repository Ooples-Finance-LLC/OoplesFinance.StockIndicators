```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error        | StdDev       | Median      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-------------:|-------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)chRsi [24]** |   **312.09 μs** |    **14.852 μs** |     **8.838 μs** |   **308.00 μs** |  **1.00** |    **0.04** |  **264.27 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)chRsi [24] |    24.13 μs |     1.176 μs |     0.700 μs |    23.70 μs |  0.08 |    0.00 |    81.8 KB |        0.31 |
|            |       |                      |             |              |              |             |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)chRsi [24]** | **4,027.05 μs** | **2,299.385 μs** | **1,520.901 μs** | **3,103.10 μs** |  **1.11** |    **0.51** | **2602.49 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)chRsi [24] |   255.43 μs |    14.667 μs |     8.728 μs |   250.30 μs |  0.07 |    0.02 |  802.83 KB |        0.31 |
