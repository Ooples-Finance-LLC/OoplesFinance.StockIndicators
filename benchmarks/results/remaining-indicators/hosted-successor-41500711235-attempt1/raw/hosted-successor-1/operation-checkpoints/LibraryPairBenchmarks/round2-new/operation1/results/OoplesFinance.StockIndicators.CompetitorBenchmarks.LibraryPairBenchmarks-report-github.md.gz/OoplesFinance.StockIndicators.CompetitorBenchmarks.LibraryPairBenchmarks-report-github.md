```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Stoch [21]** |   **257.73 μs** |   **5.963 μs** |   **3.548 μs** |  **1.00** |    **0.02** |  **720.53 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Stoch [21] |    19.35 μs |   0.824 μs |   0.431 μs |  0.08 |    0.00 |   93.42 KB |        0.13 |
|            |       |                      |             |            |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)Stoch [21]** | **3,066.63 μs** | **942.552 μs** | **623.440 μs** |  **1.03** |    **0.27** | **7144.38 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Stoch [21] |   171.72 μs |   2.839 μs |   1.485 μs |  0.06 |    0.01 |  885.09 KB |        0.12 |
