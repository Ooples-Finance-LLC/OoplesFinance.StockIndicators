```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId              | Mean       | Error       | StdDev      | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |-------------------- |-----------:|------------:|------------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Ppo** |   **371.8 μs** |     **3.97 μs** |     **2.36 μs** |  **1.00** |    **0.01** |   **1.47 MB** |        **1.00** |
|        |       |                     |            |             |             |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Ppo** | **5,010.7 μs** | **1,875.17 μs** | **1,240.31 μs** |  **1.05** |    **0.33** |  **14.78 MB** |        **1.00** |
