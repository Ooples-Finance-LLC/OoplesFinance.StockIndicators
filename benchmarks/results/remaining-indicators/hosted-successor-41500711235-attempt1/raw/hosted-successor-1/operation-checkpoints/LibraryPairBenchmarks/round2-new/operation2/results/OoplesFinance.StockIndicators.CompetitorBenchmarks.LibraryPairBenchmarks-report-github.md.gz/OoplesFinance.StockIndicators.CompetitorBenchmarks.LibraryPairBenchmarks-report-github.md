```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tochF [22]** |   **233.88 μs** | **61.671 μs** | **36.699 μs** |  **1.02** |    **0.21** |  **469.99 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tochF [22] |    17.91 μs |  2.081 μs |  1.376 μs |  0.08 |    0.01 |   93.72 KB |        0.20 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)tochF [22]** | **1,927.73 μs** | **57.434 μs** | **34.178 μs** |  **1.00** |    **0.02** | **4642.86 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tochF [22] |   159.49 μs | 10.224 μs |  6.763 μs |  0.08 |    0.00 |  885.11 KB |        0.19 |
