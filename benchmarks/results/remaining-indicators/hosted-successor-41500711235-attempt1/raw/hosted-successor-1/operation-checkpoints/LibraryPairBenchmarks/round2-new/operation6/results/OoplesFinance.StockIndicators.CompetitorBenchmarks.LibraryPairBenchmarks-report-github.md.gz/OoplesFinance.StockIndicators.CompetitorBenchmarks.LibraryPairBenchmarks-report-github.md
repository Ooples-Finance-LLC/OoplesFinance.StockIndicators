```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)nLine [44]** |   **113.6 μs** |  **2.84 μs** |  **1.49 μs** |  **1.00** |    **0.02** |  **194.64 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)nLine [44] |   719.4 μs | 30.04 μs | 17.88 μs |  6.33 |    0.17 |  895.84 KB |        4.60 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Trady(...)nLine [44]** | **1,248.9 μs** | **40.61 μs** | **26.86 μs** |  **1.00** |    **0.03** | **2341.18 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)nLine [44] | 5,324.5 μs | 96.31 μs | 57.31 μs |  4.27 |    0.10 | 8809.46 KB |        3.76 |
