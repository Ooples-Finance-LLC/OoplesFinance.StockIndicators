```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean         | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-------------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Trix** |   **217.167 μs** | **11.2423 μs** |  **6.6901 μs** |  **1.00** |    **0.04** |  **192.97 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Trix |     8.900 μs |  0.2911 μs |  0.1732 μs |  0.04 |    0.00 |   41.62 KB |        0.22 |
|            |       |                      |              |            |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Trix** | **2,165.061 μs** | **24.5359 μs** | **14.6009 μs** |  **1.00** |    **0.01** | **1890.62 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Trix |    77.112 μs |  0.9391 μs |  0.4912 μs |  0.04 |    0.00 |   402.3 KB |        0.21 |
