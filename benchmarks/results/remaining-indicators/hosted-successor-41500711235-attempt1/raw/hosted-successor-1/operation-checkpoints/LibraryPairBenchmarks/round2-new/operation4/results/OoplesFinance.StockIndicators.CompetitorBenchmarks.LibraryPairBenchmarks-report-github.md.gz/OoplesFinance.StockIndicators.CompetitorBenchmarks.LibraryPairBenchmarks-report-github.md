```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean         | Error      | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-------------:|-----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.T3** |   **182.111 μs** |  **6.7696 μs** | **4.0285 μs** |  **1.00** |    **0.03** |  **105.89 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.T3 |     4.612 μs |  0.4268 μs | 0.2232 μs |  0.03 |    0.00 |   35.02 KB |        0.33 |
|            |       |                    |              |            |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.T3** | **1,412.644 μs** | **15.9608 μs** | **9.4980 μs** |  **1.00** |    **0.01** | **1030.02 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.T3 |    42.222 μs |  1.5072 μs | 0.8969 μs |  0.03 |    0.00 |  326.98 KB |        0.32 |
