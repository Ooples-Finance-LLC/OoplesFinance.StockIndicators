```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |-------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetElderRay** | **1000**  |  **62.52 μs** |  **1.737 μs** |  **1.034 μs** |  **3.9063** |       **-** |  **80.64 KB** |
| BuilderLatestOnly | Skender.GetElderRay | 1000  |  58.10 μs |  1.365 μs |  0.714 μs |  1.9531 |       - |     33 KB |
| **BuilderFull**       | **Skender.GetElderRay** | **10000** | **576.38 μs** | **19.958 μs** | **13.201 μs** | **46.8750** | **19.5313** | **784.12 KB** |
| BuilderLatestOnly | Skender.GetElderRay | 10000 | 568.89 μs | 21.455 μs | 14.191 μs | 15.6250 |  3.9063 | 314.25 KB |
