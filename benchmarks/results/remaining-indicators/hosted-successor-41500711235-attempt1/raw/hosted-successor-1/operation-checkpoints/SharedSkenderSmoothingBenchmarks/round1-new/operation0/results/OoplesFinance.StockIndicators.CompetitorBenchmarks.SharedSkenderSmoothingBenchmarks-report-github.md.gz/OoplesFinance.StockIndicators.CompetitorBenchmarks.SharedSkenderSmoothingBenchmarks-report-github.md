```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |-------------------- |------ |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetElderRay** | **1000**  |  **64.04 μs** |  **1.438 μs** | **0.752 μs** |  **3.9063** |       **-** |  **80.64 KB** |
| BuilderLatestOnly | Skender.GetElderRay | 1000  |  57.09 μs |  2.414 μs | 1.597 μs |  1.9531 |       - |     33 KB |
| **BuilderFull**       | **Skender.GetElderRay** | **10000** | **575.85 μs** | **10.280 μs** | **5.376 μs** | **46.8750** | **19.5313** | **784.09 KB** |
| BuilderLatestOnly | Skender.GetElderRay | 10000 | 552.96 μs | 11.473 μs | 7.589 μs | 15.6250 |  3.9063 | 314.25 KB |
