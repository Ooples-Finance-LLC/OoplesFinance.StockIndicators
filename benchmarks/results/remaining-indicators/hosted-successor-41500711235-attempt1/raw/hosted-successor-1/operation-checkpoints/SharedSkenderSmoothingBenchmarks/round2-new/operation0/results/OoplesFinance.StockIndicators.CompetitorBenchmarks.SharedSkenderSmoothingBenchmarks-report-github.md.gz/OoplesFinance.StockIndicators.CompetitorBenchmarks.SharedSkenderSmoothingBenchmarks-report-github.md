```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetElderRay** | **1000**  |    **68.24 μs** | **14.749 μs** |  **9.755 μs** |  **1.41** |    **0.20** |   **3.9063** |        **-** |       **-** |   **80.61 KB** |        **0.32** |
| BuilderLatestOnly | Skender.GetElderRay | 1000  |    58.38 μs |  1.247 μs |  0.825 μs |  1.21 |    0.03 |   1.9531 |        - |       - |      33 KB |        0.13 |
| NativeSingle      | Skender.GetElderRay | 1000  |    48.38 μs |  1.837 μs |  1.215 μs |  1.00 |    0.03 |  15.1367 |   3.9063 |       - |  251.06 KB |        1.00 |
| NativeParallel    | Skender.GetElderRay | 1000  |    85.62 μs |  4.897 μs |  3.239 μs |  1.77 |    0.08 |  41.0156 |  14.1602 |       - |  637.17 KB |        2.54 |
|                   |                     |       |             |           |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skender.GetElderRay** | **10000** |   **594.69 μs** | **14.511 μs** |  **9.598 μs** |  **0.91** |    **0.01** |  **46.8750** |  **19.5313** |       **-** |   **784.1 KB** |        **0.31** |
| BuilderLatestOnly | Skender.GetElderRay | 10000 |   563.04 μs |  7.846 μs |  5.190 μs |  0.86 |    0.01 |  15.6250 |   3.9063 |       - |  314.28 KB |        0.13 |
| NativeSingle      | Skender.GetElderRay | 10000 |   652.55 μs |  6.232 μs |  3.259 μs |  1.00 |    0.01 | 148.4375 |  97.6563 | 46.8750 | 2501.43 KB |        1.00 |
| NativeParallel    | Skender.GetElderRay | 10000 | 1,149.63 μs | 39.640 μs | 26.219 μs |  1.76 |    0.04 | 429.6875 | 359.3750 | 85.9375 | 6333.22 KB |        2.53 |
