```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |------ |------------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **1000**  |    **94.31 μs** |  **2.701 μs** |  **1.787 μs** |  **4.02** |    **0.21** |   **1.9531** |       **-** |   **91.75 KB** |        **1.94** |
| BuilderLatestOnly | 1000  |    82.45 μs |  1.382 μs |  0.823 μs |  3.52 |    0.17 |   1.4648 |       - |   43.87 KB |        0.93 |
| NativeSingle      | 1000  |    23.50 μs |  1.820 μs |  1.204 μs |  1.00 |    0.07 |   1.8311 |       - |    47.2 KB |        1.00 |
| NativeParallel    | 1000  |    30.86 μs |  1.217 μs |  0.724 μs |  1.32 |    0.07 |   4.3945 |       - |  106.85 KB |        2.26 |
|                   |       |             |           |           |       |         |          |         |            |             |
| **BuilderFull**       | **10000** | **4,093.69 μs** | **39.417 μs** | **20.616 μs** | **18.83** |    **0.62** | **187.5000** | **62.5000** | **5102.53 KB** |       **10.88** |
| BuilderLatestOnly | 10000 | 4,123.76 μs | 94.194 μs | 49.265 μs | 18.97 |    0.65 | 187.5000 | 31.2500 | 4632.42 KB |        9.88 |
| NativeSingle      | 10000 |   217.67 μs | 11.570 μs |  7.653 μs |  1.00 |    0.05 |  17.5781 |  1.9531 |  469.08 KB |        1.00 |
| NativeParallel    | 10000 |   267.03 μs | 24.624 μs | 16.287 μs |  1.23 |    0.08 |  42.9688 |  7.8125 | 1056.09 KB |        2.25 |
