```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean        | Error      | StdDev    | Gen0     | Gen1    | Allocated  |
|------------------ |------ |------------:|-----------:|----------:|---------:|--------:|-----------:|
| **BuilderFull**       | **1000**  |    **93.20 μs** |   **1.681 μs** |  **1.001 μs** |   **1.9531** |       **-** |   **91.75 KB** |
| BuilderLatestOnly | 1000  |    79.51 μs |   1.099 μs |  0.575 μs |   1.4648 |       - |   43.87 KB |
| **BuilderFull**       | **10000** | **3,982.58 μs** |  **52.437 μs** | **27.426 μs** | **187.5000** | **62.5000** | **5102.56 KB** |
| BuilderLatestOnly | 10000 | 3,967.43 μs | 131.709 μs | 87.118 μs | 187.5000 | 31.2500 | 4632.48 KB |
