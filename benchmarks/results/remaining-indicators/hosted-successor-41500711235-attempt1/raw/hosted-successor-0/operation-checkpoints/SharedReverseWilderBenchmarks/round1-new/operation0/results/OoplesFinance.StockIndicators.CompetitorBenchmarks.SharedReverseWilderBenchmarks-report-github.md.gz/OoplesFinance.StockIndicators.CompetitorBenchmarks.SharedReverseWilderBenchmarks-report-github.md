```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean        | Error      | StdDev     | Gen0     | Gen1    | Allocated  |
|------------------ |------ |------------:|-----------:|-----------:|---------:|--------:|-----------:|
| **BuilderFull**       | **1000**  |    **90.30 μs** |   **2.514 μs** |   **1.663 μs** |   **1.9531** |       **-** |   **91.75 KB** |
| BuilderLatestOnly | 1000  |    82.44 μs |   1.287 μs |   0.673 μs |   1.4648 |       - |   43.87 KB |
| **BuilderFull**       | **10000** | **3,959.58 μs** |  **61.940 μs** |  **32.396 μs** | **187.5000** | **62.5000** | **5102.54 KB** |
| BuilderLatestOnly | 10000 | 4,021.48 μs | 270.489 μs | 178.912 μs | 187.5000 | 31.2500 | 4632.46 KB |
