```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)Bands [21]** | **1000**  |   **304.3 μs** |  **19.94 μs** |  **11.86 μs** |       **-** |  **97.39 KB** |
| BuilderLatestOnly | Skend(...)Bands [21] | 1000  |   293.2 μs |  17.41 μs |  10.36 μs |  1.9531 |  49.79 KB |
| **BuilderFull**       | **Skend(...)Bands [21]** | **10000** | **3,378.3 μs** | **429.07 μs** | **255.33 μs** | **31.2500** | **941.64 KB** |
| BuilderLatestOnly | Skend(...)Bands [21] | 10000 | 3,044.3 μs | 245.56 μs | 162.42 μs |       - | 471.84 KB |
