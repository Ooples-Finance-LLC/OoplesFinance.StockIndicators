```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)Bands [21]** | **1000**  |   **294.4 μs** |  **15.30 μs** |   **8.00 μs** |  **1.99** |    **0.05** |        **-** |        **-** |       **-** |   **97.39 KB** |        **0.30** |
| BuilderLatestOnly | Skend(...)Bands [21] | 1000  |   282.4 μs |   1.91 μs |   1.14 μs |  1.91 |    0.01 |   1.9531 |        - |       - |   49.79 KB |        0.15 |
| NativeSingle      | Skend(...)Bands [21] | 1000  |   148.1 μs |   1.66 μs |   0.99 μs |  1.00 |    0.01 |  12.6953 |   2.9297 |       - |  329.24 KB |        1.00 |
| NativeParallel    | Skend(...)Bands [21] | 1000  |   259.4 μs |  33.54 μs |  22.18 μs |  1.75 |    0.14 |  35.1563 |  13.6719 |       - |  832.71 KB |        2.53 |
|                   |                      |       |            |           |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)Bands [21]** | **10000** | **2,983.0 μs** |  **43.88 μs** |  **29.03 μs** |  **1.36** |    **0.02** |  **31.2500** |        **-** |       **-** |  **941.75 KB** |        **0.29** |
| BuilderLatestOnly | Skend(...)Bands [21] | 10000 | 2,861.5 μs |  29.11 μs |  15.23 μs |  1.30 |    0.01 |  15.6250 |        - |       - |  471.79 KB |        0.14 |
| NativeSingle      | Skend(...)Bands [21] | 10000 | 2,195.1 μs |  33.09 μs |  17.31 μs |  1.00 |    0.01 | 140.6250 |  93.7500 | 46.8750 | 3282.83 KB |        1.00 |
| NativeParallel    | Skend(...)Bands [21] | 10000 | 4,169.9 μs | 283.73 μs | 187.67 μs |  1.90 |    0.08 | 312.5000 | 281.2500 | 62.5000 | 8286.55 KB |        2.52 |
