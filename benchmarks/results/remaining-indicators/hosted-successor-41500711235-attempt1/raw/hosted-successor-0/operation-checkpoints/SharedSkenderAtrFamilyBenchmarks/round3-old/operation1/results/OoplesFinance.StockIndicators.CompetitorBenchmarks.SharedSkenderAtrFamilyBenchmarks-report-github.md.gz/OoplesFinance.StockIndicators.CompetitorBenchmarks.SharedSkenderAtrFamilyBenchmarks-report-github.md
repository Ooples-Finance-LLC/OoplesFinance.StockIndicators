```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error     | StdDev    | Gen0    | Allocated  |
|------------------ |------------------- |------ |-----------:|----------:|----------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetKeltner** | **1000**  |   **329.3 μs** |   **5.95 μs** |   **3.54 μs** |       **-** |  **104.66 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 1000  |   322.2 μs |   2.71 μs |   1.61 μs |  1.9531 |   57.06 KB |
| **BuilderFull**       | **Skender.GetKeltner** | **10000** | **3,386.9 μs** |  **48.87 μs** |  **29.08 μs** | **31.2500** | **1019.33 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 10000 | 3,408.6 μs | 316.55 μs | 209.38 μs |       - |  549.48 KB |
