```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |------------------- |------ |-----------:|----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetKeltner** | **1000**  |   **349.2 μs** |   **8.72 μs** |   **5.19 μs** |  **2.53** |    **0.04** |        **-** |        **-** |       **-** |  **104.66 KB** |        **0.29** |
| BuilderLatestOnly | Skender.GetKeltner | 1000  |   329.6 μs |  23.89 μs |  15.80 μs |  2.39 |    0.11 |   1.9531 |        - |       - |   57.06 KB |        0.16 |
| NativeSingle      | Skender.GetKeltner | 1000  |   138.2 μs |   1.06 μs |   0.55 μs |  1.00 |    0.01 |  14.6484 |   4.8828 |       - |  360.53 KB |        1.00 |
| NativeParallel    | Skender.GetKeltner | 1000  |   236.8 μs |   7.22 μs |   3.78 μs |  1.71 |    0.03 |  39.0625 |  15.6250 |       - |  910.99 KB |        2.53 |
|                   |                    |       |            |           |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skender.GetKeltner** | **10000** | **3,353.3 μs** |  **65.42 μs** |  **34.21 μs** |  **1.58** |    **0.05** |  **31.2500** |        **-** |       **-** | **1019.27 KB** |        **0.28** |
| BuilderLatestOnly | Skender.GetKeltner | 10000 | 3,220.0 μs |  43.28 μs |  25.76 μs |  1.52 |    0.05 |        - |        - |       - |   549.5 KB |        0.15 |
| NativeSingle      | Skender.GetKeltner | 10000 | 2,119.7 μs | 103.86 μs |  68.69 μs |  1.00 |    0.04 | 140.6250 |  93.7500 | 46.8750 | 3595.39 KB |        1.00 |
| NativeParallel    | Skender.GetKeltner | 10000 | 3,810.2 μs | 289.64 μs | 191.58 μs |  1.80 |    0.10 | 406.2500 | 281.2500 | 62.5000 | 9067.97 KB |        2.52 |
