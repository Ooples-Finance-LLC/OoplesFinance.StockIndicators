```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error     | StdDev    | Gen0    | Allocated  |
|------------------ |------------------- |------ |-----------:|----------:|----------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetKeltner** | **1000**  |   **335.0 μs** |  **11.37 μs** |   **6.77 μs** |       **-** |  **104.66 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 1000  |   338.2 μs |   3.78 μs |   1.98 μs |  1.9531 |   57.06 KB |
| **BuilderFull**       | **Skender.GetKeltner** | **10000** | **3,771.0 μs** | **426.83 μs** | **282.32 μs** | **31.2500** | **1019.33 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 10000 | 3,357.9 μs | 185.59 μs |  97.06 μs |       - |   549.5 KB |
