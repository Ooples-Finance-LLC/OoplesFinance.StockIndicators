```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)elier [21]** | **1000**  |   **217.0 μs** |   **8.23 μs** |  **4.90 μs** |  **1.85** |    **0.12** |        **-** |        **-** |   **73.25 KB** |        **0.33** |
| BuilderLatestOnly | Skend(...)elier [21] | 1000  |   201.0 μs |   3.03 μs |  1.59 μs |  1.71 |    0.10 |        - |        - |   25.68 KB |        0.12 |
| NativeSingle      | Skend(...)elier [21] | 1000  |   117.9 μs |  11.61 μs |  7.68 μs |  1.00 |    0.09 |   8.7891 |   1.9531 |  223.23 KB |        1.00 |
| NativeParallel    | Skend(...)elier [21] | 1000  |   192.7 μs |  14.58 μs |  7.62 μs |  1.64 |    0.11 |  23.4375 |   5.8594 |  566.85 KB |        2.54 |
|                   |                      |       |            |           |          |       |         |          |          |            |             |
| **BuilderFull**       | **Skend(...)elier [21]** | **10000** | **2,275.4 μs** |  **11.82 μs** |  **6.18 μs** |  **1.45** |    **0.01** |  **15.6250** |        **-** |  **706.43 KB** |        **0.32** |
| BuilderLatestOnly | Skend(...)elier [21] | 10000 | 2,124.0 μs |  29.94 μs | 15.66 μs |  1.36 |    0.01 |        - |        - |  236.73 KB |        0.11 |
| NativeSingle      | Skend(...)elier [21] | 10000 | 1,566.1 μs |  18.00 μs | 11.91 μs |  1.00 |    0.01 |  78.1250 |  15.6250 | 2227.23 KB |        1.00 |
| NativeParallel    | Skend(...)elier [21] | 10000 | 2,670.6 μs | 146.88 μs | 87.41 μs |  1.71 |    0.05 | 234.3750 | 171.8750 | 5647.04 KB |        2.54 |
