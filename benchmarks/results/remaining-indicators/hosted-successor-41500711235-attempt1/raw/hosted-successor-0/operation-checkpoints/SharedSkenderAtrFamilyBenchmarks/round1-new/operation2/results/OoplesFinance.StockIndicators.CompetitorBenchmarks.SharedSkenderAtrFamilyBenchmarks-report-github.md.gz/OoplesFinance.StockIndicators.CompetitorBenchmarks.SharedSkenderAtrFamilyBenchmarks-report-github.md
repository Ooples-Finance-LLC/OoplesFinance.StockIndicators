```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)Bands [21]** | **1000**  |   **298.1 μs** |   **7.57 μs** |   **5.01 μs** |       **-** |  **97.39 KB** |
| BuilderLatestOnly | Skend(...)Bands [21] | 1000  |   282.6 μs |   2.48 μs |   1.47 μs |  1.9531 |  49.79 KB |
| **BuilderFull**       | **Skend(...)Bands [21]** | **10000** | **3,254.4 μs** | **381.60 μs** | **252.41 μs** | **31.2500** | **941.59 KB** |
| BuilderLatestOnly | Skend(...)Bands [21] | 10000 | 2,908.4 μs |  79.14 μs |  52.35 μs | 15.6250 | 471.75 KB |
