```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error     | StdDev   | Gen0    | Allocated  |
|------------------ |------------------- |------ |-----------:|----------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetKeltner** | **1000**  |   **328.8 μs** |   **6.71 μs** |  **3.99 μs** |       **-** |  **104.66 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 1000  |   338.4 μs |  25.54 μs | 16.90 μs |  1.9531 |   57.06 KB |
| **BuilderFull**       | **Skender.GetKeltner** | **10000** | **3,454.4 μs** | **162.21 μs** | **96.53 μs** | **31.2500** | **1019.33 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 10000 | 3,210.6 μs |  27.98 μs | 14.64 μs |       - |  549.47 KB |
