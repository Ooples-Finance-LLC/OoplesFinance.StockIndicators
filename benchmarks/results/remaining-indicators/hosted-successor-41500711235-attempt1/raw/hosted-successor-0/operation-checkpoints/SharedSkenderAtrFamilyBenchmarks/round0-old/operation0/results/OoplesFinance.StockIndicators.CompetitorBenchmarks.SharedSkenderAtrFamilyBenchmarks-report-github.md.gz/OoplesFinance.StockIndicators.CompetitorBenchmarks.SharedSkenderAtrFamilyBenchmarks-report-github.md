```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)elier [21]** | **1000**  |   **216.5 μs** |   **7.66 μs** |  **4.56 μs** |       **-** |  **73.28 KB** |
| BuilderLatestOnly | Skend(...)elier [21] | 1000  |   204.4 μs |   3.94 μs |  2.06 μs |       - |  25.68 KB |
| **BuilderFull**       | **Skend(...)elier [21]** | **10000** | **2,323.4 μs** | **112.27 μs** | **74.26 μs** | **15.6250** | **706.52 KB** |
| BuilderLatestOnly | Skend(...)elier [21] | 10000 | 2,127.7 μs |  21.73 μs | 12.93 μs |       - | 236.73 KB |
