```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)Bands [21]** | **1000**  |   **293.3 μs** |   **9.22 μs** |  **5.49 μs** |       **-** |  **97.39 KB** |
| BuilderLatestOnly | Skend(...)Bands [21] | 1000  |   284.8 μs |   4.02 μs |  2.39 μs |  1.9531 |  49.78 KB |
| **BuilderFull**       | **Skend(...)Bands [21]** | **10000** | **3,057.4 μs** | **139.54 μs** | **72.98 μs** | **31.2500** | **941.61 KB** |
| BuilderLatestOnly | Skend(...)Bands [21] | 10000 | 2,943.3 μs | 135.17 μs | 89.41 μs | 15.6250 | 471.77 KB |
