```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **678.8 μs** | **102.58 μs** | **67.85 μs** |  **64.96 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   589.4 μs |   6.14 μs |  3.21 μs |  17.42 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **6,286.2 μs** |  **56.19 μs** | **29.39 μs** | **627.91 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 6,224.1 μs |  58.58 μs | 34.86 μs |  158.4 KB |
