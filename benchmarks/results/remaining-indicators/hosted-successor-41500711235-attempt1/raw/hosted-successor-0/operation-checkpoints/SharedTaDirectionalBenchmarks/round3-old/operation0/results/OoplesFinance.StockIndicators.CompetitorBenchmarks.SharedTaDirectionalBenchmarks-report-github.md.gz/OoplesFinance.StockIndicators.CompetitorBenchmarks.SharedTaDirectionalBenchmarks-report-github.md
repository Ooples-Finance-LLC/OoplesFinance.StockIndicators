```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **174.4 μs** |   **6.53 μs** |  **3.88 μs** |       **-** |  **64.96 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   164.1 μs |   2.23 μs |  1.16 μs |       - |  17.39 KB |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **1,767.5 μs** |  **97.52 μs** | **58.03 μs** | **15.6250** |  **627.9 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 1,649.8 μs | 101.28 μs | 60.27 μs |       - | 158.13 KB |
