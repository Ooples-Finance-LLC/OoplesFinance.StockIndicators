```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **309.1 μs** |  **29.51 μs** |  **19.52 μs** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   285.7 μs |   3.98 μs |   2.08 μs |   17.4 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **2,984.1 μs** |  **36.38 μs** |  **21.65 μs** | **628.08 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,956.1 μs | 177.67 μs | 117.52 μs |  158.1 KB |
