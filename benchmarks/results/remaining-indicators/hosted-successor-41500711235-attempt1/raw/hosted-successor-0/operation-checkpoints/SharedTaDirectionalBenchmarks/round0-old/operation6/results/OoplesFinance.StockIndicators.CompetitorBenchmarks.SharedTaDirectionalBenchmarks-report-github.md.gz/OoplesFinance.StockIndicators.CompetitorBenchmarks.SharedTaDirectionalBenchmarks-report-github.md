```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **622.3 μs** |  **14.80 μs** |   **9.79 μs** |  **66.72 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   588.3 μs |   8.86 μs |   5.27 μs |   19.1 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **6,229.8 μs** | **155.90 μs** |  **92.77 μs** | **638.84 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 6,229.6 μs | 263.21 μs | 156.63 μs | 168.88 KB |
