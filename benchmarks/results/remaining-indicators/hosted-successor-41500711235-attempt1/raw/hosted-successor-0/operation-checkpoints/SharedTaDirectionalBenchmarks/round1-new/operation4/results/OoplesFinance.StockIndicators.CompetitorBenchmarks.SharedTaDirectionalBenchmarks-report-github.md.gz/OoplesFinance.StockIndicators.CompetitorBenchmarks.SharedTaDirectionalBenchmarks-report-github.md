```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **624.6 μs** |   **4.29 μs** |  **2.24 μs** |     **65 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   624.5 μs |   9.36 μs |  4.89 μs |  17.41 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **6,404.7 μs** | **101.87 μs** | **53.28 μs** | **628.15 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 6,310.9 μs | 129.52 μs | 77.08 μs | 158.26 KB |
