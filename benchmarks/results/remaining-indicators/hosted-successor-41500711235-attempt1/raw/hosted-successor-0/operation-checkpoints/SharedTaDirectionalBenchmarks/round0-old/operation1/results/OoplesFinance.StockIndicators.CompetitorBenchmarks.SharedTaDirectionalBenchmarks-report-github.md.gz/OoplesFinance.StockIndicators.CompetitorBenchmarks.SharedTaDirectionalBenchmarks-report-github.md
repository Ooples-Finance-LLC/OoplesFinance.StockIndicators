```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **166.7 μs** |   **2.12 μs** |  **1.26 μs** |       **-** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   167.3 μs |  14.45 μs |  9.56 μs |       - |  17.39 KB |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,701.1 μs** | **100.41 μs** | **59.75 μs** | **15.6250** | **627.92 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 1,578.2 μs |  31.55 μs | 16.50 μs |       - | 158.14 KB |
