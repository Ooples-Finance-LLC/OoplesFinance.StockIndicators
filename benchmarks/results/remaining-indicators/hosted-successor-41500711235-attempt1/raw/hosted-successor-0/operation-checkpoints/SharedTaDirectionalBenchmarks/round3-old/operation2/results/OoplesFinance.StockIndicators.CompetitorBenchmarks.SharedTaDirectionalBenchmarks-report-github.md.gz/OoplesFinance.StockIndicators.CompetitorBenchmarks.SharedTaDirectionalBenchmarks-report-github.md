```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **303.7 μs** |   **7.78 μs** |   **4.63 μs** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   291.1 μs |   4.13 μs |   2.16 μs |  17.39 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **3,131.6 μs** |  **54.45 μs** |  **32.40 μs** | **628.01 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 3,124.7 μs | 230.01 μs | 152.14 μs | 158.27 KB |
