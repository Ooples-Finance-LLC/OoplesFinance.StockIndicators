```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **184.136 μs** | **18.9265 μs** | **12.5187 μs** | **19.26** |    **1.27** |       **-** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   162.603 μs |  3.0508 μs |  1.5957 μs | 17.01 |    0.25 |       - |      - |  17.39 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDM [23] | 1000  |     9.563 μs |  0.1994 μs |  0.1187 μs |  1.00 |    0.02 |  0.3052 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 1000  |    15.353 μs |  1.0275 μs |  0.5374 μs |  1.61 |    0.06 |  1.2207 |      - |  27.23 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,730.972 μs** | **35.1353 μs** | **20.9085 μs** | **18.20** |    **0.22** | **15.6250** |      **-** | **627.96 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 1,617.346 μs | 83.7198 μs | 49.8203 μs | 17.01 |    0.50 |       - |      - | 158.08 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDM [23] | 10000 |    95.106 μs |  0.6188 μs |  0.3682 μs |  1.00 |    0.01 |  2.9297 |      - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 10000 |   157.605 μs |  8.0880 μs |  4.8130 μs |  1.66 |    0.05 | 11.7188 | 1.9531 | 273.33 KB |        3.50 |
