```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **301.7 μs** |  **6.01 μs** |  **3.14 μs** |  **64.97 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   293.6 μs | 16.41 μs |  9.76 μs |  17.39 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **3,098.3 μs** | **19.25 μs** | **11.46 μs** | **627.99 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,999.7 μs | 73.70 μs | 48.75 μs | 158.14 KB |
