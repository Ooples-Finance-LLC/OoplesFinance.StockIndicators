```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **559.90 μs** |  **27.059 μs** |  **16.102 μs** | **44.26** |    **1.46** |       **-** |      **-** |  **65.65 KB** |        **8.67** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   539.65 μs |   9.456 μs |   5.627 μs | 42.66 |    0.90 |       - |      - |  18.05 KB |        2.38 |
| NativeSingle      | TaLib.Functions.Adx | 1000  |    12.65 μs |   0.429 μs |   0.255 μs |  1.00 |    0.03 |  0.2441 |      - |   7.57 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 1000  |    26.54 μs |   2.150 μs |   1.422 μs |  2.10 |    0.11 |  0.9766 |      - |  26.71 KB |        3.53 |
|                   |                     |       |             |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **5,806.24 μs** | **223.861 μs** | **148.070 μs** | **42.54** |    **1.04** |       **-** |      **-** | **637.62 KB** |        **8.19** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 5,602.10 μs | 146.976 μs |  87.463 μs | 41.05 |    0.62 |       - |      - |  167.8 KB |        2.15 |
| NativeSingle      | TaLib.Functions.Adx | 10000 |   136.48 μs |   0.704 μs |   0.368 μs |  1.00 |    0.00 |  2.9297 |      - |  77.89 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 10000 |   214.28 μs |  12.558 μs |   7.473 μs |  1.57 |    0.05 | 11.7188 | 1.9531 | 272.82 KB |        3.50 |
