```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **302.515 μs** |  **38.9754 μs** |  **23.1936 μs** | **39.09** |    **2.86** |       **-** |      **-** |  **64.97 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   278.338 μs |   4.6942 μs |   2.7934 μs | 35.96 |    0.43 |       - |      - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib(...)lusDI [22] | 1000  |     7.740 μs |   0.0911 μs |   0.0603 μs |  1.00 |    0.01 |  0.3052 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 1000  |    13.832 μs |   0.5044 μs |   0.3336 μs |  1.79 |    0.04 |  1.2207 |      - |  27.24 KB |        3.53 |
|                   |                      |       |              |             |             |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **3,125.178 μs** | **194.1525 μs** | **128.4199 μs** | **34.48** |    **1.41** | **15.6250** |      **-** | **627.93 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,998.434 μs |  87.5912 μs |  57.9362 μs | 33.08 |    0.73 |       - |      - | 158.13 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDI [22] | 10000 |    90.654 μs |   1.9450 μs |   1.1574 μs |  1.00 |    0.02 |  2.9297 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 10000 |   168.780 μs |   8.3217 μs |   5.5043 μs |  1.86 |    0.06 | 11.7188 | 2.9297 | 273.34 KB |        3.50 |
