```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |-------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **555.0 μs** |   **5.28 μs** |   **3.14 μs** |  **65.65 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   559.6 μs |  10.11 μs |   5.29 μs |  18.06 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **5,778.9 μs** |  **90.19 μs** |  **47.17 μs** | **637.56 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 5,798.8 μs | 356.03 μs | 235.49 μs | 167.71 KB |
