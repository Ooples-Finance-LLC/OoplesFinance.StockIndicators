```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |-------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **549.8 μs** |  **12.45 μs** |   **7.41 μs** |  **65.65 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   531.7 μs |   6.79 μs |   4.04 μs |  18.05 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **5,704.6 μs** |  **54.78 μs** |  **28.65 μs** | **637.61 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 5,823.8 μs | 459.16 μs | 303.70 μs | 167.72 KB |
