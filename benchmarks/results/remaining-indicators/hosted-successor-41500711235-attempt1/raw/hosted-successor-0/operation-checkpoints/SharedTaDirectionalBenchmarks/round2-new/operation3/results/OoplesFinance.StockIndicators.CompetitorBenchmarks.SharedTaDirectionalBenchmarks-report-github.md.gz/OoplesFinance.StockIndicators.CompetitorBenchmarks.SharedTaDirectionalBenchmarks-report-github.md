```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **302.729 μs** |  **10.5080 μs** |   **6.2532 μs** | **37.41** |    **1.83** |       **-** |      **-** |  **65.04 KB** |        **8.43** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   281.445 μs |   7.3359 μs |   4.3655 μs | 34.78 |    1.64 |       - |      - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDI [23] | 1000  |     8.108 μs |   0.5857 μs |   0.3874 μs |  1.00 |    0.06 |  0.3052 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 1000  |    13.683 μs |   0.7562 μs |   0.5002 μs |  1.69 |    0.10 |  1.2207 |      - |  27.24 KB |        3.53 |
|                   |                      |       |              |             |             |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **3,029.424 μs** | **173.7706 μs** | **103.4081 μs** | **38.96** |    **1.75** | **15.6250** |      **-** | **627.93 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,845.712 μs |  31.2321 μs |  16.3350 μs | 36.59 |    1.15 |       - |      - | 158.12 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDI [23] | 10000 |    77.840 μs |   3.9167 μs |   2.5906 μs |  1.00 |    0.04 |  2.9297 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 10000 |   138.918 μs |   8.9274 μs |   5.9050 μs |  1.79 |    0.09 | 11.7188 | 2.9297 | 273.34 KB |        3.50 |
