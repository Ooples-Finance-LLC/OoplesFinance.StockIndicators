```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **306.5 μs** |   **7.63 μs** |   **4.54 μs** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   296.1 μs |  11.60 μs |   7.67 μs |   17.4 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **3,278.8 μs** | **275.49 μs** | **182.22 μs** | **628.07 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,975.2 μs |  27.43 μs |  14.35 μs | 158.13 KB |
