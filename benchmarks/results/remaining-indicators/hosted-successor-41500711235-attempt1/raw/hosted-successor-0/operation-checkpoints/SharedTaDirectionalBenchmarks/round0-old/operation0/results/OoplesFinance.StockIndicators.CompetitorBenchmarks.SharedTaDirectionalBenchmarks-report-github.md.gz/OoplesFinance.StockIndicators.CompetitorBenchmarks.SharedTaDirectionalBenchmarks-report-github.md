```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **194.6 μs** | **87.82 μs** | **45.93 μs** |       **-** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   158.4 μs |  1.46 μs |  0.76 μs |       - |  17.39 KB |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **1,697.6 μs** | **19.66 μs** | **10.28 μs** | **15.6250** |  **627.9 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 1,664.6 μs | 26.81 μs | 15.95 μs |       - | 158.05 KB |
