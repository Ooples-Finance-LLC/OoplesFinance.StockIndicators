```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **613.68 μs** |  **19.249 μs** |  **11.455 μs** | **36.08** |    **0.68** |       **-** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   622.01 μs |  46.657 μs |  30.861 μs | 36.57 |    1.75 |       - |      - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib.Functions.Dx | 1000  |    17.01 μs |   0.178 μs |   0.118 μs |  1.00 |    0.01 |  0.2441 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 1000  |    26.57 μs |   2.596 μs |   1.717 μs |  1.56 |    0.10 |  1.2207 |      - |  27.24 KB |        3.53 |
|                   |                    |       |             |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **6,323.41 μs** | **136.691 μs** |  **81.343 μs** | **35.68** |    **1.36** |       **-** |      **-** | **628.08 KB** |        **8.05** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 6,224.19 μs | 204.962 μs | 135.570 μs | 35.12 |    1.47 |       - |      - | 158.21 KB |        2.03 |
| NativeSingle      | TaLib.Functions.Dx | 10000 |   177.45 μs |  10.468 μs |   6.924 μs |  1.00 |    0.05 |  2.9297 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 10000 |   256.97 μs |   9.009 μs |   5.959 μs |  1.45 |    0.06 | 11.7188 | 1.9531 | 273.35 KB |        3.50 |
