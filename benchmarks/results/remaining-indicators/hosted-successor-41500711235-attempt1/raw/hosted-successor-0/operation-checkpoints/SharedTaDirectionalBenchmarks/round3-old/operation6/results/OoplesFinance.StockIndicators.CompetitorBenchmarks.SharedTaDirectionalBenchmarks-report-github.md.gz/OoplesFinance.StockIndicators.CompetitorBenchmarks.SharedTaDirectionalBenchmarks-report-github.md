```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **604.2 μs** |  **25.27 μs** | **15.04 μs** |  **66.72 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   585.0 μs |  19.53 μs | 12.92 μs |  19.13 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **6,218.1 μs** | **151.63 μs** | **90.23 μs** | **638.98 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 6,014.2 μs |  42.15 μs | 27.88 μs | 169.14 KB |
