```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **335.8 μs** |  **54.36 μs** |  **35.95 μs** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   293.8 μs |  12.66 μs |   7.53 μs |  17.39 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **3,343.8 μs** | **177.41 μs** | **117.35 μs** | **628.08 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,991.4 μs |  44.34 μs |  26.39 μs | 158.17 KB |
