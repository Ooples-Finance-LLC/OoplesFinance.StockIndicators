```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **169.949 μs** |   **2.6045 μs** |   **1.5499 μs** | **17.93** |    **0.19** |       **-** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   179.532 μs |  27.2273 μs |  18.0092 μs | 18.94 |    1.82 |       - |      - |  17.38 KB |        2.25 |
| NativeSingle      | TaLib(...)lusDM [22] | 1000  |     9.479 μs |   0.0910 μs |   0.0602 μs |  1.00 |    0.01 |  0.3052 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 1000  |    15.230 μs |   0.7211 μs |   0.4770 μs |  1.61 |    0.05 |  1.0986 |      - |  27.23 KB |        3.53 |
|                   |                      |       |              |             |             |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **1,792.250 μs** | **180.5055 μs** | **119.3932 μs** | **18.80** |    **1.20** | **15.6250** |      **-** | **627.94 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 1,587.802 μs |  35.2343 μs |  18.4282 μs | 16.65 |    0.19 |       - |      - | 158.12 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDM [22] | 10000 |    95.340 μs |   0.4782 μs |   0.2846 μs |  1.00 |    0.00 |  2.9297 |      - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 10000 |   159.065 μs |   9.2954 μs |   6.1483 μs |  1.67 |    0.06 | 11.7188 | 2.9297 | 273.33 KB |        3.50 |
