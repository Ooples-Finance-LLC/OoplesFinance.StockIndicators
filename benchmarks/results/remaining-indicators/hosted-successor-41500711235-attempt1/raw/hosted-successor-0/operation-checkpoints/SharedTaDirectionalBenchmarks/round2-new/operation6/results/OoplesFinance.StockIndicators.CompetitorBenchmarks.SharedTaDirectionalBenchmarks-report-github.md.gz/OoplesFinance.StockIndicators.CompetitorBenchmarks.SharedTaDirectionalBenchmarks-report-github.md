```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **587.33 μs** |   **5.409 μs** |   **3.219 μs** | **38.54** |    **0.23** |       **-** |      **-** |  **66.72 KB** |        **4.45** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   572.47 μs |   6.845 μs |   4.073 μs | 37.57 |    0.28 |       - |      - |  19.13 KB |        1.28 |
| NativeSingle      | TaLib.Functions.Adxr | 1000  |    15.24 μs |   0.095 μs |   0.050 μs |  1.00 |    0.00 |  0.6104 |      - |  14.99 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 1000  |    30.45 μs |   1.516 μs |   1.003 μs |  2.00 |    0.06 |  1.9531 |      - |  45.43 KB |        3.03 |
|                   |                      |       |             |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **6,307.97 μs** | **261.254 μs** | **172.803 μs** | **40.22** |    **1.08** |       **-** |      **-** | **638.58 KB** |        **4.10** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 6,039.56 μs | 238.694 μs | 157.881 μs | 38.51 |    0.99 |       - |      - | 168.88 KB |        1.09 |
| NativeSingle      | TaLib.Functions.Adxr | 10000 |   156.82 μs |   1.682 μs |   1.001 μs |  1.00 |    0.01 |  5.8594 |      - | 155.62 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 10000 |   241.54 μs |  12.884 μs |   6.739 μs |  1.54 |    0.04 | 19.5313 | 5.8594 | 467.32 KB |        3.00 |
