```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)bands [22]** | **1000**  | **117.00 μs** | **25.90 μs** | **17.134 μs** |       **-** |       **-** |  **84.07 KB** |
| BuilderLatestOnly | TaLib(...)bands [22] | 1000  |  98.55 μs | 12.29 μs |  8.127 μs |  0.9766 |       - |  36.46 KB |
| **BuilderFull**       | **TaLib(...)bands [22]** | **10000** | **720.34 μs** | **38.49 μs** | **22.903 μs** | **31.2500** | **11.7188** | **787.57 KB** |
| BuilderLatestOnly | TaLib(...)bands [22] | 10000 | 681.02 μs | 85.79 μs | 56.744 μs | 11.7188 |  3.9063 | 317.75 KB |
