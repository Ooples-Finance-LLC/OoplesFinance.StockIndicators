```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)bands [22]** | **1000**  | **136.2 μs** | **14.53 μs** |  **9.61 μs** |       **-** |       **-** |  **84.07 KB** |
| BuilderLatestOnly | TaLib(...)bands [22] | 1000  | 101.6 μs | 17.60 μs |  9.20 μs |  0.9766 |       - |  36.46 KB |
| **BuilderFull**       | **TaLib(...)bands [22]** | **10000** | **720.5 μs** | **74.38 μs** | **49.19 μs** | **31.2500** | **11.7188** | **787.57 KB** |
| BuilderLatestOnly | TaLib(...)bands [22] | 10000 | 656.8 μs | 65.63 μs | 39.06 μs | 11.7188 |  3.9063 | 317.74 KB |
