```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error       | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|------------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)bands [22]** | **1000**  | **122.580 μs** |  **22.6533 μs** | **14.9838 μs** | **12.08** |    **1.41** |       **-** |       **-** |  **84.07 KB** |        **3.62** |
| BuilderLatestOnly | TaLib(...)bands [22] | 1000  |  99.076 μs |   9.6509 μs |  6.3835 μs |  9.77 |    0.60 |  0.9766 |       - |  36.46 KB |        1.57 |
| NativeSingle      | TaLib(...)bands [22] | 1000  |  10.144 μs |   0.0512 μs |  0.0268 μs |  1.00 |    0.00 |  0.9155 |  0.0610 |   23.2 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [22] | 1000  |   8.766 μs |   0.8971 μs |  0.5934 μs |  0.86 |    0.06 |  0.9155 |  0.0610 |  23.66 KB |        1.02 |
|                   |                      |       |            |             |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)bands [22]** | **10000** | **753.292 μs** | **108.7279 μs** | **71.9168 μs** |  **8.09** |    **0.74** | **31.2500** | **11.7188** | **787.57 KB** |        **3.36** |
| BuilderLatestOnly | TaLib(...)bands [22] | 10000 | 681.904 μs |  66.2374 μs | 43.8119 μs |  7.33 |    0.45 | 11.7188 |  3.9063 | 317.74 KB |        1.36 |
| NativeSingle      | TaLib(...)bands [22] | 10000 |  93.089 μs |   0.3863 μs |  0.2299 μs |  1.00 |    0.00 |  9.2773 |  2.9297 | 234.14 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [22] | 10000 |  75.813 μs |   1.1492 μs |  0.6011 μs |  0.81 |    0.01 |  9.2773 |  2.9297 |  234.6 KB |        1.00 |
