```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **440.5 μs** |  **13.51 μs** |  **8.04 μs** |       **-** |  **97.03 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   426.1 μs |   2.94 μs |  1.94 μs |       - |  49.44 KB |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **4,509.4 μs** | **150.70 μs** | **99.68 μs** | **31.2500** | **941.37 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 4,321.4 μs |  44.79 μs | 23.43 μs |       - | 471.54 KB |
