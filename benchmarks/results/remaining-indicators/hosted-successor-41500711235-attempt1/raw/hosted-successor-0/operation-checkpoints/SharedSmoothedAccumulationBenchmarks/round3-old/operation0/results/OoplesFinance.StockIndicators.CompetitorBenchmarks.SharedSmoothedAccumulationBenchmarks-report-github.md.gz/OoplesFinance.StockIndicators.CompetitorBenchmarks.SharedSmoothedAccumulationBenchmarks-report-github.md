```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **434.6 μs** |  **10.02 μs** |   **5.24 μs** |       **-** |  **97.03 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   423.4 μs |  11.34 μs |   6.75 μs |       - |  49.43 KB |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **4,500.1 μs** | **245.70 μs** | **162.51 μs** | **31.2500** | **941.37 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 4,393.0 μs | 354.11 μs | 210.72 μs |       - | 471.54 KB |
