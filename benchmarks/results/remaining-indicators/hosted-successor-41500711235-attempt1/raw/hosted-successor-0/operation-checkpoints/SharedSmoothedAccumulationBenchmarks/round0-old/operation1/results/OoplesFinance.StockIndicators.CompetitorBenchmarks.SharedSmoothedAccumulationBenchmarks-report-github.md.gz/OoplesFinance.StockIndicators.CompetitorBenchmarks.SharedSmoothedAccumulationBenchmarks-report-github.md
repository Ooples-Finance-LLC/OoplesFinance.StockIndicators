```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **447.9 μs** |  **72.79 μs** |  **48.14 μs** |  **73.52 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   414.4 μs |  32.42 μs |  21.45 μs |  25.93 KB |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **4,342.9 μs** | **324.63 μs** | **214.72 μs** | **706.84 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 4,070.0 μs | 217.98 μs | 144.18 μs | 237.07 KB |
