```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio  | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|-------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **414.058 μs** |   **9.3884 μs** |   **5.5869 μs** | **103.40** |    **1.46** |       **-** |      **-** |  **73.49 KB** |        **9.42** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   403.441 μs |   6.0009 μs |   3.9692 μs | 100.75 |    1.12 |       - |      - |  25.93 KB |        3.32 |
| NativeSingle      | TaLib(...)AdOsc [21] | 1000  |     4.004 μs |   0.0483 μs |   0.0253 μs |   1.00 |    0.01 |  0.3052 |      - |    7.8 KB |        1.00 |
| NativeParallel    | TaLib(...)AdOsc [21] | 1000  |    12.671 μs |   1.2832 μs |   0.8488 μs |   3.16 |    0.20 |  1.2207 |      - |  27.56 KB |        3.53 |
|                   |                      |       |              |             |             |        |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **4,139.381 μs** |  **37.9725 μs** |  **22.5968 μs** | **110.83** |    **0.87** |       **-** |      **-** | **706.88 KB** |        **9.05** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 4,102.920 μs | 167.8457 μs | 111.0195 μs | 109.85 |    2.91 |       - |      - | 237.08 KB |        3.03 |
| NativeSingle      | TaLib(...)AdOsc [21] | 10000 |    37.351 μs |   0.4487 μs |   0.2347 μs |   1.00 |    0.01 |  3.1738 |      - |  78.12 KB |        1.00 |
| NativeParallel    | TaLib(...)AdOsc [21] | 10000 |   112.866 μs |   4.7340 μs |   3.1313 μs |   3.02 |    0.08 | 11.7188 | 2.9297 | 273.66 KB |        3.50 |
