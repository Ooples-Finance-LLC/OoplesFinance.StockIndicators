```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **450.2 μs** | **46.58 μs** | **30.81 μs** |  **73.49 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   406.4 μs |  7.82 μs |  4.65 μs |  25.93 KB |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **4,187.4 μs** | **49.51 μs** | **25.89 μs** | **706.81 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 4,057.6 μs | 52.21 μs | 27.31 μs |    237 KB |
