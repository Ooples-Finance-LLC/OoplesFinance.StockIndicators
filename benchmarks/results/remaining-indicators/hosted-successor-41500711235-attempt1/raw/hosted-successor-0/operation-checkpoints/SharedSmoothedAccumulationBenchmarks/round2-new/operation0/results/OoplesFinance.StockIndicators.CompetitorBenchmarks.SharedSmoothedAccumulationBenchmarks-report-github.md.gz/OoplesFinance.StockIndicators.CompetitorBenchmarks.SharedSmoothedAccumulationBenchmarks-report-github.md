```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **437.0 μs** |  **12.49 μs** |   **7.43 μs** |  **3.53** |    **0.07** |        **-** |        **-** |       **-** |   **97.03 KB** |        **0.26** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   424.1 μs |   7.82 μs |   4.65 μs |  3.42 |    0.05 |        - |        - |       - |   49.44 KB |        0.13 |
| NativeSingle      | Skend(...)inOsc [21] | 1000  |   123.9 μs |   2.58 μs |   1.35 μs |  1.00 |    0.01 |  14.6484 |   4.8828 |       - |  379.71 KB |        1.00 |
| NativeParallel    | Skend(...)inOsc [21] | 1000  |   218.3 μs |  15.72 μs |   9.36 μs |  1.76 |    0.07 |  39.0625 |  13.6719 |       - |  958.68 KB |        2.52 |
|                   |                      |       |            |           |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **4,674.5 μs** | **536.87 μs** | **355.11 μs** |  **2.39** |    **0.22** |  **31.2500** |        **-** |       **-** |  **941.28 KB** |        **0.25** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 4,339.7 μs | 211.32 μs | 110.53 μs |  2.22 |    0.13 |        - |        - |       - |  471.47 KB |        0.12 |
| NativeSingle      | Skend(...)inOsc [21] | 10000 | 1,959.4 μs | 176.14 μs | 116.51 μs |  1.00 |    0.08 | 140.6250 |  93.7500 | 46.8750 | 3790.35 KB |        1.00 |
| NativeParallel    | Skend(...)inOsc [21] | 10000 | 3,319.8 μs | 250.68 μs | 165.81 μs |  1.70 |    0.12 | 406.2500 | 281.2500 | 62.5000 |  9555.1 KB |        2.52 |
