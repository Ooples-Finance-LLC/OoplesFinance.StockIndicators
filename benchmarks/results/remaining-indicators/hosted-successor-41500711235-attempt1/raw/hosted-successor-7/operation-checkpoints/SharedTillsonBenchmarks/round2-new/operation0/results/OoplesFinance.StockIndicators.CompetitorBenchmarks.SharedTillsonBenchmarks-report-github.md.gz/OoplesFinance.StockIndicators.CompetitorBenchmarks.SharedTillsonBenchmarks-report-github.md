```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation     | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |-------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetT3** | **1000**  |   **126.94 μs** |   **2.479 μs** |   **1.297 μs** |  **3.79** |    **0.13** |   **3.9063** |        **-** |        **-** |   **65.14 KB** |        **0.72** |
| BuilderLatestOnly | Skender.GetT3 | 1000  |   124.96 μs |   0.900 μs |   0.471 μs |  3.73 |    0.12 |   0.9766 |        - |        - |   17.57 KB |        0.19 |
| NativeSingle      | Skender.GetT3 | 1000  |    33.51 μs |   2.003 μs |   1.192 μs |  1.00 |    0.05 |   5.3711 |   0.7324 |        - |   90.24 KB |        1.00 |
| NativeParallel    | Skender.GetT3 | 1000  |    75.44 μs |   3.563 μs |   1.864 μs |  2.25 |    0.09 |  15.6250 |   3.9063 |        - |  234.42 KB |        2.60 |
|                   |               |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetT3** | **10000** | **1,240.87 μs** |  **44.252 μs** |  **29.270 μs** |  **2.51** |    **0.11** |  **31.2500** |   **7.8125** |        **-** |  **628.04 KB** |        **0.70** |
| BuilderLatestOnly | Skender.GetT3 | 10000 | 1,215.02 μs |   7.501 μs |   4.464 μs |  2.45 |    0.10 |   7.8125 |        - |        - |  158.26 KB |        0.18 |
| NativeSingle      | Skender.GetT3 | 10000 |   496.10 μs |  31.775 μs |  21.017 μs |  1.00 |    0.06 | 117.1875 |  89.8438 |  82.0313 |  899.86 KB |        1.00 |
| NativeParallel    | Skender.GetT3 | 10000 | 1,209.58 μs | 233.018 μs | 121.873 μs |  2.44 |    0.25 | 250.0000 | 187.5000 | 140.6250 | 2329.36 KB |        2.59 |
