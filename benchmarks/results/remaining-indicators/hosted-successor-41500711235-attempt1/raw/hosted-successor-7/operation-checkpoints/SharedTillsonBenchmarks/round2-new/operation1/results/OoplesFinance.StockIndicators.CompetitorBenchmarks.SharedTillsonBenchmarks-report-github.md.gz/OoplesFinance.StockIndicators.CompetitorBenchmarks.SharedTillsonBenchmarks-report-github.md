```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.T3** | **1000**  |   **119.873 μs** |  **0.5715 μs** |  **0.2989 μs** | **37.54** |    **0.31** |  **3.9063** |      **-** |  **65.18 KB** |        **9.34** |
| BuilderLatestOnly | TaLib.Functions.T3 | 1000  |   119.429 μs |  3.1534 μs |  1.8765 μs | 37.41 |    0.63 |  0.9766 |      - |  17.57 KB |        2.52 |
| NativeSingle      | TaLib.Functions.T3 | 1000  |     3.193 μs |  0.0446 μs |  0.0265 μs |  1.00 |    0.01 |  0.3967 |      - |   6.98 KB |        1.00 |
| NativeParallel    | TaLib.Functions.T3 | 1000  |     7.057 μs |  0.2715 μs |  0.1615 μs |  2.21 |    0.05 |  1.8311 | 0.0610 |  24.66 KB |        3.53 |
|                   |                    |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.T3** | **10000** | **1,210.097 μs** |  **6.0407 μs** |  **3.5947 μs** | **36.86** |    **1.08** | **31.2500** | **7.8125** | **628.07 KB** |        **8.13** |
| BuilderLatestOnly | TaLib.Functions.T3 | 10000 | 1,214.724 μs | 31.3662 μs | 20.7468 μs | 37.00 |    1.24 |  7.8125 |      - | 158.25 KB |        2.05 |
| NativeSingle      | TaLib.Functions.T3 | 10000 |    32.859 μs |  1.5584 μs |  1.0308 μs |  1.00 |    0.04 |  4.6387 |      - |  77.29 KB |        1.00 |
| NativeParallel    | TaLib.Functions.T3 | 10000 |    62.971 μs |  2.2068 μs |  1.3132 μs |  1.92 |    0.07 | 18.0664 | 4.3945 | 270.75 KB |        3.50 |
