```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation    | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Gen2   | Allocated  | Alloc Ratio |
|------------------ |------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|--------:|-------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.T3** | **1000**  |   **130.32 μs** |  **7.274 μs** |  **4.812 μs** |  **5.85** |    **0.21** |  **3.9063** |       **-** |      **-** |   **65.18 KB** |        **1.34** |
| BuilderLatestOnly | QuanTAlib.T3 | 1000  |   126.41 μs |  1.241 μs |  0.649 μs |  5.67 |    0.04 |  0.9766 |       - |      - |   17.57 KB |        0.36 |
| NativeSingle      | QuanTAlib.T3 | 1000  |    22.28 μs |  0.165 μs |  0.098 μs |  1.00 |    0.01 |  3.0518 |  0.2441 | 0.2441 |   48.69 KB |        1.00 |
| NativeParallel    | QuanTAlib.T3 | 1000  |    64.50 μs |  1.634 μs |  1.081 μs |  2.89 |    0.05 |  7.3242 |  0.9766 | 0.9766 |  112.86 KB |        2.32 |
|                   |              |       |             |           |           |       |         |         |         |        |            |             |
| **BuilderFull**       | **QuanTAlib.T3** | **10000** | **1,193.69 μs** |  **9.418 μs** |  **4.926 μs** |  **6.16** |    **0.22** | **31.2500** |  **7.8125** |      **-** |  **628.07 KB** |        **1.33** |
| BuilderLatestOnly | QuanTAlib.T3 | 10000 | 1,201.87 μs | 26.800 μs | 15.948 μs |  6.20 |    0.24 |  7.8125 |       - |      - |  158.25 KB |        0.34 |
| NativeSingle      | QuanTAlib.T3 | 10000 |   193.97 μs | 11.478 μs |  7.592 μs |  1.00 |    0.05 | 28.3203 |  4.8828 |      - |  470.57 KB |        1.00 |
| NativeParallel    | QuanTAlib.T3 | 10000 |   290.57 μs | 23.878 μs | 15.794 μs |  1.50 |    0.09 | 64.4531 | 11.7188 |      - | 1062.08 KB |        2.26 |
