```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation     | Count | Mean       | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |-------------- |------ |-----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetT3** | **1000**  |   **130.2 μs** |  **5.74 μs** |  **3.42 μs** |  **3.9063** |      **-** |  **65.18 KB** |
| BuilderLatestOnly | Skender.GetT3 | 1000  |   127.0 μs |  3.68 μs |  2.19 μs |  0.9766 |      - |  17.57 KB |
| **BuilderFull**       | **Skender.GetT3** | **10000** | **1,224.9 μs** | **20.57 μs** | **13.60 μs** | **31.2500** | **7.8125** | **628.08 KB** |
| BuilderLatestOnly | Skender.GetT3 | 10000 | 1,206.3 μs | 22.10 μs | 14.62 μs |  7.8125 |      - | 158.24 KB |
