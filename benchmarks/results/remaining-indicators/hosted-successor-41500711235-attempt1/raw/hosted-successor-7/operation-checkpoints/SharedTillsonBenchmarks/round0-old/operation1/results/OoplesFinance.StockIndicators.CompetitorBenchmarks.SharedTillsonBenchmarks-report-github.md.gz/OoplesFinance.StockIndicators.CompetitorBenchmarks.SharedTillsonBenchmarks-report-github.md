```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error   | StdDev  | Gen0    | Gen1   | Allocated |
|------------------ |------------------- |------ |-----------:|--------:|--------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib.Functions.T3** | **1000**  |   **121.9 μs** | **3.75 μs** | **2.23 μs** |  **3.9063** |      **-** |  **65.18 KB** |
| BuilderLatestOnly | TaLib.Functions.T3 | 1000  |   120.6 μs | 0.73 μs | 0.43 μs |  0.9766 |      - |  17.57 KB |
| **BuilderFull**       | **TaLib.Functions.T3** | **10000** | **1,214.1 μs** | **5.87 μs** | **3.49 μs** | **31.2500** | **7.8125** | **628.08 KB** |
| BuilderLatestOnly | TaLib.Functions.T3 | 10000 | 1,207.8 μs | 7.80 μs | 4.64 μs |  7.8125 |      - | 158.25 KB |
