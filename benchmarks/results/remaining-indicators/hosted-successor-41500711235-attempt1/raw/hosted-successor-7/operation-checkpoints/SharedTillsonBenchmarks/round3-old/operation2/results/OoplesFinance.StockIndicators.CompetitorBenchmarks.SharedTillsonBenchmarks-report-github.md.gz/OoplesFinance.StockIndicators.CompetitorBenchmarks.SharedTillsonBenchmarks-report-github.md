```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation    | Count | Mean       | Error   | StdDev  | Gen0    | Gen1   | Allocated |
|------------------ |------------- |------ |-----------:|--------:|--------:|--------:|-------:|----------:|
| **BuilderFull**       | **QuanTAlib.T3** | **1000**  |   **128.8 μs** | **0.42 μs** | **0.22 μs** |  **3.9063** |      **-** |  **65.18 KB** |
| BuilderLatestOnly | QuanTAlib.T3 | 1000  |   130.2 μs | 4.21 μs | 2.78 μs |  0.9766 |      - |  17.57 KB |
| **BuilderFull**       | **QuanTAlib.T3** | **10000** | **1,207.5 μs** | **3.13 μs** | **1.64 μs** | **31.2500** | **7.8125** | **628.07 KB** |
| BuilderLatestOnly | QuanTAlib.T3 | 10000 | 1,191.4 μs | 4.00 μs | 2.38 μs |  7.8125 |      - | 158.24 KB |
