```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |----------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Fwma** | **1000**  |  **64.05 μs** | **10.102 μs** |  **6.682 μs** |  **1.09** |    **0.11** |   **1.9531** |       **-** |   **60.39 KB** |        **0.24** |
| BuilderLatestOnly | QuanTAlib.Fwma | 1000  |  58.75 μs |  2.222 μs |  1.469 μs |  1.00 |    0.02 |   0.4883 |       - |   12.46 KB |        0.05 |
| NativeSingle      | QuanTAlib.Fwma | 1000  |  58.63 μs |  0.350 μs |  0.183 μs |  1.00 |    0.00 |  15.1367 |  0.4883 |   254.5 KB |        1.00 |
| NativeParallel    | QuanTAlib.Fwma | 1000  |  58.10 μs |  0.911 μs |  0.603 μs |  0.99 |    0.01 |  16.1133 |  0.4883 |   262.7 KB |        1.03 |
|                   |                |       |           |           |           |       |         |          |         |            |             |
| **BuilderFull**       | **QuanTAlib.Fwma** | **10000** | **333.39 μs** | **31.308 μs** | **20.709 μs** |  **0.57** |    **0.03** |  **33.2031** | **11.7188** |  **552.89 KB** |        **0.22** |
| BuilderLatestOnly | QuanTAlib.Fwma | 10000 | 330.11 μs | 30.644 μs | 20.269 μs |  0.57 |    0.03 |   3.9063 |       - |   82.79 KB |        0.03 |
| NativeSingle      | QuanTAlib.Fwma | 10000 | 581.84 μs |  2.243 μs |  1.173 μs |  1.00 |    0.00 | 156.2500 | 31.2500 | 2564.29 KB |        1.00 |
| NativeParallel    | QuanTAlib.Fwma | 10000 | 364.75 μs | 16.340 μs | 10.808 μs |  0.63 |    0.02 | 158.2031 | 31.2500 | 2572.66 KB |        1.00 |
