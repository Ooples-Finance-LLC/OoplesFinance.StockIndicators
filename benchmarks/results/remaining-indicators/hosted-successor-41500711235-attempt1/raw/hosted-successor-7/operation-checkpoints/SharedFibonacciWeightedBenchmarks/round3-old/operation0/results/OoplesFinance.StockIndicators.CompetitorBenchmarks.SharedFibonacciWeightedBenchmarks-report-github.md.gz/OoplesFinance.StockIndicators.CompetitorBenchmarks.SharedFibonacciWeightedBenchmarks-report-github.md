```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Fwma** | **1000**  |  **62.89 μs** |  **9.261 μs** |  **6.126 μs** |  **1.9531** |       **-** |  **60.31 KB** |
| BuilderLatestOnly | QuanTAlib.Fwma | 1000  |  58.95 μs |  3.008 μs |  1.989 μs |  0.4883 |       - |  12.46 KB |
| **BuilderFull**       | **QuanTAlib.Fwma** | **10000** | **331.87 μs** | **32.855 μs** | **19.551 μs** | **33.2031** | **11.7188** | **552.85 KB** |
| BuilderLatestOnly | QuanTAlib.Fwma | 10000 | 348.51 μs | 44.580 μs | 29.487 μs |  3.9063 |       - |  82.79 KB |
