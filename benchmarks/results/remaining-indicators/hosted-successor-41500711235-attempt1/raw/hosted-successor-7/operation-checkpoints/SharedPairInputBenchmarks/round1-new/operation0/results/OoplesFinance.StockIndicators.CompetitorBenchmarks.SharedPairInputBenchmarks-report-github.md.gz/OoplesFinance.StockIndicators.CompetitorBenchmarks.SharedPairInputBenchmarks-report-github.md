```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **510.3 μs** | **135.35 μs** | **89.52 μs** |       **-** |  **69.36 KB** |
| BuilderLatestOnly | 1000  | Beta      |   332.9 μs |  31.84 μs | 21.06 μs |       - |  21.66 KB |
| **BuilderFull**       | **10000** | **Beta**      | **3,268.2 μs** |  **86.61 μs** | **45.30 μs** | **31.2500** |  **632.3 KB** |
| BuilderLatestOnly | 10000 | Beta      | 3,302.9 μs | 131.87 μs | 87.22 μs |       - | 162.48 KB |
