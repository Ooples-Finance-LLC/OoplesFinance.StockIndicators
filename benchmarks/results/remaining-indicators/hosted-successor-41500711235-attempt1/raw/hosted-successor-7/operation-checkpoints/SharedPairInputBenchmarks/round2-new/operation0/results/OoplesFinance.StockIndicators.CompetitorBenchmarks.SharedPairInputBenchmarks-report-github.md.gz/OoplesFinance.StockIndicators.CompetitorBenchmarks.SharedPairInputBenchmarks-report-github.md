```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **464.939 μs** |  **6.8582 μs** |  **3.5870 μs** | **70.40** |    **0.57** |       **-** |      **-** |  **69.36 KB** |        **9.00** |
| BuilderLatestOnly | 1000  | Beta      |   310.685 μs | 26.4304 μs | 15.7283 μs | 47.04 |    2.27 |       - |      - |  21.67 KB |        2.81 |
| NativeSingle      | 1000  | Beta      |     6.605 μs |  0.0460 μs |  0.0240 μs |  1.00 |    0.00 |  0.4272 |      - |   7.71 KB |        1.00 |
| NativeParallel    | 1000  | Beta      |     4.808 μs |  0.3240 μs |  0.2143 μs |  0.73 |    0.03 |  0.4883 |      - |   7.98 KB |        1.03 |
|                   |       |           |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **10000** | **Beta**      | **3,137.923 μs** | **28.2261 μs** | **14.7628 μs** | **48.00** |    **0.58** | **31.2500** |      **-** |  **632.3 KB** |        **8.10** |
| BuilderLatestOnly | 10000 | Beta      | 3,085.325 μs | 35.6527 μs | 18.6471 μs | 47.19 |    0.59 |       - |      - | 162.52 KB |        2.08 |
| NativeSingle      | 10000 | Beta      |    65.385 μs |  1.3009 μs |  0.7741 μs |  1.00 |    0.02 |  4.3945 | 0.4883 |  78.03 KB |        1.00 |
| NativeParallel    | 10000 | Beta      |    44.735 μs |  5.7052 μs |  3.3951 μs |  0.68 |    0.05 |  4.3945 | 0.4883 |  78.29 KB |        1.00 |
