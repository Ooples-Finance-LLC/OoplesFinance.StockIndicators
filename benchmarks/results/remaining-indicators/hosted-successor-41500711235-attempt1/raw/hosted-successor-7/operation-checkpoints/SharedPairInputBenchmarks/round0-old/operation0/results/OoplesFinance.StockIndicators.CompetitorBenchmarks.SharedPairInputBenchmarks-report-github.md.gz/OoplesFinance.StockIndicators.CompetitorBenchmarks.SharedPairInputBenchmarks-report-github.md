```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **521.8 μs** |  **19.55 μs** | **11.63 μs** |       **-** |  **69.36 KB** |
| BuilderLatestOnly | 1000  | Beta      |   320.4 μs |  22.80 μs | 13.57 μs |       - |  21.67 KB |
| **BuilderFull**       | **10000** | **Beta**      | **3,202.4 μs** |  **44.03 μs** | **23.03 μs** | **31.2500** | **632.38 KB** |
| BuilderLatestOnly | 10000 | Beta      | 3,234.7 μs | 121.81 μs | 72.49 μs |       - | 162.46 KB |
