```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **663.9 μs** | **112.79 μs** |  **74.61 μs** |       **-** |  **69.36 KB** |
| BuilderLatestOnly | 1000  | Beta      |   316.9 μs |  17.50 μs |  10.42 μs |       - |  21.65 KB |
| **BuilderFull**       | **10000** | **Beta**      | **3,228.9 μs** | **195.75 μs** | **102.38 μs** | **31.2500** | **632.37 KB** |
| BuilderLatestOnly | 10000 | Beta      | 3,265.9 μs | 149.05 μs |  98.58 μs |       - | 162.35 KB |
