```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **1.507 ms** | **0.0334 ms** | **0.0199 ms** |  **69.06 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1.492 ms | 0.0809 ms | 0.0535 ms |  21.39 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **16.199 ms** | **1.4617 ms** | **0.9668 ms** | **632.93 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 15.487 ms | 0.0623 ms | 0.0326 ms | 162.97 KB |
