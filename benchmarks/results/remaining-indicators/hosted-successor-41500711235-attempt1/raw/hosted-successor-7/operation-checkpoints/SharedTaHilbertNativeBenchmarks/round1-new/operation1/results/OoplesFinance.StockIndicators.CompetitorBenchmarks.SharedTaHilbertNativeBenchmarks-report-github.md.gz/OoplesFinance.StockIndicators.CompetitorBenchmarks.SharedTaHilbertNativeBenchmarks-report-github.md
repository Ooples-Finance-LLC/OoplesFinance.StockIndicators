```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **1.589 ms** | **0.0166 ms** | **0.0099 ms** |  **84.94 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1.516 ms | 0.0099 ms | 0.0059 ms |  37.29 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **16.300 ms** | **0.0562 ms** | **0.0294 ms** |  **789.3 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 16.724 ms | 0.7461 ms | 0.4935 ms |  319.2 KB |
