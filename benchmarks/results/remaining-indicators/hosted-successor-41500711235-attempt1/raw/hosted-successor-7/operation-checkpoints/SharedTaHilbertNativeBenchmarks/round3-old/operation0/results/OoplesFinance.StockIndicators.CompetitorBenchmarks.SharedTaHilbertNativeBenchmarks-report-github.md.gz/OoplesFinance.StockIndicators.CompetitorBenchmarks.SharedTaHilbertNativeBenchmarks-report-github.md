```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **1.684 ms** | **0.0149 ms** | **0.0078 ms** |  **69.06 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1.494 ms | 0.0068 ms | 0.0040 ms |  21.38 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **15.631 ms** | **0.0412 ms** | **0.0216 ms** | **632.64 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 15.629 ms | 0.0479 ms | 0.0251 ms | 162.79 KB |
