```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **1,525.0 μs** |  **21.93 μs** |  **14.50 μs** |  **3.90** |    **0.09** |       **-** |  **84.94 KB** |        **5.40** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1,483.2 μs |  24.94 μs |  16.50 μs |  3.79 |    0.09 |       - |  37.25 KB |        2.37 |
| NativeSingle      | TaLib(...)tSine [22] | 1000  |    391.5 μs |  12.87 μs |   8.51 μs |  1.00 |    0.03 |       - |  15.73 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 1000  |    528.6 μs |  48.58 μs |  32.13 μs |  1.35 |    0.08 |  3.9063 |  55.96 KB |        3.56 |
|                   |                      |       |             |           |           |       |         |         |           |             |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **15,784.4 μs** | **227.73 μs** | **135.52 μs** |  **3.46** |    **0.03** |       **-** | **789.11 KB** |        **5.04** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 15,795.9 μs |  82.95 μs |  49.36 μs |  3.46 |    0.01 |       - | 319.44 KB |        2.04 |
| NativeSingle      | TaLib(...)tSine [22] | 10000 |  4,560.0 μs |  17.86 μs |   9.34 μs |  1.00 |    0.00 |       - | 156.57 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 10000 |  6,087.4 μs | 431.10 μs | 285.15 μs |  1.33 |    0.06 | 31.2500 | 548.35 KB |        3.50 |
