```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **2,093.6 μs** | **176.34 μs** | **104.94 μs** |  **5.76** |    **0.28** |  **69.06 KB** |        **8.25** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1,474.5 μs |  14.76 μs |   7.72 μs |  4.05 |    0.03 |  21.41 KB |        2.56 |
| NativeSingle      | TaLib(...)Phase [25] | 1000  |    363.8 μs |   4.13 μs |   2.46 μs |  1.00 |    0.01 |   8.37 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 1000  |    505.6 μs |  63.68 μs |  42.12 μs |  1.39 |    0.11 |  30.18 KB |        3.61 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **15,557.7 μs** |  **44.18 μs** |  **23.11 μs** |  **3.58** |    **0.02** | **632.97 KB** |        **8.02** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 15,728.8 μs | 511.38 μs | 304.32 μs |  3.62 |    0.07 | 162.88 KB |        2.07 |
| NativeSingle      | TaLib(...)Phase [25] | 10000 |  4,342.3 μs |  30.83 μs |  20.39 μs |  1.00 |    0.01 |  78.88 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 10000 |  5,614.0 μs | 429.66 μs | 284.20 μs |  1.29 |    0.06 | 276.49 KB |        3.51 |
