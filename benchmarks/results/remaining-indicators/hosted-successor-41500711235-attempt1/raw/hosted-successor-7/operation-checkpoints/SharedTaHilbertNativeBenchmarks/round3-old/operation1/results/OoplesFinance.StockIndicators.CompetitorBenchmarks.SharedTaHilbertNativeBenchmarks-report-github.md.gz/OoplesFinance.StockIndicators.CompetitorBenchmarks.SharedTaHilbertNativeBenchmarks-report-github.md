```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **1.497 ms** | **0.0153 ms** | **0.0091 ms** |  **84.94 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1.467 ms | 0.0246 ms | 0.0163 ms |  37.26 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **15.693 ms** | **0.2729 ms** | **0.1624 ms** | **789.44 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 15.744 ms | 0.1917 ms | 0.1003 ms |  319.3 KB |
