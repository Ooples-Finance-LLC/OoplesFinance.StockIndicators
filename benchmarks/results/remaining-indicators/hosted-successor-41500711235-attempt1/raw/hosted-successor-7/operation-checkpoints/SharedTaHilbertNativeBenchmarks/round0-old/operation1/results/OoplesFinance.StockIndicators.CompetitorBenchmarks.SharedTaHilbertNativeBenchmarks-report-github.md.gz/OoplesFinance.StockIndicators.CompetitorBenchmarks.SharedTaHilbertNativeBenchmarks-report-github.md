```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **2.252 ms** | **0.0153 ms** | **0.0091 ms** |  **84.95 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1.489 ms | 0.0248 ms | 0.0147 ms |  37.22 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **15.830 ms** | **0.0439 ms** | **0.0261 ms** | **789.12 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 16.141 ms | 0.5497 ms | 0.3636 ms | 319.34 KB |
