```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **1.497 ms** | **0.0057 ms** | **0.0030 ms** |  **69.05 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1.463 ms | 0.0263 ms | 0.0156 ms |  21.38 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **15.707 ms** | **0.1931 ms** | **0.1010 ms** | **631.85 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 15.636 ms | 0.0399 ms | 0.0209 ms | 162.92 KB |
