```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDI [23]** |   **286.21 μs** | **11.205 μs** |  **6.668 μs** |  **1.00** |    **0.03** |  **105.67 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDI [23] |    12.82 μs |  0.414 μs |  0.274 μs |  0.04 |    0.00 |   39.95 KB |        0.38 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDI [23]** | **2,640.52 μs** | **17.008 μs** | **10.121 μs** |  **1.00** |    **0.01** | **1034.38 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDI [23] |   115.70 μs |  5.087 μs |  2.661 μs |  0.04 |    0.00 |  329.33 KB |        0.32 |
