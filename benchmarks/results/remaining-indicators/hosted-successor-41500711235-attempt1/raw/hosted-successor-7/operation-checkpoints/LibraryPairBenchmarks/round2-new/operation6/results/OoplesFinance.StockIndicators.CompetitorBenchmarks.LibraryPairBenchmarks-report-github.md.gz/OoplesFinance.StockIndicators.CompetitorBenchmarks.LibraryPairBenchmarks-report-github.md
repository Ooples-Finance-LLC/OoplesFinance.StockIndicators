```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDI [22]** |   **292.09 μs** | **26.745 μs** | **17.690 μs** |  **1.00** |    **0.08** |  **105.64 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDI [22] |    17.96 μs |  1.208 μs |  0.799 μs |  0.06 |    0.00 |    40.6 KB |        0.38 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDI [22]** | **2,744.54 μs** | **28.611 μs** | **14.964 μs** |  **1.00** |    **0.01** | **1034.68 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDI [22] |   136.24 μs |  3.673 μs |  1.921 μs |  0.05 |    0.00 |  327.31 KB |        0.32 |
