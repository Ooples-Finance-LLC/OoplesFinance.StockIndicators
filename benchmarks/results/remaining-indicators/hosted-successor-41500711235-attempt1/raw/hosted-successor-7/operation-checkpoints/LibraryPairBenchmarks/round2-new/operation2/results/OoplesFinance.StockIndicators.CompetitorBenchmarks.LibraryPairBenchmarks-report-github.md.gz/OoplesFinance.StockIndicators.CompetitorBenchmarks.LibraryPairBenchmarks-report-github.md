```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)cdFix [23]** |   **421.90 μs** | **17.545 μs** | **11.605 μs** |  **1.00** |    **0.04** |  **203.21 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)cdFix [23] |    23.02 μs |  6.698 μs |  4.430 μs |  0.05 |    0.01 |  118.69 KB |        0.58 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)cdFix [23]** | **4,016.69 μs** | **38.016 μs** | **25.145 μs** |  **1.00** |    **0.01** | **1994.61 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)cdFix [23] |   175.99 μs | 13.559 μs |  8.069 μs |  0.04 |    0.00 |  1129.8 KB |        0.57 |
