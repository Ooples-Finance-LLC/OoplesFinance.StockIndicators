```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean       | Error   | StdDev  | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |-----------:|--------:|--------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)lusDM [22]** |   **181.4 μs** | **9.58 μs** | **5.70 μs** |  **1.00** |    **0.04** |  **105.71 KB** |        **1.00** |
|        |       |                      |            |         |         |       |         |            |             |
| **Ooples** | **10000** | **TaLib(...)lusDM [22]** | **1,587.5 μs** | **9.49 μs** | **5.65 μs** |  **1.00** |    **0.00** | **1034.05 KB** |        **1.00** |
