```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDM [23]** |   **176.66 μs** |  **1.275 μs** |  **0.758 μs** |  **1.00** |  **105.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDM [23] |    15.92 μs |  1.037 μs |  0.686 μs |  0.09 |   40.59 KB |        0.38 |
|            |       |                      |             |           |           |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDM [23]** | **1,542.56 μs** | **24.700 μs** | **16.338 μs** |  **1.00** | **1035.74 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDM [23] |   137.04 μs |  1.097 μs |  0.653 μs |  0.09 |  329.93 KB |        0.32 |
