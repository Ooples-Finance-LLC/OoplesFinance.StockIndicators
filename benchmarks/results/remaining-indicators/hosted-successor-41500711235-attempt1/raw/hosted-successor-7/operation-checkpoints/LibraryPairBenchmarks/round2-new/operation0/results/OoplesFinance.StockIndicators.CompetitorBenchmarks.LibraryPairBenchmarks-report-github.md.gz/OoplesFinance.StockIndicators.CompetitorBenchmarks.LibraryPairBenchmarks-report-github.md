```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Macd** |   **392.98 μs** | **16.821 μs** | **11.126 μs** |  **1.00** |    **0.04** |  **203.15 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Macd |    20.21 μs |  1.219 μs |  0.725 μs |  0.05 |    0.00 |  118.73 KB |        0.58 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Macd** | **3,700.54 μs** | **27.862 μs** | **16.580 μs** |  **1.00** |    **0.01** | **1992.86 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Macd |   174.79 μs |  9.134 μs |  5.435 μs |  0.05 |    0.00 |  1129.1 KB |        0.57 |
