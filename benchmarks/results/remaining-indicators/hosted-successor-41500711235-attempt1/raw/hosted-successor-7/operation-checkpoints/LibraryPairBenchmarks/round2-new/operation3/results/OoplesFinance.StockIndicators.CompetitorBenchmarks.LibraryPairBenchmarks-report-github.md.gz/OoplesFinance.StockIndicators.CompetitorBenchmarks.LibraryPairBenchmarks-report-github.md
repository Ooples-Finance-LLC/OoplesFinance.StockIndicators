```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Mavp** | **167.44 μs** |  **1.458 μs** |  **0.868 μs** |  **1.00** |    **0.01** |  **107.52 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Mavp |  41.81 μs |  1.500 μs |  0.785 μs |  0.25 |    0.00 |   59.83 KB |        0.56 |
|            |       |                      |           |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Mavp** | **958.80 μs** | **24.406 μs** | **16.143 μs** |  **1.00** |    **0.02** | **1036.24 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Mavp | 402.25 μs | 18.011 μs | 11.913 μs |  0.42 |    0.01 |  525.04 KB |        0.51 |
