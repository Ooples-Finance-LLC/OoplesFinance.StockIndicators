```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |-----------:|---------:|---------:|------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)lusDI [22]** |   **279.5 μs** |  **1.73 μs** |  **1.03 μs** |  **1.00** |  **105.67 KB** |        **1.00** |
|        |       |                      |            |          |          |       |            |             |
| **Ooples** | **10000** | **TaLib(...)lusDI [22]** | **2,651.7 μs** | **30.69 μs** | **18.27 μs** |  **1.00** | **1035.04 KB** |        **1.00** |
