```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)cdExt [23]** |   **448.61 μs** | **26.844 μs** | **17.756 μs** |  **1.00** |    **0.05** |  **752.06 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)cdExt [23] |    18.61 μs |  0.651 μs |  0.388 μs |  0.04 |    0.00 |  118.96 KB |        0.16 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)cdExt [23]** | **4,135.63 μs** | **55.849 μs** | **33.235 μs** |  **1.00** |    **0.01** | **7315.32 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)cdExt [23] |   148.06 μs |  7.811 μs |  4.648 μs |  0.04 |    0.00 | 1129.66 KB |        0.15 |
