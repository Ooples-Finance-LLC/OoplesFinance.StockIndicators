```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDM [22]** |   **199.02 μs** | **5.755 μs** | **3.424 μs** |  **1.00** |    **0.02** |  **105.63 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDM [22] |    15.45 μs | 0.596 μs | 0.312 μs |  0.08 |    0.00 |   37.64 KB |        0.36 |
|            |       |                      |             |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDM [22]** | **1,564.26 μs** | **6.300 μs** | **3.749 μs** |  **1.00** |    **0.00** | **1034.39 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDM [22] |   136.57 μs | 3.187 μs | 1.897 μs |  0.09 |    0.00 |  326.98 KB |        0.32 |
