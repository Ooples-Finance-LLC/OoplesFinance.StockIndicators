```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **472.4 μs** |  **3.00 μs** |  **1.57 μs** |       **-** |   **128.5 KB** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   472.2 μs |  9.61 μs |  5.72 μs |       - |   80.92 KB |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **4,914.9 μs** | **34.36 μs** | **17.97 μs** | **31.2500** | **1254.09 KB** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 4,742.9 μs | 42.41 μs | 22.18 μs | 31.2500 |  784.23 KB |
