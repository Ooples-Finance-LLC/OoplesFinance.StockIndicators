```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **481.48 μs** |   **2.287 μs** |  **1.361 μs** |  **6.09** |    **0.11** |        **-** |        **-** |        **-** |  **128.55 KB** |        **0.40** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   479.32 μs |   3.452 μs |  2.054 μs |  6.07 |    0.11 |        - |        - |        - |   80.92 KB |        0.25 |
| NativeSingle      | Skender.GetMacd | 1000  |    79.03 μs |   2.527 μs |  1.504 μs |  1.00 |    0.03 |  13.1836 |   3.9063 |        - |  324.54 KB |        1.00 |
| NativeParallel    | Skender.GetMacd | 1000  |   157.24 μs |  18.251 μs | 12.072 μs |  1.99 |    0.15 |  36.1328 |  12.6953 |        - |  826.62 KB |        2.55 |
|                   |                 |       |             |            |           |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **4,882.24 μs** |  **76.870 μs** | **40.204 μs** |  **3.11** |    **0.06** |  **31.2500** |        **-** |        **-** |  **1254.1 KB** |        **0.36** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 4,935.80 μs |  82.288 μs | 54.428 μs |  3.14 |    0.06 |  31.2500 |        - |        - |  784.27 KB |        0.23 |
| NativeSingle      | Skender.GetMacd | 10000 | 1,569.97 μs |  45.456 μs | 27.050 μs |  1.00 |    0.02 | 218.7500 | 218.7500 | 218.7500 | 3443.18 KB |        1.00 |
| NativeParallel    | Skender.GetMacd | 10000 | 4,773.72 μs | 144.689 μs | 75.675 μs |  3.04 |    0.07 | 562.5000 | 500.0000 | 312.5000 | 8556.12 KB |        2.48 |
