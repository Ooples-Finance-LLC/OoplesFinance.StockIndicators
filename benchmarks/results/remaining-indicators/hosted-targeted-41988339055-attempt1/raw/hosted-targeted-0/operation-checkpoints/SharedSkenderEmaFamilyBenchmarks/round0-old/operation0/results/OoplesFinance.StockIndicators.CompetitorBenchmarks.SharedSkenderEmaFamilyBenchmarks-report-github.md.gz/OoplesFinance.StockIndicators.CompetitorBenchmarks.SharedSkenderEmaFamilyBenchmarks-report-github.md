```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **491.7 μs** |  **7.49 μs** |  **3.91 μs** |       **-** |   **128.5 KB** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   477.1 μs |  5.46 μs |  2.85 μs |       - |   80.92 KB |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **4,864.9 μs** | **55.67 μs** | **29.12 μs** | **31.2500** | **1254.09 KB** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 4,793.5 μs | 84.61 μs | 50.35 μs | 31.2500 |  784.26 KB |
