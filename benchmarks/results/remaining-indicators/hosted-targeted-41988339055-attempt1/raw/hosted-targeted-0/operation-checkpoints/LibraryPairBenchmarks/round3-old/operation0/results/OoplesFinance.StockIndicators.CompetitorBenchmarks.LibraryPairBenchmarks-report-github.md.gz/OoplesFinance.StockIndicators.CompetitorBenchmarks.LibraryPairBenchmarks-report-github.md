```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId          | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |---------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetMacd** |   **626.1 μs** |  **29.14 μs** |  **15.24 μs** |  **1.00** |    **0.03** |  **331.67 KB** |        **1.00** |
|        |       |                 |            |           |           |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetMacd** | **5,930.6 μs** | **598.39 μs** | **395.80 μs** |  **1.00** |    **0.09** | **3265.32 KB** |        **1.00** |
