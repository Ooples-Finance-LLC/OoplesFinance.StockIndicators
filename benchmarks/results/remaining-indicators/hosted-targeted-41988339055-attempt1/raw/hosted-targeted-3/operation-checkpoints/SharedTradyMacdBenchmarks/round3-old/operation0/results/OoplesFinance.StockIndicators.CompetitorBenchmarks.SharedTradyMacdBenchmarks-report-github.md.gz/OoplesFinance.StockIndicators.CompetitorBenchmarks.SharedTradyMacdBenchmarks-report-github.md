```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |   **511.6 μs** |  **1.97 μs** |  **1.17 μs** |       **-** |  **73.66 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |   517.1 μs |  8.68 μs |  5.74 μs |       - |  26.06 KB |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** | **5,056.9 μs** | **33.12 μs** | **19.71 μs** | **31.2500** | **707.07 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 | 5,057.6 μs | 50.04 μs | 33.10 μs |       - | 237.23 KB |
