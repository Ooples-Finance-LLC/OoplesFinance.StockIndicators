```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |    **519.0 μs** |     **1.76 μs** |     **0.92 μs** |  **0.25** |    **0.00** |         **-** |         **-** |         **-** |    **73.66 KB** |       **0.022** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |    512.9 μs |     4.26 μs |     2.23 μs |  0.25 |    0.00 |         - |         - |         - |    26.06 KB |       0.008 |
| NativeSingle      | Movin(...)ogram [43] | 1000  |  2,056.0 μs |    23.13 μs |    13.76 μs |  1.00 |    0.01 |  203.1250 |  109.3750 |   46.8750 |  3389.08 KB |       1.000 |
| NativeParallel    | Movin(...)ogram [43] | 1000  |  1,821.4 μs |   109.96 μs |    72.73 μs |  0.89 |    0.03 |  359.3750 |  171.8750 |         - |  5597.51 KB |       1.652 |
|                   |                      |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** |  **5,133.0 μs** |    **33.49 μs** |    **19.93 μs** |  **0.22** |    **0.01** |   **31.2500** |         **-** |         **-** |   **707.07 KB** |       **0.021** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 |  5,075.7 μs |    41.77 μs |    21.85 μs |  0.21 |    0.01 |         - |         - |         - |   237.23 KB |       0.007 |
| NativeSingle      | Movin(...)ogram [43] | 10000 | 23,732.8 μs | 1,351.35 μs |   804.17 μs |  1.00 |    0.04 | 2250.0000 | 1750.0000 | 1250.0000 | 33361.09 KB |       1.000 |
| NativeParallel    | Movin(...)ogram [43] | 10000 | 22,758.5 μs | 1,596.83 μs | 1,056.20 μs |  0.96 |    0.05 | 3200.0000 | 2400.0000 | 1400.0000 | 55285.77 KB |       1.657 |
