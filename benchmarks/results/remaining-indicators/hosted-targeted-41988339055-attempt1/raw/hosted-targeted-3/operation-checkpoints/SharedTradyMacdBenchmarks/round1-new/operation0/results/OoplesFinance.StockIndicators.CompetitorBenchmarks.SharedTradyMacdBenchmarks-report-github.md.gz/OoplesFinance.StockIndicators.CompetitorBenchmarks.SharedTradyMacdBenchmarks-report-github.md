```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |   **519.5 μs** |  **8.77 μs** |  **5.22 μs** |       **-** |  **73.66 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |   513.0 μs |  3.97 μs |  2.08 μs |       - |  26.06 KB |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** | **5,123.1 μs** | **34.00 μs** | **17.78 μs** | **31.2500** | **707.07 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 | 5,102.8 μs | 24.01 μs | 14.29 μs |       - | 237.23 KB |
