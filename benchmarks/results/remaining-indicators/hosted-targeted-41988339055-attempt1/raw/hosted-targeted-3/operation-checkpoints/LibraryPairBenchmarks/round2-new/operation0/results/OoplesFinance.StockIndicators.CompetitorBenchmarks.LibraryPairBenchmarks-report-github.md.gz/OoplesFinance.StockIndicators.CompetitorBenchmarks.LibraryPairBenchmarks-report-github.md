```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)ogram [59]** |    **635.9 μs** |    **30.61 μs** |    **18.22 μs** |  **1.00** |    **0.04** |         **-** |         **-** |         **-** |    **240.7 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)ogram [59] |  2,627.0 μs |    54.35 μs |    32.34 μs |  4.13 |    0.12 |         - |         - |         - |  3698.31 KB |       15.36 |
|            |       |                      |             |             |             |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)ogram [59]** |  **6,152.9 μs** |    **38.39 μs** |    **22.85 μs** |  **1.00** |    **0.00** |         **-** |         **-** |         **-** |   **2367.4 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)ogram [59] | 33,839.2 μs | 9,444.20 μs | 6,246.76 μs |  5.50 |    0.97 | 2000.0000 | 1000.0000 | 1000.0000 | 36348.52 KB |       15.35 |
