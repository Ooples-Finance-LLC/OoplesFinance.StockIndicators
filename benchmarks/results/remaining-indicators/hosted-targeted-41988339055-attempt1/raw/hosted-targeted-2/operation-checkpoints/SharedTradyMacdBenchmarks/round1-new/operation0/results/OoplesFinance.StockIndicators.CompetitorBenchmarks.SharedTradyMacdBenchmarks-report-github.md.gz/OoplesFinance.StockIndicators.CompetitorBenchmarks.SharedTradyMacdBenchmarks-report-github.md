```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |   **412.9 μs** |  **1.74 μs** |  **0.91 μs** |  **3.9063** |  **104.99 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |   404.4 μs |  1.46 μs |  0.76 μs |       - |   57.39 KB |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** | **4,180.7 μs** |  **9.85 μs** |  **5.15 μs** | **31.2500** | **1019.63 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 | 4,259.4 μs | 87.10 μs | 57.61 μs | 31.2500 |  549.79 KB |
