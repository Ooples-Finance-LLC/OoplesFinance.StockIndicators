```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |    **415.0 μs** |     **2.31 μs** |     **1.21 μs** |  **0.25** |    **0.00** |         **-** |         **-** |         **-** |   **105.04 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |    410.5 μs |     3.96 μs |     2.36 μs |  0.24 |    0.00 |         - |         - |         - |     57.4 KB |        0.02 |
| NativeSingle      | Movin(...)gence [34] | 1000  |  1,681.7 μs |    16.29 μs |     8.52 μs |  1.00 |    0.01 |  203.1250 |  140.6250 |   46.8750 |  3232.08 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 1000  |  1,498.3 μs |    73.99 μs |    48.94 μs |  0.89 |    0.03 |  367.1875 |  156.2500 |         - |  5670.84 KB |        1.75 |
|                   |                      |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** |  **4,446.8 μs** |   **465.35 μs** |   **307.80 μs** |  **0.21** |    **0.02** |   **31.2500** |         **-** |         **-** |  **1019.66 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 |  4,204.6 μs |    10.88 μs |     5.69 μs |  0.20 |    0.01 |   31.2500 |         - |         - |   549.82 KB |        0.02 |
| NativeSingle      | Movin(...)gence [34] | 10000 | 20,766.6 μs | 2,078.41 μs | 1,236.83 μs |  1.00 |    0.08 | 2000.0000 | 1400.0000 | 1000.0000 | 31911.84 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 10000 | 20,295.4 μs | 2,771.03 μs | 1,648.99 μs |  0.98 |    0.09 | 2800.0000 | 1800.0000 | 1000.0000 | 56067.98 KB |        1.76 |
