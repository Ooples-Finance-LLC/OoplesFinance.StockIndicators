```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |   **411.3 μs** |  **1.11 μs** |  **0.66 μs** |       **-** |  **105.04 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |   403.1 μs |  2.26 μs |  1.50 μs |       - |    57.4 KB |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** | **4,123.8 μs** | **28.01 μs** | **14.65 μs** | **31.2500** | **1019.61 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 | 4,108.5 μs | 52.57 μs | 27.50 μs | 31.2500 |  549.83 KB |
