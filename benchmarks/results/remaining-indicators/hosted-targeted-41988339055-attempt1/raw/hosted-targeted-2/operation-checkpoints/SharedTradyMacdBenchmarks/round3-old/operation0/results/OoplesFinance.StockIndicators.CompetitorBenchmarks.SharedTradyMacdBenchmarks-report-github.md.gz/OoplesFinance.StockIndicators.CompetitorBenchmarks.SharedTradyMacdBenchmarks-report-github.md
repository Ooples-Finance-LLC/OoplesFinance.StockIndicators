```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev  | Gen0    | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |   **409.0 μs** |  **4.38 μs** | **2.61 μs** |       **-** |     **105 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |   406.2 μs |  3.50 μs | 2.09 μs |       - |   57.39 KB |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** | **4,212.8 μs** | **15.22 μs** | **7.96 μs** | **31.2500** | **1019.57 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 | 4,059.0 μs |  9.32 μs | 4.87 μs | 31.2500 |  549.76 KB |
