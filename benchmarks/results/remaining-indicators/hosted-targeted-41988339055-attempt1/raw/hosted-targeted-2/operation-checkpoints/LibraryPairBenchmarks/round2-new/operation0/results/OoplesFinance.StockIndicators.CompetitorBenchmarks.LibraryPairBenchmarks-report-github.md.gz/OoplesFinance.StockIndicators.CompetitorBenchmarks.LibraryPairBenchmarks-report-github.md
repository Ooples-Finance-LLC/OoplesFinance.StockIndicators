```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)gence [50]** |    **503.5 μs** |     **8.09 μs** |     **4.23 μs** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |    **290.1 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)gence [50] |  1,799.6 μs |    33.91 μs |    20.18 μs |  3.57 |    0.05 |         - |         - |         - |  3517.57 KB |       12.13 |
|            |       |                      |             |             |             |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)gence [50]** |  **4,913.8 μs** |    **23.11 μs** |    **13.75 μs** |  **1.00** |    **0.00** |         **-** |         **-** |         **-** |  **2851.94 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)gence [50] | 21,517.2 μs | 2,798.93 μs | 1,463.89 μs |  4.38 |    0.28 | 2000.0000 | 1000.0000 | 1000.0000 | 34685.38 KB |       12.16 |
