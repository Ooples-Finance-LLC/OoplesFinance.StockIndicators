```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetPvo** |   **564.43 μs** | **12.596 μs** |  **8.332 μs** |  **1.00** |    **0.02** |  **290.12 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetPvo |    63.19 μs |  1.586 μs |  0.944 μs |  0.11 |    0.00 |  375.91 KB |        1.30 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetPvo** | **5,342.48 μs** | **32.773 μs** | **19.502 μs** |  **1.00** |    **0.00** | **2853.27 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetPvo |   639.37 μs | 23.268 μs | 13.847 μs |  0.12 |    0.00 | 3868.69 KB |        1.36 |
