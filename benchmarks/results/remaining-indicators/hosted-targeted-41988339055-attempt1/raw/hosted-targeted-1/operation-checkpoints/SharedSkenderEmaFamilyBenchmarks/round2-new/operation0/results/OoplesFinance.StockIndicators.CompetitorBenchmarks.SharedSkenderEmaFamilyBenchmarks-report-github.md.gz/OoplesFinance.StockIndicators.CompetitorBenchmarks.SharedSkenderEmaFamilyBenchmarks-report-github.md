```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **440.22 μs** |   **2.511 μs** |   **1.494 μs** |  **8.62** |    **0.05** |        **-** |        **-** |        **-** |  **105.06 KB** |        **0.37** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   437.05 μs |   2.971 μs |   1.554 μs |  8.56 |    0.05 |        - |        - |        - |   57.42 KB |        0.20 |
| NativeSingle      | Skender.GetPvo | 1000  |    51.08 μs |   0.466 μs |   0.244 μs |  1.00 |    0.01 |  17.0898 |   3.4180 |        - |  285.61 KB |        1.00 |
| NativeParallel    | Skender.GetPvo | 1000  |   107.99 μs |   6.257 μs |   3.724 μs |  2.11 |    0.07 |  46.8750 |  15.6250 |        - |  729.53 KB |        2.55 |
|                   |                |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **4,586.58 μs** |  **10.896 μs** |   **5.699 μs** |  **5.22** |    **0.07** |  **31.2500** |        **-** |        **-** | **1019.58 KB** |        **0.33** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 4,670.90 μs |  19.843 μs |  10.378 μs |  5.31 |    0.07 |  31.2500 |        - |        - |   549.8 KB |        0.18 |
| NativeSingle      | Skender.GetPvo | 10000 |   879.22 μs |  20.744 μs |  12.344 μs |  1.00 |    0.02 | 164.0625 | 164.0625 | 164.0625 |  3052.2 KB |        1.00 |
| NativeParallel    | Skender.GetPvo | 10000 | 3,295.96 μs | 740.575 μs | 489.845 μs |  3.75 |    0.53 | 625.0000 | 500.0000 | 250.0000 | 7580.64 KB |        2.48 |
