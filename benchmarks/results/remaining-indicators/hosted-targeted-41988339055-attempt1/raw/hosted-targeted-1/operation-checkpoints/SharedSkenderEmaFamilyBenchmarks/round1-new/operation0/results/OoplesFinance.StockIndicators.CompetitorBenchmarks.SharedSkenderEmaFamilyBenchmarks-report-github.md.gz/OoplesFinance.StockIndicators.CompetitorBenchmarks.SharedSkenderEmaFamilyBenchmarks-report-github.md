```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |--------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **469.9 μs** |  **4.68 μs** |  **2.79 μs** |       **-** |  **105.06 KB** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   457.5 μs |  5.25 μs |  3.48 μs |       - |   57.42 KB |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **4,660.9 μs** | **49.08 μs** | **29.21 μs** | **31.2500** | **1019.61 KB** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 4,665.6 μs | 93.56 μs | 55.68 μs | 31.2500 |  549.84 KB |
