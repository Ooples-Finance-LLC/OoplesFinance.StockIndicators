```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **491.1 μs** | **11.26 μs** |  **5.89 μs** |       **-** | **105.06 KB** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   474.9 μs |  5.92 μs |  3.52 μs |       - |  57.41 KB |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **4,859.2 μs** | **54.54 μs** | **32.45 μs** | **31.2500** | **1019.6 KB** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 4,824.6 μs | 16.46 μs |  8.61 μs | 31.2500 | 549.75 KB |
