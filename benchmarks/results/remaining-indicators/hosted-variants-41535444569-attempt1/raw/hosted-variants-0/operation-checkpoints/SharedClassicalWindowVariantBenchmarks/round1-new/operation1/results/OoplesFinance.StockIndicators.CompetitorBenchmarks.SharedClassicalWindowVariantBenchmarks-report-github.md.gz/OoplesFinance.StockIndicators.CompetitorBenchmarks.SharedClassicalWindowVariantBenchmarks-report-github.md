```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Method | Count | Mean       | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------- |------ |-----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Trima**  | **1000**  |   **240.3 μs** |  **18.44 μs** | **12.20 μs** |       **-** |       **-** |  **77.73 KB** |
| BuilderLatestOnly | Trima  | 1000  |   156.1 μs |  11.00 μs |  7.28 μs |  0.9766 |       - |  30.09 KB |
| **BuilderFull**       | **Trima**  | **10000** | **1,345.5 μs** | **119.38 μs** | **78.96 μs** | **39.0625** | **15.6250** | **640.61 KB** |
| BuilderLatestOnly | Trima  | 10000 | 1,329.8 μs |  80.71 μs | 53.38 μs |  7.8125 |       - | 170.77 KB |
