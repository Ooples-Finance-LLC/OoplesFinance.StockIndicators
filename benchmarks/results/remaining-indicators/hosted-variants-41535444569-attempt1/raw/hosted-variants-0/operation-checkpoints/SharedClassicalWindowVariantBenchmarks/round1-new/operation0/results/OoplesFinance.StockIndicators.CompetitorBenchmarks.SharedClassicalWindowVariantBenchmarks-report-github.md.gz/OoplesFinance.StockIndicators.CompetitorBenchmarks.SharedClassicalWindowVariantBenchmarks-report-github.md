```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Method | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Wma**    | **1000**  |   **178.8 μs** | **31.60 μs** | **18.81 μs** |       **-** |       **-** |  **78.26 KB** |
| BuilderLatestOnly | Wma    | 1000  |   161.4 μs | 10.25 μs |  6.78 μs |  1.9531 |       - |  30.65 KB |
| **BuilderFull**       | **Wma**    | **10000** | **1,425.0 μs** | **80.55 μs** | **47.94 μs** | **31.2500** | **15.6250** | **641.24 KB** |
| BuilderLatestOnly | Wma    | 10000 | 1,397.4 μs | 95.64 μs | 56.92 μs |  7.8125 |       - | 171.34 KB |
