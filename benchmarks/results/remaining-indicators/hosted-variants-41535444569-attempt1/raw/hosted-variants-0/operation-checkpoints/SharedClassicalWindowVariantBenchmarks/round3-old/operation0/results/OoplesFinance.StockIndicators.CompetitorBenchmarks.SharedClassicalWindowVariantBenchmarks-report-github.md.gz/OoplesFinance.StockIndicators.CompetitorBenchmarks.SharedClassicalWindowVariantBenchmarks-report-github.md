```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Method | Count | Mean       | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------- |------ |-----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Wma**    | **1000**  |   **202.7 μs** |   **1.78 μs** |  **1.06 μs** |       **-** |       **-** |  **78.19 KB** |
| BuilderLatestOnly | Wma    | 1000  |   163.4 μs |  10.40 μs |  6.88 μs |  1.9531 |       - |  30.62 KB |
| **BuilderFull**       | **Wma**    | **10000** | **1,410.8 μs** |  **14.33 μs** |  **7.49 μs** | **31.2500** | **15.6250** | **641.16 KB** |
| BuilderLatestOnly | Wma    | 10000 | 1,440.4 μs | 140.10 μs | 83.37 μs |  7.8125 |       - |  171.3 KB |
