```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Method | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------- |------ |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Trima**  | **1000**  |   **200.7 μs** |  **45.49 μs** |  **30.09 μs** |       **-** |       **-** |  **77.69 KB** |
| BuilderLatestOnly | Trima  | 1000  |   148.0 μs |   1.50 μs |   0.78 μs |       - |       - |  30.08 KB |
| **BuilderFull**       | **Trima**  | **10000** | **1,374.6 μs** | **101.22 μs** |  **66.95 μs** | **39.0625** | **15.6250** | **640.58 KB** |
| BuilderLatestOnly | Trima  | 10000 | 1,378.8 μs | 196.35 μs | 129.87 μs |       - |       - | 170.83 KB |
