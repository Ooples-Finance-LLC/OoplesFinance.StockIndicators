```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Method | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------- |------ |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Trima**  | **1000**  |   **221.5 μs** |  **53.56 μs** |  **35.43 μs** |       **-** |       **-** |   **77.7 KB** |
| BuilderLatestOnly | Trima  | 1000  |   158.5 μs |  17.02 μs |  11.26 μs |       - |       - |  30.05 KB |
| **BuilderFull**       | **Trima**  | **10000** | **1,376.8 μs** | **144.70 μs** |  **95.71 μs** | **39.0625** | **15.6250** | **640.58 KB** |
| BuilderLatestOnly | Trima  | 10000 | 1,333.1 μs | 176.36 μs | 104.95 μs |       - |       - |  170.8 KB |
