```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Method | Count | Mean       | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------- |------ |-----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Trima**  | **1000**  |   **168.9 μs** |  **16.34 μs** |  **8.55 μs** |       **-** |       **-** |  **77.66 KB** |
| BuilderLatestOnly | Trima  | 1000  |   159.2 μs |  16.45 μs | 10.88 μs |       - |       - |  30.06 KB |
| **BuilderFull**       | **Trima**  | **10000** | **1,332.0 μs** |  **25.91 μs** | **13.55 μs** | **31.2500** | **15.6250** | **640.64 KB** |
| BuilderLatestOnly | Trima  | 10000 | 1,366.0 μs | 113.28 μs | 74.93 μs |  7.8125 |       - | 170.74 KB |
