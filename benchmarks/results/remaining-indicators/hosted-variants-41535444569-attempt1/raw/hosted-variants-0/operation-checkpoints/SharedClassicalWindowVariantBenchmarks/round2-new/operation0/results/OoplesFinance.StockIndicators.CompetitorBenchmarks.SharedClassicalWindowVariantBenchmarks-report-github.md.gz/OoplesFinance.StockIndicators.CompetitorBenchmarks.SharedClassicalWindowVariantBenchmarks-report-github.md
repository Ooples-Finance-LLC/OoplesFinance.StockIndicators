```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Method | Count | Mean       | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------- |------ |-----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Wma**    | **1000**  |   **202.6 μs** |   **4.47 μs** |  **2.66 μs** |       **-** |       **-** |  **78.26 KB** |
| BuilderLatestOnly | Wma    | 1000  |   164.3 μs |  15.50 μs |  9.22 μs |  1.9531 |       - |  30.66 KB |
| **BuilderFull**       | **Wma**    | **10000** | **1,464.8 μs** | **105.14 μs** | **69.54 μs** | **39.0625** | **15.6250** | **641.16 KB** |
| BuilderLatestOnly | Wma    | 10000 | 1,442.3 μs | 129.80 μs | 85.85 μs |  7.8125 |       - | 171.34 KB |
