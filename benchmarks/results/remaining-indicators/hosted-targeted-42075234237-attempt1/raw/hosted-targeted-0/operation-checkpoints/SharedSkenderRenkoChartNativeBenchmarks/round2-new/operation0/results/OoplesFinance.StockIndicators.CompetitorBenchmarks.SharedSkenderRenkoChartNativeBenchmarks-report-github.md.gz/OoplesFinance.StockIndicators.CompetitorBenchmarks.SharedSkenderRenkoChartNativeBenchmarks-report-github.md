```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method         | Count | Operation        | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|--------------- |------ |----------------- |------------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **Snapshot**       | **1000**  | **Skender.GetRenko** |   **395.13 μs** |  **3.257 μs** |  **1.704 μs** |  **6.13** |    **0.03** |  **46.8750** |       **-** |  **781.64 KB** |       **15.21** |
| NativeSingle   | 1000  | Skender.GetRenko |    64.42 μs |  0.429 μs |  0.255 μs |  1.00 |    0.01 |   2.9297 |       - |    51.4 KB |        1.00 |
| NativeParallel | 1000  | Skender.GetRenko |   125.70 μs |  4.758 μs |  3.147 μs |  1.95 |    0.05 |   8.7891 |  0.9766 |     130 KB |        2.53 |
|                |       |                  |             |           |           |       |         |          |         |            |             |
| **Snapshot**       | **10000** | **Skender.GetRenko** | **3,569.25 μs** | **18.464 μs** | **12.213 μs** |  **4.57** |    **0.02** | **468.7500** | **62.5000** | **7814.03 KB** |       **15.22** |
| NativeSingle   | 10000 | Skender.GetRenko |   780.64 μs |  6.426 μs |  3.361 μs |  1.00 |    0.01 |  31.2500 |  7.8125 |   513.3 KB |        1.00 |
| NativeParallel | 10000 | Skender.GetRenko | 1,047.24 μs | 60.363 μs | 39.926 μs |  1.34 |    0.05 |  78.1250 | 31.2500 | 1309.58 KB |        2.55 |
