```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method   | Count | Operation           | Mean       | Error     | StdDev    | Median     | Gen0     | Allocated  |
|--------- |------ |-------------------- |-----------:|----------:|----------:|-----------:|---------:|-----------:|
| **Snapshot** | **1000**  | **Skender.GetRenkoAtr** |   **578.3 μs** | **303.90 μs** | **201.01 μs** |   **461.1 μs** |  **31.2500** |  **752.59 KB** |
| **Snapshot** | **10000** | **Skender.GetRenkoAtr** | **4,164.9 μs** |  **23.14 μs** |  **13.77 μs** | **4,163.4 μs** | **437.5000** | **7522.26 KB** |
