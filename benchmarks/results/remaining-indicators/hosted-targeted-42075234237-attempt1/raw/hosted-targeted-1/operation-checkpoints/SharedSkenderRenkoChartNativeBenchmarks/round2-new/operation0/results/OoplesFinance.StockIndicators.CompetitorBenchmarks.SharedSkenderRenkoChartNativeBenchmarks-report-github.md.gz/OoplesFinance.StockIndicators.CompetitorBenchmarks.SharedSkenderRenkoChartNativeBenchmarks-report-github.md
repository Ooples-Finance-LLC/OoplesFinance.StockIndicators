```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method         | Count | Operation           | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|--------------- |------ |-------------------- |-----------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **Snapshot**       | **1000**  | **Skender.GetRenkoAtr** |   **684.6 μs** | **412.97 μs** | **273.15 μs** |  **6.20** |    **2.36** |  **31.2500** |       **-** |  **752.59 KB** |        **3.61** |
| NativeSingle   | 1000  | Skender.GetRenkoAtr |   110.5 μs |   0.76 μs |   0.45 μs |  1.00 |    0.01 |  12.6953 |  2.9297 |  208.67 KB |        1.00 |
| NativeParallel | 1000  | Skender.GetRenkoAtr |   141.4 μs |   5.16 μs |   3.07 μs |  1.28 |    0.03 |  15.6250 |  1.9531 |  270.48 KB |        1.30 |
|                |       |                     |            |           |           |       |         |          |         |            |             |
| **Snapshot**       | **10000** | **Skender.GetRenkoAtr** | **4,177.6 μs** |  **24.87 μs** |  **14.80 μs** |  **3.21** |    **0.02** | **437.5000** |       **-** |  **7522.2 KB** |        **3.62** |
| NativeSingle   | 10000 | Skender.GetRenkoAtr | 1,301.8 μs |   8.40 μs |   5.00 μs |  1.00 |    0.01 | 125.0000 | 62.5000 |  2078.5 KB |        1.00 |
| NativeParallel | 10000 | Skender.GetRenkoAtr | 1,537.7 μs |  15.68 μs |   8.20 μs |  1.18 |    0.01 | 156.2500 | 78.1250 | 2686.36 KB |        1.29 |
