```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetRenkoAtr** |   **422.1 μs** |  **15.33 μs** | **10.14 μs** |  **1.00** |    **0.03** |  **758.04 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetRenkoAtr |   128.5 μs |   9.05 μs |  4.73 μs |  0.30 |    0.01 |  225.44 KB |        0.30 |
|            |       |                     |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetRenkoAtr** | **4,147.6 μs** | **112.55 μs** | **66.97 μs** |  **1.00** |    **0.02** | **7559.44 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetRenkoAtr | 1,369.8 μs |  32.71 μs | 21.64 μs |  0.33 |    0.01 | 2148.81 KB |        0.28 |
