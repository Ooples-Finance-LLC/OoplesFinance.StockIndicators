```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method   | Count | Operation            | Mean       | Error     | StdDev    | Gen0     | Gen1    | Gen2    | Allocated  |
|--------- |------ |--------------------- |-----------:|----------:|----------:|---------:|--------:|--------:|-----------:|
| **Snapshot** | **1000**  | **Skend(...)yStop [25]** |   **526.2 μs** |   **7.34 μs** |   **4.37 μs** |        **-** |       **-** |       **-** |  **875.84 KB** |
| **Snapshot** | **10000** | **Skend(...)yStop [25]** | **6,839.4 μs** | **317.79 μs** | **189.11 μs** | **133.3333** | **66.6667** | **66.6667** | **8847.75 KB** |
