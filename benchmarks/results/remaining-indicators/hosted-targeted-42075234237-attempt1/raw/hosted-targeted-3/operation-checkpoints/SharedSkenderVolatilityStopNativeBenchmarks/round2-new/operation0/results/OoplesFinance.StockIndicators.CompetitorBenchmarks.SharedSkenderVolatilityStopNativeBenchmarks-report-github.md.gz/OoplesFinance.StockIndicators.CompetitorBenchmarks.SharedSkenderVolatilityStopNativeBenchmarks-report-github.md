```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method         | Count | Operation            | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Gen2    | Allocated  | Alloc Ratio |
|--------------- |------ |--------------------- |------------:|-----------:|-----------:|------:|--------:|--------:|--------:|--------:|-----------:|------------:|
| **Snapshot**       | **1000**  | **Skend(...)yStop [25]** |   **340.41 μs** |  **11.839 μs** |   **7.045 μs** |  **3.43** |    **0.07** |       **-** |       **-** |       **-** |  **600.47 KB** |        **2.07** |
| NativeSingle   | 1000  | Skend(...)yStop [25] |    99.29 μs |   1.393 μs |   0.829 μs |  1.00 |    0.01 |  2.9297 |       - |       - |  290.21 KB |        1.00 |
| NativeParallel | 1000  | Skend(...)yStop [25] |   151.59 μs |   6.612 μs |   3.935 μs |  1.53 |    0.04 |  7.8125 |  1.9531 |       - |  735.36 KB |        2.53 |
|                |       |                      |             |            |            |       |         |         |         |         |            |             |
| **Snapshot**       | **10000** | **Skend(...)yStop [25]** | **4,012.32 μs** | **230.485 μs** | **152.451 μs** |  **3.16** |    **0.13** | **62.5000** | **62.5000** | **62.5000** | **6039.38 KB** |        **2.09** |
| NativeSingle   | 10000 | Skend(...)yStop [25] | 1,271.71 μs |  45.655 μs |  30.198 μs |  1.00 |    0.03 | 46.8750 | 46.8750 | 46.8750 | 2892.18 KB |        1.00 |
| NativeParallel | 10000 | Skend(...)yStop [25] | 1,867.73 μs |  97.391 μs |  50.937 μs |  1.47 |    0.05 | 93.7500 | 93.7500 | 78.1250 | 7310.28 KB |        2.53 |
