```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)yStop [25]** |   **353.4 μs** |  **41.17 μs** |  **27.23 μs** |  **1.01** |    **0.10** |  **699.89 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)yStop [25] |   133.7 μs |  13.81 μs |   8.22 μs |  0.38 |    0.03 |  405.01 KB |        0.58 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)yStop [25]** | **3,577.1 μs** | **142.39 μs** |  **84.73 μs** |  **1.00** |    **0.03** | **7022.18 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)yStop [25] | 1,269.6 μs | 157.24 μs | 104.00 μs |  0.36 |    0.03 | 3955.13 KB |        0.56 |
