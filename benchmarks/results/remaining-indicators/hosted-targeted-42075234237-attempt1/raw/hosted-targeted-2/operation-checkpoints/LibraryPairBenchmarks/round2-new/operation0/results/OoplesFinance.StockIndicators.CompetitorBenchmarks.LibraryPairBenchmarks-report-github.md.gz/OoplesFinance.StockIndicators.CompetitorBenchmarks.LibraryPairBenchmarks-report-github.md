```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetPrs** |   **141.22 μs** |  **6.584 μs** |  **3.918 μs** |  **1.00** |    **0.04** |  **221.63 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetPrs |    55.49 μs |  2.743 μs |  1.632 μs |  0.39 |    0.02 |  253.31 KB |        1.14 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetPrs** | **1,177.51 μs** | **39.230 μs** | **25.948 μs** |  **1.00** |    **0.03** | **2154.84 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetPrs |   616.19 μs | 24.121 μs | 14.354 μs |  0.52 |    0.02 | 2459.37 KB |        1.14 |
