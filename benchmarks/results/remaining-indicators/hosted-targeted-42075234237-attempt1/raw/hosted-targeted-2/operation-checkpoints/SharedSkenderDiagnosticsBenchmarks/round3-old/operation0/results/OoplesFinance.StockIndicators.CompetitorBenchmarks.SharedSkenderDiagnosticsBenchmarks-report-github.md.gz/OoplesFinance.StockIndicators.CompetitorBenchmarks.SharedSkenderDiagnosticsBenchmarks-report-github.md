```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |--------------- |------ |-----------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetPrs** | **1000**  |   **236.1 μs** |  **12.38 μs** |   **6.48 μs** |  **54.6875** |   **7.8125** |  **991.03 KB** |
| BuilderLatestOnly | Skender.GetPrs | 1000  |   232.3 μs |  10.77 μs |   5.63 μs |  56.6406 |   7.8125 |  943.43 KB |
| **BuilderFull**       | **Skender.GetPrs** | **10000** | **2,410.2 μs** | **121.88 μs** |  **72.53 μs** | **578.1250** | **281.2500** | **9429.33 KB** |
| BuilderLatestOnly | Skender.GetPrs | 10000 | 2,403.5 μs | 238.84 μs | 157.98 μs | 546.8750 | 265.6250 | 8959.54 KB |
