```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |----------:|-----------:|----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetPrs** | **1000**  | **172.34 μs** |  **82.622 μs** | **54.650 μs** |  **6.51** |    **1.97** |        **-** |        **-** |        **-** |  **101.81 KB** |        **0.62** |
| BuilderLatestOnly | Skender.GetPrs | 1000  |  82.83 μs |   7.553 μs |  3.951 μs |  3.13 |    0.15 |   2.9297 |        - |        - |    54.2 KB |        0.33 |
| NativeSingle      | Skender.GetPrs | 1000  |  26.47 μs |   0.687 μs |  0.454 μs |  1.00 |    0.02 |  10.0098 |   1.4648 |        - |  164.79 KB |        1.00 |
| NativeParallel    | Skender.GetPrs | 1000  |  21.80 μs |   1.272 μs |  0.842 μs |  0.82 |    0.03 |  12.6953 |   2.8076 |        - |  184.81 KB |        1.12 |
|                   |                |       |           |            |           |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetPrs** | **10000** | **779.32 μs** |  **47.707 μs** | **28.389 μs** |  **1.83** |    **0.14** |  **54.6875** |  **19.5313** |        **-** |  **945.94 KB** |        **0.58** |
| BuilderLatestOnly | Skender.GetPrs | 10000 | 800.90 μs | 111.960 μs | 66.626 μs |  1.88 |    0.20 |  23.4375 |   7.8125 |        - |  476.16 KB |        0.29 |
| NativeSingle      | Skender.GetPrs | 10000 | 428.61 μs |  52.421 μs | 31.195 μs |  1.00 |    0.10 | 210.9375 | 167.9688 | 152.3438 | 1643.17 KB |        1.00 |
| NativeParallel    | Skender.GetPrs | 10000 | 225.41 μs |  11.149 μs |  6.634 μs |  0.53 |    0.04 | 113.2813 |  54.6875 |        - |  1731.7 KB |        1.05 |
