```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetPrs** | **1000**  | **123.39 μs** | **33.178 μs** | **21.945 μs** |       **-** |       **-** | **101.81 KB** |
| BuilderLatestOnly | Skender.GetPrs | 1000  |  83.61 μs |  6.918 μs |  4.117 μs |  2.9297 |       - |   54.2 KB |
| **BuilderFull**       | **Skender.GetPrs** | **10000** | **808.86 μs** | **83.388 μs** | **55.156 μs** | **54.6875** | **23.4375** | **945.97 KB** |
| BuilderLatestOnly | Skender.GetPrs | 10000 | 777.09 μs | 47.498 μs | 28.265 μs | 27.3438 |  7.8125 |  476.1 KB |
