```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error   | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|--------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **293.0 μs** | **2.01 μs** | **1.19 μs** |       **-** |       **-** |   **89.1 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   288.9 μs | 2.58 μs | 1.53 μs |  1.9531 |       - |   41.5 KB |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **3,113.5 μs** | **9.59 μs** | **5.02 μs** | **46.8750** | **15.6250** | **863.01 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 3,042.0 μs | 9.09 μs | 4.75 μs | 15.6250 |       - | 393.18 KB |
