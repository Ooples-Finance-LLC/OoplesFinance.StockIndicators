```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **524.2 μs** |  **9.57 μs** |  **5.69 μs** |       **-** |  **89.26 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   505.6 μs |  3.49 μs |  2.31 μs |       - |   41.6 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **5,141.1 μs** | **47.62 μs** | **24.91 μs** | **31.2500** | **863.19 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 5,304.7 μs | 15.21 μs |  7.96 μs |       - | 393.38 KB |
