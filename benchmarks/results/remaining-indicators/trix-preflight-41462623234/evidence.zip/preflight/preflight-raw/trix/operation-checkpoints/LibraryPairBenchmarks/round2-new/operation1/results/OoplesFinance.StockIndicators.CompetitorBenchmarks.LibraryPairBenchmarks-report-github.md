```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId          | Mean      | Error     | StdDev    | Ratio | Allocated | Alloc Ratio |
|------- |------ |---------------- |----------:|----------:|----------:|------:|----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetTrix** |  **1.505 ms** | **0.0312 ms** | **0.0163 ms** |  **1.00** | **211.05 KB** |        **1.00** |
|        |       |                 |           |           |           |       |           |             |
| **Ooples** | **10000** | **Skender.GetTrix** | **11.027 ms** | **0.0731 ms** | **0.0383 ms** |  **1.00** | **2073.7 KB** |        **1.00** |
