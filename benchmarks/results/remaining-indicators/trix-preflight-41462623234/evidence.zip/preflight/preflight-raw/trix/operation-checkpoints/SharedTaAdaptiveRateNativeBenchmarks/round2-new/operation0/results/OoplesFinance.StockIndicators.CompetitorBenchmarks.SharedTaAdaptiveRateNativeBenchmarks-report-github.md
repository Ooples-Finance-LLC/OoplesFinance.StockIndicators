```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **291.7 μs** |  **2.61 μs** |  **1.37 μs** |       **-** |       **-** |   **89.1 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   289.1 μs |  4.72 μs |  2.47 μs |  1.9531 |       - |   41.5 KB |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **3,076.3 μs** | **64.60 μs** | **42.73 μs** | **46.8750** | **15.6250** | **863.01 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 3,021.3 μs | 19.65 μs | 11.69 μs | 15.6250 |       - | 393.18 KB |
