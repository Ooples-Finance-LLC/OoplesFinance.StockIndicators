```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Apo** |   **327.74 μs** | **27.944 μs** | **14.615 μs** |  **1.00** |    **0.06** |  **373.16 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Apo |    11.09 μs |  0.680 μs |  0.404 μs |  0.03 |    0.00 |   47.85 KB |        0.13 |
|            |       |                     |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Apo** | **2,936.83 μs** | **33.154 μs** | **19.730 μs** |  **1.00** |    **0.01** | **3553.46 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Apo |    92.31 μs |  5.683 μs |  3.382 μs |  0.03 |    0.00 |  407.27 KB |        0.11 |
