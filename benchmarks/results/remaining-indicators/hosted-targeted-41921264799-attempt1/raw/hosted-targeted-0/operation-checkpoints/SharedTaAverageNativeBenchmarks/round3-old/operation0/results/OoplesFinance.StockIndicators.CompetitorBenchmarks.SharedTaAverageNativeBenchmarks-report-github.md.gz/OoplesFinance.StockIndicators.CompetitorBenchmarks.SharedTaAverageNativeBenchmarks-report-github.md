```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev    | Gen0     | Gen1    | Allocated  |
|------------------ |-------------------- |------ |-----------:|----------:|----------:|---------:|--------:|-----------:|
| **BuilderFull**       | **TaLib.Functions.Apo** | **1000**  |   **417.9 μs** |  **97.67 μs** |  **64.60 μs** |  **15.6250** |       **-** |  **355.23 KB** |
| BuilderLatestOnly | TaLib.Functions.Apo | 1000  |   324.5 μs |  28.32 μs |  16.85 μs |  15.6250 |       - |  307.66 KB |
| **BuilderFull**       | **TaLib.Functions.Apo** | **10000** | **3,077.2 μs** | **218.93 μs** | **144.81 μs** | **187.5000** | **93.7500** | **3167.56 KB** |
| BuilderLatestOnly | TaLib.Functions.Apo | 10000 | 3,056.1 μs | 173.16 μs | 114.53 μs | 156.2500 | 46.8750 | 2697.74 KB |
