```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev    | Gen0     | Gen1    | Allocated  |
|------------------ |-------------------- |------ |-----------:|----------:|----------:|---------:|--------:|-----------:|
| **BuilderFull**       | **TaLib.Functions.Apo** | **1000**  |   **589.6 μs** | **192.03 μs** | **127.01 μs** |  **15.6250** |       **-** |  **355.26 KB** |
| BuilderLatestOnly | TaLib.Functions.Apo | 1000  |   354.5 μs |  48.32 μs |  31.96 μs |  15.6250 |       - |  307.67 KB |
| **BuilderFull**       | **TaLib.Functions.Apo** | **10000** | **3,050.7 μs** | **194.84 μs** | **128.88 μs** | **187.5000** | **93.7500** | **3167.57 KB** |
| BuilderLatestOnly | TaLib.Functions.Apo | 10000 | 3,056.0 μs | 219.82 μs | 145.40 μs | 156.2500 | 46.8750 | 2697.75 KB |
