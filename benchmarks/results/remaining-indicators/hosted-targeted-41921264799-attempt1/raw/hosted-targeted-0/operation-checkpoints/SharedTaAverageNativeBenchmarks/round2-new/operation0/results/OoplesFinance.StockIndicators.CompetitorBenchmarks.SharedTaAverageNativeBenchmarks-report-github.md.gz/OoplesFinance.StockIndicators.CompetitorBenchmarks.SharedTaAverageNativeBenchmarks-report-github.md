```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |-------------------- |------ |-------------:|------------:|------------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Apo** | **1000**  |   **462.065 μs** | **150.0474 μs** |  **99.2471 μs** | **76.40** |   **15.68** |  **15.6250** |       **-** |   **355.3 KB** |       **22.72** |
| BuilderLatestOnly | TaLib.Functions.Apo | 1000  |   327.213 μs |  28.1215 μs |  16.7346 μs | 54.10 |    2.70 |  15.6250 |       - |  307.67 KB |       19.67 |
| NativeSingle      | TaLib.Functions.Apo | 1000  |     6.049 μs |   0.1245 μs |   0.0741 μs |  1.00 |    0.02 |   0.9155 |       - |   15.64 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Apo | 1000  |    10.919 μs |   0.4306 μs |   0.2848 μs |  1.81 |    0.05 |   3.2959 |  0.2441 |    47.7 KB |        3.05 |
|                   |                     |       |              |             |             |       |         |          |         |            |             |
| **BuilderFull**       | **TaLib.Functions.Apo** | **10000** | **3,076.034 μs** | **278.9849 μs** | **184.5313 μs** | **52.99** |    **3.06** | **187.5000** | **93.7500** | **3167.57 KB** |       **20.27** |
| BuilderLatestOnly | TaLib.Functions.Apo | 10000 | 3,003.395 μs | 205.4848 μs | 135.9155 μs | 51.74 |    2.27 | 156.2500 | 46.8750 | 2697.78 KB |       17.26 |
| NativeSingle      | TaLib.Functions.Apo | 10000 |    58.056 μs |   0.7628 μs |   0.4540 μs |  1.00 |    0.01 |   9.2773 |  1.4648 |  156.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Apo | 10000 |   114.803 μs |   3.3534 μs |   2.2181 μs |  1.98 |    0.04 |  30.2734 |  9.7656 |  469.59 KB |        3.00 |
