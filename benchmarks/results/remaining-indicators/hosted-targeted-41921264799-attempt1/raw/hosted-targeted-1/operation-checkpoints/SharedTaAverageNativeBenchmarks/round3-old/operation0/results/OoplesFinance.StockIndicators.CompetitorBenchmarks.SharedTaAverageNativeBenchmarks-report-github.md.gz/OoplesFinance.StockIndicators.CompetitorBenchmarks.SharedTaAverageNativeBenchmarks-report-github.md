```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated |
|------------------ |-------------------- |------ |-----------:|----------:|----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Ppo** | **1000**  |   **777.8 μs** | **160.37 μs** |  **83.88 μs** |  **62.5000** |        **-** |   **1.45 MB** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 1000  |   694.5 μs |  60.30 μs |  39.89 μs |  85.9375 |   7.8125 |   1.41 MB |
| **BuilderFull**       | **TaLib.Functions.Ppo** | **10000** | **7,264.3 μs** | **391.05 μs** | **232.71 μs** | **857.1429** | **428.5714** |   **14.4 MB** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 10000 | 7,705.5 μs | 943.09 μs | 623.80 μs | 833.3333 | 250.0000 |  13.94 MB |
