```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |-------------------- |------ |-------------:|------------:|------------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Ppo** | **1000**  |   **437.582 μs** | **126.6244 μs** |  **83.7542 μs** | **71.20** |   **13.01** |  **15.6250** |       **-** |   **355.3 KB** |       **22.72** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 1000  |   340.542 μs |  70.0215 μs |  46.3149 μs | 55.41 |    7.20 |  15.6250 |       - |  307.67 KB |       19.67 |
| NativeSingle      | TaLib.Functions.Ppo | 1000  |     6.146 μs |   0.0860 μs |   0.0512 μs |  1.00 |    0.01 |   0.9460 |  0.0305 |   15.64 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ppo | 1000  |    11.877 μs |   0.5605 μs |   0.3708 μs |  1.93 |    0.06 |   3.2959 |  0.1831 |    47.7 KB |        3.05 |
|                   |                     |       |              |             |             |       |         |          |         |            |             |
| **BuilderFull**       | **TaLib.Functions.Ppo** | **10000** | **3,024.275 μs** | **315.8876 μs** | **208.9401 μs** | **50.68** |    **3.35** | **187.5000** | **93.7500** | **3167.75 KB** |       **20.27** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 10000 | 3,036.605 μs | 181.5763 μs | 120.1015 μs | 50.88 |    1.94 | 156.2500 | 46.8750 | 2697.77 KB |       17.26 |
| NativeSingle      | TaLib.Functions.Ppo | 10000 |    59.679 μs |   0.5277 μs |   0.3140 μs |  1.00 |    0.01 |   9.2773 |  1.4648 |  156.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ppo | 10000 |   112.045 μs |  12.3313 μs |   8.1564 μs |  1.88 |    0.13 |  30.2734 |  9.7656 |  469.59 KB |        3.00 |
