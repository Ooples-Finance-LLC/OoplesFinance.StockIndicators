```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId              | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |-------------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Ppo** |   **756.2 μs** |  **55.51 μs** |  **36.72 μs** |  **1.00** |    **0.07** |   **1.47 MB** |        **1.00** |
|        |       |                     |            |           |           |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Ppo** | **6,579.2 μs** | **250.66 μs** | **149.17 μs** |  **1.00** |    **0.03** |  **14.78 MB** |        **1.00** |
