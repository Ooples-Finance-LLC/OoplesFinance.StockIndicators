```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ppo** |   **384.99 μs** | **47.051 μs** | **24.609 μs** |  **1.00** |    **0.09** |  **373.16 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ppo |    11.00 μs |  1.174 μs |  0.614 μs |  0.03 |    0.00 |   42.93 KB |        0.12 |
|            |       |                     |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ppo** | **2,988.40 μs** | **42.266 μs** | **25.152 μs** |  **1.00** |    **0.01** | **3553.74 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ppo |   102.75 μs | 24.492 μs | 16.200 μs |  0.03 |    0.01 |  408.91 KB |        0.12 |
