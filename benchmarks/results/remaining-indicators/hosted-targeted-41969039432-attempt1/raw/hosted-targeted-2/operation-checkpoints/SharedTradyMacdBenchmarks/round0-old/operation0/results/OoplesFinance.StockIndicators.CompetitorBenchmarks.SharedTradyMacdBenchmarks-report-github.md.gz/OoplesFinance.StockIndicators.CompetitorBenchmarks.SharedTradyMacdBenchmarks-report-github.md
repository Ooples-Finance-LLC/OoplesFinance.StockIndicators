```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |   **540.8 μs** |  **5.33 μs** |  **3.17 μs** |       **-** |  **105.04 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |   529.8 μs |  2.12 μs |  1.26 μs |       - |    57.4 KB |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** | **5,213.0 μs** | **34.88 μs** | **18.24 μs** | **31.2500** | **1019.63 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 | 5,267.8 μs | 12.26 μs |  8.11 μs | 31.2500 |  549.85 KB |
