```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |    **529.8 μs** |     **6.25 μs** |     **3.27 μs** |  **0.28** |    **0.00** |         **-** |         **-** |         **-** |      **105 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |    536.2 μs |    11.04 μs |     7.30 μs |  0.28 |    0.00 |         - |         - |         - |    57.41 KB |        0.02 |
| NativeSingle      | Movin(...)gence [34] | 1000  |  1,900.2 μs |    27.65 μs |    18.29 μs |  1.00 |    0.01 |  203.1250 |  140.6250 |   46.8750 |  3232.16 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 1000  |  1,765.3 μs |   139.35 μs |    92.17 μs |  0.93 |    0.05 |  359.3750 |  156.2500 |         - |  5670.91 KB |        1.75 |
|                   |                      |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** |  **5,352.7 μs** |    **40.65 μs** |    **26.88 μs** |  **0.26** |    **0.01** |   **31.2500** |         **-** |         **-** |  **1019.66 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 |  5,345.4 μs |    34.80 μs |    20.71 μs |  0.26 |    0.01 |   31.2500 |         - |         - |   549.86 KB |        0.02 |
| NativeSingle      | Movin(...)gence [34] | 10000 | 20,960.3 μs | 1,967.04 μs | 1,301.08 μs |  1.00 |    0.08 | 2000.0000 | 1400.0000 | 1000.0000 | 31912.58 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 10000 | 22,366.8 μs | 1,107.28 μs |   658.92 μs |  1.07 |    0.07 | 2800.0000 | 1800.0000 | 1000.0000 | 56067.74 KB |        1.76 |
