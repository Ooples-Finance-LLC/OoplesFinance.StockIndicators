```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)gence [50]** |    **645.6 μs** |     **7.56 μs** |     **3.95 μs** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |    **290.1 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)gence [50] |  2,478.4 μs |    67.44 μs |    44.60 μs |  3.84 |    0.07 |         - |         - |         - |  3520.85 KB |       12.14 |
|            |       |                      |             |             |             |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)gence [50]** |  **6,418.2 μs** |   **483.23 μs** |   **319.63 μs** |  **1.00** |    **0.07** |         **-** |         **-** |         **-** |  **2857.19 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)gence [50] | 28,223.3 μs | 1,970.97 μs | 1,030.86 μs |  4.41 |    0.25 | 2000.0000 | 1000.0000 | 1000.0000 | 34691.34 KB |       12.14 |
