```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |--------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **516.4 μs** |  **2.59 μs** |  **1.54 μs** |       **-** |  **105.06 KB** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   502.2 μs |  3.93 μs |  2.34 μs |       - |   57.42 KB |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **5,084.4 μs** | **51.45 μs** | **26.91 μs** | **31.2500** | **1019.65 KB** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 5,071.3 μs | 36.62 μs | 24.22 μs | 31.2500 |  549.84 KB |
