```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **528.80 μs** |   **3.543 μs** |   **2.108 μs** |  **7.80** |    **0.18** |        **-** |        **-** |        **-** |  **105.03 KB** |        **0.37** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   525.50 μs |   1.993 μs |   1.186 μs |  7.75 |    0.18 |        - |        - |        - |   57.42 KB |        0.20 |
| NativeSingle      | Skender.GetPvo | 1000  |    67.83 μs |   2.496 μs |   1.651 μs |  1.00 |    0.03 |  17.0898 |   3.4180 |        - |  285.61 KB |        1.00 |
| NativeParallel    | Skender.GetPvo | 1000  |   138.81 μs |  12.139 μs |   8.029 μs |  2.05 |    0.12 |  46.8750 |  15.6250 |        - |  729.53 KB |        2.55 |
|                   |                |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **5,304.71 μs** | **120.879 μs** |  **79.954 μs** |  **4.64** |    **0.12** |  **31.2500** |        **-** |        **-** | **1019.64 KB** |        **0.33** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 5,234.19 μs |  37.380 μs |  22.244 μs |  4.58 |    0.10 |  31.2500 |        - |        - |  549.86 KB |        0.18 |
| NativeSingle      | Skender.GetPvo | 10000 | 1,143.33 μs |  43.303 μs |  25.769 μs |  1.00 |    0.03 | 164.0625 | 164.0625 | 164.0625 |  3052.2 KB |        1.00 |
| NativeParallel    | Skender.GetPvo | 10000 | 3,386.28 μs | 526.000 μs | 347.916 μs |  2.96 |    0.30 | 625.0000 | 468.7500 | 250.0000 | 7581.52 KB |        2.48 |
