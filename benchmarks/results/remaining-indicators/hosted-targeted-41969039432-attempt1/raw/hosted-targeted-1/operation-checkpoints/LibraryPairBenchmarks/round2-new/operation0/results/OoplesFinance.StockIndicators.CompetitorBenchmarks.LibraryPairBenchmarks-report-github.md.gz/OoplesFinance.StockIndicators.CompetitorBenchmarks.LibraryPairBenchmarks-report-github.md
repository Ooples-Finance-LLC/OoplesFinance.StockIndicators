```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error    | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|---------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetPvo** |   **644.02 μs** | **19.38 μs** | **12.821 μs** |  **1.00** |    **0.03** |  **290.12 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetPvo |    85.28 μs | 11.76 μs |  6.153 μs |  0.13 |    0.01 |  375.63 KB |        1.29 |
|            |       |                |             |          |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetPvo** | **6,088.98 μs** | **46.13 μs** | **27.452 μs** |  **1.00** |    **0.01** | **2856.22 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetPvo |   881.30 μs | 44.27 μs | 26.347 μs |  0.14 |    0.00 | 3870.98 KB |        1.36 |
