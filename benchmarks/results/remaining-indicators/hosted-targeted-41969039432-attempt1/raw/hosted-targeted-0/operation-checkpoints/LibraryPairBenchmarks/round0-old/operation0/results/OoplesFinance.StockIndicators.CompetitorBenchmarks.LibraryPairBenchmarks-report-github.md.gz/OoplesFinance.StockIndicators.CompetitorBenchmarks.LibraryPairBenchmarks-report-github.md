```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId          | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |---------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetMacd** |   **535.8 μs** | **14.51 μs** |  **8.64 μs** |  **1.00** |    **0.02** |  **331.71 KB** |        **1.00** |
|        |       |                 |            |          |          |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetMacd** | **5,265.6 μs** | **52.04 μs** | **27.22 μs** |  **1.00** |    **0.01** | **3266.67 KB** |        **1.00** |
