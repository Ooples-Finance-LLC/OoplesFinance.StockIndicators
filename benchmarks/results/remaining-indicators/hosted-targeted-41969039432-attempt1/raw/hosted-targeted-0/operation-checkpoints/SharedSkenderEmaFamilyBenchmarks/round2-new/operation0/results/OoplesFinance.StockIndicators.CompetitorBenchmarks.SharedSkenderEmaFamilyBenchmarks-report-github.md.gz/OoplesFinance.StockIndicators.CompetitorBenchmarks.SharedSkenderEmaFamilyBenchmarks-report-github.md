```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **423.76 μs** |   **1.897 μs** |   **0.992 μs** |  **8.75** |    **0.25** |        **-** |        **-** |        **-** |  **128.55 KB** |        **0.40** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   421.31 μs |   3.783 μs |   2.251 μs |  8.70 |    0.25 |   3.9063 |        - |        - |   80.91 KB |        0.25 |
| NativeSingle      | Skender.GetMacd | 1000  |    48.47 μs |   2.167 μs |   1.433 μs |  1.00 |    0.04 |  19.7754 |   6.3477 |        - |  324.53 KB |        1.00 |
| NativeParallel    | Skender.GetMacd | 1000  |   101.77 μs |   3.222 μs |   1.685 μs |  2.10 |    0.07 |  53.7109 |  19.5313 |        - |  826.62 KB |        2.55 |
|                   |                 |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **4,572.21 μs** | **216.505 μs** | **143.205 μs** |  **4.72** |    **0.16** |  **62.5000** |        **-** |        **-** | **1254.13 KB** |        **0.36** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 4,357.86 μs |  35.514 μs |  18.575 μs |  4.49 |    0.08 |  31.2500 |        - |        - |  784.24 KB |        0.23 |
| NativeSingle      | Skender.GetMacd | 10000 |   969.81 μs |  25.231 μs |  16.689 μs |  1.00 |    0.02 | 218.7500 | 218.7500 | 218.7500 | 3443.09 KB |        1.00 |
| NativeParallel    | Skender.GetMacd | 10000 | 4,159.54 μs | 805.796 μs | 532.984 μs |  4.29 |    0.53 | 750.0000 | 656.2500 | 312.5000 | 8557.12 KB |        2.49 |
