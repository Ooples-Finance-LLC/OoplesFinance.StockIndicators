```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **425.6 μs** |  **2.37 μs** |  **1.41 μs** |       **-** |  **128.51 KB** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   434.5 μs |  2.08 μs |  1.09 μs |  3.9063 |   80.91 KB |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **4,322.9 μs** | **89.16 μs** | **58.97 μs** | **62.5000** | **1254.05 KB** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 4,331.0 μs | 43.62 μs | 25.96 μs | 31.2500 |  784.28 KB |
