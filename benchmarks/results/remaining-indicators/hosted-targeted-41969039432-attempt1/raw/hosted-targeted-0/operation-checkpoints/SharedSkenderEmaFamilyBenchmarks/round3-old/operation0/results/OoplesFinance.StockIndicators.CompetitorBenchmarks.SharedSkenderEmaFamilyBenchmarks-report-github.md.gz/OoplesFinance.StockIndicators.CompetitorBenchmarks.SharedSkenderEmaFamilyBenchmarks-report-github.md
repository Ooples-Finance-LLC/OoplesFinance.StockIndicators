```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **417.8 μs** |  **1.23 μs** |  **0.73 μs** |       **-** |  **128.51 KB** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   420.9 μs |  1.90 μs |  1.00 μs |  3.9063 |   80.91 KB |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **4,275.4 μs** | **27.81 μs** | **14.55 μs** | **62.5000** | **1254.08 KB** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 4,313.8 μs | 42.08 μs | 25.04 μs | 31.2500 |  784.21 KB |
