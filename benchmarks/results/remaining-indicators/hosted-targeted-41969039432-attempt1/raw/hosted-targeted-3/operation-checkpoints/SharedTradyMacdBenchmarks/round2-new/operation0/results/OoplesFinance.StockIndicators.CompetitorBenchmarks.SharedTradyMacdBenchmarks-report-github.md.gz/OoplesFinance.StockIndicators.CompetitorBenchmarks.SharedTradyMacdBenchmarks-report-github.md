```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |    **261.8 μs** |     **2.61 μs** |     **1.55 μs** |  **0.20** |    **0.00** |         **-** |         **-** |         **-** |    **73.65 KB** |       **0.022** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |    264.4 μs |     9.57 μs |     5.69 μs |  0.20 |    0.01 |         - |         - |         - |    26.05 KB |       0.008 |
| NativeSingle      | Movin(...)ogram [43] | 1000  |  1,312.5 μs |    44.51 μs |    29.44 μs |  1.00 |    0.03 |  203.1250 |  101.5625 |   46.8750 |  3388.98 KB |       1.000 |
| NativeParallel    | Movin(...)ogram [43] | 1000  |  1,107.3 μs |    48.59 μs |    32.14 μs |  0.84 |    0.03 |  359.3750 |  179.6875 |         - |  5597.42 KB |       1.652 |
|                   |                      |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** |  **2,569.7 μs** |   **169.48 μs** |    **88.64 μs** |  **0.16** |    **0.02** |   **31.2500** |         **-** |         **-** |   **706.87 KB** |       **0.021** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 |  2,556.2 μs |    83.03 μs |    54.92 μs |  0.16 |    0.01 |         - |         - |         - |    237.1 KB |       0.007 |
| NativeSingle      | Movin(...)ogram [43] | 10000 | 16,463.4 μs | 2,477.96 μs | 1,639.02 μs |  1.01 |    0.13 | 2166.6667 | 1500.0000 | 1166.6667 | 33358.65 KB |       1.000 |
| NativeParallel    | Movin(...)ogram [43] | 10000 | 18,375.6 μs | 3,752.12 μs | 2,481.80 μs |  1.13 |    0.18 | 3000.0000 | 2166.6667 | 1166.6667 | 55282.73 KB |       1.657 |
