```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |   **246.8 μs** |  **2.21 μs** |  **1.16 μs** |  **3.9063** |  **73.61 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |   247.7 μs |  5.65 μs |  3.36 μs |       - |  26.04 KB |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** | **2,533.8 μs** | **71.36 μs** | **42.46 μs** | **31.2500** | **706.79 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 | 2,590.0 μs | 49.58 μs | 32.79 μs |       - | 237.02 KB |
