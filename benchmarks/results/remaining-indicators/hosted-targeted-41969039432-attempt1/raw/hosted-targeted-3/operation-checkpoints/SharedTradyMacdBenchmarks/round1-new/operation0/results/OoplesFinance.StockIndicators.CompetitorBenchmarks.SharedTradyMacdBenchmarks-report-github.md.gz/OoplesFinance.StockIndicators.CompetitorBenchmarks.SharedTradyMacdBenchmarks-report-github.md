```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |   **256.9 μs** |   **6.24 μs** |   **4.12 μs** |  **3.9063** |  **73.61 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |   248.6 μs |   6.24 μs |   3.26 μs |       - |  26.04 KB |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** | **2,506.8 μs** |  **81.41 μs** |  **53.85 μs** | **31.2500** | **706.78 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 | 2,629.7 μs | 171.41 μs | 113.38 μs |       - | 236.98 KB |
