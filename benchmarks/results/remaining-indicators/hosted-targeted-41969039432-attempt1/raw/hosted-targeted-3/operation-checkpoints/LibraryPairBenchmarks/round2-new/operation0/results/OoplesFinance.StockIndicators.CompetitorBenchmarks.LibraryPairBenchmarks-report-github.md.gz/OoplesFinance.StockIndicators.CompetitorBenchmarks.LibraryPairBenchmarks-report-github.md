```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)ogram [59]** |    **328.0 μs** |     **7.51 μs** |   **3.93 μs** |  **1.00** |    **0.02** |         **-** |         **-** |         **-** |   **240.71 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)ogram [59] |  1,415.8 μs |    11.74 μs |   6.98 μs |  4.32 |    0.05 |         - |         - |         - |  3692.17 KB |       15.34 |
|            |       |                      |             |             |           |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)ogram [59]** |  **3,203.6 μs** |    **43.02 μs** |  **28.46 μs** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |  **2359.53 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)ogram [59] | 17,120.3 μs | 1,207.15 μs | 718.36 μs |  5.34 |    0.22 | 2000.0000 | 1000.0000 | 1000.0000 | 36353.69 KB |       15.41 |
