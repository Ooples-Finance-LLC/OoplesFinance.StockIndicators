```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=20000  

```
| Method     | Bars  | PairId              | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Div** |  **28.06 μs** |  **3.112 μs** | **1.627 μs** |  **1.00** |    **0.07** |  **66.53 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Div |  13.69 μs |  0.297 μs | 0.155 μs |  0.49 |    0.02 |  37.98 KB |        0.57 |
|            |       |                     |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Div** |  **83.68 μs** | **14.005 μs** | **8.334 μs** |  **1.01** |    **0.13** | **646.32 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Div | 121.33 μs | 13.179 μs | 7.843 μs |  1.46 |    0.16 | 328.39 KB |        0.51 |
