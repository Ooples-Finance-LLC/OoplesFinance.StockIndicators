```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Sinh** | **120.50 μs** | **11.079 μs** | **6.593 μs** |  **1.00** |    **0.07** |   **66.3 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Sinh |  31.08 μs |  9.662 μs | 6.391 μs |  0.26 |    0.05 |  39.99 KB |        0.60 |
|            |       |                      |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Sinh** | **121.86 μs** |  **3.786 μs** | **2.253 μs** |  **1.00** |    **0.02** | **645.98 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Sinh | 216.15 μs |  3.581 μs | 1.873 μs |  1.77 |    0.03 | 330.31 KB |        0.51 |
