```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=20000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Mult** |  **20.23 μs** |  **1.069 μs** |  **0.636 μs** |  **1.00** |    **0.04** |  **66.53 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Mult |  13.82 μs |  0.839 μs |  0.499 μs |  0.68 |    0.03 |  40.27 KB |        0.61 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Mult** |  **78.62 μs** | **24.279 μs** | **14.448 μs** |  **1.03** |    **0.23** | **646.27 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Mult | 116.47 μs |  1.127 μs |  0.671 μs |  1.52 |    0.22 | 330.31 KB |        0.51 |
