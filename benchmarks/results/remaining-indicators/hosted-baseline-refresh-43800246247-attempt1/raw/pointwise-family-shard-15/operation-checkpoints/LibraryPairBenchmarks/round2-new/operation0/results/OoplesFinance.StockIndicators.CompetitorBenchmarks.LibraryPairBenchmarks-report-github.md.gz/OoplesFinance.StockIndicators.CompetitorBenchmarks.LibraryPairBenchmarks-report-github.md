```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon 6973P-C 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Exp** |  **28.34 μs** |  **2.393 μs** |  **1.424 μs** |  **1.00** |    **0.07** |  **66.24 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Exp |  17.05 μs |  0.684 μs |  0.452 μs |  0.60 |    0.03 |  40.23 KB |        0.61 |
|            |       |                     |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Exp** | **139.80 μs** | **42.047 μs** | **27.811 μs** |  **1.04** |    **0.28** | **643.72 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Exp | 152.35 μs | 22.588 μs | 14.940 μs |  1.13 |    0.23 | 329.38 KB |        0.51 |
