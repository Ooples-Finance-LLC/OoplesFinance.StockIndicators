```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=20000  

```
| Method | Bars  | PairId              | Mean      | Error    | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |-------------------- |----------:|---------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Add** |  **8.550 μs** | **1.007 μs** | **0.5264 μs** |  **1.00** |    **0.08** |  **66.53 KB** |        **1.00** |
|        |       |                     |           |          |           |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Add** | **33.289 μs** | **4.592 μs** | **2.7324 μs** |  **1.01** |    **0.11** | **645.99 KB** |        **1.00** |
