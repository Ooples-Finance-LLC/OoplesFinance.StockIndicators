```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=20000  

```
| Method     | Bars  | PairId              | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Add** |  **8.275 μs** | **0.6760 μs** | **0.3536 μs** |  **1.00** |    **0.06** |   **66.5 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Add |  6.367 μs | 0.2223 μs | 0.1323 μs |  0.77 |    0.03 |  32.77 KB |        0.49 |
|            |       |                     |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Add** | **32.833 μs** | **2.2841 μs** | **1.3592 μs** |  **1.00** |    **0.06** | **640.05 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Add | 58.411 μs | 2.5269 μs | 1.5037 μs |  1.78 |    0.08 | 323.19 KB |        0.50 |
