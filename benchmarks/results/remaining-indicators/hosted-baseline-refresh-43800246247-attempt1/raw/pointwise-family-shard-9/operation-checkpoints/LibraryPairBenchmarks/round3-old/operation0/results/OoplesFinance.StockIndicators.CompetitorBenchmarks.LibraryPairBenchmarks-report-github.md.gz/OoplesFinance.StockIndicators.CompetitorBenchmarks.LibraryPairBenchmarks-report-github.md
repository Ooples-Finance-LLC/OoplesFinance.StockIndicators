```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId              | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |-------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Tan** |  **83.69 μs** | **12.839 μs** | **7.640 μs** |  **1.01** |    **0.12** |   **66.3 KB** |        **1.00** |
|        |       |                     |           |           |          |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Tan** | **134.10 μs** |  **2.357 μs** | **1.403 μs** |  **1.00** |    **0.01** | **645.98 KB** |        **1.00** |
