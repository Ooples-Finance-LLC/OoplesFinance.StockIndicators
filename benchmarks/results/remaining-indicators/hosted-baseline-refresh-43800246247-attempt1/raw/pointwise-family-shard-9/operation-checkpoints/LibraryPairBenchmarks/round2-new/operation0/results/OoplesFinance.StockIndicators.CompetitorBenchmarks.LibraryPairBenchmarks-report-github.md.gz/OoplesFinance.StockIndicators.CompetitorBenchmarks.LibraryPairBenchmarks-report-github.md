```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Tan** | **151.16 μs** | **16.442 μs** | **9.784 μs** |  **1.00** |    **0.08** |   **66.3 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Tan |  31.53 μs |  6.582 μs | 3.917 μs |  0.21 |    0.03 |  39.99 KB |        0.60 |
|            |       |                     |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Tan** | **143.79 μs** |  **3.356 μs** | **1.755 μs** |  **1.00** |    **0.02** | **645.66 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Tan | 275.26 μs |  4.152 μs | 2.172 μs |  1.91 |    0.03 | 327.03 KB |        0.51 |
