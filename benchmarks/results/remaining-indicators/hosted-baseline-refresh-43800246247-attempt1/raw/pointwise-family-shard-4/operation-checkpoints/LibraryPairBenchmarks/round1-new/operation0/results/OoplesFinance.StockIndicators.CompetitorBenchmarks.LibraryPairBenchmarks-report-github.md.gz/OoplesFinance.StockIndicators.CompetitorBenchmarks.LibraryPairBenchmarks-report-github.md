```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean     | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |---------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Ceil** | **77.29 μs** |  **1.768 μs** | **0.925 μs** |  **1.00** |    **0.02** |   **66.3 KB** |        **1.00** |
|        |       |                      |          |           |          |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Ceil** | **54.56 μs** | **12.648 μs** | **7.527 μs** |  **1.02** |    **0.18** | **643.38 KB** |        **1.00** |
