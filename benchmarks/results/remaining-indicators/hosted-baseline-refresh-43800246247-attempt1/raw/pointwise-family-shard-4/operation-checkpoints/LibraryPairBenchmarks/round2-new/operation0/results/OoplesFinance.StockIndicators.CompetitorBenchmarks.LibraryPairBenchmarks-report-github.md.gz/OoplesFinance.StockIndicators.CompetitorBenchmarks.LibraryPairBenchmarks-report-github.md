```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ceil** | **101.52 μs** | **9.971 μs** | **5.933 μs** |  **1.00** |    **0.08** |   **66.3 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ceil |  10.35 μs | 0.421 μs | 0.220 μs |  0.10 |    0.01 |  37.65 KB |        0.57 |
|            |       |                      |           |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ceil** |  **55.34 μs** | **1.749 μs** | **1.041 μs** |  **1.00** |    **0.03** | **641.74 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ceil |  89.05 μs | 1.017 μs | 0.532 μs |  1.61 |    0.03 | 327.73 KB |        0.51 |
