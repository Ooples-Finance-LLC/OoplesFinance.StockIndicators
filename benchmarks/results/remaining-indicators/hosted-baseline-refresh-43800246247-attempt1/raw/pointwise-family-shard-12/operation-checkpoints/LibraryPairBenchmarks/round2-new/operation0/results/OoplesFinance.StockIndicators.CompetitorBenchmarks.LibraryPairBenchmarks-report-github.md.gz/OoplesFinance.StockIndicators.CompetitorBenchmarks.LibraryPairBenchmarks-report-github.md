```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Atan** | **102.62 μs** | **9.788 μs** | **5.825 μs** |  **1.00** |    **0.07** |   **66.3 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Atan |  14.51 μs | 0.626 μs | 0.372 μs |  0.14 |    0.01 |  38.96 KB |        0.59 |
|            |       |                      |           |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Atan** |  **69.88 μs** | **1.000 μs** | **0.523 μs** |  **1.00** |    **0.01** | **645.98 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Atan | 131.76 μs | 3.920 μs | 2.050 μs |  1.89 |    0.03 | 328.67 KB |        0.51 |
