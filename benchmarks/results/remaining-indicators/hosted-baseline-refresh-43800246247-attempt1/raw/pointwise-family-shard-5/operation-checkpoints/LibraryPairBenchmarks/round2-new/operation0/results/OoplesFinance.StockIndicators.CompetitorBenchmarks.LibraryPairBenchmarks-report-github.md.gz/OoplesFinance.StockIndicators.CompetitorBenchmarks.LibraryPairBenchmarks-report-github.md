```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean     | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |---------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Floor [21]** | **80.56 μs** |  **3.591 μs** | **1.878 μs** |  **1.00** |    **0.03** |   **66.3 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Floor [21] | 10.10 μs |  0.175 μs | 0.115 μs |  0.13 |    0.00 |  38.35 KB |        0.58 |
|            |       |                      |          |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Floor [21]** | **49.86 μs** |  **2.543 μs** | **1.513 μs** |  **1.00** |    **0.04** | **643.43 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Floor [21] | 94.27 μs | 12.695 μs | 8.397 μs |  1.89 |    0.17 | 328.02 KB |        0.51 |
