```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean      | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Tanh** |  **31.30 μs** | **2.761 μs** | **1.643 μs** |  **1.00** |    **0.07** |  **66.24 KB** |        **1.00** |
|        |       |                      |           |          |          |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Tanh** | **110.25 μs** | **2.661 μs** | **1.392 μs** |  **1.00** |    **0.02** | **645.98 KB** |        **1.00** |
