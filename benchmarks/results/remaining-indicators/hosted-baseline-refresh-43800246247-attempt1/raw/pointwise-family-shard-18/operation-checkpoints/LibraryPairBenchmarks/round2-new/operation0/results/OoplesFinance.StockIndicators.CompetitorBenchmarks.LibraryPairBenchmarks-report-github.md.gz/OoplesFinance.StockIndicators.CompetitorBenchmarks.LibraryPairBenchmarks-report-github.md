```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Tanh** | **115.23 μs** | **10.848 μs** | **6.456 μs** |  **1.00** |    **0.07** |   **66.3 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Tanh |  21.43 μs |  0.379 μs | 0.198 μs |  0.19 |    0.01 |  37.98 KB |        0.57 |
|            |       |                      |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Tanh** | **106.71 μs** |  **2.541 μs** | **1.329 μs** |  **1.00** |    **0.02** | **645.62 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Tanh | 204.03 μs |  2.632 μs | 1.566 μs |  1.91 |    0.03 | 325.77 KB |        0.50 |
