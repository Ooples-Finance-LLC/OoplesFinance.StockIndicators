```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Sqrt** |  **90.55 μs** | **5.998 μs** | **3.137 μs** |  **1.00** |    **0.05** |   **66.3 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Sqrt |  15.45 μs | 0.553 μs | 0.366 μs |  0.17 |    0.01 |  39.01 KB |        0.59 |
|            |       |                      |           |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Sqrt** |  **58.83 μs** | **3.495 μs** | **1.828 μs** |  **1.00** |    **0.04** |  **644.7 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Sqrt | 135.10 μs | 5.056 μs | 2.644 μs |  2.30 |    0.08 | 330.64 KB |        0.51 |
