```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean      | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |------------------- |----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ln** |  **86.48 μs** | **2.525 μs** | **1.502 μs** |  **1.00** |    **0.02** |   **66.3 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ln |  15.11 μs | 0.788 μs | 0.412 μs |  0.17 |    0.01 |  38.96 KB |        0.59 |
|            |       |                    |           |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ln** |  **70.80 μs** | **2.892 μs** | **1.513 μs** |  **1.00** |    **0.03** | **646.31 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ln | 130.56 μs | 2.867 μs | 1.499 μs |  1.84 |    0.04 | 328.39 KB |        0.51 |
