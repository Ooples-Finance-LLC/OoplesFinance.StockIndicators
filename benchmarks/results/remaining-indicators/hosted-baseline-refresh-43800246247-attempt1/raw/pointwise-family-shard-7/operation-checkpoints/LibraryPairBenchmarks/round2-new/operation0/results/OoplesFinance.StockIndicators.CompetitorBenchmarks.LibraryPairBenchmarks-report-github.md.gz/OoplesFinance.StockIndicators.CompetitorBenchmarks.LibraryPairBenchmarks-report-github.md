```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean      | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Sin** |  **65.96 μs** | **9.697 μs** | **5.770 μs** |  **1.01** |    **0.11** |   **66.3 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Sin |  13.47 μs | 0.285 μs | 0.149 μs |  0.21 |    0.02 |  37.32 KB |        0.56 |
|            |       |                     |           |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Sin** |  **63.74 μs** | **0.824 μs** | **0.431 μs** |  **1.00** |    **0.01** | **645.38 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Sin | 126.91 μs | 2.148 μs | 1.278 μs |  1.99 |    0.02 | 326.05 KB |        0.51 |
