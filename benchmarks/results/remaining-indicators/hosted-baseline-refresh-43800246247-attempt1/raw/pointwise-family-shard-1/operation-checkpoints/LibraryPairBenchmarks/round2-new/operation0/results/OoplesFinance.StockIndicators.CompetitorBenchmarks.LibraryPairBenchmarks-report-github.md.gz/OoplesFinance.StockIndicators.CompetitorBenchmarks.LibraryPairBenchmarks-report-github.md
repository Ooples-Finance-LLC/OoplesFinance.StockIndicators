```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=20000  

```
| Method     | Bars  | PairId              | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Sub** |  **20.76 μs** |  **2.015 μs** | **1.199 μs** |  **1.00** |    **0.08** |  **66.53 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Sub |  13.54 μs |  0.468 μs | 0.245 μs |  0.65 |    0.04 |   40.6 KB |        0.61 |
|            |       |                     |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Sub** |  **74.08 μs** | **13.995 μs** | **8.328 μs** |  **1.01** |    **0.15** | **646.27 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Sub | 116.89 μs |  1.521 μs | 0.795 μs |  1.60 |    0.16 | 329.98 KB |        0.51 |
