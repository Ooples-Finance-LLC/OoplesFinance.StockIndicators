```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Asin** |  **48.83 μs** |  **8.596 μs** |  **4.496 μs** |  **1.01** |    **0.12** |  **74.21 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Asin |  26.14 μs |  8.278 μs |  5.475 μs |  0.54 |    0.12 |  40.27 KB |        0.54 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Asin** | **117.62 μs** |  **3.408 μs** |  **1.782 μs** |  **1.00** |    **0.02** | **723.97 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Asin | 217.77 μs | 19.201 μs | 12.700 μs |  1.85 |    0.11 | 330.64 KB |        0.46 |
