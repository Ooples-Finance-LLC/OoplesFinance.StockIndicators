```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Cos** |  **97.95 μs** |  **5.318 μs** | **2.782 μs** |  **1.00** |    **0.04** |   **66.3 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Cos |  21.61 μs |  1.613 μs | 0.960 μs |  0.22 |    0.01 |  38.02 KB |        0.57 |
|            |       |                     |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Cos** |  **98.68 μs** | **13.245 μs** | **7.882 μs** |  **1.01** |    **0.11** | **645.98 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Cos | 188.15 μs |  2.388 μs | 1.249 μs |  1.92 |    0.14 | 327.41 KB |        0.51 |
