```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Log10 [21]** | **130.71 μs** |  **3.173 μs** |  **2.099 μs** |  **1.00** |    **0.02** |   **66.3 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Log10 [21] |  20.42 μs |  0.660 μs |  0.437 μs |  0.16 |    0.00 |  40.93 KB |        0.62 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Log10 [21]** | **133.21 μs** | **19.341 μs** | **11.510 μs** |  **1.01** |    **0.11** | **646.31 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Log10 [21] | 195.73 μs | 21.680 μs | 14.340 μs |  1.48 |    0.15 | 330.97 KB |        0.51 |
