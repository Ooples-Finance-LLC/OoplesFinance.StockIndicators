```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib.Candles.Hammer** | **1000**  | **133.5 μs** | **17.01 μs** | **11.25 μs** |  **3.9063** |      **-** |  **66.44 KB** |
| BuilderLatestOnly | TaLib.Candles.Hammer | 1000  | 118.6 μs |  0.80 μs |  0.42 μs |  0.9766 |      - |  18.56 KB |
| **BuilderFull**       | **TaLib.Candles.Hammer** | **10000** | **513.1 μs** | **36.69 μs** | **24.27 μs** | **31.2500** | **7.8125** | **559.01 KB** |
| BuilderLatestOnly | TaLib.Candles.Hammer | 10000 | 496.8 μs | 38.77 μs | 23.07 μs |  3.9063 |      - |   88.9 KB |
