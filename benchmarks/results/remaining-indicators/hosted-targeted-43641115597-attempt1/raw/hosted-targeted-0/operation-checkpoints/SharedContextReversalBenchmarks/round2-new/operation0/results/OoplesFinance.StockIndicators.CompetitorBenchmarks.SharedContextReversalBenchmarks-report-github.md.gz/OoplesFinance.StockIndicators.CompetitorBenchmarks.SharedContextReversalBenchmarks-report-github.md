```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **NativeSingle**      | **TaLib.Candles.Hammer** | **1000**  |  **65.47 μs** |  **0.418 μs** |  **0.219 μs** |  **1.00** |    **0.00** |       **-** |      **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Hammer | 1000  | 112.61 μs |  8.563 μs |  5.664 μs |  1.72 |    0.08 |       - |      - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib.Candles.Hammer | 1000  | 124.54 μs |  7.550 μs |  4.994 μs |  1.90 |    0.07 |  3.9063 |      - |  66.45 KB |       16.74 |
| BuilderLatestOnly | TaLib.Candles.Hammer | 1000  | 121.01 μs |  3.918 μs |  2.332 μs |  1.85 |    0.03 |  0.9766 |      - |  18.56 KB |        4.68 |
|                   |                      |       |           |           |           |       |         |         |        |           |             |
| **NativeSingle**      | **TaLib.Candles.Hammer** | **10000** | **689.61 μs** |  **4.014 μs** |  **2.099 μs** |  **1.00** |    **0.00** |       **-** |      **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Hammer | 10000 | 419.85 μs |  4.782 μs |  2.501 μs |  0.61 |    0.00 |  3.9063 |      - |  78.74 KB |        2.01 |
| BuilderFull       | TaLib.Candles.Hammer | 10000 | 509.83 μs | 37.824 μs | 22.508 μs |  0.74 |    0.03 | 31.2500 | 7.8125 | 559.01 KB |       14.28 |
| BuilderLatestOnly | TaLib.Candles.Hammer | 10000 | 485.61 μs |  5.805 μs |  3.036 μs |  0.70 |    0.00 |  3.9063 |      - |   88.9 KB |        2.27 |
