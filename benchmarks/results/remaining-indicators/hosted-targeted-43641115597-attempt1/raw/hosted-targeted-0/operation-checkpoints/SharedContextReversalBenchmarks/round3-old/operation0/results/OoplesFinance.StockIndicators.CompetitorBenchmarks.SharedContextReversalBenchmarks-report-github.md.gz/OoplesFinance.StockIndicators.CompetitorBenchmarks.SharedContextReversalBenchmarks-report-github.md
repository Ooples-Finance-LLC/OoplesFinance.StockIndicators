```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib.Candles.Hammer** | **1000**  | **132.1 μs** | **16.95 μs** | **11.21 μs** |  **3.9063** |      **-** |  **66.44 KB** |
| BuilderLatestOnly | TaLib.Candles.Hammer | 1000  | 119.5 μs |  1.00 μs |  0.52 μs |  0.9766 |      - |  18.56 KB |
| **BuilderFull**       | **TaLib.Candles.Hammer** | **10000** | **517.0 μs** | **30.71 μs** | **20.31 μs** | **31.2500** | **7.8125** |    **559 KB** |
| BuilderLatestOnly | TaLib.Candles.Hammer | 10000 | 505.7 μs | 36.17 μs | 23.92 μs |  3.9063 |      - |   88.9 KB |
