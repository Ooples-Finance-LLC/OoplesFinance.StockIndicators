```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Candles.Hammer** |  **82.37 μs** | **12.556 μs** |  **7.472 μs** |  **1.01** |    **0.12** |  **69.72 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Candles.Hammer |  94.75 μs |  3.783 μs |  1.978 μs |  1.16 |    0.10 |  16.95 KB |        0.24 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Candles.Hammer** | **622.60 μs** | **24.792 μs** | **14.753 μs** |  **1.00** |    **0.03** | **639.11 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Candles.Hammer | 955.16 μs | 14.920 μs |  8.879 μs |  1.53 |    0.04 | 120.22 KB |        0.19 |
