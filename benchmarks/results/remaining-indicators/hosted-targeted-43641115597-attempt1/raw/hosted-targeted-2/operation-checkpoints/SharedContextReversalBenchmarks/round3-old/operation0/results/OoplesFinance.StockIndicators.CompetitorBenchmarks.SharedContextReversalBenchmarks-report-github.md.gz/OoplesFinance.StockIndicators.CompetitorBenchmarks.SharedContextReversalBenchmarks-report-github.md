```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)ammer [28]** | **1000**  |  **94.89 μs** |  **2.657 μs** |  **1.390 μs** |  **3.9063** |       **-** |     **64 KB** |
| BuilderLatestOnly | TaLib(...)ammer [28] | 1000  |  91.25 μs |  1.165 μs |  0.609 μs |  0.9766 |       - |  16.13 KB |
| **BuilderFull**       | **TaLib(...)ammer [28]** | **10000** | **345.17 μs** | **30.842 μs** | **20.400 μs** | **33.2031** | **13.6719** | **556.55 KB** |
| BuilderLatestOnly | TaLib(...)ammer [28] | 10000 | 325.35 μs | 14.679 μs |  7.677 μs |  3.9063 |       - |  86.46 KB |
