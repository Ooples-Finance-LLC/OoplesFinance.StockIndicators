```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)ammer [28]** | **1000**  |  **36.51 μs** |  **0.383 μs** |  **0.228 μs** |  **1.00** |    **0.01** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)ammer [28] | 1000  |  89.21 μs |  2.226 μs |  1.473 μs |  2.44 |    0.04 |  0.4883 |       - |    8.4 KB |        2.12 |
| BuilderFull       | TaLib(...)ammer [28] | 1000  |  97.26 μs |  2.681 μs |  1.596 μs |  2.66 |    0.04 |  3.9063 |       - |  64.01 KB |       16.13 |
| BuilderLatestOnly | TaLib(...)ammer [28] | 1000  |  97.77 μs |  5.553 μs |  3.673 μs |  2.68 |    0.10 |  0.9766 |       - |  16.13 KB |        4.06 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)ammer [28]** | **10000** | **373.08 μs** |  **9.543 μs** |  **5.679 μs** |  **1.00** |    **0.02** |       **-** |       **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib(...)ammer [28] | 10000 | 305.80 μs | 19.113 μs | 12.642 μs |  0.82 |    0.03 |  5.8594 |       - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib(...)ammer [28] | 10000 | 341.69 μs | 15.768 μs | 10.430 μs |  0.92 |    0.03 | 33.2031 | 13.6719 | 556.55 KB |       14.22 |
| BuilderLatestOnly | TaLib(...)ammer [28] | 10000 | 317.56 μs | 18.977 μs | 12.552 μs |  0.85 |    0.03 |  3.9063 |       - |  86.45 KB |        2.21 |
