```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)ammer [28]** | **283.93 μs** | **16.734 μs** |  **9.958 μs** |  **1.00** |    **0.05** |  **68.54 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)ammer [28] |  56.32 μs |  2.359 μs |  1.560 μs |  0.20 |    0.01 |  12.08 KB |        0.18 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)ammer [28]** | **284.03 μs** | **20.060 μs** | **11.937 μs** |  **1.00** |    **0.06** | **637.89 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)ammer [28] | 549.78 μs | 15.276 μs |  9.090 μs |  1.94 |    0.08 | 120.78 KB |        0.19 |
