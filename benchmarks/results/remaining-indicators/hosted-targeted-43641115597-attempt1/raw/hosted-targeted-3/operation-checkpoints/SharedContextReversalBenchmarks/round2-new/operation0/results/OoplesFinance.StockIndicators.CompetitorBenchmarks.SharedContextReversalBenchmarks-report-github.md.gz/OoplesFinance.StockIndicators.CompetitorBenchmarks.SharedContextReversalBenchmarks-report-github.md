```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)gStar [26]** | **1000**  |  **53.17 μs** |  **0.169 μs** |  **0.089 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)gStar [26] | 1000  | 101.37 μs |  1.439 μs |  0.753 μs |  1.91 |    0.01 |       - |       - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib(...)gStar [26] | 1000  | 116.84 μs |  4.060 μs |  2.124 μs |  2.20 |    0.04 |  3.9063 |       - |  64.01 KB |       16.13 |
| BuilderLatestOnly | TaLib(...)gStar [26] | 1000  | 115.51 μs |  4.454 μs |  2.946 μs |  2.17 |    0.05 |  0.9766 |       - |  16.13 KB |        4.06 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)gStar [26]** | **10000** | **512.90 μs** |  **5.072 μs** |  **2.653 μs** |  **1.00** |    **0.01** |       **-** |       **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)gStar [26] | 10000 | 354.24 μs | 24.196 μs | 16.004 μs |  0.69 |    0.03 |  5.8594 |       - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib(...)gStar [26] | 10000 | 399.59 μs | 10.368 μs |  5.423 μs |  0.78 |    0.01 | 31.2500 | 11.7188 | 556.57 KB |       14.21 |
| BuilderLatestOnly | TaLib(...)gStar [26] | 10000 | 393.82 μs |  3.594 μs |  1.880 μs |  0.77 |    0.01 |  3.9063 |       - |  86.46 KB |        2.21 |
