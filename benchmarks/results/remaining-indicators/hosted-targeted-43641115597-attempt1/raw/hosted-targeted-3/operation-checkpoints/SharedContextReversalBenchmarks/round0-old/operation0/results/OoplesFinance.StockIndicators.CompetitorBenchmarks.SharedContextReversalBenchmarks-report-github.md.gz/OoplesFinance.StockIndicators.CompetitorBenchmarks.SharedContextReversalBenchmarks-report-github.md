```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)gStar [26]** | **1000**  | **129.8 μs** | **18.21 μs** | **12.04 μs** |  **3.9063** |       **-** |     **64 KB** |
| BuilderLatestOnly | TaLib(...)gStar [26] | 1000  | 124.8 μs |  9.23 μs |  6.10 μs |  0.9766 |       - |  16.13 KB |
| **BuilderFull**       | **TaLib(...)gStar [26]** | **10000** | **541.8 μs** | **87.50 μs** | **57.88 μs** | **31.2500** | **11.7188** | **556.57 KB** |
| BuilderLatestOnly | TaLib(...)gStar [26] | 10000 | 488.7 μs | 31.90 μs | 18.98 μs |  3.9063 |       - |  86.46 KB |
