```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean     | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |---------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)ngMan [24]** | **104.3 μs** | **14.30 μs** |  **7.48 μs** |  **1.00** |    **0.10** |  **69.76 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)ngMan [24] | 124.7 μs |  1.63 μs |  1.08 μs |  1.20 |    0.09 |  18.27 KB |        0.26 |
|            |       |                      |          |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)ngMan [24]** | **612.2 μs** | **22.55 μs** | **11.79 μs** |  **1.00** |    **0.03** | **640.05 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)ngMan [24] | 910.5 μs | 13.42 μs |  7.99 μs |  1.49 |    0.03 | 122.47 KB |        0.19 |
