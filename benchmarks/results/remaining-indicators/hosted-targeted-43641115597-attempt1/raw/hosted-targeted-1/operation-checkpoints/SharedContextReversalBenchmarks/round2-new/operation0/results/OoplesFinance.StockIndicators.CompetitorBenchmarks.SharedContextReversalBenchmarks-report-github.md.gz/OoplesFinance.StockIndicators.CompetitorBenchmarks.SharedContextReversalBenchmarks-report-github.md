```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)ngMan [24]** | **1000**  |  **68.92 μs** |  **0.469 μs** |  **0.279 μs** |  **1.00** |    **0.01** |       **-** |      **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)ngMan [24] | 1000  | 116.01 μs |  5.479 μs |  3.624 μs |  1.68 |    0.05 |       - |      - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib(...)ngMan [24] | 1000  | 122.77 μs |  5.124 μs |  3.389 μs |  1.78 |    0.05 |  3.9063 |      - |  66.45 KB |       16.74 |
| BuilderLatestOnly | TaLib(...)ngMan [24] | 1000  | 118.54 μs |  1.502 μs |  0.785 μs |  1.72 |    0.01 |  0.9766 |      - |  18.56 KB |        4.68 |
|                   |                      |       |           |           |           |       |         |         |        |           |             |
| **NativeSingle**      | **TaLib(...)ngMan [24]** | **10000** | **656.17 μs** | **11.224 μs** |  **7.424 μs** |  **1.00** |    **0.02** |       **-** |      **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)ngMan [24] | 10000 | 418.04 μs |  3.310 μs |  1.731 μs |  0.64 |    0.01 |  3.9063 |      - |  78.74 KB |        2.01 |
| BuilderFull       | TaLib(...)ngMan [24] | 10000 | 503.90 μs | 31.696 μs | 18.862 μs |  0.77 |    0.03 | 31.2500 | 7.8125 | 559.01 KB |       14.28 |
| BuilderLatestOnly | TaLib(...)ngMan [24] | 10000 | 491.12 μs | 17.812 μs | 10.600 μs |  0.75 |    0.02 |  3.9063 |      - |   88.9 KB |        2.27 |
