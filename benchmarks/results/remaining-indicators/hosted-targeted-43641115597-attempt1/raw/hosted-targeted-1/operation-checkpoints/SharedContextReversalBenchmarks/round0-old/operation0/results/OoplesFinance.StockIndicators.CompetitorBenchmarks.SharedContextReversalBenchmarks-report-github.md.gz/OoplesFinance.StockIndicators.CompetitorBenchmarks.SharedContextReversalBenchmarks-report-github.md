```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)ngMan [24]** | **1000**  | **138.0 μs** | **18.80 μs** | **12.44 μs** |  **3.9063** |      **-** |  **66.41 KB** |
| BuilderLatestOnly | TaLib(...)ngMan [24] | 1000  | 119.8 μs |  2.06 μs |  1.23 μs |  0.9766 |      - |  18.56 KB |
| **BuilderFull**       | **TaLib(...)ngMan [24]** | **10000** | **517.1 μs** | **39.39 μs** | **26.05 μs** | **31.2500** | **7.8125** | **558.97 KB** |
| BuilderLatestOnly | TaLib(...)ngMan [24] | 10000 | 492.6 μs | 17.15 μs | 10.21 μs |  3.9063 |      - |   88.9 KB |
