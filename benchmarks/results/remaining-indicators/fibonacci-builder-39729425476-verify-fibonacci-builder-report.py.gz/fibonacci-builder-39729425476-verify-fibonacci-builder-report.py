from pathlib import Path
import hashlib,json,re
from playwright.sync_api import sync_playwright
out=Path('C:/Users/cheat/Documents/OoplesFinance-Reports/fibonacci-builder-refresh-39729425476');stage=json.loads((out/'staged.json').read_text());candidate=out/'candidate.html'
def data(path,name):return json.loads(re.search(r'<script[^>]*id="'+name+r'"[^>]*>(.*?)</script>',path.read_text(encoding='utf-8'),re.S)[1])
for name in ['dataset','archived-baseline-dataset']:assert data(out/'before.html',name)==data(candidate,name)
status=data(candidate,'rollout-status-data');assert status['measurement_totals']=={'faster':4,'slower':0,'inconclusive':0,'expected':1604,'measured':4,'pending':1600}
builder=data(candidate,'current-competitor-data');assert builder['receipts']==[stage['receipt']] and builder['verdicts']=={'faster':4,'slower':0,'inconclusive':0}
with sync_playwright() as p:
 b=p.chromium.launch(channel='msedge',headless=True);page=b.new_page(viewport={'width':1440,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto(candidate.as_uri())
 assert page.locator('#builder-current-results tbody tr').count()==4
 for r in stage['receipt']['comparisons']:
  row=page.locator(f'#builder-current-results tr[data-bars="{r["bars"]}"][data-mode="{r["mode"]}"]')
  cells=row.locator('td').all_inner_texts();assert cells[0]=='QuanTAlib.Fwma' and cells[1]==f'{r["bars"]:,}'
  assert cells[3:6]==[f'{r["ooples"]["mean_ns"]/1e6:.6f}',f'{r["native"]["NativeSingle"]["mean_ns"]/1e6:.6f}',f'{r["native"]["NativeParallel"]["mean_ns"]/1e6:.6f}']
  assert cells[6]=='Faster than both'
 assert '4 / 1604' in page.locator('#rollout-status').inner_text() and '1600 pending' in page.locator('#current-competitors').inner_text()
 page.locator('#current-competitors').screenshot(path=str(out/'builder-results.png'));assert not errors; b.close()
(out/'builder-verification.json').write_text(json.dumps({'run_id':'39729425476','builder_comparisons':4,'unchanged_baseline_comparisons':802,'report_sha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'javascript_errors':errors,'status_totals':status['measurement_totals']},indent=2))
print('Verified all four displayed builder rows and totals; baseline802 and archived baseline unchanged')
