from pathlib import Path
import sys
from consolidated_acceptance import qualifies
import gzip,hashlib,json
ROOT=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
name='consolidated'
RUN='local-consolidated-followups-control-20261030'
RAW=ROOT/RUN
REPO=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
OUT=REPO/'benchmarks/results/remaining-indicators'/RUN
summary=json.loads((RAW/'verified-summary.json').read_text(encoding='utf-8'))
count=1632
assert summary[f'all_{count}_cases_verified']
proof=json.loads((RAW/'provenance.json').read_text(encoding='utf-8'))
accepted=qualifies(summary['decisions'])
state=json.loads((RAW/'status.json').read_text(encoding='utf-8'))
paths=['status.json','provenance.json','binary-manifest.json','verified-summary.json']
paths += [Path(r['report']).relative_to(RAW).as_posix() for r in state['rounds']]
paths += [p.name for p in RAW.glob('*.log')]
paths += [p.relative_to(RAW).as_posix() for p in (RAW/'invalidated-attempts').rglob('*') if p.is_file()]
paths += [p.relative_to(RAW).as_posix() for p in (RAW/'fixture-routing-repair-20261031').rglob('*') if p.is_file()]
paths += [p.relative_to(RAW).as_posix() for p in (RAW/'directional-checkpoints').rglob('*') if p.is_file()]
paths += [p.relative_to(RAW).as_posix() for p in (RAW/'directional-checkpoint-repair-20261031').rglob('*') if p.is_file()]
paths += [p.relative_to(RAW).as_posix() for p in (RAW/'operation-checkpoints').rglob('*') if p.is_file()]
paths += [p.relative_to(RAW).as_posix() for p in (RAW/'operation-checkpoint-repair-20261101').rglob('*') if p.is_file()]
paths += [p.name for p in RAW.glob('interruption-*.json')]
OUT.mkdir(exist_ok=True)
manifest={}
for relative in paths:
 data=(RAW/relative).read_bytes();target=OUT/(relative+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(gzip.compress(data,mtime=0));manifest[relative]={'sha256':hashlib.sha256(data).hexdigest(),'archive':target.relative_to(REPO).as_posix()}
scripts={}
for script in [f'measure-{name}-control-20261030.py',f'verify-{name}-control-20261030.py','benchmark_process_cleanup.py','directional_checkpoint_runner.py','successor_checkpoint_runner.py','consolidated_acceptance.py']:
 data=(ROOT/script).read_bytes();(OUT/(script+'.gz')).write_bytes(gzip.compress(data,mtime=0));scripts[script]=hashlib.sha256(data).hexdigest()
companion_inputs={}
(OUT/'decision.json').write_text(json.dumps({'status':'candidate-qualified-for-integration' if accepted else 'candidate-rejected-or-inconclusive','sources':summary['sources'],'candidate_code_source':proof['candidate_code_source'],'measurement_location':'Local Windows; preserved source-qualified binaries; only production DLL differs','decisions':summary['decisions'],'archives':manifest,'scripts':scripts,'source_companion_inputs':companion_inputs,'report_imported':False,'production_integrated':False},indent=2)+'\n',encoding='utf-8',newline='\n')
(OUT/'.gitattributes').write_bytes(b'* -text\n')
print('Archived',count,'cases; qualified for integration:',accepted)

