```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | Gen0      | Gen1      | Allocated | Alloc Ratio |
|------- |------ |--------------------- |----------:|----------:|----------:|------:|----------:|----------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)bands [24]** |  **2.091 ms** | **0.0210 ms** | **0.0110 ms** |  **1.00** |         **-** |         **-** |   **3.23 MB** |        **1.00** |
|        |       |                      |           |           |           |       |           |           |           |             |
| **Ooples** | **10000** | **TaLib(...)bands [24]** | **12.609 ms** | **0.2190 ms** | **0.1303 ms** |  **1.00** | **2000.0000** | **1000.0000** |  **32.43 MB** |        **1.00** |
