```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adxr** |   **696.46 μs** |  **30.252 μs** |  **20.010 μs** |  **1.00** |    **0.04** |  **107.36 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adxr |    27.43 μs |   8.273 μs |   4.923 μs |  0.04 |    0.01 |   48.17 KB |        0.45 |
|            |       |                      |             |            |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adxr** | **6,795.64 μs** | **207.435 μs** | **108.493 μs** |  **1.00** |    **0.02** | **1046.98 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adxr |   243.42 μs |  16.650 μs |   9.908 μs |  0.04 |    0.00 |  408.52 KB |        0.39 |
