```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0      | Gen1      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |-------------:|-----------:|-----------:|------:|--------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)bands [24]** |  **2,279.43 μs** |  **67.913 μs** |  **35.520 μs** |  **1.00** |    **0.02** |         **-** |         **-** |  **3309.48 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)bands [24] |     31.30 μs |   4.818 μs |   3.187 μs |  0.01 |    0.00 |         - |         - |   121.56 KB |        0.04 |
|            |       |                      |              |            |            |       |         |           |           |             |             |
| **Ooples**     | **10000** | **TaLib(...)bands [24]** | **13,541.62 μs** | **915.533 μs** | **478.841 μs** |  **1.00** |    **0.05** | **2000.0000** | **1000.0000** | **33205.64 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)bands [24] |    208.51 μs |  23.121 μs |  13.759 μs |  0.02 |    0.00 |         - |         - |  1132.59 KB |        0.03 |
