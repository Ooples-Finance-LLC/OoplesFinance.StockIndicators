```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean        | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |------------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adx** |   **706.22 μs** |  **39.146 μs** |  **23.295 μs** |  **1.00** |    **0.04** |  **106.32 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adx |    24.06 μs |   0.715 μs |   0.374 μs |  0.03 |    0.00 |    40.6 KB |        0.38 |
|            |       |                     |             |            |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adx** | **6,675.48 μs** | **189.300 μs** | **112.649 μs** |  **1.00** |    **0.02** | **1046.27 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adx |   224.81 μs |   2.753 μs |   1.638 μs |  0.03 |    0.00 |  330.64 KB |        0.32 |
