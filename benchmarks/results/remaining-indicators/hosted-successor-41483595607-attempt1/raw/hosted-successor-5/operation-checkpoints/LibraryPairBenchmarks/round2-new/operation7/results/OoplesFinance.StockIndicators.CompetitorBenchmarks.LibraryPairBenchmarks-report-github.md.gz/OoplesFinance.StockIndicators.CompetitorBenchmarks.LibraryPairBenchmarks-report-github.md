```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)vgDev [22]** |   **135.57 μs** |  **10.390 μs** |   **5.434 μs** |  **1.00** |    **0.05** |  **73.05 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)vgDev [22] |    30.23 μs |   2.629 μs |   1.375 μs |  0.22 |    0.01 |  23.52 KB |        0.32 |
|            |       |                      |             |            |            |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)vgDev [22]** | **1,212.67 μs** | **201.684 μs** | **133.401 μs** |  **1.01** |    **0.15** | **643.38 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)vgDev [22] |   283.78 μs |   2.195 μs |   1.307 μs |  0.24 |    0.03 | 163.16 KB |        0.25 |
