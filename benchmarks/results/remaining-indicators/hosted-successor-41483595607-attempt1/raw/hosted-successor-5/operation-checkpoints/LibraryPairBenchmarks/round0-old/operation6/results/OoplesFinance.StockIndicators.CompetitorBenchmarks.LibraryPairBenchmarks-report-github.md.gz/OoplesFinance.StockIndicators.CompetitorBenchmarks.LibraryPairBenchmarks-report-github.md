```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId              | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |-------------------- |-----------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Apo** |   **382.1 μs** |    **22.90 μs** |  **13.62 μs** |  **1.00** |    **0.05** |  **373.16 KB** |        **1.00** |
|        |       |                     |            |             |           |       |         |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Apo** | **3,730.9 μs** | **1,070.61 μs** | **708.15 μs** |  **1.03** |    **0.26** | **3553.74 KB** |        **1.00** |
