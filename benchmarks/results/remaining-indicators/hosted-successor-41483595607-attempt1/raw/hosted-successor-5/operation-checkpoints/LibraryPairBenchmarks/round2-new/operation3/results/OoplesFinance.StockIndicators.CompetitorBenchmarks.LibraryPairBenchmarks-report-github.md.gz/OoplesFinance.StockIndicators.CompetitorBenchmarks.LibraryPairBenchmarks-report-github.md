```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean         | Error     | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-------------:|----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)AdOsc [21]** |   **716.430 μs** | **58.501 μs** | **38.6945 μs** |  **1.00** |    **0.07** |  **209.05 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)AdOsc [21] |     9.311 μs |  1.074 μs |  0.6392 μs |  0.01 |    0.00 |   39.46 KB |        0.19 |
|            |       |                      |              |           |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)AdOsc [21]** | **6,782.378 μs** | **44.377 μs** | **26.4082 μs** |  **1.00** |    **0.01** | **2054.45 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)AdOsc [21] |    74.660 μs | 23.257 μs | 15.3834 μs |  0.01 |    0.00 |  330.91 KB |        0.16 |
