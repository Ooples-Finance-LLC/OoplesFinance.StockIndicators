```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean         | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |------------------- |-------------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ad** |   **197.089 μs** | **11.6725 μs** |  **6.9461 μs** |  **1.00** |    **0.05** |  **160.8 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ad |     4.800 μs |  0.9431 μs |  0.5612 μs |  0.02 |    0.00 |    8.8 KB |        0.05 |
|            |       |                    |              |            |            |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ad** | **2,020.540 μs** | **46.0532 μs** | **30.4613 μs** |  **1.00** |    **0.02** | **2014.2 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ad |    24.062 μs |  1.7221 μs |  0.9007 μs |  0.01 |    0.00 |  85.63 KB |        0.04 |
