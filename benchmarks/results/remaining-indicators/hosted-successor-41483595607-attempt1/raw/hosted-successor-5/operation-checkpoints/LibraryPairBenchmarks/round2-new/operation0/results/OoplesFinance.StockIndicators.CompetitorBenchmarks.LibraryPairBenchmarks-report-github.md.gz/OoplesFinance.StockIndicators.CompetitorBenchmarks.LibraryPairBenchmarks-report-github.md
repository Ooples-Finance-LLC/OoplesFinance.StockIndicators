```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId            | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------ |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetZigZag** |   **272.2 μs** |  **12.20 μs** |  **7.26 μs** |  **1.00** |    **0.04** |  **479.95 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetZigZag |   382.0 μs |  77.49 μs | 46.11 μs |  1.40 |    0.16 |  429.43 KB |        0.89 |
|            |       |                   |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetZigZag** | **3,210.0 μs** | **114.51 μs** | **75.74 μs** |  **1.00** |    **0.03** | **4850.98 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetZigZag | 3,425.9 μs | 146.08 μs | 86.93 μs |  1.07 |    0.04 | 4090.04 KB |        0.84 |
