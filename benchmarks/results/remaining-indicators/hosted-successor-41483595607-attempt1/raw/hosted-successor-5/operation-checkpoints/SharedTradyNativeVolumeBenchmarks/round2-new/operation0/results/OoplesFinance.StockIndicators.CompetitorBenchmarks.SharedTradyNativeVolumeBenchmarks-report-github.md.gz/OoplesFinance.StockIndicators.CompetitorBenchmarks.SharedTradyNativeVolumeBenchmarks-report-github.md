```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|----------:|----------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Accum(...)nLine [28]** | **1000**  |   **168.2 μs** |   **3.27 μs** |   **1.95 μs** |  **0.34** |    **0.00** |    **7.8125** |         **-** |        **-** |  **153.97 KB** |        **0.26** |
| BuilderLatestOnly | Accum(...)nLine [28] | 1000  |   162.2 μs |   2.88 μs |   1.51 μs |  0.32 |    0.00 |    5.8594 |         - |        - |  106.36 KB |        0.18 |
| NativeSingle      | Accum(...)nLine [28] | 1000  |   499.9 μs |   4.06 μs |   2.12 μs |  1.00 |    0.01 |   35.1563 |   11.7188 |        - |  594.33 KB |        1.00 |
| NativeParallel    | Accum(...)nLine [28] | 1000  |   475.0 μs |  29.77 μs |  19.69 μs |  0.95 |    0.04 |   54.6875 |   19.5313 |        - |  894.26 KB |        1.50 |
|                   |                      |       |            |           |           |       |         |           |           |          |            |             |
| **BuilderFull**       | **Accum(...)nLine [28]** | **10000** | **2,051.1 μs** |  **27.86 μs** |  **14.57 μs** |  **0.35** |    **0.01** |  **109.3750** |   **46.8750** |        **-** | **1931.53 KB** |        **0.33** |
| BuilderLatestOnly | Accum(...)nLine [28] | 10000 | 2,029.1 μs |  12.69 μs |   6.64 μs |  0.35 |    0.00 |   78.1250 |   15.6250 |        - | 1461.71 KB |        0.25 |
| NativeSingle      | Accum(...)nLine [28] | 10000 | 5,877.7 μs | 123.83 μs |  81.91 μs |  1.00 |    0.02 |  656.2500 |  468.7500 | 437.5000 | 5824.15 KB |        1.00 |
| NativeParallel    | Accum(...)nLine [28] | 10000 | 5,804.3 μs | 306.25 μs | 202.57 μs |  0.99 |    0.04 | 1250.0000 | 1062.5000 | 968.7500 | 8717.93 KB |        1.50 |
