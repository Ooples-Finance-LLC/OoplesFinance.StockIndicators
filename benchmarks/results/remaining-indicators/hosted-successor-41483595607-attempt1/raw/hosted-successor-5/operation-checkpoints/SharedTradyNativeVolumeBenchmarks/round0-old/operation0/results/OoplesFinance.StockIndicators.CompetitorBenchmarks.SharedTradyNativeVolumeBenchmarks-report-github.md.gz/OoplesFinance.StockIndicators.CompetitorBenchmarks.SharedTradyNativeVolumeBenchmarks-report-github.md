```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0     | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Accum(...)nLine [28]** | **1000**  |   **153.9 μs** |  **1.11 μs** |  **0.58 μs** |   **7.8125** |       **-** |  **153.97 KB** |
| BuilderLatestOnly | Accum(...)nLine [28] | 1000  |   150.7 μs |  1.29 μs |  0.67 μs |   5.8594 |       - |  106.36 KB |
| **BuilderFull**       | **Accum(...)nLine [28]** | **10000** | **1,856.0 μs** | **31.26 μs** | **20.67 μs** | **109.3750** | **46.8750** | **1931.52 KB** |
| BuilderLatestOnly | Accum(...)nLine [28] | 10000 | 1,878.3 μs | 34.86 μs | 20.75 μs |  78.1250 | 15.6250 |  1461.7 KB |
