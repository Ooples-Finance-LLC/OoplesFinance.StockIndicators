```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0     | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Accum(...)nLine [28]** | **1000**  |   **154.9 μs** |  **3.95 μs** |  **2.07 μs** |   **7.8125** |       **-** |  **153.93 KB** |
| BuilderLatestOnly | Accum(...)nLine [28] | 1000  |   149.6 μs |  1.38 μs |  0.72 μs |   5.8594 |       - |  106.36 KB |
| **BuilderFull**       | **Accum(...)nLine [28]** | **10000** | **1,803.3 μs** | **13.55 μs** |  **7.08 μs** | **109.3750** | **46.8750** | **1931.49 KB** |
| BuilderLatestOnly | Accum(...)nLine [28] | 10000 | 1,811.6 μs | 20.15 μs | 13.33 μs |  78.1250 | 15.6250 | 1461.69 KB |
