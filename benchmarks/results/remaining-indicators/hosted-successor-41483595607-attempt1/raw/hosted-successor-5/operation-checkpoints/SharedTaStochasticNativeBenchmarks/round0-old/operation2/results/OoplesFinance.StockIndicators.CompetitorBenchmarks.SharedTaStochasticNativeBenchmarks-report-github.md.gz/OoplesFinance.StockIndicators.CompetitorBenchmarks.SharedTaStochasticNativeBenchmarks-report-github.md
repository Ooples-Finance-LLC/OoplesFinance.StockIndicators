```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|-----------:|
| **BuilderFull**       | **TaLib(...)chRsi [24]** | **1000**  |   **472.8 μs** |  **6.89 μs** |  **3.60 μs** |       **-** |       **-** |  **182.03 KB** |
| BuilderLatestOnly | TaLib(...)chRsi [24] | 1000  |   466.8 μs |  3.04 μs |  1.59 μs |  7.8125 |       - |  134.44 KB |
| **BuilderFull**       | **TaLib(...)chRsi [24]** | **10000** | **4,866.5 μs** | **21.45 μs** | **12.76 μs** | **93.7500** | **31.2500** | **1799.89 KB** |
| BuilderLatestOnly | TaLib(...)chRsi [24] | 10000 | 4,803.0 μs | 30.33 μs | 15.86 μs | 62.5000 |       - | 1330.04 KB |
