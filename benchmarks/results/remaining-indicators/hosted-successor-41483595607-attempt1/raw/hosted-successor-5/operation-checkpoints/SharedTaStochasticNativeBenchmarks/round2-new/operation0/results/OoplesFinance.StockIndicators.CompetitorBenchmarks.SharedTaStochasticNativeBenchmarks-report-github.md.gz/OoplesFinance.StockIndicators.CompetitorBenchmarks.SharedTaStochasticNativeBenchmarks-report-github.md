```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **1000**  |   **568.95 μs** | **147.128 μs** |  **97.316 μs** | **53.19** |    **8.71** |  **31.2500** |        **-** |   **645.9 KB** |       **27.22** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 1000  |   461.75 μs |  54.511 μs |  36.055 μs | 43.17 |    3.27 |  35.1563 |        - |  598.36 KB |       25.22 |
| NativeSingle      | TaLib(...)Stoch [21] | 1000  |    10.70 μs |   0.253 μs |   0.151 μs |  1.00 |    0.02 |   1.4038 |   0.0610 |   23.73 KB |        1.00 |
| NativeParallel    | TaLib(...)Stoch [21] | 1000  |    20.63 μs |   0.546 μs |   0.361 μs |  1.93 |    0.04 |   5.0049 |   0.6104 |   75.96 KB |        3.20 |
|                   |                      |       |             |            |            |       |         |          |          |            |             |
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **10000** | **4,563.35 μs** | **267.269 μs** | **159.048 μs** | **27.81** |    **1.16** | **375.0000** | **187.5000** |  **6342.1 KB** |       **27.03** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 10000 | 4,524.60 μs | 221.216 μs | 131.642 μs | 27.57 |    1.04 | 343.7500 |  93.7500 | 5872.29 KB |       25.02 |
| NativeSingle      | TaLib(...)Stoch [21] | 10000 |   164.22 μs |   7.366 μs |   4.383 μs |  1.00 |    0.04 |  13.6719 |   2.9297 |  234.67 KB |        1.00 |
| NativeParallel    | TaLib(...)Stoch [21] | 10000 |   222.20 μs |  13.827 μs |   7.232 μs |  1.35 |    0.05 |  46.8750 |  17.5781 |  743.95 KB |        3.17 |
