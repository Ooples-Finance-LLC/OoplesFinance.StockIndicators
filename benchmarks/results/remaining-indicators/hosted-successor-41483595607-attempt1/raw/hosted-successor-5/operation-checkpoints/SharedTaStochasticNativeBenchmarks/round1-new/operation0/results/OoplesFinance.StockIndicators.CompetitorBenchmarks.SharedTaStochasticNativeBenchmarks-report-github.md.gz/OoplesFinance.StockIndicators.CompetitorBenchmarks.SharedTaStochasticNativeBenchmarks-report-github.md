```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **1000**  |   **442.1 μs** |   **6.52 μs** |   **3.41 μs** |  **31.2500** |        **-** |  **645.94 KB** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 1000  |   472.2 μs |  41.34 μs |  27.34 μs |  35.1563 |        - |  598.34 KB |
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **10000** | **4,602.0 μs** | **353.26 μs** | **233.66 μs** | **375.0000** | **187.5000** | **6342.13 KB** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 10000 | 4,418.7 μs | 181.42 μs |  94.88 μs | 343.7500 |  93.7500 | 5872.27 KB |
