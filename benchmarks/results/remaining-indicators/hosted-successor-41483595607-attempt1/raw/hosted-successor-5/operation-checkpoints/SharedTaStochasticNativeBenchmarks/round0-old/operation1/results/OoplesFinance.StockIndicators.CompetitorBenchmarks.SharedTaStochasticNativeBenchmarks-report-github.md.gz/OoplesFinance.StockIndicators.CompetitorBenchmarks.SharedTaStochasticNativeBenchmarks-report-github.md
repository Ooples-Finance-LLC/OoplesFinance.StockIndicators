```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0     | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|---------:|--------:|-----------:|
| **BuilderFull**       | **TaLib(...)tochF [22]** | **1000**  |   **418.4 μs** | **106.78 μs** |  **70.63 μs** |  **15.6250** |       **-** |  **392.15 KB** |
| BuilderLatestOnly | TaLib(...)tochF [22] | 1000  |   340.0 μs |  18.04 μs |   9.43 μs |  19.5313 |       - |  344.56 KB |
| **BuilderFull**       | **TaLib(...)tochF [22]** | **10000** | **3,447.6 μs** | **282.31 μs** | **168.00 μs** | **218.7500** | **93.7500** | **3838.22 KB** |
| BuilderLatestOnly | TaLib(...)tochF [22] | 10000 | 3,416.7 μs | 328.73 μs | 217.44 μs | 187.5000 | 62.5000 | 3368.37 KB |
