```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)chRsi [24]** | **1000**  |   **493.58 μs** |   **4.369 μs** |  **2.285 μs** | **22.07** |    **0.44** |       **-** |       **-** |  **182.11 KB** |        **5.84** |
| BuilderLatestOnly | TaLib(...)chRsi [24] | 1000  |   484.17 μs |   4.699 μs |  3.108 μs | 21.65 |    0.45 |  7.8125 |       - |  134.44 KB |        4.31 |
| NativeSingle      | TaLib(...)chRsi [24] | 1000  |    22.38 μs |   0.702 μs |  0.464 μs |  1.00 |    0.03 |  1.8311 |  0.1221 |   31.16 KB |        1.00 |
| NativeParallel    | TaLib(...)chRsi [24] | 1000  |    33.51 μs |   2.403 μs |  1.589 μs |  1.50 |    0.07 |  6.1035 |  0.7324 |   94.43 KB |        3.03 |
|                   |                      |       |             |            |           |       |         |         |         |            |             |
| **BuilderFull**       | **TaLib(...)chRsi [24]** | **10000** | **5,071.92 μs** | **125.563 μs** | **83.052 μs** | **19.17** |    **0.31** | **93.7500** | **31.2500** | **1799.87 KB** |        **5.76** |
| BuilderLatestOnly | TaLib(...)chRsi [24] | 10000 | 4,970.56 μs |  24.784 μs | 14.749 μs | 18.79 |    0.10 | 62.5000 |       - | 1330.05 KB |        4.26 |
| NativeSingle      | TaLib(...)chRsi [24] | 10000 |   264.53 μs |   2.095 μs |  1.247 μs |  1.00 |    0.01 | 17.5781 |  3.9063 |  312.42 KB |        1.00 |
| NativeParallel    | TaLib(...)chRsi [24] | 10000 |   363.80 μs |  12.035 μs |  7.162 μs |  1.38 |    0.03 | 58.5938 | 23.4375 |   938.2 KB |        3.00 |
