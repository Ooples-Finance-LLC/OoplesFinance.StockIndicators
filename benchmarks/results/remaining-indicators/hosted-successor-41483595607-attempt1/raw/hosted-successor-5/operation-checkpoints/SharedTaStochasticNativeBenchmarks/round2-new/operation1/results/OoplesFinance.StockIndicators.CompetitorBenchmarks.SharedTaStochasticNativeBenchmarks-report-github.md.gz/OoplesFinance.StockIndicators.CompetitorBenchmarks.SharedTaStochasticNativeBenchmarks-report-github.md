```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)tochF [22]** | **1000**  |   **409.444 μs** |  **90.5418 μs** |  **59.8878 μs** | **45.92** |    **6.41** |  **15.6250** |       **-** |  **392.18 KB** |       **16.55** |
| BuilderLatestOnly | TaLib(...)tochF [22] | 1000  |   343.382 μs |  27.8076 μs |  14.5439 μs | 38.51 |    1.56 |  19.5313 |       - |  344.55 KB |       14.54 |
| NativeSingle      | TaLib(...)tochF [22] | 1000  |     8.918 μs |   0.1051 μs |   0.0625 μs |  1.00 |    0.01 |   1.4038 |  0.0610 |    23.7 KB |        1.00 |
| NativeParallel    | TaLib(...)tochF [22] | 1000  |    18.729 μs |   0.6561 μs |   0.3905 μs |  2.10 |    0.04 |   5.0049 |  0.4883 |   75.77 KB |        3.20 |
|                   |                      |       |              |             |             |       |         |          |         |            |             |
| **BuilderFull**       | **TaLib(...)tochF [22]** | **10000** | **3,460.917 μs** | **309.4769 μs** | **204.6998 μs** | **27.29** |    **1.72** | **218.7500** | **93.7500** | **3838.23 KB** |       **16.36** |
| BuilderLatestOnly | TaLib(...)tochF [22] | 10000 | 3,246.076 μs | 181.1430 μs |  94.7413 μs | 25.60 |    1.01 | 187.5000 | 62.5000 | 3368.38 KB |       14.36 |
| NativeSingle      | TaLib(...)tochF [22] | 10000 |   126.911 μs |   5.7311 μs |   3.7907 μs |  1.00 |    0.04 |  13.6719 |  2.9297 |  234.64 KB |        1.00 |
| NativeParallel    | TaLib(...)tochF [22] | 10000 |   194.292 μs |  13.9986 μs |   9.2592 μs |  1.53 |    0.08 |  46.8750 | 19.5313 |  743.75 KB |        3.17 |
