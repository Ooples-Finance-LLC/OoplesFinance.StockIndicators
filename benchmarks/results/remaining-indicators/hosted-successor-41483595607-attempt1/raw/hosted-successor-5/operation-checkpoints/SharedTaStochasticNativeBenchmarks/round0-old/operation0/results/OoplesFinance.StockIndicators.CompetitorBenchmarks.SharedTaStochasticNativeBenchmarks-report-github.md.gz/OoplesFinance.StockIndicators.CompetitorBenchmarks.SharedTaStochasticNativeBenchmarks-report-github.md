```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **1000**  |   **476.8 μs** |  **88.14 μs** |  **58.30 μs** |  **31.2500** |        **-** |  **645.94 KB** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 1000  |   478.8 μs |  92.46 μs |  61.16 μs |  35.1563 |        - |  598.35 KB |
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **10000** | **4,565.1 μs** | **299.92 μs** | **198.38 μs** | **375.0000** | **156.2500** | **6342.14 KB** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 10000 | 4,499.7 μs | 284.16 μs | 187.96 μs | 343.7500 |  93.7500 | 5872.26 KB |
