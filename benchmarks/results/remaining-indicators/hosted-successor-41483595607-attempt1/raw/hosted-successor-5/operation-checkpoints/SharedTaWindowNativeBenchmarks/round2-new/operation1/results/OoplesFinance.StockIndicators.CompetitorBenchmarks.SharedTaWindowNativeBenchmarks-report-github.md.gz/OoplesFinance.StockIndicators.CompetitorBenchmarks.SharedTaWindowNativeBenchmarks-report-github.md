```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **1000**  |   **163.05 μs** |  **46.596 μs** | **30.821 μs** |  **5.10** |    **0.92** |       **-** |       **-** |  **73.24 KB** |        **9.24** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 1000  |   147.11 μs |   7.860 μs |  5.199 μs |  4.61 |    0.16 |  0.9766 |       - |  25.22 KB |        3.18 |
| NativeSingle      | TaLib(...)vgDev [22] | 1000  |    31.94 μs |   0.159 μs |  0.083 μs |  1.00 |    0.00 |  0.2441 |       - |   7.92 KB |        1.00 |
| NativeParallel    | TaLib(...)vgDev [22] | 1000  |    23.03 μs |   4.222 μs |  2.793 μs |  0.72 |    0.08 |  0.9766 |       - |  16.76 KB |        2.12 |
|                   |                      |       |             |            |           |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **10000** | **1,094.16 μs** | **148.787 μs** | **98.414 μs** |  **3.38** |    **0.29** | **31.2500** | **15.6250** | **565.69 KB** |        **7.23** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 10000 | 1,031.94 μs | 109.052 μs | 72.131 μs |  3.19 |    0.21 |       - |       - |  95.59 KB |        1.22 |
| NativeSingle      | TaLib(...)vgDev [22] | 10000 |   323.66 μs |   3.506 μs |  2.086 μs |  1.00 |    0.01 |  3.9063 |       - |  78.25 KB |        1.00 |
| NativeParallel    | TaLib(...)vgDev [22] | 10000 |   221.14 μs |  23.873 μs | 15.790 μs |  0.68 |    0.05 |  9.7656 |  1.9531 |  157.4 KB |        2.01 |
