```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean          | Error       | StdDev      | Ratio  | RatioSD | Gen0      | Gen1     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |--------------:|------------:|------------:|-------:|--------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **TaLib(...)bands [24]** | **1000**  |  **2,251.984 μs** | **111.0179 μs** |  **66.0650 μs** | **236.58** |    **8.29** |  **142.8571** |        **-** |   **3187.7 KB** |       **81.56** |
| BuilderLatestOnly | TaLib(...)bands [24] | 1000  |  2,147.693 μs |  29.2047 μs |  17.3792 μs | 225.62 |    5.11 |  187.5000 |  31.2500 |   3140.2 KB |       80.34 |
| NativeSingle      | TaLib(...)bands [24] | 1000  |      9.523 μs |   0.3238 μs |   0.2141 μs |   1.00 |    0.03 |    2.3804 |   0.1831 |    39.09 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [24] | 1000  |     18.232 μs |   0.6864 μs |   0.4540 μs |   1.92 |    0.06 |    8.0566 |   1.3428 |   122.26 KB |        3.13 |
|                   |                      |       |               |             |             |        |         |           |          |             |             |
| **BuilderFull**       | **TaLib(...)bands [24]** | **10000** | **14,132.896 μs** | **645.8274 μs** | **427.1749 μs** | **152.83** |    **5.57** | **1875.0000** | **875.0000** | **32093.18 KB** |       **82.15** |
| BuilderLatestOnly | TaLib(...)bands [24] | 10000 | 13,980.540 μs | 551.3413 μs | 328.0944 μs | 151.19 |    4.76 | 1875.0000 | 875.0000 | 31623.45 KB |       80.95 |
| NativeSingle      | TaLib(...)bands [24] | 10000 |     92.518 μs |   3.2845 μs |   2.1725 μs |   1.00 |    0.03 |   23.4375 |   7.8125 |   390.65 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [24] | 10000 |    172.022 μs |   6.3520 μs |   4.2015 μs |   1.86 |    0.06 |   76.1719 |  36.1328 |  1212.11 KB |        3.10 |
