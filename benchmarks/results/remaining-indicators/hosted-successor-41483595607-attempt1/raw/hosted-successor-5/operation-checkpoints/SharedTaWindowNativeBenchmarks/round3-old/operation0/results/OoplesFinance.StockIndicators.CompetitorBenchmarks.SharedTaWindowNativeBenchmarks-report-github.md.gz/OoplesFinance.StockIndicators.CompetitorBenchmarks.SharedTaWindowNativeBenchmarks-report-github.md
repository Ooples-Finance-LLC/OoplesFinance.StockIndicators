```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0      | Gen1     | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)bands [24]** | **1000**  |  **2.194 ms** | **0.0328 ms** | **0.0195 ms** |  **142.8571** |        **-** |   **3.11 MB** |
| BuilderLatestOnly | TaLib(...)bands [24] | 1000  |  2.208 ms | 0.0246 ms | 0.0146 ms |  187.5000 |  31.2500 |   3.07 MB |
| **BuilderFull**       | **TaLib(...)bands [24]** | **10000** | **14.215 ms** | **0.4438 ms** | **0.2641 ms** | **1833.3333** | **833.3333** |  **31.34 MB** |
| BuilderLatestOnly | TaLib(...)bands [24] | 10000 | 14.798 ms | 1.1159 ms | 0.7381 ms | 1875.0000 | 875.0000 |  30.88 MB |
