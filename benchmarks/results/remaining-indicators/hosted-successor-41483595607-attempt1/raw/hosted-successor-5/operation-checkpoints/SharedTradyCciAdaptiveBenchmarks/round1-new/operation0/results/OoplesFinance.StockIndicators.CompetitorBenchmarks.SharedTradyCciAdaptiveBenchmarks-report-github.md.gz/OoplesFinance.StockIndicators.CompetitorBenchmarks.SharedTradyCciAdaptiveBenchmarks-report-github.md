```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Commo(...)Index [21]** | **1000**  |   **303.9 μs** |  **71.26 μs** |  **47.13 μs** |       **-** |       **-** |  **70.48 KB** |
| BuilderLatestOnly | Commo(...)Index [21] | 1000  |   272.6 μs |  33.57 μs |  22.21 μs |       - |       - |  22.88 KB |
| **BuilderFull**       | **Commo(...)Index [21]** | **10000** | **2,618.3 μs** | **159.70 μs** | **105.63 μs** | **31.2500** | **15.6250** | **633.45 KB** |
| BuilderLatestOnly | Commo(...)Index [21] | 10000 | 2,570.8 μs | 190.20 μs | 125.81 μs |       - |       - | 163.62 KB |
