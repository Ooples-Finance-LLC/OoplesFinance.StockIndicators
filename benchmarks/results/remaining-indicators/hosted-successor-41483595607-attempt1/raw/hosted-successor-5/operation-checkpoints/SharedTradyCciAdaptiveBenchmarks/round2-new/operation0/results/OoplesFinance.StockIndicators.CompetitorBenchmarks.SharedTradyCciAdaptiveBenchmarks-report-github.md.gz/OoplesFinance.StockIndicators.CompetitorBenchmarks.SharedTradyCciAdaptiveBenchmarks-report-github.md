```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | Gen0      | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|----------:|---------:|---------:|------------:|------------:|
| **BuilderFull**       | **Commo(...)Index [21]** | **1000**  |     **297.3 μs** |    **72.06 μs** |    **47.66 μs** |  **0.02** |         **-** |        **-** |        **-** |    **70.48 KB** |       **0.016** |
| BuilderLatestOnly | Commo(...)Index [21] | 1000  |     269.4 μs |    26.38 μs |    15.70 μs |  0.02 |         - |        - |        - |    22.88 KB |       0.005 |
| NativeSingle      | Commo(...)Index [21] | 1000  |  14,264.1 μs |   131.08 μs |    78.00 μs |  1.00 |  250.0000 |        - |        - |  4398.03 KB |       1.000 |
| NativeParallel    | Commo(...)Index [21] | 1000  |   6,582.8 μs |   158.75 μs |    94.47 μs |  0.46 |  266.6667 |  66.6667 |        - |  4407.24 KB |       1.002 |
|                   |                      |       |              |             |             |       |           |          |          |             |             |
| **BuilderFull**       | **Commo(...)Index [21]** | **10000** |   **2,634.1 μs** |   **213.02 μs** |   **140.90 μs** |  **0.02** |   **31.2500** |  **15.6250** |        **-** |   **633.46 KB** |       **0.014** |
| BuilderLatestOnly | Commo(...)Index [21] | 10000 |   2,603.7 μs |   207.22 μs |   137.06 μs |  0.02 |         - |        - |        - |   163.63 KB |       0.004 |
| NativeSingle      | Commo(...)Index [21] | 10000 | 138,855.1 μs | 1,472.14 μs |   973.73 μs |  1.00 | 2750.0000 | 500.0000 | 250.0000 | 45275.61 KB |       1.000 |
| NativeParallel    | Commo(...)Index [21] | 10000 |  80,600.3 μs | 3,112.45 μs | 2,058.69 μs |  0.58 | 2750.0000 | 500.0000 | 250.0000 | 45393.99 KB |       1.003 |
