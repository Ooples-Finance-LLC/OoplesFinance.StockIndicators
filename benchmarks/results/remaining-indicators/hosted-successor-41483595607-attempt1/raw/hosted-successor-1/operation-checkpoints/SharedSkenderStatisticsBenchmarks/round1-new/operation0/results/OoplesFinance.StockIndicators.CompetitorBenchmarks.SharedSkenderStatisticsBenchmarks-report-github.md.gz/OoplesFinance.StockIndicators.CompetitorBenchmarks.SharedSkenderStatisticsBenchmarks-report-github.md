```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Gen0     | Allocated |
|------------------ |---------------- |------ |----------:|----------:|----------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetBeta** | **1000**  |  **3.297 ms** | **0.3357 ms** | **0.2221 ms** |        **-** |   **1.29 MB** |
| BuilderLatestOnly | Skender.GetBeta | 1000  |  1.565 ms | 0.0668 ms | 0.0349 ms |  15.6250 |   1.24 MB |
| **BuilderFull**       | **Skender.GetBeta** | **10000** | **17.336 ms** | **2.4804 ms** | **1.6407 ms** | **142.8571** |  **12.96 MB** |
| BuilderLatestOnly | Skender.GetBeta | 10000 | 16.496 ms | 0.9972 ms | 0.5934 ms | 142.8571 |   12.5 MB |
