```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------------ |---------------- |------ |------------:|------------:|------------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| **BuilderFull**       | **Skender.GetBeta** | **1000**  |  **6,344.6 μs** | **4,157.90 μs** | **2,750.19 μs** |  **9.94** |    **4.11** |        **-** |        **-** |        **-** |   **1.29 MB** |        **0.52** |
| BuilderLatestOnly | Skender.GetBeta | 1000  |  1,484.8 μs |    28.99 μs |    15.16 μs |  2.33 |    0.03 |  15.6250 |        - |        - |   1.24 MB |        0.50 |
| NativeSingle      | Skender.GetBeta | 1000  |    638.3 μs |     8.31 μs |     4.94 μs |  1.00 |    0.01 |  27.3438 |   7.8125 |        - |   2.47 MB |        1.00 |
| NativeParallel    | Skender.GetBeta | 1000  |    430.6 μs |     4.96 μs |     2.59 μs |  0.67 |    0.01 |  31.2500 |  11.7188 |        - |    2.5 MB |        1.01 |
|                   |                 |       |             |             |             |       |         |          |          |          |           |             |
| **BuilderFull**       | **Skender.GetBeta** | **10000** | **16,258.5 μs** | **2,249.21 μs** | **1,487.71 μs** |  **1.69** |    **0.18** |        **-** |        **-** |        **-** |  **12.96 MB** |        **0.52** |
| BuilderLatestOnly | Skender.GetBeta | 10000 | 16,360.2 μs | 1,228.89 μs |   731.29 μs |  1.70 |    0.13 | 142.8571 |        - |        - |   12.5 MB |        0.50 |
| NativeSingle      | Skender.GetBeta | 10000 |  9,673.9 μs |   907.62 μs |   600.33 μs |  1.00 |    0.09 | 416.6667 | 333.3333 | 166.6667 |  25.13 MB |        1.00 |
| NativeParallel    | Skender.GetBeta | 10000 |  4,513.7 μs |   114.74 μs |    68.28 μs |  0.47 |    0.03 | 312.5000 | 281.2500 |        - |  25.23 MB |        1.00 |
