```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Gen0     | Allocated |
|------------------ |---------------- |------ |----------:|----------:|----------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetBeta** | **1000**  |  **2.557 ms** | **0.5938 ms** | **0.3928 ms** |        **-** |   **1.29 MB** |
| BuilderLatestOnly | Skender.GetBeta | 1000  |  1.318 ms | 0.0503 ms | 0.0263 ms |  15.6250 |   1.24 MB |
| **BuilderFull**       | **Skender.GetBeta** | **10000** | **13.539 ms** | **0.3724 ms** | **0.1948 ms** | **142.8571** |  **12.96 MB** |
| BuilderLatestOnly | Skender.GetBeta | 10000 | 14.364 ms | 1.2287 ms | 0.8127 ms | 125.0000 |   12.5 MB |
