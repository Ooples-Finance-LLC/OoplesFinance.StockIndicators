```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)nLine [44]** |   **198.5 μs** |  **23.07 μs** |  **13.73 μs** |  **1.00** |    **0.09** |  **194.64 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)nLine [44] | 1,087.6 μs |  58.56 μs |  38.74 μs |  5.50 |    0.38 |  903.95 KB |        4.64 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Trady(...)nLine [44]** | **2,030.1 μs** | **118.86 μs** |  **70.73 μs** |  **1.00** |    **0.05** |  **2337.9 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)nLine [44] | 8,301.6 μs | 212.32 μs | 126.35 μs |  4.09 |    0.15 | 8809.84 KB |        3.77 |
