```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean        | Error      | StdDev    | Ratio | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |-------------------- |------------:|-----------:|----------:|------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ppo** |   **629.89 μs** |  **48.593 μs** | **32.141 μs** |  **1.00** |    **0.07** |  **1505.21 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ppo |    11.81 μs |   0.740 μs |  0.387 μs |  0.02 |    0.00 |    43.91 KB |        0.03 |
|            |       |                     |             |            |           |       |         |             |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ppo** | **6,239.08 μs** | **121.686 μs** | **72.414 μs** |  **1.00** |    **0.02** | **15133.64 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ppo |    92.50 μs |   7.338 μs |  4.854 μs |  0.01 |    0.00 |   407.59 KB |        0.03 |
