```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)rExit [30]** |    **318.0 μs** |    **29.19 μs** |  **19.31 μs** |  **1.00** |    **0.08** |         **-** |         **-** |         **-** |    **155.1 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)rExit [30] |  1,983.6 μs |    29.04 μs |  17.28 μs |  6.26 |    0.35 |         - |         - |         - |  3033.85 KB |       19.56 |
|            |       |                      |             |             |           |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)rExit [30]** |  **2,760.8 μs** |    **95.91 μs** |  **57.07 μs** |  **1.00** |    **0.03** |         **-** |         **-** |         **-** |  **1514.85 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)rExit [30] | 24,295.0 μs | 1,663.40 μs | 989.86 μs |  8.80 |    0.38 | 1000.0000 | 1000.0000 | 1000.0000 | 29567.66 KB |       19.52 |
