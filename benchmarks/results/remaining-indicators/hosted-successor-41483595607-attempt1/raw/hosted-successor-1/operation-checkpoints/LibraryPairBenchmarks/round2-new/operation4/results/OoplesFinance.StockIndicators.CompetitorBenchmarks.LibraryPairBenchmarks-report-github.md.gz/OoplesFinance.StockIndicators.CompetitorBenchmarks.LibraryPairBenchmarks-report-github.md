```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.T3** |   **209.38 μs** | **14.615 μs** |  **7.644 μs** |  **1.00** |    **0.05** |  **105.85 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.T3 |    10.54 μs |  0.681 μs |  0.450 μs |  0.05 |    0.00 |   36.61 KB |        0.35 |
|            |       |                    |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.T3** | **2,048.03 μs** | **63.037 μs** | **32.970 μs** |  **1.00** |    **0.02** | **1034.28 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.T3 |    85.88 μs | 14.166 μs |  9.370 μs |  0.04 |    0.00 |  328.95 KB |        0.32 |
