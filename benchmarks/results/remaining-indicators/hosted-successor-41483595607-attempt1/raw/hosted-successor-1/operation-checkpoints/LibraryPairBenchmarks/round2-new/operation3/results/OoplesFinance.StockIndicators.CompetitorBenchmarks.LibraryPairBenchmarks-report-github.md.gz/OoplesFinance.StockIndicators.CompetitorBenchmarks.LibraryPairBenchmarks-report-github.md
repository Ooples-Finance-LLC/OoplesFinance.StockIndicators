```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)chRsi [24]** |   **549.32 μs** |  **48.112 μs** |  **28.631 μs** |  **1.00** |    **0.07** |  **264.27 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)chRsi [24] |    41.38 μs |   0.829 μs |   0.433 μs |  0.08 |    0.00 |   88.69 KB |        0.34 |
|            |       |                      |             |            |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)chRsi [24]** | **4,792.32 μs** | **177.969 μs** | **117.716 μs** |  **1.00** |    **0.03** | **2609.66 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)chRsi [24] |   347.41 μs |  23.377 μs |  13.912 μs |  0.07 |    0.00 |  808.08 KB |        0.31 |
