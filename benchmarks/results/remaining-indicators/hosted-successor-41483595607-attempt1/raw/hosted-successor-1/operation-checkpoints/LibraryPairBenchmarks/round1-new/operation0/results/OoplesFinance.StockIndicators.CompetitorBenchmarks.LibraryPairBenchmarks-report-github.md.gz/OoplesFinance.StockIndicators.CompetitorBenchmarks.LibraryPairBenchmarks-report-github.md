```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId              | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |-------------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Ppo** |   **643.1 μs** |  **35.37 μs** |  **21.05 μs** |  **1.00** |    **0.04** |   **1.47 MB** |        **1.00** |
|        |       |                     |            |           |           |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Ppo** | **6,343.6 μs** | **356.79 μs** | **212.32 μs** |  **1.00** |    **0.05** |  **14.78 MB** |        **1.00** |
