```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |-----------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)Stoch [21]** |   **501.3 μs** |    **74.67 μs** |  **49.39 μs** |  **1.01** |    **0.13** |  **720.53 KB** |        **1.00** |
|        |       |                      |            |             |           |       |         |            |             |
| **Ooples** | **10000** | **TaLib(...)Stoch [21]** | **5,581.4 μs** | **1,328.54 μs** | **878.75 μs** |  **1.02** |    **0.22** | **7145.03 KB** |        **1.00** |
