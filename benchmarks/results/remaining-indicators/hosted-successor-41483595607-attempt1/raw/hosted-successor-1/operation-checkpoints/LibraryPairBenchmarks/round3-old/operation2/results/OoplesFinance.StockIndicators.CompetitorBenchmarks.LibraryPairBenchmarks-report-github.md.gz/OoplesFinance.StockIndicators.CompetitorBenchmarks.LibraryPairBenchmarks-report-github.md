```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)tochF [22]** |   **352.7 μs** |  **43.49 μs** |  **25.88 μs** |  **1.00** |    **0.10** |  **469.95 KB** |        **1.00** |
|        |       |                      |            |           |           |       |         |            |             |
| **Ooples** | **10000** | **TaLib(...)tochF [22]** | **3,060.6 μs** | **207.86 μs** | **123.69 μs** |  **1.00** |    **0.05** | **4643.84 KB** |        **1.00** |
