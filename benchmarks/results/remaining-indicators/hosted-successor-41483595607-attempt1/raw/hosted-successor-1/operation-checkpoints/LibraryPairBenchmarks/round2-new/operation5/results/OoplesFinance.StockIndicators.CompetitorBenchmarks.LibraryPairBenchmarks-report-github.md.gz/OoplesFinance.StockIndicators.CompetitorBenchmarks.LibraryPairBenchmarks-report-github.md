```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Trix** |   **359.82 μs** | **36.356 μs** | **21.635 μs** |  **1.00** |    **0.08** |  **192.87 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Trix |    16.14 μs |  0.545 μs |  0.285 μs |  0.04 |    0.00 |   45.79 KB |        0.24 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Trix** | **3,336.81 μs** | **80.264 μs** | **47.764 μs** |  **1.00** |    **0.02** | **1895.02 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Trix |   142.26 μs | 13.436 μs |  7.995 μs |  0.04 |    0.00 |  407.45 KB |        0.22 |
