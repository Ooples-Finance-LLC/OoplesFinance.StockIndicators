```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev   | Gen0   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|---------:|-------:|----------:|
| **BuilderFull**       | **Expon(...)erage [24]** | **1000**  |  **30.27 μs** |  **0.431 μs** | **0.225 μs** |      **-** |  **56.66 KB** |
| BuilderLatestOnly | Expon(...)erage [24] | 1000  |  26.86 μs |  0.238 μs | 0.124 μs |      - |   8.78 KB |
| **BuilderFull**       | **Expon(...)erage [24]** | **10000** | **391.15 μs** | **14.073 μs** | **9.309 μs** | **3.9063** |  **549.2 KB** |
| BuilderLatestOnly | Expon(...)erage [24] | 10000 | 359.55 μs | 10.179 μs | 6.058 μs |      - |   79.1 KB |
