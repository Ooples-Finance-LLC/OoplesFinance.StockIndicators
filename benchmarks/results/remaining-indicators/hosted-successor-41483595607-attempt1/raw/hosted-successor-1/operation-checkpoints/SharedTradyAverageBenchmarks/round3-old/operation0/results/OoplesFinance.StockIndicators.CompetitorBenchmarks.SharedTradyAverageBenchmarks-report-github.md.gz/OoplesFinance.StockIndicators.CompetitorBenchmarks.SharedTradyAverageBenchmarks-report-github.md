```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0   | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|-------:|-------:|----------:|
| **BuilderFull**       | **Expon(...)erage [24]** | **1000**  |  **29.99 μs** |  **1.014 μs** |  **0.603 μs** |      **-** |      **-** |  **56.66 KB** |
| BuilderLatestOnly | Expon(...)erage [24] | 1000  |  24.47 μs |  0.117 μs |  0.061 μs |      - |      - |   8.78 KB |
| **BuilderFull**       | **Expon(...)erage [24]** | **10000** | **372.72 μs** | **11.917 μs** |  **7.882 μs** | **5.8594** | **1.9531** | **549.18 KB** |
| BuilderLatestOnly | Expon(...)erage [24] | 10000 | 347.09 μs | 15.325 μs | 10.137 μs |      - |      - |   79.1 KB |
