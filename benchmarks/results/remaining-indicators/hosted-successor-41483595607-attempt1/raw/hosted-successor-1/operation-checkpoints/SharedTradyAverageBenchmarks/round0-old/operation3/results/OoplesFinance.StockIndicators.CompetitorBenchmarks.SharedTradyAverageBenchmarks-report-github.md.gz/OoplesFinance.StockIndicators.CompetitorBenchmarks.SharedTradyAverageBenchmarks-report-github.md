```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Expon(...)lator [34]** | **1000**  |  **85.97 μs** |  **4.395 μs** |  **2.616 μs** |  **64.92 KB** |
| BuilderLatestOnly | Expon(...)lator [34] | 1000  |  77.87 μs |  1.067 μs |  0.706 μs |  17.32 KB |
| **BuilderFull**       | **Expon(...)lator [34]** | **10000** | **873.23 μs** | **33.030 μs** | **21.847 μs** | **627.82 KB** |
| BuilderLatestOnly | Expon(...)lator [34] | 10000 | 848.99 μs | 31.481 μs | 18.734 μs |    158 KB |
