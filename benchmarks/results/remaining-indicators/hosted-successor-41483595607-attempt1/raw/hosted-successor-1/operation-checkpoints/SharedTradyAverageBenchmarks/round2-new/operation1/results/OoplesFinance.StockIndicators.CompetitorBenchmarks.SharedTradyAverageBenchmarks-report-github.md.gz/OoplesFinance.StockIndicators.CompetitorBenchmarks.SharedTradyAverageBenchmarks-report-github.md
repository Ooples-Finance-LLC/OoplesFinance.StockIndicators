```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Weigh(...)erage [21]** | **1000**  |     **21.78 μs** |   **1.824 μs** |   **1.086 μs** | **0.013** |    **0.00** |        **-** |        **-** |        **-** |   **58.44 KB** |        **0.10** |
| BuilderLatestOnly | Weigh(...)erage [21] | 1000  |     12.36 μs |   0.645 μs |   0.337 μs | 0.008 |    0.00 |   0.1221 |        - |        - |   10.59 KB |        0.02 |
| NativeSingle      | Weigh(...)erage [21] | 1000  |  1,642.08 μs |  35.233 μs |  20.967 μs | 1.000 |    0.02 |        - |        - |        - |   559.6 KB |        1.00 |
| NativeParallel    | Weigh(...)erage [21] | 1000  |    870.69 μs |  64.292 μs |  42.525 μs | 0.530 |    0.03 |        - |        - |        - |  565.12 KB |        1.01 |
|                   |                      |       |              |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Weigh(...)erage [21]** | **10000** |    **112.56 μs** |   **3.813 μs** |   **2.269 μs** | **0.006** |    **0.00** |   **5.8594** |   **3.9063** |        **-** |  **550.96 KB** |        **0.10** |
| BuilderLatestOnly | Weigh(...)erage [21] | 10000 |     96.56 μs |   4.907 μs |   2.920 μs | 0.005 |    0.00 |   0.9766 |        - |        - |   80.91 KB |        0.01 |
| NativeSingle      | Weigh(...)erage [21] | 10000 | 17,735.99 μs | 246.114 μs | 146.458 μs | 1.000 |    0.01 | 333.3333 | 333.3333 | 333.3333 | 5508.38 KB |        1.00 |
| NativeParallel    | Weigh(...)erage [21] | 10000 |  9,372.57 μs | 381.392 μs | 226.960 μs | 0.528 |    0.01 | 166.6667 | 166.6667 | 166.6667 | 5620.59 KB |        1.02 |
