```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0   | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|-------:|-------:|----------:|
| **BuilderFull**       | **Simpl(...)lator [29]** | **1000**  |  **58.11 μs** | **10.522 μs** |  **6.960 μs** |      **-** |      **-** |  **69.52 KB** |
| BuilderLatestOnly | Simpl(...)lator [29] | 1000  |  38.44 μs |  1.584 μs |  0.943 μs |      - |      - |  21.94 KB |
| **BuilderFull**       | **Simpl(...)lator [29]** | **10000** | **279.15 μs** | **24.842 μs** | **14.783 μs** | **5.8594** | **1.9531** | **632.36 KB** |
| BuilderLatestOnly | Simpl(...)lator [29] | 10000 | 309.78 μs | 32.653 μs | 21.598 μs | 1.9531 |      - | 162.58 KB |
