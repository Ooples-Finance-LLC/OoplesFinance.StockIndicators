```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev   | Gen0   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|---------:|-------:|----------:|
| **BuilderFull**       | **Expon(...)erage [24]** | **1000**  |  **34.41 μs** | **10.311 μs** | **6.820 μs** |      **-** |  **56.66 KB** |
| BuilderLatestOnly | Expon(...)erage [24] | 1000  |  25.84 μs |  0.792 μs | 0.524 μs |      - |   8.78 KB |
| **BuilderFull**       | **Expon(...)erage [24]** | **10000** | **364.33 μs** | **11.581 μs** | **6.892 μs** | **3.9063** | **549.21 KB** |
| BuilderLatestOnly | Expon(...)erage [24] | 10000 | 339.13 μs | 14.020 μs | 9.273 μs |      - |   79.1 KB |
