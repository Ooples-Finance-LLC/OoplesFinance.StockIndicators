```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0   | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|-------:|-------:|----------:|
| **BuilderFull**       | **Simpl(...)lator [29]** | **1000**  |  **59.58 μs** |  **9.841 μs** |  **6.509 μs** |      **-** |      **-** |  **69.55 KB** |
| BuilderLatestOnly | Simpl(...)lator [29] | 1000  |  39.98 μs |  3.292 μs |  2.177 μs |      - |      - |  21.94 KB |
| **BuilderFull**       | **Simpl(...)lator [29]** | **10000** | **298.08 μs** | **30.023 μs** | **19.858 μs** | **5.8594** | **1.9531** |  **632.4 KB** |
| BuilderLatestOnly | Simpl(...)lator [29] | 10000 | 302.05 μs | 44.631 μs | 29.521 μs | 1.9531 |      - | 162.58 KB |
