```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Expon(...)lator [34]** | **1000**  |  **79.70 μs** |  **3.664 μs** |  **2.180 μs** |  **64.92 KB** |
| BuilderLatestOnly | Expon(...)lator [34] | 1000  |  75.30 μs |  1.022 μs |  0.676 μs |  17.32 KB |
| **BuilderFull**       | **Expon(...)lator [34]** | **10000** | **872.17 μs** |  **8.215 μs** |  **4.889 μs** | **627.81 KB** |
| BuilderLatestOnly | Expon(...)lator [34] | 10000 | 822.84 μs | 27.598 μs | 16.423 μs | 158.01 KB |
