```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Expon(...)lator [34]** | **1000**  |  **82.84 μs** |  **4.248 μs** |  **2.810 μs** |  **64.92 KB** |
| BuilderLatestOnly | Expon(...)lator [34] | 1000  |  78.37 μs |  0.643 μs |  0.383 μs |  17.32 KB |
| **BuilderFull**       | **Expon(...)lator [34]** | **10000** | **894.46 μs** | **30.480 μs** | **20.160 μs** | **627.81 KB** |
| BuilderLatestOnly | Expon(...)lator [34] | 10000 | 844.02 μs | 25.231 μs | 15.014 μs | 158.01 KB |
