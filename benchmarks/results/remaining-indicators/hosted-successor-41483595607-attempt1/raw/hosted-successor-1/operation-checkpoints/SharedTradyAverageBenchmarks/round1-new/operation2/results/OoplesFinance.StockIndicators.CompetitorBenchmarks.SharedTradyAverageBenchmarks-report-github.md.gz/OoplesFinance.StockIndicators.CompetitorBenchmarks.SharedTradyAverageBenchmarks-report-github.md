```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0   | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|-------:|-------:|----------:|
| **BuilderFull**       | **Simpl(...)lator [29]** | **1000**  |  **45.71 μs** |  **3.941 μs** |  **2.345 μs** |      **-** |      **-** |  **69.55 KB** |
| BuilderLatestOnly | Simpl(...)lator [29] | 1000  |  40.86 μs |  6.992 μs |  4.625 μs |      - |      - |  21.94 KB |
| **BuilderFull**       | **Simpl(...)lator [29]** | **10000** | **314.48 μs** | **42.942 μs** | **28.404 μs** | **5.8594** | **1.9531** | **632.39 KB** |
| BuilderLatestOnly | Simpl(...)lator [29] | 10000 | 289.95 μs | 45.282 μs | 29.951 μs | 1.9531 |      - | 162.58 KB |
