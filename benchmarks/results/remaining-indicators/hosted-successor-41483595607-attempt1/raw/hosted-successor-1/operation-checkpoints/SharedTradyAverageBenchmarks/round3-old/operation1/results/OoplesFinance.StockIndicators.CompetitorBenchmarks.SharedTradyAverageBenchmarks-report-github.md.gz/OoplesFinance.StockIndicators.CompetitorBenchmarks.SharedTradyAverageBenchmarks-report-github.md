```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev   | Gen0   | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|---------:|-------:|-------:|----------:|
| **BuilderFull**       | **Weigh(...)erage [21]** | **1000**  |  **25.34 μs** | **10.248 μs** | **6.778 μs** | **0.4883** |      **-** |  **58.47 KB** |
| BuilderLatestOnly | Weigh(...)erage [21] | 1000  |  12.33 μs |  1.897 μs | 1.129 μs |      - |      - |  10.59 KB |
| **BuilderFull**       | **Weigh(...)erage [21]** | **10000** | **111.18 μs** |  **6.231 μs** | **4.121 μs** | **5.8594** | **2.9297** |    **551 KB** |
| BuilderLatestOnly | Weigh(...)erage [21] | 10000 |  93.16 μs |  8.483 μs | 5.611 μs | 0.9766 |      - |  80.91 KB |
