```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0   | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|-------:|-------:|----------:|
| **BuilderFull**       | **Weigh(...)erage [21]** | **1000**  |  **19.08 μs** | **1.683 μs** | **1.002 μs** | **0.4883** |      **-** |  **58.47 KB** |
| BuilderLatestOnly | Weigh(...)erage [21] | 1000  |  11.48 μs | 0.733 μs | 0.383 μs | 0.1221 |      - |  10.59 KB |
| **BuilderFull**       | **Weigh(...)erage [21]** | **10000** | **107.92 μs** | **6.405 μs** | **4.237 μs** | **5.8594** | **3.9063** |    **551 KB** |
| BuilderLatestOnly | Weigh(...)erage [21] | 10000 |  94.65 μs | 7.709 μs | 5.099 μs | 0.9766 |      - |  80.91 KB |
