```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0   | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|-------:|-------:|----------:|
| **BuilderFull**       | **Weigh(...)erage [21]** | **1000**  |  **20.24 μs** | **2.454 μs** | **1.460 μs** | **0.4883** |      **-** |  **58.47 KB** |
| BuilderLatestOnly | Weigh(...)erage [21] | 1000  |  12.10 μs | 1.459 μs | 0.868 μs | 0.1221 |      - |  10.59 KB |
| **BuilderFull**       | **Weigh(...)erage [21]** | **10000** | **112.08 μs** | **7.918 μs** | **5.237 μs** | **5.8594** | **2.9297** |    **551 KB** |
| BuilderLatestOnly | Weigh(...)erage [21] | 10000 |  95.16 μs | 5.067 μs | 3.351 μs | 0.9766 |      - |  80.91 KB |
