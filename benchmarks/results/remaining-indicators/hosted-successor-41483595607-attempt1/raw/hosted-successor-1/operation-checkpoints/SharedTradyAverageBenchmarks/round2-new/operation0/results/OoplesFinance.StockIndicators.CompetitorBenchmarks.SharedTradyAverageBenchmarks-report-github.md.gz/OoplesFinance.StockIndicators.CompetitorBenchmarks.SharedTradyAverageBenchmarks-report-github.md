```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error        | StdDev       | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-------------:|-------------:|------:|--------:|---------:|---------:|---------:|------------:|------------:|
| **BuilderFull**       | **Expon(...)erage [24]** | **1000**  |     **29.87 μs** |     **0.588 μs** |     **0.350 μs** |  **0.06** |    **0.00** |        **-** |        **-** |        **-** |    **56.66 KB** |       **0.062** |
| BuilderLatestOnly | Expon(...)erage [24] | 1000  |     26.72 μs |     0.174 μs |     0.115 μs |  0.06 |    0.00 |        - |        - |        - |     8.78 KB |       0.010 |
| NativeSingle      | Expon(...)erage [24] | 1000  |    478.38 μs |     4.940 μs |     2.940 μs |  1.00 |    0.01 |   7.8125 |        - |        - |   915.29 KB |       1.000 |
| NativeParallel    | Expon(...)erage [24] | 1000  |    466.66 μs |    29.531 μs |    19.533 μs |  0.98 |    0.04 |  15.6250 |   3.9063 |        - |  1328.65 KB |       1.452 |
|                   |                      |       |              |              |              |       |         |          |          |          |             |             |
| **BuilderFull**       | **Expon(...)erage [24]** | **10000** |    **382.61 μs** |     **6.807 μs** |     **3.560 μs** |  **0.04** |    **0.00** |   **3.9063** |        **-** |        **-** |   **549.21 KB** |       **0.062** |
| BuilderLatestOnly | Expon(...)erage [24] | 10000 |    342.27 μs |     8.491 μs |     5.616 μs |  0.04 |    0.00 |        - |        - |        - |    79.12 KB |       0.009 |
| NativeSingle      | Expon(...)erage [24] | 10000 |  8,645.27 μs | 1,025.123 μs |   678.055 μs |  1.01 |    0.11 | 692.3077 | 692.3077 | 692.3077 |  8912.62 KB |       1.000 |
| NativeParallel    | Expon(...)erage [24] | 10000 | 10,508.74 μs | 1,839.569 μs | 1,216.761 μs |  1.22 |    0.17 | 818.1818 | 727.2727 | 727.2727 | 13009.39 KB |       1.460 |
