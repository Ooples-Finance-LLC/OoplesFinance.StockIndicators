```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error        | StdDev       | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-------------:|-------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Expon(...)lator [34]** | **1000**  |     **85.20 μs** |     **2.892 μs** |     **1.513 μs** |  **0.07** |    **0.00** |         **-** |         **-** |         **-** |    **64.92 KB** |       **0.030** |
| BuilderLatestOnly | Expon(...)lator [34] | 1000  |     78.24 μs |     2.606 μs |     1.724 μs |  0.07 |    0.00 |         - |         - |         - |    17.32 KB |       0.008 |
| NativeSingle      | Expon(...)lator [34] | 1000  |  1,152.23 μs |    14.645 μs |     8.715 μs |  1.00 |    0.01 |   23.4375 |    7.8125 |         - |  2200.75 KB |       1.000 |
| NativeParallel    | Expon(...)lator [34] | 1000  |  1,041.47 μs |    72.005 μs |    47.627 μs |  0.90 |    0.04 |   39.0625 |   31.2500 |         - |  3332.44 KB |       1.514 |
|                   |                      |       |              |              |              |       |         |           |           |           |             |             |
| **BuilderFull**       | **Expon(...)lator [34]** | **10000** |    **898.33 μs** |     **9.655 μs** |     **5.050 μs** |  **0.05** |    **0.00** |         **-** |         **-** |         **-** |   **627.81 KB** |       **0.029** |
| BuilderLatestOnly | Expon(...)lator [34] | 10000 |    849.36 μs |     9.912 μs |     5.898 μs |  0.05 |    0.00 |         - |         - |         - |   158.01 KB |       0.007 |
| NativeSingle      | Expon(...)lator [34] | 10000 | 17,478.76 μs | 2,254.582 μs | 1,491.267 μs |  1.01 |    0.11 |  666.6667 |  666.6667 |  666.6667 | 21973.94 KB |       1.000 |
| NativeParallel    | Expon(...)lator [34] | 10000 | 18,299.50 μs | 3,164.062 μs | 2,092.831 μs |  1.05 |    0.14 | 1142.8571 | 1000.0000 | 1000.0000 | 33530.13 KB |       1.526 |
