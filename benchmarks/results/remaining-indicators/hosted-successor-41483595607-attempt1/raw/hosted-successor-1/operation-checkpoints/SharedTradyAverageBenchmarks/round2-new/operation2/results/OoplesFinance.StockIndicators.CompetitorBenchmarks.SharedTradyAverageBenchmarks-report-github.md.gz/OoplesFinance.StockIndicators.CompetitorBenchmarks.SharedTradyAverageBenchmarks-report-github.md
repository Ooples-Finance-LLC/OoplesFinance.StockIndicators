```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error        | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-------------:|-----------:|------:|--------:|---------:|---------:|---------:|------------:|------------:|
| **BuilderFull**       | **Simpl(...)lator [29]** | **1000**  |     **48.96 μs** |     **1.079 μs** |   **0.642 μs** |  **0.06** |    **0.00** |        **-** |        **-** |        **-** |    **69.55 KB** |        **0.06** |
| BuilderLatestOnly | Simpl(...)lator [29] | 1000  |     41.18 μs |     3.795 μs |   2.258 μs |  0.05 |    0.00 |        - |        - |        - |    21.94 KB |        0.02 |
| NativeSingle      | Simpl(...)lator [29] | 1000  |    840.91 μs |     7.319 μs |   4.355 μs |  1.00 |    0.01 |   7.8125 |        - |        - |   1081.5 KB |        1.00 |
| NativeParallel    | Simpl(...)lator [29] | 1000  |    454.71 μs |    35.995 μs |  23.809 μs |  0.54 |    0.03 |  11.7188 |   3.9063 |        - |  1055.99 KB |        0.98 |
|                   |                      |       |              |              |            |       |         |          |          |          |             |             |
| **BuilderFull**       | **Simpl(...)lator [29]** | **10000** |    **301.18 μs** |    **33.943 μs** |  **22.451 μs** |  **0.02** |    **0.00** |   **5.8594** |   **1.9531** |        **-** |   **632.39 KB** |        **0.06** |
| BuilderLatestOnly | Simpl(...)lator [29] | 10000 |    293.36 μs |    38.347 μs |  22.820 μs |  0.02 |    0.00 |   1.9531 |        - |        - |   162.58 KB |        0.02 |
| NativeSingle      | Simpl(...)lator [29] | 10000 | 14,094.88 μs | 1,477.939 μs | 977.565 μs |  1.00 |    0.10 | 888.8889 | 888.8889 | 888.8889 | 10510.78 KB |        1.00 |
| NativeParallel    | Simpl(...)lator [29] | 10000 |  7,132.99 μs | 1,198.883 μs | 792.987 μs |  0.51 |    0.06 | 571.4286 | 500.0000 | 500.0000 | 10387.43 KB |        0.99 |
