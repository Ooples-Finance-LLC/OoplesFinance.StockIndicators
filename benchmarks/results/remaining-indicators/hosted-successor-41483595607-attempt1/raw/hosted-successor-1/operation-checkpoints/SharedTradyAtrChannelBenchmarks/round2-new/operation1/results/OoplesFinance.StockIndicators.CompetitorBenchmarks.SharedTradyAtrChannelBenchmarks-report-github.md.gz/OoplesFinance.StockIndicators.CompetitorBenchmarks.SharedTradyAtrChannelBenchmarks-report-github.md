```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |---------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **KeltnerChannels** | **1000**  |    **245.2 μs** |     **5.10 μs** |     **3.04 μs** |  **0.14** |    **0.01** |         **-** |         **-** |         **-** |    **96.79 KB** |        **0.03** |
| BuilderLatestOnly | KeltnerChannels | 1000  |    240.1 μs |     3.18 μs |     1.66 μs |  0.13 |    0.01 |         - |         - |         - |    49.23 KB |        0.02 |
| NativeSingle      | KeltnerChannels | 1000  |  1,816.8 μs |   105.97 μs |    70.10 μs |  1.00 |    0.05 |   46.8750 |   46.8750 |   46.8750 |  3049.24 KB |        1.00 |
| NativeParallel    | KeltnerChannels | 1000  |  1,270.0 μs |    28.16 μs |    14.73 μs |  0.70 |    0.03 |   62.5000 |   46.8750 |         - |  4839.38 KB |        1.59 |
|                   |                 |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **KeltnerChannels** | **10000** |  **2,533.8 μs** |    **19.27 μs** |    **10.08 μs** |  **0.10** |    **0.01** |         **-** |         **-** |         **-** |   **940.98 KB** |        **0.03** |
| BuilderLatestOnly | KeltnerChannels | 10000 |  2,459.1 μs |    30.40 μs |    18.09 μs |  0.10 |    0.01 |         - |         - |         - |   471.21 KB |        0.02 |
| NativeSingle      | KeltnerChannels | 10000 | 25,312.1 μs | 2,719.69 μs | 1,798.91 μs |  1.00 |    0.09 | 1200.0000 | 1000.0000 | 1000.0000 | 29773.84 KB |        1.00 |
| NativeParallel    | KeltnerChannels | 10000 | 24,268.4 μs | 2,910.69 μs | 1,925.24 μs |  0.96 |    0.10 | 1200.0000 | 1000.0000 | 1000.0000 | 47670.68 KB |        1.60 |
