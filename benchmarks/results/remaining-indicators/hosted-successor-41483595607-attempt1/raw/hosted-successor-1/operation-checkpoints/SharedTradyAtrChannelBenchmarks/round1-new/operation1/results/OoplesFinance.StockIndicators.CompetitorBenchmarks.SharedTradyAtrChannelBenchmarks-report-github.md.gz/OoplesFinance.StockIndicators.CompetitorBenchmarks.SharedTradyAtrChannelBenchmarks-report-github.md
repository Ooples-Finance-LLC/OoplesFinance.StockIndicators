```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **KeltnerChannels** | **1000**  |   **253.8 μs** |  **1.71 μs** |  **1.02 μs** |  **96.79 KB** |
| BuilderLatestOnly | KeltnerChannels | 1000  |   246.0 μs |  2.99 μs |  1.56 μs |  49.23 KB |
| **BuilderFull**       | **KeltnerChannels** | **10000** | **2,602.9 μs** | **40.30 μs** | **26.65 μs** | **940.98 KB** |
| BuilderLatestOnly | KeltnerChannels | 10000 | 2,484.5 μs | 23.02 μs | 12.04 μs |  471.2 KB |
