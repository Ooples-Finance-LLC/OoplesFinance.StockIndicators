```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **ChandelierExit** | **1000**  |   **232.7 μs** |   **6.00 μs** |   **3.14 μs** |   **73.7 KB** |
| BuilderLatestOnly | ChandelierExit | 1000  |   231.2 μs |  28.52 μs |  18.87 μs |  26.06 KB |
| **BuilderFull**       | **ChandelierExit** | **10000** | **2,511.7 μs** | **208.96 μs** | **138.22 μs** | **706.91 KB** |
| BuilderLatestOnly | ChandelierExit | 10000 | 2,607.6 μs | 232.26 μs | 153.63 μs | 237.11 KB |
