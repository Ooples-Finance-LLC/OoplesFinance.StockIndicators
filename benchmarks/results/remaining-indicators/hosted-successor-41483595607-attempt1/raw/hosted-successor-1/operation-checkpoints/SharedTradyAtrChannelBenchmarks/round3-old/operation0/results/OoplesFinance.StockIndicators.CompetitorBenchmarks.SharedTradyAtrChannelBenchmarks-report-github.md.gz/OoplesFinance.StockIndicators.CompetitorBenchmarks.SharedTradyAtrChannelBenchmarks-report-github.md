```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **ChandelierExit** | **1000**  |   **220.7 μs** |  **5.18 μs** |  **3.08 μs** |  **73.65 KB** |
| BuilderLatestOnly | ChandelierExit | 1000  |   206.8 μs |  3.70 μs |  1.94 μs |  26.04 KB |
| **BuilderFull**       | **ChandelierExit** | **10000** | **2,361.3 μs** | **18.22 μs** | **10.84 μs** | **706.91 KB** |
| BuilderLatestOnly | ChandelierExit | 10000 | 2,329.1 μs | 18.79 μs |  9.83 μs | 237.09 KB |
