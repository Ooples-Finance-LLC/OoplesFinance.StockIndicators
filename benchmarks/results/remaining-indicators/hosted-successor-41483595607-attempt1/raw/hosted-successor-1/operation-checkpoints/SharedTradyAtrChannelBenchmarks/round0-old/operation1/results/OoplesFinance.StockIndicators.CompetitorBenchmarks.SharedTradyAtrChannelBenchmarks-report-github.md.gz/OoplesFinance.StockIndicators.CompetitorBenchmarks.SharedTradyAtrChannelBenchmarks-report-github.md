```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |---------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **KeltnerChannels** | **1000**  |   **255.8 μs** |   **3.29 μs** |   **1.96 μs** |  **96.83 KB** |
| BuilderLatestOnly | KeltnerChannels | 1000  |   249.7 μs |   6.41 μs |   4.24 μs |  49.23 KB |
| **BuilderFull**       | **KeltnerChannels** | **10000** | **2,767.0 μs** | **204.82 μs** | **135.48 μs** | **941.02 KB** |
| BuilderLatestOnly | KeltnerChannels | 10000 | 2,570.4 μs |  84.74 μs |  50.43 μs | 471.21 KB |
