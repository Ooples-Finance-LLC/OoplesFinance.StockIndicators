```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **ChandelierExit** | **1000**  |   **225.7 μs** | **33.18 μs** | **21.95 μs** |  **73.65 KB** |
| BuilderLatestOnly | ChandelierExit | 1000  |   227.4 μs |  6.85 μs |  4.53 μs |  26.05 KB |
| **BuilderFull**       | **ChandelierExit** | **10000** | **2,366.2 μs** | **29.44 μs** | **17.52 μs** | **706.92 KB** |
| BuilderLatestOnly | ChandelierExit | 10000 | 2,289.6 μs | 14.18 μs |  7.42 μs | 237.08 KB |
