```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------- |------ |------------:|------------:|------------:|------:|--------:|---------:|---------:|---------:|------------:|------------:|
| **BuilderFull**       | **ChandelierExit** | **1000**  |    **210.8 μs** |     **4.21 μs** |     **2.79 μs** |  **0.12** |    **0.01** |        **-** |        **-** |        **-** |    **73.65 KB** |       **0.027** |
| BuilderLatestOnly | ChandelierExit | 1000  |    204.0 μs |     3.68 μs |     2.19 μs |  0.11 |    0.01 |        - |        - |        - |    26.06 KB |       0.010 |
| NativeSingle      | ChandelierExit | 1000  |  1,795.3 μs |   120.94 μs |    79.99 μs |  1.00 |    0.06 |  31.2500 |  31.2500 |  31.2500 |  2693.57 KB |       1.000 |
| NativeParallel    | ChandelierExit | 1000  |  1,169.3 μs |    84.26 μs |    55.73 μs |  0.65 |    0.04 |  46.8750 |  31.2500 |        - |  3999.69 KB |       1.485 |
|                   |                |       |             |             |             |       |         |          |          |          |             |             |
| **BuilderFull**       | **ChandelierExit** | **10000** |  **2,330.7 μs** |   **155.25 μs** |   **102.69 μs** |  **0.11** |    **0.00** |        **-** |        **-** |        **-** |    **706.9 KB** |       **0.027** |
| BuilderLatestOnly | ChandelierExit | 10000 |  2,224.7 μs |    24.01 μs |    14.29 μs |  0.11 |    0.00 |        - |        - |        - |   237.11 KB |       0.009 |
| NativeSingle      | ChandelierExit | 10000 | 20,998.8 μs |   623.42 μs |   326.06 μs |  1.00 |    0.02 | 600.0000 | 600.0000 | 600.0000 | 26252.75 KB |       1.000 |
| NativeParallel    | ChandelierExit | 10000 | 20,667.1 μs | 2,837.61 μs | 1,688.62 μs |  0.98 |    0.08 | 857.1429 | 714.2857 | 571.4286 | 39443.21 KB |       1.502 |
