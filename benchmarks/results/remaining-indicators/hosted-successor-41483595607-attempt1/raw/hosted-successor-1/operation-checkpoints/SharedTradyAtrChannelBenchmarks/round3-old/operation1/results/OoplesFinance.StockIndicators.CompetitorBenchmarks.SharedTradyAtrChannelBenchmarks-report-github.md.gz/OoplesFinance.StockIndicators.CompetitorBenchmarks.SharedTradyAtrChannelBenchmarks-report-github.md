```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **KeltnerChannels** | **1000**  |   **248.9 μs** |  **6.39 μs** |  **3.34 μs** |  **96.83 KB** |
| BuilderLatestOnly | KeltnerChannels | 1000  |   242.4 μs |  3.69 μs |  1.93 μs |  49.23 KB |
| **BuilderFull**       | **KeltnerChannels** | **10000** | **2,580.8 μs** | **53.05 μs** | **31.57 μs** |    **941 KB** |
| BuilderLatestOnly | KeltnerChannels | 10000 | 2,476.4 μs | 19.86 μs | 11.82 μs | 471.19 KB |
