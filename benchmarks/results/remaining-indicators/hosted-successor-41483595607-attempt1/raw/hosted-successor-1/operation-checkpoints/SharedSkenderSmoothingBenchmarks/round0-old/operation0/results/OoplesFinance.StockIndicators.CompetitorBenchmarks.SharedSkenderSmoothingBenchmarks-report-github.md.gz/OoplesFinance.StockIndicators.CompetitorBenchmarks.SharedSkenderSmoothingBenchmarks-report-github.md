```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean      | Error     | StdDev   | Gen0   | Allocated |
|------------------ |-------------------- |------ |----------:|----------:|---------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetElderRay** | **1000**  |  **93.61 μs** |  **2.130 μs** | **1.267 μs** |      **-** |  **80.57 KB** |
| BuilderLatestOnly | Skender.GetElderRay | 1000  |  86.37 μs |  2.540 μs | 1.680 μs |      - |     33 KB |
| **BuilderFull**       | **Skender.GetElderRay** | **10000** | **886.25 μs** | **18.974 μs** | **9.924 μs** | **7.8125** | **784.08 KB** |
| BuilderLatestOnly | Skender.GetElderRay | 10000 | 839.93 μs | 14.132 μs | 7.391 μs |      - | 314.31 KB |
