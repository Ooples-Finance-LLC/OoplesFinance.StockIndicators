```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Gen2    | Allocated  | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|-----------:|-----------:|------:|--------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetElderRay** | **1000**  |    **93.72 μs** |   **1.597 μs** |   **0.835 μs** |  **0.94** |    **0.02** |       **-** |       **-** |       **-** |    **80.6 KB** |        **0.32** |
| BuilderLatestOnly | Skender.GetElderRay | 1000  |    88.82 μs |   1.561 μs |   0.929 μs |  0.89 |    0.02 |       - |       - |       - |      33 KB |        0.13 |
| NativeSingle      | Skender.GetElderRay | 1000  |    99.52 μs |   2.731 μs |   1.807 μs |  1.00 |    0.02 |  2.9297 |       - |       - |  251.06 KB |        1.00 |
| NativeParallel    | Skender.GetElderRay | 1000  |   175.71 μs |  14.459 μs |   9.564 μs |  1.77 |    0.10 |  7.8125 |  3.9063 |       - |  637.18 KB |        2.54 |
|                   |                     |       |             |            |            |       |         |         |         |         |            |             |
| **BuilderFull**       | **Skender.GetElderRay** | **10000** |   **936.33 μs** |  **35.333 μs** |  **21.026 μs** |  **0.67** |    **0.04** |  **7.8125** |       **-** |       **-** |   **784.1 KB** |        **0.31** |
| BuilderLatestOnly | Skender.GetElderRay | 10000 |   804.40 μs |  29.014 μs |  17.266 μs |  0.58 |    0.03 |       - |       - |       - |  314.31 KB |        0.13 |
| NativeSingle      | Skender.GetElderRay | 10000 | 1,393.26 μs | 113.313 μs |  74.950 μs |  1.00 |    0.07 | 46.8750 | 46.8750 | 46.8750 | 2501.47 KB |        1.00 |
| NativeParallel    | Skender.GetElderRay | 10000 | 2,191.00 μs | 171.852 μs | 113.669 μs |  1.58 |    0.11 | 78.1250 | 78.1250 | 78.1250 | 6333.21 KB |        2.53 |
