```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean      | Error     | StdDev   | Gen0   | Allocated |
|------------------ |-------------------- |------ |----------:|----------:|---------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetElderRay** | **1000**  |  **97.05 μs** |  **0.489 μs** | **0.256 μs** |      **-** |   **80.6 KB** |
| BuilderLatestOnly | Skender.GetElderRay | 1000  |  92.01 μs |  0.702 μs | 0.418 μs |      - |     33 KB |
| **BuilderFull**       | **Skender.GetElderRay** | **10000** | **946.66 μs** | **11.484 μs** | **6.834 μs** | **7.8125** | **784.13 KB** |
| BuilderLatestOnly | Skender.GetElderRay | 10000 | 887.23 μs |  4.815 μs | 2.865 μs |      - |  314.3 KB |
