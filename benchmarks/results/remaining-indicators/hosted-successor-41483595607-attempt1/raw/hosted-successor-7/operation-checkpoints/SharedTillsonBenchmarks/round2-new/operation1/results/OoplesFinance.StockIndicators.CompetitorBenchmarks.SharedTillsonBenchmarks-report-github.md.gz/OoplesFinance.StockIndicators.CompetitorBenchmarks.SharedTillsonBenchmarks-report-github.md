```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.T3** | **1000**  |   **165.661 μs** | **18.1796 μs** | **12.0247 μs** | **44.53** |    **3.26** |  **3.9063** |      **-** |  **65.18 KB** |        **9.34** |
| BuilderLatestOnly | TaLib.Functions.T3 | 1000  |   143.570 μs |  1.1015 μs |  0.6555 μs | 38.59 |    0.92 |  0.9766 |      - |  17.57 KB |        2.52 |
| NativeSingle      | TaLib.Functions.T3 | 1000  |     3.723 μs |  0.1414 μs |  0.0936 μs |  1.00 |    0.03 |  0.3967 |      - |   6.98 KB |        1.00 |
| NativeParallel    | TaLib.Functions.T3 | 1000  |     7.965 μs |  0.3178 μs |  0.1891 μs |  2.14 |    0.07 |  1.8311 | 0.0610 |  24.66 KB |        3.53 |
|                   |                    |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.T3** | **10000** | **1,462.482 μs** |  **9.0368 μs** |  **5.3776 μs** | **38.79** |    **0.18** | **31.2500** | **7.8125** | **628.09 KB** |        **8.13** |
| BuilderLatestOnly | TaLib.Functions.T3 | 10000 | 1,426.527 μs |  3.3316 μs |  1.9826 μs | 37.84 |    0.12 |  7.8125 |      - | 158.26 KB |        2.05 |
| NativeSingle      | TaLib.Functions.T3 | 10000 |    37.700 μs |  0.2225 μs |  0.1164 μs |  1.00 |    0.00 |  4.6387 |      - |  77.29 KB |        1.00 |
| NativeParallel    | TaLib.Functions.T3 | 10000 |    76.234 μs |  4.5457 μs |  3.0067 μs |  2.02 |    0.08 | 17.5781 | 4.8828 | 270.75 KB |        3.50 |
