```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation    | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Gen2   | Allocated  | Alloc Ratio |
|------------------ |------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|--------:|-------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.T3** | **1000**  |   **167.25 μs** |  **3.805 μs** |  **2.517 μs** |  **5.73** |    **0.10** |  **3.9063** |       **-** |      **-** |   **65.18 KB** |        **1.34** |
| BuilderLatestOnly | QuanTAlib.T3 | 1000  |   162.84 μs |  0.891 μs |  0.589 μs |  5.58 |    0.06 |  0.9766 |       - |      - |   17.57 KB |        0.36 |
| NativeSingle      | QuanTAlib.T3 | 1000  |    29.18 μs |  0.649 μs |  0.339 μs |  1.00 |    0.02 |  2.9297 |  0.2441 | 0.2441 |   48.69 KB |        1.00 |
| NativeParallel    | QuanTAlib.T3 | 1000  |    70.37 μs |  2.468 μs |  1.632 μs |  2.41 |    0.06 |  7.3242 |  1.4648 | 0.9766 |  112.86 KB |        2.32 |
|                   |              |       |             |           |           |       |         |         |         |        |            |             |
| **BuilderFull**       | **QuanTAlib.T3** | **10000** | **1,487.96 μs** |  **9.630 μs** |  **6.370 μs** |  **5.71** |    **0.09** | **31.2500** |  **7.8125** |      **-** |  **628.09 KB** |        **1.33** |
| BuilderLatestOnly | QuanTAlib.T3 | 10000 | 1,491.50 μs |  8.605 μs |  5.120 μs |  5.72 |    0.09 |  7.8125 |       - |      - |  158.26 KB |        0.34 |
| NativeSingle      | QuanTAlib.T3 | 10000 |   260.78 μs |  8.212 μs |  4.295 μs |  1.00 |    0.02 | 27.3438 |  3.9063 |      - |  470.58 KB |        1.00 |
| NativeParallel    | QuanTAlib.T3 | 10000 |   341.32 μs | 24.424 μs | 16.155 μs |  1.31 |    0.06 | 64.4531 | 11.7188 |      - | 1062.08 KB |        2.26 |
