```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib.Functions.T3** | **1000**  |   **149.1 μs** |  **1.14 μs** |  **0.68 μs** |  **3.9063** |      **-** |  **65.18 KB** |
| BuilderLatestOnly | TaLib.Functions.T3 | 1000  |   144.9 μs |  1.51 μs |  0.90 μs |  0.9766 |      - |  17.57 KB |
| **BuilderFull**       | **TaLib.Functions.T3** | **10000** | **1,487.4 μs** | **10.95 μs** |  **5.73 μs** | **31.2500** | **7.8125** | **628.08 KB** |
| BuilderLatestOnly | TaLib.Functions.T3 | 10000 | 1,455.8 μs | 46.39 μs | 27.61 μs |  7.8125 |      - | 158.25 KB |
