```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation     | Count | Mean       | Error    | StdDev  | Gen0    | Gen1   | Allocated |
|------------------ |-------------- |------ |-----------:|---------:|--------:|--------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetT3** | **1000**  |   **158.0 μs** |  **1.87 μs** | **1.11 μs** |       **-** |      **-** |  **65.18 KB** |
| BuilderLatestOnly | Skender.GetT3 | 1000  |   151.2 μs |  0.53 μs | 0.31 μs |  0.9766 |      - |  17.57 KB |
| **BuilderFull**       | **Skender.GetT3** | **10000** | **1,470.9 μs** | **14.01 μs** | **8.34 μs** | **31.2500** | **7.8125** | **628.09 KB** |
| BuilderLatestOnly | Skender.GetT3 | 10000 | 1,490.9 μs |  8.45 μs | 5.03 μs |  7.8125 |      - | 158.26 KB |
