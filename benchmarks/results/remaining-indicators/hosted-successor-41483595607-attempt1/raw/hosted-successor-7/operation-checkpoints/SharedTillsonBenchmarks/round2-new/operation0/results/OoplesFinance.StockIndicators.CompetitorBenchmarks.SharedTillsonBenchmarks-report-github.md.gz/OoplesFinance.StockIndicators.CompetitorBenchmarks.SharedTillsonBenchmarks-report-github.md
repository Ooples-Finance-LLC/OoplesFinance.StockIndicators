```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation     | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |-------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetT3** | **1000**  |   **155.41 μs** |   **2.092 μs** |   **1.245 μs** |  **3.56** |    **0.05** |   **3.9063** |        **-** |        **-** |   **65.18 KB** |        **0.72** |
| BuilderLatestOnly | Skender.GetT3 | 1000  |   155.25 μs |   1.908 μs |   0.998 μs |  3.55 |    0.05 |   0.9766 |        - |        - |   17.57 KB |        0.19 |
| NativeSingle      | Skender.GetT3 | 1000  |    43.72 μs |   1.055 μs |   0.552 μs |  1.00 |    0.02 |   5.3711 |   0.7324 |        - |   90.24 KB |        1.00 |
| NativeParallel    | Skender.GetT3 | 1000  |    92.78 μs |   4.848 μs |   3.206 μs |  2.12 |    0.07 |  15.6250 |   3.4180 |        - |  234.43 KB |        2.60 |
|                   |               |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetT3** | **10000** | **1,506.18 μs** |  **18.777 μs** |  **12.420 μs** |  **2.37** |    **0.10** |  **31.2500** |   **7.8125** |        **-** |  **628.09 KB** |        **0.70** |
| BuilderLatestOnly | Skender.GetT3 | 10000 | 1,471.42 μs |   7.909 μs |   4.137 μs |  2.31 |    0.10 |   7.8125 |        - |        - |  158.26 KB |        0.18 |
| NativeSingle      | Skender.GetT3 | 10000 |   637.61 μs |  43.004 μs |  28.444 μs |  1.00 |    0.06 | 117.1875 |  89.8438 |  82.0313 |  900.16 KB |        1.00 |
| NativeParallel    | Skender.GetT3 | 10000 | 1,465.62 μs | 239.661 μs | 158.521 μs |  2.30 |    0.26 | 265.6250 | 203.1250 | 156.2500 | 2328.92 KB |        2.59 |
