```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation    | Count | Mean       | Error    | StdDev  | Gen0    | Gen1   | Allocated |
|------------------ |------------- |------ |-----------:|---------:|--------:|--------:|-------:|----------:|
| **BuilderFull**       | **QuanTAlib.T3** | **1000**  |   **161.0 μs** |  **1.59 μs** | **0.95 μs** |  **3.9063** |      **-** |  **65.18 KB** |
| BuilderLatestOnly | QuanTAlib.T3 | 1000  |   160.7 μs |  1.63 μs | 0.85 μs |  0.9766 |      - |  17.57 KB |
| **BuilderFull**       | **QuanTAlib.T3** | **10000** | **1,489.0 μs** |  **6.19 μs** | **3.24 μs** | **31.2500** | **7.8125** | **628.08 KB** |
| BuilderLatestOnly | QuanTAlib.T3 | 10000 | 1,507.3 μs | 16.25 μs | 9.67 μs |  7.8125 |      - | 158.26 KB |
