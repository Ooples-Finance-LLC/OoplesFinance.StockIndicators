```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **661.6 μs** |   **9.58 μs** |   **5.70 μs** |       **-** |  **69.39 KB** |
| BuilderLatestOnly | 1000  | Beta      |   415.5 μs |  73.78 μs |  43.91 μs |       - |  21.67 KB |
| **BuilderFull**       | **10000** | **Beta**      | **5,946.0 μs** | **654.77 μs** | **433.09 μs** | **31.2500** | **632.38 KB** |
| BuilderLatestOnly | 10000 | Beta      | 4,067.8 μs | 487.70 μs | 322.58 μs |       - | 162.51 KB |
