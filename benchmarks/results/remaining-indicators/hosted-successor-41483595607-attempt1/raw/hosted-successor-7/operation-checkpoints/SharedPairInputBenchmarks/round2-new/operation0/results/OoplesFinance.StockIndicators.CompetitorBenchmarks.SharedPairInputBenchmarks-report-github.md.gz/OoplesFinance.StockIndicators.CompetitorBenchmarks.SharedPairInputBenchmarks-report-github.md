```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean         | Error       | StdDev      | Ratio  | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-------------:|------------:|------------:|-------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Beta**      | **1,027.616 μs** | **149.4155 μs** |  **98.8291 μs** | **132.65** |   **12.18** |       **-** |      **-** |  **69.36 KB** |        **9.00** |
| BuilderLatestOnly | 1000  | Beta      |   510.412 μs |  76.2282 μs |  50.4202 μs |  65.89 |    6.22 |       - |      - |  21.71 KB |        2.81 |
| NativeSingle      | 1000  | Beta      |     7.747 μs |   0.0361 μs |   0.0189 μs |   1.00 |    0.00 |  0.4272 |      - |   7.71 KB |        1.00 |
| NativeParallel    | 1000  | Beta      |     5.913 μs |   0.4008 μs |   0.2651 μs |   0.76 |    0.03 |  0.4883 |      - |   7.98 KB |        1.03 |
|                   |       |           |              |             |             |        |         |         |        |           |             |
| **BuilderFull**       | **10000** | **Beta**      | **4,710.786 μs** | **416.3273 μs** | **275.3747 μs** |  **62.96** |    **3.52** | **31.2500** |      **-** | **632.37 KB** |        **8.10** |
| BuilderLatestOnly | 10000 | Beta      | 4,773.161 μs | 497.1295 μs | 328.8204 μs |  63.79 |    4.20 |       - |      - | 162.29 KB |        2.08 |
| NativeSingle      | 10000 | Beta      |    74.823 μs |   0.4049 μs |   0.2118 μs |   1.00 |    0.00 |  4.3945 | 0.4883 |  78.03 KB |        1.00 |
| NativeParallel    | 10000 | Beta      |    53.312 μs |   3.7627 μs |   2.4888 μs |   0.71 |    0.03 |  4.3945 | 0.4883 |  78.29 KB |        1.00 |
