```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **522.1 μs** |  **12.03 μs** |   **7.96 μs** |       **-** |  **69.39 KB** |
| BuilderLatestOnly | 1000  | Beta      |   438.0 μs |  57.99 μs |  38.36 μs |       - |  21.67 KB |
| **BuilderFull**       | **10000** | **Beta**      | **4,195.9 μs** | **650.95 μs** | **430.56 μs** | **31.2500** | **632.37 KB** |
| BuilderLatestOnly | 10000 | Beta      | 4,203.2 μs | 540.99 μs | 357.83 μs |       - | 162.53 KB |
