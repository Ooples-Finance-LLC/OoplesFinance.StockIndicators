```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |----------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Fwma** | **1000**  |  **73.43 μs** |  **2.929 μs** |  **1.532 μs** |  **0.92** |    **0.02** |   **1.9531** |       **-** |   **60.35 KB** |        **0.24** |
| BuilderLatestOnly | QuanTAlib.Fwma | 1000  |  72.84 μs |  3.516 μs |  2.326 μs |  0.91 |    0.03 |   0.4883 |       - |   12.46 KB |        0.05 |
| NativeSingle      | QuanTAlib.Fwma | 1000  |  80.05 μs |  0.651 μs |  0.341 μs |  1.00 |    0.01 |  15.1367 |  0.4883 |   254.5 KB |        1.00 |
| NativeParallel    | QuanTAlib.Fwma | 1000  |  67.88 μs |  3.881 μs |  2.567 μs |  0.85 |    0.03 |  16.1133 |  0.4883 |   262.7 KB |        1.03 |
|                   |                |       |           |           |           |       |         |          |         |            |             |
| **BuilderFull**       | **QuanTAlib.Fwma** | **10000** | **429.02 μs** | **45.486 μs** | **30.086 μs** |  **0.54** |    **0.04** |  **31.2500** | **11.7188** |  **552.91 KB** |        **0.22** |
| BuilderLatestOnly | QuanTAlib.Fwma | 10000 | 415.59 μs | 49.740 μs | 32.900 μs |  0.53 |    0.04 |   3.9063 |       - |   82.81 KB |        0.03 |
| NativeSingle      | QuanTAlib.Fwma | 10000 | 791.37 μs | 12.574 μs |  6.576 μs |  1.00 |    0.01 | 156.2500 | 31.2500 | 2564.33 KB |        1.00 |
| NativeParallel    | QuanTAlib.Fwma | 10000 | 458.43 μs | 25.810 μs | 17.072 μs |  0.58 |    0.02 | 156.2500 | 31.2500 | 2572.67 KB |        1.00 |
