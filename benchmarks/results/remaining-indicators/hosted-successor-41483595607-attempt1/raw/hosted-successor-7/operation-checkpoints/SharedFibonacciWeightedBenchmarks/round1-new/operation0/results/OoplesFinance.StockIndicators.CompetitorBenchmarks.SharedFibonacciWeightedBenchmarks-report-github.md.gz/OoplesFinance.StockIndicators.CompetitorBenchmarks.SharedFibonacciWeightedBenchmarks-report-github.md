```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Fwma** | **1000**  |  **76.81 μs** |  **4.042 μs** |  **2.674 μs** |  **1.9531** |       **-** |  **60.35 KB** |
| BuilderLatestOnly | QuanTAlib.Fwma | 1000  |  72.30 μs |  2.122 μs |  1.404 μs |  0.4883 |       - |  12.46 KB |
| **BuilderFull**       | **QuanTAlib.Fwma** | **10000** | **409.59 μs** | **45.373 μs** | **30.012 μs** | **31.2500** | **11.7188** | **552.91 KB** |
| BuilderLatestOnly | QuanTAlib.Fwma | 10000 | 430.00 μs | 57.035 μs | 37.725 μs |  3.9063 |       - |  82.79 KB |
