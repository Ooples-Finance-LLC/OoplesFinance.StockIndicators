```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **4.301 ms** | **3.5004 ms** | **2.3153 ms** |  **84.97 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1.846 ms | 0.0086 ms | 0.0051 ms |  37.34 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **19.669 ms** | **0.0878 ms** | **0.0459 ms** | **789.68 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 19.108 ms | 0.7185 ms | 0.4276 ms | 319.87 KB |
