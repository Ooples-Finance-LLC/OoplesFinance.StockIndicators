```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **2.853 ms** | **0.9963 ms** | **0.6590 ms** |  **84.89 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1.965 ms | 0.0160 ms | 0.0095 ms |  37.33 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **20.250 ms** | **0.1689 ms** | **0.0883 ms** | **789.91 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 20.076 ms | 0.0822 ms | 0.0544 ms |  320.1 KB |
