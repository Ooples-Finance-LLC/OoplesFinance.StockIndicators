```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **2.870 ms** | **0.4103 ms** | **0.2442 ms** |  **69.08 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1.866 ms | 0.0220 ms | 0.0131 ms |  21.45 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **19.244 ms** | **0.0866 ms** | **0.0453 ms** | **632.36 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 19.154 ms | 0.0508 ms | 0.0266 ms | 163.31 KB |
