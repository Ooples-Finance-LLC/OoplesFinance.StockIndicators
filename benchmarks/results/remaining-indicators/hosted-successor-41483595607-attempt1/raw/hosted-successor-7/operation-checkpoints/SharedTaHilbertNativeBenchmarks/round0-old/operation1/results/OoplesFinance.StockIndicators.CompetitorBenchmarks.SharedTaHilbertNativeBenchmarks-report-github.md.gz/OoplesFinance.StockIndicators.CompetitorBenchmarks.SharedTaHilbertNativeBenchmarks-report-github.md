```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **2.946 ms** | **0.3422 ms** | **0.2036 ms** |  **84.97 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1.950 ms | 0.0304 ms | 0.0181 ms |  37.32 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **20.834 ms** | **1.4890 ms** | **0.9849 ms** | **789.97 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 22.240 ms | 2.3398 ms | 1.5477 ms | 320.15 KB |
