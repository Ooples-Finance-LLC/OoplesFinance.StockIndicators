```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **2.906 ms** | **1.0956 ms** | **0.7247 ms** |  **69.05 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  2.076 ms | 0.0123 ms | 0.0081 ms |  21.44 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **20.674 ms** | **0.1027 ms** | **0.0537 ms** |  **633.4 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 20.965 ms | 0.1587 ms | 0.0944 ms | 163.64 KB |
