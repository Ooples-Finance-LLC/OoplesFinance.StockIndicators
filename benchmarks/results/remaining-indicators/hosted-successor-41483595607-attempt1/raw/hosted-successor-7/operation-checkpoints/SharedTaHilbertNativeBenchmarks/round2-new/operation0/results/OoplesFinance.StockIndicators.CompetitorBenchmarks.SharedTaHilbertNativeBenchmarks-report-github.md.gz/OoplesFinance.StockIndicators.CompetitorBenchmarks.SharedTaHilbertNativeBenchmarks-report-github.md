```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **1,944.4 μs** |   **8.87 μs** |   **5.28 μs** |  **3.76** |    **0.01** |  **69.04 KB** |        **8.23** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1,915.9 μs |   6.30 μs |   3.29 μs |  3.70 |    0.01 |  21.45 KB |        2.56 |
| NativeSingle      | TaLib(...)Phase [25] | 1000  |    517.2 μs |   0.68 μs |   0.35 μs |  1.00 |    0.00 |   8.39 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 1000  |    681.6 μs |  26.23 μs |  13.72 μs |  1.32 |    0.03 |  30.21 KB |        3.60 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **19,789.3 μs** | **178.09 μs** |  **93.15 μs** |  **3.52** |    **0.02** | **633.11 KB** |        **8.02** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 19,833.9 μs | 231.59 μs | 137.82 μs |  3.53 |    0.02 |  163.3 KB |        2.07 |
| NativeSingle      | TaLib(...)Phase [25] | 10000 |  5,618.5 μs |  19.55 μs |  12.93 μs |  1.00 |    0.00 |  78.91 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 10000 |  7,074.2 μs |  86.99 μs |  45.50 μs |  1.26 |    0.01 | 276.86 KB |        3.51 |
