```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev   | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|---------:|------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **1,948.6 μs** |  **28.29 μs** | **14.80 μs** |  **3.58** |    **0.03** |      **-** |  **84.93 KB** |        **5.40** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1,919.8 μs |   8.74 μs |  5.20 μs |  3.53 |    0.02 |      - |  37.34 KB |        2.37 |
| NativeSingle      | TaLib(...)tSine [22] | 1000  |    544.1 μs |   4.44 μs |  2.94 μs |  1.00 |    0.01 |      - |  15.74 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 1000  |    731.4 μs |  45.00 μs | 29.76 μs |  1.34 |    0.05 | 3.9063 |  55.96 KB |        3.55 |
|                   |                      |       |             |           |          |       |         |        |           |             |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **19,746.1 μs** | **126.54 μs** | **66.19 μs** |  **3.36** |    **0.01** |      **-** | **789.61 KB** |        **5.05** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 19,811.7 μs | 118.54 μs | 70.54 μs |  3.37 |    0.01 |      - | 319.97 KB |        2.04 |
| NativeSingle      | TaLib(...)tSine [22] | 10000 |  5,880.2 μs |  18.49 μs |  9.67 μs |  1.00 |    0.00 |      - | 156.47 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 10000 |  7,376.3 μs |  37.40 μs | 19.56 μs |  1.25 |    0.00 |      - | 548.72 KB |        3.51 |
