```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | Allocated | Alloc Ratio |
|------- |------ |--------------------- |-----------:|---------:|---------:|------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)nusDI [23]** |   **352.9 μs** |  **3.92 μs** |  **2.33 μs** |  **1.00** | **105.67 KB** |        **1.00** |
|        |       |                      |            |          |          |       |           |             |
| **Ooples** | **10000** | **TaLib(...)nusDI [23]** | **3,406.4 μs** | **58.19 μs** | **34.63 μs** |  **1.00** | **1036.4 KB** |        **1.00** |
