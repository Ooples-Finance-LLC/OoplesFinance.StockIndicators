```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDM [22]** |   **229.22 μs** |  **6.126 μs** |  **3.204 μs** |  **1.00** |    **0.02** |  **105.67 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDM [22] |    17.36 μs |  1.147 μs |  0.600 μs |  0.08 |    0.00 |   40.55 KB |        0.38 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDM [22]** | **2,100.86 μs** | **19.073 μs** | **12.616 μs** |  **1.00** |    **0.01** | **1035.74 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDM [22] |   161.71 μs | 17.840 μs | 10.617 μs |  0.08 |    0.00 |  330.91 KB |        0.32 |
