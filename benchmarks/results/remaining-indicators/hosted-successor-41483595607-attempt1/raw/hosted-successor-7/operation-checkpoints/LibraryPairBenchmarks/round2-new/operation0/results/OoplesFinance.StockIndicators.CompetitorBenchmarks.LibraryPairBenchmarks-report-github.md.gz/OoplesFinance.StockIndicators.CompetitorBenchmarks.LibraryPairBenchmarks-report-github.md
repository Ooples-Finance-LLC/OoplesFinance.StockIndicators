```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Macd** |   **506.06 μs** | **25.360 μs** | **15.091 μs** |  **1.00** |    **0.04** |  **203.15 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Macd |    25.52 μs |  1.796 μs |  1.069 μs |  0.05 |    0.00 |  120.66 KB |        0.59 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Macd** | **4,864.10 μs** | **50.397 μs** | **26.358 μs** |  **1.00** |    **0.01** | **1995.53 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Macd |   221.99 μs | 19.468 μs | 11.585 μs |  0.05 |    0.00 | 1131.73 KB |        0.57 |
