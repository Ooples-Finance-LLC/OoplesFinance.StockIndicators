```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDI [22]** |   **360.63 μs** | **23.991 μs** | **15.869 μs** |  **1.00** |    **0.06** |  **105.67 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDI [22] |    18.27 μs |  3.203 μs |  1.906 μs |  0.05 |    0.01 |    40.6 KB |        0.38 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDI [22]** | **3,294.24 μs** | **35.941 μs** | **18.798 μs** |  **1.00** |    **0.01** | **1036.73 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDI [22] |   165.75 μs |  9.771 μs |  5.110 μs |  0.05 |    0.00 |  330.92 KB |        0.32 |
