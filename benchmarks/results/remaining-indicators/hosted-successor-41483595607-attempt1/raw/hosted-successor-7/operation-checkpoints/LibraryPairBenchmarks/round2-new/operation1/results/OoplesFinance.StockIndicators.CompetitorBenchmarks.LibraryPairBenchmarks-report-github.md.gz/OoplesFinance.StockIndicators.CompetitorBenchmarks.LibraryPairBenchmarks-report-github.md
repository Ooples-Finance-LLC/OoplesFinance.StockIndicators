```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error        | StdDev       | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-------------:|-------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)cdExt [23]** |   **780.11 μs** |   **183.743 μs** |   **109.343 μs** |  **1.02** |    **0.21** |  **752.06 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)cdExt [23] |    21.80 μs |     0.468 μs |     0.245 μs |  0.03 |    0.00 |  121.54 KB |        0.16 |
|            |       |                      |             |              |              |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)cdExt [23]** | **6,134.86 μs** | **1,773.527 μs** | **1,173.078 μs** |  **1.03** |    **0.26** | **7316.63 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)cdExt [23] |   183.88 μs |     8.222 μs |     4.893 μs |  0.03 |    0.01 | 1132.61 KB |        0.15 |
