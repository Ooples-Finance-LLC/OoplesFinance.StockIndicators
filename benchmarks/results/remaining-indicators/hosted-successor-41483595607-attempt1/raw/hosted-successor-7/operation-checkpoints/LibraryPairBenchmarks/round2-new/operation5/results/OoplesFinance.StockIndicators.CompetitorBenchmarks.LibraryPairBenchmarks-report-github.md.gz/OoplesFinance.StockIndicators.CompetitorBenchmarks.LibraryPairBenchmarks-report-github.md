```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDM [23]** |   **237.53 μs** | **19.652 μs** | **12.999 μs** |  **1.00** |    **0.07** |  **105.67 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDM [23] |    20.33 μs |  6.139 μs |  3.653 μs |  0.09 |    0.02 |   40.88 KB |        0.39 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDM [23]** | **2,012.48 μs** | **21.972 μs** | **13.075 μs** |  **1.00** |    **0.01** | **1036.68 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDM [23] |   167.42 μs |  4.924 μs |  2.930 μs |  0.08 |    0.00 |  330.59 KB |        0.32 |
