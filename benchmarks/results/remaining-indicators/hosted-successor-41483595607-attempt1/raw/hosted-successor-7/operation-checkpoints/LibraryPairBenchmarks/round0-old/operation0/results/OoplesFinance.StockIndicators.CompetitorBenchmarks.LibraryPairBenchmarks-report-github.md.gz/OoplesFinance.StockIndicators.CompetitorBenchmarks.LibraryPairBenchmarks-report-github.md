```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Macd** |   **632.3 μs** | **115.39 μs** | **76.32 μs** |  **1.01** |    **0.17** |  **203.15 KB** |        **1.00** |
|        |       |                      |            |           |          |       |         |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Macd** | **4,848.8 μs** |  **94.68 μs** | **56.34 μs** |  **1.00** |    **0.02** | **1995.81 KB** |        **1.00** |
