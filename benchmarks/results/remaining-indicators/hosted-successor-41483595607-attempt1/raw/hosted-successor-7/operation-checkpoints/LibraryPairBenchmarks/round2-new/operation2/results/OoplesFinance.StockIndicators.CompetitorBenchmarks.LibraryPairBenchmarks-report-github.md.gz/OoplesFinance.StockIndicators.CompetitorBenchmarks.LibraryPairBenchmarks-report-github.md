```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)cdFix [23]** |   **512.97 μs** | **24.841 μs** | **16.431 μs** |  **1.00** |    **0.04** |  **203.18 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)cdFix [23] |    24.21 μs |  1.832 μs |  0.958 μs |  0.05 |    0.00 |  120.98 KB |        0.60 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)cdFix [23]** | **4,939.55 μs** | **24.918 μs** | **13.033 μs** |  **1.00** |    **0.00** | **1995.56 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)cdFix [23] |   235.06 μs | 37.661 μs | 19.697 μs |  0.05 |    0.00 | 1132.05 KB |        0.57 |
