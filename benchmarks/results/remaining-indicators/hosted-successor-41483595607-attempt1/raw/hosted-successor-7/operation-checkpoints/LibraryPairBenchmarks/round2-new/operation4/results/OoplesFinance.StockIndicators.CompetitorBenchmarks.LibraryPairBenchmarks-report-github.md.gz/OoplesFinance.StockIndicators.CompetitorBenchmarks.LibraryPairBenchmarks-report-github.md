```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDI [23]** |   **353.22 μs** |  **3.273 μs** |  **1.948 μs** |  **1.00** |  **105.67 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDI [23] |    13.75 μs |  0.596 μs |  0.312 μs |  0.04 |   40.27 KB |        0.38 |
|            |       |                      |             |           |           |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDI [23]** | **3,305.01 μs** | **23.009 μs** | **15.219 μs** |  **1.00** | **1036.68 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDI [23] |   135.32 μs |  5.423 μs |  2.836 μs |  0.04 |  330.64 KB |        0.32 |
