```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Mavp** |   **210.34 μs** | **19.546 μs** | **12.929 μs** |  **1.00** |    **0.08** |  **107.48 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Mavp |    46.51 μs |  0.711 μs |  0.372 μs |  0.22 |    0.01 |   60.48 KB |        0.56 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Mavp** | **1,195.68 μs** | **31.301 μs** | **18.627 μs** |  **1.00** |    **0.02** | **1038.45 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Mavp |   464.16 μs | 32.809 μs | 21.701 μs |  0.39 |    0.02 |   526.3 KB |        0.51 |
