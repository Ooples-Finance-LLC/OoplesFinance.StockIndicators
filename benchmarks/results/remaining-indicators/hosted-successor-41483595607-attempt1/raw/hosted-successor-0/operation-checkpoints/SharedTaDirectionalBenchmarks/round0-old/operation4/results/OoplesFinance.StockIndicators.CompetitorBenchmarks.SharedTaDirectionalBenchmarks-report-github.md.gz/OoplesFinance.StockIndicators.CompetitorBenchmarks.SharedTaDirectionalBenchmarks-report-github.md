```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **615.9 μs** |  **5.12 μs** |  **3.05 μs** |     **65 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   612.2 μs |  6.50 μs |  3.40 μs |  17.39 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **6,490.7 μs** | **78.58 μs** | **46.76 μs** | **628.35 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 6,310.5 μs | 56.45 μs | 37.34 μs | 158.55 KB |
