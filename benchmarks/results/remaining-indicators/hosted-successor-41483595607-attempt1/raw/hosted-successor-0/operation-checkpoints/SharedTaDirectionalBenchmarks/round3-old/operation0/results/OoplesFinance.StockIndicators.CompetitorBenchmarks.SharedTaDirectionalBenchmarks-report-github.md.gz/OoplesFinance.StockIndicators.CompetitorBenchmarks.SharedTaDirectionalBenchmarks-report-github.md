```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **179.5 μs** | **16.26 μs** | **10.75 μs** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   160.4 μs |  3.86 μs |  2.55 μs |  17.39 KB |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **1,681.9 μs** | **25.92 μs** | **15.43 μs** | **627.83 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 1,611.9 μs | 13.44 μs |  8.00 μs |  158.1 KB |
