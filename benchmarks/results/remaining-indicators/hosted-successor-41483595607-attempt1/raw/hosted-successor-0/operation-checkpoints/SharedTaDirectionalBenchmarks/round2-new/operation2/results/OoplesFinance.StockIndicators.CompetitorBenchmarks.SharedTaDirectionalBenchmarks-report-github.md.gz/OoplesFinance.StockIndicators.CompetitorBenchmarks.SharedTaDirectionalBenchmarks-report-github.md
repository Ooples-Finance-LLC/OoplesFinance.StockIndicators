```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **281.294 μs** |  **4.4502 μs** |  **2.3275 μs** | **32.80** |    **0.26** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   272.943 μs |  4.1672 μs |  2.4798 μs | 31.82 |    0.28 |      - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib(...)lusDI [22] | 1000  |     8.577 μs |  0.0240 μs |  0.0143 μs |  1.00 |    0.00 | 0.0610 |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 1000  |    13.812 μs |  0.3913 μs |  0.2329 μs |  1.61 |    0.03 | 0.3662 |  27.24 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **2,961.022 μs** | **79.7161 μs** | **47.4378 μs** | **29.60** |    **0.48** |      **-** |  **627.9 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,854.619 μs | 28.8671 μs | 15.0981 μs | 28.54 |    0.21 |      - | 158.11 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDI [22] | 10000 |   100.040 μs |  0.8695 μs |  0.5751 μs |  1.00 |    0.01 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 10000 |   171.757 μs | 10.9957 μs |  7.2730 μs |  1.72 |    0.07 | 2.9297 | 273.34 KB |        3.50 |
