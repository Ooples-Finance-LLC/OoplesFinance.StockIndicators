```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **172.75 μs** | **11.999 μs** |  **7.141 μs** | **16.95** |    **0.67** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   165.64 μs |  0.678 μs |  0.355 μs | 16.25 |    0.04 |      - |  17.39 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDM [23] | 1000  |    10.19 μs |  0.027 μs |  0.014 μs |  1.00 |    0.00 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 1000  |    16.69 μs |  0.439 μs |  0.290 μs |  1.64 |    0.03 | 0.3662 |  27.23 KB |        3.53 |
|                   |                      |       |             |           |           |       |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,755.80 μs** | **37.879 μs** | **19.811 μs** | **17.20** |    **0.19** |      **-** | **627.93 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 1,606.10 μs |  8.294 μs |  4.936 μs | 15.74 |    0.06 |      - | 158.13 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDM [23] | 10000 |   102.07 μs |  0.520 μs |  0.272 μs |  1.00 |    0.00 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 10000 |   164.66 μs |  7.856 μs |  5.196 μs |  1.61 |    0.05 | 2.9297 | 273.33 KB |        3.50 |
