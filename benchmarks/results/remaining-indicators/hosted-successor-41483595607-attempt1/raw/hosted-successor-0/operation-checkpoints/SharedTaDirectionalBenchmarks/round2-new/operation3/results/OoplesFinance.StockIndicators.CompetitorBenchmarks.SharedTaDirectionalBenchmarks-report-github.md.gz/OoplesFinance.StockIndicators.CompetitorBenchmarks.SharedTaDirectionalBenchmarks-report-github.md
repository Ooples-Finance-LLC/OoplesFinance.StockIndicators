```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **279.605 μs** |  **3.9667 μs** |  **2.3605 μs** | **32.56** |    **0.33** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   276.741 μs |  2.0068 μs |  1.1942 μs | 32.23 |    0.23 |      - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDI [23] | 1000  |     8.587 μs |  0.0912 μs |  0.0543 μs |  1.00 |    0.01 | 0.0610 |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 1000  |    13.430 μs |  0.5773 μs |  0.3819 μs |  1.56 |    0.04 | 0.3662 |  27.24 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **2,896.851 μs** | **35.3401 μs** | **21.0303 μs** | **32.95** |    **0.43** |      **-** | **627.95 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,820.440 μs | 20.8196 μs | 10.8890 μs | 32.08 |    0.37 |      - | 158.12 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDI [23] | 10000 |    87.939 μs |  1.5525 μs |  1.0268 μs |  1.00 |    0.02 | 0.4883 |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 10000 |   150.035 μs | 10.1024 μs |  6.6821 μs |  1.71 |    0.07 | 2.9297 | 273.34 KB |        3.50 |
