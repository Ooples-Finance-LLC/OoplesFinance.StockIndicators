```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0   | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|-------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **171.684 μs** |  **1.9769 μs** |  **1.0340 μs** | **17.26** |    **0.10** |      **-** |      **-** |  **64.97 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   160.212 μs |  1.0394 μs |  0.5436 μs | 16.11 |    0.06 |      - |      - |  17.39 KB |        2.25 |
| NativeSingle      | TaLib(...)lusDM [22] | 1000  |     9.947 μs |  0.0289 μs |  0.0172 μs |  1.00 |    0.00 | 0.0610 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 1000  |    17.011 μs |  0.6907 μs |  0.4110 μs |  1.71 |    0.04 | 0.3662 |      - |  27.23 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |        |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **1,749.321 μs** | **30.6138 μs** | **18.2178 μs** | **18.51** |    **0.18** |      **-** |      **-** | **627.92 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 1,601.697 μs | 10.3087 μs |  6.1345 μs | 16.95 |    0.06 |      - |      - | 158.13 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDM [22] | 10000 |    94.500 μs |  0.2082 μs |  0.1089 μs |  1.00 |    0.00 |      - |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 10000 |   151.975 μs |  8.4617 μs |  5.5969 μs |  1.61 |    0.06 | 2.9297 | 0.9766 | 273.33 KB |        3.50 |
