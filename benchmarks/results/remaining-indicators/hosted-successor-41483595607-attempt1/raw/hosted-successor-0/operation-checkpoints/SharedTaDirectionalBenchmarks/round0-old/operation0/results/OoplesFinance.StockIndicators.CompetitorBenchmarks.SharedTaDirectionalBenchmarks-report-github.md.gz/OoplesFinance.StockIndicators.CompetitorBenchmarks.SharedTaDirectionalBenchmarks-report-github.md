```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **186.6 μs** | **19.83 μs** | **11.80 μs** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   153.7 μs |  0.96 μs |  0.50 μs |  17.39 KB |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **1,614.9 μs** | **21.67 μs** | **12.90 μs** | **627.94 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 1,553.1 μs | 43.32 μs | 28.66 μs | 158.07 KB |
