```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|-----------:|----------:|------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **575.20 μs** |   **5.416 μs** |  **2.833 μs** | **45.82** |    **0.28** |      **-** |  **65.65 KB** |        **8.67** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   578.01 μs |   4.350 μs |  2.589 μs | 46.04 |    0.27 |      - |  18.06 KB |        2.39 |
| NativeSingle      | TaLib.Functions.Adx | 1000  |    12.55 μs |   0.089 μs |  0.053 μs |  1.00 |    0.01 |      - |   7.57 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 1000  |    24.88 μs |   2.437 μs |  1.612 μs |  1.98 |    0.12 | 0.2441 |  26.71 KB |        3.53 |
|                   |                     |       |             |            |           |       |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **6,005.35 μs** | **130.307 μs** | **86.190 μs** | **46.85** |    **0.78** |      **-** | **637.55 KB** |        **8.19** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 5,893.93 μs |  92.207 μs | 54.871 μs | 45.98 |    0.59 |      - | 167.75 KB |        2.15 |
| NativeSingle      | TaLib.Functions.Adx | 10000 |   128.20 μs |   2.158 μs |  1.284 μs |  1.00 |    0.01 |      - |  77.89 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 10000 |   195.32 μs |   2.850 μs |  1.491 μs |  1.52 |    0.02 | 1.9531 | 272.82 KB |        3.50 |
