```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **636.6 μs** | **12.77 μs** |  **8.45 μs** |     **65 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   622.2 μs |  3.56 μs |  1.86 μs |  17.42 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **6,701.9 μs** | **96.55 μs** | **57.45 μs** | **628.14 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 6,490.9 μs | 33.00 μs | 17.26 μs | 158.48 KB |
