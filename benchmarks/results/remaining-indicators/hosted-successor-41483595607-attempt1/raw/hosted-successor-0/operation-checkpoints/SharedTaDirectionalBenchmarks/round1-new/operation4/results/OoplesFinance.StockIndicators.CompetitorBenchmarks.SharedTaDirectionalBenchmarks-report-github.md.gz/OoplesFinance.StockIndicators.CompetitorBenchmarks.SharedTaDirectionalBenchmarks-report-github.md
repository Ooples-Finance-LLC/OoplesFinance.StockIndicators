```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **628.9 μs** | **11.81 μs** |  **7.03 μs** |     **65 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   617.0 μs | 16.19 μs | 10.71 μs |  17.39 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **6,464.8 μs** | **42.59 μs** | **25.35 μs** | **628.29 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 6,406.9 μs | 25.44 μs | 13.30 μs | 158.37 KB |
