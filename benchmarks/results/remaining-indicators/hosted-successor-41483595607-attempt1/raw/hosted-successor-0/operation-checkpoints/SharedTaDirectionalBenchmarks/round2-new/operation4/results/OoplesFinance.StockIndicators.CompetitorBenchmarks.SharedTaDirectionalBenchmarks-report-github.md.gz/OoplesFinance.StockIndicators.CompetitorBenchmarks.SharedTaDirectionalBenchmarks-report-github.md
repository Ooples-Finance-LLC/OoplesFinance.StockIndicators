```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |------------:|----------:|----------:|------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **645.55 μs** | **19.923 μs** | **11.856 μs** | **37.02** |    **0.67** |      **-** |  **65.05 KB** |        **8.43** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   625.05 μs |  9.307 μs |  5.539 μs | 35.85 |    0.35 |      - |  17.41 KB |        2.26 |
| NativeSingle      | TaLib.Functions.Dx | 1000  |    17.44 μs |  0.141 μs |  0.094 μs |  1.00 |    0.01 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 1000  |    26.54 μs |  2.564 μs |  1.696 μs |  1.52 |    0.09 | 0.2441 |  27.24 KB |        3.53 |
|                   |                    |       |             |           |           |       |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **6,706.04 μs** | **91.099 μs** | **47.647 μs** | **37.69** |    **0.27** |      **-** | **628.37 KB** |        **8.05** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 6,558.85 μs | 72.887 μs | 43.374 μs | 36.86 |    0.25 |      - | 158.46 KB |        2.03 |
| NativeSingle      | TaLib.Functions.Dx | 10000 |   177.92 μs |  0.802 μs |  0.530 μs |  1.00 |    0.00 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 10000 |   253.26 μs |  6.795 μs |  4.495 μs |  1.42 |    0.02 | 1.9531 | 273.35 KB |        3.50 |
