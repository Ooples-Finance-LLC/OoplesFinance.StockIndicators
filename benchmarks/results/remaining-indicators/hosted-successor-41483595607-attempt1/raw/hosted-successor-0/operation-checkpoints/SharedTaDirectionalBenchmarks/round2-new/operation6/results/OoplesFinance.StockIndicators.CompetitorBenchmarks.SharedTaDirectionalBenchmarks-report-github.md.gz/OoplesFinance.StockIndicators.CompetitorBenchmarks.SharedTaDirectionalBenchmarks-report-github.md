```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0   | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|-------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **582.65 μs** |  **6.518 μs** |  **3.409 μs** | **38.46** |    **0.27** |      **-** |      **-** |  **66.72 KB** |        **4.45** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   570.58 μs |  2.524 μs |  1.502 μs | 37.66 |    0.19 |      - |      - |  19.13 KB |        1.28 |
| NativeSingle      | TaLib.Functions.Adxr | 1000  |    15.15 μs |  0.120 μs |  0.072 μs |  1.00 |    0.01 | 0.1221 |      - |  14.99 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 1000  |    31.57 μs |  2.812 μs |  1.860 μs |  2.08 |    0.12 | 0.4883 |      - |  45.43 KB |        3.03 |
|                   |                      |       |             |           |           |       |         |        |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **6,153.00 μs** | **25.002 μs** | **13.077 μs** | **41.50** |    **0.30** |      **-** |      **-** |  **638.6 KB** |        **4.10** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 5,966.15 μs | 65.920 μs | 43.602 μs | 40.24 |    0.40 |      - |      - | 168.84 KB |        1.08 |
| NativeSingle      | TaLib.Functions.Adxr | 10000 |   148.27 μs |  1.630 μs |  1.078 μs |  1.00 |    0.01 | 0.9766 |      - | 155.62 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 10000 |   222.72 μs | 11.055 μs |  5.782 μs |  1.50 |    0.04 | 5.8594 | 1.9531 | 467.32 KB |        3.00 |
