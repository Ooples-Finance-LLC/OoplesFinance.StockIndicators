```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |-------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **592.2 μs** |   **5.75 μs** |   **3.01 μs** |  **65.65 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   570.8 μs |   7.71 μs |   4.59 μs |  18.06 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **6,063.9 μs** | **176.05 μs** | **116.45 μs** | **637.51 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 6,116.8 μs | 147.44 μs |  77.12 μs | 167.81 KB |
