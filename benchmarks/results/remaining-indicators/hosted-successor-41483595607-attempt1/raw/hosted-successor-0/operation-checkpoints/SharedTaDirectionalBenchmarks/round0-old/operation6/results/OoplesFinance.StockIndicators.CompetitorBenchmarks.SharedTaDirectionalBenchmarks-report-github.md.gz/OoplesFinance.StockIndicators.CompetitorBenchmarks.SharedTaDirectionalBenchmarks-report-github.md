```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **756.3 μs** | **104.34 μs** | **62.09 μs** |  **66.73 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   600.3 μs |  10.27 μs |  6.11 μs |  19.13 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **6,217.2 μs** | **106.54 μs** | **63.40 μs** | **638.45 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 6,242.2 μs |  50.35 μs | 26.33 μs | 168.87 KB |
