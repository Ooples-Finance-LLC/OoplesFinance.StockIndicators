```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **278.1 μs** |  **3.63 μs** |  **1.90 μs** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   270.4 μs |  3.17 μs |  2.09 μs |   17.4 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **2,896.8 μs** | **34.28 μs** | **20.40 μs** | **627.92 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,844.9 μs | 37.69 μs | 22.43 μs | 158.09 KB |
