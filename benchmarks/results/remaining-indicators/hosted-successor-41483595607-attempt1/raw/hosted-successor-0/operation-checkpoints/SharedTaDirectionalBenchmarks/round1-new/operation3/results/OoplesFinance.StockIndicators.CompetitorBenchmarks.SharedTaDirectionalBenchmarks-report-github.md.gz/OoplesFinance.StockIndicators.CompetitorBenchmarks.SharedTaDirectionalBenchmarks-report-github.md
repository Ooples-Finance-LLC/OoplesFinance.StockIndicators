```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **313.7 μs** |  **8.11 μs** |  **4.83 μs** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   288.5 μs |  2.26 μs |  1.35 μs |   17.4 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **3,028.7 μs** | **39.04 μs** | **25.82 μs** | **627.94 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,975.6 μs | 51.95 μs | 34.36 μs | 158.14 KB |
