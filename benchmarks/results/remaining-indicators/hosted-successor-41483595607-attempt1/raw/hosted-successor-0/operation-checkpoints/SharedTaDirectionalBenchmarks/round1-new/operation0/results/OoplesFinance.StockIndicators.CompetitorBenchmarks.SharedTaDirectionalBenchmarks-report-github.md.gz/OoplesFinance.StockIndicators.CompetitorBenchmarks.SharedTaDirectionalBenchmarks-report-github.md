```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **163.9 μs** |  **6.77 μs** |  **4.03 μs** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   154.2 μs |  3.53 μs |  2.10 μs |  17.39 KB |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **1,597.1 μs** |  **9.47 μs** |  **4.95 μs** |  **627.9 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 1,624.2 μs | 29.13 μs | 17.33 μs | 158.11 KB |
