```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **587.3 μs** | **14.41 μs** |  **9.53 μs** |  **65.64 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   579.9 μs | 13.10 μs |  7.80 μs |  18.06 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **6,010.3 μs** | **44.98 μs** | **23.53 μs** | **637.53 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 5,995.3 μs | 50.41 μs | 33.35 μs | 167.75 KB |
