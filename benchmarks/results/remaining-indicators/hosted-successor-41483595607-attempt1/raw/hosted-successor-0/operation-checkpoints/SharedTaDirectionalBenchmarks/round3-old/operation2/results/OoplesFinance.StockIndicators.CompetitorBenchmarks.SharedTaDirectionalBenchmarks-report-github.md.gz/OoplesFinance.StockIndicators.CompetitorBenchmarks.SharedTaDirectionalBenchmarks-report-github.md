```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **275.1 μs** |  **2.25 μs** |  **1.34 μs** |  **64.97 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   271.1 μs |  3.59 μs |  2.14 μs |   17.4 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **2,910.1 μs** | **79.63 μs** | **52.67 μs** | **627.88 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,821.0 μs | 22.42 μs | 13.34 μs | 158.08 KB |
