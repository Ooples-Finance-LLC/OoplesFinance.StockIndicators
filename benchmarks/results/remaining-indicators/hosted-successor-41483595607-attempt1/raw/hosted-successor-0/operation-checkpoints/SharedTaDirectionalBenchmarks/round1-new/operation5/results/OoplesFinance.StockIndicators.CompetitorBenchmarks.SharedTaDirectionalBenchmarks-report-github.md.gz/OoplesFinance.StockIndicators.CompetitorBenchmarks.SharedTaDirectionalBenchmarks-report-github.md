```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **560.6 μs** |  **2.65 μs** |  **1.39 μs** |  **65.64 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   563.4 μs |  7.46 μs |  3.90 μs |  18.03 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **5,810.4 μs** | **58.98 μs** | **30.85 μs** | **637.53 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 5,710.0 μs | 29.37 μs | 17.48 μs | 167.73 KB |
