```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **168.9 μs** | **17.18 μs** | **10.22 μs** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   157.5 μs |  1.47 μs |  0.97 μs |  17.39 KB |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,614.3 μs** | **19.02 μs** | **11.32 μs** | **627.93 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 1,584.1 μs | 11.81 μs |  7.03 μs | 158.14 KB |
