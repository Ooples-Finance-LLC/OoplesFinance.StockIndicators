```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **283.5 μs** |  **3.30 μs** |  **1.73 μs** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   275.5 μs |  3.12 μs |  1.86 μs |   17.4 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **2,881.1 μs** | **26.98 μs** | **16.06 μs** | **627.94 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,827.4 μs | 26.18 μs | 15.58 μs | 158.09 KB |
