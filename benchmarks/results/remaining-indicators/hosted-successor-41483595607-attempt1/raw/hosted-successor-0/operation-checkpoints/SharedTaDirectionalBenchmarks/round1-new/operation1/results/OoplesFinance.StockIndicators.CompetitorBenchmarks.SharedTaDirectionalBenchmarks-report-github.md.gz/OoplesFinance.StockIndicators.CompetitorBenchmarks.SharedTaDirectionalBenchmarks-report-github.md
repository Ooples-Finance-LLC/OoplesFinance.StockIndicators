```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **173.1 μs** | **10.46 μs** |  **6.22 μs** |  **65.04 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   164.0 μs |  2.21 μs |  1.32 μs |  17.39 KB |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,681.8 μs** | **32.21 μs** | **19.17 μs** | **627.91 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 1,513.3 μs | 15.45 μs |  9.19 μs | 158.05 KB |
