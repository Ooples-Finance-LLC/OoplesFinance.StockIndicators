```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev     | Ratio  | RatioSD | Gen0   | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|-----------:|-------:|--------:|-------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **469.188 μs** |  **13.8642 μs** |  **8.2504 μs** | **136.66** |    **2.39** |      **-** |      **-** |  **73.52 KB** |        **9.42** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   409.169 μs |   6.7712 μs |  4.4787 μs | 119.18 |    1.39 |      - |      - |  25.93 KB |        3.32 |
| NativeSingle      | TaLib(...)AdOsc [21] | 1000  |     3.433 μs |   0.0288 μs |  0.0191 μs |   1.00 |    0.01 | 0.0916 |      - |    7.8 KB |        1.00 |
| NativeParallel    | TaLib(...)AdOsc [21] | 1000  |     9.761 μs |   0.3475 μs |  0.2298 μs |   2.84 |    0.07 | 0.3662 |      - |  27.56 KB |        3.53 |
|                   |                      |       |              |             |            |        |         |        |        |           |             |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **4,183.037 μs** | **101.5892 μs** | **60.4541 μs** | **130.82** |    **3.71** |      **-** |      **-** | **706.91 KB** |        **9.05** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 4,125.706 μs |  59.3924 μs | 35.3435 μs | 129.03 |    3.37 |      - |      - | 237.06 KB |        3.03 |
| NativeSingle      | TaLib(...)AdOsc [21] | 10000 |    31.996 μs |   1.2834 μs |  0.8489 μs |   1.00 |    0.04 | 0.7324 |      - |  78.12 KB |        1.00 |
| NativeParallel    | TaLib(...)AdOsc [21] | 10000 |    77.221 μs |   5.8098 μs |  3.4573 μs |   2.42 |    0.12 | 3.4180 | 0.9766 | 273.66 KB |        3.50 |
