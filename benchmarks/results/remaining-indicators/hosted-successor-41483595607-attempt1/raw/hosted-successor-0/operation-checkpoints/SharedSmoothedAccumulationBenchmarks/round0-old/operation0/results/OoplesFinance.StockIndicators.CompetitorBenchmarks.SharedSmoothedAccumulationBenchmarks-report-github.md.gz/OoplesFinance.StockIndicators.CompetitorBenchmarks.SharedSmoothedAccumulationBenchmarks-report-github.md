```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **391.6 μs** |   **4.91 μs** |  **2.92 μs** |  **97.02 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   388.0 μs |  11.83 μs |  7.83 μs |  49.42 KB |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **3,962.9 μs** | **129.52 μs** | **77.07 μs** |  **941.3 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 3,909.7 μs |  39.37 μs | 20.59 μs | 471.53 KB |
