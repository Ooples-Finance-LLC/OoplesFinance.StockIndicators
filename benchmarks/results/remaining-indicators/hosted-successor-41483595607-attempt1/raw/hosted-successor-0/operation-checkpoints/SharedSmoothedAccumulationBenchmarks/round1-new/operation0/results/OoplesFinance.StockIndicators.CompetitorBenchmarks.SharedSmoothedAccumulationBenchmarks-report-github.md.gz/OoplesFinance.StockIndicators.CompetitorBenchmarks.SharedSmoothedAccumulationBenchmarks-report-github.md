```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **521.2 μs** |  **34.63 μs** | **20.61 μs** |  **97.03 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   446.4 μs |   1.28 μs |  0.67 μs |  49.44 KB |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **4,686.4 μs** | **140.93 μs** | **93.21 μs** | **941.31 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 4,564.6 μs |  70.38 μs | 41.88 μs | 471.51 KB |
