```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **368.7 μs** |  **3.93 μs** |  **2.34 μs** |  **73.57 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   363.1 μs |  8.70 μs |  5.75 μs |  25.91 KB |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **3,664.7 μs** | **25.63 μs** | **13.41 μs** | **706.82 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 3,596.0 μs | 76.25 μs | 50.44 μs | 237.08 KB |
