```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **522.3 μs** |  **20.11 μs** |  **11.96 μs** |  **4.95** |    **0.11** |        **-** |        **-** |       **-** |   **97.03 KB** |        **0.26** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   459.3 μs |   5.44 μs |   2.85 μs |  4.35 |    0.04 |        - |        - |       - |   49.44 KB |        0.13 |
| NativeSingle      | Skend(...)inOsc [21] | 1000  |   105.6 μs |   1.48 μs |   0.78 μs |  1.00 |    0.01 |   3.9063 |        - |       - |  379.71 KB |        1.00 |
| NativeParallel    | Skend(...)inOsc [21] | 1000  |   185.0 μs |   5.45 μs |   2.85 μs |  1.75 |    0.03 |  11.7188 |   5.8594 |       - |  958.69 KB |        2.52 |
|                   |                      |       |            |           |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **4,818.5 μs** | **158.56 μs** | **104.88 μs** |  **3.16** |    **0.11** |        **-** |        **-** |       **-** |  **941.35 KB** |        **0.25** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 4,715.8 μs | 118.17 μs |  78.16 μs |  3.09 |    0.10 |        - |        - |       - |  471.54 KB |        0.12 |
| NativeSingle      | Skend(...)inOsc [21] | 10000 | 1,528.0 μs |  66.28 μs |  43.84 μs |  1.00 |    0.04 |  46.8750 |  46.8750 | 46.8750 | 3790.28 KB |        1.00 |
| NativeParallel    | Skend(...)inOsc [21] | 10000 | 2,494.1 μs | 254.80 μs | 168.53 μs |  1.63 |    0.11 | 156.2500 | 140.6250 | 78.1250 |  9555.1 KB |        2.52 |
