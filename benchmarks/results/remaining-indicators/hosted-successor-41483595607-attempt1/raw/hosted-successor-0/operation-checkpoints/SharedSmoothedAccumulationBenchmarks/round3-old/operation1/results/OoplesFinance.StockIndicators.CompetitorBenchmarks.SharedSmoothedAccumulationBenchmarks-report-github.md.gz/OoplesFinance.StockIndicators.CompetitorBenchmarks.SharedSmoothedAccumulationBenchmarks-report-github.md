```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **520.7 μs** |  **4.11 μs** |  **2.45 μs** |  **73.57 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   358.0 μs |  2.65 μs |  1.39 μs |  25.93 KB |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **3,649.5 μs** | **27.45 μs** | **14.36 μs** | **706.86 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 3,570.2 μs | 58.40 μs | 34.75 μs | 237.09 KB |
