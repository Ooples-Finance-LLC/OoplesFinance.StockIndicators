```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **388.1 μs** |  **6.64 μs** |  **4.40 μs** |  **97.02 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   377.8 μs |  8.36 μs |  5.53 μs |  49.44 KB |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **3,879.0 μs** | **33.59 μs** | **17.57 μs** | **941.34 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 3,831.4 μs | 35.49 μs | 18.56 μs | 471.46 KB |
