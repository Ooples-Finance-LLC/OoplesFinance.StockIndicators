```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **427.3 μs** |   **5.20 μs** |   **2.72 μs** |  **73.51 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   410.3 μs |   5.29 μs |   2.77 μs |  25.93 KB |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **4,370.4 μs** | **194.24 μs** | **128.47 μs** | **706.91 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 4,106.4 μs |  21.57 μs |  11.28 μs | 237.04 KB |
