```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Allocated  |
|------------------ |------------------- |------ |-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetKeltner** | **1000**  |   **306.9 μs** |  **5.71 μs** |  **2.98 μs** |  **104.66 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 1000  |   296.2 μs |  3.46 μs |  2.06 μs |   57.06 KB |
| **BuilderFull**       | **Skender.GetKeltner** | **10000** | **3,276.2 μs** | **68.25 μs** | **45.14 μs** | **1019.26 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 10000 | 2,997.1 μs | 32.88 μs | 21.75 μs |  549.44 KB |
