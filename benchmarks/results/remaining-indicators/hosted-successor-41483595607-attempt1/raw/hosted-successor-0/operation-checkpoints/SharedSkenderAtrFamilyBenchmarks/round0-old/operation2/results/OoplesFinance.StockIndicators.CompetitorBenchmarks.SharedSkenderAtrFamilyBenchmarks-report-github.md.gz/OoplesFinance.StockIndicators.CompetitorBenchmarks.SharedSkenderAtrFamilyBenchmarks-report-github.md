```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Skend(...)Bands [21]** | **1000**  |   **289.3 μs** |  **11.71 μs** |   **6.13 μs** |  **97.43 KB** |
| BuilderLatestOnly | Skend(...)Bands [21] | 1000  |   283.3 μs |  29.25 μs |  19.35 μs |   49.8 KB |
| **BuilderFull**       | **Skend(...)Bands [21]** | **10000** | **3,082.8 μs** | **335.64 μs** | **222.00 μs** | **941.73 KB** |
| BuilderLatestOnly | Skend(...)Bands [21] | 10000 | 2,772.2 μs | 115.76 μs |  60.55 μs | 471.78 KB |
