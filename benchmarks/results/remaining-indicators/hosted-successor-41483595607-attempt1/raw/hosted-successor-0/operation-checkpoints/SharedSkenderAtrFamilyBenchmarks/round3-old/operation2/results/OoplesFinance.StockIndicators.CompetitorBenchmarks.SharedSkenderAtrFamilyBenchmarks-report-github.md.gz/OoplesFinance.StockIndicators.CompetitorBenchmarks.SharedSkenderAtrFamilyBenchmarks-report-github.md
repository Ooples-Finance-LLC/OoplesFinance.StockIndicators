```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skend(...)Bands [21]** | **1000**  |   **277.9 μs** | **11.92 μs** |  **6.23 μs** |  **97.39 KB** |
| BuilderLatestOnly | Skend(...)Bands [21] | 1000  |   270.9 μs |  2.70 μs |  1.60 μs |  49.79 KB |
| **BuilderFull**       | **Skend(...)Bands [21]** | **10000** | **2,926.0 μs** | **40.20 μs** | **21.03 μs** | **941.58 KB** |
| BuilderLatestOnly | Skend(...)Bands [21] | 10000 | 2,774.2 μs | 59.15 μs | 39.12 μs | 471.77 KB |
