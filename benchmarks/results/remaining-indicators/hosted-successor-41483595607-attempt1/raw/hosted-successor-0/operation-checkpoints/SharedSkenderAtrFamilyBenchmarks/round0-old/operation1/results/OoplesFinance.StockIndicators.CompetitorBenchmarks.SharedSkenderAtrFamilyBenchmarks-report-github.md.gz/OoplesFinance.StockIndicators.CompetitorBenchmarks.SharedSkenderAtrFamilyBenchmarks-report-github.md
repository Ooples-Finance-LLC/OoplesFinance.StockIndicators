```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Allocated  |
|------------------ |------------------- |------ |-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetKeltner** | **1000**  |   **311.7 μs** |  **7.88 μs** |  **4.69 μs** |  **104.71 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 1000  |   294.2 μs |  1.88 μs |  1.12 μs |   57.06 KB |
| **BuilderFull**       | **Skender.GetKeltner** | **10000** | **3,072.2 μs** | **45.94 μs** | **24.03 μs** | **1019.27 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 10000 | 3,045.3 μs | 38.87 μs | 23.13 μs |  549.49 KB |
