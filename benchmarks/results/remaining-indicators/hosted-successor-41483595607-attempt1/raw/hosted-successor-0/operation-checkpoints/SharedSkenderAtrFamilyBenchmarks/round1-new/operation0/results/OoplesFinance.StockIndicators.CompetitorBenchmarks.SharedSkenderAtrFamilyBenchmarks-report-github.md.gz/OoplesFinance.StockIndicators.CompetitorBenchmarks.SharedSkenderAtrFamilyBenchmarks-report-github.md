```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skend(...)elier [21]** | **1000**  |   **205.5 μs** |  **7.03 μs** |  **3.68 μs** |  **73.28 KB** |
| BuilderLatestOnly | Skend(...)elier [21] | 1000  |   195.4 μs |  2.13 μs |  1.27 μs |  25.68 KB |
| **BuilderFull**       | **Skend(...)elier [21]** | **10000** | **2,182.6 μs** | **11.05 μs** |  **6.58 μs** | **706.53 KB** |
| BuilderLatestOnly | Skend(...)elier [21] | 10000 | 2,195.5 μs | 61.92 μs | 40.96 μs | 236.73 KB |
