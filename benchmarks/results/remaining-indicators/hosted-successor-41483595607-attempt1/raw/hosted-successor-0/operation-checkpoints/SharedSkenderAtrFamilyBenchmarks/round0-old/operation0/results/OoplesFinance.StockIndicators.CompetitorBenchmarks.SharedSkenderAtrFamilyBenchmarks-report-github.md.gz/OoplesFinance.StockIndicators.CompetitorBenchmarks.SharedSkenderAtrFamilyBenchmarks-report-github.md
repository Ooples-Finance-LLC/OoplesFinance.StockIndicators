```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skend(...)elier [21]** | **1000**  |   **204.1 μs** | **12.49 μs** |  **6.53 μs** |  **73.24 KB** |
| BuilderLatestOnly | Skend(...)elier [21] | 1000  |   195.7 μs |  2.66 μs |  1.58 μs |  25.68 KB |
| **BuilderFull**       | **Skend(...)elier [21]** | **10000** | **2,167.2 μs** | **23.10 μs** | **12.08 μs** | **706.49 KB** |
| BuilderLatestOnly | Skend(...)elier [21] | 10000 | 2,097.5 μs | 22.34 μs | 13.29 μs | 236.72 KB |
