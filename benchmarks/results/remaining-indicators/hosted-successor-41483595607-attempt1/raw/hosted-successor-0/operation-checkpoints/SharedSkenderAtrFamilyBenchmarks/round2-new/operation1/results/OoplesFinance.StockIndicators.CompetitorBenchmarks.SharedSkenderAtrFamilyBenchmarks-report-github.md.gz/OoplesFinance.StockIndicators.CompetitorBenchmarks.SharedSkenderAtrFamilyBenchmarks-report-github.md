```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |------------------- |------ |-----------:|----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetKeltner** | **1000**  |   **303.6 μs** |   **3.34 μs** |   **1.99 μs** |  **2.48** |    **0.03** |        **-** |        **-** |       **-** |  **104.66 KB** |        **0.29** |
| BuilderLatestOnly | Skender.GetKeltner | 1000  |   295.3 μs |   2.86 μs |   1.49 μs |  2.41 |    0.02 |        - |        - |       - |   57.06 KB |        0.16 |
| NativeSingle      | Skender.GetKeltner | 1000  |   122.7 μs |   1.80 μs |   1.07 μs |  1.00 |    0.01 |   3.9063 |   0.9766 |       - |  360.53 KB |        1.00 |
| NativeParallel    | Skender.GetKeltner | 1000  |   207.1 μs |  16.09 μs |  10.65 μs |  1.69 |    0.08 |  11.7188 |   5.8594 |       - |     911 KB |        2.53 |
|                   |                    |       |            |           |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skender.GetKeltner** | **10000** | **3,072.1 μs** |  **50.32 μs** |  **33.28 μs** |  **1.78** |    **0.13** |        **-** |        **-** |       **-** | **1019.26 KB** |        **0.28** |
| BuilderLatestOnly | Skender.GetKeltner | 10000 | 2,996.8 μs |  63.68 μs |  42.12 μs |  1.73 |    0.13 |        - |        - |       - |  549.36 KB |        0.15 |
| NativeSingle      | Skender.GetKeltner | 10000 | 1,738.0 μs | 191.06 μs | 126.37 μs |  1.00 |    0.10 |  46.8750 |  46.8750 | 46.8750 | 3595.38 KB |        1.00 |
| NativeParallel    | Skender.GetKeltner | 10000 | 2,604.2 μs | 160.65 μs | 106.26 μs |  1.51 |    0.12 | 156.2500 | 140.6250 | 78.1250 | 9067.97 KB |        2.52 |
