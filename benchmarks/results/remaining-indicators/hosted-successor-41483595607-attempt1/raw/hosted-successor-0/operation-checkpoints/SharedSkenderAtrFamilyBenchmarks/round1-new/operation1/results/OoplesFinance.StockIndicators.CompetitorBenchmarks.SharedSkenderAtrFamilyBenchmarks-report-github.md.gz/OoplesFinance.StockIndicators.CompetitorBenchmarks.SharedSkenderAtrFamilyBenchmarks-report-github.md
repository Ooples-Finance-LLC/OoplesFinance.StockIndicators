```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetKeltner** | **1000**  |   **309.6 μs** |  **2.42 μs** |  **1.27 μs** | **104.71 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 1000  |   297.2 μs |  3.64 μs |  2.16 μs |  57.06 KB |
| **BuilderFull**       | **Skender.GetKeltner** | **10000** | **3,096.6 μs** | **21.81 μs** | **11.41 μs** | **1019.3 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 10000 | 3,012.8 μs | 33.08 μs | 21.88 μs | 549.34 KB |
