```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|---------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)Bands [21]** | **1000**  |   **302.7 μs** |   **5.77 μs** |   **3.43 μs** |  **1.93** |    **0.02** |        **-** |       **-** |       **-** |   **97.39 KB** |        **0.30** |
| BuilderLatestOnly | Skend(...)Bands [21] | 1000  |   270.7 μs |   7.22 μs |   4.77 μs |  1.73 |    0.03 |        - |       - |       - |   49.79 KB |        0.15 |
| NativeSingle      | Skend(...)Bands [21] | 1000  |   156.5 μs |   1.03 μs |   0.61 μs |  1.00 |    0.01 |   3.9063 |       - |       - |  329.26 KB |        1.00 |
| NativeParallel    | Skend(...)Bands [21] | 1000  |   244.5 μs |  23.07 μs |  15.26 μs |  1.56 |    0.09 |   9.7656 |  3.9063 |       - |  832.72 KB |        2.53 |
|                   |                      |       |            |           |           |       |         |          |         |         |            |             |
| **BuilderFull**       | **Skend(...)Bands [21]** | **10000** | **2,913.0 μs** |  **49.64 μs** |  **32.84 μs** |  **1.45** |    **0.04** |        **-** |       **-** |       **-** |  **941.57 KB** |        **0.29** |
| BuilderLatestOnly | Skend(...)Bands [21] | 10000 | 2,693.7 μs |  20.57 μs |  12.24 μs |  1.34 |    0.03 |        - |       - |       - |  471.76 KB |        0.14 |
| NativeSingle      | Skend(...)Bands [21] | 10000 | 2,004.7 μs |  77.56 μs |  51.30 μs |  1.00 |    0.03 |  46.8750 | 46.8750 | 46.8750 | 3282.84 KB |        1.00 |
| NativeParallel    | Skend(...)Bands [21] | 10000 | 2,910.9 μs | 225.95 μs | 134.46 μs |  1.45 |    0.07 | 125.0000 | 93.7500 | 62.5000 | 8286.55 KB |        2.52 |
