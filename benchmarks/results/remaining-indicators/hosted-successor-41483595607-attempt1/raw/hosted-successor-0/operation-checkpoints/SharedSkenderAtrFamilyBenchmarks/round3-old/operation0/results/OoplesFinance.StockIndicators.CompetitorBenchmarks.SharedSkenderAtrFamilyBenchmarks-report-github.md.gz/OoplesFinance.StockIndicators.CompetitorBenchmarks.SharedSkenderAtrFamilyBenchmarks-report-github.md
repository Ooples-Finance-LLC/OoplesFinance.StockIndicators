```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skend(...)elier [21]** | **1000**  |   **213.3 μs** |  **8.32 μs** |  **4.95 μs** |  **73.28 KB** |
| BuilderLatestOnly | Skend(...)elier [21] | 1000  |   196.6 μs |  1.35 μs |  0.71 μs |  25.68 KB |
| **BuilderFull**       | **Skend(...)elier [21]** | **10000** | **2,286.3 μs** | **35.61 μs** | **21.19 μs** | **706.54 KB** |
| BuilderLatestOnly | Skend(...)elier [21] | 10000 | 2,349.1 μs | 16.26 μs |  8.50 μs | 236.73 KB |
