```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)elier [21]** | **1000**  |   **212.8 μs** |  **7.98 μs** |  **4.75 μs** |  **1.92** |    **0.04** |       **-** |       **-** |   **73.28 KB** |        **0.33** |
| BuilderLatestOnly | Skend(...)elier [21] | 1000  |   197.3 μs |  3.52 μs |  2.10 μs |  1.78 |    0.02 |       - |       - |   25.68 KB |        0.12 |
| NativeSingle      | Skend(...)elier [21] | 1000  |   110.6 μs |  1.63 μs |  0.97 μs |  1.00 |    0.01 |  1.9531 |       - |  223.23 KB |        1.00 |
| NativeParallel    | Skend(...)elier [21] | 1000  |   182.0 μs | 17.23 μs | 11.40 μs |  1.65 |    0.10 |  5.8594 |       - |  566.86 KB |        2.54 |
|                   |                      |       |            |          |          |       |         |         |         |            |             |
| **BuilderFull**       | **Skend(...)elier [21]** | **10000** | **2,318.8 μs** | **76.64 μs** | **50.69 μs** |  **1.49** |    **0.03** |       **-** |       **-** |   **706.5 KB** |        **0.32** |
| BuilderLatestOnly | Skend(...)elier [21] | 10000 | 2,105.7 μs | 13.73 μs |  7.18 μs |  1.35 |    0.01 |       - |       - |  236.71 KB |        0.11 |
| NativeSingle      | Skend(...)elier [21] | 10000 | 1,560.7 μs | 29.30 μs | 17.44 μs |  1.00 |    0.01 | 15.6250 |       - | 2227.24 KB |        1.00 |
| NativeParallel    | Skend(...)elier [21] | 10000 | 2,303.5 μs | 82.32 μs | 48.99 μs |  1.48 |    0.03 | 62.5000 | 46.8750 | 5647.04 KB |        2.54 |
