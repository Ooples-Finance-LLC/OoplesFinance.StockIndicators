```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **Skend(...)Bands [21]** | **1000**  |   **273.7 μs** |   **4.37 μs** |  **2.60 μs** |  **97.39 KB** |
| BuilderLatestOnly | Skend(...)Bands [21] | 1000  |   265.9 μs |   1.91 μs |  1.14 μs |  49.79 KB |
| **BuilderFull**       | **Skend(...)Bands [21]** | **10000** | **2,791.5 μs** | **107.41 μs** | **71.05 μs** | **941.59 KB** |
| BuilderLatestOnly | Skend(...)Bands [21] | 10000 | 2,698.6 μs |  59.64 μs | 39.45 μs | 471.75 KB |
