```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean        | Error      | StdDev    | Gen0    | Allocated  |
|------------------ |------ |------------:|-----------:|----------:|--------:|-----------:|
| **BuilderFull**       | **1000**  |    **82.86 μs** |   **0.874 μs** |  **0.520 μs** |       **-** |   **91.75 KB** |
| BuilderLatestOnly | 1000  |    77.26 μs |   0.395 μs |  0.235 μs |  0.4883 |   43.87 KB |
| **BuilderFull**       | **10000** | **3,801.92 μs** | **135.299 μs** | **89.492 μs** | **31.2500** | **5102.49 KB** |
| BuilderLatestOnly | 10000 | 3,726.90 μs |  50.716 μs | 30.180 μs | 31.2500 |  4632.4 KB |
