```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean        | Error     | StdDev    | Gen0    | Allocated  |
|------------------ |------ |------------:|----------:|----------:|--------:|-----------:|
| **BuilderFull**       | **1000**  |    **83.55 μs** |  **2.375 μs** |  **1.413 μs** |       **-** |   **91.75 KB** |
| BuilderLatestOnly | 1000  |    79.97 μs |  0.753 μs |  0.448 μs |  0.4883 |   43.87 KB |
| **BuilderFull**       | **10000** | **3,784.16 μs** | **42.122 μs** | **22.030 μs** | **31.2500** | **5102.46 KB** |
| BuilderLatestOnly | 10000 | 3,733.43 μs | 24.510 μs | 12.819 μs | 31.2500 | 4632.38 KB |
