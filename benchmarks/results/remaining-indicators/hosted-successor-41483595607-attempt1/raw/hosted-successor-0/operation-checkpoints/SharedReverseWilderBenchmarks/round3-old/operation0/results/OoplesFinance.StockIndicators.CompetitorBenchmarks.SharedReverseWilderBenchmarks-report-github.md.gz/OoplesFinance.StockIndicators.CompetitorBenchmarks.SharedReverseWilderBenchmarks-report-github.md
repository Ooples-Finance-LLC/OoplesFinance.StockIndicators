```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean        | Error      | StdDev    | Gen0    | Allocated  |
|------------------ |------ |------------:|-----------:|----------:|--------:|-----------:|
| **BuilderFull**       | **1000**  |    **84.11 μs** |   **1.318 μs** |  **0.784 μs** |       **-** |   **91.75 KB** |
| BuilderLatestOnly | 1000  |    79.21 μs |   0.805 μs |  0.532 μs |  0.4883 |   43.87 KB |
| **BuilderFull**       | **10000** | **3,847.35 μs** | **126.113 μs** | **83.416 μs** | **31.2500** | **5102.48 KB** |
| BuilderLatestOnly | 10000 | 3,752.04 μs |  43.537 μs | 25.908 μs | 31.2500 | 4632.39 KB |
