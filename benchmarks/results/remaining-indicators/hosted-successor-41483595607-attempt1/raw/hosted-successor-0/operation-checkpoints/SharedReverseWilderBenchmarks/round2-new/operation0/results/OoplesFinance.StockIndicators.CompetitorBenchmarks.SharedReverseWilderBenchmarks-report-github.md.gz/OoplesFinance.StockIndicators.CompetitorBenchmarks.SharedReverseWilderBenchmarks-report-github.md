```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated  | Alloc Ratio |
|------------------ |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|-----------:|------------:|
| **BuilderFull**       | **1000**  |    **89.42 μs** |  **1.120 μs** |  **0.586 μs** |  **4.45** |    **0.03** |       **-** |      **-** |   **91.75 KB** |        **1.94** |
| BuilderLatestOnly | 1000  |    81.85 μs |  0.444 μs |  0.232 μs |  4.08 |    0.02 |       - |      - |   43.88 KB |        0.93 |
| NativeSingle      | 1000  |    20.07 μs |  0.104 μs |  0.062 μs |  1.00 |    0.00 |  0.4883 |      - |    47.2 KB |        1.00 |
| NativeParallel    | 1000  |    31.28 μs |  1.694 μs |  1.008 μs |  1.56 |    0.05 |  1.2207 |      - |  106.85 KB |        2.26 |
|                   |       |             |           |           |       |         |         |        |            |             |
| **BuilderFull**       | **10000** | **3,807.12 μs** | **22.213 μs** | **13.219 μs** | **21.12** |    **0.39** | **31.2500** |      **-** | **5102.48 KB** |       **10.88** |
| BuilderLatestOnly | 10000 | 3,791.01 μs | 81.069 μs | 53.622 μs | 21.03 |    0.48 | 31.2500 |      - |  4632.4 KB |        9.88 |
| NativeSingle      | 10000 |   180.31 μs |  5.119 μs |  3.386 μs |  1.00 |    0.03 |  4.8828 | 0.9766 |  469.08 KB |        1.00 |
| NativeParallel    | 10000 |   223.18 μs |  5.692 μs |  2.977 μs |  1.24 |    0.03 | 11.7188 | 1.9531 | 1056.09 KB |        2.25 |
