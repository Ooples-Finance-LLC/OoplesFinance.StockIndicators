```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0   | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|-----------:|-----------:|------:|--------:|-------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)bands [22]** | **1000**  | **120.829 μs** | **51.1745 μs** | **33.8487 μs** | **14.54** |    **3.88** |      **-** |      **-** |  **84.07 KB** |        **3.62** |
| BuilderLatestOnly | TaLib(...)bands [22] | 1000  |  84.023 μs |  5.7543 μs |  3.4243 μs | 10.11 |    0.40 |      - |      - |  36.46 KB |        1.57 |
| NativeSingle      | TaLib(...)bands [22] | 1000  |   8.311 μs |  0.0952 μs |  0.0629 μs |  1.00 |    0.01 | 0.2441 |      - |   23.2 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [22] | 1000  |   7.592 μs |  0.4161 μs |  0.2752 μs |  0.91 |    0.03 | 0.2441 |      - |  23.66 KB |        1.02 |
|                   |                      |       |            |            |            |       |         |        |        |           |             |
| **BuilderFull**       | **TaLib(...)bands [22]** | **10000** | **578.701 μs** | **47.4059 μs** | **31.3560 μs** |  **7.78** |    **0.41** | **7.8125** | **3.9063** | **787.56 KB** |        **3.36** |
| BuilderLatestOnly | TaLib(...)bands [22] | 10000 | 501.797 μs | 49.5938 μs | 29.5125 μs |  6.75 |    0.38 |      - |      - | 317.74 KB |        1.36 |
| NativeSingle      | TaLib(...)bands [22] | 10000 |  74.374 μs |  1.4254 μs |  0.9428 μs |  1.00 |    0.02 | 2.4414 | 0.9766 | 234.14 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [22] | 10000 |  56.266 μs |  3.5304 μs |  2.3351 μs |  0.76 |    0.03 | 2.4414 | 0.9766 |  234.6 KB |        1.00 |
