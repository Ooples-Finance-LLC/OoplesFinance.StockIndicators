```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)bands [22]** | **1000**  |  **95.92 μs** |  **6.572 μs** |  **4.347 μs** |      **-** |  **84.07 KB** |
| BuilderLatestOnly | TaLib(...)bands [22] | 1000  |  82.74 μs |  4.066 μs |  2.689 μs |      - |  36.46 KB |
| **BuilderFull**       | **TaLib(...)bands [22]** | **10000** | **547.84 μs** |  **8.008 μs** |  **4.188 μs** | **7.8125** | **787.59 KB** |
| BuilderLatestOnly | TaLib(...)bands [22] | 10000 | 488.55 μs | 27.959 μs | 14.623 μs |      - | 317.73 KB |
