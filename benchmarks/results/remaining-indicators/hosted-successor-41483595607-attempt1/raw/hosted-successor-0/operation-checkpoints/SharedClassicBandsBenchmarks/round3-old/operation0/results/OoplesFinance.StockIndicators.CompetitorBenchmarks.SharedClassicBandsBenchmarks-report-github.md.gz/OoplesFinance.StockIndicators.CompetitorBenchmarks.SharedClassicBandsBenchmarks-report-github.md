```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)bands [22]** | **1000**  | **109.91 μs** |  **1.503 μs** |  **0.786 μs** |      **-** |  **84.11 KB** |
| BuilderLatestOnly | TaLib(...)bands [22] | 1000  |  81.77 μs |  3.973 μs |  2.078 μs |      - |  36.46 KB |
| **BuilderFull**       | **TaLib(...)bands [22]** | **10000** | **736.14 μs** | **72.366 μs** | **47.866 μs** | **7.8125** | **787.59 KB** |
| BuilderLatestOnly | TaLib(...)bands [22] | 10000 | 574.58 μs | 71.729 μs | 47.444 μs |      - | 317.74 KB |
