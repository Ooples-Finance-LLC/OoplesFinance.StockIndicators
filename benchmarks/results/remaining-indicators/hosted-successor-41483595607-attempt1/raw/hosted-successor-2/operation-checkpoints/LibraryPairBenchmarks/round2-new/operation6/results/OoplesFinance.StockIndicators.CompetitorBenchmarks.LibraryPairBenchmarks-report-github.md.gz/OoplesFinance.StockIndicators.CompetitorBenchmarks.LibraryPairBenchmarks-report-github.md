```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAdl** |   **211.25 μs** |  **3.559 μs** |  **1.862 μs** |  **1.00** |    **0.01** |  **246.84 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAdl |    92.17 μs | 14.400 μs |  9.524 μs |  0.44 |    0.04 |  272.67 KB |        1.10 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAdl** | **2,251.45 μs** | **83.685 μs** | **55.352 μs** |  **1.00** |    **0.03** | **2809.73 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAdl |   885.21 μs | 39.226 μs | 23.343 μs |  0.39 |    0.01 | 2653.85 KB |        0.94 |
