```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId        | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |-------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **QuanTAlib.Rma** |   **116.5 μs** |  **11.59 μs** |  **6.90 μs** |  **1.00** |    **0.08** |   **97.54 KB** |        **1.00** |
|        |       |               |            |           |          |       |         |            |             |
| **Ooples** | **10000** | **QuanTAlib.Rma** | **3,750.1 μs** | **127.89 μs** | **76.11 μs** |  **1.00** |    **0.03** | **5241.33 KB** |        **1.00** |
