```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)ogram [59]** |    **585.3 μs** |    **33.21 μs** |    **19.76 μs** |  **1.00** |    **0.04** |         **-** |         **-** |         **-** |   **240.73 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)ogram [59] |  2,513.0 μs |    65.03 μs |    43.01 μs |  4.30 |    0.15 |         - |         - |         - |  3695.69 KB |       15.35 |
|            |       |                      |             |             |             |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)ogram [59]** |  **5,345.5 μs** |   **183.87 μs** |   **109.42 μs** |  **1.00** |    **0.03** |         **-** |         **-** |         **-** |  **2363.48 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)ogram [59] | 27,432.3 μs | 2,434.95 μs | 1,449.00 μs |  5.13 |    0.28 | 1000.0000 | 1000.0000 | 1000.0000 | 36352.86 KB |       15.38 |
