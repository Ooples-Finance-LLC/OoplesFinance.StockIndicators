```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)gence [50]** |    **585.2 μs** |    **16.55 μs** |     **8.66 μs** |  **1.00** |    **0.02** |         **-** |         **-** |         **-** |   **290.09 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)gence [50] |  2,289.2 μs |    77.06 μs |    45.86 μs |  3.91 |    0.09 |         - |         - |         - |  3520.52 KB |       12.14 |
|            |       |                      |             |             |             |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)gence [50]** |  **5,557.8 μs** |    **86.20 μs** |    **51.30 μs** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |  **2855.25 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)gence [50] | 26,409.2 μs | 3,959.56 μs | 2,070.92 μs |  4.75 |    0.35 | 1000.0000 | 1000.0000 | 1000.0000 | 34687.98 KB |       12.15 |
