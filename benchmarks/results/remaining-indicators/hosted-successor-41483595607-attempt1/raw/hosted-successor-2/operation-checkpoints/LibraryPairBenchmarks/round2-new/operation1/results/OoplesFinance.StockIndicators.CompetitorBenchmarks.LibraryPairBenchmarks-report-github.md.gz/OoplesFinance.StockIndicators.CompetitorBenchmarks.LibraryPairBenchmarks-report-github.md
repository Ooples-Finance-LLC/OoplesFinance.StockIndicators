```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Dwma** |    **63.13 μs** |  **13.30 μs** |  **7.913 μs** |  **1.01** |    **0.17** |   **66.37 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Dwma |   223.59 μs |  37.36 μs | 24.711 μs |  3.59 |    0.55 |  547.73 KB |        8.25 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Dwma** |   **511.70 μs** |  **90.90 μs** | **60.126 μs** |  **1.02** |    **0.18** |  **637.02 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Dwma | 2,275.61 μs | 140.20 μs | 73.329 μs |  4.52 |    0.64 | 5449.13 KB |        8.55 |
