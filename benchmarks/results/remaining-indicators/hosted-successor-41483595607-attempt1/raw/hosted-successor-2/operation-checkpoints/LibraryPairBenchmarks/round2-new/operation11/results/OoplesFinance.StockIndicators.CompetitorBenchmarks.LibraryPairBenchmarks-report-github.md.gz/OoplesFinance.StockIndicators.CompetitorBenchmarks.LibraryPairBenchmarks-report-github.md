```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)nnels [31]** |    **404.2 μs** |    **22.01 μs** |    **14.56 μs** |  **1.00** |    **0.05** |         **-** |         **-** |         **-** |   **218.88 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)nnels [31] |  1,989.2 μs |    53.71 μs |    35.52 μs |  4.93 |    0.19 |         - |         - |         - |  3154.45 KB |       14.41 |
|            |       |                      |             |             |             |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)nnels [31]** |  **3,459.6 μs** |   **167.37 μs** |    **99.60 μs** |  **1.00** |    **0.04** |         **-** |         **-** |         **-** |  **2149.87 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)nnels [31] | 25,351.3 μs | 2,693.23 μs | 1,602.70 μs |  7.33 |    0.48 | 1000.0000 | 1000.0000 | 1000.0000 | 30681.59 KB |       14.27 |
