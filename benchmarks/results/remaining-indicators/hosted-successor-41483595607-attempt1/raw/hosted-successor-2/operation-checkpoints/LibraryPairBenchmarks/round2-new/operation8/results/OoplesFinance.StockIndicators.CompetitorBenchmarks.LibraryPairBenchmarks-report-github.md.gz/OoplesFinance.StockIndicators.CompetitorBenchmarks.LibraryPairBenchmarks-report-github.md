```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean         | Error       | StdDev    | Ratio | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |-------------:|------------:|----------:|------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)Index [37]** |     **327.5 μs** |    **60.62 μs** |  **40.10 μs** |  **1.01** |    **0.17** |   **108.26 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)Index [37] |  11,689.6 μs |   153.72 μs |  91.48 μs | 36.22 |    4.56 |  4703.79 KB |       43.45 |
|            |       |                      |              |             |           |       |         |             |             |
| **Ooples**     | **10000** | **Trady(...)Index [37]** |   **2,737.7 μs** | **1,033.72 μs** | **683.74 μs** |  **1.05** |    **0.34** |  **1040.25 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)Index [37] | 122,994.4 μs |   679.49 μs | 449.44 μs | 47.35 |   10.28 | 48253.84 KB |       46.39 |
