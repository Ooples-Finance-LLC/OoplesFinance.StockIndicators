```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId         | Mean      | Error    | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------- |----------:|---------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **QuanTAlib.Fwma** |  **53.97 μs** | **11.73 μs** |  **6.978 μs** |  **1.01** |    **0.16** |  **15.95 KB** |        **1.00** |
|        |       |                |           |          |           |       |         |           |             |
| **Ooples** | **10000** | **QuanTAlib.Fwma** | **567.46 μs** | **37.20 μs** | **22.135 μs** |  **1.00** |    **0.05** | **156.57 KB** |        **1.00** |
