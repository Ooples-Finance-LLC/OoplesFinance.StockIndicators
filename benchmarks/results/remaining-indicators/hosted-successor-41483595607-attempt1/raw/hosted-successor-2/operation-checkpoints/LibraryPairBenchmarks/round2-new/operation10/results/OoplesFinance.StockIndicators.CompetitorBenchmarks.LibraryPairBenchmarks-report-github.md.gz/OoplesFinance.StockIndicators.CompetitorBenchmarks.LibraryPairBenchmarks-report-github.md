```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)lator [50]** |    **166.4 μs** |     **9.37 μs** |     **5.58 μs** |  **1.00** |    **0.04** |         **-** |         **-** |         **-** |    **105.6 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)lator [50] |  1,952.8 μs |    97.06 μs |    57.76 μs | 11.75 |    0.49 |         - |         - |         - |  2509.45 KB |       23.76 |
|            |       |                      |             |             |             |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)lator [50]** |  **1,258.4 μs** |   **103.62 μs** |    **61.67 μs** |  **1.00** |    **0.06** |         **-** |         **-** |         **-** |  **1035.72 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)lator [50] | 22,075.6 μs | 2,003.00 μs | 1,324.86 μs | 17.58 |    1.27 | 1000.0000 | 1000.0000 | 1000.0000 | 24966.21 KB |       24.11 |
