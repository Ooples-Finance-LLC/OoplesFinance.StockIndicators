```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId        | Mean      | Error    | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |-------------- |----------:|---------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **QuanTAlib.Wma** |  **53.86 μs** | **13.38 μs** |  **6.999 μs** |  **1.01** |    **0.18** |  **65.77 KB** |        **1.00** |
|        |       |               |           |          |           |       |         |           |             |
| **Ooples** | **10000** | **QuanTAlib.Wma** | **117.63 μs** | **24.31 μs** | **14.464 μs** |  **1.01** |    **0.16** | **635.73 KB** |        **1.00** |
