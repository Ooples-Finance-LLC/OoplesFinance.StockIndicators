```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean          | Error        | StdDev       | Ratio  | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |--------------:|-------------:|-------------:|-------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)erage [40]** |      **70.60 μs** |     **4.254 μs** |     **2.531 μs** |   **1.00** |    **0.05** |    **64.72 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)erage [40] |   2,877.74 μs |   149.464 μs |    88.943 μs |  40.81 |    1.81 |  1364.32 KB |       21.08 |
|            |       |                      |               |              |              |        |         |             |             |
| **Ooples**     | **10000** | **Trady(...)erage [40]** |     **446.91 μs** |    **34.218 μs** |    **20.362 μs** |   **1.00** |    **0.06** |   **632.75 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)erage [40] | 185,427.42 μs | 1,833.061 μs | 1,090.825 μs | 415.70 |   18.56 | 13284.71 KB |       21.00 |
