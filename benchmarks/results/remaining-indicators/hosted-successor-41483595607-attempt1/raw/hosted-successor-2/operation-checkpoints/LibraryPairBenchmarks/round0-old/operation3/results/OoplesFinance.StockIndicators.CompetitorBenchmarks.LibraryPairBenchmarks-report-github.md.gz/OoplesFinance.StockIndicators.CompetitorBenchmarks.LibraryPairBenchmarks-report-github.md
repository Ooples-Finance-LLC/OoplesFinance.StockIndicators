```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId        | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |-------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **QuanTAlib.Rma** |   **124.0 μs** |  **15.46 μs** |   **9.20 μs** |  **1.00** |    **0.10** |   **97.54 KB** |        **1.00** |
|        |       |               |            |           |           |       |         |            |             |
| **Ooples** | **10000** | **QuanTAlib.Rma** | **3,769.9 μs** | **180.48 μs** | **107.40 μs** |  **1.00** |    **0.04** | **5242.31 KB** |        **1.00** |
