```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean         | Error      | StdDev    | Ratio | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |-------------:|-----------:|----------:|------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)lator [45]** |     **83.36 μs** |   **3.760 μs** |  **2.237 μs** |  **1.00** |    **0.04** |   **107.84 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)lator [45] |  1,493.79 μs |  64.477 μs | 42.648 μs | 17.93 |    0.67 |  1388.36 KB |       12.87 |
|            |       |                      |              |            |           |       |         |             |             |
| **Ooples**     | **10000** | **Trady(...)lator [45]** |    **583.30 μs** | **166.165 μs** | **98.882 μs** |  **1.02** |    **0.22** |  **1039.17 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)lator [45] | 12,314.89 μs | 137.563 μs | 71.948 μs | 21.58 |    2.97 | 13489.96 KB |       12.98 |
