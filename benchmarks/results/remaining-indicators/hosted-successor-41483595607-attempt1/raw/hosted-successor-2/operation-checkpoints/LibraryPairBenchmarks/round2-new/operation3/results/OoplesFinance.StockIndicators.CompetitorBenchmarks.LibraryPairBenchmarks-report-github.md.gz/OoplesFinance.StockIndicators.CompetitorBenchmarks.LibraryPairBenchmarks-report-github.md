```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId        | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Rma** |   **149.15 μs** | **10.924 μs** |  **5.713 μs** |  **1.00** |    **0.05** |   **97.58 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Rma |    46.50 μs |  9.589 μs |  6.343 μs |  0.31 |    0.04 |   54.12 KB |        0.55 |
|            |       |               |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Rma** | **3,775.74 μs** | **72.555 μs** | **37.948 μs** |  **1.00** |    **0.01** | **5244.91 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Rma |   410.58 μs | 27.339 μs | 16.269 μs |  0.11 |    0.00 |  475.99 KB |        0.09 |
