```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId           | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |----------------- |-----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Afirma** |   **119.3 μs** | **16.60 μs** | **10.98 μs** |  **1.01** |    **0.12** |  **24.59 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Afirma |   189.7 μs | 18.08 μs | 11.96 μs |  1.60 |    0.17 |  56.05 KB |        2.28 |
|            |       |                  |            |          |          |       |         |           |             |
| **Ooples**     | **10000** | **QuanTAlib.Afirma** |   **930.2 μs** | **18.56 μs** | **12.28 μs** |  **1.00** |    **0.02** | **243.36 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Afirma | 1,802.6 μs | 20.68 μs | 12.31 μs |  1.94 |    0.03 | 475.63 KB |        1.95 |
