```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Trady(...)nnels [31]** |   **509.4 μs** | **176.32 μs** | **116.62 μs** |  **1.05** |    **0.34** |  **218.88 KB** |        **1.00** |
|        |       |                      |            |           |           |       |         |            |             |
| **Ooples** | **10000** | **Trady(...)nnels [31]** | **3,426.7 μs** |  **83.23 μs** |  **49.53 μs** |  **1.00** |    **0.02** | **2153.15 KB** |        **1.00** |
