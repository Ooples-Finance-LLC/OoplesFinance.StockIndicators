```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean         | Error      | StdDev     | Ratio  | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-------------:|-----------:|-----------:|-------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)erage [37]** |     **40.51 μs** |   **2.972 μs** |   **1.554 μs** |   **1.00** |    **0.05** |   **65.73 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)erage [37] |  2,356.03 μs |  72.192 μs |  42.960 μs |  58.23 |    2.29 |  842.72 KB |       12.82 |
|            |       |                      |              |            |            |        |         |            |             |
| **Ooples**     | **10000** | **Trady(...)erage [37]** |    **126.66 μs** |  **15.456 μs** |   **9.197 μs** |   **1.00** |    **0.09** |  **636.77 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)erage [37] | 20,595.22 μs | 241.953 μs | 126.546 μs | 163.32 |   10.58 | 8326.38 KB |       13.08 |
