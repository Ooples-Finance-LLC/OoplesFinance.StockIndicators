```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId          | Mean        | Error      | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |---------------- |------------:|-----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetBeta** |  **1,844.5 μs** |   **105.0 μs** |  **62.50 μs** |  **1.00** |    **0.05** |   **1.56 MB** |        **1.00** |
| Competitor | 1000  | Skender.GetBeta |    634.1 μs |   142.1 μs |  93.97 μs |  0.34 |    0.05 |   2.66 MB |        1.70 |
|            |       |                 |             |            |           |       |         |           |             |
| **Ooples**     | **10000** | **Skender.GetBeta** | **18,121.3 μs** | **1,174.1 μs** | **614.08 μs** |  **1.00** |    **0.04** |  **15.71 MB** |        **1.00** |
| Competitor | 10000 | Skender.GetBeta |  7,058.6 μs |   475.0 μs | 282.67 μs |  0.39 |    0.02 |  26.89 MB |        1.71 |
