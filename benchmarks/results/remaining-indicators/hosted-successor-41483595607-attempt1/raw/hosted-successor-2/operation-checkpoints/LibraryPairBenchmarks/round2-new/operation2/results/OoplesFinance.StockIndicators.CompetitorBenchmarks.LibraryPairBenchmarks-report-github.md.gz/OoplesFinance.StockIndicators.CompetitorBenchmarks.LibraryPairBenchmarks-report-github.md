```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Fwma** |    **53.19 μs** | **13.246 μs** |  **8.762 μs** |  **1.02** |    **0.21** |  **15.95 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Fwma |   123.59 μs |  7.422 μs |  4.909 μs |  2.37 |    0.34 | 261.09 KB |       16.37 |
|            |       |                |             |           |           |       |         |           |             |
| **Ooples**     | **10000** | **QuanTAlib.Fwma** |   **586.36 μs** | **23.043 μs** | **15.241 μs** |  **1.00** |    **0.03** | **161.12 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Fwma | 1,171.42 μs | 96.822 μs | 64.042 μs |  2.00 |    0.11 | 2572.5 KB |       15.97 |
