```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId       | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.T3** |   **259.08 μs** | **23.082 μs** | **15.267 μs** |  **1.00** |    **0.08** |  **105.85 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.T3 |    77.74 μs |  3.951 μs |  2.351 μs |  0.30 |    0.02 |      74 KB |        0.70 |
|            |       |              |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.T3** | **2,200.06 μs** | **60.218 μs** | **39.831 μs** |  **1.00** |    **0.02** | **1035.55 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.T3 |   642.22 μs | 30.548 μs | 18.178 μs |  0.29 |    0.01 |  643.32 KB |        0.62 |
