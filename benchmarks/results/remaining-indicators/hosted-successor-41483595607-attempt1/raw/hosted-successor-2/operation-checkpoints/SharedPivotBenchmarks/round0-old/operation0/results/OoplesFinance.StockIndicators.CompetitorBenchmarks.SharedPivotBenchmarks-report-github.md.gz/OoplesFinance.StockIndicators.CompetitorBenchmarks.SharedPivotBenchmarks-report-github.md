```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error     | StdDev    | Gen0   | Allocated  |
|------------------ |------ |-----------:|----------:|----------:|-------:|-----------:|
| **BuilderFull**       | **1000**  |   **340.9 μs** |  **55.16 μs** |  **36.49 μs** |      **-** |  **128.45 KB** |
| BuilderLatestOnly | 1000  |   187.2 μs |  31.04 μs |  18.47 μs |      - |   80.85 KB |
| **BuilderFull**       | **10000** | **1,544.6 μs** | **221.12 μs** | **146.26 μs** |      **-** | **1183.57 KB** |
| BuilderLatestOnly | 10000 | 1,506.5 μs | 147.79 μs |  97.75 μs | 7.8125 |  713.72 KB |
