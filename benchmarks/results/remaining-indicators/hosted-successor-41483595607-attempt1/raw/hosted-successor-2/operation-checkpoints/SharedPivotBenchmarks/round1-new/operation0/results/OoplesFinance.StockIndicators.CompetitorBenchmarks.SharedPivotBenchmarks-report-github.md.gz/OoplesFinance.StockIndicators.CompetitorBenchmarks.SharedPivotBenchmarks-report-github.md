```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error     | StdDev    | Gen0   | Allocated  |
|------------------ |------ |-----------:|----------:|----------:|-------:|-----------:|
| **BuilderFull**       | **1000**  |   **217.3 μs** |  **45.85 μs** |  **30.33 μs** |      **-** |  **128.45 KB** |
| BuilderLatestOnly | 1000  |   191.8 μs |  33.33 μs |  22.05 μs |      - |   80.85 KB |
| **BuilderFull**       | **10000** | **1,450.1 μs** |  **38.71 μs** |  **20.24 μs** |      **-** | **1183.58 KB** |
| BuilderLatestOnly | 10000 | 1,520.4 μs | 219.50 μs | 145.19 μs | 7.8125 |  713.72 KB |
