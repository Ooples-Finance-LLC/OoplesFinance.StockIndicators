```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error     | StdDev    | Gen0   | Allocated  |
|------------------ |------ |-----------:|----------:|----------:|-------:|-----------:|
| **BuilderFull**       | **1000**  |   **186.8 μs** |  **11.93 μs** |   **6.24 μs** |      **-** |  **128.49 KB** |
| BuilderLatestOnly | 1000  |   190.4 μs |  28.12 μs |  16.73 μs |      - |   80.85 KB |
| **BuilderFull**       | **10000** | **1,533.8 μs** | **207.64 μs** | **137.34 μs** |      **-** | **1183.57 KB** |
| BuilderLatestOnly | 10000 | 1,528.4 μs | 152.57 μs | 100.91 μs | 7.8125 |  713.71 KB |
