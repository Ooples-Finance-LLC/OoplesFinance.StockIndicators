```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |------ |-----------:|----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **1000**  |   **222.5 μs** |  **74.94 μs** |  **49.57 μs** |  **0.50** |    **0.11** |       **-** |       **-** |  **128.45 KB** |        **0.26** |
| BuilderLatestOnly | 1000  |   182.0 μs |   3.71 μs |   1.94 μs |  0.41 |    0.01 |       - |       - |   80.85 KB |        0.16 |
| NativeSingle      | 1000  |   444.1 μs |   5.54 μs |   3.67 μs |  1.00 |    0.01 |  3.9063 |       - |  499.63 KB |        1.00 |
| NativeParallel    | 1000  |   273.1 μs |  35.60 μs |  23.55 μs |  0.61 |    0.05 |  5.8594 |  1.9531 |  525.32 KB |        1.05 |
|                   |       |            |           |           |       |         |         |         |            |             |
| **BuilderFull**       | **10000** | **1,576.2 μs** | **310.09 μs** | **205.10 μs** |  **0.34** |    **0.04** |       **-** |       **-** | **1183.58 KB** |        **0.24** |
| BuilderLatestOnly | 10000 | 1,490.1 μs | 200.40 μs | 119.26 μs |  0.32 |    0.02 |       - |       - |  713.77 KB |        0.14 |
| NativeSingle      | 10000 | 4,595.0 μs |  52.49 μs |  31.24 μs |  1.00 |    0.01 | 31.2500 |       - | 5035.01 KB |        1.00 |
| NativeParallel    | 10000 | 2,640.9 μs | 249.73 μs | 165.18 μs |  0.57 |    0.03 | 62.5000 | 46.8750 | 5130.92 KB |        1.02 |
