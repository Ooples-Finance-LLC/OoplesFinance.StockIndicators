```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error    | StdDev   | Allocated  |
|------------------ |----------------- |------ |-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetRocWb** | **1000**  |   **402.4 μs** | **21.55 μs** | **12.82 μs** |  **105.31 KB** |
| BuilderLatestOnly | Skender.GetRocWb | 1000  |   371.5 μs |  2.51 μs |  1.31 μs |   57.72 KB |
| **BuilderFull**       | **Skender.GetRocWb** | **10000** | **4,046.8 μs** | **87.78 μs** | **58.06 μs** | **1019.88 KB** |
| BuilderLatestOnly | Skender.GetRocWb | 10000 | 3,948.8 μs | 25.09 μs | 14.93 μs |  550.14 KB |
