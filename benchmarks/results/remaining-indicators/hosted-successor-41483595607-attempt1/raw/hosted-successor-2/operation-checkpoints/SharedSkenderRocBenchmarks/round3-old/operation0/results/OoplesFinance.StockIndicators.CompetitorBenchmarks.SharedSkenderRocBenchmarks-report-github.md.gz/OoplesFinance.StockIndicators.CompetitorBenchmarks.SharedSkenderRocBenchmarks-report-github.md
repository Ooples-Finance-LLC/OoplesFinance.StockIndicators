```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |----------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetRocWb** | **1000**  |   **334.7 μs** |  **8.70 μs** |  **5.18 μs** | **105.36 KB** |
| BuilderLatestOnly | Skender.GetRocWb | 1000  |   325.0 μs |  9.39 μs |  6.21 μs |   57.7 KB |
| **BuilderFull**       | **Skender.GetRocWb** | **10000** | **3,523.1 μs** | **54.21 μs** | **28.35 μs** | **1019.9 KB** |
| BuilderLatestOnly | Skender.GetRocWb | 10000 | 3,400.1 μs | 24.04 μs | 12.57 μs |  550.1 KB |
