```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |----------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetRocWb** | **1000**  |   **417.21 μs** |   **9.530 μs** |   **5.671 μs** |  **6.12** |    **0.09** |        **-** |        **-** |        **-** |  **105.31 KB** |        **0.46** |
| BuilderLatestOnly | Skender.GetRocWb | 1000  |   389.94 μs |   4.510 μs |   2.684 μs |  5.72 |    0.05 |        - |        - |        - |   57.72 KB |        0.25 |
| NativeSingle      | Skender.GetRocWb | 1000  |    68.17 μs |   0.707 μs |   0.421 μs |  1.00 |    0.01 |   2.4414 |   0.4883 |        - |  231.09 KB |        1.00 |
| NativeParallel    | Skender.GetRocWb | 1000  |   132.37 μs |   6.304 μs |   3.297 μs |  1.94 |    0.05 |   6.8359 |   1.9531 |        - |  586.66 KB |        2.54 |
|                   |                  |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetRocWb** | **10000** | **4,165.47 μs** | **119.894 μs** |  **79.302 μs** |  **3.99** |    **0.15** |        **-** |        **-** |        **-** |  **1019.9 KB** |        **0.44** |
| BuilderLatestOnly | Skender.GetRocWb | 10000 | 4,029.67 μs |  40.249 μs |  23.951 μs |  3.86 |    0.12 |        - |        - |        - |  550.13 KB |        0.24 |
| NativeSingle      | Skender.GetRocWb | 10000 | 1,045.10 μs |  51.641 μs |  34.157 μs |  1.00 |    0.04 | 148.4375 | 148.4375 | 148.4375 | 2306.51 KB |        1.00 |
| NativeParallel    | Skender.GetRocWb | 10000 | 2,756.43 μs | 284.388 μs | 188.105 μs |  2.64 |    0.19 | 250.0000 | 250.0000 | 218.7500 | 5844.83 KB |        2.53 |
