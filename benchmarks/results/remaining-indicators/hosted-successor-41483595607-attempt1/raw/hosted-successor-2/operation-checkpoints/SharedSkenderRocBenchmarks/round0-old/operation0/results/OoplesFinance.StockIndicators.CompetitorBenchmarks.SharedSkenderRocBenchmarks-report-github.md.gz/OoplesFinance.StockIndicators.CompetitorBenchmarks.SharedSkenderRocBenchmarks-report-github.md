```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error    | StdDev   | Allocated  |
|------------------ |----------------- |------ |-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetRocWb** | **1000**  |   **326.2 μs** |  **7.54 μs** |  **3.94 μs** |  **105.36 KB** |
| BuilderLatestOnly | Skender.GetRocWb | 1000  |   318.9 μs |  3.01 μs |  1.57 μs |    57.7 KB |
| **BuilderFull**       | **Skender.GetRocWb** | **10000** | **3,491.7 μs** | **56.88 μs** | **33.85 μs** | **1019.94 KB** |
| BuilderLatestOnly | Skender.GetRocWb | 10000 | 3,447.7 μs | 23.42 μs | 12.25 μs |  550.03 KB |
