```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean     | Error    | StdDev   | Gen0    | Gen1   | Allocated  |
|------------------ |---------- |------ |---------:|---------:|---------:|--------:|-------:|-----------:|
| **BuilderFull**       | **Dwma**      | **1000**  | **140.8 μs** | **14.74 μs** |  **9.75 μs** |       **-** |      **-** |  **173.26 KB** |
| BuilderLatestOnly | Dwma      | 1000  | 136.1 μs |  5.03 μs |  3.33 μs |  0.9766 |      - |  125.63 KB |
| **BuilderFull**       | **Dwma**      | **10000** | **820.7 μs** | **68.92 μs** | **45.58 μs** | **15.6250** | **7.8125** | **1609.01 KB** |
| BuilderLatestOnly | Dwma      | 10000 | 803.6 μs | 96.50 μs | 63.83 μs | 11.7188 |      - | 1139.14 KB |
