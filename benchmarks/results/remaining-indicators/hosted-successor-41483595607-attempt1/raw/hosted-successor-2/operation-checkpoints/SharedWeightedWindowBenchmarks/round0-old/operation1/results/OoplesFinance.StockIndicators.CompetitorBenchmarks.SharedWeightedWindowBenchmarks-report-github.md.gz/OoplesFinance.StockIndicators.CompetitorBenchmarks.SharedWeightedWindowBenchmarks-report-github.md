```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean     | Error    | StdDev   | Gen0    | Gen1   | Allocated  |
|------------------ |---------- |------ |---------:|---------:|---------:|--------:|-------:|-----------:|
| **BuilderFull**       | **Dwma**      | **1000**  | **131.1 μs** | **27.53 μs** | **18.21 μs** |       **-** |      **-** |  **173.26 KB** |
| BuilderLatestOnly | Dwma      | 1000  | 127.9 μs |  5.76 μs |  3.81 μs |  0.9766 |      - |  125.63 KB |
| **BuilderFull**       | **Dwma**      | **10000** | **863.8 μs** | **71.26 μs** | **42.41 μs** | **15.6250** | **7.8125** |    **1609 KB** |
| BuilderLatestOnly | Dwma      | 10000 | 781.4 μs | 76.87 μs | 50.85 μs |  7.8125 |      - | 1139.17 KB |
