```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error    | StdDev   | Gen0   | Gen1   | Allocated |
|------------------ |---------- |------ |----------:|---------:|---------:|-------:|-------:|----------:|
| **BuilderFull**       | **Wma**       | **1000**  |  **20.05 μs** | **0.287 μs** | **0.171 μs** |      **-** |      **-** |  **58.45 KB** |
| BuilderLatestOnly | Wma       | 1000  |  11.68 μs | 2.172 μs | 1.293 μs | 0.1221 |      - |  10.56 KB |
| **BuilderFull**       | **Wma**       | **10000** | **121.89 μs** | **9.092 μs** | **6.014 μs** | **5.8594** | **2.9297** | **550.97 KB** |
| BuilderLatestOnly | Wma       | 10000 | 103.56 μs | 8.541 μs | 5.649 μs | 0.9766 |      - |  80.88 KB |
