```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated  | Alloc Ratio |
|------------------ |---------- |------ |----------:|----------:|----------:|------:|--------:|--------:|-------:|-----------:|------------:|
| **BuilderFull**       | **Wma**       | **1000**  |  **22.04 μs** |  **9.512 μs** |  **4.975 μs** |  **0.23** |    **0.05** |       **-** |      **-** |   **58.45 KB** |        **0.23** |
| BuilderLatestOnly | Wma       | 1000  |  13.11 μs |  1.297 μs |  0.858 μs |  0.14 |    0.01 |  0.1221 |      - |   10.56 KB |        0.04 |
| NativeSingle      | Wma       | 1000  |  97.06 μs |  1.392 μs |  0.829 μs |  1.00 |    0.01 |  2.9297 |      - |  254.32 KB |        1.00 |
| NativeParallel    | Wma       | 1000  |  84.70 μs |  2.452 μs |  1.622 μs |  0.87 |    0.02 |  2.9297 |      - |  261.98 KB |        1.03 |
|                   |           |       |           |           |           |       |         |         |        |            |             |
| **BuilderFull**       | **Wma**       | **10000** | **116.96 μs** |  **6.704 μs** |  **3.989 μs** |  **0.12** |    **0.00** |  **5.8594** | **3.9063** |  **550.97 KB** |        **0.21** |
| BuilderLatestOnly | Wma       | 10000 | 101.58 μs |  9.652 μs |  6.384 μs |  0.10 |    0.01 |  0.9766 |      - |   80.88 KB |        0.03 |
| NativeSingle      | Wma       | 10000 | 998.37 μs | 27.423 μs | 16.319 μs |  1.00 |    0.02 | 31.2500 |      - | 2564.14 KB |        1.00 |
| NativeParallel    | Wma       | 10000 | 620.41 μs | 14.155 μs |  9.363 μs |  0.62 |    0.01 | 31.2500 | 3.9063 | 2571.95 KB |        1.00 |
