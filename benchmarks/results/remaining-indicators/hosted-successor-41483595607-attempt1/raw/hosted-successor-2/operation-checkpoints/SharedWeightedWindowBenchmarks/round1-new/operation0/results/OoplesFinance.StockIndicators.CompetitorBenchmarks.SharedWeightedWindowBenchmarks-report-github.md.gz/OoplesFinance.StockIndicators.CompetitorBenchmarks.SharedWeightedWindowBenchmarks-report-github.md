```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error    | StdDev   | Gen0   | Gen1   | Allocated |
|------------------ |---------- |------ |----------:|---------:|---------:|-------:|-------:|----------:|
| **BuilderFull**       | **Wma**       | **1000**  |  **18.19 μs** | **0.718 μs** | **0.427 μs** | **0.4883** |      **-** |  **58.45 KB** |
| BuilderLatestOnly | Wma       | 1000  |  12.91 μs | 1.125 μs | 0.744 μs | 0.1221 |      - |  10.56 KB |
| **BuilderFull**       | **Wma**       | **10000** | **114.55 μs** | **4.730 μs** | **2.474 μs** | **5.8594** | **2.9297** | **550.97 KB** |
| BuilderLatestOnly | Wma       | 10000 | 101.92 μs | 7.958 μs | 5.264 μs | 0.9766 |      - |  80.88 KB |
