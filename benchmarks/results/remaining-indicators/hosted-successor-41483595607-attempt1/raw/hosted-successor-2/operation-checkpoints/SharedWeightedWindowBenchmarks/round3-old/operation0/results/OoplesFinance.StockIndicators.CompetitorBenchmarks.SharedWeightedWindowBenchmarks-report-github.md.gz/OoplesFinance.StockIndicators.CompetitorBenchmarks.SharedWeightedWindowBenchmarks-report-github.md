```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev   | Gen0   | Gen1   | Allocated |
|------------------ |---------- |------ |----------:|----------:|---------:|-------:|-------:|----------:|
| **BuilderFull**       | **Wma**       | **1000**  |  **18.14 μs** |  **0.789 μs** | **0.469 μs** | **0.4883** |      **-** |  **58.45 KB** |
| BuilderLatestOnly | Wma       | 1000  |  12.38 μs |  1.154 μs | 0.604 μs | 0.1221 |      - |  10.56 KB |
| **BuilderFull**       | **Wma**       | **10000** | **125.23 μs** | **12.935 μs** | **8.556 μs** | **5.8594** | **2.9297** | **550.97 KB** |
| BuilderLatestOnly | Wma       | 10000 |  98.77 μs |  7.846 μs | 4.669 μs | 0.9766 |      - |  80.88 KB |
