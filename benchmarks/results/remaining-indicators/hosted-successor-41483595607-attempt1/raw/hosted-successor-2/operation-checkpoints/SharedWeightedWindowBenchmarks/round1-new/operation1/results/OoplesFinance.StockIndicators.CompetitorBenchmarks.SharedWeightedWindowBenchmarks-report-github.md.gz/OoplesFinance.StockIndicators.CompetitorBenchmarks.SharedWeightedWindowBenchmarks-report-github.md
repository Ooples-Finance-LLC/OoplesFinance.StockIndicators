```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean     | Error    | StdDev   | Gen0    | Gen1   | Allocated  |
|------------------ |---------- |------ |---------:|---------:|---------:|--------:|-------:|-----------:|
| **BuilderFull**       | **Dwma**      | **1000**  | **140.9 μs** | **23.53 μs** | **15.56 μs** |       **-** |      **-** |  **173.26 KB** |
| BuilderLatestOnly | Dwma      | 1000  | 131.6 μs |  7.44 μs |  4.92 μs |  0.9766 |      - |  125.63 KB |
| **BuilderFull**       | **Dwma**      | **10000** | **820.8 μs** | **96.45 μs** | **57.40 μs** | **15.6250** | **7.8125** | **1609.01 KB** |
| BuilderLatestOnly | Dwma      | 10000 | 762.9 μs | 20.25 μs | 10.59 μs |  7.8125 |      - | 1139.17 KB |
