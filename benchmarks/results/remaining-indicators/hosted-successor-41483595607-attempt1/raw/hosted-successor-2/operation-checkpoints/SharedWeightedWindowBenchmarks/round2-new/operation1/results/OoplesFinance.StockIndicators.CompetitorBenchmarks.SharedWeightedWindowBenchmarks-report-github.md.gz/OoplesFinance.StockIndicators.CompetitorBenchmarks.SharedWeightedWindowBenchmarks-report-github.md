```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error    | StdDev   | Ratio | RatioSD | Gen0    | Gen1   | Allocated  | Alloc Ratio |
|------------------ |---------- |------ |-----------:|---------:|---------:|------:|--------:|--------:|-------:|-----------:|------------:|
| **BuilderFull**       | **Dwma**      | **1000**  |   **127.1 μs** | **33.32 μs** | **22.04 μs** |  **0.59** |    **0.10** |       **-** |      **-** |  **173.26 KB** |        **0.32** |
| BuilderLatestOnly | Dwma      | 1000  |   126.7 μs |  3.33 μs |  1.74 μs |  0.59 |    0.01 |  0.9766 |      - |  125.63 KB |        0.23 |
| NativeSingle      | Dwma      | 1000  |   215.6 μs |  3.08 μs |  2.04 μs |  1.00 |    0.01 |  5.8594 |      - |  540.12 KB |        1.00 |
| NativeParallel    | Dwma      | 1000  |   164.7 μs |  5.44 μs |  3.60 μs |  0.76 |    0.02 |  6.8359 |      - |  588.75 KB |        1.09 |
|                   |           |       |            |          |          |       |         |         |        |            |             |
| **BuilderFull**       | **Dwma**      | **10000** |   **785.1 μs** | **51.39 μs** | **26.88 μs** |  **0.36** |    **0.01** | **15.6250** | **7.8125** | **1609.01 KB** |        **0.30** |
| BuilderLatestOnly | Dwma      | 10000 |   776.0 μs | 71.23 μs | 47.11 μs |  0.36 |    0.02 | 11.7188 |      - | 1139.15 KB |        0.21 |
| NativeSingle      | Dwma      | 10000 | 2,152.5 μs | 39.31 μs | 26.00 μs |  1.00 |    0.02 | 62.5000 |      - | 5441.01 KB |        1.00 |
| NativeParallel    | Dwma      | 10000 | 1,294.4 μs | 45.53 μs | 30.12 μs |  0.60 |    0.02 | 62.5000 | 7.8125 | 5489.94 KB |        1.01 |
