```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetCmf** | **1000**  |    **65.73 μs** |  **1.713 μs** |  **1.019 μs** |  **0.67** |    **0.01** |       **-** |       **-** |       **-** |   **85.73 KB** |        **0.29** |
| BuilderLatestOnly | Skender.GetCmf | 1000  |    66.20 μs |  0.888 μs |  0.464 μs |  0.67 |    0.01 |       - |       - |       - |   38.12 KB |        0.13 |
| NativeSingle      | Skender.GetCmf | 1000  |    98.82 μs |  0.616 μs |  0.367 μs |  1.00 |    0.00 |  2.9297 |       - |       - |   297.9 KB |        1.00 |
| NativeParallel    | Skender.GetCmf | 1000  |    88.76 μs |  1.919 μs |  1.269 μs |  0.90 |    0.01 |  3.9063 |  0.9766 |       - |   326.3 KB |        1.10 |
|                   |                |       |             |           |           |       |         |         |         |         |            |             |
| **BuilderFull**       | **Skender.GetCmf** | **10000** |   **425.41 μs** | **35.089 μs** | **20.881 μs** |  **0.32** |    **0.02** |  **7.8125** |  **3.9063** |       **-** |  **789.22 KB** |        **0.27** |
| BuilderLatestOnly | Skender.GetCmf | 10000 |   446.39 μs | 61.093 μs | 40.409 μs |  0.34 |    0.03 |  3.9063 |       - |       - |   319.4 KB |        0.11 |
| NativeSingle      | Skender.GetCmf | 10000 | 1,325.08 μs | 39.964 μs | 20.902 μs |  1.00 |    0.02 | 46.8750 | 46.8750 | 46.8750 | 2970.18 KB |        1.00 |
| NativeParallel    | Skender.GetCmf | 10000 |   676.39 μs | 58.489 μs | 38.687 μs |  0.51 |    0.03 | 39.0625 | 31.2500 |       - | 3068.51 KB |        1.03 |
