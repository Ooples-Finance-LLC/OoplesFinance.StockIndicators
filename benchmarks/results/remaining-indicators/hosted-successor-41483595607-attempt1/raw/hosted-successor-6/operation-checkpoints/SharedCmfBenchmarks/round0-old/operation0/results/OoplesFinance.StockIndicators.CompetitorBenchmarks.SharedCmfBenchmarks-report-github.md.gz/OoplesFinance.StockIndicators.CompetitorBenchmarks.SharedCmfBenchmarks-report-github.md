```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Gen0   | Gen1   | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|-------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetCmf** | **1000**  |  **65.89 μs** |  **2.363 μs** |  **1.406 μs** |      **-** |      **-** |  **85.73 KB** |
| BuilderLatestOnly | Skender.GetCmf | 1000  |  63.85 μs |  1.956 μs |  1.164 μs |      - |      - |  38.12 KB |
| **BuilderFull**       | **Skender.GetCmf** | **10000** | **421.13 μs** | **36.869 μs** | **24.387 μs** | **7.8125** | **3.9063** |  **789.2 KB** |
| BuilderLatestOnly | Skender.GetCmf | 10000 | 391.41 μs | 55.116 μs | 36.456 μs | 3.9063 |      - |  319.4 KB |
