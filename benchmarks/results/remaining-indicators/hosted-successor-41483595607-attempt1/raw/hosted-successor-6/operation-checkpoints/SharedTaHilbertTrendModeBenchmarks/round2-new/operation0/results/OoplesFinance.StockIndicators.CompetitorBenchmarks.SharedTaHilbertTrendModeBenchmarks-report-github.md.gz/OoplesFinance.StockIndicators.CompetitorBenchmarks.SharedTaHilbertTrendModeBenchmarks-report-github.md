```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **3,357.1 μs** |  **70.17 μs** |  **41.76 μs** |  **6.83** |    **0.08** |  **71.75 KB** |       **15.16** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  2,078.7 μs |  10.24 μs |   6.10 μs |  4.23 |    0.01 |  24.07 KB |        5.09 |
| NativeSingle      | TaLib(...)dMode [27] | 1000  |    491.6 μs |   1.49 μs |   0.89 μs |  1.00 |    0.00 |   4.73 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 1000  |    653.6 μs |  37.31 μs |  24.68 μs |  1.33 |    0.05 |   17.4 KB |        3.68 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **21,422.6 μs** |  **80.71 μs** |  **48.03 μs** |  **4.03** |    **0.03** | **636.03 KB** |       **15.86** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 21,419.5 μs |  61.61 μs |  36.66 μs |  4.03 |    0.03 | 166.26 KB |        4.15 |
| NativeSingle      | TaLib(...)dMode [27] | 10000 |  5,310.4 μs |  59.69 μs |  39.48 μs |  1.00 |    0.01 |   40.1 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 10000 |  6,704.3 μs | 181.55 μs | 108.04 μs |  1.26 |    0.02 | 140.95 KB |        3.52 |
