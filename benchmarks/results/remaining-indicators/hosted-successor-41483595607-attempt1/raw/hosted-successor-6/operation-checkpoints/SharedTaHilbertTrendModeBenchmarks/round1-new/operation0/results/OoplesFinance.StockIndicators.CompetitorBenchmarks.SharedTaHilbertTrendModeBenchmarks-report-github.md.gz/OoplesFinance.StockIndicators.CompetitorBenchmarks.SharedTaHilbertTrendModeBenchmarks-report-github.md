```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **3.293 ms** | **0.0456 ms** | **0.0271 ms** |  **71.75 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  2.053 ms | 0.0079 ms | 0.0052 ms |  24.07 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **21.589 ms** | **0.0706 ms** | **0.0369 ms** | **636.01 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 21.224 ms | 0.0745 ms | 0.0493 ms | 166.26 KB |
