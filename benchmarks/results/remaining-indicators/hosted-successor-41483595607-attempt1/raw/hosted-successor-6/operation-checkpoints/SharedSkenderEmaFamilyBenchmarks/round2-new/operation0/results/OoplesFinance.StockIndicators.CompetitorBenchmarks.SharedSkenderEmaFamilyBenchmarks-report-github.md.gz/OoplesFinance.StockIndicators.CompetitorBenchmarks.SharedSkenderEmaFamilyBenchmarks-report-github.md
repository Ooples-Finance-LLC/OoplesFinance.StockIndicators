```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **376.13 μs** |   **3.885 μs** |   **2.032 μs** |  **8.31** |    **0.06** |        **-** |        **-** |        **-** |  **128.44 KB** |        **0.40** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   373.40 μs |   4.883 μs |   3.230 μs |  8.25 |    0.08 |        - |        - |        - |    80.9 KB |        0.25 |
| NativeSingle      | Skender.GetMacd | 1000  |    45.26 μs |   0.394 μs |   0.206 μs |  1.00 |    0.01 |   3.9063 |   1.7090 |        - |  324.53 KB |        1.00 |
| NativeParallel    | Skender.GetMacd | 1000  |    98.19 μs |   2.393 μs |   1.583 μs |  2.17 |    0.03 |  10.7422 |   4.8828 |        - |  826.62 KB |        2.55 |
|                   |                 |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **3,938.29 μs** |  **50.576 μs** |  **33.453 μs** |  **3.62** |    **0.04** |        **-** |        **-** |        **-** | **1254.01 KB** |        **0.36** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 3,861.08 μs |  30.935 μs |  16.180 μs |  3.55 |    0.03 |        - |        - |        - |  784.24 KB |        0.23 |
| NativeSingle      | Skender.GetMacd | 10000 | 1,088.46 μs |  13.007 μs |   7.740 μs |  1.00 |    0.01 | 218.7500 | 218.7500 | 218.7500 | 3443.11 KB |        1.00 |
| NativeParallel    | Skender.GetMacd | 10000 | 4,345.67 μs | 568.948 μs | 376.324 μs |  3.99 |    0.33 | 375.0000 | 375.0000 | 312.5000 | 8556.82 KB |        2.49 |
