```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **238.4 μs** |  **1.32 μs** |  **0.78 μs** |   **89.1 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   235.0 μs |  2.24 μs |  1.34 μs |   41.5 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **2,501.0 μs** |  **6.86 μs** |  **3.59 μs** | **862.99 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 2,452.0 μs | 20.41 μs | 12.15 μs | 393.17 KB |
