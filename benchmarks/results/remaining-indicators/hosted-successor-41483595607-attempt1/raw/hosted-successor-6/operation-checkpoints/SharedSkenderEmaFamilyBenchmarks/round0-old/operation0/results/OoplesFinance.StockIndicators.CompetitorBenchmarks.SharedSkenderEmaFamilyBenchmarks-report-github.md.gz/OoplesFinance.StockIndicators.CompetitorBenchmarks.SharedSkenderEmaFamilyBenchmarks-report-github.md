```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev  | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **373.8 μs** |  **0.96 μs** | **0.50 μs** | **128.48 KB** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   377.3 μs |  2.40 μs | 1.43 μs |  80.88 KB |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **3,817.4 μs** | **10.13 μs** | **6.03 μs** |   **1254 KB** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 3,775.7 μs |  8.01 μs | 4.19 μs | 784.22 KB |
