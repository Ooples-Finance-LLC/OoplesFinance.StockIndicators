```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated  |
|------------------ |--------------- |------ |-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **447.8 μs** | **14.89 μs** |  **9.85 μs** |  **104.94 KB** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   445.0 μs | 16.76 μs | 11.08 μs |   57.39 KB |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **4,589.6 μs** | **60.89 μs** | **36.23 μs** | **1019.53 KB** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 4,503.1 μs | 63.49 μs | 37.78 μs |  549.76 KB |
