```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |---------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **410.7 μs** |   **8.52 μs** |  **5.07 μs** |  **89.15 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   402.9 μs |   3.59 μs |  2.14 μs |   41.6 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **4,147.8 μs** |  **22.51 μs** | **11.77 μs** | **863.14 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 4,356.5 μs | 116.93 μs | 77.34 μs | 393.39 KB |
