```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev  | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **444.5 μs** | **14.59 μs** | **8.68 μs** | **104.97 KB** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   440.3 μs |  1.86 μs | 0.97 μs |  57.39 KB |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **4,555.5 μs** |  **9.14 μs** | **4.78 μs** | **1019.6 KB** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 4,521.7 μs | 13.95 μs | 8.30 μs | 549.79 KB |
