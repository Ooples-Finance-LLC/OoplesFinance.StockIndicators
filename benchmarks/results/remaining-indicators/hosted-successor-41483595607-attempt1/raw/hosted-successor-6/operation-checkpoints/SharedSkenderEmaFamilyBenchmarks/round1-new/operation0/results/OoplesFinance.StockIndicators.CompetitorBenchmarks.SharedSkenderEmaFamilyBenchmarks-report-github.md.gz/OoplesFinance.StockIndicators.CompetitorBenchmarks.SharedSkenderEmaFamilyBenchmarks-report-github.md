```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Allocated  |
|------------------ |---------------- |------ |-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **378.6 μs** |  **5.43 μs** |  **2.84 μs** |  **128.48 KB** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   373.8 μs |  3.49 μs |  2.31 μs |    80.9 KB |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **3,904.8 μs** | **23.42 μs** | **12.25 μs** | **1254.06 KB** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 3,935.1 μs | 51.33 μs | 26.85 μs |  784.26 KB |
