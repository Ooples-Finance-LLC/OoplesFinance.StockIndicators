```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **239.88 μs** |   **2.071 μs** |   **1.083 μs** |  **9.91** |    **0.09** |        **-** |        **-** |        **-** |    **89.1 KB** |        **0.73** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   233.43 μs |   2.439 μs |   1.451 μs |  9.65 |    0.10 |        - |        - |        - |    41.5 KB |        0.34 |
| NativeSingle      | Skender.GetTrix | 1000  |    24.20 μs |   0.361 μs |   0.215 μs |  1.00 |    0.01 |        - |        - |        - |   121.5 KB |        1.00 |
| NativeParallel    | Skender.GetTrix | 1000  |    52.66 μs |   2.691 μs |   1.780 μs |  2.18 |    0.07 |   3.9063 |   1.4648 |        - |  312.32 KB |        2.57 |
|                   |                 |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **2,465.80 μs** |   **2.773 μs** |   **1.450 μs** |  **4.78** |    **0.03** |        **-** |        **-** |        **-** |  **862.99 KB** |        **0.71** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 2,424.40 μs |   7.443 μs |   3.893 μs |  4.70 |    0.03 |        - |        - |        - |  393.17 KB |        0.32 |
| NativeSingle      | Skender.GetTrix | 10000 |   515.64 μs |   4.984 μs |   2.966 μs |  1.00 |    0.01 |  97.6563 |  97.6563 |  97.6563 | 1212.12 KB |        1.00 |
| NativeParallel    | Skender.GetTrix | 10000 | 1,653.37 μs | 457.814 μs | 302.816 μs |  3.21 |    0.56 | 171.8750 | 171.8750 | 156.2500 | 3109.33 KB |        2.57 |
