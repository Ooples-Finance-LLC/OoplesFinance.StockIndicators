```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Allocated  |
|------------------ |---------------- |------ |-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **382.4 μs** | **11.28 μs** |  **6.71 μs** |  **128.48 KB** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   375.7 μs |  2.47 μs |  1.29 μs |    80.9 KB |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **3,847.2 μs** | **22.85 μs** | **11.95 μs** | **1254.03 KB** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 3,802.5 μs | 23.37 μs | 15.46 μs |  784.23 KB |
