```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **436.30 μs** |   **2.999 μs** |   **1.568 μs** |  **8.45** |    **0.07** |        **-** |        **-** |        **-** |  **104.97 KB** |        **0.37** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   432.98 μs |   1.629 μs |   0.970 μs |  8.38 |    0.07 |        - |        - |        - |   57.39 KB |        0.20 |
| NativeSingle      | Skender.GetPvo | 1000  |    51.65 μs |   0.847 μs |   0.443 μs |  1.00 |    0.01 |   3.4180 |   1.4648 |        - |  285.61 KB |        1.00 |
| NativeParallel    | Skender.GetPvo | 1000  |   107.75 μs |   1.716 μs |   0.898 μs |  2.09 |    0.02 |   8.7891 |   3.9063 |        - |  729.53 KB |        2.55 |
|                   |                |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **4,549.58 μs** |  **20.312 μs** |  **10.624 μs** |  **4.51** |    **0.04** |        **-** |        **-** |        **-** | **1019.56 KB** |        **0.33** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 4,517.25 μs |  19.447 μs |  10.171 μs |  4.47 |    0.04 |        - |        - |        - |  549.78 KB |        0.18 |
| NativeSingle      | Skender.GetPvo | 10000 | 1,009.52 μs |  15.154 μs |   9.018 μs |  1.00 |    0.01 | 164.0625 | 164.0625 | 164.0625 | 3052.15 KB |        1.00 |
| NativeParallel    | Skender.GetPvo | 10000 | 3,190.79 μs | 416.941 μs | 248.115 μs |  3.16 |    0.23 | 312.5000 | 312.5000 | 250.0000 | 7581.81 KB |        2.48 |
