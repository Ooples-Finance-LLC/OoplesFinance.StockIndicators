```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev  | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **411.5 μs** |  **9.80 μs** | **6.48 μs** |  **89.18 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   404.9 μs |  0.98 μs | 0.51 μs |   41.6 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **4,138.5 μs** | **14.70 μs** | **8.75 μs** |  **863.2 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 4,138.3 μs | 14.00 μs | 8.33 μs | 393.37 KB |
