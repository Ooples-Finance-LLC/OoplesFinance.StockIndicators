```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)lysis [22]** | **1000**  |   **280.14 μs** | **100.127 μs** |  **66.228 μs** |  **4.00** |    **0.90** |       **-** |       **-** |       **-** |   **144.2 KB** |        **0.78** |
| BuilderLatestOnly | Skend(...)lysis [22] | 1000  |   205.76 μs |  21.088 μs |  13.949 μs |  2.94 |    0.19 |       - |       - |       - |   96.55 KB |        0.52 |
| NativeSingle      | Skend(...)lysis [22] | 1000  |    70.05 μs |   0.369 μs |   0.193 μs |  1.00 |    0.00 |  1.9531 |       - |       - |  184.11 KB |        1.00 |
| NativeParallel    | Skend(...)lysis [22] | 1000  |    54.38 μs |   5.273 μs |   3.488 μs |  0.78 |    0.05 |  2.4414 |  0.4883 |       - |  204.15 KB |        1.11 |
|                   |                      |       |             |            |            |       |         |         |         |         |            |             |
| **BuilderFull**       | **Skend(...)lysis [22]** | **10000** | **2,132.01 μs** | **115.590 μs** |  **76.456 μs** |  **1.82** |    **0.13** | **15.6250** |       **-** |       **-** | **1272.58 KB** |        **0.69** |
| BuilderLatestOnly | Skend(...)lysis [22] | 10000 | 2,222.26 μs | 361.293 μs | 238.973 μs |  1.90 |    0.23 |       - |       - |       - |  802.76 KB |        0.44 |
| NativeSingle      | Skend(...)lysis [22] | 10000 | 1,176.31 μs | 115.183 μs |  76.186 μs |  1.00 |    0.09 | 93.7500 | 78.1250 | 78.1250 | 1837.23 KB |        1.00 |
| NativeParallel    | Skend(...)lysis [22] | 10000 |   477.86 μs |  72.948 μs |  48.251 μs |  0.41 |    0.05 | 23.4375 | 15.6250 |       - | 1926.84 KB |        1.05 |
