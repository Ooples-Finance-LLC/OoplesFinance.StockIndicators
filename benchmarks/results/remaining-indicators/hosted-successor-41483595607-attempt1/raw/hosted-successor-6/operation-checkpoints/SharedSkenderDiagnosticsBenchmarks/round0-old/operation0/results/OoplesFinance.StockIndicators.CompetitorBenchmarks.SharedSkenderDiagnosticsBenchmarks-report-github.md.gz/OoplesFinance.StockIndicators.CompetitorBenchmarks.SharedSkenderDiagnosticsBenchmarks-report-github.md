```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Gen0     | Gen1    | Allocated  |
|------------------ |--------------- |------ |-----------:|----------:|----------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetPrs** | **1000**  |   **491.3 μs** | **123.00 μs** |  **81.36 μs** |        **-** |       **-** |  **990.99 KB** |
| BuilderLatestOnly | Skender.GetPrs | 1000  |   322.9 μs |  55.17 μs |  36.49 μs |   7.8125 |       - |  943.41 KB |
| **BuilderFull**       | **Skender.GetPrs** | **10000** | **3,047.4 μs** | **223.97 μs** | **148.14 μs** | **109.3750** | **93.7500** | **9429.01 KB** |
| BuilderLatestOnly | Skender.GetPrs | 10000 | 3,026.9 μs | 193.28 μs | 127.84 μs | 109.3750 | 93.7500 | 8959.17 KB |
