```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|-----------:|
| **BuilderFull**       | **Skend(...)lysis [22]** | **1000**  |   **343.6 μs** |  **78.97 μs** |  **46.99 μs** |       **-** |  **144.16 KB** |
| BuilderLatestOnly | Skend(...)lysis [22] | 1000  |   220.8 μs |  37.38 μs |  24.72 μs |       - |   96.56 KB |
| **BuilderFull**       | **Skend(...)lysis [22]** | **10000** | **2,137.3 μs** | **179.66 μs** | **106.91 μs** | **15.6250** | **1272.56 KB** |
| BuilderLatestOnly | Skend(...)lysis [22] | 10000 | 2,238.8 μs | 359.75 μs | 237.95 μs |       - |  802.73 KB |
