```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|-----------:|
| **BuilderFull**       | **Skend(...)lysis [22]** | **1000**  |   **282.7 μs** | **115.68 μs** |  **76.52 μs** |       **-** |   **144.2 KB** |
| BuilderLatestOnly | Skend(...)lysis [22] | 1000  |   223.4 μs |  43.13 μs |  28.53 μs |       - |   96.56 KB |
| **BuilderFull**       | **Skend(...)lysis [22]** | **10000** | **2,232.4 μs** | **283.68 μs** | **187.64 μs** | **15.6250** | **1272.58 KB** |
| BuilderLatestOnly | Skend(...)lysis [22] | 10000 | 2,186.9 μs | 271.74 μs | 161.71 μs |       - |  802.74 KB |
