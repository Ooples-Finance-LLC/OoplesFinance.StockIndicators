```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Gen0     | Gen1    | Allocated  |
|------------------ |--------------- |------ |-----------:|----------:|----------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetPrs** | **1000**  |   **458.7 μs** | **149.16 μs** |  **98.66 μs** |        **-** |       **-** |  **990.99 KB** |
| BuilderLatestOnly | Skender.GetPrs | 1000  |   324.8 μs |  52.40 μs |  31.18 μs |   7.8125 |       - |  943.41 KB |
| **BuilderFull**       | **Skender.GetPrs** | **10000** | **2,965.7 μs** | **159.33 μs** | **105.39 μs** | **109.3750** | **93.7500** | **9429.03 KB** |
| BuilderLatestOnly | Skender.GetPrs | 10000 | 3,071.7 μs | 241.99 μs | 160.06 μs | 109.3750 | 93.7500 |  8959.2 KB |
