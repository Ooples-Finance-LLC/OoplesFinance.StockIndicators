```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|-----------:|
| **BuilderFull**       | **Skend(...)lysis [22]** | **1000**  |   **233.4 μs** |   **5.46 μs** |   **3.25 μs** |       **-** |  **144.21 KB** |
| BuilderLatestOnly | Skend(...)lysis [22] | 1000  |   214.1 μs |  25.29 μs |  16.72 μs |       - |   96.56 KB |
| **BuilderFull**       | **Skend(...)lysis [22]** | **10000** | **2,145.6 μs** | **242.86 μs** | **144.52 μs** | **15.6250** | **1272.56 KB** |
| BuilderLatestOnly | Skend(...)lysis [22] | 10000 | 2,135.5 μs | 179.45 μs | 118.70 μs |       - |  802.77 KB |
