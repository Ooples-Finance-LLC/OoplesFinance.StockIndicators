```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetPrs** | **1000**  |   **470.61 μs** | **189.163 μs** | **125.119 μs** | **11.44** |    **2.91** |        **-** |        **-** |        **-** |  **991.08 KB** |        **6.01** |
| BuilderLatestOnly | Skender.GetPrs | 1000  |   317.82 μs |  39.650 μs |  23.595 μs |  7.73 |    0.55 |   7.8125 |        - |        - |  943.41 KB |        5.72 |
| NativeSingle      | Skender.GetPrs | 1000  |    41.14 μs |   0.686 μs |   0.359 μs |  1.00 |    0.01 |   1.9531 |   0.2441 |        - |  164.79 KB |        1.00 |
| NativeParallel    | Skender.GetPrs | 1000  |    30.42 μs |   1.683 μs |   1.113 μs |  0.74 |    0.03 |   2.4414 |   0.4883 |        - |  184.81 KB |        1.12 |
|                   |                |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetPrs** | **10000** | **3,075.19 μs** | **257.580 μs** | **170.373 μs** |  **4.17** |    **0.33** | **109.3750** |  **93.7500** |        **-** | **9429.04 KB** |        **5.74** |
| BuilderLatestOnly | Skender.GetPrs | 10000 | 2,842.82 μs |  67.517 μs |  35.313 μs |  3.85 |    0.23 |  93.7500 |  62.5000 |        - | 8959.35 KB |        5.45 |
| NativeSingle      | Skender.GetPrs | 10000 |   740.50 μs |  70.447 μs |  46.596 μs |  1.00 |    0.08 | 164.0625 | 152.3438 | 152.3438 | 1643.24 KB |        1.00 |
| NativeParallel    | Skender.GetPrs | 10000 |   313.09 μs |  19.950 μs |  11.872 μs |  0.42 |    0.03 |  21.4844 |  13.6719 |        - |  1731.7 KB |        1.05 |
