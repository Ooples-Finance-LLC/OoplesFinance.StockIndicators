```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Gen0     | Gen1    | Allocated  |
|------------------ |--------------- |------ |-----------:|----------:|----------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetPrs** | **1000**  |   **398.6 μs** | **156.89 μs** | **103.77 μs** |        **-** |       **-** |  **991.09 KB** |
| BuilderLatestOnly | Skender.GetPrs | 1000  |   315.8 μs |  47.40 μs |  28.21 μs |   7.8125 |       - |  943.41 KB |
| **BuilderFull**       | **Skender.GetPrs** | **10000** | **2,976.3 μs** | **287.34 μs** | **190.06 μs** | **109.3750** | **93.7500** | **9429.02 KB** |
| BuilderLatestOnly | Skender.GetPrs | 10000 | 3,068.3 μs | 458.82 μs | 303.48 μs |  93.7500 | 62.5000 |  8959.3 KB |
