```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean       | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-----------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ma** | **129.611 μs** | **15.6214 μs** |  **9.2960 μs** |  **1.00** |    **0.10** |  **112.59 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ma |   8.700 μs |  0.7608 μs |  0.4528 μs |  0.07 |    0.01 |   33.41 KB |        0.30 |
|            |       |                    |            |            |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ma** | **863.522 μs** | **25.0785 μs** | **14.9238 μs** |  **1.00** |    **0.02** | **1043.93 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ma |  50.180 μs |  5.5140 μs |  3.6472 μs |  0.06 |    0.00 |  330.66 KB |        0.32 |
