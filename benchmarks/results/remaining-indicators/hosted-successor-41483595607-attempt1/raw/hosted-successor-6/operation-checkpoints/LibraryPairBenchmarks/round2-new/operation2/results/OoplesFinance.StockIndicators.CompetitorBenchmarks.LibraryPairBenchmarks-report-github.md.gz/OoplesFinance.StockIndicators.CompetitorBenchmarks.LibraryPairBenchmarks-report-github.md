```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Cci** |   **200.14 μs** | **18.591 μs** | **11.063 μs** |  **1.00** |    **0.07** |  **106.42 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Cci |    24.47 μs |  0.606 μs |  0.361 μs |  0.12 |    0.01 |   40.78 KB |        0.38 |
|            |       |                     |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Cci** | **1,775.32 μs** | **14.295 μs** |  **8.507 μs** |  **1.00** |    **0.01** | **1037.76 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Cci |   214.38 μs |  1.938 μs |  1.282 μs |  0.12 |    0.00 |   331.1 KB |        0.32 |
