```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)bands [22]** | **133.87 μs** | **12.634 μs** |  **7.518 μs** |  **1.00** |    **0.08** |  **205.02 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)bands [22] |  21.19 μs |  0.864 μs |  0.452 μs |  0.16 |    0.01 |  106.18 KB |        0.52 |
|            |       |                      |           |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)bands [22]** | **943.26 μs** | **40.400 μs** | **26.722 μs** |  **1.00** |    **0.04** | **1997.41 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)bands [22] | 153.35 μs |  1.871 μs |  0.978 μs |  0.16 |    0.00 |  975.27 KB |        0.49 |
