```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Dx** |   **608.35 μs** | **59.056 μs** | **39.062 μs** |  **1.00** |    **0.08** |  **105.67 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Dx |    20.06 μs |  0.411 μs |  0.272 μs |  0.03 |    0.00 |    40.6 KB |        0.38 |
|            |       |                    |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Dx** | **5,507.03 μs** | **41.362 μs** | **24.614 μs** |  **1.00** |    **0.01** | **1033.45 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Dx |   179.81 μs | 15.798 μs | 10.450 μs |  0.03 |    0.00 |     329 KB |        0.32 |
