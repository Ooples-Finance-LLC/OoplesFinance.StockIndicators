```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error    | StdDev   | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|---------:|---------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tSine [22]** |  **1,667.1 μs** | **22.33 μs** | **13.29 μs** |  **1.00** |  **166.46 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tSine [22] |    490.0 μs | 16.91 μs | 11.18 μs |  0.29 |   74.56 KB |        0.45 |
|            |       |                      |             |          |          |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)tSine [22]** | **16,463.1 μs** | **74.01 μs** | **44.04 μs** |  **1.00** | **1596.52 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tSine [22] |  5,030.6 μs | 31.51 μs | 20.84 μs |  0.31 |  652.67 KB |        0.41 |
