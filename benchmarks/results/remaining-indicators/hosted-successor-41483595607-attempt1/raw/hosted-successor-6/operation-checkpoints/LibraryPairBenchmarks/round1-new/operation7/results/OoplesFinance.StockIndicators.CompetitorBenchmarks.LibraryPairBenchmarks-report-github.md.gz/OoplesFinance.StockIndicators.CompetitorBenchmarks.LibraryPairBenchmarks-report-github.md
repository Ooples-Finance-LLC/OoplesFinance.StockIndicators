```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId             | Mean     | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |------------------- |---------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Ma** | **122.6 μs** |  **7.46 μs** |  **3.90 μs** |  **1.00** |    **0.04** |  **112.59 KB** |        **1.00** |
|        |       |                    |          |          |          |       |         |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Ma** | **887.8 μs** | **47.06 μs** | **28.01 μs** |  **1.00** |    **0.04** | **1043.93 KB** |        **1.00** |
