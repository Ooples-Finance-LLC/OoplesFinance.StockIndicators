```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Beta** |   **376.66 μs** | **36.252 μs** | **21.573 μs** |  **1.00** |    **0.08** |  **108.38 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Beta |    12.51 μs |  1.534 μs |  0.803 μs |  0.03 |    0.00 |   38.19 KB |        0.35 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Beta** | **3,251.12 μs** | **60.190 μs** | **39.812 μs** |  **1.00** |    **0.02** | **1039.72 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Beta |    95.17 μs |  2.148 μs |  1.123 μs |  0.03 |    0.00 |  330.24 KB |        0.32 |
