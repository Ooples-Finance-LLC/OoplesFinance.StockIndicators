```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error    | StdDev   | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|---------:|---------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Phase [25]** |  **1,643.7 μs** | **25.26 μs** | **15.03 μs** |  **1.00** |  **110.06 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Phase [25] |    453.4 μs | 17.16 μs | 11.35 μs |  0.28 |   41.76 KB |        0.38 |
|            |       |                      |             |          |          |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)Phase [25]** | **16,407.6 μs** | **85.08 μs** | **50.63 μs** |  **1.00** | **1039.15 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Phase [25] |  4,701.1 μs | 26.63 μs | 15.85 μs |  0.29 |  329.83 KB |        0.32 |
