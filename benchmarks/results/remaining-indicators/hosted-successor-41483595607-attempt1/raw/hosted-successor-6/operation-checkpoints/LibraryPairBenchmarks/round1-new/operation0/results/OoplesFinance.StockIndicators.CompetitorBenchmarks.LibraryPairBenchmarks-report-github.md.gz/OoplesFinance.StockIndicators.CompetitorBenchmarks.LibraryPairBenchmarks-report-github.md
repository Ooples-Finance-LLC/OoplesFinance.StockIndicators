```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean     | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |---------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)bands [22]** | **148.6 μs** | **38.80 μs** | **23.09 μs** |  **1.02** |    **0.21** |  **205.02 KB** |        **1.00** |
|        |       |                      |          |          |          |       |         |            |             |
| **Ooples** | **10000** | **TaLib(...)bands [22]** | **925.6 μs** | **89.69 μs** | **53.37 μs** |  **1.00** |    **0.08** | **1997.08 KB** |        **1.00** |
