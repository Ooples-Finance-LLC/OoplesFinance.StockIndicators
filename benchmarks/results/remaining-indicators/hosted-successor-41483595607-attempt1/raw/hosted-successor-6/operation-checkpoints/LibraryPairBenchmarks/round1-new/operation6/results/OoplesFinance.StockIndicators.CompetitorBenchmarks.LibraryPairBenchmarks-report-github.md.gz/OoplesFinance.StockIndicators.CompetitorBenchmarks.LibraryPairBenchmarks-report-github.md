```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |----------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)dMode [27]** |  **2.134 ms** | **0.0099 ms** | **0.0059 ms** |  **1.00** |  **112.68 KB** |        **1.00** |
|        |       |                      |           |           |           |       |            |             |
| **Ooples** | **10000** | **TaLib(...)dMode [27]** | **21.650 ms** | **0.0876 ms** | **0.0521 ms** |  **1.00** | **1040.08 KB** |        **1.00** |
