```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error    | StdDev   | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|---------:|---------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dMode [27]** |  **2,133.9 μs** | **19.55 μs** | **11.63 μs** |  **1.00** |  **112.68 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dMode [27] |    521.5 μs | 21.92 μs | 14.50 μs |  0.24 |    37.2 KB |        0.33 |
|            |       |                      |             |          |          |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)dMode [27]** | **21,491.4 μs** | **98.61 μs** | **58.68 μs** |  **1.00** | **1040.41 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dMode [27] |  5,338.6 μs | 19.25 μs | 12.73 μs |  0.25 |  292.73 KB |        0.28 |
