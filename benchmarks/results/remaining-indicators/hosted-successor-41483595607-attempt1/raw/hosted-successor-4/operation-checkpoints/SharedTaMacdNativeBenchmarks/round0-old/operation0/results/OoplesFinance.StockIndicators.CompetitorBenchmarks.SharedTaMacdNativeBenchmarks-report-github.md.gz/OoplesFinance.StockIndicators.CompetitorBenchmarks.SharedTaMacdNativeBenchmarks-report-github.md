```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **1000**  |   **649.7 μs** | **236.20 μs** | **156.23 μs** |  **31.2500** |        **-** |  **665.07 KB** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 1000  |   506.1 μs |  34.11 μs |  20.30 μs |  31.2500 |        - |   617.5 KB |
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **10000** | **5,276.0 μs** | **429.02 μs** | **283.77 μs** | **375.0000** | **187.5000** | **6140.92 KB** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 10000 | 5,074.1 μs | 479.63 μs | 317.24 μs | 343.7500 | 156.2500 |  5671.1 KB |
