```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **1000**  |   **445.80 μs** |  **2.638 μs** |  **1.380 μs** | **34.08** |    **0.93** |       **-** |       **-** |   **81.36 KB** |        **2.13** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 1000  |   443.70 μs |  6.151 μs |  3.217 μs | 33.92 |    0.95 |       - |       - |   33.72 KB |        0.88 |
| NativeSingle      | TaLib(...)cdFix [23] | 1000  |    13.09 μs |  0.542 μs |  0.358 μs |  1.00 |    0.04 |  2.3193 |  0.1221 |   38.27 KB |        1.00 |
| NativeParallel    | TaLib(...)cdFix [23] | 1000  |    20.32 μs |  1.454 μs |  0.962 μs |  1.55 |    0.08 |  7.9346 |  1.2207 |  119.47 KB |        3.12 |
|                   |                      |       |             |           |           |       |         |         |         |            |             |
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **10000** | **4,430.41 μs** | **40.906 μs** | **24.343 μs** | **35.15** |    **0.85** | **31.2500** |       **-** |  **785.03 KB** |        **2.01** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 10000 | 4,360.81 μs | 28.983 μs | 17.247 μs | 34.60 |    0.83 |       - |       - |   315.2 KB |        0.81 |
| NativeSingle      | TaLib(...)cdFix [23] | 10000 |   126.11 μs |  4.690 μs |  3.102 μs |  1.00 |    0.03 | 23.4375 |       - |  389.84 KB |        1.00 |
| NativeParallel    | TaLib(...)cdFix [23] | 10000 |   205.88 μs | 11.416 μs |  7.551 μs |  1.63 |    0.07 | 74.2188 | 31.2500 | 1209.33 KB |        3.10 |
