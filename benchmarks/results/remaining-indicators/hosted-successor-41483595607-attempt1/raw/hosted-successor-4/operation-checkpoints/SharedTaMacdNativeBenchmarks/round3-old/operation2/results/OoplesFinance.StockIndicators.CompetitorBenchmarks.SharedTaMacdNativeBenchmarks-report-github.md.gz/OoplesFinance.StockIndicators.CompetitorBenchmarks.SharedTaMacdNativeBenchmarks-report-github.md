```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev  | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **1000**  |   **440.2 μs** |  **9.91 μs** | **5.18 μs** |       **-** |  **81.36 KB** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 1000  |   426.8 μs |  2.14 μs | 1.12 μs |       - |  33.72 KB |
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **10000** | **4,333.7 μs** | **15.13 μs** | **9.00 μs** | **31.2500** | **785.04 KB** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 10000 | 4,297.3 μs | 14.71 μs | 7.69 μs |       - | 315.18 KB |
