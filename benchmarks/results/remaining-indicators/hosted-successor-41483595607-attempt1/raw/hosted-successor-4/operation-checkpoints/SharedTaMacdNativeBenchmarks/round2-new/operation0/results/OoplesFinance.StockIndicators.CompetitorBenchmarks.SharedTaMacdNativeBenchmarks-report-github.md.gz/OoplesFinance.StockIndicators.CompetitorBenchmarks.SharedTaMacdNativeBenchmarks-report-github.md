```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **1000**  |   **779.64 μs** | **289.455 μs** | **151.390 μs** | **74.57** |   **13.84** |  **31.2500** |        **-** |  **665.07 KB** |       **17.30** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 1000  |   518.14 μs |  46.552 μs |  30.791 μs | 49.56 |    3.22 |  35.1563 |   3.9063 |  617.46 KB |       16.06 |
| NativeSingle      | TaLib(...)cdExt [23] | 1000  |    10.46 μs |   0.512 μs |   0.339 μs |  1.00 |    0.04 |   2.3193 |   0.1831 |   38.45 KB |        1.00 |
| NativeParallel    | TaLib(...)cdExt [23] | 1000  |    19.14 μs |   0.419 μs |   0.219 μs |  1.83 |    0.06 |   8.1787 |   1.2207 |  120.22 KB |        3.13 |
|                   |                      |       |             |            |            |       |         |          |          |            |             |
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **10000** | **5,103.36 μs** | **404.436 μs** | **267.509 μs** | **51.32** |    **2.81** | **375.0000** | **187.5000** | **6140.91 KB** |       **15.74** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 10000 | 5,210.78 μs | 426.139 μs | 281.865 μs | 52.40 |    2.95 | 343.7500 | 156.2500 | 5671.11 KB |       14.54 |
| NativeSingle      | TaLib(...)cdExt [23] | 10000 |    99.50 μs |   3.561 μs |   2.355 μs |  1.00 |    0.03 |  23.4375 |   7.8125 |  390.02 KB |        1.00 |
| NativeParallel    | TaLib(...)cdExt [23] | 10000 |   184.65 μs |  11.804 μs |   7.807 μs |  1.86 |    0.09 |  76.1719 |  33.2031 | 1210.08 KB |        3.10 |
