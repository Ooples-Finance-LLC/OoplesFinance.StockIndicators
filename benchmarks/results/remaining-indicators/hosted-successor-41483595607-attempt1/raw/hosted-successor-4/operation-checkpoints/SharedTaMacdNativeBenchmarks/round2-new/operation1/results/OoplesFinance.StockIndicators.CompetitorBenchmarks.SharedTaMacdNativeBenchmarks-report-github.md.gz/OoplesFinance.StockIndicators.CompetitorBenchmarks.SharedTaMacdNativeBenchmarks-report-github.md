```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Macd** | **1000**  |   **430.42 μs** |  **3.050 μs** |  **1.815 μs** | **33.37** |    **0.50** |       **-** |       **-** |   **81.29 KB** |        **2.12** |
| BuilderLatestOnly | TaLib.Functions.Macd | 1000  |   425.52 μs |  3.351 μs |  1.753 μs | 32.99 |    0.50 |       - |       - |   33.66 KB |        0.88 |
| NativeSingle      | TaLib.Functions.Macd | 1000  |    12.90 μs |  0.294 μs |  0.194 μs |  1.00 |    0.02 |  2.3193 |  0.1221 |   38.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Macd | 1000  |    20.42 μs |  0.845 μs |  0.503 μs |  1.58 |    0.04 |  7.9346 |  1.2207 |  119.47 KB |        3.12 |
|                   |                      |       |             |           |           |       |         |         |         |            |             |
| **BuilderFull**       | **TaLib.Functions.Macd** | **10000** | **4,317.09 μs** | **22.497 μs** | **11.766 μs** | **33.97** |    **0.78** | **31.2500** |       **-** |  **784.96 KB** |        **2.01** |
| BuilderLatestOnly | TaLib.Functions.Macd | 10000 | 4,278.52 μs | 18.030 μs |  9.430 μs | 33.67 |    0.77 |       - |       - |  315.14 KB |        0.81 |
| NativeSingle      | TaLib.Functions.Macd | 10000 |   127.15 μs |  4.511 μs |  2.984 μs |  1.00 |    0.03 | 23.4375 |       - |  389.84 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Macd | 10000 |   201.51 μs | 14.457 μs |  8.603 μs |  1.59 |    0.07 | 74.2188 | 33.2031 | 1209.33 KB |        3.10 |
