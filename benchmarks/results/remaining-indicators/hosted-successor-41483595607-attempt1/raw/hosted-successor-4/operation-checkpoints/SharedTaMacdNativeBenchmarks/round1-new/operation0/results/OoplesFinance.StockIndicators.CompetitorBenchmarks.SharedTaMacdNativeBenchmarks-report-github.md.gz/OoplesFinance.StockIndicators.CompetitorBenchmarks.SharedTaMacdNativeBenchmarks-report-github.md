```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Median     | Gen0     | Gen1     | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **1000**  |   **929.9 μs** | **551.80 μs** | **364.98 μs** |   **667.4 μs** |  **31.2500** |        **-** |   **665.1 KB** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 1000  |   534.3 μs |  88.90 μs |  58.80 μs |   501.0 μs |  31.2500 |        - |  617.49 KB |
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **10000** | **5,142.4 μs** | **222.05 μs** | **146.87 μs** | **5,115.0 μs** | **375.0000** | **187.5000** | **6140.95 KB** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 10000 | 4,999.6 μs | 376.62 μs | 249.11 μs | 4,858.8 μs | 343.7500 | 156.2500 |  5671.1 KB |
