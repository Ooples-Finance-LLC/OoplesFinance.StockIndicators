```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |    **58.80 μs** |  **0.633 μs** |  **0.377 μs** |  **0.77** |    **0.02** |   **3.9063** |        **-** |   **88.31 KB** |        **0.50** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |    56.68 μs |  0.733 μs |  0.383 μs |  0.74 |    0.02 |   2.4414 |        - |    40.7 KB |        0.23 |
| NativeSingle      | Skender.GetAdl | 1000  |    76.59 μs |  2.620 μs |  1.733 μs |  1.00 |    0.03 |  10.7422 |   2.4414 |  176.21 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 1000  |   143.02 μs | 10.288 μs |  6.805 μs |  1.87 |    0.09 |  28.3203 |   9.7656 |   449.4 KB |        2.55 |
|                   |                |       |             |           |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetAdl** | **10000** |   **573.04 μs** | **24.380 μs** | **16.126 μs** |  **0.67** |    **0.02** |  **50.7813** |  **15.6250** |  **862.14 KB** |        **0.49** |
| BuilderLatestOnly | Skender.GetAdl | 10000 |   534.06 μs |  5.171 μs |  2.704 μs |  0.63 |    0.01 |  23.4375 |   7.8125 |   392.3 KB |        0.22 |
| NativeSingle      | Skender.GetAdl | 10000 |   852.99 μs | 10.481 μs |  6.933 μs |  1.00 |    0.01 | 101.5625 |  62.5000 |  1758.3 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 10000 | 1,413.43 μs | 98.186 μs | 64.944 μs |  1.66 |    0.07 | 273.4375 | 195.3125 | 4474.84 KB |        2.54 |
