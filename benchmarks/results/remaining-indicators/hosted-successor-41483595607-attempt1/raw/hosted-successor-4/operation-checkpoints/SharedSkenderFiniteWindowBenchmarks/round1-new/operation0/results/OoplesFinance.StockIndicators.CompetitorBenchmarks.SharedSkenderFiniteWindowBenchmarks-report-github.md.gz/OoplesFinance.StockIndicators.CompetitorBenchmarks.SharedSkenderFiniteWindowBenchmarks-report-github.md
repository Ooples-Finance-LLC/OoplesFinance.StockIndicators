```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetCci** | **1000**  |   **207.1 μs** |  **14.17 μs** |  **7.41 μs** |       **-** |  **66.73 KB** |
| BuilderLatestOnly | Skender.GetCci | 1000  |   207.6 μs |  19.02 μs | 12.58 μs |       - |  19.13 KB |
| **BuilderFull**       | **Skender.GetCci** | **10000** | **2,053.7 μs** | **140.34 μs** | **92.83 μs** | **31.2500** | **629.71 KB** |
| BuilderLatestOnly | Skender.GetCci | 10000 | 1,952.0 μs |  19.06 μs |  9.97 μs |       - | 159.88 KB |
