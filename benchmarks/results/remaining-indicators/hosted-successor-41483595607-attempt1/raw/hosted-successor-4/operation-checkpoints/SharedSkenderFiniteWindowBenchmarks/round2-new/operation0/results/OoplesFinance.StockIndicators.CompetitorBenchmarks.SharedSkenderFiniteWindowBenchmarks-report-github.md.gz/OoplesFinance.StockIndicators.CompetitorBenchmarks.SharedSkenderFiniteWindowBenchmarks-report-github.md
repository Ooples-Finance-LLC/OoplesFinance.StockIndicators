```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetCci** | **1000**  |   **298.84 μs** |  **61.205 μs** |  **40.483 μs** |  **3.46** |    **0.45** |       **-** |       **-** |   **66.73 KB** |        **0.46** |
| BuilderLatestOnly | Skender.GetCci | 1000  |   195.47 μs |   4.352 μs |   2.276 μs |  2.26 |    0.04 |       - |       - |   19.13 KB |        0.13 |
| NativeSingle      | Skender.GetCci | 1000  |    86.48 μs |   1.936 μs |   1.152 μs |  1.00 |    0.02 |  8.7891 |  1.9531 |  145.01 KB |        1.00 |
| NativeParallel    | Skender.GetCci | 1000  |    67.28 μs |  11.792 μs |   7.799 μs |  0.78 |    0.09 |  9.7656 |  1.9531 |  162.64 KB |        1.12 |
|                   |                |       |             |            |            |       |         |         |         |            |             |
| **BuilderFull**       | **Skender.GetCci** | **10000** | **2,033.91 μs** | **170.498 μs** |  **89.174 μs** |  **2.11** |    **0.09** | **31.2500** | **15.6250** |   **629.7 KB** |        **0.44** |
| BuilderLatestOnly | Skender.GetCci | 10000 | 2,007.14 μs | 171.847 μs | 102.263 μs |  2.08 |    0.10 |       - |       - |  159.87 KB |        0.11 |
| NativeSingle      | Skender.GetCci | 10000 |   964.08 μs |  22.673 μs |  13.492 μs |  1.00 |    0.02 | 85.9375 | 39.0625 | 1445.85 KB |        1.00 |
| NativeParallel    | Skender.GetCci | 10000 |   559.23 μs |  40.372 μs |  26.704 μs |  0.58 |    0.03 | 97.6563 | 42.9688 | 1533.76 KB |        1.06 |
