```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |    **517.4 μs** |     **8.98 μs** |     **4.70 μs** |  **0.27** |    **0.00** |         **-** |         **-** |         **-** |    **73.68 KB** |       **0.022** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |    511.0 μs |     3.72 μs |     1.95 μs |  0.26 |    0.00 |         - |         - |         - |    26.05 KB |       0.008 |
| NativeSingle      | Movin(...)ogram [43] | 1000  |  1,933.3 μs |    42.36 μs |    25.21 μs |  1.00 |    0.02 |  203.1250 |  109.3750 |   46.8750 |  3389.08 KB |       1.000 |
| NativeParallel    | Movin(...)ogram [43] | 1000  |  1,751.5 μs |    85.95 μs |    56.85 μs |  0.91 |    0.03 |  359.3750 |  187.5000 |         - |  5597.51 KB |       1.652 |
|                   |                      |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** |  **5,195.0 μs** |     **8.85 μs** |     **4.63 μs** |  **0.24** |    **0.01** |   **31.2500** |         **-** |         **-** |   **707.02 KB** |       **0.021** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 |  5,118.3 μs |    29.37 μs |    19.42 μs |  0.24 |    0.01 |         - |         - |         - |   237.22 KB |       0.007 |
| NativeSingle      | Movin(...)ogram [43] | 10000 | 21,691.5 μs | 1,919.73 μs | 1,269.78 μs |  1.00 |    0.08 | 2000.0000 | 1400.0000 | 1000.0000 | 33358.62 KB |       1.000 |
| NativeParallel    | Movin(...)ogram [43] | 10000 | 22,436.7 μs |   467.55 μs |   244.54 μs |  1.04 |    0.06 | 3400.0000 | 2600.0000 | 1600.0000 | 55285.72 KB |       1.657 |
