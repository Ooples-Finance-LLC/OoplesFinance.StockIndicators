```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |    **540.1 μs** |     **4.04 μs** |     **2.41 μs** |  **0.27** |    **0.01** |         **-** |         **-** |         **-** |   **105.03 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |    534.3 μs |    13.61 μs |     9.00 μs |  0.26 |    0.01 |         - |         - |         - |    57.39 KB |        0.02 |
| NativeSingle      | Movin(...)gence [34] | 1000  |  2,018.5 μs |    61.55 μs |    40.71 μs |  1.00 |    0.03 |  203.1250 |  140.6250 |   46.8750 |  3232.17 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 1000  |  1,693.1 μs |    53.01 μs |    27.73 μs |  0.84 |    0.02 |  359.3750 |  156.2500 |         - |  5670.92 KB |        1.75 |
|                   |                      |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** |  **5,251.4 μs** |    **29.33 μs** |    **15.34 μs** |  **0.26** |    **0.01** |   **31.2500** |         **-** |         **-** |  **1019.65 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 |  5,303.1 μs |   144.07 μs |    85.74 μs |  0.26 |    0.01 |   31.2500 |         - |         - |   549.84 KB |        0.02 |
| NativeSingle      | Movin(...)gence [34] | 10000 | 20,338.3 μs |   772.70 μs |   459.82 μs |  1.00 |    0.03 | 2000.0000 | 1400.0000 | 1000.0000 | 31912.58 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 10000 | 22,901.6 μs | 2,870.39 μs | 1,898.58 μs |  1.13 |    0.09 | 2800.0000 | 1800.0000 | 1000.0000 | 56065.11 KB |        1.76 |
