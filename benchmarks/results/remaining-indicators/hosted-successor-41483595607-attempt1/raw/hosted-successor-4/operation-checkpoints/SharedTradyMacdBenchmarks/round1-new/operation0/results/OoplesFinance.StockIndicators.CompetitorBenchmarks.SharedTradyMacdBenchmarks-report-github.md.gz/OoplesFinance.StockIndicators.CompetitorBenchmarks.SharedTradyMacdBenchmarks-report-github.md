```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |   **540.5 μs** |   **2.34 μs** |  **1.22 μs** |       **-** |  **105.03 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |   533.6 μs |   3.18 μs |  1.66 μs |       - |   57.39 KB |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** | **5,431.6 μs** | **149.72 μs** | **99.03 μs** | **31.2500** | **1019.63 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 | 5,374.2 μs |  89.06 μs | 58.91 μs | 31.2500 |  549.83 KB |
