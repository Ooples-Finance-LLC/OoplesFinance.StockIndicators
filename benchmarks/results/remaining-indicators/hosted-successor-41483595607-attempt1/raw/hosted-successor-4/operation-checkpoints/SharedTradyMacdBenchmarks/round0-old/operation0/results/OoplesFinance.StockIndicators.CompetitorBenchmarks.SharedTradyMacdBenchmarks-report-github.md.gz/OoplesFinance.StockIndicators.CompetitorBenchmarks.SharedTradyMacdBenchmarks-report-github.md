```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|-----------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |   **538.8 μs** |   **7.43 μs** |   **4.42 μs** |       **-** |  **104.99 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |   528.3 μs |   3.61 μs |   1.89 μs |       - |   57.39 KB |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** | **5,446.5 μs** | **118.42 μs** |  **70.47 μs** | **31.2500** | **1019.65 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 | 5,566.0 μs | 277.44 μs | 165.10 μs | 31.2500 |  549.82 KB |
