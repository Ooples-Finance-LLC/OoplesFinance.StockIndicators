```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)lysis [22]** |   **517.8 μs** | **16.22 μs** |  **8.48 μs** |  **1.00** |    **0.02** |  **298.81 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)lysis [22] |   113.8 μs |  1.53 μs |  0.80 μs |  0.22 |    0.00 |  291.52 KB |        0.98 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)lysis [22]** | **3,508.7 μs** | **56.15 μs** | **33.41 μs** |  **1.00** |    **0.01** | **2875.41 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)lysis [22] | 1,161.4 μs | 36.26 μs | 21.58 μs |  0.33 |    0.01 |  2823.1 KB |        0.98 |
