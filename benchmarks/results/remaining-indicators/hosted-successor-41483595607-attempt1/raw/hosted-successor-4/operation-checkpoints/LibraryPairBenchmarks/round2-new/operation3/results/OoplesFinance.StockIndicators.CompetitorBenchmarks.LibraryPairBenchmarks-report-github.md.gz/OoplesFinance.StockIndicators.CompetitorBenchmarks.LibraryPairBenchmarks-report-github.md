```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)ivots [24]** |   **309.9 μs** |   **5.31 μs** |  **2.78 μs** |  **1.00** |    **0.01** |  **388.09 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)ivots [24] |   848.7 μs |  27.06 μs | 16.10 μs |  2.74 |    0.05 |  738.21 KB |        1.90 |
|            |       |                      |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)ivots [24]** | **3,505.9 μs** |  **62.16 μs** | **41.12 μs** |  **1.00** |    **0.02** | **3849.74 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)ivots [24] | 8,632.6 μs | 127.59 μs | 75.93 μs |  2.46 |    0.03 | 7321.83 KB |        1.90 |
