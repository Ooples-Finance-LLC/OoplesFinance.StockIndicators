```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skend(...)Bands [21]** |   **392.1 μs** | **33.92 μs** | **22.44 μs** |  **1.00** |    **0.08** |  **219.44 KB** |        **1.00** |
|        |       |                      |            |          |          |       |         |            |             |
| **Ooples** | **10000** | **Skend(...)Bands [21]** | **3,535.4 μs** | **38.95 μs** | **23.18 μs** |  **1.00** |    **0.01** | **2152.45 KB** |        **1.00** |
