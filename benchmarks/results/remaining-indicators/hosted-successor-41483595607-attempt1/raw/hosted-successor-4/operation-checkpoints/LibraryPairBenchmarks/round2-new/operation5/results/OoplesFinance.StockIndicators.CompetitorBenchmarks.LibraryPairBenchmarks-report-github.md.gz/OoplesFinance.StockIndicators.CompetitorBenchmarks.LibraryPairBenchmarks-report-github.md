```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)Bands [21]** |   **376.7 μs** | **32.33 μs** | **21.38 μs** |  **1.00** |    **0.08** |  **219.44 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)Bands [21] |   130.9 μs |  2.80 μs |  1.46 μs |  0.35 |    0.02 |  419.87 KB |        1.91 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)Bands [21]** | **3,616.8 μs** | **29.39 μs** | **15.37 μs** |  **1.00** |    **0.01** | **2152.73 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)Bands [21] | 1,383.7 μs | 32.38 μs | 19.27 μs |  0.38 |    0.01 | 4102.48 KB |        1.91 |
