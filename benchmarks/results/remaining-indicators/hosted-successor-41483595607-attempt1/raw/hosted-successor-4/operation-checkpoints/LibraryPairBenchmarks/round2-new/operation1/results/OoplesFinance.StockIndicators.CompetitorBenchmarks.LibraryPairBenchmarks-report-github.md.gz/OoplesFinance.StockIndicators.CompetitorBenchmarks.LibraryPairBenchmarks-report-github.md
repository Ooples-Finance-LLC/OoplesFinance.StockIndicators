```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetPvo** |   **812.56 μs** | **36.672 μs** | **21.823 μs** |  **1.00** |    **0.04** |  **290.09 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetPvo |    78.56 μs |  1.328 μs |  0.695 μs |  0.10 |    0.00 |  375.96 KB |        1.30 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetPvo** | **7,986.97 μs** | **66.964 μs** | **39.849 μs** |  **1.00** |    **0.01** | **2848.03 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetPvo |   824.59 μs | 39.706 μs | 23.628 μs |  0.10 |    0.00 |  3870.7 KB |        1.36 |
