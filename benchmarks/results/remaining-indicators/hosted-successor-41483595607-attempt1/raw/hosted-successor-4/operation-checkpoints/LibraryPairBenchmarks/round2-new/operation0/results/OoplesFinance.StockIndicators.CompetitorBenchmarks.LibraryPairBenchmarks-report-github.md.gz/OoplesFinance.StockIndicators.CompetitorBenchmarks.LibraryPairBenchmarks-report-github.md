```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |--------------- |-----------:|----------:|----------:|------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetPrs** |   **505.4 μs** |  **22.83 μs** |  **15.10 μs** |  **1.00** |    **0.04** |  **1079.56 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetPrs |   101.6 μs |   6.26 μs |   3.73 μs |  0.20 |    0.01 |   255.66 KB |        0.24 |
|            |       |                |            |           |           |       |         |             |             |
| **Ooples**     | **10000** | **Skender.GetPrs** | **4,442.9 μs** | **116.43 μs** |  **69.28 μs** |  **1.00** |    **0.02** | **10606.93 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetPrs | 1,291.6 μs | 438.64 μs | 290.13 μs |  0.29 |    0.06 |  2461.99 KB |        0.23 |
