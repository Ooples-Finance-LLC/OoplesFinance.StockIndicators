```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId           | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |----------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetRocWb** |   **506.2 μs** | **20.73 μs** | **12.33 μs** |  **1.00** |    **0.03** |  **172.54 KB** |        **1.00** |
|        |       |                  |            |          |          |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetRocWb** | **4,811.7 μs** | **94.22 μs** | **49.28 μs** |  **1.00** |    **0.01** | **1692.41 KB** |        **1.00** |
