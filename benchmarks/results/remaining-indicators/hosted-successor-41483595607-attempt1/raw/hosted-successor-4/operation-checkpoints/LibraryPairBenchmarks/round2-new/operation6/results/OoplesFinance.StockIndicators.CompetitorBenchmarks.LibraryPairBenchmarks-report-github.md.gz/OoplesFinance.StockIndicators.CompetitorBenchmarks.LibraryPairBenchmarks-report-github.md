```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId        | Mean        | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |-------------- |------------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetT3** |   **225.21 μs** |  **3.928 μs** |  **2.055 μs** |  **1.00** |  **105.85 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetT3 |    49.76 μs |  4.148 μs |  2.468 μs |  0.22 |  112.37 KB |        1.06 |
|            |       |               |             |           |           |       |            |             |
| **Ooples**     | **10000** | **Skender.GetT3** | **2,136.94 μs** | **16.857 μs** | **11.150 μs** |  **1.00** | **1036.86 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetT3 |   527.99 μs | 35.258 μs | 20.981 μs |  0.25 | 1073.38 KB |        1.04 |
