```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |-------------------- |------ |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Cci** | **1000**  |   **351.6 μs** |  **92.06 μs** |  **60.89 μs** |       **-** |       **-** |  **66.78 KB** |
| BuilderLatestOnly | TaLib.Functions.Cci | 1000  |   246.4 μs |   5.05 μs |   2.64 μs |       - |       - |  19.13 KB |
| **BuilderFull**       | **TaLib.Functions.Cci** | **10000** | **2,502.4 μs** | **138.40 μs** |  **82.36 μs** | **31.2500** | **15.6250** | **629.69 KB** |
| BuilderLatestOnly | TaLib.Functions.Cci | 10000 | 2,546.4 μs | 191.63 μs | 126.75 μs |       - |       - | 159.88 KB |
