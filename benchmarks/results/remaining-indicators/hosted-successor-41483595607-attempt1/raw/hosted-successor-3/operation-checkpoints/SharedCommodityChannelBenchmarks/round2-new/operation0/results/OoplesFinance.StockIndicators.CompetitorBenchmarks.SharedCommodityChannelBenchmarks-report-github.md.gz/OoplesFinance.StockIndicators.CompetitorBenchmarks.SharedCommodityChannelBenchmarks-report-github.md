```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Cci** | **1000**  |   **455.92 μs** |   **7.903 μs** |   **4.703 μs** | **14.94** |    **0.15** |       **-** |       **-** |  **66.78 KB** |        **8.64** |
| BuilderLatestOnly | TaLib.Functions.Cci | 1000  |   257.96 μs |  33.814 μs |  22.366 μs |  8.46 |    0.70 |       - |       - |  19.13 KB |        2.48 |
| NativeSingle      | TaLib.Functions.Cci | 1000  |    30.51 μs |   0.096 μs |   0.050 μs |  1.00 |    0.00 |  0.2441 |       - |   7.73 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Cci | 1000  |    17.93 μs |   0.909 μs |   0.601 μs |  0.59 |    0.02 |  0.4883 |       - |   8.02 KB |        1.04 |
|                   |                     |       |             |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Cci** | **10000** | **2,566.65 μs** | **235.212 μs** | **155.579 μs** |  **8.30** |    **0.49** | **31.2500** | **15.6250** |  **629.7 KB** |        **8.07** |
| BuilderLatestOnly | TaLib.Functions.Cci | 10000 | 2,509.17 μs | 172.281 μs | 113.953 μs |  8.11 |    0.37 |       - |       - | 159.87 KB |        2.05 |
| NativeSingle      | TaLib.Functions.Cci | 10000 |   309.37 μs |   6.308 μs |   4.172 μs |  1.00 |    0.02 |  3.9063 |       - |  78.05 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Cci | 10000 |   191.38 μs |  16.845 μs |  11.142 μs |  0.62 |    0.04 |  3.9063 |       - |  78.34 KB |        1.00 |
