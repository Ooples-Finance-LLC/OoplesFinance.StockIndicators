```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |-------------------- |------ |-------------:|------------:|------------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Apo** | **1000**  |   **405.876 μs** |  **85.2743 μs** |  **50.7454 μs** | **71.38** |    **8.66** |  **15.6250** |       **-** |   **355.3 KB** |       **22.72** |
| BuilderLatestOnly | TaLib.Functions.Apo | 1000  |   325.640 μs |  45.0798 μs |  29.8175 μs | 57.27 |    5.22 |  15.6250 |       - |  307.67 KB |       19.67 |
| NativeSingle      | TaLib.Functions.Apo | 1000  |     5.690 μs |   0.2396 μs |   0.1585 μs |  1.00 |    0.04 |   0.9460 |  0.0305 |   15.64 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Apo | 1000  |    10.131 μs |   0.2295 μs |   0.1366 μs |  1.78 |    0.05 |   3.3569 |  0.1831 |    47.7 KB |        3.05 |
|                   |                     |       |              |             |             |       |         |          |         |            |             |
| **BuilderFull**       | **TaLib.Functions.Apo** | **10000** | **2,974.772 μs** | **178.9045 μs** | **118.3343 μs** | **54.45** |    **2.30** | **187.5000** | **93.7500** | **3167.61 KB** |       **20.27** |
| BuilderLatestOnly | TaLib.Functions.Apo | 10000 | 2,953.372 μs | 160.7480 μs | 106.3248 μs | 54.06 |    2.11 | 156.2500 | 46.8750 | 2697.77 KB |       17.26 |
| NativeSingle      | TaLib.Functions.Apo | 10000 |    54.651 μs |   1.6200 μs |   1.0715 μs |  1.00 |    0.03 |   9.2773 |  1.4648 |  156.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Apo | 10000 |   106.406 μs |   7.2194 μs |   4.7752 μs |  1.95 |    0.09 |  30.2734 |  7.8125 |  469.59 KB |        3.00 |
