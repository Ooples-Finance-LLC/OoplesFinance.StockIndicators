```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev    | Gen0     | Gen1    | Allocated  |
|------------------ |-------------------- |------ |-----------:|----------:|----------:|---------:|--------:|-----------:|
| **BuilderFull**       | **TaLib.Functions.Apo** | **1000**  |   **459.9 μs** |  **91.87 μs** |  **60.77 μs** |  **15.6250** |       **-** |  **355.26 KB** |
| BuilderLatestOnly | TaLib.Functions.Apo | 1000  |   307.3 μs |   9.82 μs |   5.14 μs |  15.6250 |       - |  307.67 KB |
| **BuilderFull**       | **TaLib.Functions.Apo** | **10000** | **2,938.6 μs** | **240.91 μs** | **143.36 μs** | **187.5000** | **93.7500** | **3167.61 KB** |
| BuilderLatestOnly | TaLib.Functions.Apo | 10000 | 2,973.4 μs | 298.70 μs | 197.57 μs | 156.2500 | 46.8750 | 2697.77 KB |
