```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error       | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |-----------:|------------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Ma** | **1000**  | **133.874 μs** |  **25.4168 μs** | **16.8117 μs** | **58.67** |    **7.05** |  **3.9063** |       **-** |  **78.19 KB** |        **9.83** |
| BuilderLatestOnly | TaLib.Functions.Ma | 1000  | 115.412 μs |  10.2424 μs |  6.7747 μs | 50.58 |    2.87 |  1.9531 |       - |  30.62 KB |        3.85 |
| NativeSingle      | TaLib.Functions.Ma | 1000  |   2.282 μs |   0.0350 μs |  0.0208 μs |  1.00 |    0.01 |  0.4730 |       - |   7.95 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ma | 1000  |   5.018 μs |   0.1676 μs |  0.0997 μs |  2.20 |    0.05 |  1.9836 |  0.0916 |  28.37 KB |        3.57 |
|                   |                    |       |            |             |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Ma** | **10000** | **989.911 μs** | **121.0723 μs** | **80.0818 μs** | **45.36** |    **3.53** | **39.0625** | **15.6250** | **641.11 KB** |        **8.19** |
| BuilderLatestOnly | TaLib.Functions.Ma | 10000 | 904.313 μs |  45.7541 μs | 23.9303 μs | 41.44 |    1.11 |  7.8125 |       - | 171.31 KB |        2.19 |
| NativeSingle      | TaLib.Functions.Ma | 10000 |  21.824 μs |   0.3493 μs |  0.2310 μs |  1.00 |    0.01 |  4.7607 |  0.7324 |  78.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ma | 10000 |  39.759 μs |   1.4019 μs |  0.9273 μs |  1.82 |    0.04 | 18.0664 |  5.3711 | 274.46 KB |        3.51 |
