```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean         | Error       | StdDev      | Ratio  | RatioSD | Gen0     | Gen1     | Allocated   | Alloc Ratio |
|------------------ |-------------------- |------ |-------------:|------------:|------------:|-------:|--------:|---------:|---------:|------------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Ppo** | **1000**  | **1,052.368 μs** | **761.5054 μs** | **398.2821 μs** | **167.50** |   **59.79** |  **62.5000** |        **-** |  **1487.41 KB** |       **95.10** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 1000  |   710.334 μs |  53.3846 μs |  35.3106 μs | 113.06 |    5.86 |  85.9375 |   7.8125 |  1439.82 KB |       92.06 |
| NativeSingle      | TaLib.Functions.Ppo | 1000  |     6.286 μs |   0.2127 μs |   0.1407 μs |   1.00 |    0.03 |   0.9155 |        - |    15.64 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ppo | 1000  |    12.087 μs |   0.5888 μs |   0.3894 μs |   1.92 |    0.07 |   3.2959 |   0.2441 |     47.7 KB |        3.05 |
|                   |                     |       |              |             |             |        |         |          |          |             |             |
| **BuilderFull**       | **TaLib.Functions.Ppo** | **10000** | **7,218.309 μs** | **196.6774 μs** | **102.8661 μs** | **118.83** |    **1.84** | **846.1538** | **384.6154** | **14748.84 KB** |       **94.38** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 10000 | 7,366.976 μs | 409.0506 μs | 270.5616 μs | 121.28 |    4.35 | 857.1429 | 285.7143 |    14279 KB |       91.37 |
| NativeSingle      | TaLib.Functions.Ppo | 10000 |    60.749 μs |   0.7514 μs |   0.4970 μs |   1.00 |    0.01 |   9.2773 |   1.4648 |   156.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ppo | 10000 |   112.658 μs |   4.8786 μs |   2.5516 μs |   1.85 |    0.04 |  30.2734 |   9.7656 |   469.59 KB |        3.00 |
