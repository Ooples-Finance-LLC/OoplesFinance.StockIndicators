```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Ma** | **1000**  | **126.8 μs** | **20.64 μs** | **13.65 μs** |  **3.9063** |       **-** |  **78.23 KB** |
| BuilderLatestOnly | TaLib.Functions.Ma | 1000  | 119.6 μs |  7.83 μs |  5.18 μs |  1.9531 |       - |  30.62 KB |
| **BuilderFull**       | **TaLib.Functions.Ma** | **10000** | **938.1 μs** | **14.30 μs** |  **7.48 μs** | **39.0625** | **15.6250** | **641.13 KB** |
| BuilderLatestOnly | TaLib.Functions.Ma | 10000 | 928.2 μs | 53.03 μs | 31.56 μs |  7.8125 |       - | 171.27 KB |
