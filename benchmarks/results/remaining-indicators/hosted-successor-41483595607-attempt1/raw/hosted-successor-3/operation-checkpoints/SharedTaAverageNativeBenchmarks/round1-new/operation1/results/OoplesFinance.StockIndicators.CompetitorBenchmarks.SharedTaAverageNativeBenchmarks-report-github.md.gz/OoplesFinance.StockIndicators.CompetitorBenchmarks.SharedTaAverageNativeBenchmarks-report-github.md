```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev    | Gen0     | Gen1    | Allocated  |
|------------------ |-------------------- |------ |-----------:|----------:|----------:|---------:|--------:|-----------:|
| **BuilderFull**       | **TaLib.Functions.Apo** | **1000**  |   **380.2 μs** | **124.17 μs** |  **82.13 μs** |  **15.6250** |       **-** |  **355.26 KB** |
| BuilderLatestOnly | TaLib.Functions.Apo | 1000  |   317.6 μs |  26.30 μs |  15.65 μs |  15.6250 |       - |  307.67 KB |
| **BuilderFull**       | **TaLib.Functions.Apo** | **10000** | **2,979.9 μs** | **280.33 μs** | **166.82 μs** | **187.5000** | **93.7500** | **3167.62 KB** |
| BuilderLatestOnly | TaLib.Functions.Apo | 10000 | 2,969.8 μs | 191.10 μs | 126.40 μs | 156.2500 | 46.8750 | 2697.77 KB |
