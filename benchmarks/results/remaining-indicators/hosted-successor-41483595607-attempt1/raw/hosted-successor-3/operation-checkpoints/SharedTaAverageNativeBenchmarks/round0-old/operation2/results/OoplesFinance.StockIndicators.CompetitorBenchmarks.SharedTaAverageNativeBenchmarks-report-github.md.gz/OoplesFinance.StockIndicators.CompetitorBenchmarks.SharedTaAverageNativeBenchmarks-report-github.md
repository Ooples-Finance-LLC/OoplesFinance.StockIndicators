```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated |
|------------------ |-------------------- |------ |-----------:|----------:|----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Ppo** | **1000**  |   **749.3 μs** |  **15.35 μs** |   **8.03 μs** |  **62.5000** |        **-** |   **1.45 MB** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 1000  |   680.1 μs |  37.80 μs |  22.49 μs |  85.9375 |   7.8125 |   1.41 MB |
| **BuilderFull**       | **TaLib.Functions.Ppo** | **10000** | **7,480.8 μs** | **385.11 μs** | **254.73 μs** | **857.1429** | **428.5714** |   **14.4 MB** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 10000 | 7,469.3 μs | 328.16 μs | 217.06 μs | 857.1429 | 285.7143 |  13.94 MB |
