```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetKeltner** |   **443.4 μs** | **24.19 μs** | **14.40 μs** |  **1.00** |    **0.04** |  **267.47 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetKeltner |   130.4 μs |  6.30 μs |  3.29 μs |  0.29 |    0.01 |  475.81 KB |        1.78 |
|            |       |                    |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetKeltner** | **4,325.3 μs** | **25.18 μs** | **16.65 μs** |  **1.00** |    **0.01** | **2631.09 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetKeltner | 1,351.0 μs | 51.57 μs | 30.69 μs |  0.31 |    0.01 | 4659.36 KB |        1.77 |
