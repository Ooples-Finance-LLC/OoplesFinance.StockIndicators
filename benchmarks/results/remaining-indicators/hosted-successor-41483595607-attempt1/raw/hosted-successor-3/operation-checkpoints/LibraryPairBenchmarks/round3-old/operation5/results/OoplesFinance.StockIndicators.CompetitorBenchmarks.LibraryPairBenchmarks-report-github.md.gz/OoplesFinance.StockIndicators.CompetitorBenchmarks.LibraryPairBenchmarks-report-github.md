```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId             | Mean       | Error    | StdDev   | Ratio | Allocated  | Alloc Ratio |
|------- |------ |------------------- |-----------:|---------:|---------:|------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetKeltner** |   **430.1 μs** |  **4.50 μs** |  **2.35 μs** |  **1.00** |  **267.47 KB** |        **1.00** |
|        |       |                    |            |          |          |       |            |             |
| **Ooples** | **10000** | **Skender.GetKeltner** | **4,375.9 μs** | **26.94 μs** | **14.09 μs** |  **1.00** | **2630.81 KB** |        **1.00** |
