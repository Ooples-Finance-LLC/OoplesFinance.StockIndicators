```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetCmf** |   **278.3 μs** |  **76.38 μs** |  **50.52 μs** |  **1.03** |    **0.25** |  **189.85 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetCmf |   141.9 μs |  10.50 μs |   6.95 μs |  0.52 |    0.09 |  388.41 KB |        2.05 |
|            |       |                |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetCmf** | **2,182.3 μs** | **644.24 μs** | **426.13 μs** |  **1.03** |    **0.27** | **1841.89 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetCmf | 1,489.3 μs |  56.31 μs |  29.45 μs |  0.71 |    0.13 | 3789.49 KB |        2.06 |
