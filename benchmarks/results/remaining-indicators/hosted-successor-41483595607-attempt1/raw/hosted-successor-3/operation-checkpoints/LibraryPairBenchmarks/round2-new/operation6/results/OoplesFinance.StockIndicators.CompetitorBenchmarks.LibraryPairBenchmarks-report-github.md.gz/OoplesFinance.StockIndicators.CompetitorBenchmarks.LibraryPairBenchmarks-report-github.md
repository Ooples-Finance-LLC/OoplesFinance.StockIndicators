```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId          | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetMacd** |   **670.3 μs** | **32.24 μs** | **19.19 μs** |  **1.00** |    **0.04** |   **331.7 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetMacd |   108.3 μs | 33.78 μs | 20.10 μs |  0.16 |    0.03 |  456.03 KB |        1.37 |
|            |       |                 |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetMacd** | **6,493.2 μs** | **44.77 μs** | **23.42 μs** |  **1.00** |    **0.00** | **3266.66 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetMacd | 1,054.9 μs | 79.34 μs | 52.48 μs |  0.16 |    0.01 | 4672.18 KB |        1.43 |
