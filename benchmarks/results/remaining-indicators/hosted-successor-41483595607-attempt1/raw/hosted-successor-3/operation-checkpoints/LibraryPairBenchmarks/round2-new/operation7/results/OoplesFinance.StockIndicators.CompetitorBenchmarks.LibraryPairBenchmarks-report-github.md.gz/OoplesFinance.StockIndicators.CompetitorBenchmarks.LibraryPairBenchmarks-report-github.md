```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)oints [22]** |    **67.76 μs** |  **4.793 μs** |  **3.170 μs** |  **1.00** |    **0.06** |  **233.83 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)oints [22] |   196.48 μs | 23.763 μs | 14.141 μs |  2.91 |    0.23 |   512.6 KB |        2.19 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)oints [22]** |   **942.82 μs** | **48.233 μs** | **28.703 μs** |  **1.00** |    **0.04** | **2312.66 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)oints [22] | 1,836.66 μs | 41.765 μs | 24.854 μs |  1.95 |    0.06 | 5021.67 KB |        2.17 |
