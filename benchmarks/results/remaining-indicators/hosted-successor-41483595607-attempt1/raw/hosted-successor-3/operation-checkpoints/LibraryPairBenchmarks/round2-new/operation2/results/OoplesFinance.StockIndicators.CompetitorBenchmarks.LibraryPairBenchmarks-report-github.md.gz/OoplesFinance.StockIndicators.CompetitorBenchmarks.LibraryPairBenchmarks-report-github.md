```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)elier [21]** |   **288.1 μs** | **43.26 μs** | **28.61 μs** |  **1.01** |    **0.13** |  **145.78 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)elier [21] |   134.6 μs |  1.97 μs |  1.03 μs |  0.47 |    0.04 |  255.98 KB |        1.76 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)elier [21]** | **2,517.9 μs** | **19.23 μs** | **11.44 μs** |  **1.00** |    **0.01** |  **1428.4 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)elier [21] | 1,358.3 μs | 23.14 μs | 12.10 μs |  0.54 |    0.01 | 2479.33 KB |        1.74 |
