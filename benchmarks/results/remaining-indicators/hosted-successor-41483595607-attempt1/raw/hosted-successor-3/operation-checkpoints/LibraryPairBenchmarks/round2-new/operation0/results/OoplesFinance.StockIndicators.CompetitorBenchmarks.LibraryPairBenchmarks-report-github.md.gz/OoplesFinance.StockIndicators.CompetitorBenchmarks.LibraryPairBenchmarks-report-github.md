```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetCci** |   **238.96 μs** |  **15.828 μs** |  **10.469 μs** |  **1.00** |    **0.06** |  **106.42 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetCci |    94.91 μs |  18.134 μs |  10.791 μs |  0.40 |    0.05 |  177.81 KB |        1.67 |
|            |       |                |             |            |            |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetCci** | **2,137.53 μs** |   **9.558 μs** |   **4.999 μs** |  **1.00** |    **0.00** | **1037.76 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetCci | 1,106.95 μs | 407.376 μs | 269.454 μs |  0.52 |    0.12 |  1698.6 KB |        1.64 |
