```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId              | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |-------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetElderRay** |   **183.6 μs** | **15.24 μs** |  **9.07 μs** |  **1.00** |    **0.06** |  **186.84 KB** |        **1.00** |
|        |       |                     |            |          |          |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetElderRay** | **1,627.1 μs** | **42.95 μs** | **25.56 μs** |  **1.00** |    **0.02** | **1838.27 KB** |        **1.00** |
