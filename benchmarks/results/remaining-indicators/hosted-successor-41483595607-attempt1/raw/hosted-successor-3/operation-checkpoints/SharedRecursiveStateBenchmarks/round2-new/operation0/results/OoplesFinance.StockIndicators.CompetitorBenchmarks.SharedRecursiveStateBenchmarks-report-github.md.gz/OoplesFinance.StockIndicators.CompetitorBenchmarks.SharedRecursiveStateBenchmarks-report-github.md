```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **142.235 μs** |  **5.9545 μs** |  **3.5434 μs** | **58.50** |    **1.50** |  **3.9063** |      **-** |  **64.85 KB** |        **8.23** |
| BuilderLatestOnly | Ad        | 1000  |   131.101 μs |  0.9502 μs |  0.6285 μs | 53.93 |    0.58 |  0.9766 |      - |  17.27 KB |        2.19 |
| NativeSingle      | Ad        | 1000  |     2.431 μs |  0.0416 μs |  0.0247 μs |  1.00 |    0.01 |  0.4730 |      - |   7.88 KB |        1.00 |
| NativeParallel    | Ad        | 1000  |     5.691 μs |  0.1242 μs |  0.0739 μs |  2.34 |    0.04 |  0.4883 |      - |   8.16 KB |        1.04 |
|                   |           |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **Ad**        | **10000** | **1,228.104 μs** | **14.4607 μs** |  **8.6053 μs** | **57.78** |    **0.44** | **31.2500** | **7.8125** | **627.75 KB** |        **8.03** |
| BuilderLatestOnly | Ad        | 10000 | 1,208.845 μs | 40.1230 μs | 26.5389 μs | 56.88 |    1.21 |  7.8125 |      - | 157.96 KB |        2.02 |
| NativeSingle      | Ad        | 10000 |    21.254 μs |  0.1330 μs |  0.0792 μs |  1.00 |    0.00 |  4.7607 | 0.8545 |  78.19 KB |        1.00 |
| NativeParallel    | Ad        | 10000 |    42.788 μs |  3.7333 μs |  1.9526 μs |  2.01 |    0.09 |  4.3945 | 0.4883 |  78.48 KB |        1.00 |
