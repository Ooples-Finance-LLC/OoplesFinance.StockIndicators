```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mavp** | **1000**  | **109.88 μs** | **19.359 μs** | **12.805 μs** |  **3.9063** |      **-** |  **66.38 KB** |
| BuilderLatestOnly | TaLib.Functions.Mavp | 1000  |  93.03 μs |  0.902 μs |  0.537 μs |  0.9766 |      - |  18.77 KB |
| **BuilderFull**       | **TaLib.Functions.Mavp** | **10000** | **905.97 μs** | **27.989 μs** | **16.656 μs** | **31.2500** | **7.8125** |  **629.3 KB** |
| BuilderLatestOnly | TaLib.Functions.Mavp | 10000 | 885.93 μs |  4.896 μs |  2.913 μs |  7.8125 |      - | 159.46 KB |
