```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev   | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|---------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Mavp** | **1000**  | **106.26 μs** |  **1.096 μs** | **0.573 μs** |  **3.83** |    **0.04** |  **3.9063** |       **-** |  **66.38 KB** |        **3.34** |
| BuilderLatestOnly | TaLib.Functions.Mavp | 1000  |  97.87 μs |  0.653 μs | 0.389 μs |  3.52 |    0.04 |  0.9766 |       - |  18.77 KB |        0.94 |
| NativeSingle      | TaLib.Functions.Mavp | 1000  |  27.77 μs |  0.462 μs | 0.305 μs |  1.00 |    0.01 |  0.9766 |       - |   19.9 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mavp | 1000  |  44.55 μs |  1.430 μs | 0.946 μs |  1.60 |    0.04 |  4.1504 |  0.2441 |   59.1 KB |        2.97 |
|                   |                      |       |           |           |          |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Mavp** | **10000** | **937.52 μs** |  **6.904 μs** | **3.611 μs** |  **2.96** |    **0.02** | **31.2500** |  **7.8125** |  **629.3 KB** |        **3.22** |
| BuilderLatestOnly | TaLib.Functions.Mavp | 10000 | 918.46 μs | 10.942 μs | 5.723 μs |  2.90 |    0.02 |  7.8125 |       - | 159.46 KB |        0.81 |
| NativeSingle      | TaLib.Functions.Mavp | 10000 | 316.23 μs |  2.670 μs | 1.397 μs |  1.00 |    0.01 | 11.7188 |  1.9531 | 195.69 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mavp | 10000 | 425.51 μs | 16.235 μs | 9.661 μs |  1.35 |    0.03 | 35.1563 | 15.6250 | 568.89 KB |        2.91 |
