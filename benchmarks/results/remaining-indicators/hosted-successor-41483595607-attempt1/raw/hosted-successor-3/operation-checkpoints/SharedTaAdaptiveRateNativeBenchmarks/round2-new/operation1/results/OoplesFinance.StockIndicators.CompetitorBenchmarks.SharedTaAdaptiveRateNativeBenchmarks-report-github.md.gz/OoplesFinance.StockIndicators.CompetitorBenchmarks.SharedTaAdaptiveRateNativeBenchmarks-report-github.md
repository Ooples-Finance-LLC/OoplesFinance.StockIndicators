```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **291.98 μs** |  **2.368 μs** |  **1.409 μs** | **27.60** |    **0.32** |       **-** |       **-** |   **89.1 KB** |        **5.75** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   293.72 μs |  8.352 μs |  5.524 μs | 27.76 |    0.58 |  1.9531 |       - |   41.5 KB |        2.68 |
| NativeSingle      | TaLib.Functions.Trix | 1000  |    10.58 μs |  0.180 μs |  0.119 μs |  1.00 |    0.02 |  0.9155 |       - |  15.48 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Trix | 1000  |    15.27 μs |  0.832 μs |  0.495 μs |  1.44 |    0.05 |  3.2959 |  0.1221 |   47.6 KB |        3.07 |
|                   |                      |       |             |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **3,107.73 μs** | **17.909 μs** | **10.658 μs** | **29.32** |    **0.33** | **46.8750** | **15.6250** | **863.02 KB** |        **5.53** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 3,002.46 μs | 27.347 μs | 16.274 μs | 28.32 |    0.33 | 15.6250 |       - | 393.19 KB |        2.52 |
| NativeSingle      | TaLib.Functions.Trix | 10000 |   106.01 μs |  1.999 μs |  1.190 μs |  1.00 |    0.02 |  8.7891 |  0.9766 | 156.12 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Trix | 10000 |   163.43 μs |  6.452 μs |  4.268 μs |  1.54 |    0.04 | 29.2969 |  8.7891 | 469.48 KB |        3.01 |
