```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetKvo** | **1000**  |   **929.4 μs** | **13.34 μs** |  **6.98 μs** |  **81.29 KB** |
| BuilderLatestOnly | Skender.GetKvo | 1000  |   904.9 μs |  3.06 μs |  1.82 μs |  33.66 KB |
| **BuilderFull**       | **Skender.GetKvo** | **10000** | **9,255.1 μs** | **66.96 μs** | **39.84 μs** | **785.43 KB** |
| BuilderLatestOnly | Skender.GetKvo | 10000 | 9,237.2 μs | 12.52 μs |  7.45 μs | 315.59 KB |
