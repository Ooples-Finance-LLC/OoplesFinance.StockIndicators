```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetKvo** | **1000**  |   **858.6 μs** |  **3.63 μs** |  **2.16 μs** |  **81.31 KB** |
| BuilderLatestOnly | Skender.GetKvo | 1000  |   845.4 μs |  8.73 μs |  4.56 μs |  33.68 KB |
| **BuilderFull**       | **Skender.GetKvo** | **10000** | **8,702.3 μs** | **38.89 μs** | **20.34 μs** | **785.31 KB** |
| BuilderLatestOnly | Skender.GetKvo | 10000 | 8,494.1 μs | 70.17 μs | 41.76 μs | 315.49 KB |
