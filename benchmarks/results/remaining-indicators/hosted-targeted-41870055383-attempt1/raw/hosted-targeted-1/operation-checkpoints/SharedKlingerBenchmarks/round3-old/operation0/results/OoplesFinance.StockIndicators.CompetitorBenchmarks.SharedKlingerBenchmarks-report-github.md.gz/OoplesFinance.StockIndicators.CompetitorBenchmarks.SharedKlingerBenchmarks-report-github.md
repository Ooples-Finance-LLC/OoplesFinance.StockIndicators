```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetKvo** | **1000**  |   **928.6 μs** |   **2.29 μs** |  **1.20 μs** |  **81.29 KB** |
| BuilderLatestOnly | Skender.GetKvo | 1000  |   944.1 μs |  15.38 μs |  9.15 μs |  33.65 KB |
| **BuilderFull**       | **Skender.GetKvo** | **10000** | **9,445.7 μs** | **147.30 μs** | **87.65 μs** |  **785.4 KB** |
| BuilderLatestOnly | Skender.GetKvo | 10000 | 9,248.8 μs |  59.24 μs | 35.25 μs | 315.61 KB |
