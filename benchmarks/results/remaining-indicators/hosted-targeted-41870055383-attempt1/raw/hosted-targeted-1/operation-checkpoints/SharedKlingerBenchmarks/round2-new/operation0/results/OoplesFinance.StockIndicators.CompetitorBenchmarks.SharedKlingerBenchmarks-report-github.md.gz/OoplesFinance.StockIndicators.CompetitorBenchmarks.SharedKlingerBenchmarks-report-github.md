```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetKvo** | **1000**  | **1,611.38 μs** | **748.173 μs** | **494.870 μs** | **21.07** |    **6.18** |        **-** |        **-** |   **81.31 KB** |        **0.39** |
| BuilderLatestOnly | Skender.GetKvo | 1000  |   866.90 μs |  23.589 μs |  14.037 μs | 11.34 |    0.22 |        - |        - |   33.67 KB |        0.16 |
| NativeSingle      | Skender.GetKvo | 1000  |    76.49 μs |   1.670 μs |   0.994 μs |  1.00 |    0.02 |  12.6953 |   3.9063 |  207.63 KB |        1.00 |
| NativeParallel    | Skender.GetKvo | 1000  |   134.73 μs |   6.707 μs |   3.508 μs |  1.76 |    0.05 |  33.2031 |  10.7422 |  528.19 KB |        2.54 |
|                   |                |       |             |            |            |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetKvo** | **10000** | **8,674.44 μs** |  **87.521 μs** |  **52.082 μs** | **10.43** |    **0.43** |        **-** |        **-** |  **785.36 KB** |        **0.38** |
| BuilderLatestOnly | Skender.GetKvo | 10000 | 8,625.22 μs |  84.863 μs |  50.501 μs | 10.37 |    0.43 |        - |        - |  315.57 KB |        0.15 |
| NativeSingle      | Skender.GetKvo | 10000 |   832.99 μs |  55.162 μs |  36.486 μs |  1.00 |    0.06 | 125.0000 |  85.9375 | 2070.96 KB |        1.00 |
| NativeParallel    | Skender.GetKvo | 10000 | 1,393.81 μs |  84.817 μs |  50.473 μs |  1.68 |    0.09 | 320.3125 | 265.6250 | 5256.76 KB |        2.54 |
