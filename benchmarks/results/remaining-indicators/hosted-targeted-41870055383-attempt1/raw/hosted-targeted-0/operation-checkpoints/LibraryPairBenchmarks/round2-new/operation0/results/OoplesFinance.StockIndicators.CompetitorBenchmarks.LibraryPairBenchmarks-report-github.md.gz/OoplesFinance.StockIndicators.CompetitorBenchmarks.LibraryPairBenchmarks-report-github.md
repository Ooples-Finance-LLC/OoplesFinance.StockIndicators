```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean         | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-------------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetKvo** |  **1,082.55 μs** | **43.29 μs** | **28.63 μs** |  **1.00** |    **0.04** |  **162.97 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetKvo |     89.26 μs | 21.03 μs | 12.51 μs |  0.08 |    0.01 |  273.22 KB |        1.68 |
|            |       |                |              |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetKvo** | **10,574.94 μs** | **59.04 μs** | **30.88 μs** |  **1.00** |    **0.00** |    **1595 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetKvo |    841.19 μs | 29.42 μs | 17.51 μs |  0.08 |    0.00 | 2646.55 KB |        1.66 |
