```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId         | Mean      | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|------- |------ |--------------- |----------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetKvo** |  **1.234 ms** | **0.0222 ms** | **0.0132 ms** |  **1.00** |  **162.91 KB** |        **1.00** |
|        |       |                |           |           |           |       |            |             |
| **Ooples** | **10000** | **Skender.GetKvo** | **11.881 ms** | **0.0255 ms** | **0.0152 ms** |  **1.00** | **1592.97 KB** |        **1.00** |
