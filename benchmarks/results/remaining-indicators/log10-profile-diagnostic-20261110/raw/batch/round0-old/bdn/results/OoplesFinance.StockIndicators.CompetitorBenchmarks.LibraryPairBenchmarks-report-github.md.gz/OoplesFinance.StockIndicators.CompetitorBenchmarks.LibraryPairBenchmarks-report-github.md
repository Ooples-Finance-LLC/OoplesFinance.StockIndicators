```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean     | Error   | StdDev  | Ratio | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |---------:|--------:|--------:|------:|----------:|------------:|
| Ooples     | 10000 | TaLib(...)Log10 [21] | 216.5 μs | 3.24 μs | 1.93 μs |  1.00 | 950.99 KB |        1.00 |
| Competitor | 10000 | TaLib(...)Log10 [21] | 137.3 μs | 1.66 μs | 0.87 μs |  0.63 | 330.64 KB |        0.35 |
