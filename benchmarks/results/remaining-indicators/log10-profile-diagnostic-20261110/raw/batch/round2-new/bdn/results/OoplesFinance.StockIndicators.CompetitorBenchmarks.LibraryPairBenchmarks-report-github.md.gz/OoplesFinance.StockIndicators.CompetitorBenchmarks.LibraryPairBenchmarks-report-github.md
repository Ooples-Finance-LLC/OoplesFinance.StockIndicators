```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean     | Error   | StdDev  | Ratio | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |---------:|--------:|--------:|------:|----------:|------------:|
| Ooples     | 10000 | TaLib(...)Log10 [21] | 248.4 μs | 3.85 μs | 2.01 μs |  1.00 | 950.73 KB |        1.00 |
| Competitor | 10000 | TaLib(...)Log10 [21] | 130.3 μs | 0.61 μs | 0.32 μs |  0.52 | 329.33 KB |        0.35 |
