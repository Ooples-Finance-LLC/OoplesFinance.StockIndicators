```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method         | Count | Operation | Mean     | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|--------------- |------ |---------- |---------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| BuilderFull    | 10000 | Log10     | 66.59 μs |  3.164 μs |  1.883 μs |  1.71 |    0.05 | 33.2031 | 13.6719 | 549.31 KB |        7.03 |
| NativeSingle   | 10000 | Log10     | 38.84 μs |  0.616 μs |  0.367 μs |  1.00 |    0.01 |  4.3945 |  0.4883 |  78.18 KB |        1.00 |
| NativeParallel | 10000 | Log10     | 98.08 μs | 15.303 μs | 10.122 μs |  2.53 |    0.25 |  3.9063 |       - |  78.45 KB |        1.00 |
