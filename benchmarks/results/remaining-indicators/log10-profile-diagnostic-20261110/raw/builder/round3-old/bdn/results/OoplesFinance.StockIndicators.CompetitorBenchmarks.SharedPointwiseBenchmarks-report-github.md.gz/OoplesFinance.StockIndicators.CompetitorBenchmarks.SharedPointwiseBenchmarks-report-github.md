```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method         | Count | Operation | Mean      | Error    | StdDev   | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|--------------- |------ |---------- |----------:|---------:|---------:|------:|--------:|--------:|--------:|----------:|------------:|
| BuilderFull    | 10000 | Log10     | 107.84 μs | 5.235 μs | 3.116 μs |  2.76 |    0.08 | 33.2031 | 13.6719 | 549.75 KB |        7.03 |
| NativeSingle   | 10000 | Log10     |  39.14 μs | 0.434 μs | 0.227 μs |  1.00 |    0.01 |  4.3945 |  0.4883 |  78.18 KB |        1.00 |
| NativeParallel | 10000 | Log10     |  91.24 μs | 4.024 μs | 2.662 μs |  2.33 |    0.07 |  4.3945 |  0.4883 |  78.45 KB |        1.00 |
