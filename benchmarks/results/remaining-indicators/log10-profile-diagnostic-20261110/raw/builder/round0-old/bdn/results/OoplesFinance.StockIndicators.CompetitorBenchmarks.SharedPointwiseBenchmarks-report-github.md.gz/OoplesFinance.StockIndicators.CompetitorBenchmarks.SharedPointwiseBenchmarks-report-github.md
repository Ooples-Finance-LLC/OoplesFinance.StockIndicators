```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method         | Count | Operation | Mean      | Error    | StdDev   | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|--------------- |------ |---------- |----------:|---------:|---------:|------:|--------:|--------:|--------:|----------:|------------:|
| BuilderFull    | 10000 | Log10     | 111.32 μs | 9.427 μs | 5.610 μs |  2.66 |    0.21 | 33.2031 | 13.6719 | 549.75 KB |        7.03 |
| NativeSingle   | 10000 | Log10     |  42.08 μs | 6.184 μs | 3.234 μs |  1.00 |    0.10 |  4.3945 |  0.4883 |  78.18 KB |        1.00 |
| NativeParallel | 10000 | Log10     |  92.76 μs | 3.830 μs | 2.533 μs |  2.21 |    0.15 |  4.3945 |  0.4883 |  78.45 KB |        1.00 |
