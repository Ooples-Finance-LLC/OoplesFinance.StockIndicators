"""Compose only complete accepted candidates; never execute before all results exist."""
import argparse, json, subprocess, sys
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('baseline');a=p.parse_args()
r=Path(__file__).parent;base=Path(r'C:\Users\cheat\source\repos\Ooples-Finance-LLC')
repo=base/'si-adx-weighted-certificate-20261104'
tooling=base/'si-hosted-combined-local-certificates-20261103'
sys.path.insert(0,str(tooling/'scripts'))
from hosted_timing.targeted import SCOPES
q=json.loads((r/'continuation-latest-20261028.json').read_text())['performance_continuation_20261103']
profiles=dict(pvo=('pvo_volume_dispatch_draft','pvo-volume-dispatch','20261103'),
    adx=('adx_weighted_certificate_20261104','adx-weighted-certificate','20261104'),
    fisher=('fisher_exact_inputs_20261104','fisher-exact-inputs','20261104'))
def git(*args):
    return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
main=base/'si-parabolic-array-rollback-20261022'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=main,text=True).strip()==a.baseline
assert not subprocess.check_output(['git','status','--porcelain'],cwd=main)
bench=['benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','benchmarks/OoplesFinance.StockIndicators.CompetitorTests']
selected=[];excluded=[];paths=set();classes={arm:set() for arm in ('old','successor')};parity=set();unit_counts={};parity_counts={}
for member,(key,scope,date) in profiles.items():
    record=q[key];run=record['timing_run']
    proof_path=r/'hosted-runs'/str(run)/'verified-targeted-local.json'
    assert proof_path.is_file(), 'All three complete collections are required before composition: '+member
    proof=json.loads(proof_path.read_text())
    assert (proof['case_count'],proof['decision_count'])==SCOPES[scope]['totals']
    assert proof['sources']['new']==record['qualified_source']
    assert {str(d['provenance']['host']['run_id']) for d in proof['decisions']}=={str(run)}
    if not proof['accepted']:
        excluded.append(member);continue
    assert proof['verdicts'].get('faster',0)>0 and not proof['verdicts'].get('slower',0)
    assert not git('diff','--name-only',proof['sources']['old'],a.baseline,'--','src','tests',*bench)
    member_paths=SCOPES[scope]['paths'];assert not paths & member_paths;paths.update(member_paths)
    plan=json.loads((tooling/'benchmarks/plans'/f'hosted-{scope}-{date}.json').read_text())
    for arm in classes:classes[arm].update(plan['cpu_test_classes'][arm])
    parity.update(record['parity'].split(','))
    status=json.loads((r/f'{scope}-{date}'/'status.json').read_text())
    for counts,kind in ((unit_counts,'unit'),(parity_counts,'parity')):
        for name,count in status[kind]['classes'].items():
            assert name not in counts or counts[name]==count
            counts[name]=count
    selected.append(dict(member=member,scope=scope,source=proof['sources']['new'],run_id=run,paths=sorted(member_paths)))
assert 2<=len(selected)<=3
assert set(unit_counts)==classes['successor'] and set(parity_counts)==parity
branch='perf/combined-private-inputs-20261104'
exists=subprocess.run(['git','show-ref','--verify','--quiet','refs/heads/'+branch],cwd=repo).returncode
assert exists in (0,1)
if exists==0:
    assert git('branch','--show-current')==branch and git('rev-parse','HEAD')==a.baseline
    pending=set(git('diff','HEAD','--name-only').splitlines()) | set(git('ls-files','--others','--exclude-standard').splitlines())
    assert pending<=paths, 'Resume only this script-owned partial composition'
else:
    assert not git('status','--porcelain')
    subprocess.run(['git','switch','-c',branch,a.baseline],cwd=repo,check=True)
for member in selected:
    subprocess.run(['git','restore','--source='+member['source'],'--',*member['paths']],cwd=repo,check=True)
    # New test files must enter the index before git diff can compare their blobs.
    subprocess.run(['git','add','--',*member['paths']],cwd=repo,check=True)
    assert not git('diff',member['source'],'--',*member['paths'])
assert set(git('diff','HEAD','--name-only','--','src','tests').splitlines())==paths
assert not git('diff','--name-only',a.baseline,'--',*bench)
subprocess.run(['git','diff','--check'],cwd=repo,check=True)
subprocess.run(['git','add','--',*sorted(paths)],cwd=repo,check=True)
assert set(git('diff','--cached','--name-only').splitlines())==paths
subprocess.run(['git','diff','--cached','--check'],cwd=repo,check=True)
subprocess.run(['git','commit','--quiet','-m','perf: combine qualified private input arithmetic'],cwd=repo,check=True)
source=git('rev-parse','HEAD')
subprocess.run(['git','push','origin','HEAD:refs/heads/'+branch],cwd=repo,check=True)
selection=dict(baseline=a.baseline,source=source,repo=str(repo),branch=branch,selected=selected,excluded=excluded,
    unit=','.join(sorted(classes['successor'])),parity=','.join(sorted(parity)),expected_unit=sum(unit_counts.values()),
    expected_comparator=sum(parity_counts.values()),source_paths=sorted(paths),status='Source composed and pushed; fresh correctness and full combined timing required')
(r/'combined-private-inputs-selection-20261104.json').write_bytes((json.dumps(selection,indent=2)+'\n').encode())
print(json.dumps(selection,indent=2))
