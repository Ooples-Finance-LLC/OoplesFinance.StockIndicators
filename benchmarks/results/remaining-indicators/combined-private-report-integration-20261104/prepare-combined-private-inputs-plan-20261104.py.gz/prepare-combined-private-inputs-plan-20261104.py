"""Freeze fresh timing only for complete, accepted same-baseline candidates."""
import argparse, copy, datetime, hashlib, json, subprocess, sys
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('source')
parser.add_argument('baseline')
parser.add_argument('--members',nargs='+',choices=['pvo','adx','fisher'],required=True)
a=parser.parse_args()
assert 2<=len(a.members)<=3 and len(set(a.members))==len(a.members)
r=Path.cwd();recovery=Path(__file__).parent
sys.path.insert(0,str(r/'scripts'))
from hosted_timing.targeted import SCOPES,verify_reference
q=json.loads((recovery/'continuation-latest-20261028.json').read_text())['performance_continuation_20261103']
profiles=dict(pvo=('pvo_volume_dispatch_draft','pvo-volume-dispatch','20261103'),
    adx=('adx_weighted_certificate_20261104','adx-weighted-certificate','20261104'),
    fisher=('fisher_exact_inputs_20261104','fisher-exact-inputs','20261104'))
status=json.loads((recovery/'combined-private-inputs-20261104/status.json').read_text())
assert status['status']=='correctness-complete'
candidate=Path(status['repo'])
def git(*args):
    return subprocess.check_output(['git',*args],cwd=candidate,text=True).strip()
assert git('rev-parse','HEAD')==a.source and not git('status','--porcelain')
assert not git('diff','--name-only',status['source'],a.source,'--','src','tests')
bench=['benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','benchmarks/OoplesFinance.StockIndicators.CompetitorTests']
assert not git('diff','--name-only',a.baseline,a.source,'--',*bench)
fixtures={};paths=set();classes={arm:set() for arm in ('old','successor')};parity=set();individual=[]
for member in sorted(a.members):
    key,scope,date=profiles[member];record=q[key];run=record['timing_run']
    proof=json.loads((recovery/'hosted-runs'/str(run)/'verified-targeted-local.json').read_text())
    assert proof['accepted'] and proof['verdicts'].get('faster',0)>0 and not proof['verdicts'].get('slower',0)
    definition=SCOPES[scope]
    assert (proof['case_count'],proof['decision_count'])==definition['totals']
    source=proof['sources']['new']
    assert source==record['qualified_source']
    assert {str(d['provenance']['host']['run_id']) for d in proof['decisions']}=={str(run)}
    assert not git('diff','--name-only',proof['sources']['old'],a.baseline,'--','src','tests',*bench)
    assert not (paths & definition['paths'])
    assert not git('diff','--name-only',source,a.source,'--',*sorted(definition['paths']))
    paths.update(definition['paths'])
    for fixture,mapping in definition['fixtures'].items():
        existing=fixtures.setdefault(fixture,{})
        assert not existing.keys() & mapping.keys()
        existing.update(mapping)
    plan=json.loads((r/'benchmarks/plans'/f'hosted-{scope}-{date}.json').read_text())
    for arm in classes:classes[arm].update(plan['cpu_test_classes'][arm])
    parity.update(record['parity'].split(','))
    individual.append(dict(scope=scope,run_id=str(run),source=source,verdicts=proof['verdicts']))
assert set(git('diff','--name-only',a.baseline,a.source,'--','src','tests').splitlines())==paths
assert set(status['unit']['classes'])==classes['successor']
assert set(status['parity']['classes'])==parity
count=sum(len(m) for m in fixtures.values())
assert 2<=count<=6
scope='combined-private-inputs'
definition=dict(fixtures=fixtures,implicit_fixtures=set(),paths=paths,totals=(30*count,6*count),
    shards=count,baseline_phase='targeted',baseline_totals=(30,6))
assert scope not in SCOPES
SCOPES[scope]=definition
p=json.loads((r/'benchmarks/plans/hosted-pvo-volume-dispatch-20261103.json').read_text())
p['sources'].update(published=a.baseline,old=a.baseline,successor=a.source)
p['gpu_sources'].update(old=a.baseline,successor=a.source)
p['cpu_test_classes']={arm:sorted(names) for arm,names in classes.items()}
receipt='benchmarks/results/remaining-indicators/hosted-targeted-41769857963-attempt1/decision.json'
raw=subprocess.check_output(['git','show',a.baseline+':'+receipt],cwd=r)
p['targeted_reference']=dict(scope=scope,run_id='41769857963',decision=receipt,
    sha256=hashlib.sha256(raw).hexdigest(),qualified_source='0285a8217d791857cf3ddeeac34c1aa826d27d65')
p['affected_pairs']=sorted(pair for mapping in fixtures.values() for pair in mapping)
p['cases'],p['decisions']=definition['totals']
p['targeted_shards']=[]
for fixture,mapping in sorted(fixtures.items()):
    for pair,operation in sorted(mapping.items()):
        index=len(p['targeted_shards'])
        tasks=[dict(fixture='LibraryPairBenchmarks',operations=[dict(pair=pair,raw=pair)],
            methods=['Ooples','Competitor'],implicit_pair=False,cases=10,decisions=2),
            dict(fixture=fixture,operations=[dict(pair=pair,raw=operation)],
            methods=['BuilderFull','BuilderLatestOnly','NativeSingle','NativeParallel'],implicit_pair=False,cases=20,decisions=4)]
        p['targeted_shards'].append(dict(index=index,tasks=tasks,cases=30,decisions=6))
p['matrix']=dict(shards=count,max_parallel=count,timeout_minutes_per_shard=180)
gpu=json.loads((candidate/'benchmarks/results/shared-rollout/local-gpu-contracts/receipt.json').read_text())
assert gpu['passed_cases']==100
p['source_correctness']=dict(unit=status['unit']['passed'],comparator=status['parity']['passed'],actual_local_gpu=100,
    source_sha256=gpu['source_sha256'],cpu_build_run=status['build_origin']['run_id'],cpu_build_workflow_head=status['build_origin']['workflow_head'])
p['individual_qualifications']=individual
p['scope']='Fresh combined-source qualification of only accepted PVO/ADX/Fisher private arithmetic candidates.'
p['call_graph']=['Exact source/test equality to every selected qualified member; complete mapped pair union. Shared arithmetic and benchmark code stay unchanged.']
p['limits']=['Only complete accepted individual candidates may enter; no pooling of independent and combined rounds.',
    'Fresh full affected-consumer qualification with at least one faster and zero slower; all SDK/runtime/warmup/iteration/CPU/build/hash/source gates unchanged.',
    'At most180cases36decisions and six isolated pair VMs. PR remains draft.']
p['created_utc']=p['frozen_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
verify_reference(p)
path=r/'benchmarks/plans/hosted-combined-private-inputs-20261104.json'
assert not path.exists()
path.write_text(json.dumps(p,indent=2)+'\n',newline='\n')
targeted=r/'scripts/hosted_timing/targeted.py'
s=targeted.read_text();needle='def expected_totals(plan):';assert s.count(needle)==1
targeted.write_text(s.replace(needle,'SCOPES['+repr(scope)+'] = '+repr(definition)+'\n\n\n'+needle),newline='\n')
w=r/'.github/workflows/cpu-kernel-performance.yml';s=w.read_text()
needle='benchmarks/plans/hosted-fisher-exact-inputs-20261104.json]';assert s.count(needle)==1
w.write_text(s.replace(needle,needle[:-1]+', '+path.relative_to(r).as_posix()+']'),newline='\n')
attributes=r/'.gitattributes'
attributes.write_text(attributes.read_text()+path.relative_to(r).as_posix()+' text eol=lf\n',newline='\n')
test=(r/'scripts/test_hosted_pvo_volume_dispatch.py').read_text()
test=test.replace('Require all four consumers after the private PVO dispatch repair.', 'Require complete accepted private arithmetic consumers.')
test=test.replace('PvoVolumeDispatchTests','CombinedPrivateInputsTests').replace('(120,24)',repr(definition['totals']))
test=test.replace('hosted-pvo-volume-dispatch-20261103','hosted-combined-private-inputs-20261104')
(r/'scripts/test_hosted_combined_private_inputs.py').write_text(test,newline='\n')
print(a.source,sorted(a.members),hashlib.sha256(path.read_bytes()).hexdigest(),p['cases'],p['decisions'])
