```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetCmf** | **1000**  | **123.7 μs** |  **6.96 μs** |  **4.60 μs** |  **3.9063** |       **-** |  **85.73 KB** |
| BuilderLatestOnly | Skender.GetCmf | 1000  | 119.7 μs |  4.71 μs |  3.11 μs |  1.9531 |       - |  38.13 KB |
| **BuilderFull**       | **Skender.GetCmf** | **10000** | **486.8 μs** |  **9.09 μs** |  **4.76 μs** | **46.8750** | **19.5313** | **789.24 KB** |
| BuilderLatestOnly | Skender.GetCmf | 10000 | 467.0 μs | 35.27 μs | 23.33 μs | 15.6250 |  3.9063 | 319.41 KB |
