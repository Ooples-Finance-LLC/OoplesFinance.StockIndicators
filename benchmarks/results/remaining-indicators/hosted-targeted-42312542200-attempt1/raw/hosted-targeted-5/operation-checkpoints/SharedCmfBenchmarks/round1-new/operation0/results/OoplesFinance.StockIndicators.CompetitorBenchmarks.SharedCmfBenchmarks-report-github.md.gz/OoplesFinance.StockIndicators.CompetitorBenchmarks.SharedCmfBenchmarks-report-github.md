```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetCmf** | **1000**  | **123.2 μs** |  **6.93 μs** |  **4.58 μs** |  **3.9063** |       **-** |  **85.73 KB** |
| BuilderLatestOnly | Skender.GetCmf | 1000  | 121.8 μs |  4.24 μs |  2.80 μs |  1.9531 |       - |  38.13 KB |
| **BuilderFull**       | **Skender.GetCmf** | **10000** | **497.3 μs** | **39.16 μs** | **25.90 μs** | **46.8750** | **19.5313** | **789.24 KB** |
| BuilderLatestOnly | Skender.GetCmf | 10000 | 457.6 μs |  6.40 μs |  3.35 μs | 15.6250 |  3.9063 | 319.41 KB |
