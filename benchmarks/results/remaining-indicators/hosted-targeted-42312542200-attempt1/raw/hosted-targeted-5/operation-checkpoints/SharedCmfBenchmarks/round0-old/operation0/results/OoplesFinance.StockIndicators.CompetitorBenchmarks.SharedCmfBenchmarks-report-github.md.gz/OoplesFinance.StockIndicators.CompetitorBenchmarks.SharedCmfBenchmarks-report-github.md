```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetCmf** | **1000**  | **123.7 μs** |  **8.20 μs** |  **5.42 μs** |  **3.9063** |       **-** |   **85.7 KB** |
| BuilderLatestOnly | Skender.GetCmf | 1000  | 118.0 μs |  1.75 μs |  0.92 μs |  1.9531 |       - |  38.13 KB |
| **BuilderFull**       | **Skender.GetCmf** | **10000** | **485.0 μs** |  **8.85 μs** |  **4.63 μs** | **46.8750** | **19.5313** | **789.21 KB** |
| BuilderLatestOnly | Skender.GetCmf | 10000 | 474.3 μs | 34.53 μs | 22.84 μs | 15.6250 |  3.9063 | 319.41 KB |
