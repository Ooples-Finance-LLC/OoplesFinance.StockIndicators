```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetCmf** | **1000**  |   **123.70 μs** |  **6.890 μs** |  **4.557 μs** |  **1.31** |    **0.05** |   **3.9063** |        **-** |       **-** |   **85.73 KB** |        **0.29** |
| BuilderLatestOnly | Skender.GetCmf | 1000  |   119.63 μs |  6.357 μs |  3.783 μs |  1.27 |    0.04 |   1.9531 |        - |       - |   38.13 KB |        0.13 |
| NativeSingle      | Skender.GetCmf | 1000  |    94.40 μs |  2.054 μs |  1.222 μs |  1.00 |    0.02 |  18.0664 |   4.8828 |       - |  297.89 KB |        1.00 |
| NativeParallel    | Skender.GetCmf | 1000  |   139.37 μs |  7.655 μs |  5.063 μs |  1.48 |    0.05 |  20.5078 |   4.8828 |       - |   326.3 KB |        1.10 |
|                   |                |       |             |           |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skender.GetCmf** | **10000** |   **498.67 μs** | **32.692 μs** | **21.624 μs** |  **0.41** |    **0.02** |  **46.8750** |  **19.5313** |       **-** |  **789.24 KB** |        **0.27** |
| BuilderLatestOnly | Skender.GetCmf | 10000 |   455.70 μs |  8.012 μs |  4.190 μs |  0.38 |    0.00 |  15.6250 |   3.9063 |       - |  319.41 KB |        0.11 |
| NativeSingle      | Skender.GetCmf | 10000 | 1,201.73 μs | 10.462 μs |  5.472 μs |  1.00 |    0.01 | 195.3125 | 148.4375 | 46.8750 | 2970.19 KB |        1.00 |
| NativeParallel    | Skender.GetCmf | 10000 |   792.23 μs | 46.781 μs | 30.943 μs |  0.66 |    0.02 | 195.3125 | 117.1875 |       - | 3068.51 KB |        1.03 |
