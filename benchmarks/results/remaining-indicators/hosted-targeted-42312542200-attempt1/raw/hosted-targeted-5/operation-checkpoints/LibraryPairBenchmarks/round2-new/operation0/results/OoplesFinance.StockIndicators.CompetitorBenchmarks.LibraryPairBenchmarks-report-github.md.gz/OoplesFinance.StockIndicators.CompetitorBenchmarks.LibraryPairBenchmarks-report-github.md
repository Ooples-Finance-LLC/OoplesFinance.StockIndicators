```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetCmf** |   **156.3 μs** |   **4.66 μs** |   **2.43 μs** |  **1.00** |    **0.02** |  **189.85 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetCmf |   107.1 μs |   7.79 μs |   4.64 μs |  0.69 |    0.03 |  386.11 KB |        2.03 |
|            |       |                |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetCmf** | **1,738.5 μs** | **270.44 μs** | **160.94 μs** |  **1.01** |    **0.13** | **1841.23 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetCmf | 1,142.0 μs |  75.44 μs |  49.90 μs |  0.66 |    0.07 | 3789.49 KB |        2.06 |
