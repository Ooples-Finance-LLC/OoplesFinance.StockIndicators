```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|----------:|----------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Accum(...)nLine [28]** | **1000**  |   **119.2 μs** |   **0.98 μs** |   **0.58 μs** |  **0.27** |    **0.00** |    **7.8125** |         **-** |        **-** |  **153.97 KB** |        **0.26** |
| BuilderLatestOnly | Accum(...)nLine [28] | 1000  |   118.5 μs |   1.01 μs |   0.53 μs |  0.27 |    0.00 |    5.8594 |         - |        - |  106.36 KB |        0.18 |
| NativeSingle      | Accum(...)nLine [28] | 1000  |   439.5 μs |   4.98 μs |   2.97 μs |  1.00 |    0.01 |   35.1563 |   11.7188 |        - |  594.33 KB |        1.00 |
| NativeParallel    | Accum(...)nLine [28] | 1000  |   438.5 μs |  37.07 μs |  24.52 μs |  1.00 |    0.05 |   54.6875 |   19.5313 |        - |  894.29 KB |        1.50 |
|                   |                      |       |            |           |           |       |         |           |           |          |            |             |
| **BuilderFull**       | **Accum(...)nLine [28]** | **10000** | **1,539.4 μs** |  **27.34 μs** |  **16.27 μs** |  **0.30** |    **0.01** |  **117.1875** |   **54.6875** |        **-** | **1931.45 KB** |        **0.33** |
| BuilderLatestOnly | Accum(...)nLine [28] | 10000 | 1,516.5 μs |   9.52 μs |   4.98 μs |  0.29 |    0.00 |   85.9375 |   23.4375 |        - | 1461.64 KB |        0.25 |
| NativeSingle      | Accum(...)nLine [28] | 10000 | 5,176.9 μs | 113.90 μs |  75.34 μs |  1.00 |    0.02 |  656.2500 |  468.7500 | 437.5000 | 5824.03 KB |        1.00 |
| NativeParallel    | Accum(...)nLine [28] | 10000 | 5,882.1 μs | 583.31 μs | 385.82 μs |  1.14 |    0.07 | 1187.5000 | 1000.0000 | 906.2500 | 8719.29 KB |        1.50 |
