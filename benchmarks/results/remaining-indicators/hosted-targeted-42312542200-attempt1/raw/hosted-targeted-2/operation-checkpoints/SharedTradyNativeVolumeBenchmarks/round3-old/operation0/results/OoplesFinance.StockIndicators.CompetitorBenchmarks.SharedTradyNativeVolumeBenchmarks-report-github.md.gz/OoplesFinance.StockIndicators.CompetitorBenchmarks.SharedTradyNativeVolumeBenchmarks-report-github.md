```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0     | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Accum(...)nLine [28]** | **1000**  |   **121.4 μs** |  **5.97 μs** |  **3.55 μs** |   **7.8125** |       **-** |  **153.93 KB** |
| BuilderLatestOnly | Accum(...)nLine [28] | 1000  |   118.9 μs |  5.47 μs |  3.26 μs |   5.8594 |       - |  106.36 KB |
| **BuilderFull**       | **Accum(...)nLine [28]** | **10000** | **1,506.8 μs** | **27.43 μs** | **18.15 μs** | **117.1875** | **54.6875** | **1931.42 KB** |
| BuilderLatestOnly | Accum(...)nLine [28] | 10000 | 1,583.7 μs | 43.44 μs | 25.85 μs |  78.1250 | 15.6250 | 1461.68 KB |
