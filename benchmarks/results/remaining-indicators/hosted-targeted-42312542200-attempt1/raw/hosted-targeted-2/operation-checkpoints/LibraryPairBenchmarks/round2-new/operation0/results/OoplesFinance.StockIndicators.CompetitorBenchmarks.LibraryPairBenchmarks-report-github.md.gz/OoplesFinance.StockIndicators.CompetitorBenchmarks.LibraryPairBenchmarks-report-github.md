```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)nLine [44]** |   **167.4 μs** |  **17.07 μs** | **11.29 μs** |  **1.00** |    **0.09** |  **194.64 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)nLine [44] |   959.5 μs |  30.80 μs | 18.33 μs |  5.75 |    0.37 |  895.47 KB |        4.60 |
|            |       |                      |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **Trady(...)nLine [44]** | **1,712.1 μs** |  **66.72 μs** | **44.13 μs** |  **1.00** |    **0.03** | **2337.57 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)nLine [44] | 7,517.2 μs | 130.67 μs | 77.76 μs |  4.39 |    0.11 |  8811.1 KB |        3.77 |
