```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |    **32.61 μs** |  **3.251 μs** |  **1.935 μs** |  **0.58** |    **0.03** |   **5.3711** |   **0.9766** |   **88.31 KB** |        **0.50** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |    29.04 μs |  0.264 μs |  0.138 μs |  0.52 |    0.00 |   2.4414 |   0.2441 |    40.7 KB |        0.23 |
| NativeSingle      | Skender.GetAdl | 1000  |    55.77 μs |  0.595 μs |  0.354 μs |  1.00 |    0.01 |  10.7422 |   2.4414 |  176.21 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 1000  |   146.32 μs |  6.537 μs |  3.890 μs |  2.62 |    0.07 |  27.3438 |   7.8125 |  449.41 KB |        2.55 |
|                   |                |       |             |           |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetAdl** | **10000** |   **298.72 μs** |  **2.492 μs** |  **1.303 μs** |  **0.47** |    **0.00** |  **50.7813** |  **17.5781** |  **862.11 KB** |        **0.49** |
| BuilderLatestOnly | Skender.GetAdl | 10000 |   278.26 μs |  1.536 μs |  0.914 μs |  0.44 |    0.00 |  23.4375 |   9.7656 |  392.29 KB |        0.22 |
| NativeSingle      | Skender.GetAdl | 10000 |   630.72 μs |  5.689 μs |  2.976 μs |  1.00 |    0.01 | 105.4688 |  66.4063 | 1758.26 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 10000 | 1,365.95 μs | 67.119 μs | 44.395 μs |  2.17 |    0.07 | 273.4375 | 203.1250 | 4474.84 KB |        2.55 |
