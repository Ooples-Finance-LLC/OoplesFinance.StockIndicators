```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAdl** |   **424.68 μs** | **10.910 μs** |  **5.706 μs** |  **1.00** |    **0.02** |  **246.88 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAdl |    66.26 μs |  1.342 μs |  0.799 μs |  0.16 |    0.00 |     273 KB |        1.11 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAdl** | **1,883.51 μs** | **15.475 μs** |  **9.209 μs** |  **1.00** |    **0.01** | **2811.05 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAdl |   679.26 μs | 21.723 μs | 11.361 μs |  0.36 |    0.01 | 2654.88 KB |        0.94 |
