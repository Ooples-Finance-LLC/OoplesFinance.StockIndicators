```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)dDoji [28]** | **1000**  |  **81.61 μs** |  **0.350 μs** |  **0.208 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)dDoji [28] | 1000  | 118.21 μs |  4.260 μs |  2.535 μs |  1.45 |    0.03 |       - |       - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib(...)dDoji [28] | 1000  |  73.72 μs |  1.414 μs |  0.739 μs |  0.90 |    0.01 |  2.9297 |       - |  57.27 KB |       14.43 |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 1000  |  67.26 μs |  0.639 μs |  0.380 μs |  0.82 |    0.00 |  0.4883 |       - |   9.38 KB |        2.36 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)dDoji [28]** | **10000** | **618.97 μs** |  **3.262 μs** |  **1.706 μs** |  **1.00** |    **0.00** |       **-** |       **-** |  **39.16 KB** |        **1.00** |
| NativeParallel    | TaLib(...)dDoji [28] | 10000 | 442.42 μs | 69.997 μs | 46.299 μs |  0.71 |    0.07 |  3.9063 |       - |  78.72 KB |        2.01 |
| BuilderFull       | TaLib(...)dDoji [28] | 10000 | 670.78 μs |  6.454 μs |  3.375 μs |  1.08 |    0.01 | 31.2500 | 11.7188 | 549.83 KB |       14.04 |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 10000 | 629.76 μs |  6.358 μs |  3.325 μs |  1.02 |    0.01 |  3.9063 |       - |  79.72 KB |        2.04 |
