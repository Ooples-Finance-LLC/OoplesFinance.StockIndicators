```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dDoji [28]** | **108.61 μs** |  **4.016 μs** |  **2.101 μs** |  **1.00** |    **0.03** |  **65.32 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dDoji [28] |  77.06 μs |  1.688 μs |  0.883 μs |  0.71 |    0.01 |  19.58 KB |        0.30 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)dDoji [28]** | **616.04 μs** | **23.087 μs** | **13.739 μs** |  **1.00** |    **0.03** | **635.33 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dDoji [28] | 773.38 μs | 26.255 μs | 17.366 μs |  1.26 |    0.04 | 124.77 KB |        0.20 |
