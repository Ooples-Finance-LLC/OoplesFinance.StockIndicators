```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Candles.Harami** | **1000**  | **148.9 μs** | **25.38 μs** | **16.79 μs** |  **3.9063** |       **-** |  **63.69 KB** |
| BuilderLatestOnly | TaLib.Candles.Harami | 1000  | 117.4 μs |  5.71 μs |  3.77 μs |  0.9766 |       - |  15.81 KB |
| **BuilderFull**       | **TaLib.Candles.Harami** | **10000** | **386.4 μs** | **13.40 μs** |  **7.01 μs** | **31.2500** | **11.7188** | **556.26 KB** |
| BuilderLatestOnly | TaLib.Candles.Harami | 10000 | 379.3 μs | 26.16 μs | 17.30 μs |  3.9063 |       - |  86.14 KB |
