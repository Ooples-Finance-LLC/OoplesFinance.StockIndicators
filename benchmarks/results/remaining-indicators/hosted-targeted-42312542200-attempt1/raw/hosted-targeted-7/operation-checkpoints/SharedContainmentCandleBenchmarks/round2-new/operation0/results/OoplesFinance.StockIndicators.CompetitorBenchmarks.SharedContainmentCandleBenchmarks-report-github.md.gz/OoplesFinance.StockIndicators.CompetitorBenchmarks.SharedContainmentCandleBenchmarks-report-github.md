```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib.Candles.Harami** | **1000**  |  **81.18 μs** |  **1.201 μs** |  **0.715 μs** |  **1.00** |    **0.01** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Harami | 1000  | 110.61 μs |  3.093 μs |  1.841 μs |  1.36 |    0.02 |       - |       - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib.Candles.Harami | 1000  | 121.97 μs |  7.163 μs |  4.263 μs |  1.50 |    0.05 |  3.9063 |       - |   63.7 KB |       16.05 |
| BuilderLatestOnly | TaLib.Candles.Harami | 1000  | 118.68 μs |  5.717 μs |  3.782 μs |  1.46 |    0.05 |  0.9766 |       - |  15.81 KB |        3.98 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib.Candles.Harami** | **10000** | **461.05 μs** |  **3.364 μs** |  **2.002 μs** |  **1.00** |    **0.01** |       **-** |       **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Harami | 10000 | 340.68 μs | 20.374 μs | 13.476 μs |  0.74 |    0.03 |  5.8594 |       - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib.Candles.Harami | 10000 | 394.81 μs | 25.344 μs | 16.763 μs |  0.86 |    0.03 | 33.2031 | 13.6719 | 556.24 KB |       14.21 |
| BuilderLatestOnly | TaLib.Candles.Harami | 10000 | 383.07 μs | 36.983 μs | 24.462 μs |  0.83 |    0.05 |  3.9063 |       - |  86.14 KB |        2.20 |
