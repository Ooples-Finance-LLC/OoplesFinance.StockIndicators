```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Candles.Harami** | **1000**  | **141.2 μs** | **23.60 μs** | **15.61 μs** |  **3.9063** |       **-** |  **63.65 KB** |
| BuilderLatestOnly | TaLib.Candles.Harami | 1000  | 116.7 μs |  3.41 μs |  2.03 μs |  0.9766 |       - |  15.81 KB |
| **BuilderFull**       | **TaLib.Candles.Harami** | **10000** | **393.9 μs** | **23.58 μs** | **14.03 μs** | **31.2500** | **11.7188** | **556.22 KB** |
| BuilderLatestOnly | TaLib.Candles.Harami | 10000 | 384.7 μs | 27.17 μs | 17.97 μs |  3.9063 |       - |  86.14 KB |
