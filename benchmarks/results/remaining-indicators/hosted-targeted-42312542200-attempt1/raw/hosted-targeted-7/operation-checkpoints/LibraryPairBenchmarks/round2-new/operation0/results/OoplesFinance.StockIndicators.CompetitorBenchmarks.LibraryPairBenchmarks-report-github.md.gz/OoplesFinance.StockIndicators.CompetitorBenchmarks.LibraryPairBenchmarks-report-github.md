```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Candles.Harami** |  **95.58 μs** | **28.453 μs** | **16.932 μs** |  **1.02** |    **0.23** |  **68.38 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Candles.Harami |  61.42 μs |  0.790 μs |  0.413 μs |  0.66 |    0.10 |  18.59 KB |        0.27 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Candles.Harami** | **374.57 μs** | **23.726 μs** | **14.119 μs** |  **1.00** |    **0.05** |    **639 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Candles.Harami | 607.64 μs | 24.592 μs | 16.266 μs |  1.62 |    0.07 | 124.44 KB |        0.19 |
