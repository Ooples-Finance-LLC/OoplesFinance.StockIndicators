```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean         | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-------------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ad** |   **187.090 μs** | **11.7488 μs** |  **7.7711 μs** |  **1.00** |    **0.06** |   **160.8 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ad |     5.537 μs |  0.2271 μs |  0.1188 μs |  0.03 |    0.00 |    8.15 KB |        0.05 |
|            |       |                    |              |            |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ad** | **1,809.933 μs** | **71.4234 μs** | **42.5029 μs** |  **1.00** |    **0.03** | **2012.23 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ad |    26.633 μs |  3.2822 μs |  1.9532 μs |  0.01 |    0.00 |   83.66 KB |        0.04 |
