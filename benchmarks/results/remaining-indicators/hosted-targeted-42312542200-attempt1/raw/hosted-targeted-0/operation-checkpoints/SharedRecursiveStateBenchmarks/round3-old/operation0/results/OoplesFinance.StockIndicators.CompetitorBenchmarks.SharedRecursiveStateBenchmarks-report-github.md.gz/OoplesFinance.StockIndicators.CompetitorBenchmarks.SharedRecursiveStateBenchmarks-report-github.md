```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error    | StdDev  | Allocated |
|------------------ |---------- |------ |-----------:|---------:|--------:|----------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **116.3 μs** |  **2.09 μs** | **1.25 μs** |  **64.88 KB** |
| BuilderLatestOnly | Ad        | 1000  |   113.3 μs |  1.17 μs | 0.61 μs |  17.27 KB |
| **BuilderFull**       | **Ad**        | **10000** | **1,065.5 μs** | **16.20 μs** | **9.64 μs** | **627.76 KB** |
| BuilderLatestOnly | Ad        | 10000 |   968.5 μs | 10.98 μs | 5.74 μs | 157.95 KB |
