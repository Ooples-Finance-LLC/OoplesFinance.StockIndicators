```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |---------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **128.9 μs** |  **2.01 μs** |  **1.05 μs** |  **64.88 KB** |
| BuilderLatestOnly | Ad        | 1000  |   106.9 μs |  1.17 μs |  0.70 μs |  17.27 KB |
| **BuilderFull**       | **Ad**        | **10000** | **1,086.1 μs** |  **7.99 μs** |  **4.18 μs** | **627.77 KB** |
| BuilderLatestOnly | Ad        | 10000 | 1,021.1 μs | 42.70 μs | 28.24 μs | 157.96 KB |
