```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0   | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |-------------:|-----------:|-----------:|------:|--------:|-------:|-------:|----------:|------------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **118.806 μs** |  **1.5293 μs** |  **0.7998 μs** | **44.29** |    **0.35** |      **-** |      **-** |  **64.88 KB** |        **8.24** |
| BuilderLatestOnly | Ad        | 1000  |   106.585 μs |  1.2055 μs |  0.7174 μs | 39.74 |    0.31 |      - |      - |  17.27 KB |        2.19 |
| NativeSingle      | Ad        | 1000  |     2.682 μs |  0.0250 μs |  0.0131 μs |  1.00 |    0.01 | 0.0916 |      - |   7.88 KB |        1.00 |
| NativeParallel    | Ad        | 1000  |    61.399 μs |  4.2884 μs |  2.8365 μs | 22.89 |    1.01 |      - |      - |   8.17 KB |        1.04 |
|                   |           |       |              |            |            |       |         |        |        |           |             |
| **BuilderFull**       | **Ad**        | **10000** | **1,082.527 μs** | **13.9458 μs** |  **8.2989 μs** | **49.20** |    **0.42** |      **-** |      **-** | **627.76 KB** |        **8.03** |
| BuilderLatestOnly | Ad        | 10000 |   996.549 μs | 39.9452 μs | 26.4213 μs | 45.29 |    1.16 |      - |      - | 157.96 KB |        2.02 |
| NativeSingle      | Ad        | 10000 |    22.004 μs |  0.1686 μs |  0.1003 μs |  1.00 |    0.01 | 0.8545 | 0.1221 |  78.19 KB |        1.00 |
| NativeParallel    | Ad        | 10000 |    84.839 μs |  5.6441 μs |  3.7332 μs |  3.86 |    0.16 | 0.4883 |      - |  78.48 KB |        1.00 |
