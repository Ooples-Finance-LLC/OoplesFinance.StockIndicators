```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **244.8 μs** |  **3.82 μs** |  **2.00 μs** |       **-** |       **-** |  **96.99 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   242.0 μs |  2.42 μs |  1.44 μs |  1.9531 |       - |  49.42 KB |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **2,601.3 μs** | **21.89 μs** | **11.45 μs** | **46.8750** | **15.6250** | **941.19 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 2,587.9 μs | 28.39 μs | 16.89 μs | 15.6250 |       - | 471.38 KB |
