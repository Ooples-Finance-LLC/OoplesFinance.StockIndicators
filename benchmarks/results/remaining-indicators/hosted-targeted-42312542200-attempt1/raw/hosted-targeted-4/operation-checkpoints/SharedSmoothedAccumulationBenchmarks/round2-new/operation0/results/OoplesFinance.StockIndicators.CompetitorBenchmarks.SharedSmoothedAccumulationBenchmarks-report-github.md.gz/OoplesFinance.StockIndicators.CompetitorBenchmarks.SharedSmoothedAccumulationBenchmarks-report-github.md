```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **245.24 μs** |  **1.991 μs** |  **1.185 μs** |  **3.57** |    **0.09** |        **-** |        **-** |       **-** |   **97.06 KB** |        **0.26** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   242.08 μs |  1.049 μs |  0.549 μs |  3.52 |    0.09 |   1.9531 |        - |       - |   49.42 KB |        0.13 |
| NativeSingle      | Skend(...)inOsc [21] | 1000  |    68.78 μs |  2.921 μs |  1.738 μs |  1.00 |    0.03 |  22.9492 |   6.8359 |       - |  379.71 KB |        1.00 |
| NativeParallel    | Skend(...)inOsc [21] | 1000  |   172.01 μs | 15.994 μs |  9.518 μs |  2.50 |    0.14 |  58.5938 |  19.5313 |       - |  958.69 KB |        2.52 |
|                   |                      |       |             |           |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **2,650.47 μs** | **93.736 μs** | **55.781 μs** |  **2.92** |    **0.08** |  **46.8750** |  **15.6250** |       **-** |  **941.24 KB** |        **0.25** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 2,634.40 μs | 22.989 μs | 12.024 μs |  2.90 |    0.05 |  15.6250 |        - |       - |  471.41 KB |        0.12 |
| NativeSingle      | Skend(...)inOsc [21] | 10000 |   909.34 μs | 29.760 μs | 17.710 μs |  1.00 |    0.03 | 242.1875 | 148.4375 | 46.8750 | 3790.29 KB |        1.00 |
| NativeParallel    | Skend(...)inOsc [21] | 10000 | 2,182.16 μs | 70.314 μs | 46.509 μs |  2.40 |    0.07 | 593.7500 | 515.6250 | 78.1250 | 9555.11 KB |        2.52 |
