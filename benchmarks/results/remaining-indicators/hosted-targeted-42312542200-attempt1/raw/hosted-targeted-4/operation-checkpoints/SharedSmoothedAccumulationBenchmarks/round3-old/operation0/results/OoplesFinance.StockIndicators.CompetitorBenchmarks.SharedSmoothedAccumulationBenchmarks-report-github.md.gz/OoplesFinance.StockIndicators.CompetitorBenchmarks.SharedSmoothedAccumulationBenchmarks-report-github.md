```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **243.9 μs** |  **2.52 μs** |  **1.50 μs** |       **-** |       **-** |  **97.06 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   247.2 μs |  2.15 μs |  1.28 μs |  1.9531 |       - |  49.42 KB |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **2,549.2 μs** |  **6.93 μs** |  **4.12 μs** | **46.8750** | **15.6250** | **941.24 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 2,551.0 μs | 19.68 μs | 11.71 μs | 15.6250 |       - | 471.36 KB |
