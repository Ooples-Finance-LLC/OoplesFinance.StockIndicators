```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)inOsc [21]** |   **390.64 μs** |  **4.228 μs** |  **2.211 μs** |  **1.00** |  **259.67 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)inOsc [21] |    81.66 μs |  6.649 μs |  3.957 μs |  0.21 |  494.53 KB |        1.90 |
|            |       |                      |             |           |           |       |            |             |
| **Ooples**     | **10000** | **Skend(...)inOsc [21]** | **3,565.49 μs** | **14.757 μs** |  **8.782 μs** |  **1.00** | **2551.02 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)inOsc [21] |   816.94 μs | 24.742 μs | 14.723 μs |  0.23 | 4852.22 KB |        1.90 |
