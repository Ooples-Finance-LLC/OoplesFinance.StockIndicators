```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **329.6 μs** |  **1.31 μs** |  **0.68 μs** |       **-** |  **73.53 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   324.5 μs |  2.38 μs |  1.42 μs |       - |  25.92 KB |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **3,283.0 μs** | **74.57 μs** | **49.32 μs** | **31.2500** |  **706.9 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 3,286.7 μs | 37.08 μs | 22.06 μs |       - | 237.09 KB |
