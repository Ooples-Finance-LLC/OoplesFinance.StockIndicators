```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **325.1 μs** |   **1.42 μs** |   **0.74 μs** |       **-** |  **73.52 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   338.4 μs |  18.29 μs |  10.89 μs |       - |  25.92 KB |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **3,315.8 μs** |  **85.82 μs** |  **51.07 μs** | **31.2500** | **706.93 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 3,407.4 μs | 322.06 μs | 213.02 μs |       - |  237.1 KB |
