```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio  | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|-------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **314.836 μs** |  **5.8506 μs** |  **3.0600 μs** | **103.30** |    **1.40** |       **-** |      **-** |  **73.52 KB** |        **9.42** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   316.159 μs |  2.2749 μs |  1.1898 μs | 103.73 |    1.10 |       - |      - |  25.92 KB |        3.32 |
| NativeSingle      | TaLib(...)AdOsc [21] | 1000  |     3.048 μs |  0.0541 μs |  0.0322 μs |   1.00 |    0.01 |  0.4730 |      - |    7.8 KB |        1.00 |
| NativeParallel    | TaLib(...)AdOsc [21] | 1000  |    91.181 μs |  1.5405 μs |  1.0189 μs |  29.92 |    0.44 |  1.4648 |      - |  27.57 KB |        3.53 |
|                   |                      |       |              |            |            |        |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **3,235.965 μs** | **49.0311 μs** | **32.4311 μs** | **109.21** |    **1.76** | **31.2500** |      **-** |  **706.9 KB** |        **9.05** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 3,151.398 μs | 17.1641 μs |  8.9771 μs | 106.35 |    1.42 |       - |      - | 237.09 KB |        3.04 |
| NativeSingle      | TaLib(...)AdOsc [21] | 10000 |    29.636 μs |  0.6930 μs |  0.4124 μs |   1.00 |    0.02 |  4.6387 |      - |  78.12 KB |        1.00 |
| NativeParallel    | TaLib(...)AdOsc [21] | 10000 |   133.355 μs |  3.9747 μs |  2.3653 μs |   4.50 |    0.10 | 17.5781 | 3.9063 | 273.66 KB |        3.50 |
