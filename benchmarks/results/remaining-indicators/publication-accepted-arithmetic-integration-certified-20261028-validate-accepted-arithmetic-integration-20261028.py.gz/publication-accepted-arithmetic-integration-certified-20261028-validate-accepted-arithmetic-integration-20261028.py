"""Recover the next bounded publication batch without accessing the repairing drive."""
import collections
import sys
import datetime
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import psutil
import shutil
import subprocess
import time
import xml.etree.ElementTree as ET
from compact_macd_acceptance import qualifies

repo=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
root=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
out=root/'accepted-arithmetic-integration-20261028';out.mkdir(exist_ok=True)
temporary=root/'temp';temporary.mkdir(exist_ok=True)
os.environ['TEMP']=os.environ['TMP']=str(temporary)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert len(sys.argv)==3, 'Usage: validator MACD_VARIANT ZIGZAG_VARIANT'
macd,zigzag=sys.argv[1:]
assert macd in ('none','fused','fixed') and zigzag in ('published','compact')
assert (macd,zigzag)!=('none','published'), 'No source change requires no new build'
assert json.loads((root/'fixed-macd-correctness-four-timings-20261028.json').read_text())['step']=='four-batches-qualified-publication-review-pending'
assert json.loads((root/'zigzag-compact-publication-continuation-20261028.json').read_text())['step']=='qualified-awaiting-acceptance-and-publication-review'
for process in psutil.process_iter(['name','cmdline']):
    assert not ((process.info['name'] or '').lower()=='dotnet.exe' and any('OoplesFinance.StockIndicators.CompetitorBenchmarks.dll' in arg for arg in (process.info['cmdline'] or []))), 'A benchmark is still active'
names=['afirma-compact','zigzag-compact-publication' if zigzag=='compact' else 'zigzag-exact-scale']
if macd!='none':names.append('compact-macd-'+('fixed' if macd=='fixed' else 'fused')+'-recurrence')
expected_units={};expected_parity={};expected_changes=set()
for name in names:
    qualified=json.loads((root/name/'status.json').read_text())
    assert qualified['status']=='checks-passed-review-and-publication-pending'
    summary=json.loads((root/('local-'+name+'-control-20261028')/'verified-summary.json').read_text())
    if name.startswith('compact-macd-'):
        assert summary['all_384_cases_verified'] and qualifies(summary['decisions'])
    else:
        assert summary['all_16_cases_verified']
        assert any(row['verdict']=='faster' for row in summary['decisions']) and not any(row['verdict']=='slower' for row in summary['decisions'])
    matched_paths=set(qualified['reviewed_source_changes'])
    if name=='compact-macd-fixed-recurrence':
        matched_paths.update(json.loads((root/'compact-macd-fused-recurrence/status.json').read_text())['reviewed_source_changes'])
    subprocess.run(['git','diff','--exit-code',summary['sources']['new'],head,'--',*sorted(matched_paths)],cwd=repo,check=True)
    for label,target in [('unit',expected_units),('parity',expected_parity)]:
        for key,count in qualified[label]['class_counts'].items():
            assert key not in target or target[key]==count
            target[key]=count
    if name not in ('afirma-compact','zigzag-exact-scale'):
        expected_changes.update(qualified['reviewed_source_changes'])
if macd=='fixed':
    expected_changes.update(json.loads((root/'compact-macd-fused-recurrence/status.json').read_text())['reviewed_source_changes'])
state=dict(input_head=head,source='Fresh combined-tree validation of accepted arithmetic candidates',checks={},drive='C:',status='starting',macd_variant=macd,zigzag_variant=zigzag,qualified_batches=names)

def save(status,step):
    state.update(status=status,step=step,updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    path=out/'status.tmp';path.write_text(json.dumps(state,indent=2),encoding='utf-8');path.replace(out/'status.json')
    print(status,step,flush=True)
def capacity():
    pass # Correctness work may run while unrelated builds exist; timing remains stopped.

def run(label,args):
    if label.startswith('build-'):capacity()
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
    save('running',label)
    with (out/(label+'.log')).open('wb') as stream:
        subprocess.run(args,cwd=repo,env=os.environ.copy(),stdout=stream,stderr=subprocess.STDOUT,check=True)
    state['checks'][label]='passed'
def verify(label,expected):
    path=out/label/(label+'.trx');raw=path.read_bytes();tree=ET.fromstring(raw)
    assert tree.find('.//{*}ResultSummary').attrib['outcome']=='Completed'
    definitions={t.attrib['id']:t.find('.//{*}TestMethod').attrib['className'].split(',')[0].rsplit('.',1)[-1]
        for t in tree.findall('.//{*}UnitTest')}
    results=tree.findall('.//{*}UnitTestResult')
    assert results and all(t.attrib['outcome']=='Passed' for t in results)
    counts=dict(collections.Counter(definitions[t.attrib['testId']] for t in results))
    assert counts.keys()==expected.keys(),(counts,expected)
    assert all(counts[k]>0 and (v is None or counts[k]==v) for k,v in expected.items()),(counts,expected)
    state[label]=dict(passed=len(results),class_counts=counts,trx=str(path),sha256=hashlib.sha256(raw).hexdigest())
def test(label,dll,classes):
    run(label,['dotnet','vstest',str(repo/dll),'/TestCaseFilter:'+'|'.join('FullyQualifiedName~.'+x+'.' for x in classes),
        '/Logger:trx;LogFileName='+label+'.trx','/ResultsDirectory:'+str(out/label)])
    verify(label,classes)
try:
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
    expected=expected_changes
    changes=set(subprocess.check_output(['git','diff','--name-only','d4b72c87e0ce61de3a5a4f3a3b6803e86250e8db',head,'--','src','tests','examples','benchmarks/OoplesFinance.StockIndicators.CompetitorTests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','scripts','.github','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json','NuGet.Config','nuget.config'],cwd=repo,text=True).splitlines())
    assert changes==expected,changes
    state['reviewed_source_changes']=sorted(changes)
    state['batch_note']='Fresh combined-tree validation of accepted MACD/ZigZag candidates with published Afirma; affected numerical, parity, GPU, and inventory checks. Individual timing sources remain explicit.'
    run('build-unit',['dotnet','build','tests/OoplesFinance.StockIndicators.Tests.Unit.csproj','-c','Release','-p:GeneratePackageOnBuild=false','-p:UseSharedCompilation=false','-m:1'])
    test('unit','tests/bin/Release/net10.0/OoplesFinance.StockIndicators.Tests.Unit.dll',expected_units)
    run('build-benchmark',['dotnet','build','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','-c','Release','-p:BuildProjectReferences=false','-p:GeneratePackageOnBuild=false','-p:UseSharedCompilation=false','-m:1'])
    run('build-comparator',['dotnet','build','benchmarks/OoplesFinance.StockIndicators.CompetitorTests','-c','Release','-p:BuildProjectReferences=false','-p:GeneratePackageOnBuild=false','-p:UseSharedCompilation=false','-m:1'])
    test('parity','benchmarks/OoplesFinance.StockIndicators.CompetitorTests/bin/Release/net10.0/OoplesFinance.StockIndicators.CompetitorTests.dll',expected_parity)
    spec=importlib.util.spec_from_file_location('gpu',repo/'scripts/verify-competitor-local-gpu.py')
    gpu=importlib.util.module_from_spec(spec);spec.loader.exec_module(gpu)
    before=gpu.source_fingerprint(repo);methods=json.loads(gpu.METHODS.read_text())
    settings=out/'serial.runsettings'
    settings.write_text('<RunSettings><RunConfiguration><MaxCpuCount>1</MaxCpuCount></RunConfiguration><xUnit><ParallelizeTestCollections>false</ParallelizeTestCollections><MaxParallelThreads>1</MaxParallelThreads></xUnit></RunSettings>',encoding='utf-8')
    dll=repo/'benchmarks/OoplesFinance.StockIndicators.CompetitorTests/bin/Release/net10.0/OoplesFinance.StockIndicators.CompetitorTests.dll'
    run('gpu',['dotnet','vstest',str(dll),'/Settings:'+str(settings),'/TestCaseFilter:'+'|'.join('FullyQualifiedName='+m for m in methods),
        '/Logger:trx;LogFileName=gpu.trx','/ResultsDirectory:'+str(out/'gpu')])
    raw=(out/'gpu/gpu.trx').read_bytes();count=gpu.contracts.verify_trx(out/'gpu/gpu.trx',methods)
    assert count==100 and gpu.source_fingerprint(repo)==before
    receipt=dict(source_sha256=before,methods=methods,passed_cases=count,trx_sha256=hashlib.sha256(raw).hexdigest(),
        host=platform.platform(),device='Radeon RX 5500 XT; RequiredGPU fixtures',
        dotnet_info=subprocess.check_output(['dotnet','--info']).decode(),test_assembly_sha256=hashlib.sha256(dll.read_bytes()).hexdigest(),
        note='Actual RequiredGPU execution using already-built source-matched binaries; correctness, not performance qualification.')
    gpu.verify_evidence(receipt,raw,methods,before)
    (gpu.EVIDENCE/'gpu.trx.gz').write_bytes(gzip.compress(raw,mtime=0))
    (gpu.EVIDENCE/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    state['gpu_passed']=count
    run('discover-contracts',['python3.13.exe','scripts/run-competitor-contracts.py','discover',str(dll),str(out/'all-methods.json')])
    run('gpu-source-verification',['python3.13.exe','scripts/verify-competitor-local-gpu.py','verify',str(out/'all-methods.json'),str(out/'hosted-methods.json')])
    run('inventory',['python3.13.exe','benchmarks/build_remaining_indicator_inventory.py'])
    run('inventory-check',['python3.13.exe','benchmarks/build_remaining_indicator_inventory.py','--check'])
    run('inventory-tests',['python3.13.exe','-m','unittest','discover','-s','benchmarks','-p','test_remaining_indicator_inventory.py'])
    paths=['src','tests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','benchmarks/OoplesFinance.StockIndicators.CompetitorTests']
    state['production_dll_sha256']={str(repo/p/'bin/Release/net10.0/OoplesFinance.StockIndicators.dll'):
        hashlib.sha256((repo/p/'bin/Release/net10.0/OoplesFinance.StockIndicators.dll').read_bytes()).hexdigest() for p in paths}
    assert len(set(state['production_dll_sha256'].values()))==1
    run('diff-check',['git','diff','--check'])
    save('checks-passed-review-and-publication-pending','complete')
except Exception as error:
    state['error']=repr(error);save('failed-needs-inspection',state.get('step','startup'));raise
