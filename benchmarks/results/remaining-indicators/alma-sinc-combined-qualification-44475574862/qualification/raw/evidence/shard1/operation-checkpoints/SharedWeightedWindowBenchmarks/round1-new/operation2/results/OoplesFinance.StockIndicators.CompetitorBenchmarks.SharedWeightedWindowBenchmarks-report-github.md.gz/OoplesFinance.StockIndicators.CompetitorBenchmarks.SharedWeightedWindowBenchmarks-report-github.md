```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------ |------ |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Convolution** | **1000**  |  **81.21 μs** |  **3.048 μs** | **1.814 μs** |  **1.9531** |       **-** |  **60.53 KB** |
| BuilderLatestOnly | Convolution | 1000  |  81.24 μs |  1.796 μs | 0.939 μs |  0.4883 |       - |  12.65 KB |
| **BuilderFull**       | **Convolution** | **10000** | **207.16 μs** |  **2.732 μs** | **1.429 μs** | **33.2031** | **11.7188** | **553.08 KB** |
| BuilderLatestOnly | Convolution | 10000 | 208.32 μs | 11.043 μs | 7.304 μs |  3.9063 |       - |  82.98 KB |
