```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |----------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Fwma** | **1000**  |  **86.34 μs** |  **3.265 μs** |  **2.159 μs** |  **2.05** |    **0.05** |   **2.9297** |       **-** |   **60.35 KB** |        **0.24** |
| BuilderLatestOnly | QuanTAlib.Fwma | 1000  |  84.01 μs |  2.172 μs |  1.292 μs |  2.00 |    0.04 |        - |       - |   12.47 KB |        0.05 |
| NativeSingle      | QuanTAlib.Fwma | 1000  |  42.08 μs |  0.964 μs |  0.504 μs |  1.00 |    0.02 |  15.3809 |  0.4883 |   254.5 KB |        1.00 |
| NativeParallel    | QuanTAlib.Fwma | 1000  |  96.21 μs |  1.566 μs |  0.932 μs |  2.29 |    0.03 |  16.1133 |  0.4883 |   262.7 KB |        1.03 |
|                   |                |       |           |           |           |       |         |          |         |            |             |
| **BuilderFull**       | **QuanTAlib.Fwma** | **10000** | **247.76 μs** | **12.204 μs** |  **8.072 μs** |  **0.58** |    **0.02** |  **33.2031** | **11.7188** |   **552.9 KB** |        **0.22** |
| BuilderLatestOnly | QuanTAlib.Fwma | 10000 | 238.67 μs |  7.626 μs |  3.989 μs |  0.56 |    0.01 |   3.9063 |       - |   82.79 KB |        0.03 |
| NativeSingle      | QuanTAlib.Fwma | 10000 | 428.05 μs | 15.132 μs |  7.914 μs |  1.00 |    0.02 | 156.2500 | 31.2500 | 2564.28 KB |        1.00 |
| NativeParallel    | QuanTAlib.Fwma | 10000 | 398.67 μs | 19.887 μs | 13.154 μs |  0.93 |    0.03 | 156.2500 | 31.2500 | 2572.66 KB |        1.00 |
