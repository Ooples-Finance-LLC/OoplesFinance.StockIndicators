```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Gma**       | **1000**  |  **83.43 μs** |  **2.832 μs** | **1.481 μs** |  **3.9063** |       **-** |   **80.3 KB** |
| BuilderLatestOnly | Gma       | 1000  |  82.42 μs |  3.392 μs | 2.243 μs |  1.9531 |       - |  32.42 KB |
| **BuilderFull**       | **Gma**       | **10000** | **212.98 μs** | **14.814 μs** | **8.816 μs** | **33.2031** | **15.6250** | **572.84 KB** |
| BuilderLatestOnly | Gma       | 10000 | 198.39 μs |  3.850 μs | 2.014 μs |  5.8594 |       - | 102.75 KB |
