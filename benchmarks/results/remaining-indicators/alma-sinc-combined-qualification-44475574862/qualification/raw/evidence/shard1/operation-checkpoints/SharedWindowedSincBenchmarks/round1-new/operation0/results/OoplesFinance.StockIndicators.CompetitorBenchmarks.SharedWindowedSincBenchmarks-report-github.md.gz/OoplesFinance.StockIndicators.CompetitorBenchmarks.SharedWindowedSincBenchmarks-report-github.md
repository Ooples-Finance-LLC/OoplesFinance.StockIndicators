```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean     | Error    | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |----------------- |------ |---------:|---------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Afirma** | **1000**  | **207.5 μs** |  **9.52 μs** | **5.66 μs** |  **1.9531** |       **-** |  **61.41 KB** |
| BuilderLatestOnly | QuanTAlib.Afirma | 1000  | 214.0 μs | 11.55 μs | 6.88 μs |       - |       - |  13.54 KB |
| **BuilderFull**       | **QuanTAlib.Afirma** | **10000** | **221.5 μs** |  **5.05 μs** | **2.64 μs** | **35.1563** | **11.7188** | **577.63 KB** |
| BuilderLatestOnly | QuanTAlib.Afirma | 10000 | 204.8 μs |  4.08 μs | 2.13 μs |  5.8594 |       - | 107.51 KB |
