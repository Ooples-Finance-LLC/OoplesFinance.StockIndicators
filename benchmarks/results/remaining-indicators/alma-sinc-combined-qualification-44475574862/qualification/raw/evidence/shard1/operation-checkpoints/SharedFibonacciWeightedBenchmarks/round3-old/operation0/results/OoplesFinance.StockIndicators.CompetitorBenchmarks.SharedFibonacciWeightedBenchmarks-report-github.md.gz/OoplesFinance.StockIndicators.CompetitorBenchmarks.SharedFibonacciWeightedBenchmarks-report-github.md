```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Fwma** | **1000**  |  **88.07 μs** |  **5.486 μs** |  **2.869 μs** |  **1.9531** |       **-** |  **60.35 KB** |
| BuilderLatestOnly | QuanTAlib.Fwma | 1000  |  85.86 μs |  4.399 μs |  2.910 μs |       - |       - |  12.47 KB |
| **BuilderFull**       | **QuanTAlib.Fwma** | **10000** | **246.69 μs** | **11.019 μs** |  **6.557 μs** | **33.2031** | **11.7188** |  **552.9 KB** |
| BuilderLatestOnly | QuanTAlib.Fwma | 10000 | 264.89 μs | 16.349 μs | 10.814 μs |  3.9063 |       - |  82.79 KB |
