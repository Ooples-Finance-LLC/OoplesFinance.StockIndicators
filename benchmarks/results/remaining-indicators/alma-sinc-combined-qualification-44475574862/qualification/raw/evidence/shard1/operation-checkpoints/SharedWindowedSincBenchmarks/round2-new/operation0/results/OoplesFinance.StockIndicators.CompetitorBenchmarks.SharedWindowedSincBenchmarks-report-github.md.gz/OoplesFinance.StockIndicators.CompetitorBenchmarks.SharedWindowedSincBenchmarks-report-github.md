```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |----------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Afirma** | **1000**  | **238.13 μs** | **11.791 μs** |  **7.799 μs** |  **2.76** |    **0.09** |       **-** |       **-** |  **61.68 KB** |        **1.29** |
| BuilderLatestOnly | QuanTAlib.Afirma | 1000  | 213.46 μs |  3.513 μs |  1.837 μs |  2.47 |    0.02 |       - |       - |  13.54 KB |        0.28 |
| NativeSingle      | QuanTAlib.Afirma | 1000  |  86.34 μs |  0.968 μs |  0.507 μs |  1.00 |    0.01 |  2.4414 |       - |  47.82 KB |        1.00 |
| NativeParallel    | QuanTAlib.Afirma | 1000  | 107.81 μs |  3.136 μs |  1.866 μs |  1.25 |    0.02 |  2.9297 |       - |  53.11 KB |        1.11 |
|                   |                  |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **QuanTAlib.Afirma** | **10000** | **223.49 μs** | **19.516 μs** | **12.909 μs** |  **0.26** |    **0.01** | **35.1563** | **11.7188** | **577.62 KB** |        **1.23** |
| BuilderLatestOnly | QuanTAlib.Afirma | 10000 | 203.29 μs | 11.221 μs |  6.678 μs |  0.23 |    0.01 |  5.8594 |       - | 107.51 KB |        0.23 |
| NativeSingle      | QuanTAlib.Afirma | 10000 | 876.45 μs | 21.369 μs | 12.716 μs |  1.00 |    0.02 | 23.4375 |       - | 469.71 KB |        1.00 |
| NativeParallel    | QuanTAlib.Afirma | 10000 | 535.62 μs | 18.526 μs | 11.025 μs |  0.61 |    0.01 | 27.3438 |  3.9063 | 475.01 KB |        1.01 |
