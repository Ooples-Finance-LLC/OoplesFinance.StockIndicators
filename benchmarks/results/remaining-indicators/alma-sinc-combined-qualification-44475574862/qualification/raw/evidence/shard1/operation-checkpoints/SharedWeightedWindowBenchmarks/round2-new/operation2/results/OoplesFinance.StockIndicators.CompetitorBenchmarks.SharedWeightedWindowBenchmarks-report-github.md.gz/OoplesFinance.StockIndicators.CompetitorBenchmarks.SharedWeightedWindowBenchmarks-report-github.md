```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |------------ |------ |----------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Convolution** | **1000**  |  **81.21 μs** |  **3.284 μs** |  **1.954 μs** |  **2.61** |    **0.07** |   **1.9531** |       **-** |   **60.53 KB** |        **0.28** |
| BuilderLatestOnly | Convolution | 1000  |  78.66 μs |  0.826 μs |  0.492 μs |  2.53 |    0.04 |   0.4883 |       - |   12.65 KB |        0.06 |
| NativeSingle      | Convolution | 1000  |  31.10 μs |  0.874 μs |  0.520 μs |  1.00 |    0.02 |  12.9395 |  0.2441 |  215.11 KB |        1.00 |
| NativeParallel    | Convolution | 1000  |  84.29 μs |  2.015 μs |  1.054 μs |  2.71 |    0.05 |  13.1836 |       - |   220.1 KB |        1.02 |
|                   |             |       |           |           |           |       |         |          |         |            |             |
| **BuilderFull**       | **Convolution** | **10000** | **207.38 μs** | **11.864 μs** |  **7.848 μs** |  **0.67** |    **0.02** |  **33.2031** | **13.6719** |  **553.08 KB** |        **0.25** |
| BuilderLatestOnly | Convolution | 10000 | 210.87 μs | 14.974 μs |  9.905 μs |  0.68 |    0.03 |   3.9063 |       - |   82.98 KB |        0.04 |
| NativeSingle      | Convolution | 10000 | 309.43 μs |  3.897 μs |  2.319 μs |  1.00 |    0.01 | 132.8125 | 25.3906 | 2173.32 KB |        1.00 |
| NativeParallel    | Convolution | 10000 | 302.81 μs | 15.472 μs | 10.234 μs |  0.98 |    0.03 | 132.8125 | 25.3906 | 2178.49 KB |        1.00 |
