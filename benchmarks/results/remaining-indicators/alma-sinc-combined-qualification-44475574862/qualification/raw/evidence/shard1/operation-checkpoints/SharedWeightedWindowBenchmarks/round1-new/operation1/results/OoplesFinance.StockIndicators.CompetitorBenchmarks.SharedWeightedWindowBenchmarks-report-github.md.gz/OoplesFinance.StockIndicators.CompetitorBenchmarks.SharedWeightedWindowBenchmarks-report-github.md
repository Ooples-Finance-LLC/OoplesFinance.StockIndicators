```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Sinema**    | **1000**  |  **81.40 μs** |  **4.306 μs** | **2.562 μs** |  **3.9063** |       **-** |  **80.29 KB** |
| BuilderLatestOnly | Sinema    | 1000  |  79.82 μs |  2.671 μs | 1.767 μs |  1.9531 |       - |  32.41 KB |
| **BuilderFull**       | **Sinema**    | **10000** | **198.19 μs** | **12.683 μs** | **8.389 μs** | **33.2031** | **15.6250** | **572.83 KB** |
| BuilderLatestOnly | Sinema    | 10000 | 185.70 μs | 11.967 μs | 7.915 μs |  5.8594 |  0.9766 | 102.73 KB |
