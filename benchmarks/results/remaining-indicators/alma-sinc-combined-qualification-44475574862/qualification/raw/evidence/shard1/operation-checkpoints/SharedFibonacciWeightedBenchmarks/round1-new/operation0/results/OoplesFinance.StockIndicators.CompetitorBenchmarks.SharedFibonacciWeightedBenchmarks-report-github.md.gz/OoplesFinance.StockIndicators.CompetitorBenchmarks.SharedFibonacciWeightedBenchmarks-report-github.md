```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Fwma** | **1000**  |  **90.44 μs** | **7.549 μs** | **4.993 μs** |  **1.9531** |       **-** |  **60.32 KB** |
| BuilderLatestOnly | QuanTAlib.Fwma | 1000  |  87.44 μs | 1.635 μs | 0.973 μs |       - |       - |  12.47 KB |
| **BuilderFull**       | **QuanTAlib.Fwma** | **10000** | **249.56 μs** | **9.675 μs** | **5.060 μs** | **33.2031** | **11.7188** | **552.87 KB** |
| BuilderLatestOnly | QuanTAlib.Fwma | 10000 | 236.85 μs | 3.349 μs | 1.751 μs |  3.9063 |       - |  82.79 KB |
