```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev   | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |---------- |------ |----------:|----------:|---------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Gma**       | **1000**  |  **80.06 μs** |  **4.153 μs** | **2.747 μs** |  **1.77** |    **0.07** |   **3.9063** |       **-** |    **80.3 KB** |        **0.32** |
| BuilderLatestOnly | Gma       | 1000  |  76.39 μs |  1.914 μs | 1.266 μs |  1.69 |    0.05 |   1.9531 |       - |   32.42 KB |        0.13 |
| NativeSingle      | Gma       | 1000  |  45.15 μs |  1.685 μs | 1.114 μs |  1.00 |    0.03 |  15.3809 |  0.4883 |  254.32 KB |        1.00 |
| NativeParallel    | Gma       | 1000  | 101.08 μs |  5.444 μs | 3.601 μs |  2.24 |    0.09 |  15.6250 |       - |  261.98 KB |        1.03 |
|                   |           |       |           |           |          |       |         |          |         |            |             |
| **BuilderFull**       | **Gma**       | **10000** | **198.26 μs** | **11.316 μs** | **7.485 μs** |  **0.46** |    **0.02** |  **34.1797** | **15.6250** |  **572.83 KB** |        **0.22** |
| BuilderLatestOnly | Gma       | 10000 | 184.48 μs | 11.774 μs | 7.007 μs |  0.43 |    0.02 |   5.8594 |  0.9766 |  102.74 KB |        0.04 |
| NativeSingle      | Gma       | 10000 | 431.05 μs | 10.368 μs | 6.170 μs |  1.00 |    0.02 | 156.2500 | 31.2500 |  2564.1 KB |        1.00 |
| NativeParallel    | Gma       | 10000 | 384.09 μs | 14.621 μs | 9.671 μs |  0.89 |    0.02 | 156.2500 | 31.2500 | 2571.94 KB |        1.00 |
