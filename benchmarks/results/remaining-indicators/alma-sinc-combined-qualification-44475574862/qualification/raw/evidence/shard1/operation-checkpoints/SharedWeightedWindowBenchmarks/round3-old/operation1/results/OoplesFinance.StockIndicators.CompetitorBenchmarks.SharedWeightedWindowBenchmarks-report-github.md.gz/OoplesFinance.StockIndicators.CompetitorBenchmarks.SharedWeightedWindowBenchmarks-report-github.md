```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Sinema**    | **1000**  |  **85.76 μs** | **5.064 μs** | **3.350 μs** |  **3.9063** |       **-** |  **80.29 KB** |
| BuilderLatestOnly | Sinema    | 1000  |  81.73 μs | 1.792 μs | 1.185 μs |  1.9531 |       - |  32.41 KB |
| **BuilderFull**       | **Sinema**    | **10000** | **207.12 μs** | **9.410 μs** | **4.921 μs** | **33.2031** | **15.6250** | **572.83 KB** |
| BuilderLatestOnly | Sinema    | 10000 | 189.39 μs | 9.443 μs | 6.246 μs |  5.8594 |  0.9766 | 102.73 KB |
