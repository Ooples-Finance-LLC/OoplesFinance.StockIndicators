```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |---------- |------ |----------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Sinema**    | **1000**  |  **81.01 μs** |  **2.096 μs** |  **1.247 μs** |  **1.88** |    **0.04** |   **3.9063** |       **-** |   **80.29 KB** |        **0.32** |
| BuilderLatestOnly | Sinema    | 1000  | 107.57 μs |  6.086 μs |  4.025 μs |  2.50 |    0.10 |   1.9531 |       - |   32.41 KB |        0.13 |
| NativeSingle      | Sinema    | 1000  |  43.00 μs |  1.132 μs |  0.674 μs |  1.00 |    0.02 |  15.3809 |  0.4883 |  254.32 KB |        1.00 |
| NativeParallel    | Sinema    | 1000  | 128.93 μs |  3.725 μs |  2.464 μs |  3.00 |    0.07 |  15.6250 |       - |  261.98 KB |        1.03 |
|                   |           |       |           |           |           |       |         |          |         |            |             |
| **BuilderFull**       | **Sinema**    | **10000** | **219.56 μs** |  **4.703 μs** |  **2.460 μs** |  **0.52** |    **0.01** |  **33.2031** | **15.6250** |  **572.83 KB** |        **0.22** |
| BuilderLatestOnly | Sinema    | 10000 | 215.99 μs | 14.132 μs |  8.410 μs |  0.51 |    0.02 |   5.8594 |       - |  102.74 KB |        0.04 |
| NativeSingle      | Sinema    | 10000 | 426.02 μs |  6.156 μs |  3.663 μs |  1.00 |    0.01 | 156.2500 | 31.2500 | 2564.11 KB |        1.00 |
| NativeParallel    | Sinema    | 10000 | 451.27 μs | 22.061 μs | 14.592 μs |  1.06 |    0.03 | 156.2500 | 31.2500 | 2571.94 KB |        1.00 |
