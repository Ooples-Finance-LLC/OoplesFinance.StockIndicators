```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |----------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Afirma** | **1000**  |   **217.9 μs** | **11.52 μs** |  **6.86 μs** |  **1.9531** |       **-** |  **61.37 KB** |
| BuilderLatestOnly | QuanTAlib.Afirma | 1000  |   215.3 μs | 12.63 μs |  7.52 μs |       - |       - |  13.54 KB |
| **BuilderFull**       | **QuanTAlib.Afirma** | **10000** | **1,503.3 μs** | **48.42 μs** | **28.81 μs** | **31.2500** | **15.6250** | **554.05 KB** |
| BuilderLatestOnly | QuanTAlib.Afirma | 10000 | 1,554.9 μs | 51.11 μs | 33.81 μs |       - |       - |   83.9 KB |
