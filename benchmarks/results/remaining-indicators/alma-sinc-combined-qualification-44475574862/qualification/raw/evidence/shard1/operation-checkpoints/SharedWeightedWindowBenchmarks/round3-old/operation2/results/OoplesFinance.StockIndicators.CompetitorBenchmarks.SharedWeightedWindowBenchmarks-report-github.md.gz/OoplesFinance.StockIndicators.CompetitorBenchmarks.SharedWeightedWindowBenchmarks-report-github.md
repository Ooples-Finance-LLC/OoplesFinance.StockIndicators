```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------------ |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Convolution** | **1000**  |  **84.44 μs** |  **3.419 μs** |  **2.261 μs** |  **1.9531** |       **-** |  **60.53 KB** |
| BuilderLatestOnly | Convolution | 1000  |  81.00 μs |  0.787 μs |  0.521 μs |  0.4883 |       - |  12.65 KB |
| **BuilderFull**       | **Convolution** | **10000** | **222.27 μs** | **16.276 μs** | **10.765 μs** | **33.2031** | **11.7188** | **553.08 KB** |
| BuilderLatestOnly | Convolution | 10000 | 198.20 μs |  3.063 μs |  1.602 μs |  3.9063 |       - |  82.98 KB |
