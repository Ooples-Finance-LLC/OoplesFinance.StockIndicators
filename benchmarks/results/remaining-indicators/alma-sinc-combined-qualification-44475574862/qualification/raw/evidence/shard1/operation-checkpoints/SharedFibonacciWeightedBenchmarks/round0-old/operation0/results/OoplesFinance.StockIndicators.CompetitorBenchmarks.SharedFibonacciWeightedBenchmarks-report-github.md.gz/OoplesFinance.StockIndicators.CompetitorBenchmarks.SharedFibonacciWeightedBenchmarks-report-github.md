```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Fwma** | **1000**  |  **87.41 μs** |  **3.504 μs** |  **2.318 μs** |  **2.9297** |       **-** |  **60.35 KB** |
| BuilderLatestOnly | QuanTAlib.Fwma | 1000  |  87.44 μs |  3.494 μs |  2.311 μs |       - |       - |  12.47 KB |
| **BuilderFull**       | **QuanTAlib.Fwma** | **10000** | **243.96 μs** | **19.339 μs** | **12.791 μs** | **33.2031** | **11.7188** |  **552.9 KB** |
| BuilderLatestOnly | QuanTAlib.Fwma | 10000 | 231.61 μs | 11.171 μs |  6.648 μs |  3.9063 |       - |  82.79 KB |
