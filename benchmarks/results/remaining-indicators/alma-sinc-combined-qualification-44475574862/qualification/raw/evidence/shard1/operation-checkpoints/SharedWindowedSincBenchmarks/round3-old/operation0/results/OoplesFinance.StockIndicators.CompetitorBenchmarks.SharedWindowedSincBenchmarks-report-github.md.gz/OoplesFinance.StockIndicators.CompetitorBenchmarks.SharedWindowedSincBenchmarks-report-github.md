```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |----------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Afirma** | **1000**  |   **227.4 μs** | **13.22 μs** |  **8.74 μs** |  **1.9531** |       **-** |  **61.41 KB** |
| BuilderLatestOnly | QuanTAlib.Afirma | 1000  |   219.1 μs |  7.66 μs |  4.01 μs |       - |       - |  13.54 KB |
| **BuilderFull**       | **QuanTAlib.Afirma** | **10000** | **1,573.1 μs** | **94.73 μs** | **62.66 μs** | **31.2500** | **15.6250** | **554.02 KB** |
| BuilderLatestOnly | QuanTAlib.Afirma | 10000 | 1,544.7 μs | 69.42 μs | 45.92 μs |       - |       - |   83.9 KB |
