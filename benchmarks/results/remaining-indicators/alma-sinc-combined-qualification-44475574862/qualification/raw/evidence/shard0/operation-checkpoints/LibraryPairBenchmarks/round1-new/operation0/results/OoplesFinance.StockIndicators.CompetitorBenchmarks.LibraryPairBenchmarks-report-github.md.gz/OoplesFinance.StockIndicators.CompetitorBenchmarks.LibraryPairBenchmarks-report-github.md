```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId        | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |-------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **QuanTAlib.Gma** |  **68.63 μs** |  **19.43 μs** | **11.56 μs** |  **1.02** |    **0.21** |   **76.7 KB** |        **1.00** |
|        |       |               |           |           |          |       |         |           |             |
| **Ooples** | **10000** | **QuanTAlib.Gma** | **371.42 μs** | **121.91 μs** | **72.55 μs** |  **1.04** |    **0.28** | **646.99 KB** |        **1.00** |
