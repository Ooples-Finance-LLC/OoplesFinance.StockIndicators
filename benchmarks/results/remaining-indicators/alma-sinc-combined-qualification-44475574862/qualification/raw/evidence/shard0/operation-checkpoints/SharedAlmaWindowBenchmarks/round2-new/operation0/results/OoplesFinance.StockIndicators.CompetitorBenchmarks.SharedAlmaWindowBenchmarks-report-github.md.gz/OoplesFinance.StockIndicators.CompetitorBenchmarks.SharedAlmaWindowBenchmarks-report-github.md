```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Median     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------- |------ |-----------:|----------:|----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Alma** | **1000**  |   **451.0 μs** | **431.55 μs** | **285.44 μs** |   **320.7 μs** |  **1.82** |    **1.10** |       **-** |       **-** | **112.43 KB** |        **2.36** |
| BuilderLatestOnly | QuanTAlib.Alma | 1000  |   188.8 μs |   2.42 μs |   1.27 μs |   189.2 μs |  0.76 |    0.01 |  3.9063 |       - |  64.79 KB |        1.36 |
| NativeSingle      | QuanTAlib.Alma | 1000  |   247.6 μs |   2.28 μs |   1.35 μs |   246.8 μs |  1.00 |    0.01 |  1.9531 |       - |  47.62 KB |        1.00 |
| NativeParallel    | QuanTAlib.Alma | 1000  |   223.7 μs |  17.77 μs |  10.57 μs |   218.7 μs |  0.90 |    0.04 |  1.9531 |       - |  52.15 KB |        1.10 |
|                   |                |       |            |           |           |            |       |         |         |         |           |             |
| **BuilderFull**       | **QuanTAlib.Alma** | **10000** |   **465.3 μs** |  **54.54 μs** |  **36.08 μs** |   **453.6 μs** |  **0.19** |    **0.01** | **39.0625** | **15.6250** | **675.26 KB** |        **1.44** |
| BuilderLatestOnly | QuanTAlib.Alma | 10000 |   439.1 μs |  37.20 μs |  24.61 μs |   427.5 μs |  0.18 |    0.01 | 11.7188 |  3.9063 | 205.44 KB |        0.44 |
| NativeSingle      | QuanTAlib.Alma | 10000 | 2,490.7 μs |  16.34 μs |   9.72 μs | 2,487.9 μs |  1.00 |    0.01 | 15.6250 |       - |  469.6 KB |        1.00 |
| NativeParallel    | QuanTAlib.Alma | 10000 | 1,480.5 μs | 112.49 μs |  74.41 μs | 1,441.9 μs |  0.59 |    0.03 | 23.4375 |       - | 474.07 KB |        1.01 |
