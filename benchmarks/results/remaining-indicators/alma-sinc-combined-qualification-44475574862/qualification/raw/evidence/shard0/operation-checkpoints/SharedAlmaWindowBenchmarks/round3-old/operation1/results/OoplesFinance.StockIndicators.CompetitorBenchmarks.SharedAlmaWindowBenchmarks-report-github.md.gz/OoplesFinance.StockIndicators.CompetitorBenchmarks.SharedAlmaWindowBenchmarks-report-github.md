```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetAlma** | **1000**  |   **725.1 μs** |  **53.31 μs** | **35.26 μs** |       **-** |  **76.76 KB** |
| BuilderLatestOnly | Skender.GetAlma | 1000  |   408.8 μs |  18.60 μs |  9.73 μs |       - |  29.11 KB |
| **BuilderFull**       | **Skender.GetAlma** | **10000** | **3,278.8 μs** | **100.30 μs** | **52.46 μs** | **31.2500** | **639.79 KB** |
| BuilderLatestOnly | Skender.GetAlma | 10000 | 3,151.8 μs | 118.10 μs | 70.28 μs |       - | 169.96 KB |
