```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId          | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAlma** | **127.14 μs** | **10.160 μs** |  **5.314 μs** |  **1.00** |    **0.06** |   **90.36 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAlma |  67.29 μs |  2.798 μs |  1.851 μs |  0.53 |    0.03 |  114.91 KB |        1.27 |
|            |       |                 |           |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAlma** | **379.84 μs** | **24.465 μs** | **12.796 μs** |  **1.00** |    **0.04** |  **740.08 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAlma | 697.52 μs | 39.531 μs | 26.147 μs |  1.84 |    0.09 | 1073.25 KB |        1.45 |
