```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId          | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |---------------- |-----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetAlma** |   **421.3 μs** | **35.01 μs** | **23.16 μs** |  **1.00** |    **0.07** |   **79.8 KB** |        **1.00** |
|        |       |                 |            |          |          |       |         |           |             |
| **Ooples** | **10000** | **Skender.GetAlma** | **3,061.4 μs** | **76.72 μs** | **45.65 μs** |  **1.00** |    **0.02** | **729.56 KB** |        **1.00** |
