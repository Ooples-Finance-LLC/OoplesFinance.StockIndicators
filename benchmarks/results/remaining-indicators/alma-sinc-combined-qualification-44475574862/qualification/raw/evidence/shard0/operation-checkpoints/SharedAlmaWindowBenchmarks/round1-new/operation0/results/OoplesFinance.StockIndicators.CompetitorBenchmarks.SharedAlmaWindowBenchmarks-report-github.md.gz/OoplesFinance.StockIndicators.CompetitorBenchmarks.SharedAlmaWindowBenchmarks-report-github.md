```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean     | Error     | StdDev    | Median   | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |---------:|----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Alma** | **1000**  | **735.9 μs** | **970.54 μs** | **641.95 μs** | **378.7 μs** |       **-** |       **-** | **112.43 KB** |
| BuilderLatestOnly | QuanTAlib.Alma | 1000  | 187.5 μs |  10.38 μs |   6.18 μs | 184.5 μs |  3.9063 |       - |  64.79 KB |
| **BuilderFull**       | **QuanTAlib.Alma** | **10000** | **456.4 μs** |  **36.12 μs** |  **23.89 μs** | **441.8 μs** | **39.0625** | **11.7188** | **675.26 KB** |
| BuilderLatestOnly | QuanTAlib.Alma | 10000 | 440.3 μs |  50.73 μs |  33.55 μs | 424.1 μs | 11.7188 |  3.9063 | 205.44 KB |
