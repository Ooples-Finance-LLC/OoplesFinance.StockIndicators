```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId           | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |----------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Sinema** |    **80.17 μs** | **11.026 μs** |  **6.562 μs** |  **1.01** |    **0.11** |    **76.7 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Sinema |   104.87 μs |  1.112 μs |  0.661 μs |  1.32 |    0.10 |  262.23 KB |        3.42 |
|            |       |                  |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Sinema** |   **389.39 μs** | **56.946 μs** | **33.888 μs** |  **1.01** |    **0.11** |  **647.28 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Sinema | 1,068.67 μs | 50.876 μs | 33.652 μs |  2.76 |    0.23 | 2572.32 KB |        3.97 |
