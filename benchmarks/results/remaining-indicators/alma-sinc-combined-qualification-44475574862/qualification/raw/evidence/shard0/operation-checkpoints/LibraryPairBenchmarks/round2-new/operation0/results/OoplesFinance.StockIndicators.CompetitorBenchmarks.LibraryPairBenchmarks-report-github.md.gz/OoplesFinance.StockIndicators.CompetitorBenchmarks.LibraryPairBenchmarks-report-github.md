```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId        | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Gma** |   **100.5 μs** | **46.94 μs** | **31.05 μs** |  **1.08** |    **0.44** |    **76.7 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Gma |   104.3 μs |  0.48 μs |  0.25 μs |  1.12 |    0.30 |  262.55 KB |        3.42 |
|            |       |               |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Gma** |   **341.3 μs** | **82.40 μs** | **49.04 μs** |  **1.02** |    **0.20** |  **647.32 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Gma | 1,039.3 μs | 42.87 μs | 28.36 μs |  3.10 |    0.45 | 2571.99 KB |        3.97 |
