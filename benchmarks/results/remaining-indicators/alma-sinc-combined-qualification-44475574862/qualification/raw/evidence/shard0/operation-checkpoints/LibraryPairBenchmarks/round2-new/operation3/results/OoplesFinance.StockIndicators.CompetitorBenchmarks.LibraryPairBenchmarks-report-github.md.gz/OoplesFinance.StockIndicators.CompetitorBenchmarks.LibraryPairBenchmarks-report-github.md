```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------- |-----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Alma** |   **115.1 μs** | **22.95 μs** | **13.66 μs** |  **1.01** |    **0.15** | **104.98 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Alma |   289.1 μs |  1.55 μs |  0.81 μs |  2.54 |    0.24 |  71.98 KB |        0.69 |
|            |       |                |            |          |          |       |         |           |             |
| **Ooples**     | **10000** | **QuanTAlib.Alma** |   **382.1 μs** | **46.96 μs** | **27.94 μs** |  **1.00** |    **0.10** | **754.41 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Alma | 2,938.7 μs | 27.73 μs | 14.50 μs |  7.73 |    0.51 | 643.23 KB |        0.85 |
