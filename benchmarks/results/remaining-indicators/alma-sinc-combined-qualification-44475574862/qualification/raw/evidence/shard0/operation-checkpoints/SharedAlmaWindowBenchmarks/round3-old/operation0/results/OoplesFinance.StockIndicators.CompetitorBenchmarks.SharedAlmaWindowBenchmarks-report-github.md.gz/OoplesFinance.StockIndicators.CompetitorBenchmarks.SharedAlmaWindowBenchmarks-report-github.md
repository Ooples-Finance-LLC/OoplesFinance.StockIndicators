```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Alma** | **1000**  | **1,115.5 μs** | **152.86 μs** | **101.11 μs** |       **-** |  **91.43 KB** |
| BuilderLatestOnly | QuanTAlib.Alma | 1000  |   445.4 μs |  12.03 μs |   6.29 μs |       - |  43.77 KB |
| **BuilderFull**       | **QuanTAlib.Alma** | **10000** | **3,369.5 μs** |  **87.03 μs** |  **45.52 μs** | **31.2500** | **654.45 KB** |
| BuilderLatestOnly | QuanTAlib.Alma | 10000 | 3,310.3 μs | 341.52 μs | 203.23 μs |       - | 184.62 KB |
