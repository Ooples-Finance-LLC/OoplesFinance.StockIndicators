```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean     | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |---------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetAlma** | **1000**  | **228.3 μs** | **228.68 μs** | **119.60 μs** |       **-** |       **-** |  **97.76 KB** |
| BuilderLatestOnly | Skender.GetAlma | 1000  | 139.2 μs |   5.11 μs |   3.38 μs |  2.9297 |       - |  50.12 KB |
| **BuilderFull**       | **Skender.GetAlma** | **10000** | **385.3 μs** |  **10.60 μs** |   **6.31 μs** | **39.0625** | **15.6250** | **660.59 KB** |
| BuilderLatestOnly | Skender.GetAlma | 10000 | 379.5 μs |  22.59 μs |  14.94 μs |  9.7656 |  1.9531 | 190.75 KB |
