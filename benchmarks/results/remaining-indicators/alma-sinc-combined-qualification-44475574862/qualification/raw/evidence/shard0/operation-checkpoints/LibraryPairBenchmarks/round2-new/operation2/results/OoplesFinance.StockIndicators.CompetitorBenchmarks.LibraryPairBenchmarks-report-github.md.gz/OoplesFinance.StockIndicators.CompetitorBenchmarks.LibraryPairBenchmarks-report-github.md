```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanT(...)ution [21]** | **392.54 μs** | **20.981 μs** | **12.486 μs** |  **1.00** |    **0.04** |   **67.15 KB** |        **1.00** |
| Competitor | 1000  | QuanT(...)ution [21] |  86.09 μs |  1.440 μs |  0.753 μs |  0.22 |    0.01 |  223.15 KB |        3.32 |
|            |       |                      |           |           |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanT(...)ution [21]** | **355.04 μs** | **10.015 μs** |  **5.960 μs** |  **1.00** |    **0.02** |  **637.77 KB** |        **1.00** |
| Competitor | 10000 | QuanT(...)ution [21] | 850.06 μs | 27.502 μs | 16.366 μs |  2.39 |    0.06 | 2180.98 KB |        3.42 |
