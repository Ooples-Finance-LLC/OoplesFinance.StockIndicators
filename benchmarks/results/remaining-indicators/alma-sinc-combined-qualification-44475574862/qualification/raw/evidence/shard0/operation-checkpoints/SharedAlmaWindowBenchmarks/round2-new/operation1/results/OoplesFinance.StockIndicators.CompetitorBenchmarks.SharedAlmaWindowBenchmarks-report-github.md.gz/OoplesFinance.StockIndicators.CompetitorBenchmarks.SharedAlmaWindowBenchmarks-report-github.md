```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error      | StdDev     | Median    | Ratio | RatioSD | Gen0     | Gen1    | Gen2    | Allocated | Alloc Ratio |
|------------------ |---------------- |------ |----------:|-----------:|-----------:|----------:|------:|--------:|---------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **Skender.GetAlma** | **1000**  | **305.36 μs** | **291.764 μs** | **192.984 μs** | **220.08 μs** |  **5.30** |    **3.21** |        **-** |       **-** |       **-** |  **97.76 KB** |        **0.99** |
| BuilderLatestOnly | Skender.GetAlma | 1000  | 132.10 μs |   1.488 μs |   0.778 μs | 131.91 μs |  2.29 |    0.11 |   2.9297 |       - |       - |  50.12 KB |        0.51 |
| NativeSingle      | Skender.GetAlma | 1000  |  57.79 μs |   4.686 μs |   3.100 μs |  56.22 μs |  1.00 |    0.07 |   5.8594 |  0.9766 |       - |  98.29 KB |        1.00 |
| NativeParallel    | Skender.GetAlma | 1000  | 122.49 μs |   3.851 μs |   2.292 μs | 122.74 μs |  2.12 |    0.11 |   6.8359 |       - |       - | 105.27 KB |        1.07 |
|                   |                 |       |           |            |            |           |       |         |          |         |         |           |             |
| **BuilderFull**       | **Skender.GetAlma** | **10000** | **388.38 μs** |  **28.911 μs** |  **17.205 μs** | **381.91 μs** |  **0.55** |    **0.03** |  **39.0625** | **15.6250** |       **-** | **660.59 KB** |        **0.68** |
| BuilderLatestOnly | Skender.GetAlma | 10000 | 380.20 μs |  23.815 μs |  15.752 μs | 379.83 μs |  0.54 |    0.03 |   9.7656 |  1.9531 |       - | 190.75 KB |        0.20 |
| NativeSingle      | Skender.GetAlma | 10000 | 701.23 μs |  49.061 μs |  32.451 μs | 684.67 μs |  1.00 |    0.06 | 125.0000 | 97.6563 | 85.9375 | 977.99 KB |        1.00 |
| NativeParallel    | Skender.GetAlma | 10000 | 456.10 μs |  53.137 μs |  35.147 μs | 438.90 μs |  0.65 |    0.06 |  62.5000 | 23.4375 |       - | 984.19 KB |        1.01 |
