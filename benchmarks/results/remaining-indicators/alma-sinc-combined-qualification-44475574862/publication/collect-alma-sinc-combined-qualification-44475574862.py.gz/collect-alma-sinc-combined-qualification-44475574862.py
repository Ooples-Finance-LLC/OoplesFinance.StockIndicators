"""Collect one analytic exact-grid full qualification; explicit --recollect re-streams hosted ZIP but never replaces retained evidence or installs payload."""
import argparse,hashlib,json,os,re,shutil,stat,subprocess,sys,tempfile,traceback,uuid,zipfile
from pathlib import Path,PurePosixPath

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--run',required=True);parser.add_argument('--head',required=True)
parser.add_argument('--plan-sha256',required=True);parser.add_argument('--recollect',action='store_true')
parser.add_argument('--repo',type=Path,default=Path(r'C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-alma-sinc-combined-qualification-20261119'))
args=parser.parse_args()
assert re.fullmatch('[1-9][0-9]*',args.run) and re.fullmatch('[a-f0-9]{40}',args.head) and re.fullmatch('[a-f0-9]{64}',args.plan_sha256)
assert (args.run,args.head,args.plan_sha256)==('44475574862','c3ed12bdc91a534e9bcaf697fdc3a83713a187e4','3a20fad981c48c235c1930b4786db2c882babc38dacf15b3551972af3f025738'),'Exact approved actual run/head/plan only'
REPO=args.repo.resolve();REMOTE='Ooples-Finance-LLC/OoplesFinance.StockIndicators'
PLAN_REL='benchmarks/plans/hosted-alma-sinc-combined-qualification-20261119.json';PLAN=REPO/PLAN_REL
OPS=Path(r'C:\Users\cheat\source\stock-indicators-operations\alma-sinc-combined-qualification-20261119')
OUT=Path('Z:/StockIndicators-Archives/qualification-evidence/alma-sinc-combined-20261119')/('alma-sinc-combined-qualification-'+args.run)
PREP=OPS/('hosted-inputs-'+args.run);RAW=OUT/'raw/evidence';SCRATCH=OPS/('verification-temp-'+args.run)
CACHES=[Path('C:/Users/cheat/source/stock-indicators-operations/alma-cached-wide-baseline-correctness-20261119/authenticated-input-44460024410'),Path('C:/Users/cheat/source/stock-indicators-operations/alma-sinc-combined-correctness-20261119/authenticated-input-44469775767')]

def git(*values):return subprocess.check_output(['git',*values],cwd=REPO)
def api(path):return json.loads(subprocess.check_output(['gh','api','repos/'+REMOTE+'/'+path],cwd=REPO))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def write(path,data):path.write_bytes((json.dumps(data,indent=2)+'\n').encode())
def zip_digest(package,entry):
    with package.open(entry) as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
MAX_ARCHIVE_BYTES=2*1024**3

def stream_archive_to_z(command,target,expected_size,expected_sha256):
    assert 0<expected_size<=MAX_ARCHIVE_BYTES
    assert target.resolve().parent==OUT.resolve() and target.suffix=='.zip'
    downloaded=0;hasher=hashlib.sha256()
    with target.open('xb') as archive:
        process=subprocess.Popen(command,cwd=REPO,stdout=subprocess.PIPE)
        try:
            while True:
                chunk=process.stdout.read(1024*1024)
                if not chunk:break
                downloaded+=len(chunk)
                assert downloaded<=expected_size,'Archive exceeded authenticated API size'
                hasher.update(chunk);archive.write(chunk)
            assert process.wait()==0
        finally:
            if process.poll() is None:process.kill();process.wait()
            process.stdout.close()
        archive.flush();os.fsync(archive.fileno())
    assert downloaded==expected_size and hasher.hexdigest()==expected_sha256
    return downloaded

def verifier_bound():
    assert git('rev-parse','HEAD').decode().strip()==args.head and not git('status','--porcelain')
    raw=PLAN.read_bytes();assert sha(raw)==args.plan_sha256 and b'\r' not in raw and raw==git('show',args.head+':'+PLAN_REL)

verifier_bound();os.environ['HOSTED_TIMING_PLAN']=str(PLAN);sys.path.insert(0,str(REPO/'scripts'))
from hosted_timing import alma_sinc_combined_qualification as q
plan=q.p.read(PLAN);q.validate_scope(plan)
assert q.OLD=='48980c2bd9d04dd5cd472ccc768efe9b44e5e20e' and q.NEW=='4b4e8a385ed1c210998d26de6460e23f5842ffe9'
assert q.ALMA==['QuanTAlib.Alma','Skender.GetAlma'] and len(q.expected_contexts())==38
assert q.SCOPE=='alma-sinc-combined-qualification-20261119'
state=api('actions/runs/'+args.run)
assert str(state['id'])==args.run and state['head_sha']==args.head and state['run_attempt']==1
assert state['head_branch']=='perf/alma-sinc-combined-qualification-20261119' and state['path']=='.github/workflows/alma-sinc-combined-qualification.yml'
assert state['event']=='push' and state['status']=='completed','Require actual completion before collection'
assert state['conclusion']=='success','Failed workflow cannot establish an authenticated completed diagnostic'
jobs=api('actions/runs/'+args.run+'/jobs?per_page=100')['jobs'];active=[job for job in jobs if job['conclusion']!='skipped']
assert len(active)==4 and {j['name'] for j in active}=={'prepare','measure (0)','measure (1)','collect'} and all(j['conclusion']=='success' for j in active),'Exactly prepare/two isolated measure/collect jobs required'
items=api('actions/runs/'+args.run+'/artifacts')['artifacts'];items=[item for item in items if item['name']=='alma-sinc-combined-qualification' and not item['expired']]
assert len(items)==1;artifact=items[0]
assert str(artifact['workflow_run']['id'])==args.run and artifact['workflow_run']['head_sha']==args.head
assert re.fullmatch('sha256:[a-f0-9]{64}',artifact['digest'])
if args.recollect:
    receipt=q.p.read(OUT/'collection-receipt.json')
    assert receipt['status']=='actual-alma-sinc-combined-qualification-authenticated' and receipt['run_id']==args.run and receipt['head']==args.head
    assert receipt['plan_sha256']==args.plan_sha256 and receipt['artifact_id']==artifact['id'] and receipt['artifact_zip_sha256']==artifact['digest'][7:]
    assert PREP.is_dir() and RAW.is_dir() and SCRATCH.is_dir()
else:
    OPS.mkdir(parents=True,exist_ok=True)
    claim=OPS/('normal-collection-'+args.run+'.claim.json')
    with claim.open('x',encoding='utf-8') as handle:
        json.dump(dict(run_id=args.run,head=args.head,plan_sha256=args.plan_sha256,collector_sha256=digest(Path(__file__)),exclusive_normal_collection=True,automatic_retry_allowed=False),handle,indent=2)
        handle.write('\n')
    assert not OUT.exists() and not PREP.exists() and not SCRATCH.exists(),'Preserve existing or failed collection; no automatic retry'
    assert shutil.disk_usage(OPS.parent).free>=64*1024**2,'Fresh metadata headroom; exact post-ZIP budget follows before installation'
    OUT.mkdir(parents=True);assert shutil.disk_usage(OUT).free>=64*1024**2;write(OUT/'run-api.json',state);write(OUT/'artifact-api.json',artifact)

phase='hosted-z-stream-recollection' if args.recollect else 'download-stream-to-z'
try:
    assert 0<artifact['size_in_bytes']<=MAX_ARCHIVE_BYTES,'Archive exceeds reviewed2GiB storage bound; leave hosted'
    assert shutil.disk_usage(OUT).free>=artifact['size_in_bytes']+256*1024**2,'Fresh Z archive/reserve budget'
    archive=OUT/('recollection-'+uuid.uuid4().hex+'.zip' if args.recollect else 'downloaded-artifact.zip')
    print(json.dumps(dict(phase=phase,run_id=args.run,artifact_id=artifact['id'],bytes=artifact['size_in_bytes'],archive_cap_bytes=MAX_ARCHIVE_BYTES)),flush=True)
    downloaded=stream_archive_to_z(['gh','api',f"repos/{REMOTE}/actions/artifacts/{artifact['id']}/zip"],archive,artifact['size_in_bytes'],artifact['digest'][7:])
    phase='zip-authentication'
    with zipfile.ZipFile(archive) as package:
        entries=[entry for entry in package.infolist() if not entry.is_dir()];files={entry.filename:entry for entry in entries}
        assert len(files)==len(entries)==len({name.casefold() for name in files})
        for name,entry in files.items():
            rel=PurePosixPath(name)
            assert not rel.is_absolute() and '..' not in rel.parts and ':' not in name and '\\' not in name
            assert all(part not in ('.','..') and not part.endswith(('.',' ')) for part in rel.parts)
            assert not stat.S_ISLNK(entry.external_attr>>16)
        prep_prefix='reconciled-inputs/';raw_prefix='reconciled-qualification/evidence/';summary_name='reconciled-qualification/summary.json'
        prepared={name[len(prep_prefix):]:entry for name,entry in files.items() if name.startswith(prep_prefix)}
        raw={name[len(raw_prefix):]:entry for name,entry in files.items() if any(name.startswith(raw_prefix+'shard'+str(i)+'/') for i in (0,1))}
        assert prepared and raw and summary_name in files
        proof_raw=package.read(prep_prefix+'provenance.json');proof=json.loads(proof_raw)
        assert str(proof['run_id'])==args.run and str(proof['run_attempt'])=='1' and proof['workflow_head']==args.head
        assert proof['sources']==plan['sources'] and proof['plan_sha256']==args.plan_sha256
        assert proof['published_baseline']==q.verify_publication(plan)
        classified={prep_prefix+name for name in prepared}|{raw_prefix+name for name in raw}|{summary_name};runtime_count=0
        for shard_index in (0,1):
            shard=json.loads(package.read(raw_prefix+'shard'+str(shard_index)+'/provenance.json'))
            assert shard['input_provenance_sha256']==sha(proof_raw)
            for arm in ('old','new'):
                prefix=raw_prefix+'shard'+str(shard_index)+'-runtime-'+arm+'/'
                actual={name[len(prefix):]:entry for name,entry in files.items() if name.startswith(prefix)}
                declared=shard['binary_manifest'][arm];assert set(actual)==set(declared)
                for relative,entry in actual.items():
                    assert zip_digest(package,entry)==declared[relative];classified.add(entry.filename);runtime_count+=1
        assert runtime_count==4*len(proof['common_manifest'])
        assert classified==set(files),'Every uploaded file must have an authenticated role'
        cache={};unit_temp_sizes=[]
        for root,key in zip(CACHES,('old_candidate','candidate')):
            manifest_path=root/'manifest.json';assert digest(manifest_path)==plan[key]['manifest_sha256'];manifest=json.loads(manifest_path.read_bytes())
            assert manifest['source']==plan[key]['source'] and str(manifest['run_id'])==plan[key]['ci_run']
            for path in (root/'blobs').rglob('*'):
                if path.is_file():cache.setdefault(path.name,path)
            unit_temp_sizes.append(sum((root/'blobs'/value).stat().st_size for name,value in manifest['runtime_files'].items() if name.startswith('tests/bin/Release/net10.0/')))
        def payload(relative):return relative.startswith(('common/','production/')) or '/blobs/' in relative
        metadata_bytes=sum(entry.file_size for relative,entry in prepared.items() if not payload(relative))
        raw_bytes=sum(entry.file_size for entry in raw.values());summary_bytes=files[summary_name].file_size
        assert shutil.disk_usage(OUT).free>=raw_bytes+3*summary_bytes+64*1024*1024,'Z raw/summary/headroom budget'
        metadata_allowance=4096*(len(prepared)+len(raw)+64)
        temp_peak=max(unit_temp_sizes);required=(0 if args.recollect else metadata_bytes+raw_bytes+3*summary_bytes+metadata_allowance)+temp_peak+64*1024*1024
        if not args.recollect:OPS.mkdir(parents=True,exist_ok=True)
        free=shutil.disk_usage(OPS).free;assert free>=required,'Insufficient C metadata/temp/headroom; preserve artifact without materializing payload'
        if not args.recollect:
            write(OUT/'storage-budget.json',dict(available_free_bytes=free,required_free_bytes=required,prepared_metadata_bytes=metadata_bytes,retained_raw_bytes=raw_bytes,summary_bytes=summary_bytes,counted_metadata_allowance_bytes=metadata_allowance,verification_temp_peak_bytes=temp_peak,reserve_bytes=64*1024*1024,new_runtime_payload_bytes=0,retained_zip_bytes=0,transient_z_archive_bytes=downloaded,archive_cap_bytes=MAX_ARCHIVE_BYTES))
            PREP.mkdir();RAW.mkdir(parents=True);SCRATCH.mkdir()
        phase='prepared-and-raw-verification';verified_cache=set();links=0
        for relative,entry in prepared.items():
            target=PREP.joinpath(*PurePosixPath(relative).parts);assert target.resolve().is_relative_to(PREP.resolve())
            expected=zip_digest(package,entry)
            if args.recollect:assert target.is_file() and digest(target)==expected
            else:
                target.parent.mkdir(parents=True,exist_ok=True)
                if payload(relative):
                    assert expected in cache,'No uncached runtime payload may be installed: '+relative
                    if expected not in verified_cache:assert digest(cache[expected])==expected;verified_cache.add(expected)
                    os.link(cache[expected],target);assert os.path.samefile(cache[expected],target);links+=1
                else:
                    assert target.suffix.lower() not in ('.dll','.exe','.pdb')
                    target.write_bytes(package.read(entry));assert digest(target)==expected
        for relative,entry in raw.items():
            target=RAW.joinpath(*PurePosixPath(relative).parts);assert target.resolve().is_relative_to(RAW.resolve())
            assert target.suffix.lower() not in ('.dll','.exe','.pdb'),'Runtime ZIP payload is authenticated in place; retain only critical raw evidence'
            expected=zip_digest(package,entry)
            if args.recollect:assert target.is_file() and digest(target)==expected
            else:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(package.read(entry));assert digest(target)==expected
        assert {path.relative_to(PREP).as_posix() for path in PREP.rglob('*') if path.is_file()}==set(prepared)
        assert {path.relative_to(RAW).as_posix() for path in RAW.rglob('*') if path.is_file()}==set(raw)
        summary_raw=package.read(summary_name);hosted=json.loads(summary_raw)
        assert len(prepared)+len(raw)+runtime_count+1==len(files)
        if not args.recollect:(OUT/'uploaded-summary.json').write_bytes(summary_raw)
        else:assert (OUT/'uploaded-summary.json').read_bytes()==summary_raw
        assert digest(PREP/'provenance.json')==sha(proof_raw)
        assert shutil.disk_usage(OPS).free>=temp_peak+64*1024*1024,'Fresh verification temp budget required'
        os.environ.update(TEMP=str(SCRATCH),TMP=str(SCRATCH));tempfile.tempdir=str(SCRATCH)
        phase='actual-collector-replay';verifier_bound();q.p.verify_inputs(PREP);result=q.collect(RAW);verifier_bound()
        assert result==hosted and result['input_provenance_sha256']==sha(proof_raw)
        assert (result['case_count'],result['decision_count'])==(190,38)
        assert type(result['accepted']) is bool and result['qualification'] is True
        assert result['production_integrated'] is False and result['report_imported'] is False
        assert result['accepted']==(result['source_gate_accepted'] and result['native_progress_gate_passed'] and result['all_context_prior_native_wins_preserved'])
        expected={(op['pair'],bars,task['fixture'],method) for shard in q.shards() for task in shard['tasks'] for op in task['operations'] for bars in (1000,10000) for method in task['methods'] if method in q.p.OWNED}
        assert {(row['pair'],row['bars'],row['fixture'],row['method']) for row in result['decisions']}==expected
        rendered=(json.dumps(result,indent=2)+'\n').encode();assert rendered==summary_raw,'Recomputed canonical summary must be byte-identical to uploaded summary'
        screen=result['native_progress_gate']
        assert screen['minimum_native_margin'] is None and screen['native_policy_id']==plan['native_win_policy_approval']['policy_id']
        all_context=screen['family_gates']['all']
        concise=dict(status='actual-alma-sinc-combined-qualification-authenticated',run_id=args.run,head=args.head,plan_sha256=args.plan_sha256,
            artifact_id=artifact['id'],artifact_zip_sha256=artifact['digest'][7:],artifact_zip_bytes_streamed_to_z=downloaded,retained_zip_bytes=0,zip_files_verified=len(files),prepared_files_verified=len(prepared),raw_files_verified=len(raw),runtime_zip_payload_files_verified=runtime_count,
            prepared=str(PREP),raw=str(RAW),prepared_provenance_sha256=sha(proof_raw),fixture_inventory_sha256=digest(PREP/'fixture-method-inventory.json'),
            summary_sha256=sha(rendered),cases=190,decisions=38,verdicts=result['verdicts'],source_gate_passed=result['source_gate_accepted'],native_progress_gate_passed=screen['passed'],all_context_prior_native_wins_preserved=result['all_context_prior_native_wins_preserved'],
            family_gates=screen['family_gates'],new_alma_primary_wins=screen['new_10000_alma_primary_wins'],new_sinc_builder_wins=screen['new_10000_sinc_builder_wins'],lp_afirma_report_row_credit=0,
            runtime_hardlinks=links if not args.recollect else receipt['runtime_hardlinks'],new_runtime_payload_bytes=0,uploaded_summary_byte_equal=True,
            accepted=result['accepted'],qualification=True,production_integrated=False,report_imported=False,closure_credit=0,automatic_qualification=False,new_measurements=0,root_authentication_pending=True)
        if args.recollect:
            assert (OUT/'authenticated-summary.json').read_bytes()==rendered and receipt['summary_sha256']==sha(rendered)
            concise['status']='independent-recollection-matches-original';concise['retained_evidence_files_changed']=0
        else:(OUT/'authenticated-summary.json').write_bytes(rendered)
    # Close the authenticated ZIP before deleting only this newly created transient file.
    assert archive.resolve().parent==OUT.resolve() and archive.suffix=='.zip' and archive.is_file()
    archive.unlink()
    if not args.recollect:write(OUT/'collection-receipt.json',concise)
    print(json.dumps(concise,indent=2),flush=True)
except BaseException as error:
    if not args.recollect:write(OUT/'collection-failure.json',dict(run_id=args.run,head=args.head,phase=phase,error=str(error),traceback=traceback.format_exc(),automatic_retry_allowed=False,accepted=False,closure_credit=0))
    raise
