```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method   | Count | Operation        | Mean       | Error    | StdDev   | Gen0     | Gen1    | Allocated  |
|--------- |------ |----------------- |-----------:|---------:|---------:|---------:|--------:|-----------:|
| **Snapshot** | **1000**  | **Skender.GetRenko** |   **363.1 μs** |  **2.80 μs** |  **1.66 μs** |  **31.2500** |       **-** |  **531.67 KB** |
| **Snapshot** | **10000** | **Skender.GetRenko** | **3,679.4 μs** | **37.24 μs** | **22.16 μs** | **312.5000** | **31.2500** | **5314.85 KB** |
