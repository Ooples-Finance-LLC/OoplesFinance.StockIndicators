```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method         | Count | Operation        | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|--------------- |------ |----------------- |------------:|-----------:|-----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **Snapshot**       | **1000**  | **Skender.GetRenko** |   **462.44 μs** | **433.156 μs** | **286.506 μs** |  **5.83** |    **3.44** |  **7.8125** |       **-** |   **147.8 KB** |        **2.87** |
| NativeSingle   | 1000  | Skender.GetRenko |    79.37 μs |   0.757 μs |   0.450 μs |  1.00 |    0.01 |       - |       - |   51.43 KB |        1.00 |
| NativeParallel | 1000  | Skender.GetRenko |   146.15 μs |  11.388 μs |   7.533 μs |  1.84 |    0.09 |  8.7891 |  0.9766 |  130.01 KB |        2.53 |
|                |       |                  |             |            |            |       |         |         |         |            |             |
| **Snapshot**       | **10000** | **Skender.GetRenko** | **1,806.32 μs** |  **34.186 μs** |  **17.880 μs** |  **1.83** |    **0.02** | **78.1250** |       **-** | **1476.18 KB** |        **2.88** |
| NativeSingle   | 10000 | Skender.GetRenko |   987.95 μs |   9.605 μs |   5.716 μs |  1.00 |    0.01 | 31.2500 |  7.8125 |  513.33 KB |        1.00 |
| NativeParallel | 10000 | Skender.GetRenko | 1,333.18 μs |  77.949 μs |  51.558 μs |  1.35 |    0.05 | 78.1250 | 31.2500 | 1309.57 KB |        2.55 |
