```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId           | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |----------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetRenko** |   **209.2 μs** | **43.06 μs** | **28.48 μs** |  **1.02** |    **0.18** |  **159.63 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetRenko |   111.4 μs |  1.63 μs |  0.97 μs |  0.54 |    0.07 |   82.14 KB |        0.51 |
|            |       |                  |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetRenko** | **1,729.4 μs** | **19.51 μs** | **10.20 μs** |  **1.00** |    **0.01** | **1578.22 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetRenko | 1,081.9 μs | 37.04 μs | 22.04 μs |  0.63 |    0.01 |  731.09 KB |        0.46 |
