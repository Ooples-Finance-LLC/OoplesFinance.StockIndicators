```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetRenkoAtr** |   **244.1 μs** | **10.36 μs** |  **5.42 μs** |  **1.00** |    **0.03** |  **105.31 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetRenkoAtr |   164.6 μs | 14.78 μs |  8.79 μs |  0.67 |    0.04 |  225.06 KB |        2.14 |
|            |       |                     |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetRenkoAtr** | **2,314.8 μs** |  **9.72 μs** |  **5.79 μs** |  **1.00** |    **0.00** | **1026.77 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetRenkoAtr | 1,659.0 μs | 23.92 μs | 14.23 μs |  0.72 |    0.01 | 2148.44 KB |        2.09 |
