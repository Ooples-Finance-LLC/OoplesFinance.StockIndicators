```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method   | Count | Operation           | Mean       | Error     | StdDev    | Gen0     | Allocated |
|--------- |------ |-------------------- |-----------:|----------:|----------:|---------:|----------:|
| **Snapshot** | **1000**  | **Skender.GetRenkoAtr** |   **623.6 μs** | **166.79 μs** | **110.32 μs** |  **15.6250** | **502.66 KB** |
| **Snapshot** | **10000** | **Skender.GetRenkoAtr** | **4,096.1 μs** |  **89.08 μs** |  **53.01 μs** | **281.2500** | **5022.8 KB** |
