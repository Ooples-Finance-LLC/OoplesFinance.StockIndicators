```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method         | Count | Operation           | Mean       | Error    | StdDev   | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|--------------- |------ |-------------------- |-----------:|---------:|---------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **Snapshot**       | **1000**  | **Skender.GetRenkoAtr** |   **299.9 μs** | **78.30 μs** | **51.79 μs** |  **2.04** |    **0.34** |        **-** |       **-** |   **99.87 KB** |        **0.48** |
| NativeSingle   | 1000  | Skender.GetRenkoAtr |   147.4 μs |  5.49 μs |  3.63 μs |  1.00 |    0.03 |  12.6953 |  2.9297 |  208.67 KB |        1.00 |
| NativeParallel | 1000  | Skender.GetRenkoAtr |   211.4 μs | 33.99 μs | 22.48 μs |  1.43 |    0.15 |  15.6250 |  1.9531 |  270.48 KB |        1.30 |
|                |       |                     |            |          |          |       |         |          |         |            |             |
| **Snapshot**       | **10000** | **Skender.GetRenkoAtr** | **2,393.8 μs** | **27.75 μs** | **16.52 μs** |  **1.37** |    **0.02** |  **46.8750** |       **-** |  **990.13 KB** |        **0.48** |
| NativeSingle   | 10000 | Skender.GetRenkoAtr | 1,745.5 μs | 36.30 μs | 24.01 μs |  1.00 |    0.02 | 125.0000 | 62.5000 | 2078.58 KB |        1.00 |
| NativeParallel | 10000 | Skender.GetRenkoAtr | 2,056.7 μs | 17.39 μs |  9.10 μs |  1.18 |    0.02 | 156.2500 | 78.1250 | 2686.36 KB |        1.29 |
