```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)ngLow [25]** | **1000**  | **105.68 μs** | **13.120 μs** |  **8.678 μs** |  **1.9531** |       **-** |  **61.32 KB** |
| BuilderLatestOnly | TaLib(...)ngLow [25] | 1000  |  96.66 μs |  1.328 μs |  0.790 μs |       - |       - |  13.44 KB |
| **BuilderFull**       | **TaLib(...)ngLow [25]** | **10000** | **222.78 μs** |  **4.988 μs** |  **2.609 μs** | **33.2031** | **11.7188** | **549.74 KB** |
| BuilderLatestOnly | TaLib(...)ngLow [25] | 10000 | 212.25 μs | 15.596 μs | 10.316 μs |  3.9063 |       - |  79.64 KB |
