```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)ngLow [25]** | **1000**  |  **14.04 μs** |  **0.071 μs** |  **0.042 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)ngLow [25] | 1000  |  83.59 μs |  1.464 μs |  0.969 μs |  5.95 |    0.07 |  0.4883 |       - |   8.33 KB |        2.10 |
| BuilderFull       | TaLib(...)ngLow [25] | 1000  |  98.69 μs |  1.522 μs |  0.796 μs |  7.03 |    0.06 |  2.9297 |       - |  61.29 KB |       15.44 |
| BuilderLatestOnly | TaLib(...)ngLow [25] | 1000  |  96.90 μs |  1.666 μs |  0.871 μs |  6.90 |    0.06 |       - |       - |  13.44 KB |        3.39 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)ngLow [25]** | **10000** | **143.41 μs** |  **0.469 μs** |  **0.245 μs** |  **1.00** |    **0.00** |  **1.9531** |       **-** |  **39.13 KB** |        **1.00** |
| NativeParallel    | TaLib(...)ngLow [25] | 10000 | 157.95 μs | 15.432 μs | 10.208 μs |  1.10 |    0.07 |  5.8594 |       - |  78.65 KB |        2.01 |
| BuilderFull       | TaLib(...)ngLow [25] | 10000 | 227.52 μs | 14.766 μs |  8.787 μs |  1.59 |    0.06 | 33.2031 | 11.7188 | 549.71 KB |       14.05 |
| BuilderLatestOnly | TaLib(...)ngLow [25] | 10000 | 213.13 μs | 13.052 μs |  8.633 μs |  1.49 |    0.06 |  3.9063 |       - |  79.63 KB |        2.04 |
