```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)ngLow [25]** | **1000**  | **103.49 μs** |  **4.781 μs** |  **2.845 μs** |  **1.9531** |       **-** |  **61.32 KB** |
| BuilderLatestOnly | TaLib(...)ngLow [25] | 1000  |  97.54 μs |  1.045 μs |  0.547 μs |       - |       - |  13.44 KB |
| **BuilderFull**       | **TaLib(...)ngLow [25]** | **10000** | **319.75 μs** | **22.186 μs** | **14.675 μs** | **33.2031** | **13.6719** | **553.86 KB** |
| BuilderLatestOnly | TaLib(...)ngLow [25] | 10000 | 299.34 μs | 18.183 μs | 12.027 μs |  3.9063 |       - |  83.76 KB |
