```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)dwich [27]** | **1000**  | **108.49 μs** |  **9.218 μs** |  **6.097 μs** |  **1.9531** |       **-** |  **61.32 KB** |
| BuilderLatestOnly | TaLib(...)dwich [27] | 1000  |  96.99 μs |  0.786 μs |  0.411 μs |       - |       - |  13.44 KB |
| **BuilderFull**       | **TaLib(...)dwich [27]** | **10000** | **360.50 μs** | **12.038 μs** |  **6.296 μs** | **31.2500** | **11.7188** | **553.88 KB** |
| BuilderLatestOnly | TaLib(...)dwich [27] | 10000 | 311.28 μs | 18.021 μs | 11.920 μs |  3.9063 |       - |  83.76 KB |
