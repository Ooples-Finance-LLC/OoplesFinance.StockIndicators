```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)dwich [27]** | **1000**  | **102.6 μs** |  **4.83 μs** |  **2.88 μs** |  **1.9531** |       **-** |  **61.32 KB** |
| BuilderLatestOnly | TaLib(...)dwich [27] | 1000  | 101.1 μs |  2.75 μs |  1.82 μs |       - |       - |  13.44 KB |
| **BuilderFull**       | **TaLib(...)dwich [27]** | **10000** | **309.5 μs** | **16.93 μs** | **11.20 μs** | **33.2031** | **13.6719** | **553.87 KB** |
| BuilderLatestOnly | TaLib(...)dwich [27] | 10000 | 308.4 μs | 15.63 μs | 10.34 μs |  3.9063 |       - |  83.76 KB |
