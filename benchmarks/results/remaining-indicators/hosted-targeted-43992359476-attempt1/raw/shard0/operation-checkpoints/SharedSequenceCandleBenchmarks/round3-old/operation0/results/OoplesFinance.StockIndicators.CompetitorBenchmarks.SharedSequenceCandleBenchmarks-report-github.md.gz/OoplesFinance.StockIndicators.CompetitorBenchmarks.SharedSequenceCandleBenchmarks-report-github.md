```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)ngLow [25]** | **1000**  | **108.05 μs** |  **4.814 μs** |  **2.864 μs** |  **1.9531** |       **-** |  **61.32 KB** |
| BuilderLatestOnly | TaLib(...)ngLow [25] | 1000  |  96.62 μs |  1.138 μs |  0.595 μs |       - |       - |  13.44 KB |
| **BuilderFull**       | **TaLib(...)ngLow [25]** | **10000** | **308.76 μs** | **18.679 μs** | **12.355 μs** | **33.2031** | **13.6719** | **553.87 KB** |
| BuilderLatestOnly | TaLib(...)ngLow [25] | 10000 | 306.88 μs | 17.047 μs | 11.275 μs |  3.9063 |       - |  83.76 KB |
