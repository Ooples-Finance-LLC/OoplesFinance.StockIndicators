```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)dwich [27]** | **1000**  |  **14.40 μs** |  **0.035 μs** |  **0.018 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)dwich [27] | 1000  |  83.83 μs |  1.745 μs |  1.154 μs |  5.82 |    0.08 |  0.4883 |       - |   8.36 KB |        2.11 |
| BuilderFull       | TaLib(...)dwich [27] | 1000  | 100.06 μs |  3.173 μs |  2.099 μs |  6.95 |    0.14 |  2.9297 |       - |  61.32 KB |       15.45 |
| BuilderLatestOnly | TaLib(...)dwich [27] | 1000  | 103.85 μs |  2.313 μs |  1.530 μs |  7.21 |    0.10 |       - |       - |  13.44 KB |        3.39 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)dwich [27]** | **10000** | **143.97 μs** |  **0.958 μs** |  **0.501 μs** |  **1.00** |    **0.00** |  **1.9531** |       **-** |  **39.13 KB** |        **1.00** |
| NativeParallel    | TaLib(...)dwich [27] | 10000 | 162.66 μs |  8.435 μs |  5.579 μs |  1.13 |    0.04 |  5.8594 |       - |  78.67 KB |        2.01 |
| BuilderFull       | TaLib(...)dwich [27] | 10000 | 299.73 μs |  9.060 μs |  4.738 μs |  2.08 |    0.03 | 33.2031 | 13.6719 | 553.86 KB |       14.15 |
| BuilderLatestOnly | TaLib(...)dwich [27] | 10000 | 289.97 μs | 20.580 μs | 13.612 μs |  2.01 |    0.09 |  3.9063 |       - |  83.76 KB |        2.14 |
