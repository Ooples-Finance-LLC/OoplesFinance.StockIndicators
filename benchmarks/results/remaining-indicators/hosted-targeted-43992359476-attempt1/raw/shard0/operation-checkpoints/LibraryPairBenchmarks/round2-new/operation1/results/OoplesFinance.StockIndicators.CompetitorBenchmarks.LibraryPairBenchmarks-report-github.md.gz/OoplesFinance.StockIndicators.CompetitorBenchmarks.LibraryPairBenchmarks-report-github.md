```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error    | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|---------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Lines [29]** |  **91.41 μs** | **13.60 μs** |  **8.093 μs** |  **1.01** |    **0.13** |  **72.84 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Lines [29] |  62.43 μs | 13.12 μs |  8.676 μs |  0.69 |    0.12 |  17.28 KB |        0.24 |
|            |       |                      |           |          |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Lines [29]** | **521.74 μs** | **41.92 μs** | **24.946 μs** |  **1.00** |    **0.06** | **643.16 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Lines [29] | 538.73 μs | 18.50 μs | 12.237 μs |  1.03 |    0.05 | 124.06 KB |        0.19 |
