```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dwich [27]** |  **59.31 μs** | **12.131 μs** | **7.219 μs** |  **1.01** |    **0.15** |   **67.2 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dwich [27] |  21.99 μs |  0.427 μs | 0.223 μs |  0.37 |    0.04 |     17 KB |        0.25 |
|            |       |                      |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)dwich [27]** | **276.43 μs** | **14.705 μs** | **8.751 μs** |  **1.00** |    **0.04** | **637.48 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dwich [27] | 200.57 μs |  1.267 μs | 0.663 μs |  0.73 |    0.02 | 123.08 KB |        0.19 |
