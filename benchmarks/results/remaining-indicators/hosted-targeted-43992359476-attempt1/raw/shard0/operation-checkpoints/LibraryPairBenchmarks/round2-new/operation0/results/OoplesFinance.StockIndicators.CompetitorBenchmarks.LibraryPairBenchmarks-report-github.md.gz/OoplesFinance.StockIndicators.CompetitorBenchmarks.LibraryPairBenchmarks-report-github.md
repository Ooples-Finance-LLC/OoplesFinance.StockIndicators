```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)ngLow [25]** | **217.56 μs** | **10.962 μs** | **6.523 μs** |  **1.00** |    **0.04** |   **67.2 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)ngLow [25] |  24.93 μs |  0.223 μs | 0.116 μs |  0.11 |    0.00 |  16.63 KB |        0.25 |
|            |       |                      |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)ngLow [25]** | **133.36 μs** | **10.274 μs** | **5.373 μs** |  **1.00** |    **0.05** | **634.44 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)ngLow [25] | 236.31 μs | 11.386 μs | 6.775 μs |  1.77 |    0.08 | 123.41 KB |        0.19 |
