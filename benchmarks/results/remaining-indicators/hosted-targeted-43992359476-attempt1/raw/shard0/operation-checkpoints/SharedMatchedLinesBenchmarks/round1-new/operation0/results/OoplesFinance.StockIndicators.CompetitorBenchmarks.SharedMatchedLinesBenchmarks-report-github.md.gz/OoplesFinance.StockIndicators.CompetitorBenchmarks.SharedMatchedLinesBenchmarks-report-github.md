```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)Lines [29]** | **1000**  | **139.0 μs** | **26.00 μs** | **17.20 μs** |  **3.9063** |       **-** |  **72.63 KB** |
| BuilderLatestOnly | TaLib(...)Lines [29] | 1000  | 117.7 μs |  6.97 μs |  4.61 μs |  0.9766 |       - |  24.79 KB |
| **BuilderFull**       | **TaLib(...)Lines [29]** | **10000** | **522.2 μs** | **66.24 μs** | **43.81 μs** | **31.2500** | **15.6250** | **565.19 KB** |
| BuilderLatestOnly | TaLib(...)Lines [29] | 10000 | 448.3 μs |  5.77 μs |  3.02 μs |  3.9063 |       - |  95.13 KB |
