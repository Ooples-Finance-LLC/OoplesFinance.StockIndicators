```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)Lines [29]** | **1000**  |  **43.67 μs** |  **0.849 μs** |  **0.505 μs** |  **1.00** |    **0.02** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)Lines [29] | 1000  | 100.04 μs |  3.535 μs |  2.338 μs |  2.29 |    0.06 |       - |       - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib(...)Lines [29] | 1000  | 120.29 μs |  1.671 μs |  0.874 μs |  2.76 |    0.04 |  3.9063 |       - |  72.67 KB |       18.31 |
| BuilderLatestOnly | TaLib(...)Lines [29] | 1000  | 116.21 μs |  2.479 μs |  1.475 μs |  2.66 |    0.04 |  0.9766 |       - |  24.79 KB |        6.25 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)Lines [29]** | **10000** | **436.27 μs** |  **3.716 μs** |  **1.944 μs** |  **1.00** |    **0.01** |       **-** |       **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)Lines [29] | 10000 | 318.78 μs | 23.600 μs | 15.610 μs |  0.73 |    0.03 |  5.8594 |       - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib(...)Lines [29] | 10000 | 494.97 μs | 17.517 μs | 10.424 μs |  1.13 |    0.02 | 31.2500 | 15.6250 | 565.23 KB |       14.44 |
| BuilderLatestOnly | TaLib(...)Lines [29] | 10000 | 455.29 μs |  9.508 μs |  4.973 μs |  1.04 |    0.01 |  3.9063 |       - |  95.13 KB |        2.43 |
