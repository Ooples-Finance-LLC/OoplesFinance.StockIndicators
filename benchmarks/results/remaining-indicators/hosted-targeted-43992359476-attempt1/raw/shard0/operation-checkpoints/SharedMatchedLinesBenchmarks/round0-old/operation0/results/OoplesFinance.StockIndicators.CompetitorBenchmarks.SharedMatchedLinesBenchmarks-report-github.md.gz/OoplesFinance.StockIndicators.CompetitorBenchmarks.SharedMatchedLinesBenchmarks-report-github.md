```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)Lines [29]** | **1000**  | **125.1 μs** | **11.60 μs** | **7.67 μs** |  **3.9063** |       **-** |  **72.67 KB** |
| BuilderLatestOnly | TaLib(...)Lines [29] | 1000  | 118.0 μs |  5.69 μs | 3.76 μs |  0.9766 |       - |  24.79 KB |
| **BuilderFull**       | **TaLib(...)Lines [29]** | **10000** | **490.0 μs** | **15.32 μs** | **8.01 μs** | **31.2500** | **15.6250** | **565.23 KB** |
| BuilderLatestOnly | TaLib(...)Lines [29] | 10000 | 447.2 μs | 10.93 μs | 5.72 μs |  3.9063 |       - |  95.13 KB |
