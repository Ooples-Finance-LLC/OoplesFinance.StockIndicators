```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **4.387 ms** | **0.1234 ms** | **0.0816 ms** |  **85.02 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1.105 ms | 0.0066 ms | 0.0039 ms |  37.28 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **11.751 ms** | **0.1986 ms** | **0.1039 ms** | **789.14 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 11.632 ms | 0.1291 ms | 0.0768 ms | 319.18 KB |
