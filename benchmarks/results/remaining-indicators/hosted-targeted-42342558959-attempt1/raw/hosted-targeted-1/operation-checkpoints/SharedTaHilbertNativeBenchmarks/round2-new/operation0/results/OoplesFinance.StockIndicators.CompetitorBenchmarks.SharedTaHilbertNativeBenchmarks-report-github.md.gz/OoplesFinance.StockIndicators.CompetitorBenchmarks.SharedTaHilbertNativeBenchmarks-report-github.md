```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **3,647.2 μs** | **1,869.58 μs** | **1,236.61 μs** |  **6.60** |    **2.13** |  **85.02 KB** |        **5.40** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1,123.1 μs |    22.08 μs |    11.55 μs |  2.03 |    0.02 |  37.28 KB |        2.37 |
| NativeSingle      | TaLib(...)tSine [22] | 1000  |    552.7 μs |     6.24 μs |     3.72 μs |  1.00 |    0.01 |  15.74 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 1000  |    768.3 μs |    29.40 μs |    19.45 μs |  1.39 |    0.03 |  55.96 KB |        3.56 |
|                   |                      |       |             |             |             |       |         |           |             |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **11,975.1 μs** |   **211.27 μs** |   **125.72 μs** |  **2.03** |    **0.02** | **789.18 KB** |        **5.04** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 11,791.9 μs |   106.33 μs |    55.61 μs |  2.00 |    0.01 |  319.4 KB |        2.04 |
| NativeSingle      | TaLib(...)tSine [22] | 10000 |  5,893.3 μs |    51.36 μs |    30.56 μs |  1.00 |    0.01 | 156.55 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 10000 |  8,310.8 μs |   644.11 μs |   383.30 μs |  1.41 |    0.06 | 548.72 KB |        3.51 |
