```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Median    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **3.601 ms** | **1.8513 ms** | **1.2245 ms** |  **4.337 ms** |  **85.02 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1.102 ms | 0.0132 ms | 0.0087 ms |  1.098 ms |  37.28 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **11.793 ms** | **0.1689 ms** | **0.1005 ms** | **11.756 ms** | **788.89 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 11.697 ms | 0.2993 ms | 0.1781 ms | 11.627 ms | 319.37 KB |
