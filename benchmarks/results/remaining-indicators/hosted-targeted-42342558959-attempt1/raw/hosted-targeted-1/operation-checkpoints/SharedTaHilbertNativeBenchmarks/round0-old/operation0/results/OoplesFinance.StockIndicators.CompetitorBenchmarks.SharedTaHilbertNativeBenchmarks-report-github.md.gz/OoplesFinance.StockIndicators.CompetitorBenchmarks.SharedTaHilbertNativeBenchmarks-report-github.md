```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **4.406 ms** | **0.0901 ms** | **0.0536 ms** |  **85.02 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1.121 ms | 0.0426 ms | 0.0282 ms |  37.26 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **11.677 ms** | **0.0990 ms** | **0.0518 ms** | **789.11 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 11.628 ms | 0.0728 ms | 0.0482 ms | 319.08 KB |
