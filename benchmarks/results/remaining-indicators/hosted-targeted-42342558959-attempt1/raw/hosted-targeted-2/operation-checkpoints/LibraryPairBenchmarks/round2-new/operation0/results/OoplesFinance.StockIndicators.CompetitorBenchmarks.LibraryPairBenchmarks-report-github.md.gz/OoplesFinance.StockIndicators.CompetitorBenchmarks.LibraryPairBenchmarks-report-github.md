```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error    | StdDev   | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|---------:|---------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dMode [27]** |  **1,724.7 μs** |  **4.65 μs** |  **2.43 μs** |  **1.00** |  **112.73 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dMode [27] |    616.2 μs | 29.17 μs | 15.26 μs |  0.36 |   37.57 KB |        0.33 |
|            |       |                      |             |          |          |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)dMode [27]** | **17,396.2 μs** | **99.67 μs** | **52.13 μs** |  **1.00** | **1043.41 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dMode [27] |  6,416.8 μs | 29.36 μs | 19.42 μs |  0.37 |  292.45 KB |        0.28 |
