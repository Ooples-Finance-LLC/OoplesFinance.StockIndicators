```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1,697.5 μs** |     **9.38 μs** |   **4.90 μs** |  **2.91** |    **0.01** |   **71.7 KB** |       **15.15** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1,666.0 μs |     3.03 μs |   1.59 μs |  2.85 |    0.01 |  24.11 KB |        5.10 |
| NativeSingle      | TaLib(...)dMode [27] | 1000  |    583.9 μs |     1.53 μs |   1.01 μs |  1.00 |    0.00 |   4.73 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 1000  |    831.4 μs |    28.94 μs |  17.22 μs |  1.42 |    0.03 |  17.43 KB |        3.68 |
|                   |                      |       |             |             |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **17,298.6 μs** |    **91.15 μs** |  **54.24 μs** |  **2.72** |    **0.01** | **635.79 KB** |       **15.76** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 18,177.5 μs | 1,063.09 μs | 703.17 μs |  2.86 |    0.11 | 166.02 KB |        4.11 |
| NativeSingle      | TaLib(...)dMode [27] | 10000 |  6,354.3 μs |    23.85 μs |  15.77 μs |  1.00 |    0.00 |  40.35 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 10000 |  8,491.0 μs |   484.56 μs | 288.35 μs |  1.34 |    0.04 | 141.07 KB |        3.50 |
