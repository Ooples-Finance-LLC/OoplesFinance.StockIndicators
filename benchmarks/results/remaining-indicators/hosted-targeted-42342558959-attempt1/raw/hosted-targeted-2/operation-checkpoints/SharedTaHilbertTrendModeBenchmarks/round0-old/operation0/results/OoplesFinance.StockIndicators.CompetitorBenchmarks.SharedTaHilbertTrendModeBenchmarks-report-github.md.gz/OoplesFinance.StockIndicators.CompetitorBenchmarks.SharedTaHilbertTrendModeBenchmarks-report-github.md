```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1.671 ms** | **0.0054 ms** | **0.0028 ms** |   **71.7 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1.664 ms | 0.0050 ms | 0.0026 ms |  24.11 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **17.085 ms** | **0.0462 ms** | **0.0305 ms** | **635.78 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 17.164 ms | 0.0551 ms | 0.0328 ms | 165.97 KB |
