```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **2.324 ms** | **0.6300 ms** | **0.4167 ms** |   **71.7 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1.667 ms | 0.0097 ms | 0.0057 ms |  24.12 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **17.238 ms** | **0.0409 ms** | **0.0271 ms** | **635.79 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 17.219 ms | 0.0730 ms | 0.0435 ms | 165.97 KB |
