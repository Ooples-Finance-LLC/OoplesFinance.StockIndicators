```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Phase [25]** |   **905.1 μs** | **30.69 μs** | **16.05 μs** |  **1.00** |    **0.02** |  **110.06 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Phase [25] |   430.4 μs | 19.07 μs | 12.61 μs |  0.48 |    0.02 |   39.79 KB |        0.36 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)Phase [25]** | **9,118.4 μs** | **40.23 μs** | **23.94 μs** |  **1.00** |    **0.00** | **1037.79 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Phase [25] | 4,420.6 μs | 31.21 μs | 20.65 μs |  0.48 |    0.00 |  328.89 KB |        0.32 |
