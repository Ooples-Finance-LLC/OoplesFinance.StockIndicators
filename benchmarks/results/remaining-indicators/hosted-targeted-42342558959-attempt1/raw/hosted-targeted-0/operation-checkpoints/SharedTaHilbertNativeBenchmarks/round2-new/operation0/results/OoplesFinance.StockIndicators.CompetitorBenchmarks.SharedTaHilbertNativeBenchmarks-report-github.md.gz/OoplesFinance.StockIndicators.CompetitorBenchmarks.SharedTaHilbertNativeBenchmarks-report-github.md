```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **797.2 μs** |  **10.75 μs** |   **6.40 μs** |  **2.19** |    **0.03** |  **68.94 KB** |        **8.24** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   794.3 μs |   6.16 μs |   3.66 μs |  2.18 |    0.02 |  21.36 KB |        2.55 |
| NativeSingle      | TaLib(...)Phase [25] | 1000  |   364.3 μs |   5.90 μs |   3.51 μs |  1.00 |    0.01 |   8.37 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 1000  |   564.9 μs |  29.60 μs |  15.48 μs |  1.55 |    0.04 |  30.19 KB |        3.61 |
|                   |                      |       |            |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **8,998.2 μs** | **144.51 μs** |  **86.00 μs** |  **2.07** |    **0.02** | **632.25 KB** |        **8.02** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 8,935.5 μs |  31.90 μs |  18.99 μs |  2.05 |    0.01 |  162.3 KB |        2.06 |
| NativeSingle      | TaLib(...)Phase [25] | 10000 | 4,350.8 μs |  31.84 μs |  18.95 μs |  1.00 |    0.01 |  78.84 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 10000 | 6,192.3 μs | 321.82 μs | 212.86 μs |  1.42 |    0.05 | 276.75 KB |        3.51 |
