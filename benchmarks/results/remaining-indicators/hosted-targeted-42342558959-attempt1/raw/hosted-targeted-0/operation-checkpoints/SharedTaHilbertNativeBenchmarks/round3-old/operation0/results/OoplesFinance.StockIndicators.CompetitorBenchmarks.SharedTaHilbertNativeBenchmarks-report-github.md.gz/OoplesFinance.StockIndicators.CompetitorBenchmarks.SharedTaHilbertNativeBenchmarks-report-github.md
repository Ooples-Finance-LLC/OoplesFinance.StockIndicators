```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **813.0 μs** |   **9.98 μs** |   **5.94 μs** |  **68.94 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   824.4 μs |   6.02 μs |   3.15 μs |  21.36 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **9,356.5 μs** | **411.26 μs** | **272.02 μs** | **632.11 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 9,213.4 μs | 128.02 μs |  84.68 μs | 162.54 KB |
