```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **803.3 μs** | **10.32 μs** |  **5.40 μs** |  **68.94 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   800.5 μs | 10.10 μs |  6.01 μs |  21.37 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **8,965.8 μs** | **61.56 μs** | **40.72 μs** | **632.17 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 8,968.9 μs | 52.30 μs | 31.12 μs | 162.41 KB |
