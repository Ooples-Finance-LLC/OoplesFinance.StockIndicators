```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **820.8 μs** |  **9.78 μs** |  **5.82 μs** |  **68.94 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   816.1 μs | 10.17 μs |  6.05 μs |  21.37 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **9,197.6 μs** | **30.79 μs** | **16.11 μs** | **632.41 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 9,130.8 μs | 29.40 μs | 15.38 μs | 162.51 KB |
