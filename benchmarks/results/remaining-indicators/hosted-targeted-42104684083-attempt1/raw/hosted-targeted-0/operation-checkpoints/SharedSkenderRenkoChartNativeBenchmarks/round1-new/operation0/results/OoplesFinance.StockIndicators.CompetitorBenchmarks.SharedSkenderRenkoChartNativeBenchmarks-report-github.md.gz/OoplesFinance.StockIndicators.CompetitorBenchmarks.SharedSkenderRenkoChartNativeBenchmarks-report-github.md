```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method   | Count | Operation        | Mean       | Error     | StdDev   | Gen0    | Allocated  |
|--------- |------ |----------------- |-----------:|----------:|---------:|--------:|-----------:|
| **Snapshot** | **1000**  | **Skender.GetRenko** |   **400.4 μs** |  **97.15 μs** | **64.26 μs** |       **-** |  **531.67 KB** |
| **Snapshot** | **10000** | **Skender.GetRenko** | **3,540.2 μs** | **150.06 μs** | **89.30 μs** | **62.5000** | **5314.85 KB** |
