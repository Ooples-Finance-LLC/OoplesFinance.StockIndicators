```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method         | Count | Operation        | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated  | Alloc Ratio |
|--------------- |------ |----------------- |------------:|----------:|----------:|------:|--------:|--------:|-------:|-----------:|------------:|
| **Snapshot**       | **1000**  | **Skender.GetRenko** |   **370.68 μs** | **53.043 μs** | **35.085 μs** |  **5.28** |    **0.48** |       **-** |      **-** |  **531.67 KB** |       **10.34** |
| NativeSingle   | 1000  | Skender.GetRenko |    70.21 μs |  1.671 μs |  1.105 μs |  1.00 |    0.02 |  0.4883 |      - |    51.4 KB |        1.00 |
| NativeParallel | 1000  | Skender.GetRenko |   122.65 μs |  8.578 μs |  5.674 μs |  1.75 |    0.08 |  0.9766 |      - |  130.01 KB |        2.53 |
|                |       |                  |             |           |           |       |         |         |        |            |             |
| **Snapshot**       | **10000** | **Skender.GetRenko** | **3,500.69 μs** | **25.877 μs** | **13.534 μs** |  **3.97** |    **0.02** | **62.5000** |      **-** | **5314.87 KB** |       **10.35** |
| NativeSingle   | 10000 | Skender.GetRenko |   881.87 μs |  6.662 μs |  3.484 μs |  1.00 |    0.01 |       - |      - |  513.34 KB |        1.00 |
| NativeParallel | 10000 | Skender.GetRenko | 1,209.56 μs | 94.340 μs | 62.400 μs |  1.37 |    0.07 | 15.6250 | 7.8125 | 1309.57 KB |        2.55 |
