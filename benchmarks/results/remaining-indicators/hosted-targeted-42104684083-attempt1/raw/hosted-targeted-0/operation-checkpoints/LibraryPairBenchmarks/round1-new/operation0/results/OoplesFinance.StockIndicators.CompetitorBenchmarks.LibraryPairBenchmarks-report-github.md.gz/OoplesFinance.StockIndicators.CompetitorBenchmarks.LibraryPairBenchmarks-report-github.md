```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId           | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |----------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetRenko** |   **328.2 μs** |  **20.29 μs** |  **10.61 μs** |  **1.00** |    **0.04** |  **543.49 KB** |        **1.00** |
|        |       |                  |            |           |           |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetRenko** | **3,211.4 μs** | **204.92 μs** | **121.95 μs** |  **1.00** |    **0.05** | **5413.83 KB** |        **1.00** |
