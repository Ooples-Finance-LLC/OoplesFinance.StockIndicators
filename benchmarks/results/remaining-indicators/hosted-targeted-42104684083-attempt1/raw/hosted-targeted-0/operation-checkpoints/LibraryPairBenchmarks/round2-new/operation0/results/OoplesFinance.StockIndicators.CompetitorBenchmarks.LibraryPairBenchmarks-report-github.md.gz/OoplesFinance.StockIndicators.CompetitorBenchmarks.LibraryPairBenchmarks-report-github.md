```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId           | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |----------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetRenko** |   **349.4 μs** | **33.88 μs** | **22.41 μs** |  **1.00** |    **0.09** |  **543.49 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetRenko |   105.9 μs |  1.14 μs |  0.60 μs |  0.30 |    0.02 |   82.47 KB |        0.15 |
|            |       |                  |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetRenko** | **3,349.7 μs** | **84.46 μs** | **44.17 μs** |  **1.00** |    **0.02** | **5414.77 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetRenko | 1,026.2 μs | 39.74 μs | 23.65 μs |  0.31 |    0.01 |  730.06 KB |        0.13 |
