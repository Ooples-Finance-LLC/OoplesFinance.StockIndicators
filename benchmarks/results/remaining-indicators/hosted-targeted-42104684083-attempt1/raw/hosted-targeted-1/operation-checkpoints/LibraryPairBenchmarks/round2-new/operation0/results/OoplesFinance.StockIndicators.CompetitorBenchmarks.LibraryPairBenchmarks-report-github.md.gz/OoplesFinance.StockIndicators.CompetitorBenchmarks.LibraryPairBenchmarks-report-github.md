```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetRenkoAtr** |   **411.3 μs** |  **29.50 μs** |  **17.56 μs** |  **1.00** |    **0.06** |  **508.07 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetRenkoAtr |   161.1 μs |   3.25 μs |   1.93 μs |  0.39 |    0.02 |  225.44 KB |        0.44 |
|            |       |                     |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetRenkoAtr** | **4,041.1 μs** | **305.47 μs** | **181.78 μs** |  **1.00** |    **0.06** | **5060.22 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetRenkoAtr | 1,670.8 μs |  38.78 μs |  23.08 μs |  0.41 |    0.02 | 2140.94 KB |        0.42 |
