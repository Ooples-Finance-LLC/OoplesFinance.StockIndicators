```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method         | Count | Operation           | Mean       | Error     | StdDev    | Median     | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|--------------- |------ |-------------------- |-----------:|----------:|----------:|-----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **Snapshot**       | **1000**  | **Skender.GetRenkoAtr** |   **620.6 μs** | **420.51 μs** | **278.14 μs** |   **468.6 μs** |  **4.27** |    **1.83** |  **15.6250** |       **-** |  **502.63 KB** |        **2.41** |
| NativeSingle   | 1000  | Skender.GetRenkoAtr |   145.3 μs |   5.70 μs |   3.39 μs |   143.9 μs |  1.00 |    0.03 |   7.8125 |       - |  208.73 KB |        1.00 |
| NativeParallel | 1000  | Skender.GetRenkoAtr |   203.5 μs |  22.56 μs |  13.43 μs |   203.5 μs |  1.40 |    0.09 |  17.5781 |  1.9531 |  270.48 KB |        1.30 |
|                |       |                     |            |           |           |            |       |         |          |         |            |             |
| **Snapshot**       | **10000** | **Skender.GetRenkoAtr** | **4,083.9 μs** |  **84.00 μs** |  **49.99 μs** | **4,084.9 μs** |  **2.32** |    **0.04** | **281.2500** |       **-** | **5023.05 KB** |        **2.42** |
| NativeSingle   | 10000 | Skender.GetRenkoAtr | 1,757.5 μs |  35.10 μs |  20.89 μs | 1,751.5 μs |  1.00 |    0.02 | 125.0000 | 62.5000 | 2078.58 KB |        1.00 |
| NativeParallel | 10000 | Skender.GetRenkoAtr | 2,078.3 μs | 140.76 μs |  93.11 μs | 2,030.3 μs |  1.18 |    0.05 | 156.2500 | 78.1250 | 2686.36 KB |        1.29 |
