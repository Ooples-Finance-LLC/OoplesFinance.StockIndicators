```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error       | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |------------------- |------ |-----------:|------------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetDynamic** | **1000**  |   **877.7 μs** |    **47.08 μs** |  **24.63 μs** |  **46.8750** |        **-** |  **953.61 KB** |
| BuilderLatestOnly | Skender.GetDynamic | 1000  |   844.8 μs |    41.27 μs |  27.30 μs |  54.6875 |        - |   906.1 KB |
| **BuilderFull**       | **Skender.GetDynamic** | **10000** | **8,778.0 μs** |   **910.40 μs** | **602.17 μs** | **555.5556** | **222.2222** | **9525.53 KB** |
| BuilderLatestOnly | Skender.GetDynamic | 10000 | 9,569.4 μs | 1,309.67 μs | 684.98 μs | 545.4545 | 181.8182 | 9055.58 KB |
