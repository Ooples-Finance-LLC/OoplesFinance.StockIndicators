```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Gen0     | Gen1     | Allocated  |
|------------------ |--------------- |------ |-----------:|---------:|---------:|---------:|---------:|-----------:|
| **BuilderFull**       | **QuanTAlib.Mgdi** | **1000**  |   **819.8 μs** |  **8.50 μs** |  **4.45 μs** |  **46.8750** |        **-** |  **953.62 KB** |
| BuilderLatestOnly | QuanTAlib.Mgdi | 1000  |   813.1 μs |  7.18 μs |  4.27 μs |  54.6875 |        - |   906.1 KB |
| **BuilderFull**       | **QuanTAlib.Mgdi** | **10000** | **8,214.0 μs** | **60.35 μs** | **35.91 μs** | **538.4615** | **230.7692** | **9525.25 KB** |
| BuilderLatestOnly | QuanTAlib.Mgdi | 10000 | 7,974.1 μs | 31.72 μs | 18.87 μs | 538.4615 | 153.8462 | 9055.44 KB |
