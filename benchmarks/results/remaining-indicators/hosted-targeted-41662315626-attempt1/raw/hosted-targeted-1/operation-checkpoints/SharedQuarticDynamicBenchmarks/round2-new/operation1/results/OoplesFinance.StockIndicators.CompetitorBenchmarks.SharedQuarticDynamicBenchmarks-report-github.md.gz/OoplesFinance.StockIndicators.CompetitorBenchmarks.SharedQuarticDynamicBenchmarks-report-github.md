```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetDynamic** | **1000**  |   **198.34 μs** |  **34.011 μs** |  **22.496 μs** |  **2.51** |    **0.27** |   **7.8125** |        **-** |        **-** |  **128.38 KB** |        **1.42** |
| BuilderLatestOnly | Skender.GetDynamic | 1000  |   146.34 μs |   6.512 μs |   3.875 μs |  1.85 |    0.05 |   4.8828 |        - |        - |   80.78 KB |        0.90 |
| NativeSingle      | Skender.GetDynamic | 1000  |    78.92 μs |   0.431 μs |   0.257 μs |  1.00 |    0.00 |   5.3711 |   0.4883 |        - |   90.24 KB |        1.00 |
| NativeParallel    | Skender.GetDynamic | 1000  |   137.88 μs |   7.545 μs |   4.991 μs |  1.75 |    0.06 |  14.6484 |   2.9297 |        - |  234.43 KB |        2.60 |
|                   |                    |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetDynamic** | **10000** | **1,452.95 μs** |  **37.308 μs** |  **24.677 μs** |  **1.49** |    **0.03** |  **78.1250** |  **39.0625** |        **-** | **1326.83 KB** |        **1.47** |
| BuilderLatestOnly | Skender.GetDynamic | 10000 | 1,411.17 μs |  12.697 μs |   8.398 μs |  1.45 |    0.02 |  46.8750 |  15.6250 |        - |     857 KB |        0.95 |
| NativeSingle      | Skender.GetDynamic | 10000 |   972.95 μs |  23.003 μs |  13.689 μs |  1.00 |    0.02 | 109.3750 |  85.9375 |  78.1250 |  899.63 KB |        1.00 |
| NativeParallel    | Skender.GetDynamic | 10000 | 1,787.87 μs | 252.799 μs | 167.211 μs |  1.84 |    0.17 | 265.6250 | 203.1250 | 156.2500 | 2328.67 KB |        2.59 |
