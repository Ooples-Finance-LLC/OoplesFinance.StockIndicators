```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |--------------- |------ |-----------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **QuanTAlib.Mgdi** | **1000**  |   **834.9 μs** |  **25.66 μs** |  **15.27 μs** |  **46.8750** |        **-** |  **953.65 KB** |
| BuilderLatestOnly | QuanTAlib.Mgdi | 1000  |   824.5 μs |  12.70 μs |   6.64 μs |  54.6875 |        - |   906.1 KB |
| **BuilderFull**       | **QuanTAlib.Mgdi** | **10000** | **8,838.2 μs** | **755.81 μs** | **499.92 μs** | **545.4545** | **272.7273** | **9525.22 KB** |
| BuilderLatestOnly | QuanTAlib.Mgdi | 10000 | 8,560.1 μs | 442.64 μs | 263.41 μs | 545.4545 | 181.8182 | 9055.58 KB |
