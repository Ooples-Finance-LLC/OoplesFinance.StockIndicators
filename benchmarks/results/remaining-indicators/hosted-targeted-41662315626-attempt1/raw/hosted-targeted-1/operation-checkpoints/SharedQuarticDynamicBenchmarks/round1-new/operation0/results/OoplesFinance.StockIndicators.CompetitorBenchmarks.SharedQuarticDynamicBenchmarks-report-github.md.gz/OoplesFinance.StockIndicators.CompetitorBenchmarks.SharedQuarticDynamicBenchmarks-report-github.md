```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated  |
|------------------ |--------------- |------ |-----------:|---------:|---------:|--------:|--------:|-----------:|
| **BuilderFull**       | **QuanTAlib.Mgdi** | **1000**  |   **141.5 μs** |  **1.75 μs** |  **0.91 μs** |  **7.8125** |       **-** |  **128.38 KB** |
| BuilderLatestOnly | QuanTAlib.Mgdi | 1000  |   138.5 μs |  1.60 μs |  0.95 μs |  4.8828 |       - |   80.78 KB |
| **BuilderFull**       | **QuanTAlib.Mgdi** | **10000** | **1,408.6 μs** | **17.96 μs** | **10.69 μs** | **78.1250** | **39.0625** | **1326.83 KB** |
| BuilderLatestOnly | QuanTAlib.Mgdi | 10000 | 1,386.0 μs | 30.41 μs | 15.91 μs | 46.8750 | 15.6250 |     857 KB |
