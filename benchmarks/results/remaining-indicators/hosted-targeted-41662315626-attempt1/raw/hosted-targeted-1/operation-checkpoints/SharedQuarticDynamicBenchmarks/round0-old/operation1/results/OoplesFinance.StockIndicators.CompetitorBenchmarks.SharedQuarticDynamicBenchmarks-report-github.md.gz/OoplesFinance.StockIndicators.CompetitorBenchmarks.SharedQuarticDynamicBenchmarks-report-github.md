```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0     | Gen1     | Allocated  |
|------------------ |------------------- |------ |-----------:|---------:|---------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetDynamic** | **1000**  |   **833.1 μs** | **21.75 μs** | **14.39 μs** |  **46.8750** |        **-** |  **953.65 KB** |
| BuilderLatestOnly | Skender.GetDynamic | 1000  |   833.1 μs | 16.96 μs |  8.87 μs |  54.6875 |        - |   906.1 KB |
| **BuilderFull**       | **Skender.GetDynamic** | **10000** | **8,073.0 μs** | **75.53 μs** | **39.50 μs** | **538.4615** | **230.7692** | **9525.28 KB** |
| BuilderLatestOnly | Skender.GetDynamic | 10000 | 8,146.9 μs | 58.11 μs | 30.39 μs | 538.4615 | 153.8462 | 9055.46 KB |
