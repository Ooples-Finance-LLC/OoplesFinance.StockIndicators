```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Mgdi** | **1000**  |   **143.58 μs** |   **5.700 μs** |   **3.392 μs** |  **2.68** |    **0.06** |  **7.8125** |       **-** |  **128.38 KB** |        **2.72** |
| BuilderLatestOnly | QuanTAlib.Mgdi | 1000  |   143.90 μs |  11.670 μs |   7.719 μs |  2.69 |    0.14 |  4.8828 |       - |   80.78 KB |        1.71 |
| NativeSingle      | QuanTAlib.Mgdi | 1000  |    53.56 μs |   0.144 μs |   0.075 μs |  1.00 |    0.00 |  2.4414 |       - |   47.16 KB |        1.00 |
| NativeParallel    | QuanTAlib.Mgdi | 1000  |    78.35 μs |   3.748 μs |   2.230 μs |  1.46 |    0.04 |  6.3477 |       - |  106.72 KB |        2.26 |
|                   |                |       |             |            |            |       |         |         |         |            |             |
| **BuilderFull**       | **QuanTAlib.Mgdi** | **10000** | **1,412.12 μs** |   **8.634 μs** |   **5.138 μs** |  **2.63** |    **0.01** | **78.1250** | **39.0625** | **1326.84 KB** |        **2.83** |
| BuilderLatestOnly | QuanTAlib.Mgdi | 10000 | 1,585.67 μs | 525.049 μs | 312.448 μs |  2.95 |    0.55 | 46.8750 | 15.6250 |     857 KB |        1.83 |
| NativeSingle      | QuanTAlib.Mgdi | 10000 |   537.69 μs |   3.037 μs |   2.009 μs |  1.00 |    0.01 | 27.3438 |  3.9063 |  469.06 KB |        1.00 |
| NativeParallel    | QuanTAlib.Mgdi | 10000 |   743.69 μs |  84.746 μs |  56.054 μs |  1.38 |    0.10 | 62.5000 |  7.8125 |    1056 KB |        2.25 |
