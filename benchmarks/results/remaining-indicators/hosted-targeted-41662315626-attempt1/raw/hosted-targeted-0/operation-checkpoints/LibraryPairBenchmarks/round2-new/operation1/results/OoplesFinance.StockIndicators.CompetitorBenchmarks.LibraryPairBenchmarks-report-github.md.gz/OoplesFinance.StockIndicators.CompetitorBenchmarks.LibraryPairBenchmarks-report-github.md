```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetDynamic** |   **202.53 μs** | **10.570 μs** |  **5.529 μs** |  **1.00** |    **0.04** |  **130.98 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetDynamic |    84.04 μs |  6.189 μs |  3.683 μs |  0.42 |    0.02 |  115.33 KB |        0.88 |
|            |       |                    |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetDynamic** | **1,100.20 μs** | **44.698 μs** | **23.378 μs** |  **1.00** |    **0.03** | **1190.27 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetDynamic |   846.26 μs | 30.627 μs | 18.226 μs |  0.77 |    0.02 | 1073.62 KB |        0.90 |
