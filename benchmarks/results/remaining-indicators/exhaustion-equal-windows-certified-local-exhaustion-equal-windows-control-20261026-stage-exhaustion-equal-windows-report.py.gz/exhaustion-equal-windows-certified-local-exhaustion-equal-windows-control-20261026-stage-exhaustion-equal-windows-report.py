from pathlib import Path
import sys
import copy,datetime,hashlib,html,json,re,subprocess
ROOT=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
REPO=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
name='exhaustion-equal-windows'
RUN=f'local-{name}-control-20261026'
RAW=ROOT/RUN
LIVE=Path('C:/Users/cheat/Documents/OoplesFinance-Reports/competitor-performance.html')
OUT=LIVE.parent/(name+'-refresh-'+RUN)
summary=json.loads((RAW/'verified-summary.json').read_text(encoding='utf-8'))
assert summary['all_144_cases_verified'] and not any(r['verdict']=='slower' for r in summary['decisions']) and any(r['verdict']=='faster' for r in summary['decisions'])
SOURCE=summary['sources']['new'];PAIRS={r['pair'] for r in summary['final_candidate_rows']['LibraryPairBenchmarks']}
fixtures=['SharedTaReversalContinuationBenchmarks'] # All four matched native and builder arms are measured.
BUILDER_PAIRS={r['pair'] for fixture in fixtures for r in summary['final_candidate_rows'][fixture]}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
archive='benchmarks/results/remaining-indicators/'+RUN+'/decision.json'
subprocess.run(['git','cat-file','-e',head+':'+archive],cwd=REPO,check=True)
url='https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/blob/'+head+'/'+archive
original=LIVE.read_bytes();s=original.decode('utf-8')
def embedded(name):return json.loads(re.search(r'<script[^>]*id="'+name+r'"[^>]*>(.*?)</script>',s,re.S)[1])
def replace(name,value):
 global s
 s,n=re.subn(r'(<script[^>]*id="'+name+r'"[^>]*>).*?(</script>)',lambda m:m[1]+json.dumps(value,ensure_ascii=True).replace('<','\\u003c')+m[2],s,flags=re.S);assert n==1
data=embedded('dataset');before=copy.deepcopy(data);builder=embedded('current-competitor-data');status=embedded('rollout-status-data');oldcounts=status['measurement_totals'].copy()
state=json.loads((RAW/'status.json').read_text(encoding='utf-8'))
record=next(r for r in state['rounds'] if r['index']==2 and r['fixture']=='LibraryPairBenchmarks')
raw=Path(record['report']).read_bytes();assert hashlib.sha256(raw).hexdigest()==record['sha256'];report=json.loads(raw)
for row in data['rows']:
 if row['pair'] not in PAIRS:continue
 for method,arm in [('Ooples','ooples'),('Competitor','competitor')]:
  cases=[c for c in report['Benchmarks'] if c['Method']==method and f'Bars: {row["bars"]},' in c['FullName'] and f'PairId: "{row["pair"]}"' in c['FullName']];assert len(cases)==1
  c=cases[0];stats=c['Statistics'];row.update({arm+'_mean_ns':stats['Mean'],arm+'_stddev_ns':stats['StandardDeviation'],arm+'_samples':stats['N'],arm+'_allocated_bytes':c['Memory']['BytesAllocatedPerOperation']})
  row['raw'][method]={'samples':stats['OriginalValues'],'host':report['HostEnvironmentInfo'],'report':str(Path(record['report']).relative_to(RAW)),'confidence_interval':stats['ConfidenceInterval']}
 row.update(competitor_over_ooples=row['competitor_mean_ns']/row['ooples_mean_ns'],source_sha=SOURCE,measurement_run_url=url)
data['evidence']['rowOverrides']=[r for r in data['evidence']['rowOverrides'] if r['pair'] not in PAIRS]
for pair in sorted(PAIRS):data['evidence']['rowOverrides'].append({'pair':pair,'sourceSha':SOURCE,'runUrl':url,'reportSha256':record['sha256'],'round':2,'selection':'Chronologically final candidate round of local Windows actual LibraryPair measurements; builder timing is separate.','measurementLocation':'Local Windows'})
assert sum(a==b for a,b in zip(before['rows'],data['rows'],strict=True))==len(before['rows'])-2*len(PAIRS)
replace('dataset',data)
old_builder_count=builder['full_comparisons']
old_builder_pairs=len({c['pair'] for receipt in builder['receipts'] for c in receipt['comparisons']})
replaced=0
for receipt in builder['receipts']:
 keep=[c for c in receipt['comparisons'] if c['pair'] not in BUILDER_PAIRS]
 replaced+=len(receipt['comparisons'])-len(keep);receipt['comparisons']=keep
assert replaced<=4*len(BUILDER_PAIRS)
builder['receipts']=[receipt for receipt in builder['receipts'] if receipt['comparisons']]
for builder_fixture in fixtures:
 cases={(row['pair'],row['bars'],row['method']):row for row in summary['final_candidate_rows'][builder_fixture]}
 pairs={key[0] for key in cases}
 assert cases.keys()=={(pair,bars,method) for pair in pairs for bars in [1000,10000] for method in ['BuilderFull','BuilderLatestOnly','NativeSingle','NativeParallel']}
 def stats(row):return {key:row[key] for key in ['mean_ns','lower_ns','upper_ns','samples','allocated_bytes']}
 comparisons=[]
 for pair in sorted(pairs):
  for bars in [1000,10000]:
   native={method:stats(cases[pair,bars,method]) for method in ['NativeSingle','NativeParallel']}
   for mode in ['BuilderFull','BuilderLatestOnly']:
    ours=stats(cases[pair,bars,mode]);verdict='faster' if ours['upper_ns']<min(n['lower_ns'] for n in native.values()) else 'slower' if ours['lower_ns']>min(n['upper_ns'] for n in native.values()) else 'inconclusive'
    comparisons.append({'pair':pair,'bars':bars,'mode':mode,'ooples':ours,'native':native,'fastest_native':min(native,key=lambda method:native[method]['mean_ns']),'verdict':verdict})
 record=next(row for row in state['rounds'] if row['index']==2 and row['fixture']==builder_fixture)
 builder['receipts'].append({'fixture':builder_fixture,'source_sha':SOURCE,'run_id':RUN,'measurement_url':url,'measurement_location':'Local Windows','round':2,'report_file':str(Path(record['report']).relative_to(RAW)),'report_sha256':record['sha256'],'selection':'Chronologically final candidate round, not fastest.','complete':True,'comparisons':comparisons})
added=4*len(BUILDER_PAIRS)-replaced
builder['full_comparisons']=old_builder_count+added
rows=[{**c,'run_id':str(r['run_id']),'source_sha':r['source_sha'],'measurement_url':r.get('measurement_url','https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/'+str(r['run_id']))} for r in builder['receipts'] for c in r['comparisons']]
assert len(rows)==builder['full_comparisons'] and len({(r['pair'],r['bars'],r['mode']) for r in rows})==len(rows)
counts={v:sum(r['verdict']==v for r in rows) for v in ['faster','slower','inconclusive']};builder['verdicts']=counts
if fixtures:
 builder['status'].update(commit=SOURCE,updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),run_url=url)
 builder['status']['completed']=sorted(set(builder['status']['completed'])|set(fixtures))
replace('current-competitor-data',builder)
oldhead=status['published_head'];status.update(published_head=head,inventory_commit=head,row_overrides=data['evidence']['rowOverrides'],inventory_sha256=hashlib.sha256((REPO/'benchmarks/results/remaining-indicators/inventory.json').read_bytes()).hexdigest());status['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();status['measurement_totals'].update(counts,measured=len(rows),pending=oldcounts['expected']-len(rows));status['builder_measurement_sources'].extend([{'source_sha':SOURCE,'run_url':url,'comparisons':4*len(BUILDER_PAIRS),'replaces_pairs':sorted(BUILDER_PAIRS),'round':2,'measurement_location':'Local Windows'}] if fixtures else []);replace('rollout-status-data',status)
groups={}
for row in data['rows']:
 key=(row['source_sha'],row['measurement_run_url']);groups[key]=groups.get(key,0)+1
caption='Measured builds: '+', '.join(f'{sha[:8]} ({count} comparisons)' for (sha,link),count in groups.items())+'.'
s=re.sub(r'Measured builds: [^<]*?\.',lambda _:caption,s)
oldwins=sum(r['competitor_over_ooples']>1 for r in before['rows'] if r['bars']==10000);wins=sum(r['competitor_over_ooples']>1 for r in data['rows'] if r['bars']==10000)
s=s.replace(f'{oldwins} / 401 APIs at 10,000 bars',f'{wins} / 401 APIs at 10,000 bars').replace('published <code>'+oldhead[:8]+'</code>','published <code>'+head[:8]+'</code>')
for prefix in ['Builder-mode timing: ',': ']:
 old=prefix+f"{oldcounts['faster']} faster, {oldcounts['slower']} slower, {oldcounts['inconclusive']} inconclusive, "+('and ' if prefix.startswith('Builder') else '')+f"{oldcounts['pending']} pending."
 new=prefix+f"{counts['faster']} faster, {counts['slower']} slower, {counts['inconclusive']} inconclusive, "+('and ' if prefix.startswith('Builder') else '')+f"{status['measurement_totals']['pending']} pending."
 s=s.replace(old,new)
s=s.replace(f"{old_builder_count} / {oldcounts['expected']}",f"{len(rows)} / {oldcounts['expected']}").replace(f'{old_builder_pairs} API pairs',f"{len({row['pair'] for row in rows})} API pairs")
body=[]
for r in sorted(rows,key=lambda r:(r['pair'],r['bars'],r['mode'])):
 values=[r['pair'],f"{r['bars']:,}",'Full history' if r['mode']=='BuilderFull' else 'Latest only',f"{r['ooples']['mean_ns']/1e6:.6f}",f"{r['native']['NativeSingle']['mean_ns']/1e6:.6f}",f"{r['native']['NativeParallel']['mean_ns']/1e6:.6f}",{'faster':'Faster than both','slower':'Slower than at least one','inconclusive':'Inconclusive'}[r['verdict']]]
 body.append('<tr data-builder-pair="'+html.escape(r['pair'],quote=True)+'" data-bars="'+str(r['bars'])+'" data-mode="'+r['mode']+'">'+''.join('<td>'+html.escape(x)+'</td>' for x in values)+'<td><a href="'+html.escape(r['measurement_url'],quote=True)+'">'+r['run_id']+'</a></td></tr>')
s,n=re.subn(r'(<table id="builder-current-results">.*?<tbody>).*?(</tbody>)',lambda m:m[1]+''.join(body)+m[2],s,flags=re.S);assert n==1
source_html='<p>'+ ' '.join(f'{count} comparisons: <code>{sha}</code>, <a href="{html.escape(link,quote=True)}">measurement evidence</a>.' for (sha,link),count in groups.items())+' Per-row details and CSV contain each measurement source and evidence link.</p>'
s,n=re.subn(r"\$\('source'\)\.innerHTML=[^\r\n]*;",lambda _:"$('source').innerHTML="+json.dumps(source_html)+';',s,count=1,flags=re.M);assert n==1
# Keep the qualification introduction consistent with the actual mixed-source rows.
refresh_rows=sum(row['source_sha']!=data['evidence']['baseSourceSha'] for row in data['rows'])
intro=(f"The table contains {len(data['rows'])} measured comparisons across {len({row['pair'] for row in data['rows']})} API pairs. "
       f"{refresh_rows} comparison rows use separately qualified updates. Each row identifies its measured source and run; builder timings are reported separately.")
s,n=re.subn(r'(<section id="rollout-status".*?<p class="sub">.*?published <code>[^<]+</code>\. ).*?(</p>)',lambda m:m[1]+intro+m[2],s,count=1,flags=re.S)
assert n==1

OUT.mkdir(exist_ok=True);assert not (OUT/'before.html').exists() or (OUT/'before.html').read_bytes()==original
(OUT/'before.html').write_bytes(original);(OUT/'candidate.html').write_text(s,encoding='utf-8')
(OUT/'measurement.json').write_text(json.dumps({'source_sha':SOURCE,'run_id':RUN,'measurement_url':url}),encoding='utf-8')
(OUT/'staged.json').write_text(json.dumps({'before_sha256':hashlib.sha256(original).hexdigest(),'candidate_sha256':hashlib.sha256((OUT/'candidate.html').read_bytes()).hexdigest(),'changed_baseline_rows':2*len(PAIRS),'unchanged_baseline_rows':len(data['rows'])-2*len(PAIRS),'changed_builder_slots':4*len(BUILDER_PAIRS),'added_builder_slots':added,'replaced_builder_slots':replaced,'builder_rows':rows,'verdicts':counts},indent=2),encoding='utf-8')
print('Staged',2*len(PAIRS),'baseline rows and',4*len(BUILDER_PAIRS),'builder slots',counts)
