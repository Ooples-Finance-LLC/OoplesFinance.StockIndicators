```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev   | Gen0     | Gen1    | Allocated  |
|------------------ |-------------------- |------ |-----------:|---------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **TaLib.Functions.Apo** | **1000**  |   **212.0 μs** | **56.39 μs** | **37.30 μs** |  **15.6250** |       **-** |  **355.26 KB** |
| BuilderLatestOnly | TaLib.Functions.Apo | 1000  |   180.9 μs | 19.17 μs | 11.41 μs |  18.5547 |  0.9766 |  307.65 KB |
| **BuilderFull**       | **TaLib.Functions.Apo** | **10000** | **1,553.9 μs** | **46.58 μs** | **24.36 μs** | **187.5000** | **93.7500** |  **3167.5 KB** |
| BuilderLatestOnly | TaLib.Functions.Apo | 10000 | 1,622.4 μs | 80.54 μs | 53.27 μs | 164.0625 | 54.6875 | 2697.66 KB |
