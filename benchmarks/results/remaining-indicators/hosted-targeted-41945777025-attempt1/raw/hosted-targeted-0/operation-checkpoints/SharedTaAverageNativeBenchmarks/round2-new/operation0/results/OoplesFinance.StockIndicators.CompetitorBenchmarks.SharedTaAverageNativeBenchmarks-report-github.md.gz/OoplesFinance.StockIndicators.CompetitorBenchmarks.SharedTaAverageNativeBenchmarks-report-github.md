```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean         | Error       | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |-------------:|------------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Apo** | **1000**  |   **112.378 μs** |   **2.3965 μs** |  **1.2534 μs** | **40.17** |    **0.70** |  **3.9063** |       **-** |  **86.49 KB** |        **5.53** |
| BuilderLatestOnly | TaLib.Functions.Apo | 1000  |   111.383 μs |   6.8487 μs |  4.5300 μs | 39.81 |    1.64 |  1.9531 |       - |  38.88 KB |        2.49 |
| NativeSingle      | TaLib.Functions.Apo | 1000  |     2.798 μs |   0.0690 μs |  0.0411 μs |  1.00 |    0.02 |  0.9460 |  0.0305 |  15.64 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Apo | 1000  |     5.902 μs |   0.1565 μs |  0.0931 μs |  2.11 |    0.04 |  3.3569 |  0.1831 |   47.7 KB |        3.05 |
|                   |                     |       |              |             |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Apo** | **10000** | **1,005.311 μs** | **109.6019 μs** | **72.4949 μs** | **37.90** |    **2.67** | **39.0625** | **15.6250** | **649.37 KB** |        **4.16** |
| BuilderLatestOnly | TaLib.Functions.Apo | 10000 |   946.432 μs |  65.5388 μs | 43.3499 μs | 35.68 |    1.65 |  7.8125 |       - | 179.54 KB |        1.15 |
| NativeSingle      | TaLib.Functions.Apo | 10000 |    26.534 μs |   0.7083 μs |  0.4215 μs |  1.00 |    0.02 |  9.5215 |  1.4648 | 156.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Apo | 10000 |    55.938 μs |   2.1485 μs |  1.4211 μs |  2.11 |    0.06 | 30.7617 |  9.2773 | 469.58 KB |        3.01 |
