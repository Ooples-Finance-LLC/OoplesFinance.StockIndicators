```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |-------------------- |------ |-----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Apo** | **1000**  |   **132.4 μs** |  **21.93 μs** | **14.50 μs** |  **3.9063** |       **-** |  **86.49 KB** |
| BuilderLatestOnly | TaLib.Functions.Apo | 1000  |   115.4 μs |  10.59 μs |  7.00 μs |  1.9531 |       - |  38.88 KB |
| **BuilderFull**       | **TaLib.Functions.Apo** | **10000** | **1,043.0 μs** | **123.90 μs** | **81.95 μs** | **39.0625** | **15.6250** | **649.38 KB** |
| BuilderLatestOnly | TaLib.Functions.Apo | 10000 |   962.7 μs |   7.29 μs |  3.81 μs |  7.8125 |       - | 179.54 KB |
