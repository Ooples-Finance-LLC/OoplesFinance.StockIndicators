```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev   | Gen0     | Gen1    | Allocated  |
|------------------ |-------------------- |------ |-----------:|----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **TaLib.Functions.Apo** | **1000**  |   **183.5 μs** |  **18.04 μs** |  **9.43 μs** |  **15.6250** |       **-** |  **355.26 KB** |
| BuilderLatestOnly | TaLib.Functions.Apo | 1000  |   176.6 μs |   2.78 μs |  1.45 μs |  17.5781 |       - |  307.65 KB |
| **BuilderFull**       | **TaLib.Functions.Apo** | **10000** | **1,678.3 μs** | **157.18 μs** | **93.54 μs** | **187.5000** | **93.7500** | **3167.55 KB** |
| BuilderLatestOnly | TaLib.Functions.Apo | 10000 | 1,634.7 μs |  45.05 μs | 23.56 μs | 156.2500 | 46.8750 |  2697.7 KB |
