```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean         | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |-------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Apo** |   **161.690 μs** | **11.690 μs** | **7.7322 μs** |  **1.00** |    **0.06** |  **116.91 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Apo |     5.830 μs |  1.332 μs | 0.8807 μs |  0.04 |    0.01 |   46.16 KB |        0.39 |
|            |       |                     |              |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Apo** | **1,138.975 μs** | **16.373 μs** | **8.5633 μs** |  **1.00** |    **0.01** | **1047.59 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Apo |    44.789 μs |  5.148 μs | 3.0633 μs |  0.04 |    0.00 |  404.31 KB |        0.39 |
