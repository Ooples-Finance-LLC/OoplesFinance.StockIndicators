```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev    | Gen0     | Gen1    | Allocated  |
|------------------ |-------------------- |------ |-----------:|----------:|----------:|---------:|--------:|-----------:|
| **BuilderFull**       | **TaLib.Functions.Ppo** | **1000**  |   **346.2 μs** |  **20.46 μs** |  **10.70 μs** |  **15.6250** |       **-** |   **355.3 KB** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 1000  |   330.8 μs |  46.16 μs |  27.47 μs |  15.6250 |       - |  307.67 KB |
| **BuilderFull**       | **TaLib.Functions.Ppo** | **10000** | **2,939.9 μs** | **117.72 μs** |  **61.57 μs** | **187.5000** | **93.7500** | **3167.75 KB** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 10000 | 3,147.5 μs | 584.63 μs | 386.70 μs | 156.2500 | 31.2500 | 2697.91 KB |
