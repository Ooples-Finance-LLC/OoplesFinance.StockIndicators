```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev    | Gen0     | Gen1    | Allocated  |
|------------------ |-------------------- |------ |-----------:|----------:|----------:|---------:|--------:|-----------:|
| **BuilderFull**       | **TaLib.Functions.Ppo** | **1000**  |   **505.7 μs** |  **63.08 μs** |  **41.72 μs** |  **15.6250** |       **-** |  **355.26 KB** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 1000  |   329.0 μs |  37.97 μs |  22.60 μs |  15.6250 |       - |  307.64 KB |
| **BuilderFull**       | **TaLib.Functions.Ppo** | **10000** | **3,017.6 μs** | **184.60 μs** | **109.85 μs** | **187.5000** | **93.7500** |  **3167.6 KB** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 10000 | 3,117.8 μs | 313.38 μs | 207.28 μs | 156.2500 | 46.8750 | 2697.76 KB |
