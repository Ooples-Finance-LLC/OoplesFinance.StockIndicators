```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |-------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Ppo** | **1000**  |   **226.7 μs** |  **45.23 μs** |  **29.91 μs** |       **-** |  **86.49 KB** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 1000  |   202.9 μs |   9.17 μs |   4.80 μs |  1.9531 |  38.89 KB |
| **BuilderFull**       | **TaLib.Functions.Ppo** | **10000** | **1,889.6 μs** | **215.25 μs** | **142.37 μs** | **31.2500** | **649.47 KB** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 10000 | 1,831.0 μs | 139.74 μs |  92.43 μs |       - | 179.63 KB |
