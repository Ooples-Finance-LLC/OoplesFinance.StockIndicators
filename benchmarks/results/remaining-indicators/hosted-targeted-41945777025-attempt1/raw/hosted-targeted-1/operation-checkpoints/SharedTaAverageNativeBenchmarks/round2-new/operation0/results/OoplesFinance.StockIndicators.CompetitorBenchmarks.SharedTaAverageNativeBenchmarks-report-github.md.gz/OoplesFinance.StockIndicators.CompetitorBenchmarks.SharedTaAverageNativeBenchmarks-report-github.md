```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |-------------:|------------:|------------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Ppo** | **1000**  |   **214.823 μs** |   **1.9789 μs** |   **1.0350 μs** | **34.42** |    **0.47** |       **-** |      **-** |  **86.49 KB** |        **5.53** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 1000  |   212.036 μs |  18.6710 μs |  12.3497 μs | 33.97 |    1.94 |  1.9531 |      - |  38.89 KB |        2.49 |
| NativeSingle      | TaLib.Functions.Ppo | 1000  |     6.242 μs |   0.1274 μs |   0.0842 μs |  1.00 |    0.02 |  0.9155 |      - |  15.64 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ppo | 1000  |    11.962 μs |   0.2183 μs |   0.1299 μs |  1.92 |    0.03 |  3.2959 | 0.2441 |   47.7 KB |        3.05 |
|                   |                     |       |              |             |             |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Ppo** | **10000** | **1,816.304 μs** |  **25.4725 μs** |  **13.3226 μs** | **30.04** |    **0.27** | **31.2500** |      **-** | **649.47 KB** |        **4.16** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 10000 | 1,876.155 μs | 211.6252 μs | 139.9769 μs | 31.03 |    2.22 |       - |      - | 179.63 KB |        1.15 |
| NativeSingle      | TaLib.Functions.Ppo | 10000 |    60.467 μs |   0.6339 μs |   0.3772 μs |  1.00 |    0.01 |  9.2773 | 1.4648 | 156.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ppo | 10000 |   113.336 μs |   7.5888 μs |   5.0195 μs |  1.87 |    0.08 | 30.2734 | 9.7656 | 469.59 KB |        3.00 |
