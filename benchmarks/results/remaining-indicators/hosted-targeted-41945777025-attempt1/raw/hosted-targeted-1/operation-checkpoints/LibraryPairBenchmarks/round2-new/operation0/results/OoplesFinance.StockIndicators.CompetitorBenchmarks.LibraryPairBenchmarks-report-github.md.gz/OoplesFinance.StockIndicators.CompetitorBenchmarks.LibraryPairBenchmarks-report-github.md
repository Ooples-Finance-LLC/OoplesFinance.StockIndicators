```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ppo** |   **235.86 μs** |  **4.400 μs** |  **2.302 μs** |  **1.00** |    **0.01** |  **116.91 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ppo |    11.30 μs |  0.698 μs |  0.415 μs |  0.05 |    0.00 |   48.46 KB |        0.41 |
|            |       |                     |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ppo** | **2,147.29 μs** | **40.659 μs** | **26.893 μs** |  **1.00** |    **0.02** | **1048.24 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ppo |    94.99 μs |  8.444 μs |  5.025 μs |  0.04 |    0.00 |  408.86 KB |        0.39 |
