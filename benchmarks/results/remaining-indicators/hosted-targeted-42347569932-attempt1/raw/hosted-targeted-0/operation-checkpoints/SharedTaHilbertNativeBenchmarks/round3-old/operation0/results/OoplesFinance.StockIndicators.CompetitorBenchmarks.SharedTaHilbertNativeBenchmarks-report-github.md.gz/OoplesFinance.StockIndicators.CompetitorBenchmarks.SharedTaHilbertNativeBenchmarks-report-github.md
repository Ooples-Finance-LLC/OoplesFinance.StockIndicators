```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **817.3 μs** | **12.71 μs** |  **7.56 μs** |  **68.94 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   814.3 μs | 11.56 μs |  6.88 μs |  21.38 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **9,178.4 μs** | **38.31 μs** | **20.04 μs** | **632.53 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 9,226.7 μs | 29.02 μs | 15.18 μs | 162.36 KB |
