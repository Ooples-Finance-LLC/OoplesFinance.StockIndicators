```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **786.3 μs** |   **9.14 μs** |   **5.44 μs** |  **2.18** |    **0.02** |  **68.94 KB** |        **8.24** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   776.4 μs |   4.23 μs |   2.21 μs |  2.15 |    0.01 |  21.34 KB |        2.55 |
| NativeSingle      | TaLib(...)Phase [25] | 1000  |   360.7 μs |   2.17 μs |   1.29 μs |  1.00 |    0.00 |   8.37 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 1000  |   552.3 μs |  19.02 μs |  12.58 μs |  1.53 |    0.03 |  30.19 KB |        3.61 |
|                   |                      |       |            |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **8,859.8 μs** |  **28.21 μs** |  **16.79 μs** |  **2.04** |    **0.01** | **632.28 KB** |        **8.02** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 8,945.3 μs |  81.04 μs |  42.39 μs |  2.06 |    0.01 | 162.46 KB |        2.06 |
| NativeSingle      | TaLib(...)Phase [25] | 10000 | 4,346.4 μs |  30.64 μs |  16.03 μs |  1.00 |    0.00 |  78.84 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 10000 | 6,185.8 μs | 242.71 μs | 126.94 μs |  1.42 |    0.03 | 276.78 KB |        3.51 |
