```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **821.4 μs** |  **9.81 μs** |  **5.84 μs** |  **68.94 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   816.3 μs |  6.54 μs |  3.42 μs |  21.36 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **9,115.2 μs** | **42.59 μs** | **25.34 μs** |  **632.5 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 9,214.8 μs | 51.68 μs | 34.18 μs | 162.51 KB |
