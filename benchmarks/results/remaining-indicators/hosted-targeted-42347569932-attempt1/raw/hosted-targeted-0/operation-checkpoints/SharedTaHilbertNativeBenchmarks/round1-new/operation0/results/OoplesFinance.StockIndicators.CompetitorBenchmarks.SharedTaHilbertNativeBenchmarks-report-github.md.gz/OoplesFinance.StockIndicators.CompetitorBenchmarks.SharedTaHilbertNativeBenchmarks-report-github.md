```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **789.6 μs** |  **12.38 μs** |   **6.48 μs** |  **68.94 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   783.5 μs |   4.21 μs |   2.51 μs |  21.37 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **9,056.2 μs** |  **27.58 μs** |  **14.43 μs** | **632.44 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 9,107.3 μs | 270.43 μs | 160.93 μs | 162.71 KB |
