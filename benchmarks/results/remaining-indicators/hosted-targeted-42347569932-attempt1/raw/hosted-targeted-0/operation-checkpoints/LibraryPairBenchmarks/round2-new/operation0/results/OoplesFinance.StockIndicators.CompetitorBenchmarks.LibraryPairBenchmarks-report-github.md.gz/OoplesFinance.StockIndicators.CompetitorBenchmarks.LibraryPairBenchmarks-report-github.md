```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Phase [25]** |   **902.3 μs** | **24.23 μs** | **16.03 μs** |  **1.00** |    **0.02** |  **110.06 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Phase [25] |   426.0 μs | 10.15 μs |  5.31 μs |  0.47 |    0.01 |   37.82 KB |        0.34 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)Phase [25]** | **9,042.6 μs** | **90.15 μs** | **53.65 μs** |  **1.00** |    **0.01** | **1035.26 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Phase [25] | 4,421.3 μs | 32.45 μs | 21.46 μs |  0.49 |    0.00 |  327.53 KB |        0.32 |
