```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1.332 ms** | **0.0058 ms** | **0.0035 ms** |  **71.69 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1.383 ms | 0.1483 ms | 0.0981 ms |  24.02 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **14.134 ms** | **0.0596 ms** | **0.0312 ms** |  **635.4 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 14.095 ms | 0.0557 ms | 0.0291 ms | 165.73 KB |
