```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1,331.2 μs** |  **18.65 μs** |  **12.34 μs** |  **3.24** |    **0.05** |  **71.68 KB** |       **15.17** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1,308.2 μs |  11.21 μs |   5.86 μs |  3.18 |    0.04 |  24.03 KB |        5.09 |
| NativeSingle      | TaLib(...)dMode [27] | 1000  |    411.5 μs |   9.39 μs |   4.91 μs |  1.00 |    0.02 |   4.72 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 1000  |    628.2 μs |  25.68 μs |  16.99 μs |  1.53 |    0.04 |   17.4 KB |        3.68 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **14,020.7 μs** |  **38.81 μs** |  **23.10 μs** |  **2.84** |    **0.01** | **635.63 KB** |       **15.87** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 14,220.6 μs |  16.97 μs |   8.88 μs |  2.88 |    0.00 | 165.42 KB |        4.13 |
| NativeSingle      | TaLib(...)dMode [27] | 10000 |  4,933.1 μs |  12.65 μs |   6.61 μs |  1.00 |    0.00 |  40.04 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 10000 |  7,091.0 μs | 593.95 μs | 310.65 μs |  1.44 |    0.06 | 141.13 KB |        3.52 |
