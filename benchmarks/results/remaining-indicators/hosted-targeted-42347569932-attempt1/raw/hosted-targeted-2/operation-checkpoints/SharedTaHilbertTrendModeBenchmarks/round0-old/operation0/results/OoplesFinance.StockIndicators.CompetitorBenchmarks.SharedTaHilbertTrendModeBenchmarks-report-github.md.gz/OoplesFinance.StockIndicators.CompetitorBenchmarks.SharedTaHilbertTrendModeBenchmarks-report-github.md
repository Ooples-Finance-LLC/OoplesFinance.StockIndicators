```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1.340 ms** | **0.0365 ms** | **0.0191 ms** |  **71.68 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1.311 ms | 0.0139 ms | 0.0083 ms |  24.03 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **14.137 ms** | **0.0534 ms** | **0.0279 ms** | **635.19 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 14.033 ms | 0.0375 ms | 0.0223 ms |  165.4 KB |
