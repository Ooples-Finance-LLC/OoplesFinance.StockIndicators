```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1.325 ms** | **0.0135 ms** | **0.0080 ms** |   **71.6 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1.299 ms | 0.0101 ms | 0.0053 ms |  24.05 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **14.031 ms** | **0.0477 ms** | **0.0284 ms** | **635.16 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 14.015 ms | 0.0307 ms | 0.0183 ms | 165.67 KB |
