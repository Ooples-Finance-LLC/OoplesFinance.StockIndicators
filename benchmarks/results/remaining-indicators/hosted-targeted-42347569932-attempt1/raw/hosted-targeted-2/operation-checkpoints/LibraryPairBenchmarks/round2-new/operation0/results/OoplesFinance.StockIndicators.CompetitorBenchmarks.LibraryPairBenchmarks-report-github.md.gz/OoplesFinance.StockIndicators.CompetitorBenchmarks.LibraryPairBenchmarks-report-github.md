```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dMode [27]** |  **1,438.5 μs** |  **36.22 μs** | **23.96 μs** |  **1.00** |    **0.02** |  **112.69 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dMode [27] |    486.4 μs |  19.47 μs | 11.59 μs |  0.34 |    0.01 |    37.2 KB |        0.33 |
|            |       |                      |             |           |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)dMode [27]** | **14,183.1 μs** | **116.18 μs** | **60.76 μs** |  **1.00** |    **0.01** | **1041.12 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dMode [27] |  5,002.2 μs |  33.90 μs | 22.42 μs |  0.35 |    0.00 |  290.77 KB |        0.28 |
