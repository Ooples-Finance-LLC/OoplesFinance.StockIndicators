```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |----------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)dMode [27]** |  **1.405 ms** | **0.0175 ms** | **0.0104 ms** |  **1.00** |  **112.73 KB** |        **1.00** |
|        |       |                      |           |           |           |       |            |             |
| **Ooples** | **10000** | **TaLib(...)dMode [27]** | **14.303 ms** | **0.0427 ms** | **0.0254 ms** |  **1.00** | **1042.14 KB** |        **1.00** |
