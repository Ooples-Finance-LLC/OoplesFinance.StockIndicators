```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tSine [22]** |   **670.5 μs** | **21.52 μs** | **12.81 μs** |  **1.00** |    **0.03** |  **166.46 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tSine [22] |   378.3 μs |  0.68 μs |  0.36 μs |  0.56 |    0.01 |   69.31 KB |        0.42 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)tSine [22]** | **6,929.2 μs** | **57.05 μs** | **29.84 μs** |  **1.00** |    **0.01** | **1590.62 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tSine [22] | 4,088.3 μs | 53.74 μs | 35.54 μs |  0.59 |    0.01 |  648.45 KB |        0.41 |
