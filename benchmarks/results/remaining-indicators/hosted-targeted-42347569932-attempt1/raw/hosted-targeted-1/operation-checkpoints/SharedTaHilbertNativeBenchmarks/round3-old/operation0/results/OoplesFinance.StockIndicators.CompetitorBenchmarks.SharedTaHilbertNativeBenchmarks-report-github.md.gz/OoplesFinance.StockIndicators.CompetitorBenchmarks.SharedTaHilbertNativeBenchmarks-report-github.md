```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **586.4 μs** |   **7.25 μs** |  **4.31 μs** | **3.9063** |  **84.83 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   598.1 μs |  31.81 μs | 18.93 μs |      - |  37.22 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **6,931.7 μs** | **106.74 μs** | **55.83 μs** |      **-** | **788.32 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 6,839.6 μs |  56.50 μs | 33.62 μs |      - | 318.65 KB |
