```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **576.4 μs** |  **38.16 μs** |  **25.24 μs** |  **1.48** |    **0.09** |  **3.9063** |  **84.83 KB** |        **5.40** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   556.8 μs |  13.03 μs |   7.75 μs |  1.43 |    0.07 |       - |  37.24 KB |        2.37 |
| NativeSingle      | TaLib(...)tSine [22] | 1000  |   389.2 μs |  29.35 μs |  19.41 μs |  1.00 |    0.07 |       - |  15.72 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 1000  |   547.1 μs |  18.64 μs |  11.09 μs |  1.41 |    0.07 |       - |  55.96 KB |        3.56 |
|                   |                      |       |            |           |           |       |         |         |           |             |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **6,542.9 μs** |  **45.42 μs** |  **27.03 μs** |  **1.66** |    **0.02** |       **-** |  **788.8 KB** |        **5.05** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 6,501.1 μs | 138.24 μs |  82.27 μs |  1.65 |    0.03 |       - | 318.69 KB |        2.04 |
| NativeSingle      | TaLib(...)tSine [22] | 10000 | 3,949.2 μs | 102.55 μs |  53.64 μs |  1.00 |    0.02 |       - | 156.35 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 10000 | 5,826.3 μs | 177.34 μs | 117.30 μs |  1.48 |    0.03 | 31.2500 | 548.31 KB |        3.51 |
