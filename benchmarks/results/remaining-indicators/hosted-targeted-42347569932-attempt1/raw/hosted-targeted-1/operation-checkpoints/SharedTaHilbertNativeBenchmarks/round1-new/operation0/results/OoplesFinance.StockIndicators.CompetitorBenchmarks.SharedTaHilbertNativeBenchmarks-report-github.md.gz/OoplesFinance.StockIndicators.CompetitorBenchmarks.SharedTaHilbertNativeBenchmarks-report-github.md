```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **575.7 μs** |  **18.38 μs** |  **10.94 μs** |   **84.8 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   561.7 μs |  19.59 μs |  11.66 μs |  37.23 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **6,406.2 μs** | **204.23 μs** | **135.08 μs** | **788.59 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 6,445.9 μs | 120.50 μs |  79.70 μs | 318.89 KB |
