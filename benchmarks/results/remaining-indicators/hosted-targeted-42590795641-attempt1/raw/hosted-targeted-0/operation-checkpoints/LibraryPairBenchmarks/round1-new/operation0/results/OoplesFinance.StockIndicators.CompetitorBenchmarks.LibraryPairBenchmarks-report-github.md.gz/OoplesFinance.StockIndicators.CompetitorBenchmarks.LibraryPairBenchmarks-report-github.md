```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId         | Mean     | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------- |---------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetAdl** | **138.3 μs** | **15.77 μs** |  **9.38 μs** |  **1.00** |    **0.09** |     **159 KB** |        **1.00** |
|        |       |                |          |          |          |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetAdl** | **951.8 μs** | **65.07 μs** | **43.04 μs** |  **1.00** |    **0.06** | **1511.38 KB** |        **1.00** |
