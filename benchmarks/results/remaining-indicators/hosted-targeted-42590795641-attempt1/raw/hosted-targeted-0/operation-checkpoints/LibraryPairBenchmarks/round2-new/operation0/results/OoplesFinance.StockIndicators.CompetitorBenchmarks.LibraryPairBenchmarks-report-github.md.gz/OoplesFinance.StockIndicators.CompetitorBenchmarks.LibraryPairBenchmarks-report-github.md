```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean      | Error      | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |----------:|-----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAdl** | **117.12 μs** |   **1.916 μs** |  **1.140 μs** |  **1.00** |    **0.01** |  **158.97 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAdl |  80.93 μs |   9.895 μs |  6.545 μs |  0.69 |    0.05 |     273 KB |        1.72 |
|            |       |                |           |            |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAdl** | **949.59 μs** |  **49.430 μs** | **32.695 μs** |  **1.00** |    **0.05** | **1510.09 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAdl | 752.99 μs | 102.795 μs | 67.993 μs |  0.79 |    0.07 | 2653.52 KB |        1.76 |
