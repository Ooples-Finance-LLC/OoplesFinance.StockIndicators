```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error    | StdDev   | Gen0   | Gen1   | Allocated |
|------------------ |--------------- |------ |----------:|---------:|---------:|-------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |  **31.12 μs** | **0.525 μs** | **0.312 μs** | **0.9766** |      **-** |  **88.31 KB** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |  29.05 μs | 0.666 μs | 0.441 μs | 0.4883 |      - |   40.7 KB |
| **BuilderFull**       | **Skender.GetAdl** | **10000** | **294.03 μs** | **7.227 μs** | **4.780 μs** | **9.7656** | **3.9063** | **862.09 KB** |
| BuilderLatestOnly | Skender.GetAdl | 10000 | 271.30 μs | 3.979 μs | 2.081 μs | 3.9063 |      - | 392.28 KB |
