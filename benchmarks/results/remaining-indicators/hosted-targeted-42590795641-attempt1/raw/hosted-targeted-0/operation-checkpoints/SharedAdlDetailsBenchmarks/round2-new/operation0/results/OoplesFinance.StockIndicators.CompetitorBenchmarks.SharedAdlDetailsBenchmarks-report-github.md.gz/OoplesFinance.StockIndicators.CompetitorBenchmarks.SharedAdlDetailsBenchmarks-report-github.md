```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |    **31.40 μs** |  **0.722 μs** |  **0.429 μs** |  **0.57** |    **0.02** |  **0.9766** |       **-** |   **88.31 KB** |        **0.50** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |    29.28 μs |  0.411 μs |  0.244 μs |  0.53 |    0.01 |  0.4883 |       - |    40.7 KB |        0.23 |
| NativeSingle      | Skender.GetAdl | 1000  |    55.36 μs |  2.215 μs |  1.465 μs |  1.00 |    0.04 |  1.9531 |  0.4883 |  176.21 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 1000  |   138.93 μs | 14.165 μs |  9.369 μs |  2.51 |    0.17 |  3.9063 |       - |  449.41 KB |        2.55 |
|                   |                |       |             |           |           |       |         |         |         |            |             |
| **BuilderFull**       | **Skender.GetAdl** | **10000** |   **290.70 μs** |  **5.594 μs** |  **2.926 μs** |  **0.46** |    **0.01** |  **9.7656** |  **3.9063** |  **862.09 KB** |        **0.49** |
| BuilderLatestOnly | Skender.GetAdl | 10000 |   287.23 μs |  3.356 μs |  1.997 μs |  0.45 |    0.01 |  3.9063 |       - |  392.28 KB |        0.22 |
| NativeSingle      | Skender.GetAdl | 10000 |   636.26 μs | 16.973 μs | 11.227 μs |  1.00 |    0.02 | 19.5313 | 15.6250 | 1758.27 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 10000 | 1,248.56 μs | 76.670 μs | 50.713 μs |  1.96 |    0.08 | 54.6875 | 46.8750 | 4474.84 KB |        2.55 |
