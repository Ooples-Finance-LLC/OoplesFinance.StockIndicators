```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Gen0   | Gen1   | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|-------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |  **31.67 μs** |  **1.219 μs** |  **0.726 μs** | **0.9766** |      **-** |  **88.31 KB** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |  30.09 μs |  0.844 μs |  0.558 μs | 0.4883 |      - |   40.7 KB |
| **BuilderFull**       | **Skender.GetAdl** | **10000** | **300.13 μs** | **16.676 μs** | **11.030 μs** | **9.7656** | **3.9063** | **862.09 KB** |
| BuilderLatestOnly | Skender.GetAdl | 10000 | 275.12 μs |  9.688 μs |  6.408 μs | 3.9063 |      - | 392.27 KB |
