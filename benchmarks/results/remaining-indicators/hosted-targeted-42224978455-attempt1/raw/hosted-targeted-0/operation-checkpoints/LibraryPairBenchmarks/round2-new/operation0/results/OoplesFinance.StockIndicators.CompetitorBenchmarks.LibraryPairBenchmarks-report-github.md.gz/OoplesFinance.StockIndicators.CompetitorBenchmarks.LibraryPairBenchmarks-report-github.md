```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAdl** |   **159.82 μs** |  **3.856 μs** |  **2.551 μs** |  **1.00** |    **0.02** |  **159.01 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAdl |    73.77 μs | 11.588 μs |  6.896 μs |  0.46 |    0.04 |  271.69 KB |        1.71 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAdl** | **1,335.36 μs** | **22.147 μs** | **13.179 μs** |  **1.00** |    **0.01** | **1509.38 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAdl |   702.32 μs | 25.239 μs | 15.019 μs |  0.53 |    0.01 | 2652.54 KB |        1.76 |
