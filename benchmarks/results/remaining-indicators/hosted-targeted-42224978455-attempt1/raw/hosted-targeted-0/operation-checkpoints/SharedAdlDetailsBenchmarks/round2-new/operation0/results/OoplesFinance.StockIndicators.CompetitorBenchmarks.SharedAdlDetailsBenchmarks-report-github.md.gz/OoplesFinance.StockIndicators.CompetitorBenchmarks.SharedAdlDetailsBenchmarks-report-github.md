```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |    **32.82 μs** |  **1.246 μs** |  **0.742 μs** |  **0.55** |    **0.01** |   **5.3711** |   **0.9766** |   **88.31 KB** |        **0.50** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |    29.40 μs |  0.117 μs |  0.061 μs |  0.49 |    0.01 |   2.4414 |   0.2441 |    40.7 KB |        0.23 |
| NativeSingle      | Skender.GetAdl | 1000  |    59.71 μs |  1.531 μs |  1.012 μs |  1.00 |    0.02 |  10.7422 |   2.4414 |  176.21 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 1000  |   117.13 μs |  8.092 μs |  5.353 μs |  1.96 |    0.09 |  28.3203 |   9.7656 |   449.4 KB |        2.55 |
|                   |                |       |             |           |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetAdl** | **10000** |   **343.85 μs** | **10.834 μs** |  **7.166 μs** |  **0.52** |    **0.01** |  **50.7813** |  **17.5781** |  **862.12 KB** |        **0.49** |
| BuilderLatestOnly | Skender.GetAdl | 10000 |   283.79 μs |  5.575 μs |  3.318 μs |  0.43 |    0.01 |  23.4375 |   9.7656 |  392.28 KB |        0.22 |
| NativeSingle      | Skender.GetAdl | 10000 |   655.26 μs | 13.628 μs |  8.110 μs |  1.00 |    0.02 | 105.4688 |  66.4063 | 1758.27 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 10000 | 1,159.87 μs | 70.931 μs | 46.916 μs |  1.77 |    0.07 | 273.4375 | 195.3125 | 4474.84 KB |        2.55 |
