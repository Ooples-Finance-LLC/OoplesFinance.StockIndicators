```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |  **31.89 μs** | **0.944 μs** | **0.562 μs** |  **5.3711** |  **0.9766** |  **88.31 KB** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |  29.16 μs | 1.007 μs | 0.599 μs |  2.4414 |  0.2441 |   40.7 KB |
| **BuilderFull**       | **Skender.GetAdl** | **10000** | **297.78 μs** | **4.908 μs** | **2.567 μs** | **50.7813** | **17.5781** | **862.12 KB** |
| BuilderLatestOnly | Skender.GetAdl | 10000 | 277.40 μs | 2.194 μs | 1.147 μs | 23.4375 |  9.7656 | 392.29 KB |
