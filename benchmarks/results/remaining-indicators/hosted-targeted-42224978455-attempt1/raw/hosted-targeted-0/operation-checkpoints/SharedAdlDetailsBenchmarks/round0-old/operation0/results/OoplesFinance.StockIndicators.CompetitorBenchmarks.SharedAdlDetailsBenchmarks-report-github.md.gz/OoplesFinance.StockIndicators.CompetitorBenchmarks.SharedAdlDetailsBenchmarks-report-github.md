```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |  **31.64 μs** | **0.553 μs** | **0.365 μs** |  **5.3711** |  **0.9766** |  **88.27 KB** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |  29.08 μs | 0.221 μs | 0.115 μs |  2.4414 |  0.2441 |   40.7 KB |
| **BuilderFull**       | **Skender.GetAdl** | **10000** | **301.89 μs** | **4.826 μs** | **2.524 μs** | **50.7813** | **17.5781** | **862.08 KB** |
| BuilderLatestOnly | Skender.GetAdl | 10000 | 278.20 μs | 1.671 μs | 0.994 μs | 23.4375 |  9.7656 | 392.28 KB |
