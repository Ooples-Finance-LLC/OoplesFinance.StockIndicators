```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |    **97.85 μs** |   **4.643 μs** |   **2.763 μs** |  **2.60** |    **0.07** |        **-** |        **-** |        **-** |   **89.04 KB** |        **0.73** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |    88.57 μs |   0.480 μs |   0.286 μs |  2.36 |    0.02 |        - |        - |        - |   41.44 KB |        0.34 |
| NativeSingle      | Skender.GetTrix | 1000  |    37.59 μs |   0.431 μs |   0.285 μs |  1.00 |    0.01 |   1.4648 |   0.2441 |        - |  121.49 KB |        1.00 |
| NativeParallel    | Skender.GetTrix | 1000  |   135.00 μs |   3.023 μs |   1.581 μs |  3.59 |    0.05 |   3.9063 |   0.9766 |        - |  312.32 KB |        2.57 |
|                   |                 |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **1,006.32 μs** |  **18.501 μs** |   **9.676 μs** |  **1.77** |    **0.04** |   **7.8125** |        **-** |        **-** |  **862.87 KB** |        **0.71** |
| BuilderLatestOnly | Skender.GetTrix | 10000 |   946.09 μs |   8.632 μs |   5.137 μs |  1.66 |    0.03 |        - |        - |        - |  393.06 KB |        0.32 |
| NativeSingle      | Skender.GetTrix | 10000 |   569.99 μs |  17.158 μs |  11.349 μs |  1.00 |    0.03 |  97.6563 |  97.6563 |  97.6563 | 1212.12 KB |        1.00 |
| NativeParallel    | Skender.GetTrix | 10000 | 1,738.89 μs | 381.329 μs | 252.225 μs |  3.05 |    0.43 | 171.8750 | 171.8750 | 156.2500 | 3109.09 KB |        2.57 |
