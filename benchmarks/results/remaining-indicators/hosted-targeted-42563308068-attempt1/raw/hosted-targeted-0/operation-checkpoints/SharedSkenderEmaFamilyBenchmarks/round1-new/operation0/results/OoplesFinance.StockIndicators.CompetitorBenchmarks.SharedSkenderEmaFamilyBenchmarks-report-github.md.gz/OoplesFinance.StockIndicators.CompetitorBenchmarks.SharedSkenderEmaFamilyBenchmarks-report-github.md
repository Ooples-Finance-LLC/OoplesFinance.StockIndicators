```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error     | StdDev    | Gen0   | Allocated |
|------------------ |---------------- |------ |------------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |    **98.72 μs** |  **1.684 μs** |  **1.002 μs** |      **-** |  **89.08 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |    93.76 μs |  3.342 μs |  1.748 μs |      - |  41.44 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **1,126.53 μs** | **93.410 μs** | **55.587 μs** | **7.8125** | **862.86 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 |   980.26 μs | 27.637 μs | 16.446 μs |      - | 393.06 KB |
