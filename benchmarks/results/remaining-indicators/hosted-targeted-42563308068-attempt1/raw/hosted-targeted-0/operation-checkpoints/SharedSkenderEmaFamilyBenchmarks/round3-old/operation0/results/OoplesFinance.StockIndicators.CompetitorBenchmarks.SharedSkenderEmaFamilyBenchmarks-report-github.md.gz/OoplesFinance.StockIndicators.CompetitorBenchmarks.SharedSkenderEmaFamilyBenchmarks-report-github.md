```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error     | StdDev    | Gen0   | Allocated |
|------------------ |---------------- |------ |------------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |    **92.77 μs** |  **0.725 μs** |  **0.432 μs** |      **-** |  **89.04 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |    89.20 μs |  1.202 μs |  0.715 μs | 0.4883 |  41.43 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **1,000.93 μs** | **47.917 μs** | **28.514 μs** | **7.8125** | **862.88 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 |   939.82 μs | 16.020 μs | 10.596 μs |      - | 393.05 KB |
