```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error    | StdDev   | Gen0   | Allocated |
|------------------ |---------------- |------ |----------:|---------:|---------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |  **95.95 μs** | **1.506 μs** | **0.787 μs** |      **-** |  **89.04 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |  88.54 μs | 1.868 μs | 1.236 μs |      - |  41.44 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **991.75 μs** | **7.666 μs** | **4.010 μs** | **7.8125** | **862.88 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 923.33 μs | 8.450 μs | 5.028 μs |      - | 393.05 KB |
