```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId          | Mean        | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |------------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetTrix** |   **187.65 μs** | **24.31 μs** | **12.72 μs** |  **1.00** |    **0.09** |  **210.95 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetTrix |    72.59 μs | 25.76 μs | 17.04 μs |  0.39 |    0.09 |  202.99 KB |        0.96 |
|            |       |                 |             |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetTrix** | **1,559.70 μs** | **60.58 μs** | **40.07 μs** |  **1.00** |    **0.03** | **2073.27 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetTrix |   647.04 μs | 61.70 μs | 36.72 μs |  0.42 |    0.02 | 1950.38 KB |        0.94 |
