```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Trix** |   **199.82 μs** |  **6.592 μs** | **3.448 μs** |  **1.00** |    **0.02** |  **192.81 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Trix |    17.77 μs |  2.786 μs | 1.843 μs |  0.09 |    0.01 |    47.1 KB |        0.24 |
|            |       |                      |             |           |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Trix** | **1,936.39 μs** | **13.428 μs** | **7.991 μs** |  **1.00** |    **0.01** | **1897.59 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Trix |   133.98 μs | 16.679 μs | 9.925 μs |  0.07 |    0.00 |  408.48 KB |        0.22 |
