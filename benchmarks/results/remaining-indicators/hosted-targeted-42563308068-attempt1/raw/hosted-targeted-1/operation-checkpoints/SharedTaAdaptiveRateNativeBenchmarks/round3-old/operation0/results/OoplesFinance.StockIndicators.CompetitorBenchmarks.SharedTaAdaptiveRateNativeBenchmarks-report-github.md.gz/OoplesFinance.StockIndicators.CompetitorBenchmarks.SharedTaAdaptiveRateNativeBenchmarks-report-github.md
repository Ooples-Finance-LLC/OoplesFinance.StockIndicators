```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **114.9 μs** |  **1.60 μs** |  **0.84 μs** |  **3.9063** |       **-** |  **89.04 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   113.6 μs |  1.07 μs |  0.56 μs |  1.9531 |       - |  41.44 KB |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **1,179.2 μs** | **18.05 μs** | **11.94 μs** | **46.8750** | **15.6250** | **862.89 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 1,163.8 μs |  9.20 μs |  5.47 μs | 23.4375 |  7.8125 | 393.01 KB |
