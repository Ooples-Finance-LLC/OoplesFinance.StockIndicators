```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **119.54 μs** |  **1.693 μs** |  **1.008 μs** | **10.78** |    **0.09** |  **3.9063** |       **-** |  **89.04 KB** |        **5.75** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   114.07 μs |  1.712 μs |  1.019 μs | 10.29 |    0.09 |  1.9531 |       - |  41.44 KB |        2.68 |
| NativeSingle      | TaLib.Functions.Trix | 1000  |    11.08 μs |  0.070 μs |  0.042 μs |  1.00 |    0.01 |  0.9155 |       - |  15.48 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Trix | 1000  |   100.73 μs |  2.040 μs |  1.214 μs |  9.09 |    0.11 |  2.9297 |       - |  47.61 KB |        3.07 |
|                   |                      |       |             |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **1,226.03 μs** | **42.629 μs** | **28.196 μs** | **10.90** |    **0.24** | **46.8750** | **15.6250** |  **862.9 KB** |        **5.53** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 1,183.79 μs | 15.298 μs |  9.104 μs | 10.53 |    0.08 | 23.4375 |  7.8125 | 393.07 KB |        2.52 |
| NativeSingle      | TaLib.Functions.Trix | 10000 |   112.43 μs |  0.572 μs |  0.340 μs |  1.00 |    0.00 |  8.7891 |  0.9766 | 156.12 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Trix | 10000 |   234.33 μs | 12.478 μs |  8.253 μs |  2.08 |    0.07 | 29.2969 |  9.7656 | 469.49 KB |        3.01 |
