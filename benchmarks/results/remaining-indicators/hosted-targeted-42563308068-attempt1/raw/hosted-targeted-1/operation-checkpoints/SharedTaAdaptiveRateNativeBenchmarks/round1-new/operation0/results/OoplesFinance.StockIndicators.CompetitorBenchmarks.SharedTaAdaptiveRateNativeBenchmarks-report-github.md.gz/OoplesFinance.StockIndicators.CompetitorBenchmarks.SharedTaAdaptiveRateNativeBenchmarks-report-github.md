```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **119.1 μs** |  **0.79 μs** | **0.47 μs** |  **3.9063** |       **-** |  **89.04 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   117.6 μs |  2.64 μs | 1.57 μs |  1.9531 |       - |  41.44 KB |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **1,214.5 μs** | **12.11 μs** | **7.21 μs** | **46.8750** | **15.6250** |  **862.9 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 1,203.3 μs |  8.09 μs | 4.23 μs | 23.4375 |  7.8125 | 393.07 KB |
