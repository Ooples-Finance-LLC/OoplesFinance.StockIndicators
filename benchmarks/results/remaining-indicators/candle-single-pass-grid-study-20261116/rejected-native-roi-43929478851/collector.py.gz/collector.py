"""Collect a frozen completed ROI diagnostic; never qualify source or import a report."""
import argparse
from collections import Counter
from fractions import Fraction
import hashlib
import importlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import zipfile

REMOTE = 'Ooples-Finance-LLC/OoplesFinance.StockIndicators'
ARCHIVES = Path(r'Z:\StockIndicators-Archives\hosted-runs-20261116')
RESERVED = {'CON', 'PRN', 'AUX', 'NUL', 'CONIN$', 'CONOUT$',
            *(f'COM{i}' for i in range(1, 10)), *(f'LPT{i}' for i in range(1, 10)),
            *(prefix + digit for prefix in ('COM', 'LPT') for digit in ('\u00b9', '\u00b2', '\u00b3'))}


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, value):
    Path(path).write_bytes((json.dumps(value, indent=2, allow_nan=False) + '\n').encode())


def safe_parts(name):
    assert name and '\\' not in name and '\0' not in name, 'Invalid ZIP path'
    path = PurePosixPath(name)
    assert not path.is_absolute() and all(part not in ('', '.', '..') for part in name.rstrip('/').split('/'))
    for part in path.parts:
        assert not any(character in part for character in ':<>"|?*') and part.rstrip(' .') == part, 'Windows path alias/stream'
        assert part.split('.')[0].rstrip(' ').upper() not in RESERVED, 'Windows reserved path'
    return path.parts


def extract_selected(archive, out, prefix):
    """Keep timing shards, merged summary and small input provenance; skip runtimes."""
    prefix_parts = safe_parts(prefix)
    assert len(prefix_parts) == 1, 'Diagnostic prefix must be one artifact-root folder'
    selected = []
    seen = set()
    with zipfile.ZipFile(archive) as package:
        for info in package.infolist():
            parts = safe_parts(info.filename)
            assert not stat.S_ISLNK(info.external_attr >> 16), 'ZIP symlink'
            if info.is_dir():
                continue
            # Runtime-old/new directories are siblings of shard directories.
            timing = (len(parts) >= 4 and parts[:2] == (prefix, 'evidence')
                      and re.fullmatch(r'shard\d+', parts[2]) is not None
                      and Path(parts[-1]).suffix.lower() in
                          {'.json', '.log', '.txt', '.csv', '.md', '.html', '.xml', '.trx'})
            summary = parts == (prefix, 'summary.json')
            provenance = len(parts) == 2 and parts[1] == 'provenance.json'
            if not (timing or summary or provenance):
                continue
            key = '/'.join(parts).casefold()
            assert key not in seen, 'Duplicate/case-aliased selected ZIP member'
            seen.add(key)
            target = out.joinpath(*parts).resolve()
            assert target.is_relative_to(out.resolve())
            target.parent.mkdir(parents=True, exist_ok=True)
            with package.open(info) as source, target.open('xb') as destination:
                while chunk := source.read(1024 * 1024):
                    destination.write(chunk)
            selected.append(dict(path='/'.join(parts), bytes=info.file_size, sha256=digest(target)))
    assert (out / prefix / 'summary.json').is_file(), 'Missing completed CI summary'
    assert list((out / prefix / 'evidence').glob('shard*/provenance.json')), 'Missing timing provenance'
    return selected


def checked_sample(value):
    for key in ('mean_ns', 'lower_ns', 'upper_ns'):
        assert math.isfinite(value[key])
    assert value['mean_ns'] > 0 and value['lower_ns'] <= value['mean_ns'] <= value['upper_ns']
    return value


def analyze_native_gate(measurements, decisions, *, sentinels, required_crossovers,
                        expected_cases, expected_decisions):
    """The only native control is round 2; both candidate rounds must beat it."""
    assert required_crossovers >= 1
    pairs = {pair for pair, bars in measurements}
    assert set(measurements) == {(pair, bars) for pair in pairs for bars in (1000, 10000)}
    assert set(sentinels) <= pairs
    decision_map = {}
    for decision in decisions:
        assert decision['fixture'] == 'LibraryPairBenchmarks' and decision['method'] == 'Ooples'
        key = decision['pair'], decision['bars']
        assert key not in decision_map
        assert decision['verdict'] in ('faster', 'slower', 'inconclusive')
        decision_map[key] = decision
    assert set(decision_map) == set(measurements)
    assert len(decisions) == expected_decisions
    actual_cases = 0
    rows = []
    for (pair, bars), rounds in sorted(measurements.items()):
        assert set(rounds) == {0, 1, 2, 3}
        for index, methods in rounds.items():
            assert set(methods) == ({'Ooples', 'Competitor'} if index == 2 else {'Ooples'})
            actual_cases += len(methods)
        old = [checked_sample(rounds[index]['Ooples']) for index in (0, 3)]
        new = [checked_sample(rounds[index]['Ooples']) for index in (1, 2)]
        native = checked_sample(rounds[2]['Competitor'])
        old_wins = [value['mean_ns'] < native['mean_ns'] for value in old]
        baseline = ('wins_both_old_rounds' if all(old_wins) else
                    'mixed_old_rounds_uncertain' if any(old_wins) else 'nonwinning_both_old_rounds')
        candidate_rounds = [dict(index=index, sample=value,
            point_win=value['mean_ns'] < native['mean_ns'],
            intervals_separated=value['upper_ns'] < native['lower_ns'],
            mean_margin_fraction=(native['mean_ns'] - value['mean_ns']) / native['mean_ns'],
            minimum_ten_percent_margin=Fraction(value['mean_ns']) * 10 <= Fraction(native['mean_ns']) * 9)
            for index, value in zip((1, 2), new)]
        both_win = all(row['intervals_separated'] and row['minimum_ten_percent_margin']
                       for row in candidate_rounds)
        decision = decision_map[pair, bars]
        rows.append(dict(pair=pair, bars=bars, is_sentinel=pair in sentinels,
            baseline_classification=baseline, old_rounds=[dict(index=index, sample=value)
                for index, value in zip((0, 3), old)],
            native_round=2, native=native, candidate_rounds=candidate_rounds,
            both_candidates_clear_native_gate=both_win,
            strongest_new_10k_crossover=(bars == 10000 and pair not in sentinels and both_win
                and baseline == 'nonwinning_both_old_rounds'),
            source_decision=decision))
    assert actual_cases == expected_cases, 'All measured cases must be represented'
    slower = [decision for decision in decisions if decision['verdict'] == 'slower']
    crossovers = [row['pair'] for row in rows if row['strongest_new_10k_crossover']]
    return dict(diagnostic_only=True, qualification=False, accepted=False,
        source_imported=False, report_imported=False, policy_changed=False,
        case_count=actual_cases, decision_count=len(decisions),
        native_control_round=2, required_new_10k_crossovers=required_crossovers,
        strongest_new_10k_crossovers=crossovers,
        native_gate_met=len(crossovers) >= required_crossovers and not slower,
        source_slower_decisions=slower,
        sentinel_decisions=[decision for decision in decisions if decision['pair'] in sentinels],
        baseline_classification_counts=dict(Counter(row['baseline_classification'] for row in rows)),
        rows=rows,
        limits='Diagnostic launch gate only. Mixed/baseline-winning rows are not new crossovers. '
               'Native was measured only in round2. Every raw CI and retained sample remains in evidence. '
               'This cannot qualify, publish or import production source.')


def read_measurements(folder, plan, timing, verify, checkpoints, run, attempt, head):
    measurements = {}
    for root in sorted(folder.glob('shard*')):
        if not root.is_dir() or re.fullmatch(r'shard\d+', root.name) is None:
            continue
        proof = timing.read(root / 'provenance.json')
        assert str(proof['host']['run_id']) == run
        assert str(proof['host']['run_attempt']) == str(attempt)
        assert proof['input_provenance']['workflow_head'] == head
        state = timing.read(root / 'status.json')
        tasks = {task['fixture']: task for task in timing.phase_tasks(plan, 'diagnostic', proof['shard'])}
        assert set(tasks) == {'LibraryPairBenchmarks'}, 'Native ROI supports batch-only diagnostics'
        task = tasks['LibraryPairBenchmarks']
        mapping = {operation['raw']: operation['pair'] for operation in task['operations']}
        implicit = next(iter(mapping)) if task.get('implicit_pair') else None
        for record in state['rounds']:
            assert record['fixture'] == 'LibraryPairBenchmarks'
            index = record['index']
            report = timing.read(verify.archived(root, proof['raw_root'], record['report']))
            for case in report['Benchmarks']:
                raw, bars, method = checkpoints.case_key(case, implicit)
                pair = mapping[raw]
                values = measurements.setdefault((pair, bars), {}).setdefault(index, {})
                assert method not in values, 'Duplicate raw case'
                value = verify.sample(case)
                value.update(confidence_interval=dict(case['Statistics']['ConfidenceInterval']),
                             original_values_ns=list(case['Statistics']['OriginalValues']))
                values[method] = value
    return measurements


def verify_tooling(repo, head, plan, module):
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == head
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo), 'Tooling must be frozen and clean'
    for path in (plan, repo / 'scripts/hosted_timing' / (module + '.py')):
        relative = path.relative_to(repo).as_posix()
        committed = subprocess.check_output(['git', 'show', head + ':' + relative], cwd=repo)
        assert path.read_bytes().replace(b'\r\n', b'\n') == committed.replace(b'\r\n', b'\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('run', 'tooling-head', 'artifact', 'diagnostic-prefix', 'module'):
        parser.add_argument('--' + name, required=True)
    for name in ('tooling-repo', 'plan', 'out'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--sentinel', action='append', default=[])
    parser.add_argument('--required-crossovers', type=int, required=True)
    args = parser.parse_args()
    assert re.fullmatch(r'\d+', args.run) and re.fullmatch(r'[a-f0-9]{40}', args.tooling_head)
    assert re.fullmatch(r'[A-Za-z0-9_.-]+', args.artifact)
    assert re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*', args.module)
    assert args.required_crossovers >= 1 and len(args.sentinel) == len(set(args.sentinel))
    safe_parts(args.diagnostic_prefix)
    repo = args.tooling_repo.resolve()
    plan_path = (repo / args.plan).resolve()
    assert plan_path.is_relative_to(repo / 'benchmarks/plans') and plan_path.suffix == '.json'
    out = args.out.resolve()
    ops = Path(__file__).resolve().parent
    assert out != ops and out.is_relative_to(ops) and not out.exists(), 'Use a fresh stable OPS output directory'
    verify_tooling(repo, args.tooling_head, plan_path, args.module)

    def api(endpoint):
        return json.loads(subprocess.check_output(['gh', 'api', endpoint]))

    run = api(f'repos/{REMOTE}/actions/runs/{args.run}')
    assert run['id'] == int(args.run) and run['head_sha'] == args.tooling_head
    assert run['status'] == 'completed' and run['conclusion'] == 'success', 'Never consume running/failed/partial evidence'
    items = []
    page = 1
    while True:
        result = api(f'repos/{REMOTE}/actions/runs/{args.run}/artifacts?per_page=100&page={page}')
        items.extend(result['artifacts'])
        if len(items) >= result['total_count']:
            break
        assert result['artifacts'], 'Incomplete artifact inventory'
        page += 1
    matches = [item for item in items if item['name'] == args.artifact and not item['expired']]
    assert len(matches) == 1
    artifact = matches[0]
    assert ARCHIVES.parent.is_dir(), 'Z archive volume must be reachable; do not duplicate bulky ZIP on C'
    archive_root = (ARCHIVES / args.run).resolve()
    assert archive_root.is_relative_to(ARCHIVES.resolve())
    archive_root.mkdir(parents=True, exist_ok=True)
    archive = archive_root / f"{args.artifact}-attempt{run['run_attempt']}-artifact{artifact['id']}.zip"
    assert not archive.exists(), 'Artifact already retained; inspect existing receipt before another collection'
    temporary = archive.with_suffix('.zip.download')
    with temporary.open('xb') as stream:
        subprocess.run(['gh', 'api', f"repos/{REMOTE}/actions/artifacts/{artifact['id']}/zip"], stdout=stream, check=True)
    temporary.replace(archive)
    assert archive.stat().st_size > 0
    receipt = dict(run_id=args.run, run_attempt=run['run_attempt'], tooling_head=args.tooling_head,
        artifact=artifact, archive=str(archive), archive_sha256=digest(archive),
        collector_sha256=digest(Path(__file__)), plan=str(plan_path.relative_to(repo)),
        plan_sha256=digest(plan_path), module=args.module, remote_run=run)
    write(archive.with_suffix('.receipt.json'), receipt)
    out.mkdir()
    selected = extract_selected(archive, out, args.diagnostic_prefix)

    os.environ['HOSTED_TIMING_PLAN'] = plan_path.relative_to(repo).as_posix()
    sys.path.insert(0, str(repo / 'scripts'))
    timing = importlib.import_module('hosted_timing.pipeline')
    verify = importlib.import_module('hosted_timing.verify')
    checkpoints = importlib.import_module('hosted_timing.checkpoints')
    roi = importlib.import_module('hosted_timing.' + args.module)
    assert timing.REPO.resolve() == repo and timing.PLAN.resolve() == plan_path
    plan = timing.read(plan_path)
    roi.validate_scope(plan)
    folder = out / args.diagnostic_prefix
    local = roi.collect(folder / 'evidence')
    hosted = timing.read(folder / 'summary.json')
    assert local == hosted, 'Independent frozen collector differs from CI summary'
    assert local['diagnostic_only'] and not local['accepted'] and not local['qualification']
    assert (local['case_count'], local['decision_count']) == (plan['cases'], plan['decisions'])
    measurements = read_measurements(folder / 'evidence', plan, timing, verify, checkpoints,
        args.run, run['run_attempt'], args.tooling_head)
    sentinels = set(args.sentinel)
    approval = timing.read(repo / plan['roi_approval']['path'])
    if 'initial_prototype_pairs' in approval:
        pairs = {pair for pair, bars in measurements}
        assert sentinels == pairs - set(approval['initial_prototype_pairs']), 'Explicitly identify every approved sentinel'
    analysis = analyze_native_gate(measurements, local['decisions'], sentinels=sentinels,
        required_crossovers=args.required_crossovers, expected_cases=local['case_count'],
        expected_decisions=local['decision_count'])
    verify_tooling(repo, args.tooling_head, plan_path, args.module)
    write(out / 'locally-verified-diagnostic.json', local)
    write(out / 'native-gate-analysis.json', analysis)
    receipt.update(local_hosted_collection_equal=True, selected_files=selected,
        diagnostic_only=True, qualification=False, native_gate_analysis_sha256=digest(out / 'native-gate-analysis.json'))
    write(out / 'collection-receipt.json', receipt)
    print(json.dumps(dict(run=args.run, cases=analysis['case_count'], decisions=analysis['decision_count'],
        new_10k_crossovers=analysis['strongest_new_10k_crossovers'],
        source_slower=len(analysis['source_slower_decisions']), native_gate_met=analysis['native_gate_met'],
        analysis=str(out / 'native-gate-analysis.json')), indent=2))


if __name__ == '__main__':
    main()
