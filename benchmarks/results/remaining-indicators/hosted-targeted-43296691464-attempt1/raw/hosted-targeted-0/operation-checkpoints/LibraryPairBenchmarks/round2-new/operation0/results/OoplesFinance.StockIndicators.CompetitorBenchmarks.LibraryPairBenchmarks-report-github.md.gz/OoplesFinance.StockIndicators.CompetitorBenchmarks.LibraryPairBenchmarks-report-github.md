```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)inOsc [21]** |   **590.4 μs** | **203.07 μs** | **134.32 μs** |  **1.05** |    **0.34** |  **259.73 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)inOsc [21] |   114.5 μs |  14.25 μs |   8.48 μs |  0.20 |    0.05 |  494.86 KB |        1.91 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)inOsc [21]** | **3,763.1 μs** |  **48.97 μs** |  **32.39 μs** |  **1.00** |    **0.01** | **2553.09 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)inOsc [21] | 1,170.6 μs |  67.91 μs |  44.92 μs |  0.31 |    0.01 | 4854.19 KB |        1.90 |
