```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error       | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|------------:|----------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **330.5 μs** |     **5.50 μs** |   **3.28 μs** |       **-** |  **97.03 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   321.9 μs |     1.89 μs |   1.12 μs |  1.9531 |  49.42 KB |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **4,236.4 μs** | **1,287.36 μs** | **851.51 μs** | **31.2500** | **941.38 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 3,376.2 μs |    77.26 μs |  40.41 μs |       - | 471.53 KB |
