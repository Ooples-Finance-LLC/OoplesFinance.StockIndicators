```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **295.79 μs** |  **3.196 μs** |  **1.672 μs** |  **3.03** |    **0.05** |        **-** |        **-** |       **-** |   **97.09 KB** |        **0.26** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   284.60 μs |  4.891 μs |  2.911 μs |  2.92 |    0.05 |   1.9531 |        - |       - |   49.49 KB |        0.13 |
| NativeSingle      | Skend(...)inOsc [21] | 1000  |    97.64 μs |  2.796 μs |  1.664 μs |  1.00 |    0.02 |  22.4609 |   5.8594 |       - |  379.71 KB |        1.00 |
| NativeParallel    | Skend(...)inOsc [21] | 1000  |   231.63 μs | 20.443 μs | 13.521 μs |  2.37 |    0.14 |  58.5938 |  19.5313 |       - |  958.69 KB |        2.52 |
|                   |                      |       |             |           |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **2,874.43 μs** | **15.515 μs** |  **9.233 μs** |  **2.19** |    **0.04** |  **46.8750** |  **15.6250** |       **-** |  **941.32 KB** |        **0.25** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 2,808.75 μs | 14.888 μs |  8.860 μs |  2.14 |    0.04 |  15.6250 |        - |       - |  471.48 KB |        0.12 |
| NativeSingle      | Skend(...)inOsc [21] | 10000 | 1,314.61 μs | 38.861 μs | 25.704 μs |  1.00 |    0.03 | 242.1875 | 148.4375 | 46.8750 | 3790.28 KB |        1.00 |
| NativeParallel    | Skend(...)inOsc [21] | 10000 | 2,861.72 μs | 77.263 μs | 51.105 μs |  2.18 |    0.05 | 593.7500 | 515.6250 | 78.1250 | 9555.11 KB |        2.52 |
