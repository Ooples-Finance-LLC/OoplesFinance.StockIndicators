```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **306.8 μs** |  **1.81 μs** |  **0.95 μs** |       **-** |       **-** |  **97.09 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   285.9 μs |  1.84 μs |  0.96 μs |  1.9531 |       - |  49.49 KB |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **2,963.4 μs** | **19.02 μs** | **11.32 μs** | **46.8750** | **15.6250** | **941.31 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 2,859.5 μs | 31.54 μs | 18.77 μs | 15.6250 |       - | 471.48 KB |
