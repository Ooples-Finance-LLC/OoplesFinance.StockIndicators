```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **331.0 μs** |  **4.21 μs** |  **2.51 μs** |       **-** |  **97.03 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   334.4 μs |  3.32 μs |  1.74 μs |       - |  49.44 KB |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **3,380.9 μs** | **32.55 μs** | **19.37 μs** | **31.2500** | **941.38 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 3,322.6 μs | 36.52 μs | 24.15 μs |       - | 471.55 KB |
