```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean         | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-------------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)AdOsc [21]** |   **460.710 μs** |  **45.6531 μs** |  **30.1967 μs** |  **1.00** |    **0.09** |  **209.14 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)AdOsc [21] |     8.767 μs |   0.7468 μs |   0.4444 μs |  0.02 |    0.00 |   37.91 KB |        0.18 |
|            |       |                      |              |             |             |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)AdOsc [21]** | **4,113.967 μs** | **319.4805 μs** | **190.1177 μs** |  **1.00** |    **0.06** | **2054.21 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)AdOsc [21] |    88.700 μs |  21.7420 μs |  14.3810 μs |  0.02 |    0.00 |  330.58 KB |        0.16 |
