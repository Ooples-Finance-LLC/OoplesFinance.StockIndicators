```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **272.3 μs** |  **3.59 μs** |  **2.14 μs** |       **-** |  **73.62 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   266.7 μs |  1.48 μs |  0.78 μs |       - |  25.98 KB |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **2,686.9 μs** | **55.12 μs** | **36.46 μs** | **31.2500** | **706.86 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 2,639.6 μs | 79.04 μs | 47.04 μs |       - | 237.03 KB |
