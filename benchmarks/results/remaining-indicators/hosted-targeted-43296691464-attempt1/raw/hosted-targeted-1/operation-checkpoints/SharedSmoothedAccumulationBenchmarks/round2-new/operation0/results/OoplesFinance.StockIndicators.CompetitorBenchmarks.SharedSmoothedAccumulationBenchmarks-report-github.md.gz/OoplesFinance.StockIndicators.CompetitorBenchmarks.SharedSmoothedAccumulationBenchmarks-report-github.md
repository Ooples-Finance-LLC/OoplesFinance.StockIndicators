```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **276.712 μs** | **15.3208 μs** | **8.0131 μs** | **89.13** |    **2.70** |       **-** |      **-** |  **73.58 KB** |        **9.43** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   264.734 μs |  1.3976 μs | 0.9245 μs | 85.27 |    1.16 |       - |      - |  25.98 KB |        3.33 |
| NativeSingle      | TaLib(...)AdOsc [21] | 1000  |     3.105 μs |  0.0731 μs | 0.0435 μs |  1.00 |    0.02 |  0.4578 |      - |    7.8 KB |        1.00 |
| NativeParallel    | TaLib(...)AdOsc [21] | 1000  |    90.630 μs |  2.3000 μs | 1.5213 μs | 29.19 |    0.60 |  1.4648 |      - |  27.57 KB |        3.53 |
|                   |                      |       |              |            |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **2,753.718 μs** |  **7.7083 μs** | **4.0316 μs** | **90.51** |    **1.29** | **31.2500** |      **-** | **706.86 KB** |        **9.05** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 2,618.189 μs | 11.8494 μs | 6.1975 μs | 86.06 |    1.23 |       - |      - | 237.03 KB |        3.03 |
| NativeSingle      | TaLib(...)AdOsc [21] | 10000 |    30.431 μs |  0.6868 μs | 0.4543 μs |  1.00 |    0.02 |  4.6387 |      - |  78.12 KB |        1.00 |
| NativeParallel    | TaLib(...)AdOsc [21] | 10000 |   130.887 μs |  2.9359 μs | 1.5355 μs |  4.30 |    0.08 | 17.5781 | 3.9063 | 273.66 KB |        3.50 |
