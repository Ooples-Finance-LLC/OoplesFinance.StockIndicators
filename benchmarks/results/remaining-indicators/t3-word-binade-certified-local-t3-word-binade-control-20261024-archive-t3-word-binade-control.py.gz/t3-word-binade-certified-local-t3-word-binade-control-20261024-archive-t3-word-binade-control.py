from pathlib import Path
import sys
import gzip,hashlib,json
ROOT=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
name='t3-word-binade'
RUN=f'local-{name}-control-20261024'
RAW=ROOT/RUN
REPO=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
OUT=REPO/'benchmarks/results/remaining-indicators'/RUN
summary=json.loads((RAW/'verified-summary.json').read_text(encoding='utf-8'))
count=144
assert summary[f'all_{count}_cases_verified']
proof=json.loads((RAW/'provenance.json').read_text(encoding='utf-8'))
accepted=not any(r['verdict']=='slower' for r in summary['decisions']) and any(r['verdict']=='faster' for r in summary['decisions'])
state=json.loads((RAW/'status.json').read_text(encoding='utf-8'))
paths=['status.json','provenance.json','binary-manifest.json','verified-summary.json']
paths += [Path(r['report']).relative_to(RAW).as_posix() for r in state['rounds']]
paths += [p.name for p in RAW.glob('*.log')]
paths += [p.relative_to(RAW).as_posix() for p in (RAW/'invalidated-attempts').rglob('*') if p.is_file()]
OUT.mkdir(exist_ok=True)
manifest={}
for relative in paths:
 data=(RAW/relative).read_bytes();target=OUT/(relative+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(gzip.compress(data,mtime=0));manifest[relative]={'sha256':hashlib.sha256(data).hexdigest(),'archive':target.relative_to(REPO).as_posix()}
scripts={}
for script in [f'measure-{name}-control.py',f'verify-{name}-control.py']:
 data=(ROOT/script).read_bytes();(OUT/(script+'.gz')).write_bytes(gzip.compress(data,mtime=0));scripts[script]=hashlib.sha256(data).hexdigest()
(OUT/'decision.json').write_text(json.dumps({'status':'candidate-qualified-for-integration' if accepted else 'candidate-rejected-or-inconclusive','sources':summary['sources'],'candidate_code_source':proof['candidate_code_source'],'measurement_location':'Local Windows; preserved source-qualified binaries; only production DLL differs','decisions':summary['decisions'],'archives':manifest,'scripts':scripts,'report_imported':False,'production_integrated':False},indent=2)+'\n',encoding='utf-8',newline='\n')
(OUT/'.gitattributes').write_bytes(b'* -text\n')
print('Archived',count,'cases; qualified for integration:',accepted)


diagnostic_hashes={'draft-t3-word-binade-20261024.py': '414a77de7a32a8877922001044013ae72604efd6e75bd45e7f5596e3d6b1b74f', 't3-word-binade-draft-20261024/arithmetic-source-proof.json': 'e2c83a2e49405cb93f050ddb903b847f7424d50851997bdc74d84378b3b54d91', 't3-word-qualified-profile-20261024/status.json': 'd2142b0859ff67b4ae70980ae2c00ce985f328ac8c8ba2a544ae6e5ac9c3d185', 't3-word-qualified-profile-20261024/ready.json': '694e185fe4bbad6a00498f381f80682f0282a21032560202f5f085510d0cb35e', 't3-word-qualified-profile-20261024/completed.json': 'dcd65f05fed4cb2bf517cb6d80cf23ef595bd8acc57f6c00c0694e0811082f5a', 't3-word-qualified-profile-20261024/profile-summary.json': '0591a9397fac9e2cd93ca2eb28c9b5be3c7170af35e019006082f1bf108e14cc', 't3-word-qualified-profile-20261024/t3.speedscope.json': '70a6661a79abe060711cf52357ac227f9e033e6d6650a5bf7325e31e4d4fead3', 't3-word-qualified-profile-20261024/worker.ps1': 'f7f91d8295b7b6851666f2ee3f529eaadec8e23829d328d5305da8eb6c7101bf'}
diagnostics={}
for relative,sha in diagnostic_hashes.items():
 data=(ROOT/relative).read_bytes();assert hashlib.sha256(data).hexdigest()==sha
 target=OUT/'diagnostic'/(relative+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(gzip.compress(data,mtime=0));diagnostics[relative]={'sha256':sha,'archive':target.relative_to(REPO).as_posix()}
decision=json.loads((OUT/'decision.json').read_text())
decision['diagnostic_and_arithmetic_proof']={'note':'Profile from the qualified published word-smoothing source before the polynomial trial; concurrent compilation; sampled-thread attribution only, not timing qualification. Arithmetic proof checks unchanged extracted core text.','archives':diagnostics}
(OUT/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
