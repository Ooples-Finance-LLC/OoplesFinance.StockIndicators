```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetKvo** |   **535.21 μs** | **13.249 μs** |  **7.884 μs** |  **1.00** |    **0.02** |  **162.97 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetKvo |    42.34 μs |  2.946 μs |  1.541 μs |  0.08 |    0.00 |  265.34 KB |        1.63 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetKvo** | **5,321.04 μs** | **50.791 μs** | **26.564 μs** |  **1.00** |    **0.01** | **1587.13 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetKvo |   475.88 μs | 28.396 μs | 18.782 μs |  0.09 |    0.00 | 2638.39 KB |        1.66 |
