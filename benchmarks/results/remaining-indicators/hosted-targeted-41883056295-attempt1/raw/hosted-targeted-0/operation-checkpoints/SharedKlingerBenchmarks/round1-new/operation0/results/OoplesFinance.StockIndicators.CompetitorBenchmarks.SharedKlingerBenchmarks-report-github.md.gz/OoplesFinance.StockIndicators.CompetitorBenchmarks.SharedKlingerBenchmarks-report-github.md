```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetKvo** | **1000**  |   **460.2 μs** |  **12.75 μs** |   **8.43 μs** |  **3.9063** |  **81.23 KB** |
| BuilderLatestOnly | Skender.GetKvo | 1000  |   460.2 μs |  15.18 μs |  10.04 μs |       - |  33.62 KB |
| **BuilderFull**       | **Skender.GetKvo** | **10000** | **4,609.0 μs** |  **97.53 μs** |  **64.51 μs** | **31.2500** | **784.82 KB** |
| BuilderLatestOnly | Skender.GetKvo | 10000 | 4,674.9 μs | 167.51 μs | 110.80 μs |       - | 315.01 KB |
