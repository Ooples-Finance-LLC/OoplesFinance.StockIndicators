```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetKvo** | **1000**  |   **466.64 μs** |   **8.314 μs** |  **4.348 μs** | **13.94** |    **0.41** |        **-** |        **-** |   **81.24 KB** |        **0.39** |
| BuilderLatestOnly | Skender.GetKvo | 1000  |   468.04 μs |   4.741 μs |  2.821 μs | 13.98 |    0.40 |        - |        - |   33.63 KB |        0.16 |
| NativeSingle      | Skender.GetKvo | 1000  |    33.50 μs |   1.541 μs |  1.019 μs |  1.00 |    0.04 |  12.6953 |   3.9063 |  207.63 KB |        1.00 |
| NativeParallel    | Skender.GetKvo | 1000  |    72.64 μs |   3.091 μs |  1.839 μs |  2.17 |    0.08 |  33.2031 |  11.7188 |  528.18 KB |        2.54 |
|                   |                |       |             |            |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetKvo** | **10000** | **4,821.83 μs** | **117.353 μs** | **77.622 μs** | **12.50** |    **0.22** |  **31.2500** |        **-** |  **784.85 KB** |        **0.38** |
| BuilderLatestOnly | Skender.GetKvo | 10000 | 4,621.02 μs |  31.870 μs | 16.668 μs | 11.98 |    0.10 |        - |        - |  315.05 KB |        0.15 |
| NativeSingle      | Skender.GetKvo | 10000 |   385.87 μs |   6.195 μs |  3.240 μs |  1.00 |    0.01 | 125.0000 |  80.0781 | 2070.92 KB |        1.00 |
| NativeParallel    | Skender.GetKvo | 10000 |   724.24 μs |  25.894 μs | 15.409 μs |  1.88 |    0.04 | 324.2188 | 265.6250 | 5256.72 KB |        2.54 |
