```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetKvo** | **1000**  |   **497.9 μs** |  **13.87 μs** |   **9.18 μs** |  **3.9063** |  **81.18 KB** |
| BuilderLatestOnly | Skender.GetKvo | 1000  |   493.6 μs |  13.45 μs |   8.00 μs |       - |  33.61 KB |
| **BuilderFull**       | **Skender.GetKvo** | **10000** | **5,117.5 μs** | **183.18 μs** | **121.16 μs** | **31.2500** | **784.81 KB** |
| BuilderLatestOnly | Skender.GetKvo | 10000 | 5,057.1 μs |  80.28 μs |  47.78 μs |       - | 315.01 KB |
