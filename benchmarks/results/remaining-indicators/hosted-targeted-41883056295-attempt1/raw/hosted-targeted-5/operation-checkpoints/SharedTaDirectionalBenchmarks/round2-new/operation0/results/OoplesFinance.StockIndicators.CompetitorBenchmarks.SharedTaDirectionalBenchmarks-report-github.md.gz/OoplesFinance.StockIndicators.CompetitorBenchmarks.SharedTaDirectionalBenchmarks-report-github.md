```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **141.40 μs** |  **0.566 μs** |  **0.337 μs** | **13.84** |    **0.09** |  **3.9063** |      **-** |  **65.01 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   139.67 μs |  1.546 μs |  0.809 μs | 13.67 |    0.11 |  0.9766 |      - |  17.41 KB |        2.26 |
| NativeSingle      | TaLib(...)nusDM [23] | 1000  |    10.22 μs |  0.096 μs |  0.063 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 1000  |    14.18 μs |  0.563 μs |  0.373 μs |  1.39 |    0.04 |  1.8311 |      - |  27.23 KB |        3.53 |
|                   |                      |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,353.49 μs** |  **4.302 μs** |  **2.560 μs** | **13.13** |    **0.08** | **31.2500** | **7.8125** | **627.92 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 1,353.27 μs | 36.387 μs | 24.067 μs | 13.13 |    0.23 |  7.8125 |      - | 158.09 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDM [23] | 10000 |   103.10 μs |  1.031 μs |  0.614 μs |  1.00 |    0.01 |  3.9063 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 10000 |   156.52 μs |  4.416 μs |  2.921 μs |  1.52 |    0.03 | 17.5781 | 4.8828 | 273.33 KB |        3.50 |
