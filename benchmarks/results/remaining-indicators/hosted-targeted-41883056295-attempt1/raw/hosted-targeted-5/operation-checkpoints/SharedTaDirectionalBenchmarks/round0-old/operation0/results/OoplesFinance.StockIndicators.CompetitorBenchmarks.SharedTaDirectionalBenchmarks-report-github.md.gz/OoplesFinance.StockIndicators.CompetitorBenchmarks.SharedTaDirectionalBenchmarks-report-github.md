```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error   | StdDev  | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |-----------:|--------:|--------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **139.9 μs** | **0.80 μs** | **0.48 μs** |  **3.9063** |      **-** |  **65.01 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   137.2 μs | 0.67 μs | 0.35 μs |  0.9766 |      - |  17.41 KB |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,338.3 μs** | **5.98 μs** | **3.13 μs** | **31.2500** | **7.8125** | **627.92 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 1,323.4 μs | 9.05 μs | 5.99 μs |  7.8125 |      - | 158.09 KB |
