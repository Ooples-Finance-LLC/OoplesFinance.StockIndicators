```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **145.8 μs** |   **2.01 μs** |   **1.20 μs** |       **-** |      **-** |  **65.02 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   150.8 μs |  12.73 μs |   8.42 μs |  0.9766 |      - |  17.41 KB |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,577.6 μs** | **222.49 μs** | **147.16 μs** | **31.2500** | **7.8125** | **627.89 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 1,599.7 μs | 245.56 μs | 162.42 μs |       - |      - | 158.16 KB |
