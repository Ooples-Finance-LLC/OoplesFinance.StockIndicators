```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDM [23]** |   **177.67 μs** |  **2.699 μs** |  **1.606 μs** |  **1.00** | **105.73 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDM [23] |    17.34 μs |  2.353 μs |  1.230 μs |  0.10 |  40.27 KB |        0.38 |
|            |       |                      |             |           |           |       |           |             |
| **Ooples**     | **10000** | **TaLib(...)nusDM [23]** | **1,511.44 μs** | **15.759 μs** | **10.423 μs** |  **1.00** | **1036.7 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDM [23] |   160.66 μs | 12.431 μs |  7.397 μs |  0.11 | 330.91 KB |        0.32 |
