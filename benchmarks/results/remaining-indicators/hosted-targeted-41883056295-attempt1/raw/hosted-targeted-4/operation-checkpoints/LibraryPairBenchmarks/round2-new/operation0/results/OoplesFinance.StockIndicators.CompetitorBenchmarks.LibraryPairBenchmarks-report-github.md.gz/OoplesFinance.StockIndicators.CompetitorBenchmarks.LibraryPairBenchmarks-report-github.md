```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error    | StdDev   | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|---------:|---------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDI [23]** |   **214.45 μs** | **1.174 μs** | **0.614 μs** |  **1.00** |  **105.69 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDI [23] |    12.46 μs | 1.053 μs | 0.696 μs |  0.06 |   38.26 KB |        0.36 |
|            |       |                      |             |          |          |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDI [23]** | **1,908.02 μs** | **8.592 μs** | **5.113 μs** |  **1.00** | **1033.74 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDI [23] |   119.30 μs | 9.138 μs | 5.438 μs |  0.06 |  327.97 KB |        0.32 |
