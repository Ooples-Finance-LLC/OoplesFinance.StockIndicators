```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **142.521 μs** | **1.3676 μs** | **0.7153 μs** | **22.17** |    **0.12** |       **-** |      **-** |  **65.05 KB** |        **8.43** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   139.545 μs | 3.0101 μs | 1.9910 μs | 21.70 |    0.30 |  0.9766 |      - |  17.41 KB |        2.26 |
| NativeSingle      | TaLib(...)nusDI [23] | 1000  |     6.430 μs | 0.0310 μs | 0.0162 μs |  1.00 |    0.00 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 1000  |    10.369 μs | 0.5268 μs | 0.3484 μs |  1.61 |    0.05 |  1.8311 | 0.0610 |  27.24 KB |        3.53 |
|                   |                      |       |              |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **1,732.415 μs** | **4.9259 μs** | **2.5763 μs** | **28.74** |    **0.23** | **31.2500** |      **-** | **627.95 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 1,707.188 μs | 5.2004 μs | 2.7199 μs | 28.32 |    0.23 |       - |      - | 158.08 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDI [23] | 10000 |    60.281 μs | 0.8391 μs | 0.4993 μs |  1.00 |    0.01 |  4.3945 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 10000 |   109.852 μs | 2.7707 μs | 1.6488 μs |  1.82 |    0.03 | 18.5547 | 4.8828 | 273.34 KB |        3.50 |
