```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev  | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **160.1 μs** |  **2.25 μs** | **1.18 μs** |       **-** |  **65.01 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   154.9 μs |  1.04 μs | 0.62 μs |  0.9766 |   17.4 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **1,918.9 μs** |  **6.85 μs** | **3.58 μs** | **31.2500** | **627.98 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 1,876.2 μs | 15.42 μs | 9.17 μs |       - | 158.15 KB |
