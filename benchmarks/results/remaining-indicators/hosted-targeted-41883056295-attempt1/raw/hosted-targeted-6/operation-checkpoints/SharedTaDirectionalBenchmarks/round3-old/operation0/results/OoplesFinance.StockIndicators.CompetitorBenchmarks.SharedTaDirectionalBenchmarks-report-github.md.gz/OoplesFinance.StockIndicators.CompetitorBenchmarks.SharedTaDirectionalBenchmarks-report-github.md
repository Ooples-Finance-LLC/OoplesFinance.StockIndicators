```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon 6973P-C 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **178.5 μs** | **11.40 μs** |  **7.54 μs** |  **65.01 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   160.0 μs |  2.14 μs |  1.12 μs |  17.41 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **1,835.2 μs** | **34.70 μs** | **22.95 μs** | **627.96 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 1,700.5 μs | 32.24 μs | 19.18 μs | 158.13 KB |
