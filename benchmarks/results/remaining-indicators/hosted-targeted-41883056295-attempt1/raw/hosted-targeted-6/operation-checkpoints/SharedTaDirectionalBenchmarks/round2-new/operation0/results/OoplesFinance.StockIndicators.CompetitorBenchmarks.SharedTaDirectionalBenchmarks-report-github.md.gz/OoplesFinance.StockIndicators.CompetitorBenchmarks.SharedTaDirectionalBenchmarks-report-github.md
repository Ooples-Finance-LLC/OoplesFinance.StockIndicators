```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon 6973P-C 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0   | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|-------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **158.026 μs** |  **5.6834 μs** |  **3.7592 μs** | **21.23** |    **0.76** |      **-** |      **-** |  **65.01 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   149.892 μs |  2.3591 μs |  1.4038 μs | 20.14 |    0.58 |      - |      - |  17.41 KB |        2.26 |
| NativeSingle      | TaLib(...)lusDI [22] | 1000  |     7.450 μs |  0.3286 μs |  0.2173 μs |  1.00 |    0.04 | 0.0610 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 1000  |    12.164 μs |  0.3892 μs |  0.2316 μs |  1.63 |    0.05 | 0.3662 |      - |  27.24 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |        |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **1,669.383 μs** | **34.8470 μs** | **23.0491 μs** | **21.24** |    **0.35** |      **-** |      **-** | **627.96 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 1,510.569 μs | 58.9995 μs | 39.0245 μs | 19.22 |    0.51 |      - |      - | 158.09 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDI [22] | 10000 |    78.615 μs |  1.4018 μs |  0.8342 μs |  1.00 |    0.01 | 0.4883 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 10000 |   140.031 μs | 10.5426 μs |  6.9733 μs |  1.78 |    0.09 | 2.9297 | 0.9766 | 273.34 KB |        3.50 |
