```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon 6973P-C 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **189.0 μs** | **22.87 μs** | **13.61 μs** |  **65.01 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   164.5 μs |  4.44 μs |  2.64 μs |  17.41 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **1,797.0 μs** | **45.45 μs** | **27.05 μs** | **627.96 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 1,758.1 μs | 35.49 μs | 18.56 μs | 158.15 KB |
