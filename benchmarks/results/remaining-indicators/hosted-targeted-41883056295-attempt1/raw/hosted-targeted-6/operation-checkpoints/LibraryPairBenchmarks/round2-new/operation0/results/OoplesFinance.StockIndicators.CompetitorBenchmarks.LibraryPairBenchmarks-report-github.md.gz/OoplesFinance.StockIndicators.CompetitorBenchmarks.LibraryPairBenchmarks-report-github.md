```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon 6973P-C 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDI [22]** |   **193.43 μs** |  **1.694 μs** |  **0.886 μs** |  **1.00** |    **0.01** |  **105.66 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDI [22] |    16.06 μs |  0.804 μs |  0.421 μs |  0.08 |    0.00 |   40.23 KB |        0.38 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDI [22]** | **1,733.23 μs** | **62.629 μs** | **41.425 μs** |  **1.00** |    **0.03** | **1036.66 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDI [22] |   132.31 μs |  8.485 μs |  5.612 μs |  0.08 |    0.00 |  330.92 KB |        0.32 |
