```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **325.39 μs** | **12.110 μs** |  **7.206 μs** | **25.02** |    **0.55** |       **-** |      **-** |  **65.01 KB** |        **8.42** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   317.55 μs |  5.012 μs |  2.982 μs | 24.42 |    0.27 |       - |      - |  17.41 KB |        2.26 |
| NativeSingle      | TaLib.Functions.Dx | 1000  |    13.00 μs |  0.138 μs |  0.091 μs |  1.00 |    0.01 |  0.3662 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 1000  |    19.74 μs |  0.750 μs |  0.446 μs |  1.52 |    0.03 |  1.8311 |      - |  27.24 KB |        3.53 |
|                   |                    |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **3,771.06 μs** | **40.509 μs** | **21.187 μs** | **28.93** |    **0.22** | **31.2500** |      **-** | **628.08 KB** |        **8.05** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 3,740.40 μs | 36.579 μs | 19.131 μs | 28.70 |    0.20 |       - |      - | 158.21 KB |        2.03 |
| NativeSingle      | TaLib.Functions.Dx | 10000 |   130.35 μs |  1.221 μs |  0.727 μs |  1.00 |    0.01 |  3.9063 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 10000 |   188.42 μs | 12.720 μs |  8.413 μs |  1.45 |    0.06 | 17.5781 | 3.9063 | 273.35 KB |        3.50 |
