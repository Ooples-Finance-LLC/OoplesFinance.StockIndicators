```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **318.4 μs** |  **6.13 μs** |  **3.20 μs** |       **-** |  **64.98 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   311.5 μs |  2.78 μs |  1.66 μs |       - |  17.41 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **3,713.8 μs** | **10.95 μs** |  **5.72 μs** | **31.2500** | **627.94 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 3,695.3 μs | 23.25 μs | 13.84 μs |       - | 158.25 KB |
