```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **381.6 μs** |   **6.43 μs** |  **3.37 μs** |       **-** |  **65.02 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   375.5 μs |   7.35 μs |  4.86 μs |       - |  17.41 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **4,365.1 μs** | **101.59 μs** | **67.19 μs** | **31.2500** | **628.06 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 4,291.2 μs |   8.71 μs |  4.56 μs |       - | 158.22 KB |
