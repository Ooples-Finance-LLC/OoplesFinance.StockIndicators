```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **401.7 μs** |   **4.56 μs** |  **2.38 μs** |       **-** |  **64.99 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   390.7 μs |   4.67 μs |  2.78 μs |       - |  17.43 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **4,422.0 μs** | **116.55 μs** | **77.09 μs** | **31.2500** | **628.03 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 4,373.7 μs |  23.01 μs | 12.04 μs |       - | 158.22 KB |
