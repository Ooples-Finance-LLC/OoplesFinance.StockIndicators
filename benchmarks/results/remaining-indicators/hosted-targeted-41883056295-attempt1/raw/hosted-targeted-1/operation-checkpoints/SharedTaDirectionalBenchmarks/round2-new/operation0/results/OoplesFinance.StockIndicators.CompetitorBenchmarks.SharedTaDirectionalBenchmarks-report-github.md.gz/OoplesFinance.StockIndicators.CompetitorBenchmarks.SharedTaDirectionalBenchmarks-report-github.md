```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **278.45 μs** |  **7.529 μs** |  **4.980 μs** | **23.08** |    **0.47** |       **-** |      **-** |   **65.2 KB** |        **8.61** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   269.61 μs |  7.876 μs |  5.210 μs | 22.35 |    0.48 |       - |      - |  17.62 KB |        2.33 |
| NativeSingle      | TaLib.Functions.Adx | 1000  |    12.06 μs |  0.245 μs |  0.146 μs |  1.00 |    0.02 |  0.3662 |      - |   7.57 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 1000  |    22.06 μs |  0.492 μs |  0.293 μs |  1.83 |    0.03 |  1.7090 |      - |  26.71 KB |        3.53 |
|                   |                     |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **3,351.58 μs** |  **9.610 μs** |  **5.026 μs** | **28.61** |    **0.07** | **31.2500** |      **-** | **630.81 KB** |        **8.10** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 3,313.69 μs | 10.298 μs |  5.386 μs | 28.28 |    0.07 |       - |      - | 161.08 KB |        2.07 |
| NativeSingle      | TaLib.Functions.Adx | 10000 |   117.16 μs |  0.476 μs |  0.249 μs |  1.00 |    0.00 |  3.9063 |      - |  77.89 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 10000 |   174.91 μs | 19.215 μs | 11.434 μs |  1.49 |    0.09 | 17.5781 | 3.9063 | 272.82 KB |        3.50 |
