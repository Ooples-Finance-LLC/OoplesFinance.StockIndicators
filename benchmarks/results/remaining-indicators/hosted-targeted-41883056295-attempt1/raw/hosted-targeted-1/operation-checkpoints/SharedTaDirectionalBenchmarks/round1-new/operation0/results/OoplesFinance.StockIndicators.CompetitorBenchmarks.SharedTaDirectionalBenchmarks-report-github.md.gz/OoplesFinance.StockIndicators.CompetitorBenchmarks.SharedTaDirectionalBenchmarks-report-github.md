```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev  | Gen0    | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **274.1 μs** |  **2.36 μs** | **1.23 μs** |       **-** |  **65.23 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   270.2 μs |  2.99 μs | 1.78 μs |       - |  17.63 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **3,347.8 μs** |  **9.53 μs** | **4.98 μs** | **31.2500** | **630.93 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 3,315.1 μs | 14.09 μs | 7.37 μs |       - |    161 KB |
