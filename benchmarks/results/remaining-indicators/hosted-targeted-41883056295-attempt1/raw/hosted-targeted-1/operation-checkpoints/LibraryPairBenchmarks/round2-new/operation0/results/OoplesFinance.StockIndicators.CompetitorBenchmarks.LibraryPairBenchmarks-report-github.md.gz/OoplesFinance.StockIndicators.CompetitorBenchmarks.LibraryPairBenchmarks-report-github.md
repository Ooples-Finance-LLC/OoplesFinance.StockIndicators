```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean        | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |------------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adx** |   **388.14 μs** |  **18.956 μs** |  **12.538 μs** |  **1.00** |    **0.04** |  **105.91 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adx |    18.68 μs |   1.234 μs |   0.734 μs |  0.05 |    0.00 |   36.95 KB |        0.35 |
|            |       |                     |             |            |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adx** | **3,661.39 μs** | **237.028 μs** | **141.051 μs** |  **1.00** |    **0.05** | **1039.56 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adx |   176.40 μs |  23.027 μs |  15.231 μs |  0.05 |    0.00 |  327.36 KB |        0.31 |
