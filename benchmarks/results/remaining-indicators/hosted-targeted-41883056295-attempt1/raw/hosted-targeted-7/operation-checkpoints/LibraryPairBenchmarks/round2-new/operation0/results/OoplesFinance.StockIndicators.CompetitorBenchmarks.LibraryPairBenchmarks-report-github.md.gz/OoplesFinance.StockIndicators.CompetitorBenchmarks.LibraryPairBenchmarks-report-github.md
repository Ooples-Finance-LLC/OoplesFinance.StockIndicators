```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDM [22]** |   **167.47 μs** |  **2.020 μs** |  **1.057 μs** |  **1.00** |  **105.65 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDM [22] |    16.90 μs |  1.463 μs |  0.870 μs |  0.10 |   40.27 KB |        0.38 |
|            |       |                      |             |           |           |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDM [22]** | **1,489.26 μs** | **24.658 μs** | **14.674 μs** |  **1.00** | **1036.38 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDM [22] |   156.81 μs |  5.826 μs |  3.467 μs |  0.11 |  330.63 KB |        0.32 |
