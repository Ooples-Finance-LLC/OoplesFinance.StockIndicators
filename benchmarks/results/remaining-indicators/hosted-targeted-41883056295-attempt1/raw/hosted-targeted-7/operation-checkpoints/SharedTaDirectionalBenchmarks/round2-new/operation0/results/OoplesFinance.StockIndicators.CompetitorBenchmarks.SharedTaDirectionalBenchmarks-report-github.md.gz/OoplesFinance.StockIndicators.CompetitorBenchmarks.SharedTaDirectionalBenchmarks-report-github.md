```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev   | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|---------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **136.29 μs** |  **1.002 μs** | **0.524 μs** | **13.33** |    **0.08** |       **-** |      **-** |  **65.05 KB** |        **8.43** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   131.65 μs |  1.241 μs | 0.738 μs | 12.88 |    0.09 |  0.9766 |      - |  17.41 KB |        2.26 |
| NativeSingle      | TaLib(...)lusDM [22] | 1000  |    10.22 μs |  0.073 μs | 0.048 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 1000  |    16.59 μs |  1.363 μs | 0.901 μs |  1.62 |    0.08 |  1.7090 |      - |  27.23 KB |        3.53 |
|                   |                      |       |             |           |          |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **1,294.92 μs** | **11.423 μs** | **6.798 μs** | **12.50** |    **0.08** | **31.2500** | **7.8125** | **627.92 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 1,287.99 μs | 10.379 μs | 6.176 μs | 12.43 |    0.07 |  7.8125 |      - | 158.09 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDM [22] | 10000 |   103.63 μs |  0.550 μs | 0.364 μs |  1.00 |    0.00 |  3.9063 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 10000 |   156.24 μs |  5.480 μs | 3.625 μs |  1.51 |    0.03 | 17.5781 | 3.9063 | 273.33 KB |        3.50 |
