```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **294.1 μs** |  **5.26 μs** |  **3.13 μs** |       **-** |   **66.3 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   291.8 μs |  2.49 μs |  1.48 μs |       - |   18.7 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **3,245.7 μs** | **32.87 μs** | **19.56 μs** | **31.2500** | **632.01 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 3,200.8 μs | 19.36 μs | 11.52 μs |       - | 162.04 KB |
