```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **247.8 μs** |  **3.37 μs** |  **2.01 μs** |       **-** |       **-** |   **66.3 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   244.2 μs |  1.51 μs |  0.90 μs |       - |       - |   18.7 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **2,789.3 μs** | **38.21 μs** | **22.74 μs** | **31.2500** | **15.6250** | **631.83 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 2,732.3 μs | 75.47 μs | 49.92 μs |       - |       - | 161.98 KB |
