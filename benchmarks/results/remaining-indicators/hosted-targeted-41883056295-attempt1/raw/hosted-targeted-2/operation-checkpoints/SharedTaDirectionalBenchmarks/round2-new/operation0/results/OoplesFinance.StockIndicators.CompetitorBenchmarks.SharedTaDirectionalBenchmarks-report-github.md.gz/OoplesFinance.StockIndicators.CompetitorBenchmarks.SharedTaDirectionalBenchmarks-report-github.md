```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **253.30 μs** |  **8.977 μs** |  **4.695 μs** | **23.60** |    **0.48** |       **-** |       **-** |   **66.3 KB** |        **4.42** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   248.46 μs |  5.086 μs |  3.026 μs | 23.15 |    0.36 |       - |       - |   18.7 KB |        1.25 |
| NativeSingle      | TaLib.Functions.Adxr | 1000  |    10.73 μs |  0.233 μs |  0.122 μs |  1.00 |    0.01 |  0.9155 |       - |  14.99 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 1000  |    17.89 μs |  0.597 μs |  0.312 μs |  1.67 |    0.03 |  3.0518 |  0.1221 |  45.43 KB |        3.03 |
|                   |                      |       |             |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **2,826.84 μs** | **68.725 μs** | **40.897 μs** | **26.10** |    **0.37** | **31.2500** | **15.6250** | **631.81 KB** |        **4.06** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 2,825.20 μs | 76.663 μs | 50.708 μs | 26.09 |    0.45 |       - |       - |    162 KB |        1.04 |
| NativeSingle      | TaLib.Functions.Adxr | 10000 |   108.30 μs |  0.699 μs |  0.366 μs |  1.00 |    0.00 |  8.7891 |  0.9766 | 155.63 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 10000 |   165.59 μs | 21.108 μs | 13.961 μs |  1.53 |    0.12 | 30.2734 |  9.7656 | 467.31 KB |        3.00 |
