```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **295.7 μs** |  **7.15 μs** |  **3.74 μs** |       **-** |  **66.27 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   299.5 μs | 11.49 μs |  7.60 μs |       - |   18.7 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **3,226.8 μs** | **40.22 μs** | **23.94 μs** | **31.2500** | **631.98 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 3,242.5 μs | 66.12 μs | 39.35 μs |       - | 162.05 KB |
