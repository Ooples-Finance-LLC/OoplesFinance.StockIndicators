```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adxr** |   **316.58 μs** | **17.543 μs** | **10.440 μs** |  **1.00** |    **0.04** | **106.98 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adxr |    13.62 μs |  0.778 μs |  0.463 μs |  0.04 |    0.00 |  44.52 KB |        0.42 |
|            |       |                      |             |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adxr** | **3,044.22 μs** | **19.028 μs** | **11.323 μs** |  **1.00** |    **0.00** | **1037.3 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adxr |   146.05 μs |  9.022 μs |  5.369 μs |  0.05 |    0.00 | 404.21 KB |        0.39 |
