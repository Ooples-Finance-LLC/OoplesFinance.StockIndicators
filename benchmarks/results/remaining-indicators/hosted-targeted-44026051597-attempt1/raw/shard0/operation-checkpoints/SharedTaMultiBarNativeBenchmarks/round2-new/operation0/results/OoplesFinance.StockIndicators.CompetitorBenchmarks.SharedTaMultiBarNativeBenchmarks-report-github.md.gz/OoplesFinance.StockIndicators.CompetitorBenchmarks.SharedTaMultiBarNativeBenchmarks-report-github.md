```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |---------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **Breakaway** | **1000**  | **106.24 μs** |  **3.439 μs** |  **2.047 μs** |  **5.07** |    **0.09** |  **3.9063** |       **-** |  **64.43 KB** |       **16.23** |
| BuilderLatestOnly | Breakaway | 1000  | 103.95 μs |  5.018 μs |  3.319 μs |  4.96 |    0.15 |  0.9766 |       - |  16.59 KB |        4.18 |
| NativeSingle      | Breakaway | 1000  |  20.94 μs |  0.136 μs |  0.071 μs |  1.00 |    0.00 |  0.1221 |       - |   3.97 KB |        1.00 |
| NativeParallel    | Breakaway | 1000  |  87.06 μs |  1.168 μs |  0.773 μs |  4.16 |    0.04 |  0.4883 |       - |   8.42 KB |        2.12 |
|                   |           |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **Breakaway** | **10000** | **341.79 μs** | **19.712 μs** | **10.310 μs** |  **1.52** |    **0.05** | **33.2031** | **11.7188** | **556.98 KB** |       **14.23** |
| BuilderLatestOnly | Breakaway | 10000 | 331.72 μs | 32.195 μs | 21.295 μs |  1.47 |    0.09 |  3.9063 |       - |  86.92 KB |        2.22 |
| NativeSingle      | Breakaway | 10000 | 225.09 μs |  5.021 μs |  2.626 μs |  1.00 |    0.02 |  1.9531 |       - |  39.13 KB |        1.00 |
| NativeParallel    | Breakaway | 10000 | 204.69 μs | 15.861 μs | 10.491 μs |  0.91 |    0.05 |  5.8594 |       - |  78.73 KB |        2.01 |
