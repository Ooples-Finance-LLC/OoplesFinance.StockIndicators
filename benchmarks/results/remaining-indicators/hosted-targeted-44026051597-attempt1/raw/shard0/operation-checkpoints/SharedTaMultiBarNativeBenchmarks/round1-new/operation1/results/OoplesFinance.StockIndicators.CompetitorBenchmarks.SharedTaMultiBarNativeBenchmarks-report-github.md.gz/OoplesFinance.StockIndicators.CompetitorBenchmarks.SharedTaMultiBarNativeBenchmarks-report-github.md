```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Conce(...)allow [21]** | **1000**  | **103.93 μs** |  **2.135 μs** |  **1.117 μs** |  **3.9063** |       **-** |  **64.44 KB** |
| BuilderLatestOnly | Conce(...)allow [21] | 1000  |  99.51 μs |  1.214 μs |  0.635 μs |  0.9766 |       - |  16.59 KB |
| **BuilderFull**       | **Conce(...)allow [21]** | **10000** | **335.72 μs** | **18.826 μs** | **12.452 μs** | **33.2031** | **11.7188** | **556.99 KB** |
| BuilderLatestOnly | Conce(...)allow [21] | 10000 | 306.59 μs |  3.613 μs |  1.890 μs |  3.9063 |       - |  86.93 KB |
