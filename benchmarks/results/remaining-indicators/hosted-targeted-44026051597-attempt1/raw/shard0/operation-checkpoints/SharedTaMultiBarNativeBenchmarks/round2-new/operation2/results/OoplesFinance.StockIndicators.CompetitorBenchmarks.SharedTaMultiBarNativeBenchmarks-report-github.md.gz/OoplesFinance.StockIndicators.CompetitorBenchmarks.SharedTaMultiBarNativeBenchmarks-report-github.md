```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation    | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **LadderBottom** | **1000**  | **108.22 μs** |  **9.459 μs** |  **6.257 μs** |  **7.22** |    **0.40** |  **3.9063** |       **-** |  **64.47 KB** |       **16.24** |
| BuilderLatestOnly | LadderBottom | 1000  | 100.17 μs |  0.975 μs |  0.510 μs |  6.69 |    0.06 |  0.9766 |       - |  16.59 KB |        4.18 |
| NativeSingle      | LadderBottom | 1000  |  14.98 μs |  0.211 μs |  0.125 μs |  1.00 |    0.01 |  0.1221 |       - |   3.97 KB |        1.00 |
| NativeParallel    | LadderBottom | 1000  |  83.46 μs |  1.253 μs |  0.746 μs |  5.57 |    0.06 |  0.4883 |       - |   8.42 KB |        2.12 |
|                   |              |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **LadderBottom** | **10000** | **332.75 μs** | **22.215 μs** | **14.694 μs** |  **2.22** |    **0.09** | **33.2031** | **11.7188** | **557.02 KB** |       **14.23** |
| BuilderLatestOnly | LadderBottom | 10000 | 312.94 μs | 18.743 μs | 12.398 μs |  2.09 |    0.08 |  3.9063 |       - |  86.92 KB |        2.22 |
| NativeSingle      | LadderBottom | 10000 | 149.61 μs |  1.415 μs |  0.842 μs |  1.00 |    0.01 |  1.9531 |       - |  39.13 KB |        1.00 |
| NativeParallel    | LadderBottom | 10000 | 164.09 μs | 10.333 μs |  6.835 μs |  1.10 |    0.04 |  5.8594 |       - |  78.73 KB |        2.01 |
