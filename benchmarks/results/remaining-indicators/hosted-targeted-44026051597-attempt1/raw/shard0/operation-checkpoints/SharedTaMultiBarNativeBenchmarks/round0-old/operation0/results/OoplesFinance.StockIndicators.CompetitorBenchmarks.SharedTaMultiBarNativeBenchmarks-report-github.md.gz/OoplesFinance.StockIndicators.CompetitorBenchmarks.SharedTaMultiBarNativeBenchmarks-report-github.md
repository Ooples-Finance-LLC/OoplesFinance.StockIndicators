```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Breakaway** | **1000**  | **128.5 μs** | **17.94 μs** | **11.87 μs** |  **3.9063** |       **-** |  **64.47 KB** |
| BuilderLatestOnly | Breakaway | 1000  | 116.5 μs |  4.55 μs |  3.01 μs |  0.9766 |       - |  16.59 KB |
| **BuilderFull**       | **Breakaway** | **10000** | **501.4 μs** | **39.48 μs** | **26.11 μs** | **31.2500** | **11.7188** | **557.04 KB** |
| BuilderLatestOnly | Breakaway | 10000 | 467.8 μs | 38.45 μs | 25.43 μs |  3.9063 |       - |  86.93 KB |
