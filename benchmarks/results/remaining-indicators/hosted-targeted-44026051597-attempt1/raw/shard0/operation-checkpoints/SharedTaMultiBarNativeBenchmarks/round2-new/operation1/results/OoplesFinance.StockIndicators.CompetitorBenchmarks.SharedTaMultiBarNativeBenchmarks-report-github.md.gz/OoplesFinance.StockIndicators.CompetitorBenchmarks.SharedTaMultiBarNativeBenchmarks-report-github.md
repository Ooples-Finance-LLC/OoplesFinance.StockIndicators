```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **Conce(...)allow [21]** | **1000**  | **106.87 μs** |  **6.556 μs** |  **3.901 μs** |  **2.58** |    **0.09** |  **3.9063** |       **-** |  **64.47 KB** |       **16.24** |
| BuilderLatestOnly | Conce(...)allow [21] | 1000  | 102.93 μs |  5.820 μs |  3.850 μs |  2.49 |    0.09 |  0.9766 |       - |  16.59 KB |        4.18 |
| NativeSingle      | Conce(...)allow [21] | 1000  |  41.34 μs |  0.137 μs |  0.072 μs |  1.00 |    0.00 |       - |       - |   3.97 KB |        1.00 |
| NativeParallel    | Conce(...)allow [21] | 1000  |  96.82 μs |  1.483 μs |  0.776 μs |  2.34 |    0.02 |       - |       - |   8.42 KB |        2.12 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **Conce(...)allow [21]** | **10000** | **341.70 μs** | **28.067 μs** | **18.565 μs** |  **0.81** |    **0.04** | **33.2031** | **11.7188** | **557.01 KB** |       **14.23** |
| BuilderLatestOnly | Conce(...)allow [21] | 10000 | 312.64 μs | 18.970 μs | 12.548 μs |  0.74 |    0.03 |  3.9063 |       - |  86.92 KB |        2.22 |
| NativeSingle      | Conce(...)allow [21] | 10000 | 423.24 μs | 11.286 μs |  6.716 μs |  1.00 |    0.02 |       - |       - |  39.14 KB |        1.00 |
| NativeParallel    | Conce(...)allow [21] | 10000 | 306.49 μs | 27.179 μs | 17.977 μs |  0.72 |    0.04 |  5.8594 |       - |  78.74 KB |        2.01 |
