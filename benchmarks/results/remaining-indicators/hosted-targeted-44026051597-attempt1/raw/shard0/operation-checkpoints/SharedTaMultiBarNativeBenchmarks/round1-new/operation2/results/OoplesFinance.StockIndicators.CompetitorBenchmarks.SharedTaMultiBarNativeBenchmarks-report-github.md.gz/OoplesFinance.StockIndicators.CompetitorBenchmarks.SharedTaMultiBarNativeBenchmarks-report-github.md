```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation    | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **LadderBottom** | **1000**  | **105.8 μs** |  **6.46 μs** |  **4.27 μs** |  **3.9063** |       **-** |  **64.47 KB** |
| BuilderLatestOnly | LadderBottom | 1000  | 101.8 μs |  4.00 μs |  2.65 μs |  0.9766 |       - |  16.59 KB |
| **BuilderFull**       | **LadderBottom** | **10000** | **338.1 μs** | **29.82 μs** | **19.72 μs** | **31.2500** | **11.7188** | **557.04 KB** |
| BuilderLatestOnly | LadderBottom | 10000 | 312.1 μs | 30.88 μs | 18.38 μs |  3.9063 |       - |  86.92 KB |
