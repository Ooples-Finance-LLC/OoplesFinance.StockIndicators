```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Breakaway** | **1000**  | **106.2 μs** |  **4.31 μs** |  **2.56 μs** |  **3.9063** |       **-** |  **64.47 KB** |
| BuilderLatestOnly | Breakaway | 1000  | 102.0 μs |  2.36 μs |  1.23 μs |  0.9766 |       - |  16.59 KB |
| **BuilderFull**       | **Breakaway** | **10000** | **366.1 μs** | **30.33 μs** | **20.06 μs** | **33.2031** | **11.7188** | **557.02 KB** |
| BuilderLatestOnly | Breakaway | 10000 | 323.2 μs | 26.27 μs | 17.37 μs |  3.9063 |       - |  86.92 KB |
