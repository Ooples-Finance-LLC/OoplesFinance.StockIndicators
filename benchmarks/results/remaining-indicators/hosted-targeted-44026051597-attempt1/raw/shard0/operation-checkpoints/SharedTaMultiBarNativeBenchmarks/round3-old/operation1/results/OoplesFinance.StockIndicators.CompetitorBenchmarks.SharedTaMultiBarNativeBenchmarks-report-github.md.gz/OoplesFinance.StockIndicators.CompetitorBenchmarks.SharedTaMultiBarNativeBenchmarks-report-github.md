```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error   | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |---------:|--------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **Conce(...)allow [21]** | **1000**  | **102.6 μs** | **0.70 μs** | **0.37 μs** |  **3.9063** |       **-** |  **64.47 KB** |
| BuilderLatestOnly | Conce(...)allow [21] | 1000  | 102.0 μs | 5.01 μs | 3.31 μs |  0.9766 |       - |  16.59 KB |
| **BuilderFull**       | **Conce(...)allow [21]** | **10000** | **325.6 μs** | **9.51 μs** | **4.97 μs** | **31.2500** | **11.7188** | **557.03 KB** |
| BuilderLatestOnly | Conce(...)allow [21] | 10000 | 304.3 μs | 6.78 μs | 4.03 μs |  3.9063 |       - |  86.93 KB |
