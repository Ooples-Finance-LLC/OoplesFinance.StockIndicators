```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation    | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **LadderBottom** | **1000**  | **108.0 μs** |  **8.75 μs** |  **5.79 μs** |  **3.9063** |       **-** |  **64.47 KB** |
| BuilderLatestOnly | LadderBottom | 1000  | 102.1 μs |  1.94 μs |  1.01 μs |  0.9766 |       - |  16.59 KB |
| **BuilderFull**       | **LadderBottom** | **10000** | **326.4 μs** | **10.16 μs** |  **5.32 μs** | **31.2500** | **11.7188** | **557.04 KB** |
| BuilderLatestOnly | LadderBottom | 10000 | 307.3 μs | 21.48 μs | 12.78 μs |  3.9063 |       - |  86.92 KB |
