```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)kaway [23]** | **229.69 μs** |  **8.900 μs** | **5.296 μs** |  **1.00** |    **0.03** |  **68.77 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)kaway [23] |  37.69 μs |  0.371 μs | 0.220 μs |  0.16 |    0.00 |  12.08 KB |        0.18 |
|            |       |                      |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)kaway [23]** | **279.33 μs** | **10.974 μs** | **6.530 μs** |  **1.00** |    **0.03** | **638.13 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)kaway [23] | 352.49 μs | 10.649 μs | 6.337 μs |  1.26 |    0.03 | 123.08 KB |        0.19 |
