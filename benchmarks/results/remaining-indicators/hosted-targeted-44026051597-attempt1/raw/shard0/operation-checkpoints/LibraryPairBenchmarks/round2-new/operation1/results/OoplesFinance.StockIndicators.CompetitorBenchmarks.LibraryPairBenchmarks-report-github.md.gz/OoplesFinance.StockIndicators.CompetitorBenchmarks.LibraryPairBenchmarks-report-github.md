```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)allow [35]** | **215.94 μs** |  **4.852 μs** |  **2.538 μs** |  **1.00** |    **0.02** |  **68.77 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)allow [35] |  50.68 μs |  0.427 μs |  0.254 μs |  0.23 |    0.00 |  18.27 KB |        0.27 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)allow [35]** | **253.99 μs** | **11.517 μs** |  **6.854 μs** |  **1.00** |    **0.04** | **639.35 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)allow [35] | 469.31 μs | 21.288 μs | 14.081 μs |  1.85 |    0.07 | 123.45 KB |        0.19 |
