"""Tiny synthetic-only collector defenses; no remote access or production runtime."""
import importlib.util
import io
import tempfile
import unittest
from unittest import mock
import zipfile
from pathlib import Path
spec=importlib.util.spec_from_file_location('collector',Path(__file__).with_name('collect-breakaway-predicate-qualification-20261116.py'))
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)

class CollectorTests(unittest.TestCase):
    def test_member_paths_and_aliases(self):
        for names in [('a/../b',),('C:/bad',),('a\\b',),('CON.txt',),('file','FILE')]:
            with self.subTest(names=names):
                stream=io.BytesIO()
                with zipfile.ZipFile(stream,'w') as p:
                    for name in names:
                        item=zipfile.ZipInfo('placeholder');item.filename=name
                        p.writestr(item,b'x')
                with zipfile.ZipFile(stream) as p,self.assertRaises(AssertionError):c.members(p)
    def test_preflight_source_and_assembly_evidence(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);stream=io.BytesIO()
            names=['predicate-inputs/old-candidate-authentication/evidence/unit.trx',
                'predicate-inputs/candidate-authentication/evidence/parity.trx',
                'predicate-inputs/baseline-authentication/evidence/source-change.patch']
            with zipfile.ZipFile(stream,'w') as p:
                for name in names:p.writestr(name,b'proof')
            original=c.reserve
            try:
                c.reserve=lambda *args:None
                with zipfile.ZipFile(stream) as p:
                    rows=c.extract_text(p,c.members(p),set(names),root)
                self.assertEqual(len(rows),3)
            finally:c.reserve=original
    def test_fresh_links_preserve_original_and_reject_overwrite(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);source=root/'source';target=root/'target';source.write_bytes(b'exact')
            sha=c.digest(source);self.assertEqual(c.link_verified(source,target,sha),'hardlink')
            self.assertEqual(target.read_bytes(),b'exact')
            with self.assertRaises(AssertionError):c.link_verified(source,target,sha)
            self.assertEqual(c.digest(source),sha)
    def test_rejected_summary_retained(self):
        result=dict(case_count=90,decision_count=18,accepted=False,source_gate_accepted=True,native_progress_gate_passed=False,native_progress_gate=dict(passed=False))
        self.assertEqual(c.check_summary(result,dict(result)),result)
        self.assertNotIn('production_integrated',c.check_summary(result,dict(result)))
        self.assertNotIn('report_imported',c.check_summary(result,dict(result)))
        accepted=dict(result,accepted=True,native_progress_gate_passed=True,native_progress_gate=dict(passed=True))
        self.assertEqual(c.check_summary(accepted,dict(accepted)),accepted)
        with self.assertRaises(AssertionError):c.check_summary(dict(result,report_imported=True),dict(result,report_imported=True))
        with self.assertRaises(AssertionError):c.check_summary(result,dict(result,accepted=True))
        with self.assertRaises(AssertionError):c.check_summary(dict(result,accepted=True),dict(result,accepted=True))
    def test_round_keys_use_exact_json_representation(self):
        result=dict(case_count=90,decision_count=18,accepted=False,source_gate_accepted=True,native_progress_gate_passed=False,native_progress_gate=dict(passed=False),
            production_integrated=False,report_imported=False,native_progress_samples={0:{'mean_ns':123.5}})
        hosted=dict(result,native_progress_samples={'0':{'mean_ns':123.5}})
        self.assertEqual(c.check_summary(result,hosted),hosted)
        with self.assertRaises(AssertionError):
            c.check_summary(result,dict(hosted,native_progress_samples={'0':{'mean_ns':123.6}}))
    def test_archived_snapshots_exact_and_wrong_core(self):
        import hashlib
        h=lambda raw:hashlib.sha256(raw).hexdigest()
        core='OoplesFinance.StockIndicators.dll'
        common={core:h(b'common-core'),'dependency.dll':h(b'dependency')}
        proof=dict(common_manifest=common,production_sha256=dict(old=h(b'old-core'),successor=h(b'new-core')))
        by_sha={sha:None for sha in [*common.values(),*proof['production_sha256'].values()]}
        for corruption in (None,'old','new'):
            stream=io.BytesIO()
            with zipfile.ZipFile(stream,'w') as p:
                for label in ('old','new'):
                    prefix='predicate-qualification/evidence/shard0-runtime-'+label+'/'
                    p.writestr(prefix+'dependency.dll',b'dependency')
                    raw=(label+'-core').encode()
                    p.writestr(prefix+core,b'WRONG' if corruption==label else raw)
            with zipfile.ZipFile(stream) as p:
                if corruption:
                    with self.assertRaises(AssertionError):c.archived_snapshots(p,c.members(p),proof,by_sha)
                else:
                    result=c.archived_snapshots(p,c.members(p),proof,by_sha)
                    self.assertEqual(set(result),{'old','new'})
                    self.assertEqual(result['new']['files'][core],h(b'new-core'))
    def test_runtime_bytes_checked_before_materialization(self):
        import json
        for corruption in ('common','old-blob','new-blob'):
            with self.subTest(corruption=corruption),tempfile.TemporaryDirectory() as folder:
                root=Path(folder);base=root/'base';candidate=root/'candidate';old_candidate=root/'old-candidate'
                for directory in (base/'common',base/'production',candidate,old_candidate):directory.mkdir(parents=True)
                harness='OoplesFinance.StockIndicators.CompetitorBenchmarks.dll'
                core='OoplesFinance.StockIndicators.dll'
                names=[harness,core]+['dependency'+str(i)+'.dll' for i in range(92)]
                payload={name:b'dependency' for name in names};payload[harness]=b'harness';payload[core]=b'variant-core'
                for name,raw in payload.items():(base/'common'/name).write_bytes(raw)
                original=dict(common_manifest={name:c.digest(base/'common'/name) for name in names},production_sha256={})
                for name,raw in [('old',b'original-core'),('successor',b'original-core'),('variants',b'variant-core')]:
                    path=base/'production'/(name+'.dll');path.write_bytes(raw);original['production_sha256'][name]=c.digest(path)
                c.write(base/'provenance.json',original)
                relative='src/bin/Release/net10.0/'+core
                for directory,raw in ((candidate,b'new-core'),(old_candidate,b'old-core')):
                    path=directory/relative;path.parent.mkdir(parents=True);path.write_bytes(raw)
                old_sha=c.digest(old_candidate/relative);new_sha=c.digest(candidate/relative)
                cpu=dict(source=c.SOURCE,run_id=c.CPU_RUN,workflow_head=c.CPU_PRODUCER,runtime_files={relative:new_sha})
                old_cpu=dict(source=c.OLD_SOURCE,run_id=c.OLD_CPU_RUN,workflow_head=c.CPU_PRODUCER,runtime_files={relative:old_sha})
                proof=dict(common_manifest=original['common_manifest'],production_sha256=dict(old=old_sha,successor=new_sha,variants=original['production_sha256']['variants']))
                archive=root/'input.zip';out=root/'out'
                with zipfile.ZipFile(archive,'w') as package:
                    package.writestr('predicate-inputs/provenance.json',json.dumps(proof))
                    package.writestr('predicate-qualification/summary.json','{}')
                    for name,raw in payload.items():
                        package.writestr('predicate-inputs/common/'+name,b'CORRUPTED' if corruption=='common' and name==harness else raw)
                        for label in ('old','new'):
                            data=(label+'-core').encode() if name==core else raw
                            package.writestr('predicate-qualification/evidence/shard0-runtime-'+label+'/'+name,data)
                    for label,raw in [('old',b'old-core'),('successor',b'new-core'),('variants',b'variant-core')]:
                        package.writestr('predicate-inputs/production/'+label+'.dll',raw)
                    package.writestr('predicate-inputs/baseline-authentication/common/'+harness,payload[harness])
                    package.writestr('predicate-inputs/old-candidate-authentication/blobs/'+old_sha,b'CORRUPTED' if corruption=='old-blob' else b'old-core')
                    package.writestr('predicate-inputs/candidate-authentication/blobs/'+new_sha,b'CORRUPTED' if corruption=='new-blob' else b'new-core')
                with (mock.patch.object(c,'OLD_CORE',old_sha),mock.patch.object(c,'NEW_CORE',new_sha),
                      mock.patch.object(c,'link_verified',wraps=c.link_verified) as link):
                    with self.assertRaises(AssertionError):c.reconstruct(archive,out,base,candidate,cpu,old_candidate,old_cpu)
                    link.assert_not_called()
                self.assertFalse(out.exists())

if __name__=='__main__':unittest.main()
