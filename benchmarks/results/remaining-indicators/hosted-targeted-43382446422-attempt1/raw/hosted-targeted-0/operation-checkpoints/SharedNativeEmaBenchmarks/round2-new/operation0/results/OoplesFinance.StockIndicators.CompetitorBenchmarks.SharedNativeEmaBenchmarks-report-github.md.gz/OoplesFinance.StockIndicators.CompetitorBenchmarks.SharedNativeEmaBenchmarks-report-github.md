```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Qema** | **1000**  |   **364.05 μs** |   **9.970 μs** |  **5.933 μs** |  **3.68** |    **0.06** |  **15.6250** |       **-** |  **356.29 KB** |        **1.74** |
| BuilderLatestOnly | QuanTAlib.Qema | 1000  |   342.77 μs |   1.643 μs |  1.087 μs |  3.47 |    0.03 |  17.5781 |       - |  308.42 KB |        1.50 |
| NativeSingle      | QuanTAlib.Qema | 1000  |    98.83 μs |   1.307 μs |  0.864 μs |  1.00 |    0.01 |  11.7188 |       - |  205.19 KB |        1.00 |
| NativeParallel    | QuanTAlib.Qema | 1000  |   426.32 μs |  39.672 μs | 26.241 μs |  4.31 |    0.26 |  29.2969 |       - |  504.46 KB |        2.46 |
|                   |                |       |             |            |           |       |         |          |         |            |             |
| **BuilderFull**       | **QuanTAlib.Qema** | **10000** | **1,387.36 μs** |   **4.422 μs** |  **2.632 μs** |  **1.52** |    **0.01** |  **46.8750** | **15.6250** |  **848.88 KB** |        **0.42** |
| BuilderLatestOnly | QuanTAlib.Qema | 10000 | 1,479.37 μs |  10.032 μs |  5.247 μs |  1.62 |    0.01 |  15.6250 |       - |  378.73 KB |        0.19 |
| NativeSingle      | QuanTAlib.Qema | 10000 |   915.53 μs |   4.614 μs |  2.746 μs |  1.00 |    0.00 | 117.1875 | 23.4375 | 2033.37 KB |        1.00 |
| NativeParallel    | QuanTAlib.Qema | 10000 | 1,974.54 μs | 140.965 μs | 83.886 μs |  2.16 |    0.09 | 296.8750 | 46.8750 | 4969.41 KB |        2.44 |
