```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error   | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |-----------:|--------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Qema** | **1000**  |   **386.9 μs** | **2.34 μs** | **1.23 μs** | **15.6250** |       **-** | **356.26 KB** |
| BuilderLatestOnly | QuanTAlib.Qema | 1000  |   368.6 μs | 6.21 μs | 3.25 μs | 17.5781 |       - | 308.42 KB |
| **BuilderFull**       | **QuanTAlib.Qema** | **10000** | **1,627.5 μs** | **7.72 μs** | **4.60 μs** | **46.8750** | **15.6250** | **848.88 KB** |
| BuilderLatestOnly | QuanTAlib.Qema | 10000 | 1,685.1 μs | 2.83 μs | 1.48 μs | 15.6250 |       - | 378.79 KB |
