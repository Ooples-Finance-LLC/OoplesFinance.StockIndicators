```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Qema** | **1000**  |   **347.9 μs** |  **2.77 μs** | **1.45 μs** | **15.6250** |       **-** | **356.29 KB** |
| BuilderLatestOnly | QuanTAlib.Qema | 1000  |   356.2 μs | 11.87 μs | 7.85 μs | 17.5781 |       - | 308.42 KB |
| **BuilderFull**       | **QuanTAlib.Qema** | **10000** | **1,372.5 μs** |  **5.92 μs** | **3.10 μs** | **46.8750** | **15.6250** | **848.86 KB** |
| BuilderLatestOnly | QuanTAlib.Qema | 10000 | 1,473.0 μs | 12.92 μs | 7.69 μs | 15.6250 |       - | 378.77 KB |
