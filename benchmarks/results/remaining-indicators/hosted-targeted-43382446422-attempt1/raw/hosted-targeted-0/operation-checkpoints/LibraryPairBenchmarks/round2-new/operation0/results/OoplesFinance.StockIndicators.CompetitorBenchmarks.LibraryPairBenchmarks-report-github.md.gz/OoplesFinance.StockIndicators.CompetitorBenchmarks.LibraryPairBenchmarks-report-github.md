```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error    | StdDev   | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|---------:|---------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Qema** |   **353.6 μs** |  **5.90 μs** |  **3.51 μs** |  **1.00** |  **365.92 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Qema |   124.4 μs |  4.28 μs |  2.83 μs |  0.35 |  213.09 KB |        0.58 |
|            |       |                |            |          |          |       |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Qema** | **1,407.6 μs** |  **7.41 μs** |  **4.41 μs** |  **1.00** |  **934.98 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Qema | 1,163.5 μs | 26.67 μs | 17.64 μs |  0.83 | 2038.27 KB |        2.18 |
