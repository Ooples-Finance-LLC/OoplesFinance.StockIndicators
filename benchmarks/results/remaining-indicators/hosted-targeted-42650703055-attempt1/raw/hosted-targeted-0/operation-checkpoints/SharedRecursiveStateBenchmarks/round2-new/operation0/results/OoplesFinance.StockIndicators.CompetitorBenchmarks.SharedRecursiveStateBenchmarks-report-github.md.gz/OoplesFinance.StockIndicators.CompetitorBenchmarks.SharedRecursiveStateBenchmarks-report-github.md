```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean         | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |-------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **145.872 μs** | **4.1458 μs** | **2.1683 μs** | **56.22** |    **1.09** |  **3.9063** |      **-** |  **64.88 KB** |        **8.24** |
| BuilderLatestOnly | Ad        | 1000  |   131.993 μs | 1.5829 μs | 0.8279 μs | 50.87 |    0.75 |  0.9766 |      - |  17.27 KB |        2.19 |
| NativeSingle      | Ad        | 1000  |     2.595 μs | 0.0553 μs | 0.0366 μs |  1.00 |    0.02 |  0.4730 |      - |   7.88 KB |        1.00 |
| NativeParallel    | Ad        | 1000  |    89.004 μs | 1.6682 μs | 1.1034 μs | 34.30 |    0.61 |  0.4883 |      - |   8.17 KB |        1.04 |
|                   |           |       |              |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **Ad**        | **10000** | **1,251.792 μs** | **8.7012 μs** | **4.5509 μs** | **56.69** |    **0.32** | **31.2500** | **7.8125** | **627.79 KB** |        **8.03** |
| BuilderLatestOnly | Ad        | 10000 | 1,236.260 μs | 6.2447 μs | 3.2661 μs | 55.99 |    0.29 |  7.8125 |      - | 157.94 KB |        2.02 |
| NativeSingle      | Ad        | 10000 |    22.082 μs | 0.1794 μs | 0.1067 μs |  1.00 |    0.01 |  4.7607 | 0.8545 |  78.19 KB |        1.00 |
| NativeParallel    | Ad        | 10000 |   116.588 μs | 4.2544 μs | 2.8141 μs |  5.28 |    0.12 |  3.9063 |      - |  78.48 KB |        1.00 |
