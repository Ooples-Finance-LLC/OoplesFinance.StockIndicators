```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |---------- |------ |-----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **136.7 μs** |  **3.47 μs** |  **1.81 μs** |  **3.9063** |      **-** |  **64.88 KB** |
| BuilderLatestOnly | Ad        | 1000  |   133.3 μs |  1.05 μs |  0.55 μs |  0.9766 |      - |  17.27 KB |
| **BuilderFull**       | **Ad**        | **10000** | **1,230.7 μs** | **14.52 μs** |  **7.59 μs** | **31.2500** | **7.8125** | **627.79 KB** |
| BuilderLatestOnly | Ad        | 10000 | 1,215.1 μs | 37.69 μs | 24.93 μs |  7.8125 |      - | 157.94 KB |
