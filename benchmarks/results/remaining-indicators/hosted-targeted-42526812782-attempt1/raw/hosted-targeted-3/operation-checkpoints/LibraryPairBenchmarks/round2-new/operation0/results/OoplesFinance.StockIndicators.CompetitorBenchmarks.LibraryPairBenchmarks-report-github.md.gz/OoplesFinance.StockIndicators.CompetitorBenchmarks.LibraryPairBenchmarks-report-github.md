```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDI [23]** |   **254.69 μs** |  **0.917 μs** |  **0.479 μs** |  **1.00** |    **0.00** |   **105.6 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDI [23] |    14.40 μs |  0.849 μs |  0.444 μs |  0.06 |    0.00 |   40.27 KB |        0.38 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDI [23]** | **2,302.38 μs** | **61.458 μs** | **36.572 μs** |  **1.00** |    **0.02** | **1036.33 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDI [23] |   139.45 μs |  1.799 μs |  0.941 μs |  0.06 |    0.00 |  330.31 KB |        0.32 |
