```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **217.292 μs** |  **0.7428 μs** | **0.4421 μs** | **30.53** |    **0.19** |       **-** |      **-** |  **64.93 KB** |        **8.41** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   215.493 μs |  0.7486 μs | 0.3916 μs | 30.28 |    0.18 |       - |      - |  17.37 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDI [23] | 1000  |     7.118 μs |  0.0653 μs | 0.0432 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 1000  |    94.452 μs |  1.7762 μs | 1.1749 μs | 13.27 |    0.18 |  1.9531 |      - |  27.25 KB |        3.53 |
|                   |                      |       |              |            |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **2,106.007 μs** | **12.0194 μs** | **7.1526 μs** | **29.62** |    **0.20** | **31.2500** |      **-** |  **627.9 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,069.906 μs |  5.4342 μs | 3.2338 μs | 29.12 |    0.18 |       - |      - | 158.11 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDI [23] | 10000 |    71.096 μs |  0.6875 μs | 0.4548 μs |  1.00 |    0.01 |  4.3945 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 10000 |   171.411 μs | 10.1074 μs | 6.6854 μs |  2.41 |    0.09 | 17.5781 | 2.9297 | 273.34 KB |        3.50 |
