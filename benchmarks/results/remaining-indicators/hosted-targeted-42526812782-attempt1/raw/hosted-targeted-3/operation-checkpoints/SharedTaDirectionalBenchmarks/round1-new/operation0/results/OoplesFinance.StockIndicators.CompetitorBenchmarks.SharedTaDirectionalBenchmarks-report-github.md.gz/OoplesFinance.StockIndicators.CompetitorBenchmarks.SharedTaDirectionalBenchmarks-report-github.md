```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **219.1 μs** |  **1.41 μs** |  **0.84 μs** |       **-** |  **64.97 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   221.5 μs |  9.56 μs |  5.69 μs |       - |  17.37 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **2,121.4 μs** | **45.90 μs** | **27.31 μs** | **31.2500** | **627.94 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,081.6 μs |  8.93 μs |  4.67 μs |       - |  158.1 KB |
