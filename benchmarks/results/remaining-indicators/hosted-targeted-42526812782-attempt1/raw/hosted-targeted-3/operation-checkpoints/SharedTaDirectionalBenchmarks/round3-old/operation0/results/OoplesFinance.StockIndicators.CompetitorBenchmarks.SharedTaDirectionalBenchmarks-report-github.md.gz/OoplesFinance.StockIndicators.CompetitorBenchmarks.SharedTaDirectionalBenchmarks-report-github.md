```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **217.6 μs** |  **4.34 μs** |  **2.58 μs** |       **-** |  **64.97 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   215.7 μs |  1.16 μs |  0.61 μs |       - |  17.37 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **2,094.7 μs** | **36.02 μs** | **18.84 μs** | **31.2500** | **627.93 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,077.9 μs | 14.68 μs |  7.68 μs |       - | 158.09 KB |
