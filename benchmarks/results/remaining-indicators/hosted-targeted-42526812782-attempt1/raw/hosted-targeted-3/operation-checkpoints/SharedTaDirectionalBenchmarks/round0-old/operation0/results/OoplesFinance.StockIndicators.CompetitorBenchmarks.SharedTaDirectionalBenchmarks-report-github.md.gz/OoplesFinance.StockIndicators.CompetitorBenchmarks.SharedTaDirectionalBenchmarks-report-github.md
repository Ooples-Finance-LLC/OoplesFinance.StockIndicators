```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error   | StdDev  | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **215.1 μs** | **1.36 μs** | **0.71 μs** |       **-** |  **64.97 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   213.1 μs | 1.52 μs | 0.79 μs |       - |  17.37 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **2,069.7 μs** | **7.70 μs** | **4.03 μs** | **31.2500** | **627.93 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,061.7 μs | 7.74 μs | 4.61 μs |       - |  158.1 KB |
