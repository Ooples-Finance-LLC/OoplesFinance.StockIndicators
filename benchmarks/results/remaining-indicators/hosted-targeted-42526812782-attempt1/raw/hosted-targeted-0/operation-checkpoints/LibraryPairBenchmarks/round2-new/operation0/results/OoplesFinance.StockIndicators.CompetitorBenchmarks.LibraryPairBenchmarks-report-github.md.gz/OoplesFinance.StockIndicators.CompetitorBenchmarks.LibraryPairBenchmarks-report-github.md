```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDM [22]** |   **186.06 μs** |  **7.411 μs** |  **3.876 μs** |  **1.00** |    **0.03** |  **105.64 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDM [22] |    16.84 μs |  1.519 μs |  0.795 μs |  0.09 |    0.00 |   40.27 KB |        0.38 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDM [22]** | **1,398.54 μs** | **59.426 μs** | **39.307 μs** |  **1.00** |    **0.04** | **1035.99 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDM [22] |   163.86 μs |  5.177 μs |  3.081 μs |  0.12 |    0.00 |  330.63 KB |        0.32 |
