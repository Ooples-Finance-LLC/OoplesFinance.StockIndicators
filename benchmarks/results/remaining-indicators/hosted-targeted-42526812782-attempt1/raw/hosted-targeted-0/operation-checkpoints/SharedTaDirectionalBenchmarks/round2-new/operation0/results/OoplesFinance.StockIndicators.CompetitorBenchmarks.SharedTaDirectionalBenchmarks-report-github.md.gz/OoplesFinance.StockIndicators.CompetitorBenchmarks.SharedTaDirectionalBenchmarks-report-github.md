```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev   | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|---------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **123.19 μs** |  **7.248 μs** | **4.794 μs** | **12.11** |    **0.45** |  **3.9063** |      **-** |  **64.93 KB** |        **8.41** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   117.05 μs |  2.135 μs | 1.117 μs | 11.51 |    0.12 |  0.9766 |      - |  17.36 KB |        2.25 |
| NativeSingle      | TaLib(...)lusDM [22] | 1000  |    10.17 μs |  0.089 μs | 0.059 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 1000  |    97.15 μs |  1.542 μs | 0.806 μs |  9.55 |    0.09 |  1.9531 |      - |  27.23 KB |        3.53 |
|                   |                      |       |             |           |          |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **1,147.10 μs** | **11.869 μs** | **6.208 μs** | **11.16** |    **0.10** | **31.2500** | **7.8125** | **627.84 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 1,145.09 μs | 10.513 μs | 6.256 μs | 11.14 |    0.10 |  7.8125 |      - | 158.05 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDM [22] | 10000 |   102.83 μs |  1.182 μs | 0.782 μs |  1.00 |    0.01 |  3.9063 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 10000 |   207.22 μs | 11.671 μs | 7.720 μs |  2.02 |    0.07 | 17.5781 | 1.9531 | 273.34 KB |        3.50 |
