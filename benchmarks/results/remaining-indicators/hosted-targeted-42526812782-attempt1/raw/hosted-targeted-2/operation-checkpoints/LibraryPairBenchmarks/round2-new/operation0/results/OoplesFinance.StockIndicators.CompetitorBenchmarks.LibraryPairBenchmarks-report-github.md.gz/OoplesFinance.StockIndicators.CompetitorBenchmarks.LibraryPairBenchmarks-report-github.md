```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDI [22]** |   **141.84 μs** |  **6.424 μs** |  **3.360 μs** |  **1.00** |    **0.03** |  **105.64 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDI [22] |    11.45 μs |  2.901 μs |  1.919 μs |  0.08 |    0.01 |   40.55 KB |        0.38 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDI [22]** | **1,361.99 μs** | **36.896 μs** | **19.297 μs** |  **1.00** |    **0.02** | **1031.73 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDI [22] |    95.49 μs |  4.221 μs |  2.207 μs |  0.07 |    0.00 |  323.14 KB |        0.31 |
