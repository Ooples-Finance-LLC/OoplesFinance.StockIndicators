```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **117.074 μs** |  **3.6102 μs** |  **2.1484 μs** | **22.62** |    **0.46** |  **3.9063** |      **-** |  **64.97 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   116.829 μs |  2.9593 μs |  1.7610 μs | 22.57 |    0.40 |  0.9766 |      - |  17.36 KB |        2.25 |
| NativeSingle      | TaLib(...)lusDI [22] | 1000  |     5.177 μs |  0.0988 μs |  0.0588 μs |  1.00 |    0.02 |  0.4578 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 1000  |    71.653 μs |  1.3684 μs |  0.8143 μs | 13.84 |    0.21 |  1.9531 |      - |  27.25 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **1,185.286 μs** | **20.2137 μs** | **12.0289 μs** | **23.21** |    **0.44** | **31.2500** | **7.8125** | **627.81 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 1,152.104 μs | 40.0942 μs | 23.8594 μs | 22.56 |    0.57 |  7.8125 |      - | 158.01 KB |        2.02 |
| NativeSingle      | TaLib(...)lusDI [22] | 10000 |    51.080 μs |  1.4935 μs |  0.8888 μs |  1.00 |    0.02 |  4.3945 |      - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 10000 |   127.427 μs |  3.8343 μs |  2.2817 μs |  2.50 |    0.06 | 17.5781 | 3.9063 | 273.34 KB |        3.50 |
