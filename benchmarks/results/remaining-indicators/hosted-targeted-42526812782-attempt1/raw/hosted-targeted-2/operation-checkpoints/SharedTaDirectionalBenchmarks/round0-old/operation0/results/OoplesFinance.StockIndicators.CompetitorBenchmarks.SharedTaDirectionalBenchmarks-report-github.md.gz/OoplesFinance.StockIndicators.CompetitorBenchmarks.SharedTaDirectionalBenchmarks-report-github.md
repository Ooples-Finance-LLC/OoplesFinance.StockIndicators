```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **110.4 μs** |  **1.10 μs** |  **0.66 μs** |  **3.9063** |      **-** |  **64.97 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   108.3 μs |  0.81 μs |  0.42 μs |  0.9766 |      - |  17.36 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **1,104.8 μs** | **34.52 μs** | **20.54 μs** | **31.2500** | **7.8125** | **627.84 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 1,085.0 μs | 30.15 μs | 19.94 μs |  7.8125 |      - | 158.03 KB |
