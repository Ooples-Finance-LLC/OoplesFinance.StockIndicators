```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |------------:|-----------:|----------:|------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **446.59 μs** |  **73.193 μs** | **48.413 μs** | **25.33** |    **2.62** |      **-** |  **64.97 KB** |        **8.42** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   365.04 μs |   1.564 μs |  0.931 μs | 20.70 |    0.06 |      - |  17.37 KB |        2.25 |
| NativeSingle      | TaLib.Functions.Dx | 1000  |    17.63 μs |   0.048 μs |  0.028 μs |  1.00 |    0.00 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 1000  |    76.68 μs |   3.900 μs |  2.321 μs |  4.35 |    0.13 |      - |  27.25 KB |        3.53 |
|                   |                    |       |             |            |           |       |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **4,005.70 μs** | **154.916 μs** | **92.188 μs** | **22.56** |    **0.50** |      **-** |    **628 KB** |        **8.05** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 3,962.32 μs |  90.702 μs | 53.975 μs | 22.32 |    0.30 |      - | 158.18 KB |        2.03 |
| NativeSingle      | TaLib.Functions.Dx | 10000 |   177.54 μs |   1.060 μs |  0.631 μs |  1.00 |    0.00 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 10000 |   246.11 μs |  21.585 μs | 14.277 μs |  1.39 |    0.08 | 1.9531 | 273.35 KB |        3.50 |
