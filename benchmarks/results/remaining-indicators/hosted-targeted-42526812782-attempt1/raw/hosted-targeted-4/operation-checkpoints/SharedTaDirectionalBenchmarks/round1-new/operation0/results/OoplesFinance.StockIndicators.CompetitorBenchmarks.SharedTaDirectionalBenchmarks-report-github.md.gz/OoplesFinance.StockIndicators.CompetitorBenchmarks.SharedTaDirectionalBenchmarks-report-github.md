```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **365.8 μs** |  **3.03 μs** |  **1.81 μs** |  **64.97 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   358.7 μs |  4.87 μs |  2.55 μs |  17.38 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **3,910.3 μs** | **51.84 μs** | **30.85 μs** | **627.92 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 3,838.2 μs | 17.04 μs |  8.91 μs | 158.17 KB |
