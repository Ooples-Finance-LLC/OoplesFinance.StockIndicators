```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **394.0 μs** |  **2.80 μs** |  **1.47 μs** |  **64.97 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   381.3 μs |  4.97 μs |  2.60 μs |  17.38 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **4,098.8 μs** | **44.72 μs** | **23.39 μs** | **628.01 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 4,029.8 μs | 35.33 μs | 21.03 μs | 158.23 KB |
