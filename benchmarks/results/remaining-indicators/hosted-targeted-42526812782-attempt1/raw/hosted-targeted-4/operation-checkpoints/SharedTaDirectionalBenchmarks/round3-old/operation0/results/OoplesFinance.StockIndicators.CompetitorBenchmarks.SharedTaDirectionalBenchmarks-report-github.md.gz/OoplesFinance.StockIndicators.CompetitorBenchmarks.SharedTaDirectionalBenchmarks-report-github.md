```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **387.9 μs** |  **2.86 μs** |  **1.50 μs** |  **64.93 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   383.6 μs |  3.18 μs |  1.66 μs |  17.37 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **4,100.3 μs** | **44.66 μs** | **26.58 μs** | **627.91 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 4,037.8 μs | 34.02 μs | 20.25 μs | 158.17 KB |
