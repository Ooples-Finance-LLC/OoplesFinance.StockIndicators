```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Dx** |   **478.98 μs** | **20.159 μs** | **11.996 μs** |  **1.00** |    **0.03** |  **105.64 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Dx |    26.37 μs |  2.895 μs |  1.915 μs |  0.06 |    0.00 |   40.88 KB |        0.39 |
|            |       |                    |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Dx** | **4,271.30 μs** | **52.826 μs** | **34.941 μs** |  **1.00** |    **0.01** | **1035.34 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Dx |   217.19 μs | 14.982 μs |  9.910 μs |  0.05 |    0.00 |  330.92 KB |        0.32 |
