```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **220.186 μs** | **12.9054 μs** |  **8.5361 μs** | **23.98** |    **1.02** |       **-** |       **-** |  **65.18 KB** |        **8.61** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   212.825 μs |  8.8065 μs |  5.8249 μs | 23.18 |    0.78 |       - |       - |  17.58 KB |        2.32 |
| NativeSingle      | TaLib.Functions.Adx | 1000  |     9.185 μs |  0.3105 μs |  0.2054 μs |  1.00 |    0.03 |  0.4272 |       - |   7.57 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 1000  |    74.342 μs |  2.4106 μs |  1.5945 μs |  8.10 |    0.24 |  1.9531 |       - |  26.71 KB |        3.53 |
|                   |                     |       |              |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **2,449.215 μs** | **53.7340 μs** | **35.5417 μs** | **26.76** |    **0.78** | **31.2500** | **15.6250** | **630.71 KB** |        **8.10** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 2,303.230 μs | 52.0332 μs | 34.4168 μs | 25.16 |    0.74 |       - |       - | 160.86 KB |        2.07 |
| NativeSingle      | TaLib.Functions.Adx | 10000 |    91.592 μs |  3.8113 μs |  2.5209 μs |  1.00 |    0.04 |  4.3945 |       - |  77.88 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 10000 |   167.497 μs | 13.4345 μs |  8.8861 μs |  1.83 |    0.10 | 17.5781 |  3.9063 | 272.81 KB |        3.50 |
