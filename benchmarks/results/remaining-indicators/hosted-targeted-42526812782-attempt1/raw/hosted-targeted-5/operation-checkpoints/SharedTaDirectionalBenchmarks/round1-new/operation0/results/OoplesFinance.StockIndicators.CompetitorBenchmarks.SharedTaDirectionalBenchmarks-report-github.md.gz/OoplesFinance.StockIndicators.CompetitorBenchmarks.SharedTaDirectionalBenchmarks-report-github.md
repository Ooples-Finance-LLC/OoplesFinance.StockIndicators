```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **208.6 μs** |  **1.50 μs** |  **0.89 μs** |       **-** |       **-** |  **65.18 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   213.8 μs | 10.63 μs |  7.03 μs |       - |       - |  17.58 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **2,405.3 μs** | **88.82 μs** | **58.75 μs** | **31.2500** | **15.6250** | **630.66 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 2,318.0 μs | 62.68 μs | 41.46 μs |       - |       - | 160.87 KB |
