```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **216.9 μs** |  **3.46 μs** |  **1.81 μs** |  **3.9063** |       **-** |  **65.18 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   212.9 μs |  2.32 μs |  1.21 μs |       - |       - |  17.58 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **2,366.5 μs** | **86.57 μs** | **57.26 μs** | **31.2500** | **15.6250** | **630.64 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 2,325.8 μs | 42.15 μs | 22.05 μs |       - |       - | 160.81 KB |
