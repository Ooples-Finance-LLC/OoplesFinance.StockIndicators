```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adx** |   **288.63 μs** | **11.846 μs** |  **7.835 μs** |  **1.00** |    **0.04** | **105.86 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adx |    12.12 μs |  1.712 μs |  0.896 μs |  0.04 |    0.00 |  35.68 KB |        0.34 |
|            |       |                     |             |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adx** | **2,509.21 μs** | **19.393 μs** | **11.541 μs** |  **1.00** |    **0.01** | **1032.3 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adx |   131.07 μs |  4.372 μs |  2.601 μs |  0.05 |    0.00 | 325.67 KB |        0.32 |
