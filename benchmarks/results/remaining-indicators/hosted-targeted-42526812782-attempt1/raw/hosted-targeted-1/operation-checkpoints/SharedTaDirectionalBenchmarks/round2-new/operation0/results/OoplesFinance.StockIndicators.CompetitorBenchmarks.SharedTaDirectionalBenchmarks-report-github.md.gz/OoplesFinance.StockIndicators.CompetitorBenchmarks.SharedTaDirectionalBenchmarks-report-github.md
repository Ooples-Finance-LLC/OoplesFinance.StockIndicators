```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |    **95.350 μs** |  **3.7326 μs** |  **2.2212 μs** | **10.46** |    **0.23** |  **3.9063** |      **-** |  **64.97 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |    88.386 μs |  0.3154 μs |  0.1650 μs |  9.70 |    0.03 |  0.9766 |      - |  17.36 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDM [23] | 1000  |     9.112 μs |  0.0440 μs |  0.0291 μs |  1.00 |    0.00 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 1000  |    86.445 μs |  1.6809 μs |  1.1118 μs |  9.49 |    0.12 |  1.4648 |      - |  27.23 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,040.568 μs** | **38.9449 μs** | **25.7597 μs** | **11.47** |    **0.27** | **31.2500** | **7.8125** | **627.85 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 1,001.974 μs |  1.5560 μs |  0.8138 μs | 11.05 |    0.02 |  7.8125 |      - | 158.02 KB |        2.02 |
| NativeSingle      | TaLib(...)nusDM [23] | 10000 |    90.697 μs |  0.1746 μs |  0.1155 μs |  1.00 |    0.00 |  4.3945 |      - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 10000 |   177.542 μs |  5.3535 μs |  3.5410 μs |  1.96 |    0.04 | 17.5781 | 2.9297 | 273.33 KB |        3.50 |
