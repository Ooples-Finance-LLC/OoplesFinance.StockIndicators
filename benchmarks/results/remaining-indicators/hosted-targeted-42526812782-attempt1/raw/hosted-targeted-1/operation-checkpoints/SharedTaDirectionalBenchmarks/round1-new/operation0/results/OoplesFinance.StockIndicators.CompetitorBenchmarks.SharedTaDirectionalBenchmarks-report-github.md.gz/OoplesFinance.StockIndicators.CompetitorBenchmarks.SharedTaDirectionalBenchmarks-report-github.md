```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |------------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |    **94.93 μs** | **0.813 μs** | **0.484 μs** |  **3.9063** |      **-** |  **64.97 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |    89.98 μs | 1.128 μs | 0.590 μs |  0.9766 |      - |  17.36 KB |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,037.92 μs** | **6.709 μs** | **3.509 μs** | **31.2500** | **7.8125** | **627.87 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 1,007.75 μs | 9.542 μs | 5.678 μs |  7.8125 |      - | 158.02 KB |
