```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **434.57 μs** |  **3.167 μs** |  **1.656 μs** | **26.10** |    **0.15** |       **-** |      **-** |  **66.26 KB** |        **4.42** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   429.78 μs |  6.522 μs |  3.881 μs | 25.81 |    0.25 |       - |      - |  18.67 KB |        1.25 |
| NativeSingle      | TaLib.Functions.Adxr | 1000  |    16.65 μs |  0.157 μs |  0.082 μs |  1.00 |    0.01 |  0.8545 |      - |  14.99 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 1000  |   104.57 μs |  2.866 μs |  1.499 μs |  6.28 |    0.09 |  2.9297 |      - |  45.44 KB |        3.03 |
|                   |                      |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **4,585.16 μs** | **45.569 μs** | **27.118 μs** | **26.78** |    **0.56** | **31.2500** |      **-** | **631.94 KB** |        **4.06** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 4,558.40 μs | 15.866 μs |  8.298 μs | 26.63 |    0.54 |       - |      - | 162.11 KB |        1.04 |
| NativeSingle      | TaLib.Functions.Adxr | 10000 |   171.26 μs |  5.545 μs |  3.668 μs |  1.00 |    0.03 |  8.7891 | 0.9766 | 155.62 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 10000 |   313.13 μs | 20.222 μs | 13.376 μs |  1.83 |    0.08 | 29.2969 | 9.7656 | 467.32 KB |        3.00 |
