```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **431.4 μs** |  **4.18 μs** |  **2.49 μs** |       **-** |  **66.26 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   428.0 μs |  3.18 μs |  1.89 μs |       - |  18.67 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **4,534.5 μs** |  **6.88 μs** |  **3.60 μs** | **31.2500** | **631.96 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 4,485.2 μs | 28.17 μs | 14.73 μs |       - | 162.13 KB |
