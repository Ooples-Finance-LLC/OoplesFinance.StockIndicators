```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **431.2 μs** |  **4.20 μs** |  **2.20 μs** |       **-** |  **66.26 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   426.2 μs |  8.68 μs |  5.74 μs |       - |  18.67 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **4,514.6 μs** | **31.98 μs** | **19.03 μs** | **31.2500** | **631.96 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 4,477.4 μs | 18.55 μs | 11.04 μs |       - |  162.1 KB |
