```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio  | RatioSD | Gen0      | Gen1     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|-------:|--------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **TaLib(...)bands [24]** | **1000**  | **3,580.40 μs** | **661.113 μs** | **437.285 μs** | **277.68** |   **36.23** |  **400.0000** | **100.0000** |  **3703.51 KB** |       **94.75** |
| BuilderLatestOnly | TaLib(...)bands [24] | 1000  | 3,237.41 μs | 347.945 μs | 207.057 μs | 251.08 |   21.16 |  437.5000 |  62.5000 |   3656.1 KB |       93.54 |
| NativeSingle      | TaLib(...)bands [24] | 1000  |    12.94 μs |   1.331 μs |   0.792 μs |   1.00 |    0.08 |    4.7607 |   0.3662 |    39.09 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [24] | 1000  |    34.52 μs |   0.549 μs |   0.327 μs |   2.68 |    0.16 |   30.2734 |   6.5918 |   201.88 KB |        5.17 |
|                   |                      |       |             |            |            |        |         |           |          |             |             |
| **BuilderFull**       | **TaLib(...)bands [24]** | **10000** | **8,320.10 μs** | **179.441 μs** | **106.783 μs** |  **72.43** |    **2.37** | **4545.4545** | **272.7273** | **37512.02 KB** |       **96.02** |
| BuilderLatestOnly | TaLib(...)bands [24] | 10000 | 8,084.69 μs | 184.964 μs | 122.342 μs |  70.38 |    2.36 | 4538.4615 | 384.6154 | 37042.15 KB |       94.82 |
| NativeSingle      | TaLib(...)bands [24] | 10000 |   114.97 μs |   5.593 μs |   3.700 μs |   1.00 |    0.04 |   46.8750 |  15.6250 |   390.66 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [24] | 10000 |   298.92 μs |  46.453 μs |  30.726 μs |   2.60 |    0.27 |  257.8125 | 197.2656 |  1994.87 KB |        5.11 |
