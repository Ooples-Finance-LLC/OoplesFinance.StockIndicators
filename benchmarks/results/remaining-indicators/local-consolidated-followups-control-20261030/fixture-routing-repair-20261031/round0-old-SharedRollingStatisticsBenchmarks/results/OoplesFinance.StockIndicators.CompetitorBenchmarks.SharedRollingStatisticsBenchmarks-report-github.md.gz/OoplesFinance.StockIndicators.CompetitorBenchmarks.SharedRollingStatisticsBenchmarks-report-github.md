```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |--------------------- |------ |------------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetCci**       | **1000**  |    **80.08 μs** |  **2.168 μs** |  **1.290 μs** |   **7.8125** |        **-** |   **68.74 KB** |
| BuilderLatestOnly | Skender.GetCci       | 1000  |    62.80 μs |  2.492 μs |  1.648 μs |   2.4414 |        - |   21.09 KB |
| **BuilderFull**       | **Skender.GetCci**       | **10000** |   **656.78 μs** |  **8.100 μs** |  **4.820 μs** |  **74.2188** |  **70.3125** |  **631.58 KB** |
| BuilderLatestOnly | Skender.GetCci       | 10000 |   605.48 μs | 49.593 μs | 29.512 μs |  19.5313 |   3.9063 |  161.76 KB |
| **BuilderFull**       | **Skend(...)lysis [22]** | **1000**  |   **138.10 μs** |  **8.470 μs** |  **5.040 μs** |  **19.5313** |   **4.8828** |  **160.48 KB** |
| BuilderLatestOnly | Skend(...)lysis [22] | 1000  |   137.73 μs |  2.575 μs |  1.703 μs |  13.6719 |   1.9531 |   112.9 KB |
| **BuilderFull**       | **Skend(...)lysis [22]** | **10000** | **1,374.71 μs** |  **7.730 μs** |  **5.113 μs** | **156.2500** | **101.5625** | **1288.93 KB** |
| BuilderLatestOnly | Skend(...)lysis [22] | 10000 | 1,322.55 μs | 12.566 μs |  8.311 μs |  93.7500 |  54.6875 |  819.11 KB |
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **1000**  |    **52.14 μs** |  **2.032 μs** |  **1.344 μs** |  **10.7422** |   **1.4648** |   **89.29 KB** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 1000  |    48.47 μs |  0.717 μs |  0.475 μs |   5.3711 |   0.2441 |   41.44 KB |
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **10000** |   **463.26 μs** |  **4.006 μs** |  **2.650 μs** |  **70.3125** |  **35.1563** |  **581.88 KB** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 10000 |   423.50 μs |  3.644 μs |  2.410 μs |  11.7188 |        - |  111.79 KB |
| **BuilderFull**       | **Trady(...)Index [37]** | **1000**  |    **87.97 μs** |  **0.739 μs** |  **0.489 μs** |   **9.2773** |   **1.4648** |   **76.17 KB** |
| BuilderLatestOnly | Trady(...)Index [37] | 1000  |    82.01 μs |  7.245 μs |  4.792 μs |   3.4180 |        - |   28.59 KB |
| **BuilderFull**       | **Trady(...)Index [37]** | **10000** |   **770.68 μs** |  **8.150 μs** |  **5.391 μs** |  **78.1250** |  **31.2500** |  **639.08 KB** |
| BuilderLatestOnly | Trady(...)Index [37] | 10000 |   724.57 μs |  3.141 μs |  2.077 μs |  19.5313 |   3.9063 |  169.26 KB |
