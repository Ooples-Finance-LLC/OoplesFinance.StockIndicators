```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0      | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|----------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetPrs** | **1000**  |   **297.17 μs** |  **17.785 μs** |   **9.302 μs** |  **4.70** |    **0.15** |  **125.0000** |  **31.2500** |        **-** | **1058.56 KB** |        **6.42** |
| BuilderLatestOnly | Skender.GetPrs | 1000  |   276.91 μs |  12.513 μs |   8.277 μs |  4.38 |    0.14 |  123.0469 |  19.5313 |        - | 1010.96 KB |        6.13 |
| NativeSingle      | Skender.GetPrs | 1000  |    63.29 μs |   1.683 μs |   0.880 μs |  1.00 |    0.02 |   20.0195 |   3.4180 |        - |  164.79 KB |        1.00 |
| NativeParallel    | Skender.GetPrs | 1000  |    32.01 μs |   2.055 μs |   1.223 μs |  0.51 |    0.02 |   26.6113 |   6.3477 |        - |  200.91 KB |        1.22 |
|                   |                |       |             |            |            |       |         |           |          |          |            |             |
| **BuilderFull**       | **Skender.GetPrs** | **10000** | **3,277.45 μs** | **444.719 μs** | **294.154 μs** |  **1.60** |    **0.16** | **1171.8750** | **531.2500** |  **15.6250** | **9497.82 KB** |        **5.78** |
| BuilderLatestOnly | Skender.GetPrs | 10000 | 3,148.11 μs | 306.657 μs | 202.834 μs |  1.54 |    0.12 | 1109.3750 | 546.8750 |        - | 9027.47 KB |        5.50 |
| NativeSingle      | Skender.GetPrs | 10000 | 2,052.21 μs | 152.178 μs |  90.559 μs |  1.00 |    0.06 |  234.3750 | 140.6250 | 125.0000 |  1642.7 KB |        1.00 |
| NativeParallel    | Skender.GetPrs | 10000 |   404.54 μs |  67.721 μs |  44.793 μs |  0.20 |    0.02 |  253.9063 | 167.9688 |        - | 1747.75 KB |        1.06 |
