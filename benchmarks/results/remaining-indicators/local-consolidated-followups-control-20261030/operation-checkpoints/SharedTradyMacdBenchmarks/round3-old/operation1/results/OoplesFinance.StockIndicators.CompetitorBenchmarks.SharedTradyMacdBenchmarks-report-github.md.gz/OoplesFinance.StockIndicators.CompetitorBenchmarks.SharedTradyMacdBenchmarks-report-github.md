```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |    **724.1 μs** |    **11.17 μs** |     **6.65 μs** |  **0.34** |    **0.01** |         **-** |         **-** |         **-** |   **113.03 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |    715.2 μs |    10.14 μs |     5.31 μs |  0.34 |    0.01 |    7.8125 |         - |         - |    65.38 KB |        0.02 |
| NativeSingle      | Movin(...)ogram [43] | 1000  |  2,100.3 μs |    59.63 μs |    35.48 μs |  1.00 |    0.02 |  406.2500 |  203.1250 |   46.8750 |  3389.12 KB |        1.00 |
| NativeParallel    | Movin(...)ogram [43] | 1000  |  1,837.6 μs |    24.64 μs |    12.89 μs |  0.88 |    0.02 | 1140.6250 |  968.7500 |         - |  8315.63 KB |        2.45 |
|                   |                      |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** |  **7,110.7 μs** |   **181.35 μs** |   **119.95 μs** |  **0.27** |    **0.03** |   **76.9231** |         **-** |         **-** |  **1101.27 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 |  7,129.9 μs |   449.92 μs |   297.60 μs |  0.28 |    0.03 |   66.6667 |         - |         - |   631.34 KB |        0.02 |
| NativeSingle      | Movin(...)ogram [43] | 10000 | 26,139.3 μs | 3,806.48 μs | 2,517.75 μs |  1.01 |    0.14 | 3250.0000 | 2000.0000 | 1000.0000 |  33358.9 KB |        1.00 |
| NativeParallel    | Movin(...)ogram [43] | 10000 | 30,797.9 μs | 4,035.17 μs | 2,669.02 μs |  1.19 |    0.15 | 7250.0000 | 2750.0000 | 1500.0000 | 86835.45 KB |        2.60 |
