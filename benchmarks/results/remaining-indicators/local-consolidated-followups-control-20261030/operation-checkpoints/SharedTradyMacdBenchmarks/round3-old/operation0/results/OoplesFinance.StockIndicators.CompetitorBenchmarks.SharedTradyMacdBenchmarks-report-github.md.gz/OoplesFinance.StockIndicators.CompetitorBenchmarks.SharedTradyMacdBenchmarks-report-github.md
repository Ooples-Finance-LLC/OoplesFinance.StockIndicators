```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |    **742.0 μs** |    **33.66 μs** |    **20.03 μs** |  **0.35** |    **0.02** |         **-** |         **-** |         **-** |   **144.38 KB** |        **0.04** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |    806.7 μs |   125.33 μs |    82.90 μs |  0.38 |    0.04 |   11.7188 |         - |         - |    96.73 KB |        0.03 |
| NativeSingle      | Movin(...)gence [34] | 1000  |  2,109.0 μs |   186.39 μs |   123.29 μs |  1.00 |    0.08 |  375.0000 |  265.6250 |   46.8750 |  3232.19 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 1000  |  1,915.8 μs |    99.66 μs |    59.31 μs |  0.91 |    0.06 | 1156.2500 |  984.3750 |         - |  8368.82 KB |        2.59 |
|                   |                      |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** |  **7,424.4 μs** |   **400.84 μs** |   **238.53 μs** |  **0.28** |    **0.03** |  **142.8571** |   **71.4286** |         **-** |  **1413.86 KB** |        **0.04** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 |  7,274.7 μs |   121.12 μs |    72.08 μs |  0.27 |    0.03 |   83.3333 |         - |         - |   944.12 KB |        0.03 |
| NativeSingle      | Movin(...)gence [34] | 10000 | 26,835.5 μs | 4,491.08 μs | 2,970.57 μs |  1.01 |    0.16 | 3000.0000 | 1750.0000 | 1000.0000 | 31913.26 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 10000 | 28,801.9 μs | 6,364.75 μs | 4,209.89 μs |  1.09 |    0.20 | 7000.0000 | 2250.0000 | 1250.0000 | 87377.88 KB |        2.74 |
