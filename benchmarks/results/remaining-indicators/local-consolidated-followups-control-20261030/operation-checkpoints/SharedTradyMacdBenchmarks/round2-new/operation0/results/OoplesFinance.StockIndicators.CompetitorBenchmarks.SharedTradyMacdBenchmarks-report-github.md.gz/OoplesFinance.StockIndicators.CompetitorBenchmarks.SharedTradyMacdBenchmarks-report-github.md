```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |    **610.2 μs** |    **70.89 μs** |    **46.89 μs** |  **0.25** |    **0.02** |         **-** |         **-** |         **-** |   **105.03 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |    616.7 μs |    50.98 μs |    33.72 μs |  0.26 |    0.02 |    3.9063 |         - |         - |     57.4 KB |        0.02 |
| NativeSingle      | Movin(...)gence [34] | 1000  |  2,410.0 μs |   102.10 μs |    67.54 μs |  1.00 |    0.04 |  375.0000 |  265.6250 |   46.8750 |  3232.19 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 1000  |  1,944.7 μs |    67.58 μs |    35.35 μs |  0.81 |    0.03 | 1171.8750 |  984.3750 |   15.6250 |  8306.98 KB |        2.57 |
|                   |                      |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** |  **6,005.2 μs** |   **652.11 μs** |   **388.06 μs** |  **0.23** |    **0.03** |   **93.7500** |   **31.2500** |         **-** |  **1019.71 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 |  6,320.9 μs |   862.55 μs |   570.52 μs |  0.24 |    0.03 |   62.5000 |         - |         - |   550.16 KB |        0.02 |
| NativeSingle      | Movin(...)gence [34] | 10000 | 26,707.6 μs | 4,609.22 μs | 3,048.71 μs |  1.01 |    0.16 | 3000.0000 | 1750.0000 | 1000.0000 | 31913.27 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 10000 | 29,089.8 μs | 3,297.23 μs | 1,962.13 μs |  1.10 |    0.14 | 7000.0000 | 2250.0000 | 1250.0000 | 86751.36 KB |        2.72 |
