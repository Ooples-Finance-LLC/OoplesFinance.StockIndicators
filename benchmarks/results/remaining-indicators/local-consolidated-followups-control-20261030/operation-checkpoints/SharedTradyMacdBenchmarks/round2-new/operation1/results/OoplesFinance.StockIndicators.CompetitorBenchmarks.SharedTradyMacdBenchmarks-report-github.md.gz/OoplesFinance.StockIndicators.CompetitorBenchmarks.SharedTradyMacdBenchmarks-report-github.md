```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |    **532.2 μs** |    **56.90 μs** |    **37.63 μs** |  **0.24** |    **0.02** |         **-** |         **-** |         **-** |    **73.64 KB** |       **0.022** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |    543.2 μs |    33.40 μs |    22.09 μs |  0.25 |    0.01 |         - |         - |         - |    26.04 KB |       0.008 |
| NativeSingle      | Movin(...)ogram [43] | 1000  |  2,193.4 μs |    99.47 μs |    59.19 μs |  1.00 |    0.04 |  406.2500 |  203.1250 |   46.8750 |  3389.12 KB |       1.000 |
| NativeParallel    | Movin(...)ogram [43] | 1000  |  1,955.4 μs |    62.36 μs |    32.62 μs |  0.89 |    0.03 | 1156.2500 |  984.3750 |         - |  8315.63 KB |       2.454 |
|                   |                      |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** |  **5,407.9 μs** |   **797.21 μs** |   **527.30 μs** |  **0.18** |    **0.02** |   **62.5000** |   **31.2500** |         **-** |   **707.08 KB** |       **0.021** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 |  5,628.2 μs |   936.50 μs |   619.44 μs |  0.19 |    0.03 |         - |         - |         - |   237.24 KB |       0.007 |
| NativeSingle      | Movin(...)ogram [43] | 10000 | 30,430.4 μs | 4,118.98 μs | 2,724.45 μs |  1.01 |    0.13 | 3250.0000 | 2000.0000 | 1000.0000 | 33358.89 KB |       1.000 |
| NativeParallel    | Movin(...)ogram [43] | 10000 | 28,151.0 μs | 4,299.77 μs | 2,844.03 μs |  0.93 |    0.12 | 7750.0000 | 3500.0000 | 2000.0000 | 86841.85 KB |       2.603 |
