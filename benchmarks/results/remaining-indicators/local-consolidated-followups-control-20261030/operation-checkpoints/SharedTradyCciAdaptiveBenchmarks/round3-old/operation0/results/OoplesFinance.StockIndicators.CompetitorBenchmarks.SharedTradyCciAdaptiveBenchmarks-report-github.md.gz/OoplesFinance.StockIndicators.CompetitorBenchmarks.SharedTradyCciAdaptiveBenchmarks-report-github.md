```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean          | Error        | StdDev       | Ratio | RatioSD | Gen0      | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |--------------:|-------------:|-------------:|------:|--------:|----------:|---------:|---------:|------------:|------------:|
| **BuilderFull**       | **Commo(...)Index [21]** | **1000**  |      **89.91 μs** |    **14.414 μs** |     **8.577 μs** | **0.007** |    **0.00** |    **7.8125** |        **-** |        **-** |     **76.2 KB** |       **0.017** |
| BuilderLatestOnly | Commo(...)Index [21] | 1000  |      89.38 μs |     0.562 μs |     0.372 μs | 0.007 |    0.00 |    3.4180 |        - |        - |    28.59 KB |       0.007 |
| NativeSingle      | Commo(...)Index [21] | 1000  |  12,715.17 μs |   350.710 μs |   208.702 μs | 1.000 |    0.02 |  500.0000 | 125.0000 |        - |  4398.15 KB |       1.000 |
| NativeParallel    | Commo(...)Index [21] | 1000  |   2,296.14 μs |    42.468 μs |    28.090 μs | 0.181 |    0.00 |  546.8750 | 171.8750 |        - |  4403.14 KB |       1.001 |
|                   |                      |       |               |              |              |       |         |           |          |          |             |             |
| **BuilderFull**       | **Commo(...)Index [21]** | **10000** |     **803.88 μs** |     **4.035 μs** |     **2.401 μs** | **0.006** |    **0.00** |   **78.1250** |  **31.2500** |        **-** |   **639.13 KB** |       **0.014** |
| BuilderLatestOnly | Commo(...)Index [21] | 10000 |     770.62 μs |     5.630 μs |     3.724 μs | 0.006 |    0.00 |   19.5313 |   3.9063 |        - |   169.26 KB |       0.004 |
| NativeSingle      | Commo(...)Index [21] | 10000 | 135,277.18 μs | 4,007.417 μs | 2,384.750 μs | 1.000 |    0.02 | 5500.0000 | 750.0000 | 250.0000 | 45275.79 KB |       1.000 |
| NativeParallel    | Commo(...)Index [21] | 10000 |  23,760.79 μs |   401.051 μs |   265.271 μs | 0.176 |    0.00 | 5400.0000 | 400.0000 |        - | 45330.54 KB |       1.001 |
