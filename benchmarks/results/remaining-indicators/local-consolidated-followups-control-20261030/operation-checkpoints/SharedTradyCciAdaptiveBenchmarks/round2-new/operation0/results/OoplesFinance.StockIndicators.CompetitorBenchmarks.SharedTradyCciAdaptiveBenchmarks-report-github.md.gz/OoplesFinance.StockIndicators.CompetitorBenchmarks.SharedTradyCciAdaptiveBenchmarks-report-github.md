```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean          | Error        | StdDev       | Ratio | RatioSD | Gen0      | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |--------------:|-------------:|-------------:|------:|--------:|----------:|---------:|---------:|------------:|------------:|
| **BuilderFull**       | **Commo(...)Index [21]** | **1000**  |      **93.92 μs** |     **3.525 μs** |     **2.098 μs** | **0.007** |    **0.00** |    **7.8125** |        **-** |        **-** |     **76.2 KB** |       **0.017** |
| BuilderLatestOnly | Commo(...)Index [21] | 1000  |      89.32 μs |     0.777 μs |     0.462 μs | 0.007 |    0.00 |    3.4180 |        - |        - |    28.59 KB |       0.007 |
| NativeSingle      | Commo(...)Index [21] | 1000  |  13,758.17 μs | 1,416.670 μs |   937.039 μs | 1.004 |    0.09 |  428.5714 | 142.8571 |        - |  4398.28 KB |       1.000 |
| NativeParallel    | Commo(...)Index [21] | 1000  |   2,527.65 μs |    85.355 μs |    50.793 μs | 0.184 |    0.01 |  546.8750 | 171.8750 |        - |  4403.15 KB |       1.001 |
|                   |                      |       |               |              |              |       |         |           |          |          |             |             |
| **BuilderFull**       | **Commo(...)Index [21]** | **10000** |     **809.91 μs** |    **29.870 μs** |    **17.775 μs** | **0.006** |    **0.00** |   **78.1250** |  **31.2500** |        **-** |   **639.13 KB** |       **0.014** |
| BuilderLatestOnly | Commo(...)Index [21] | 10000 |     770.61 μs |    18.573 μs |    12.285 μs | 0.005 |    0.00 |   15.6250 |        - |        - |   169.28 KB |       0.004 |
| NativeSingle      | Commo(...)Index [21] | 10000 | 141,521.78 μs | 5,094.312 μs | 3,369.572 μs | 1.001 |    0.03 | 5500.0000 | 750.0000 | 250.0000 | 45275.83 KB |       1.000 |
| NativeParallel    | Commo(...)Index [21] | 10000 |  25,002.76 μs | 1,988.455 μs | 1,315.240 μs | 0.177 |    0.01 | 5400.0000 | 400.0000 |        - |  45330.7 KB |       1.001 |
