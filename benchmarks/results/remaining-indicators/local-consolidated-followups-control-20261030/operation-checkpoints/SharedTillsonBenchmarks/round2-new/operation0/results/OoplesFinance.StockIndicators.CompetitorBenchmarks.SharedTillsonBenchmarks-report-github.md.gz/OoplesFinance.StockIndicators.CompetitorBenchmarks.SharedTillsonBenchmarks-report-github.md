```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation     | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |-------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetT3** | **1000**  |   **190.41 μs** |  **27.362 μs** |  **18.099 μs** |  **2.90** |    **0.30** |   **7.8125** |        **-** |        **-** |   **65.14 KB** |        **0.72** |
| BuilderLatestOnly | Skender.GetT3 | 1000  |   156.03 μs |   5.318 μs |   3.165 μs |  2.38 |    0.13 |   1.9531 |        - |        - |   17.58 KB |        0.19 |
| NativeSingle      | Skender.GetT3 | 1000  |    65.74 μs |   5.343 μs |   3.534 μs |  1.00 |    0.07 |  10.7422 |   0.9766 |        - |   90.24 KB |        1.00 |
| NativeParallel    | Skender.GetT3 | 1000  |    93.44 μs |   2.603 μs |   1.722 μs |  1.43 |    0.08 |  60.0586 |  18.5547 |        - |  415.91 KB |        4.61 |
|                   |               |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetT3** | **10000** | **1,710.32 μs** |  **60.558 μs** |  **40.055 μs** |  **1.93** |    **0.17** |  **62.5000** |  **15.6250** |        **-** |  **628.14 KB** |        **0.70** |
| BuilderLatestOnly | Skender.GetT3 | 10000 | 1,674.15 μs |  91.042 μs |  54.178 μs |  1.89 |    0.17 |  15.6250 |        - |        - |  158.34 KB |        0.18 |
| NativeSingle      | Skender.GetT3 | 10000 |   894.10 μs | 129.194 μs |  85.454 μs |  1.01 |    0.13 | 140.6250 |  93.7500 |  70.3125 |   899.5 KB |        1.00 |
| NativeParallel    | Skender.GetT3 | 10000 | 3,412.10 μs | 344.998 μs | 228.195 μs |  3.85 |    0.41 | 593.7500 | 531.2500 | 218.7500 | 4132.84 KB |        4.59 |
