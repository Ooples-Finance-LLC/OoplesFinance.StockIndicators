```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation    | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1    | Gen2   | Allocated | Alloc Ratio |
|------------------ |------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **QuanTAlib.T3** | **1000**  |   **201.73 μs** |  **11.096 μs** |   **7.340 μs** |  **5.41** |    **0.38** |   **7.8125** |       **-** |      **-** |  **65.14 KB** |        **1.34** |
| BuilderLatestOnly | QuanTAlib.T3 | 1000  |   184.25 μs |  18.758 μs |  12.407 μs |  4.94 |    0.44 |   1.9531 |       - |      - |  17.58 KB |        0.36 |
| NativeSingle      | QuanTAlib.T3 | 1000  |    37.45 μs |   3.891 μs |   2.574 μs |  1.00 |    0.09 |   5.8594 |  0.2441 | 0.2441 |  48.69 KB |        1.00 |
| NativeParallel    | QuanTAlib.T3 | 1000  |    67.29 μs |   1.905 μs |   1.260 μs |  1.80 |    0.12 |  24.9023 |  2.4414 | 2.4414 | 198.15 KB |        4.07 |
|                   |              |       |             |            |            |       |         |          |         |        |           |             |
| **BuilderFull**       | **QuanTAlib.T3** | **10000** | **1,913.14 μs** | **167.560 μs** | **110.830 μs** |  **4.59** |    **0.28** |  **62.5000** | **15.6250** |      **-** | **628.14 KB** |        **1.33** |
| BuilderLatestOnly | QuanTAlib.T3 | 10000 | 1,896.30 μs |  31.304 μs |  20.706 μs |  4.55 |    0.12 |  15.6250 |       - |      - | 158.34 KB |        0.34 |
| NativeSingle      | QuanTAlib.T3 | 10000 |   416.86 μs |  15.623 μs |  10.334 μs |  1.00 |    0.03 |  54.6875 |  7.8125 |      - | 470.59 KB |        1.00 |
| NativeParallel    | QuanTAlib.T3 | 10000 |   402.52 μs |   8.154 μs |   4.852 μs |  0.97 |    0.03 | 222.6563 | 42.9688 |      - | 1850.5 KB |        3.93 |
