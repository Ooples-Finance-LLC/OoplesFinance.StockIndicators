```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean         | Error       | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |-------------:|------------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.T3** | **1000**  |   **179.576 μs** |  **19.3205 μs** | **12.7793 μs** | **34.38** |    **2.45** |  **7.8125** |       **-** |  **65.18 KB** |        **9.34** |
| BuilderLatestOnly | TaLib.Functions.T3 | 1000  |   171.160 μs |   6.4065 μs |  4.2375 μs | 32.77 |    1.05 |  1.9531 |       - |  17.58 KB |        2.52 |
| NativeSingle      | TaLib.Functions.T3 | 1000  |     5.225 μs |   0.1793 μs |  0.1186 μs |  1.00 |    0.03 |  0.8240 |       - |   6.98 KB |        1.00 |
| NativeParallel    | TaLib.Functions.T3 | 1000  |    10.722 μs |   0.2032 μs |  0.1344 μs |  2.05 |    0.05 |  6.1646 |  0.2441 |   38.7 KB |        5.55 |
|                   |                    |       |              |             |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.T3** | **10000** | **1,762.029 μs** |  **71.0559 μs** | **46.9991 μs** | **31.96** |    **1.19** | **62.5000** | **15.6250** | **628.18 KB** |        **8.13** |
| BuilderLatestOnly | TaLib.Functions.T3 | 10000 | 1,729.857 μs | 118.8819 μs | 78.6330 μs | 31.38 |    1.61 | 15.6250 |       - | 158.32 KB |        2.05 |
| NativeSingle      | TaLib.Functions.T3 | 10000 |    55.168 μs |   2.6369 μs |  1.5692 μs |  1.00 |    0.04 |  9.2773 |       - |  77.29 KB |        1.00 |
| NativeParallel    | TaLib.Functions.T3 | 10000 |    85.304 μs |   4.6348 μs |  3.0656 μs |  1.55 |    0.07 | 60.0586 | 22.4609 | 425.43 KB |        5.50 |
