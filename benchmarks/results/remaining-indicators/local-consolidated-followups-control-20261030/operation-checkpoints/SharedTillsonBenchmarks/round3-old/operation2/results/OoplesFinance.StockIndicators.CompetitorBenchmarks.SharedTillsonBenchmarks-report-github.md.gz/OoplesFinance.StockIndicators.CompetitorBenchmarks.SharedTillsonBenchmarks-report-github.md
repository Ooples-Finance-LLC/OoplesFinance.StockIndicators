```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation    | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1    | Gen2   | Allocated | Alloc Ratio |
|------------------ |------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **QuanTAlib.T3** | **1000**  |   **166.91 μs** |   **5.382 μs** |   **3.560 μs** |  **5.34** |    **0.13** |   **7.8125** |       **-** |      **-** |  **65.18 KB** |        **1.34** |
| BuilderLatestOnly | QuanTAlib.T3 | 1000  |   160.08 μs |   6.737 μs |   4.009 μs |  5.13 |    0.14 |   1.9531 |       - |      - |  17.57 KB |        0.36 |
| NativeSingle      | QuanTAlib.T3 | 1000  |    31.24 μs |   0.864 μs |   0.452 μs |  1.00 |    0.02 |   5.8594 |  0.2441 | 0.2441 |  48.69 KB |        1.00 |
| NativeParallel    | QuanTAlib.T3 | 1000  |    65.63 μs |   2.752 μs |   1.638 μs |  2.10 |    0.06 |  24.9023 |  2.4414 | 2.4414 | 198.15 KB |        4.07 |
|                   |              |       |             |            |            |       |         |          |         |        |           |             |
| **BuilderFull**       | **QuanTAlib.T3** | **10000** | **1,793.80 μs** | **266.169 μs** | **176.055 μs** |  **6.26** |    **0.61** |  **62.5000** | **15.6250** |      **-** | **628.18 KB** |        **1.33** |
| BuilderLatestOnly | QuanTAlib.T3 | 10000 | 1,493.88 μs | 147.114 μs |  87.545 μs |  5.21 |    0.32 |  15.6250 |       - |      - | 158.27 KB |        0.34 |
| NativeSingle      | QuanTAlib.T3 | 10000 |   286.86 μs |  12.860 μs |   8.506 μs |  1.00 |    0.04 |  56.6406 |  9.7656 |      - | 470.58 KB |        1.00 |
| NativeParallel    | QuanTAlib.T3 | 10000 |   394.31 μs |  12.969 μs |   8.578 μs |  1.38 |    0.05 | 226.5625 | 46.8750 | 1.9531 | 1850.5 KB |        3.93 |
