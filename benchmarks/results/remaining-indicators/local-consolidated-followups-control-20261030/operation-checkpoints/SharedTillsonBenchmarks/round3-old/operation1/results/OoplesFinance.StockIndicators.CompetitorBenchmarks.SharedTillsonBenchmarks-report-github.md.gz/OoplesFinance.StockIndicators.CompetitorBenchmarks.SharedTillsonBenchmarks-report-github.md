```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.T3** | **1000**  |   **157.821 μs** | **20.5600 μs** | **12.2349 μs** | **34.74** |    **3.25** |  **7.8125** |       **-** |  **65.18 KB** |        **9.34** |
| BuilderLatestOnly | TaLib.Functions.T3 | 1000  |   150.848 μs | 13.6562 μs |  9.0328 μs | 33.21 |    2.70 |  1.9531 |       - |  17.57 KB |        2.52 |
| NativeSingle      | TaLib.Functions.T3 | 1000  |     4.558 μs |  0.4224 μs |  0.2794 μs |  1.00 |    0.08 |  0.8240 |       - |   6.98 KB |        1.00 |
| NativeParallel    | TaLib.Functions.T3 | 1000  |    10.288 μs |  0.1157 μs |  0.0689 μs |  2.26 |    0.13 |  6.1646 |  0.2441 |   38.7 KB |        5.55 |
|                   |                    |       |              |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.T3** | **10000** | **1,503.986 μs** | **70.3086 μs** | **41.8395 μs** | **32.76** |    **1.63** | **70.3125** | **23.4375** | **628.11 KB** |        **8.13** |
| BuilderLatestOnly | TaLib.Functions.T3 | 10000 | 1,443.255 μs | 46.6611 μs | 24.4047 μs | 31.44 |    1.42 | 15.6250 |       - | 158.27 KB |        2.05 |
| NativeSingle      | TaLib.Functions.T3 | 10000 |    45.987 μs |  3.1112 μs |  2.0579 μs |  1.00 |    0.06 |  9.2773 |       - |  77.29 KB |        1.00 |
| NativeParallel    | TaLib.Functions.T3 | 10000 |    79.500 μs |  2.2697 μs |  1.1871 μs |  1.73 |    0.08 | 60.0586 | 22.4609 | 425.43 KB |        5.50 |
