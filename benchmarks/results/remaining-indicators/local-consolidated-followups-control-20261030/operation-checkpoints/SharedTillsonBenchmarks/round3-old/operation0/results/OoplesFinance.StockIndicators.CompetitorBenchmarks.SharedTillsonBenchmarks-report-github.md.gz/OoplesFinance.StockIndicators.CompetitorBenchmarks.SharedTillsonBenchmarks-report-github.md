```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation     | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |-------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetT3** | **1000**  |   **165.62 μs** | **14.991 μs** |  **8.921 μs** |  **3.18** |    **0.18** |   **7.8125** |        **-** |        **-** |   **65.15 KB** |        **0.72** |
| BuilderLatestOnly | Skender.GetT3 | 1000  |   155.96 μs |  4.879 μs |  2.904 μs |  2.99 |    0.09 |   1.9531 |        - |        - |   17.57 KB |        0.19 |
| NativeSingle      | Skender.GetT3 | 1000  |    52.19 μs |  2.406 μs |  1.432 μs |  1.00 |    0.04 |  10.7422 |   0.9766 |        - |   90.24 KB |        1.00 |
| NativeParallel    | Skender.GetT3 | 1000  |    89.76 μs |  3.127 μs |  1.861 μs |  1.72 |    0.06 |  60.0586 |  17.5781 |        - |  415.91 KB |        4.61 |
|                   |               |       |             |           |           |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetT3** | **10000** | **1,532.93 μs** | **81.399 μs** | **48.439 μs** |  **2.06** |    **0.08** |  **62.5000** |  **15.6250** |        **-** |  **628.15 KB** |        **0.70** |
| BuilderLatestOnly | Skender.GetT3 | 10000 | 1,465.01 μs | 50.072 μs | 29.797 μs |  1.97 |    0.06 |  15.6250 |        - |        - |  158.33 KB |        0.18 |
| NativeSingle      | Skender.GetT3 | 10000 |   745.12 μs | 30.646 μs | 18.237 μs |  1.00 |    0.03 | 148.4375 | 101.5625 |  78.1250 |  899.91 KB |        1.00 |
| NativeParallel    | Skender.GetT3 | 10000 | 3,304.96 μs | 28.309 μs | 18.725 μs |  4.44 |    0.10 | 593.7500 | 531.2500 | 218.7500 | 4132.58 KB |        4.59 |
