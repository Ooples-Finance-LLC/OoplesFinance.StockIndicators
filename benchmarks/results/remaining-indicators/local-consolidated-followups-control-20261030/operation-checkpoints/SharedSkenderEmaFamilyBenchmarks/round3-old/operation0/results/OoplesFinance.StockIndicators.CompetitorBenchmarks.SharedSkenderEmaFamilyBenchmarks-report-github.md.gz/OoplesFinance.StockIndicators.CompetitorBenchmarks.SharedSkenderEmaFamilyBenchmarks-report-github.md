```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error        | StdDev       | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated   | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-------------:|-------------:|------:|--------:|----------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **721.48 μs** |    **53.473 μs** |    **31.821 μs** |  **9.49** |    **0.52** |         **-** |         **-** |        **-** |   **167.89 KB** |        **0.52** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   716.52 μs |    23.876 μs |    12.487 μs |  9.43 |    0.36 |   11.7188 |         - |        - |   120.24 KB |        0.37 |
| NativeSingle      | Skender.GetMacd | 1000  |    76.08 μs |     4.282 μs |     2.832 μs |  1.00 |    0.05 |   39.5508 |   10.2539 |        - |   324.54 KB |        1.00 |
| NativeParallel    | Skender.GetMacd | 1000  |   229.10 μs |     8.044 μs |     5.321 μs |  3.01 |    0.12 |  203.1250 |  121.0938 |        - |  1494.74 KB |        4.61 |
|                   |                 |       |             |              |              |       |         |           |           |          |             |             |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **7,276.15 μs** |   **131.141 μs** |    **68.590 μs** |  **2.34** |    **0.02** |  **142.8571** |   **71.4286** |        **-** |  **1648.25 KB** |        **0.48** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 7,616.17 μs |   764.797 μs |   455.119 μs |  2.45 |    0.14 |  100.0000 |         - |        - |  1178.69 KB |        0.34 |
| NativeSingle      | Skender.GetMacd | 10000 | 3,106.68 μs |    28.182 μs |    18.640 μs |  1.00 |    0.01 |  515.6250 |  500.0000 | 187.5000 |  3442.99 KB |        1.00 |
| NativeParallel    | Skender.GetMacd | 10000 | 9,591.59 μs | 2,072.178 μs | 1,370.618 μs |  3.09 |    0.42 | 2111.1111 | 1777.7778 | 444.4444 | 15379.74 KB |        4.47 |
