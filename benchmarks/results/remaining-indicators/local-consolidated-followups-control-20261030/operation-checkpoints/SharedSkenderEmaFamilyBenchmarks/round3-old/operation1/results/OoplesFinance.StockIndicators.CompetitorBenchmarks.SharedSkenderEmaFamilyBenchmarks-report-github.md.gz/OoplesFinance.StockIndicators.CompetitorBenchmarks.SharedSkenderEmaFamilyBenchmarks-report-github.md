```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error        | StdDev       | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-------------:|-------------:|------:|--------:|----------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **943.28 μs** |    **21.578 μs** |    **12.841 μs** | **11.61** |    **0.61** |         **-** |         **-** |        **-** |   **318.52 KB** |        **1.12** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   939.20 μs |    21.589 μs |    11.291 μs | 11.56 |    0.61 |   31.2500 |         - |        - |   270.91 KB |        0.95 |
| NativeSingle      | Skender.GetPvo | 1000  |    81.48 μs |     7.028 μs |     4.649 μs |  1.00 |    0.08 |   34.6680 |   10.2539 |        - |   285.61 KB |        1.00 |
| NativeParallel    | Skender.GetPvo | 1000  |   214.36 μs |    18.043 μs |    11.934 μs |  2.64 |    0.19 |  177.7344 |   70.3125 |        - |  1320.09 KB |        4.62 |
|                   |                |       |             |              |              |       |         |           |           |          |             |             |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **9,556.16 μs** |   **255.082 μs** |   **133.413 μs** |  **3.66** |    **0.06** |  **363.6364** |  **272.7273** |        **-** |  **3162.87 KB** |        **1.04** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 9,533.54 μs |   126.642 μs |    66.236 μs |  3.65 |    0.04 |  272.7273 |   90.9091 |        - |  2693.02 KB |        0.88 |
| NativeSingle      | Skender.GetPvo | 10000 | 2,613.24 μs |    39.616 μs |    23.575 μs |  1.00 |    0.01 |  453.1250 |  375.0000 | 156.2500 |  3052.26 KB |        1.00 |
| NativeParallel    | Skender.GetPvo | 10000 | 9,001.64 μs | 1,671.667 μs | 1,105.704 μs |  3.44 |    0.40 | 1818.1818 | 1727.2727 | 363.6364 | 13621.85 KB |        4.46 |
