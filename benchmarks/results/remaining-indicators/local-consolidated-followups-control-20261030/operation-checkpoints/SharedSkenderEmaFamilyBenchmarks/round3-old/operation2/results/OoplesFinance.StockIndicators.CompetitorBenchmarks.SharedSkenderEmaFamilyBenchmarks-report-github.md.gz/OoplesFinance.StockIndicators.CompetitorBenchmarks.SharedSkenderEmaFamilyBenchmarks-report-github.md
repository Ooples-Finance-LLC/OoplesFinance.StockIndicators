```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  | **1,597.55 μs** | **376.139 μs** | **248.793 μs** | **36.61** |    **6.91** |        **-** |        **-** |        **-** |   **89.13 KB** |        **0.73** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   828.41 μs |  24.427 μs |  14.536 μs | 18.98 |    2.21 |        - |        - |        - |    41.5 KB |        0.34 |
| NativeSingle      | Skender.GetTrix | 1000  |    44.25 μs |   8.538 μs |   5.648 μs |  1.01 |    0.17 |  14.6484 |   3.4180 |        - |  121.49 KB |        1.00 |
| NativeParallel    | Skender.GetTrix | 1000  |    85.90 μs |   4.876 μs |   2.550 μs |  1.97 |    0.23 |  77.6367 |  24.9023 |        - |  556.08 KB |        4.58 |
|                   |                 |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **8,236.21 μs** | **222.428 μs** | **116.334 μs** |  **6.62** |    **0.30** |  **76.9231** |        **-** |        **-** |   **863.5 KB** |        **0.71** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 8,564.46 μs | 967.727 μs | 640.092 μs |  6.89 |    0.57 |        - |        - |        - |  393.67 KB |        0.32 |
| NativeSingle      | Skender.GetTrix | 10000 | 1,246.11 μs |  86.217 μs |  57.027 μs |  1.00 |    0.06 | 187.5000 | 140.6250 |  78.1250 | 1212.13 KB |        1.00 |
| NativeParallel    | Skender.GetTrix | 10000 | 3,309.88 μs |  35.896 μs |  18.774 μs |  2.66 |    0.12 | 781.2500 | 687.5000 | 218.7500 | 5538.37 KB |        4.57 |
