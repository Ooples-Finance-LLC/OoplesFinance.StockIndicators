```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error       | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated   | Alloc Ratio |
|------------------ |---------------- |------ |------------:|------------:|----------:|------:|--------:|----------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |    **616.6 μs** |    **19.18 μs** |  **12.68 μs** |  **5.93** |    **0.31** |   **15.6250** |    **3.9063** |        **-** |   **128.49 KB** |        **0.40** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |    612.4 μs |    34.65 μs |  22.92 μs |  5.89 |    0.35 |    7.8125 |         - |        - |    80.91 KB |        0.25 |
| NativeSingle      | Skender.GetMacd | 1000  |    104.2 μs |     8.18 μs |   5.41 μs |  1.00 |    0.07 |   39.5508 |   10.2539 |        - |   324.54 KB |        1.00 |
| NativeParallel    | Skender.GetMacd | 1000  |    237.1 μs |    12.48 μs |   8.25 μs |  2.28 |    0.13 |  203.1250 |  128.9063 |        - |  1494.74 KB |        4.61 |
|                   |                 |       |             |             |           |       |         |           |           |          |             |             |
| **BuilderFull**       | **Skender.GetMacd** | **10000** |  **5,566.6 μs** |   **658.32 μs** | **435.44 μs** |  **1.80** |    **0.13** |  **125.0000** |   **62.5000** |        **-** |  **1254.16 KB** |        **0.36** |
| BuilderLatestOnly | Skender.GetMacd | 10000 |  5,971.7 μs |   278.05 μs | 183.91 μs |  1.93 |    0.06 |   93.7500 |   62.5000 |        - |   784.28 KB |        0.23 |
| NativeSingle      | Skender.GetMacd | 10000 |  3,096.4 μs |    32.82 μs |  21.71 μs |  1.00 |    0.01 |  515.6250 |  500.0000 | 187.5000 |     3443 KB |        1.00 |
| NativeParallel    | Skender.GetMacd | 10000 | 10,693.5 μs | 1,340.16 μs | 886.43 μs |  3.45 |    0.27 | 2000.0000 | 1700.0000 | 400.0000 | 15378.05 KB |        4.47 |
