```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **698.23 μs** |  **34.919 μs** |  **23.097 μs** | **16.14** |    **0.76** |   **7.8125** |        **-** |        **-** |   **89.19 KB** |        **0.73** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   656.26 μs |  78.212 μs |  51.732 μs | 15.17 |    1.26 |        - |        - |        - |   41.64 KB |        0.34 |
| NativeSingle      | Skender.GetTrix | 1000  |    43.30 μs |   2.443 μs |   1.616 μs |  1.00 |    0.05 |  14.6484 |   3.4180 |        - |  121.49 KB |        1.00 |
| NativeParallel    | Skender.GetTrix | 1000  |    90.45 μs |   5.370 μs |   3.552 μs |  2.09 |    0.11 |  77.6367 |  25.8789 |        - |  556.08 KB |        4.58 |
|                   |                 |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **7,973.81 μs** | **332.998 μs** | **220.257 μs** |  **6.10** |    **0.16** |  **76.9231** |        **-** |        **-** |  **863.65 KB** |        **0.71** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 7,781.90 μs | 101.903 μs |  67.403 μs |  5.95 |    0.05 |        - |        - |        - |  393.81 KB |        0.32 |
| NativeSingle      | Skender.GetTrix | 10000 | 1,307.52 μs |   7.080 μs |   4.213 μs |  1.00 |    0.00 | 187.5000 | 140.6250 |  78.1250 | 1212.09 KB |        1.00 |
| NativeParallel    | Skender.GetTrix | 10000 | 3,690.19 μs | 217.003 μs | 143.534 μs |  2.82 |    0.11 | 781.2500 | 718.7500 | 218.7500 | 5538.98 KB |        4.57 |
