```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error       | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------- |------ |-----------:|------------:|----------:|------:|--------:|----------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **787.5 μs** |    **48.52 μs** |  **28.87 μs** |  **7.86** |    **0.54** |    **7.8125** |         **-** |        **-** |   **104.98 KB** |        **0.37** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   746.3 μs |    74.24 μs |  49.10 μs |  7.45 |    0.64 |         - |         - |        - |    57.43 KB |        0.20 |
| NativeSingle      | Skender.GetPvo | 1000  |   100.6 μs |     9.70 μs |   6.41 μs |  1.00 |    0.09 |   34.1797 |    9.7656 |        - |   285.62 KB |        1.00 |
| NativeParallel    | Skender.GetPvo | 1000  |   213.6 μs |     7.79 μs |   4.63 μs |  2.13 |    0.13 |  177.7344 |   72.2656 |        - |  1320.09 KB |        4.62 |
|                   |                |       |            |             |           |       |         |           |           |          |             |             |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **8,165.1 μs** |   **640.12 μs** | **423.40 μs** |  **3.14** |    **0.16** |   **83.3333** |         **-** |        **-** |  **1020.15 KB** |        **0.33** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 7,769.7 μs |   500.15 μs | 330.82 μs |  2.99 |    0.13 |   66.6667 |         - |        - |   550.11 KB |        0.18 |
| NativeSingle      | Skender.GetPvo | 10000 | 2,601.1 μs |    47.17 μs |  31.20 μs |  1.00 |    0.02 |  453.1250 |  375.0000 | 156.2500 |  3052.26 KB |        1.00 |
| NativeParallel    | Skender.GetPvo | 10000 | 8,845.2 μs | 1,496.96 μs | 990.14 μs |  3.40 |    0.37 | 1818.1818 | 1727.2727 | 363.6364 | 13619.61 KB |        4.46 |
