```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetCci** | **1000**  |    **68.73 μs** |  **1.618 μs** |  **1.070 μs** |  **0.81** |    **0.04** |   **7.8125** |        **-** |    **68.7 KB** |        **0.47** |
| BuilderLatestOnly | Skender.GetCci | 1000  |    61.53 μs |  6.754 μs |  4.468 μs |  0.72 |    0.06 |   2.4414 |        - |   21.09 KB |        0.15 |
| NativeSingle      | Skender.GetCci | 1000  |    85.28 μs |  7.804 μs |  4.644 μs |  1.00 |    0.07 |  17.5781 |   3.9063 |  145.01 KB |        1.00 |
| NativeParallel    | Skender.GetCci | 1000  |    32.79 μs |  0.786 μs |  0.520 μs |  0.39 |    0.02 |  22.4609 |   5.1270 |  175.46 KB |        1.21 |
|                   |                |       |             |           |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetCci** | **10000** |   **644.65 μs** |  **9.974 μs** |  **6.597 μs** |  **0.64** |    **0.02** |  **74.2188** |  **70.3125** |   **631.6 KB** |        **0.44** |
| BuilderLatestOnly | Skender.GetCci | 10000 |   611.52 μs |  2.316 μs |  1.532 μs |  0.61 |    0.02 |  19.5313 |   3.9063 |  161.76 KB |        0.11 |
| NativeSingle      | Skender.GetCci | 10000 | 1,008.24 μs | 45.517 μs | 27.087 μs |  1.00 |    0.04 | 171.8750 | 109.3750 | 1445.85 KB |        1.00 |
| NativeParallel    | Skender.GetCci | 10000 |   381.58 μs | 15.922 μs | 10.532 μs |  0.38 |    0.01 | 205.0781 | 140.6250 | 1546.59 KB |        1.07 |
