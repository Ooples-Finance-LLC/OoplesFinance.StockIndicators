```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetCci** | **1000**  |    **67.04 μs** | **10.818 μs** |  **6.438 μs** |  **0.76** |    **0.08** |   **7.8125** |        **-** |    **68.7 KB** |        **0.47** |
| BuilderLatestOnly | Skender.GetCci | 1000  |    62.59 μs |  2.903 μs |  1.920 μs |  0.71 |    0.04 |   2.4414 |        - |   21.09 KB |        0.15 |
| NativeSingle      | Skender.GetCci | 1000  |    88.60 μs |  7.936 μs |  5.249 μs |  1.00 |    0.08 |  17.5781 |   3.9063 |  145.01 KB |        1.00 |
| NativeParallel    | Skender.GetCci | 1000  |    32.89 μs |  0.757 μs |  0.451 μs |  0.37 |    0.02 |  22.4609 |   5.1270 |  175.46 KB |        1.21 |
|                   |                |       |             |           |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetCci** | **10000** |   **646.18 μs** |  **3.456 μs** |  **2.057 μs** |  **0.64** |    **0.02** |  **74.2188** |  **70.3125** |  **631.61 KB** |        **0.44** |
| BuilderLatestOnly | Skender.GetCci | 10000 |   620.02 μs |  2.731 μs |  1.806 μs |  0.61 |    0.02 |  19.5313 |   3.9063 |  161.76 KB |        0.11 |
| NativeSingle      | Skender.GetCci | 10000 | 1,013.53 μs | 60.365 μs | 35.922 μs |  1.00 |    0.05 | 171.8750 | 109.3750 | 1445.84 KB |        1.00 |
| NativeParallel    | Skender.GetCci | 10000 |   384.43 μs | 15.228 μs | 10.073 μs |  0.38 |    0.02 | 205.0781 | 140.6250 | 1546.59 KB |        1.07 |
