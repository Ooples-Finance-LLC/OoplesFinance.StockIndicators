```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Ma** | **1000**  |   **158.827 μs** |  **4.1914 μs** |  **2.1922 μs** | **56.35** |    **2.27** |  **83.9844** |  **19.5313** |  **688.02 KB** |       **86.51** |
| BuilderLatestOnly | TaLib.Functions.Ma | 1000  |   143.444 μs |  4.5023 μs |  2.6792 μs | 50.89 |    2.14 |  79.1016 |  13.6719 |  640.41 KB |       80.52 |
| NativeSingle      | TaLib.Functions.Ma | 1000  |     2.823 μs |  0.1727 μs |  0.1142 μs |  1.00 |    0.05 |   0.9613 |   0.0153 |    7.95 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ma | 1000  |     9.646 μs |  0.1662 μs |  0.1099 μs |  3.42 |    0.14 |   7.2632 |   0.4883 |   44.84 KB |        5.64 |
|                   |                    |       |              |            |            |       |         |          |          |            |             |
| **BuilderFull**       | **TaLib.Functions.Ma** | **10000** | **1,350.678 μs** | **20.4978 μs** | **10.7207 μs** | **55.17** |    **3.06** | **781.2500** | **718.7500** | **6313.29 KB** |       **80.66** |
| BuilderLatestOnly | TaLib.Functions.Ma | 10000 | 1,293.403 μs | 78.6747 μs | 52.0385 μs | 52.83 |    3.54 | 726.5625 | 242.1875 | 5843.42 KB |       74.66 |
| NativeSingle      | TaLib.Functions.Ma | 10000 |    24.556 μs |  2.2111 μs |  1.4625 μs |  1.00 |    0.08 |   9.5215 |   1.7090 |   78.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ma | 10000 |    60.140 μs |  1.9106 μs |  1.2638 μs |  2.46 |    0.14 |  60.5469 |  23.4375 |  431.56 KB |        5.51 |
