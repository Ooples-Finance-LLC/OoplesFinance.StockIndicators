```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |-------------------- |------ |-------------:|------------:|------------:|------:|--------:|----------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Apo** | **1000**  |   **439.941 μs** |   **6.9846 μs** |   **4.1564 μs** | **63.61** |    **0.81** |  **242.1875** |  **78.1250** |       **-** | **1966.95 KB** |      **125.76** |
| BuilderLatestOnly | TaLib.Functions.Apo | 1000  |   433.122 μs |  13.2806 μs |   7.9031 μs | 62.62 |    1.23 |  234.3750 |  54.6875 |       - | 1919.37 KB |      122.72 |
| NativeSingle      | TaLib.Functions.Apo | 1000  |     6.917 μs |   0.1289 μs |   0.0674 μs |  1.00 |    0.01 |    1.8921 |   0.0610 |       - |   15.64 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Apo | 1000  |    15.744 μs |   0.1233 μs |   0.0645 μs |  2.28 |    0.02 |   12.4512 |   1.2207 |       - |   79.77 KB |        5.10 |
|                   |                     |       |              |             |             |       |         |           |          |         |            |             |
| **BuilderFull**       | **TaLib.Functions.Apo** | **10000** | **4,694.136 μs** | **231.4042 μs** | **153.0595 μs** | **68.27** |    **4.42** | **2281.2500** | **312.5000** | **31.2500** | **18272.8 KB** |      **116.93** |
| BuilderLatestOnly | TaLib.Functions.Apo | 10000 | 4,292.535 μs | 388.5509 μs | 257.0023 μs | 62.43 |    5.03 | 2187.5000 |  62.5000 |       - |   17802 KB |      113.92 |
| NativeSingle      | TaLib.Functions.Apo | 10000 |    68.986 μs |   6.5063 μs |   4.3035 μs |  1.00 |    0.08 |   19.0430 |   4.3945 |       - |  156.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Apo | 10000 |   118.940 μs |   3.8566 μs |   2.2950 μs |  1.73 |    0.10 |  110.3516 |  71.2891 |       - |   782.9 KB |        5.01 |
