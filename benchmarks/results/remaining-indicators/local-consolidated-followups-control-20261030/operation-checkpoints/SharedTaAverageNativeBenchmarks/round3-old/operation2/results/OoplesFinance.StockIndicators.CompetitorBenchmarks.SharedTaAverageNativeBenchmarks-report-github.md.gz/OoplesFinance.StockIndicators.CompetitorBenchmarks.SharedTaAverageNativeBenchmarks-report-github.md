```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1     | Gen2    | Allocated   | Alloc Ratio |
|------------------ |-------------------- |------ |-------------:|------------:|------------:|------:|--------:|----------:|---------:|--------:|------------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Ppo** | **1000**  |   **527.698 μs** |  **17.5721 μs** |  **10.4569 μs** | **76.59** |    **2.51** |  **296.8750** |  **93.7500** |       **-** |   **2429.5 KB** |      **155.32** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 1000  |   548.642 μs |  28.3692 μs |  16.8820 μs | 79.63 |    3.15 |  292.9688 |  70.3125 |       - |  2381.91 KB |      152.28 |
| NativeSingle      | TaLib.Functions.Ppo | 1000  |     6.895 μs |   0.3356 μs |   0.1997 μs |  1.00 |    0.04 |    1.8921 |   0.0610 |       - |    15.64 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ppo | 1000  |    16.964 μs |   0.2860 μs |   0.1702 μs |  2.46 |    0.07 |   12.4512 |   1.2207 |       - |    79.77 KB |        5.10 |
|                   |                     |       |              |             |             |       |         |           |          |         |             |             |
| **BuilderFull**       | **TaLib.Functions.Ppo** | **10000** | **5,635.487 μs** | **253.8344 μs** | **151.0528 μs** | **70.66** |    **6.77** | **2843.7500** | **312.5000** | **31.2500** | **23002.82 KB** |      **147.20** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 10000 | 4,988.416 μs | 150.2897 μs |  89.4350 μs | 62.55 |    5.87 | 2750.0000 | 156.2500 |       - | 22532.52 KB |      144.19 |
| NativeSingle      | TaLib.Functions.Ppo | 10000 |    80.424 μs |  11.6944 μs |   7.7351 μs |  1.01 |    0.13 |   19.0430 |   4.3945 |       - |   156.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ppo | 10000 |   130.577 μs |   6.6693 μs |   3.9688 μs |  1.64 |    0.16 |  110.3516 |  89.8438 |       - |    782.9 KB |        5.01 |
