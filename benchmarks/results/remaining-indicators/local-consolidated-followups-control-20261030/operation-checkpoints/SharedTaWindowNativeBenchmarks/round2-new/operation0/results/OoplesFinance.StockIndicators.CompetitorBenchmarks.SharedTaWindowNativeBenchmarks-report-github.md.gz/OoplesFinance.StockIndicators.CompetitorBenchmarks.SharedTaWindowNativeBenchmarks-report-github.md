```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio  | RatioSD | Gen0      | Gen1     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|-------:|--------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **TaLib(...)bands [24]** | **1000**  | **3,387.77 μs** | **397.959 μs** | **263.225 μs** | **252.78** |   **21.80** |  **300.0000** |        **-** |  **3187.82 KB** |       **81.56** |
| BuilderLatestOnly | TaLib(...)bands [24] | 1000  | 3,189.18 μs | 165.635 μs | 109.557 μs | 237.97 |   13.06 |  375.0000 |  62.5000 |  3140.33 KB |       80.34 |
| NativeSingle      | TaLib(...)bands [24] | 1000  |    13.43 μs |   0.935 μs |   0.619 μs |   1.00 |    0.06 |    4.7607 |   0.3662 |    39.09 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [24] | 1000  |    34.74 μs |   0.404 μs |   0.211 μs |   2.59 |    0.12 |   30.2734 |   6.8359 |   201.88 KB |        5.17 |
|                   |                      |       |             |            |            |        |         |           |          |             |             |
| **BuilderFull**       | **TaLib(...)bands [24]** | **10000** | **7,636.33 μs** | **239.808 μs** | **158.618 μs** |  **57.39** |    **2.70** | **3923.0769** | **307.6923** | **32287.16 KB** |       **82.65** |
| BuilderLatestOnly | TaLib(...)bands [24] | 10000 | 7,524.18 μs |  70.360 μs |  41.870 μs |  56.55 |    2.43 | 3928.5714 | 285.7143 | 31817.28 KB |       81.45 |
| NativeSingle      | TaLib(...)bands [24] | 10000 |   133.31 μs |   9.079 μs |   6.005 μs |   1.00 |    0.06 |   46.8750 |  15.6250 |   390.66 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [24] | 10000 |   270.97 μs |   4.860 μs |   2.892 μs |   2.04 |    0.09 |  257.8125 | 201.1719 |  1994.87 KB |        5.11 |
