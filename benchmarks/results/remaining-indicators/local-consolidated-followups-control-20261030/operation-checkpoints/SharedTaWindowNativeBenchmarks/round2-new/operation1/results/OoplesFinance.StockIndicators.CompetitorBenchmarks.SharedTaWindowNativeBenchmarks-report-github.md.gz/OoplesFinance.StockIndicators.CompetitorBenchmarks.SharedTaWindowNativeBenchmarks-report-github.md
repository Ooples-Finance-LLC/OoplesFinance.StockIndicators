```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **1000**  |  **52.843 μs** |  **1.7302 μs** |  **1.0296 μs** |  **1.65** |    **0.16** |  **7.8125** |       **-** |  **89.32 KB** |       **11.27** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 1000  |  47.573 μs |  1.1563 μs |  0.7648 μs |  1.48 |    0.14 |  5.3711 |       - |  41.44 KB |        5.23 |
| NativeSingle      | TaLib(...)vgDev [22] | 1000  |  32.358 μs |  4.8570 μs |  3.2126 μs |  1.01 |    0.14 |  0.7324 |       - |   7.92 KB |        1.00 |
| NativeParallel    | TaLib(...)vgDev [22] | 1000  |   8.797 μs |  0.2903 μs |  0.1920 μs |  0.27 |    0.03 |  2.2583 |  0.0610 |  17.79 KB |        2.25 |
|                   |                      |       |            |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **10000** | **460.255 μs** | **11.7716 μs** |  **7.7862 μs** |  **1.48** |    **0.05** | **70.3125** | **35.1563** | **581.91 KB** |        **7.44** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 10000 | 415.382 μs | 17.8488 μs | 11.8059 μs |  1.34 |    0.06 | 13.6719 |  1.9531 | 111.77 KB |        1.43 |
| NativeSingle      | TaLib(...)vgDev [22] | 10000 | 311.465 μs | 16.2429 μs | 10.7437 μs |  1.00 |    0.05 |  7.8125 |       - |  78.25 KB |        1.00 |
| NativeParallel    | TaLib(...)vgDev [22] | 10000 |  72.352 μs |  1.8259 μs |  1.2077 μs |  0.23 |    0.01 | 27.3438 |  6.3477 | 158.42 KB |        2.02 |
