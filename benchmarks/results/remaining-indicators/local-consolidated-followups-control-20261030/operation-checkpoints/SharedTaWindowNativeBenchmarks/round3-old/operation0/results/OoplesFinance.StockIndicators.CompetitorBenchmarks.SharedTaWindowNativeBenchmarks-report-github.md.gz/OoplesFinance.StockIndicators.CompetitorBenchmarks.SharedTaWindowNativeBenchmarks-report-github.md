```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio  | RatioSD | Gen0      | Gen1     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|-------:|--------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **TaLib(...)bands [24]** | **1000**  | **3,308.28 μs** | **826.425 μs** | **546.629 μs** | **305.71** |   **49.05** |  **363.6364** |  **90.9091** |  **3703.48 KB** |       **94.75** |
| BuilderLatestOnly | TaLib(...)bands [24] | 1000  | 2,922.08 μs | 171.722 μs | 113.584 μs | 270.03 |   12.88 |  437.5000 |  78.1250 |     3656 KB |       93.54 |
| NativeSingle      | TaLib(...)bands [24] | 1000  |    10.83 μs |   0.523 μs |   0.346 μs |   1.00 |    0.04 |    4.7607 |   0.3662 |    39.09 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [24] | 1000  |    32.60 μs |   0.369 μs |   0.193 μs |   3.01 |    0.09 |   30.2734 |   6.1035 |   201.88 KB |        5.17 |
|                   |                      |       |             |            |            |        |         |           |          |             |             |
| **BuilderFull**       | **TaLib(...)bands [24]** | **10000** | **8,060.20 μs** | **151.918 μs** |  **90.404 μs** |  **79.35** |    **2.68** | **4615.3846** | **230.7692** | **37511.96 KB** |       **96.02** |
| BuilderLatestOnly | TaLib(...)bands [24] | 10000 | 7,998.43 μs | 140.582 μs |  92.987 μs |  78.74 |    2.67 | 4538.4615 | 384.6154 | 37042.17 KB |       94.82 |
| NativeSingle      | TaLib(...)bands [24] | 10000 |   101.69 μs |   5.273 μs |   3.488 μs |   1.00 |    0.05 |   46.8750 |  15.6250 |   390.66 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [24] | 10000 |   263.23 μs |   9.322 μs |   6.166 μs |   2.59 |    0.10 |  257.8125 | 201.1719 |  1994.87 KB |        5.11 |
