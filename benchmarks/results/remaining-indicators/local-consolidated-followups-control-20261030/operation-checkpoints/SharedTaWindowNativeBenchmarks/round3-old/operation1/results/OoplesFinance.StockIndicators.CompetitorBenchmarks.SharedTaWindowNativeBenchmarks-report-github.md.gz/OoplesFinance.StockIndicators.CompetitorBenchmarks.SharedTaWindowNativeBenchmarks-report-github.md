```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **1000**  |  **50.320 μs** |  **1.5433 μs** |  **1.0208 μs** |  **1.82** |    **0.06** |  **7.8125** |       **-** |  **89.32 KB** |       **11.27** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 1000  |  46.128 μs |  1.1706 μs |  0.7743 μs |  1.67 |    0.06 |  5.3711 |       - |  41.44 KB |        5.23 |
| NativeSingle      | TaLib(...)vgDev [22] | 1000  |  27.686 μs |  1.4789 μs |  0.8801 μs |  1.00 |    0.04 |  0.7324 |       - |   7.92 KB |        1.00 |
| NativeParallel    | TaLib(...)vgDev [22] | 1000  |   8.272 μs |  0.4614 μs |  0.3052 μs |  0.30 |    0.01 |  2.2583 |  0.0610 |  17.79 KB |        2.25 |
|                   |                      |       |            |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **10000** | **454.244 μs** | **13.3755 μs** |  **8.8470 μs** |  **1.62** |    **0.05** | **70.3125** | **35.1563** | **581.91 KB** |        **7.44** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 10000 | 407.748 μs | 25.5738 μs | 16.9155 μs |  1.45 |    0.07 | 11.7188 |       - | 111.78 KB |        1.43 |
| NativeSingle      | TaLib(...)vgDev [22] | 10000 | 280.944 μs | 12.1294 μs |  7.2180 μs |  1.00 |    0.03 |  7.8125 |       - |  78.25 KB |        1.00 |
| NativeParallel    | TaLib(...)vgDev [22] | 10000 |  69.370 μs |  2.6333 μs |  1.3773 μs |  0.25 |    0.01 | 27.3438 |  6.3477 | 158.42 KB |        2.02 |
