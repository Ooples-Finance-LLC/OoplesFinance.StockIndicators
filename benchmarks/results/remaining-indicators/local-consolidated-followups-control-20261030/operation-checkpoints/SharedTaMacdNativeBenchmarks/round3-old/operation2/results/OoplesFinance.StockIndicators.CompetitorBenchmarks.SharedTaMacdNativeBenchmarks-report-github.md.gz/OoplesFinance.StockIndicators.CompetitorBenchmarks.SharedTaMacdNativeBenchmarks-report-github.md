```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **1000**  |   **770.96 μs** | **136.098 μs** |  **90.020 μs** | **57.50** |    **6.82** |        **-** |        **-** |  **119.83 KB** |        **3.13** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 1000  |   649.35 μs |  33.634 μs |  17.591 μs | 48.43 |    2.33 |   7.8125 |        - |   72.21 KB |        1.89 |
| NativeSingle      | TaLib(...)cdFix [23] | 1000  |    13.43 μs |   0.898 μs |   0.594 μs |  1.00 |    0.06 |   4.6387 |   0.2441 |   38.27 KB |        1.00 |
| NativeParallel    | TaLib(...)cdFix [23] | 1000  |    35.49 μs |   0.599 μs |   0.357 μs |  2.65 |    0.11 |  29.5410 |   6.8359 |  196.91 KB |        5.15 |
|                   |                      |       |             |            |            |       |         |          |          |            |             |
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **10000** | **6,559.16 μs** | **433.183 μs** | **257.780 μs** | **52.31** |    **2.37** | **125.0000** |  **62.5000** | **1173.89 KB** |        **3.01** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 10000 | 6,758.88 μs | 452.742 μs | 299.461 μs | 53.90 |    2.66 |  62.5000 |        - |  704.03 KB |        1.81 |
| NativeSingle      | TaLib(...)cdFix [23] | 10000 |   125.48 μs |   5.145 μs |   3.403 μs |  1.00 |    0.04 |  46.8750 |        - |  389.84 KB |        1.00 |
| NativeParallel    | TaLib(...)cdFix [23] | 10000 |   304.43 μs |  32.225 μs |  21.315 μs |  2.43 |    0.17 | 255.8594 | 195.3125 | 1989.89 KB |        5.10 |
