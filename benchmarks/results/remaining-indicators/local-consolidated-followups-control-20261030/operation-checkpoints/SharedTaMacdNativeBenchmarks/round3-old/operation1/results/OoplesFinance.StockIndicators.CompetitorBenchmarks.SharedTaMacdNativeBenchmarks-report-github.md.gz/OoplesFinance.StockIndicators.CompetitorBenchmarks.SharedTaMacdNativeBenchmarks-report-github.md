```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Macd** | **1000**  |   **665.06 μs** |  **87.286 μs** |  **57.734 μs** | **50.21** |    **4.44** |        **-** |        **-** |   **120.2 KB** |        **3.14** |
| BuilderLatestOnly | TaLib.Functions.Macd | 1000  |   623.38 μs |  15.364 μs |   9.143 μs | 47.06 |    1.60 |   7.8125 |        - |   72.55 KB |        1.90 |
| NativeSingle      | TaLib.Functions.Macd | 1000  |    13.26 μs |   0.661 μs |   0.437 μs |  1.00 |    0.04 |   4.6387 |   0.2441 |   38.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Macd | 1000  |    35.41 μs |   0.885 μs |   0.585 μs |  2.67 |    0.09 |  29.5410 |   6.8359 |  196.91 KB |        5.15 |
|                   |                      |       |             |            |            |       |         |          |          |            |             |
| **BuilderFull**       | **TaLib.Functions.Macd** | **10000** | **6,345.53 μs** | **217.746 μs** | **129.577 μs** | **53.90** |    **1.60** | **125.0000** |  **62.5000** |  **1178.6 KB** |        **3.02** |
| BuilderLatestOnly | TaLib.Functions.Macd | 10000 | 6,325.64 μs | 420.599 μs | 250.292 μs | 53.73 |    2.35 |  62.5000 |  31.2500 |   708.5 KB |        1.82 |
| NativeSingle      | TaLib.Functions.Macd | 10000 |   117.78 μs |   4.815 μs |   2.865 μs |  1.00 |    0.03 |  46.8750 |        - |  389.84 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Macd | 10000 |   282.98 μs |   9.696 μs |   5.770 μs |  2.40 |    0.07 | 255.8594 | 197.2656 | 1989.89 KB |        5.10 |
