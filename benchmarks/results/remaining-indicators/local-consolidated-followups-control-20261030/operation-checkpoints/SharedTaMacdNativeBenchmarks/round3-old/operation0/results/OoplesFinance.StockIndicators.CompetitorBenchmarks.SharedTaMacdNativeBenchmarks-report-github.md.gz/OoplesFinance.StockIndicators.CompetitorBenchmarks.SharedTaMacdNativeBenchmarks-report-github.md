```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0      | Gen1     | Gen2    | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|----------:|---------:|--------:|------------:|------------:|
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **1000**  |   **654.40 μs** |  **48.262 μs** |  **31.922 μs** | **60.30** |    **4.56** |  **296.8750** |  **93.7500** |       **-** |  **2479.04 KB** |       **64.47** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 1000  |   598.97 μs |  29.947 μs |  17.821 μs | 55.20 |    3.64 |  300.7813 |  74.2188 |       - |  2431.45 KB |       63.23 |
| NativeSingle      | TaLib(...)cdExt [23] | 1000  |    10.89 μs |   1.137 μs |   0.677 μs |  1.00 |    0.08 |    4.6997 |   0.4272 |       - |    38.45 KB |        1.00 |
| NativeParallel    | TaLib(...)cdExt [23] | 1000  |    33.30 μs |   1.223 μs |   0.809 μs |  3.07 |    0.20 |   30.0293 |   6.5918 |       - |   198.41 KB |        5.16 |
|                   |                      |       |             |            |            |       |         |           |          |         |             |             |
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **10000** | **6,132.17 μs** | **253.685 μs** | **167.797 μs** | **61.65** |    **2.03** | **2906.2500** | **343.7500** | **31.2500** | **23423.64 KB** |       **60.06** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 10000 | 5,610.23 μs | 118.836 μs |  78.603 μs | 56.41 |    1.36 | 2812.5000 |  31.2500 |       - |  22953.1 KB |       58.85 |
| NativeSingle      | TaLib(...)cdExt [23] | 10000 |    99.50 μs |   3.584 μs |   2.133 μs |  1.00 |    0.03 |   46.8750 |  15.6250 |       - |   390.02 KB |        1.00 |
| NativeParallel    | TaLib(...)cdExt [23] | 10000 |   255.00 μs |   4.299 μs |   2.558 μs |  2.56 |    0.06 |  257.8125 | 195.3125 |       - |  1991.39 KB |        5.11 |
