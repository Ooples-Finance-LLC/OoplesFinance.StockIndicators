```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0      | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|----------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetPrs** | **1000**  |   **290.32 μs** |  **36.103 μs** |  **21.484 μs** |  **4.00** |    **0.39** |  **125.0000** |  **31.2500** |        **-** | **1058.56 KB** |        **6.42** |
| BuilderLatestOnly | Skender.GetPrs | 1000  |   254.51 μs |  10.168 μs |   6.726 μs |  3.51 |    0.25 |  125.0000 |  19.5313 |        - | 1010.96 KB |        6.13 |
| NativeSingle      | Skender.GetPrs | 1000  |    72.85 μs |   9.383 μs |   4.907 μs |  1.00 |    0.09 |   20.0195 |   3.4180 |        - |  164.79 KB |        1.00 |
| NativeParallel    | Skender.GetPrs | 1000  |    32.72 μs |   1.453 μs |   0.865 μs |  0.45 |    0.03 |   26.6113 |   6.5918 |        - |  200.91 KB |        1.22 |
|                   |                |       |             |            |            |       |         |           |          |          |            |             |
| **BuilderFull**       | **Skender.GetPrs** | **10000** | **2,606.05 μs** |  **50.246 μs** |  **33.235 μs** |  **1.36** |    **0.11** | **1171.8750** | **531.2500** |  **15.6250** | **9497.87 KB** |        **5.78** |
| BuilderLatestOnly | Skender.GetPrs | 10000 | 2,393.01 μs | 148.569 μs |  98.269 μs |  1.25 |    0.11 | 1109.3750 | 546.8750 |        - | 9027.48 KB |        5.50 |
| NativeSingle      | Skender.GetPrs | 10000 | 1,928.51 μs | 234.152 μs | 154.877 μs |  1.01 |    0.11 |  234.3750 | 140.6250 | 125.0000 | 1642.57 KB |        1.00 |
| NativeParallel    | Skender.GetPrs | 10000 |   300.03 μs |  18.772 μs |  12.417 μs |  0.16 |    0.01 |  253.9063 | 162.1094 |        - | 1747.73 KB |        1.06 |
