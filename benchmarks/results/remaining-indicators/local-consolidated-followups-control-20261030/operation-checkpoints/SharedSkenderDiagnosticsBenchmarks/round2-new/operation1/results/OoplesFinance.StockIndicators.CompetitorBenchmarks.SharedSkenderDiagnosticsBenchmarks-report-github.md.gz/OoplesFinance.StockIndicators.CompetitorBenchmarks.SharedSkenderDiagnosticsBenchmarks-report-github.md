```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)lysis [22]** | **1000**  |   **147.46 μs** |  **10.548 μs** |   **6.277 μs** |  **1.24** |    **0.08** |  **15.6250** |        **-** |       **-** |  **160.55 KB** |        **0.87** |
| BuilderLatestOnly | Skend(...)lysis [22] | 1000  |   133.73 μs |   3.634 μs |   2.404 μs |  1.13 |    0.06 |  13.6719 |   1.9531 |       - |   112.9 KB |        0.61 |
| NativeSingle      | Skend(...)lysis [22] | 1000  |   119.11 μs |   9.220 μs |   6.098 μs |  1.00 |    0.07 |  22.4609 |   4.8828 |       - |  184.12 KB |        1.00 |
| NativeParallel    | Skend(...)lysis [22] | 1000  |    39.71 μs |   1.227 μs |   0.812 μs |  0.33 |    0.02 |  27.8320 |   7.3242 |       - |  220.16 KB |        1.20 |
|                   |                      |       |             |            |            |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)lysis [22]** | **10000** | **1,384.02 μs** |  **19.841 μs** |  **13.123 μs** |  **0.58** |    **0.04** | **156.2500** | **101.5625** |       **-** | **1288.96 KB** |        **0.70** |
| BuilderLatestOnly | Skend(...)lysis [22] | 10000 | 1,304.73 μs |  49.802 μs |  32.941 μs |  0.55 |    0.04 |  93.7500 |  54.6875 |       - |  819.11 KB |        0.45 |
| NativeSingle      | Skend(...)lysis [22] | 10000 | 2,382.53 μs | 282.354 μs | 186.759 μs |  1.01 |    0.11 | 250.0000 | 187.5000 | 78.1250 | 1837.36 KB |        1.00 |
| NativeParallel    | Skend(...)lysis [22] | 10000 |   457.57 μs |  13.157 μs |   6.881 μs |  0.19 |    0.01 | 261.7188 | 171.8750 |       - | 1942.87 KB |        1.06 |
