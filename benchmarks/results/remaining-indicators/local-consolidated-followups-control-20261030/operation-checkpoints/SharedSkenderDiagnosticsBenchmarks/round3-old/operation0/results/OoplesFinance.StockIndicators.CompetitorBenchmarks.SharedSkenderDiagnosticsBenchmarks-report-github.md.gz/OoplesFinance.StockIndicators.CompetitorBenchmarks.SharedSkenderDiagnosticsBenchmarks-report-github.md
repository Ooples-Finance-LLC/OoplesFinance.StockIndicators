```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0      | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|----------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetPrs** | **1000**  |   **289.66 μs** |  **12.983 μs** |   **8.588 μs** |  **4.79** |    **0.37** |  **125.0000** |  **31.2500** |        **-** | **1058.56 KB** |        **6.42** |
| BuilderLatestOnly | Skender.GetPrs | 1000  |   266.46 μs |   2.146 μs |   1.277 μs |  4.41 |    0.32 |  125.0000 |  19.5313 |        - | 1010.96 KB |        6.13 |
| NativeSingle      | Skender.GetPrs | 1000  |    60.75 μs |   7.117 μs |   4.707 μs |  1.01 |    0.10 |   20.0195 |   3.4180 |        - |  164.79 KB |        1.00 |
| NativeParallel    | Skender.GetPrs | 1000  |    30.81 μs |   0.902 μs |   0.537 μs |  0.51 |    0.04 |   26.6113 |   6.5918 |        - |  200.91 KB |        1.22 |
|                   |                |       |             |            |            |       |         |           |          |          |            |             |
| **BuilderFull**       | **Skender.GetPrs** | **10000** | **2,875.30 μs** | **222.414 μs** | **147.113 μs** |  **2.40** |    **0.28** | **1171.8750** | **531.2500** |  **15.6250** | **9497.79 KB** |        **5.78** |
| BuilderLatestOnly | Skender.GetPrs | 10000 | 2,504.04 μs | 125.551 μs |  74.714 μs |  2.09 |    0.23 | 1109.3750 | 546.8750 |        - | 9027.47 KB |        5.49 |
| NativeSingle      | Skender.GetPrs | 10000 | 1,210.69 μs | 213.022 μs | 140.901 μs |  1.01 |    0.16 |  257.8125 | 171.8750 | 140.6250 | 1642.91 KB |        1.00 |
| NativeParallel    | Skender.GetPrs | 10000 |   287.60 μs |   6.103 μs |   4.037 μs |  0.24 |    0.03 |  253.9063 | 166.0156 |        - | 1747.73 KB |        1.06 |
