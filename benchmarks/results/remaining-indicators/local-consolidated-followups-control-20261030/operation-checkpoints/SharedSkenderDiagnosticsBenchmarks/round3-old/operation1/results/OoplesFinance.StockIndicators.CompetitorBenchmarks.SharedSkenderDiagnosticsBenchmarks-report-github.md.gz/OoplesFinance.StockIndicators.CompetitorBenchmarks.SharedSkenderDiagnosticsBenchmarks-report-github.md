```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)lysis [22]** | **1000**  |   **139.94 μs** |   **1.456 μs** |   **0.866 μs** |  **1.49** |    **0.08** |  **15.6250** |        **-** |       **-** |  **160.47 KB** |        **0.87** |
| BuilderLatestOnly | Skend(...)lysis [22] | 1000  |   135.55 μs |   1.723 μs |   1.025 μs |  1.44 |    0.07 |  13.6719 |   1.9531 |       - |   112.9 KB |        0.61 |
| NativeSingle      | Skend(...)lysis [22] | 1000  |    94.23 μs |   8.900 μs |   5.296 μs |  1.00 |    0.07 |  22.4609 |   4.8828 |       - |  184.12 KB |        1.00 |
| NativeParallel    | Skend(...)lysis [22] | 1000  |    37.05 μs |   0.619 μs |   0.324 μs |  0.39 |    0.02 |  27.8320 |   7.5684 |       - |  220.16 KB |        1.20 |
|                   |                      |       |             |            |            |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)lysis [22]** | **10000** | **1,339.63 μs** |  **24.946 μs** |  **16.500 μs** |  **0.84** |    **0.08** | **156.2500** | **101.5625** |       **-** | **1288.92 KB** |        **0.70** |
| BuilderLatestOnly | Skend(...)lysis [22] | 10000 | 1,294.40 μs |  81.324 μs |  53.791 μs |  0.81 |    0.09 |  93.7500 |  54.6875 |       - |  819.11 KB |        0.45 |
| NativeSingle      | Skend(...)lysis [22] | 10000 | 1,614.96 μs | 269.755 μs | 178.426 μs |  1.01 |    0.15 | 265.6250 | 203.1250 | 85.9375 | 1837.46 KB |        1.00 |
| NativeParallel    | Skend(...)lysis [22] | 10000 |   432.08 μs |  10.239 μs |   6.773 μs |  0.27 |    0.03 | 261.7188 | 164.0625 |       - | 1942.87 KB |        1.06 |
