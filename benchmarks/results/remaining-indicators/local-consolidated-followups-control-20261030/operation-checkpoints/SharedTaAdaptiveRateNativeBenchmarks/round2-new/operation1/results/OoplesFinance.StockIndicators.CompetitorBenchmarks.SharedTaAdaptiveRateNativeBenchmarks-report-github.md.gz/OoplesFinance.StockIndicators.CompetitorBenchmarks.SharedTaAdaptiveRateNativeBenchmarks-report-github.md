```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error        | StdDev     | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-------------:|-----------:|------:|--------:|---------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **776.56 μs** |    **12.248 μs** |   **8.101 μs** | **61.54** |    **0.90** |   **7.8125** |       **-** |  **89.19 KB** |        **5.76** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   762.47 μs |    26.138 μs |  17.289 μs | 60.43 |    1.46 |   3.9063 |       - |  41.61 KB |        2.69 |
| NativeSingle      | TaLib.Functions.Trix | 1000  |    12.62 μs |     0.214 μs |   0.142 μs |  1.00 |    0.02 |   1.7090 |       - |  15.49 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Trix | 1000  |    21.48 μs |     0.356 μs |   0.186 μs |  1.70 |    0.02 |  12.8174 |  1.2207 |  80.07 KB |        5.17 |
|                   |                      |       |             |              |            |       |         |          |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **7,471.19 μs** | **1,023.338 μs** | **676.875 μs** | **70.54** |    **6.23** |  **76.9231** |       **-** | **863.62 KB** |        **5.53** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 6,994.42 μs | 1,170.551 μs | 774.247 μs | 66.04 |    7.07 |  31.2500 |       - | 393.43 KB |        2.52 |
| NativeSingle      | TaLib.Functions.Trix | 10000 |   105.95 μs |     3.408 μs |   2.028 μs |  1.00 |    0.03 |  18.5547 |  3.9063 | 156.12 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Trix | 10000 |   164.59 μs |     7.798 μs |   4.640 μs |  1.55 |    0.05 | 110.3516 | 61.5234 |  783.2 KB |        5.02 |
