```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Mavp** | **1000**  |   **132.13 μs** |  **30.434 μs** |  **20.130 μs** |  **4.07** |    **0.68** |   **7.8125** |       **-** |  **66.39 KB** |        **3.34** |
| BuilderLatestOnly | TaLib.Functions.Mavp | 1000  |   125.71 μs |  27.838 μs |  18.413 μs |  3.87 |    0.63 |   1.9531 |       - |  18.78 KB |        0.94 |
| NativeSingle      | TaLib.Functions.Mavp | 1000  |    32.70 μs |   4.086 μs |   2.703 μs |  1.01 |    0.11 |   2.1973 |       - |   19.9 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mavp | 1000  |    41.32 μs |   0.998 μs |   0.522 μs |  1.27 |    0.10 |  15.8691 |  1.9531 | 100.59 KB |        5.05 |
|                   |                      |       |             |            |            |       |         |          |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Mavp** | **10000** | **1,300.12 μs** | **151.775 μs** | **100.390 μs** |  **3.25** |    **0.35** |  **70.3125** | **23.4375** | **629.34 KB** |        **3.22** |
| BuilderLatestOnly | TaLib.Functions.Mavp | 10000 | 1,051.66 μs | 143.882 μs |  95.169 μs |  2.63 |    0.31 |  15.6250 |       - | 159.47 KB |        0.81 |
| NativeSingle      | TaLib.Functions.Mavp | 10000 |   402.28 μs |  49.395 μs |  32.672 μs |  1.01 |    0.11 |  23.4375 |  7.8125 | 195.71 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mavp | 10000 |   431.76 μs |   3.380 μs |   1.768 μs |  1.08 |    0.09 | 128.9063 | 62.5000 | 962.07 KB |        4.92 |
