```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Mavp** | **1000**  |   **112.20 μs** |   **6.668 μs** |   **3.488 μs** |  **4.05** |    **0.14** |   **7.8125** |       **-** |  **66.38 KB** |        **3.34** |
| BuilderLatestOnly | TaLib.Functions.Mavp | 1000  |    97.07 μs |   2.384 μs |   1.247 μs |  3.51 |    0.08 |   1.9531 |       - |  18.78 KB |        0.94 |
| NativeSingle      | TaLib.Functions.Mavp | 1000  |    27.69 μs |   0.956 μs |   0.569 μs |  1.00 |    0.03 |   2.1973 |       - |   19.9 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mavp | 1000  |    39.17 μs |   2.484 μs |   1.643 μs |  1.42 |    0.06 |  15.8691 |  1.9531 | 100.59 KB |        5.05 |
|                   |                      |       |             |            |            |       |         |          |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Mavp** | **10000** |   **982.26 μs** |  **49.512 μs** |  **25.896 μs** |  **2.81** |    **0.09** |  **70.3125** | **23.4375** | **629.33 KB** |        **3.22** |
| BuilderLatestOnly | TaLib.Functions.Mavp | 10000 | 1,035.87 μs | 227.863 μs | 150.718 μs |  2.97 |    0.42 |  15.6250 |       - | 159.47 KB |        0.81 |
| NativeSingle      | TaLib.Functions.Mavp | 10000 |   349.34 μs |  10.930 μs |   6.505 μs |  1.00 |    0.02 |  23.4375 |  7.8125 |  195.7 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mavp | 10000 |   422.36 μs |   8.483 μs |   5.611 μs |  1.21 |    0.03 | 128.9063 | 58.5938 | 962.07 KB |        4.92 |
