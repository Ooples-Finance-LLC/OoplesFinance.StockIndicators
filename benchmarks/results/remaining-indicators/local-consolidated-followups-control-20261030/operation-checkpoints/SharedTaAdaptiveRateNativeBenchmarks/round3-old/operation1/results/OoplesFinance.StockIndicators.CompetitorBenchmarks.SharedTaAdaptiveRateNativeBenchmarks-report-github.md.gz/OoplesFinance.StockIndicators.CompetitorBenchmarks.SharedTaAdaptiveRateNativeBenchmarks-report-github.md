```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **807.10 μs** |  **10.568 μs** |   **5.527 μs** | **73.03** |    **2.34** |        **-** |       **-** |  **89.13 KB** |        **5.76** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   827.24 μs |  19.409 μs |  11.550 μs | 74.85 |    2.55 |        - |       - |   41.5 KB |        2.68 |
| NativeSingle      | TaLib.Functions.Trix | 1000  |    11.06 μs |   0.625 μs |   0.372 μs |  1.00 |    0.04 |   1.8921 |  0.0610 |  15.48 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Trix | 1000  |    21.00 μs |   0.710 μs |   0.371 μs |  1.90 |    0.07 |  12.8174 |  0.9766 |  80.07 KB |        5.17 |
|                   |                      |       |             |            |            |       |         |          |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **8,403.05 μs** | **211.231 μs** | **110.478 μs** | **76.58** |    **1.32** |  **83.3333** |       **-** | **863.56 KB** |        **5.53** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 8,591.26 μs | 155.234 μs |  92.377 μs | 78.30 |    1.24 |        - |       - | 393.77 KB |        2.52 |
| NativeSingle      | TaLib.Functions.Trix | 10000 |   109.74 μs |   2.348 μs |   1.397 μs |  1.00 |    0.02 |  18.5547 |  3.9063 | 156.12 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Trix | 10000 |   163.37 μs |   2.985 μs |   1.776 μs |  1.49 |    0.02 | 110.3516 | 58.5938 |  783.2 KB |        5.02 |
