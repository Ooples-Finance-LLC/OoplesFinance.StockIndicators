```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Stoch [21]** | **2,027.3 μs** |  **48.26 μs** |  **28.72 μs** |  **1.00** |    **0.02** |         **-** |  **1334.62 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Stoch [21] |   379.5 μs |  50.41 μs |  33.34 μs |  0.19 |    0.02 |         - |    94.08 KB |        0.07 |
|            |       |                      |            |           |           |       |         |           |             |             |
| **Ooples**     | **10000** | **TaLib(...)Stoch [21]** | **8,921.8 μs** | **714.01 μs** | **424.90 μs** |  **1.00** |    **0.07** | **1000.0000** | **13103.59 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Stoch [21] |   467.9 μs |  82.24 μs |  48.94 μs |  0.05 |    0.01 |         - |    888.7 KB |        0.07 |
