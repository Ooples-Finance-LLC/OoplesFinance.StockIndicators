```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDM [23]** |   **886.9 μs** |  **30.28 μs** |  **15.84 μs** |  **1.00** |    **0.02** |  **105.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDM [23] |   143.6 μs |   5.64 μs |   3.35 μs |  0.16 |    0.00 |   40.55 KB |        0.38 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDM [23]** | **3,042.3 μs** | **802.47 μs** | **530.78 μs** |  **1.03** |    **0.24** | **1036.77 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDM [23] |   226.8 μs |  20.96 μs |  12.47 μs |  0.08 |    0.01 |  329.93 KB |        0.32 |
