```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDI [23]** | **1,362.7 μs** |    **20.53 μs** |    **12.22 μs** |  **1.00** |    **0.01** |  **105.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDI [23] |   200.6 μs |     8.01 μs |     4.77 μs |  0.15 |    0.00 |   40.88 KB |        0.39 |
|            |       |                      |            |             |             |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDI [23]** | **5,012.9 μs** | **1,568.07 μs** | **1,037.18 μs** |  **1.04** |    **0.28** | **1037.05 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDI [23] |   233.7 μs |    41.67 μs |    24.80 μs |  0.05 |    0.01 |  330.92 KB |        0.32 |
