```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)cdExt [23]** | **4,139.1 μs** |  **81.48 μs** |  **48.49 μs** |  **1.00** |    **0.02** |         **-** |         **-** |  **2601.32 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)cdExt [23] |   316.1 μs |  39.08 μs |  23.26 μs |  0.08 |    0.01 |         - |         - |   121.91 KB |        0.05 |
|            |       |                      |            |           |           |       |         |           |           |             |             |
| **Ooples**     | **10000** | **TaLib(...)cdExt [23]** | **6,838.2 μs** | **438.83 μs** | **229.52 μs** |  **1.00** |    **0.04** | **2000.0000** | **1000.0000** | **24633.55 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)cdExt [23] |   279.6 μs |  81.43 μs |  48.46 μs |  0.04 |    0.01 |         - |         - |  1132.94 KB |        0.05 |
