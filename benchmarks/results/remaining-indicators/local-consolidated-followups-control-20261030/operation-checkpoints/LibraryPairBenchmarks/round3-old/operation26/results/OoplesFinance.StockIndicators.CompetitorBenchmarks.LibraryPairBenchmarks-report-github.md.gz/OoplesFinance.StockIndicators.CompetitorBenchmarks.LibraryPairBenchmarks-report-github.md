```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetCci** |   **825.6 μs** |  **88.68 μs** |  **58.65 μs** |  **1.00** |    **0.10** |  **109.41 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetCci |   243.6 μs |  39.05 μs |  25.83 μs |  0.30 |    0.04 |  178.42 KB |        1.63 |
|            |       |                |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetCci** | **2,174.2 μs** | **513.17 μs** | **339.43 μs** |  **1.03** |    **0.23** | **1041.08 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetCci |   942.6 μs |  35.49 μs |  21.12 μs |  0.44 |    0.08 | 1698.27 KB |        1.63 |
