```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tochF [22]** | **1,491.3 μs** |  **66.44 μs** | **39.53 μs** |  **1.00** |    **0.04** |  **792.37 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tochF [22] |   312.0 μs |  35.34 μs | 23.38 μs |  0.21 |    0.02 |   97.66 KB |        0.12 |
|            |       |                      |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)tochF [22]** | **6,664.2 μs** | **125.60 μs** | **65.69 μs** |  **1.00** |    **0.01** | **7780.41 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tochF [22] |   388.0 μs |  37.37 μs | 22.24 μs |  0.06 |    0.00 |  887.03 KB |        0.11 |
