```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)gence [50]** |  **5.909 ms** | **0.0390 ms** | **0.0232 ms** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |   **329.45 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)gence [50] |  9.589 ms | 1.9541 ms | 1.2925 ms |  1.62 |    0.21 |         - |         - |         - |  4583.59 KB |       13.91 |
|            |       |                      |           |           |           |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)gence [50]** | **10.623 ms** | **1.9346 ms** | **1.2796 ms** |  **1.01** |    **0.17** |         **-** |         **-** |         **-** |  **3250.69 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)gence [50] | 40.132 ms | 2.3793 ms | 1.5737 ms |  3.83 |    0.48 | 3000.0000 | 2000.0000 | 1000.0000 | 34691.44 KB |       10.67 |
