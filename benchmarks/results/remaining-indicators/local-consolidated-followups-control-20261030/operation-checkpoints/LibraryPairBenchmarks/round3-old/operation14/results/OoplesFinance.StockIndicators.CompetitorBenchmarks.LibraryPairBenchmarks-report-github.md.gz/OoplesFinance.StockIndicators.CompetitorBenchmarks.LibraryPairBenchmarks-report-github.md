```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|---------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Trix** | **5,689.8 μs** |  **21.41 μs** | **12.74 μs** |  **1.00** |  **192.85 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Trix |   164.9 μs |  12.55 μs |  7.47 μs |  0.03 |   48.46 KB |        0.25 |
|            |       |                      |            |           |          |       |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Trix** | **8,908.5 μs** | **168.22 μs** | **87.98 μs** |  **1.00** | **1897.34 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Trix |   203.2 μs |  14.83 μs |  8.83 μs |  0.02 |  407.13 KB |        0.21 |
