```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId              | Mean       | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Allocated   | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|------------:|------------:|------:|--------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ppo** | **3,286.8 μs** |    **74.91 μs** |    **44.58 μs** |  **1.00** |    **0.02** |         **-** |         **-** |  **2470.38 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ppo |   183.2 μs |    18.69 μs |    12.36 μs |  0.06 |    0.00 |         - |         - |    49.16 KB |        0.02 |
|            |       |                     |            |             |             |       |         |           |           |             |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ppo** | **6,459.6 μs** | **1,737.58 μs** | **1,149.30 μs** |  **1.03** |    **0.23** | **2000.0000** | **1000.0000** | **23410.88 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ppo |   201.6 μs |    18.58 μs |     9.72 μs |  0.03 |    0.01 |         - |         - |   409.52 KB |        0.02 |
