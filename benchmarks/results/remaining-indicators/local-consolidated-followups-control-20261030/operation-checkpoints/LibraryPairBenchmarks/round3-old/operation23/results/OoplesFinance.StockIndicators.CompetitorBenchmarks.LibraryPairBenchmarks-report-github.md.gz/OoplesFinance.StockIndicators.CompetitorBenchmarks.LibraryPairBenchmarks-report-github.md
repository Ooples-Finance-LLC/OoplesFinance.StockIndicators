```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)lysis [22]** | **2,070.0 μs** |  **43.20 μs** | **25.71 μs** |  **1.00** |    **0.02** |  **323.37 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)lysis [22] |   523.7 μs |   9.63 μs |  5.04 μs |  0.25 |    0.00 |  292.18 KB |        0.90 |
|            |       |                      |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)lysis [22]** | **2,271.7 μs** | **126.19 μs** | **83.47 μs** |  **1.00** |    **0.05** | **2901.55 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)lysis [22] | 1,237.4 μs |  73.60 μs | 38.50 μs |  0.55 |    0.02 | 2823.43 KB |        0.97 |
