```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)cdFix [23]** | **5,575.3 μs** | **164.48 μs** | **108.80 μs** |  **1.00** |    **0.03** |   **241.7 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)cdFix [23] |   275.4 μs |  69.04 μs |  41.09 μs |  0.05 |    0.01 |  121.36 KB |        0.50 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)cdFix [23]** | **7,031.5 μs** | **387.49 μs** | **230.59 μs** |  **1.00** |    **0.04** | **2384.16 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)cdFix [23] |   386.8 μs |  69.98 μs |  41.64 μs |  0.06 |    0.01 |  1132.1 KB |        0.47 |
