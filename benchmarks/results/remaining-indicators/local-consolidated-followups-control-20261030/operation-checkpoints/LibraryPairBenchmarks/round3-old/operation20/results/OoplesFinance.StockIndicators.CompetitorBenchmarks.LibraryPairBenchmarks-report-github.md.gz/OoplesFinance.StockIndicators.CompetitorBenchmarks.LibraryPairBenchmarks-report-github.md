```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId       | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------- |-----------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.T3** |   **805.0 μs** |    **19.35 μs** |  **11.52 μs** |  **1.00** |    **0.02** |  **105.89 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.T3 |   311.6 μs |     8.46 μs |   5.03 μs |  0.39 |    0.01 |   73.72 KB |        0.70 |
|            |       |              |            |             |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.T3** | **3,562.7 μs** | **1,071.80 μs** | **560.57 μs** |  **1.02** |    **0.23** | **1034.93 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.T3 |   829.4 μs |    73.60 μs |  43.80 μs |  0.24 |    0.04 |  645.34 KB |        0.62 |
