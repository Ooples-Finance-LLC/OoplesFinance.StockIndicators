```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId          | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetTrix** | **5,902.7 μs** |  **45.11 μs** |  **26.84 μs** |  **1.00** |    **0.01** |  **210.99 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetTrix |   907.6 μs | 302.49 μs | 180.00 μs |  0.15 |    0.03 |   203.7 KB |        0.97 |
|            |       |                 |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetTrix** | **9,124.7 μs** | **459.34 μs** | **303.83 μs** |  **1.00** |    **0.04** | **2073.69 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetTrix | 1,374.0 μs | 345.47 μs | 205.58 μs |  0.15 |    0.02 | 1953.33 KB |        0.94 |
