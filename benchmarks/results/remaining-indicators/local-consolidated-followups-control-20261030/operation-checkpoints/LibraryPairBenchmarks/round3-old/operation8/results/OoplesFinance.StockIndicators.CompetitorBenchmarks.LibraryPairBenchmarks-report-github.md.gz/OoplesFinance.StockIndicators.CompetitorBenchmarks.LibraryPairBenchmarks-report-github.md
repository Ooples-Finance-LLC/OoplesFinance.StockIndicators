```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Macd** | **5,523.5 μs** |    **48.71 μs** |  **28.99 μs** |  **1.00** |    **0.01** |  **242.08 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Macd |   388.1 μs |   202.13 μs | 133.69 μs |  0.07 |    0.02 |  121.36 KB |        0.50 |
|            |       |                      |            |             |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Macd** | **7,668.4 μs** | **1,166.35 μs** | **694.08 μs** |  **1.01** |    **0.12** | **2389.17 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Macd |   377.6 μs |    57.14 μs |  34.00 μs |  0.05 |    0.01 |  1129.8 KB |        0.47 |
