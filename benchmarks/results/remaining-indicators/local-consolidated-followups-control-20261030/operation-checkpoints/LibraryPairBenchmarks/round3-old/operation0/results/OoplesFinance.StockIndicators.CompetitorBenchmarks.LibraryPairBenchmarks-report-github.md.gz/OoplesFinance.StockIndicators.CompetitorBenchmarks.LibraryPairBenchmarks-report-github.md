```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId             | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ma** | **1,097.7 μs** |  **32.22 μs** |  **16.85 μs** |  **1.00** |    **0.02** |  **729.09 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ma |   109.7 μs |   4.58 μs |   2.73 μs |  0.10 |    0.00 |   40.95 KB |        0.06 |
|            |       |                    |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ma** | **3,286.1 μs** | **390.77 μs** | **232.54 μs** |  **1.00** |    **0.10** | **6721.89 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ma |   137.9 μs |  13.72 μs |   8.16 μs |  0.04 |    0.00 |  330.95 KB |        0.05 |
