```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Fwma** |   **563.9 μs** |  **24.53 μs** |  **16.22 μs** |  **1.00** |    **0.04** |  **15.98 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Fwma |   445.7 μs |  13.35 μs |   7.94 μs |  0.79 |    0.03 | 262.73 KB |       16.44 |
|            |       |                |            |           |           |       |         |           |             |
| **Ooples**     | **10000** | **QuanTAlib.Fwma** |   **835.5 μs** |  **48.16 μs** |  **25.19 μs** |  **1.00** |    **0.04** | **164.15 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Fwma | 1,151.7 μs | 175.63 μs | 104.51 μs |  1.38 |    0.12 | 2572.5 KB |       15.67 |
