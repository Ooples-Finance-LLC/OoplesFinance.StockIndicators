```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDM [22]** |   **870.1 μs** |    **24.30 μs** |  **14.46 μs** |  **1.00** |    **0.02** |  **105.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDM [22] |   146.8 μs |    10.08 μs |   6.00 μs |  0.17 |    0.01 |   40.88 KB |        0.39 |
|            |       |                      |            |             |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDM [22]** | **4,561.3 μs** | **1,169.94 μs** | **696.21 μs** |  **1.02** |    **0.23** | **1037.05 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDM [22] |   226.8 μs |     8.35 μs |   4.37 μs |  0.05 |    0.01 |   329.6 KB |        0.32 |
