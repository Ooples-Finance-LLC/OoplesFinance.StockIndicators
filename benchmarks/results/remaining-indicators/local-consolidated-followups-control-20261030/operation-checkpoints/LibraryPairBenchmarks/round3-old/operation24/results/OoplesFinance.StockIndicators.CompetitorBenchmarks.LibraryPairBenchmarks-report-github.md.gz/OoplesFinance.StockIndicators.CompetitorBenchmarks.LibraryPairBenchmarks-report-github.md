```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error    | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|---------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)vgDev [22]** | **588.20 μs** | **47.63 μs** | **31.508 μs** |  **1.00** |    **0.07** |  **97.63 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)vgDev [22] |  62.32 μs | 10.24 μs |  6.776 μs |  0.11 |    0.01 |  23.84 KB |        0.24 |
|            |       |                      |           |          |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)vgDev [22]** | **539.89 μs** | **27.77 μs** | **16.528 μs** |  **1.00** |    **0.04** | **668.34 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)vgDev [22] | 352.91 μs | 89.69 μs | 59.324 μs |  0.65 |    0.11 |  164.8 KB |        0.25 |
