```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0      | Allocated   | Alloc Ratio |
|----------- |------ |--------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetPrs** | **2,129.6 μs** |  **62.29 μs** |  **37.07 μs** |  **1.00** |    **0.02** |         **-** |  **1180.85 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetPrs |   753.6 μs |  85.58 μs |  56.60 μs |  0.35 |    0.03 |         - |   256.27 KB |        0.22 |
|            |       |                |            |           |           |       |         |           |             |             |
| **Ooples**     | **10000** | **Skender.GetPrs** | **3,795.4 μs** | **768.94 μs** | **402.17 μs** |  **1.01** |    **0.14** | **1000.0000** | **10707.61 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetPrs | 1,652.9 μs | 199.45 μs | 118.69 μs |  0.44 |    0.05 |         - |  2462.04 KB |        0.23 |
