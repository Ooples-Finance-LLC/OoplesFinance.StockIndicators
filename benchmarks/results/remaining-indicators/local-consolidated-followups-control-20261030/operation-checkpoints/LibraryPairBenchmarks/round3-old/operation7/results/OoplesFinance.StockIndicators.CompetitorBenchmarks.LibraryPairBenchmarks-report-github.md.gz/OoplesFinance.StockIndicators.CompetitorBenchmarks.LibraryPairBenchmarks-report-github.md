```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Mavp** |   **508.1 μs** |  **18.72 μs** |  **11.14 μs** |  **1.00** |    **0.03** |  **107.52 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Mavp |   693.2 μs | 631.00 μs | 375.50 μs |  1.37 |    0.70 |   60.81 KB |        0.57 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Mavp** | **1,541.1 μs** | **372.23 μs** | **246.21 μs** |  **1.02** |    **0.23** | **1038.53 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Mavp |   604.6 μs | 102.36 μs |  53.54 μs |  0.40 |    0.07 |  526.63 KB |        0.51 |
