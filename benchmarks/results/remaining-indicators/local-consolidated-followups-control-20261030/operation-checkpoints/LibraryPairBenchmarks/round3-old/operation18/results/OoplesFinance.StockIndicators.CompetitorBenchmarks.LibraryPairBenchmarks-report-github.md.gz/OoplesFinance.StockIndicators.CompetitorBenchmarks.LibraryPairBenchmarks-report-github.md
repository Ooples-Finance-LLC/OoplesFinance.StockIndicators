```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId        | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetT3** |   **717.8 μs** |  **22.13 μs** |  **13.17 μs** |  **1.00** |    **0.02** |  **105.89 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetT3 |   957.3 μs |  57.93 μs |  34.47 μs |  1.33 |    0.05 |  115.65 KB |        1.09 |
|            |       |               |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetT3** | **3,466.1 μs** | **814.57 μs** | **426.04 μs** |  **1.01** |    **0.16** |  **1036.9 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetT3 | 1,220.9 μs | 280.82 μs | 185.75 μs |  0.36 |    0.07 | 1073.38 KB |        1.04 |
