```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)chRsi [24]** | **2,766.3 μs** |  **60.10 μs** |  **35.76 μs** |  **1.00** |    **0.02** |  **739.13 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)chRsi [24] |   349.9 μs |  16.99 μs |  10.11 μs |  0.13 |    0.00 |   88.97 KB |        0.12 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)chRsi [24]** | **8,240.9 μs** | **530.57 μs** | **277.50 μs** |  **1.00** |    **0.04** | **7427.19 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)chRsi [24] |   535.8 μs |  28.10 μs |  16.72 μs |  0.07 |    0.00 |  809.67 KB |        0.11 |
