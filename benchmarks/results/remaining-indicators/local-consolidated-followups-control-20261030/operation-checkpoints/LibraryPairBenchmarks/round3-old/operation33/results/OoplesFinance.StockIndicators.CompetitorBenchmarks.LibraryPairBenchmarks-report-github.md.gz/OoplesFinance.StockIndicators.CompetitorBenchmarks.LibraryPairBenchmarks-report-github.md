```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId             | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Dx** | **2,508.9 μs** |  **66.87 μs** |  **44.23 μs** |  **1.00** |    **0.02** |  **105.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Dx |   304.6 μs |  42.82 μs |  22.40 μs |  0.12 |    0.01 |   40.23 KB |        0.38 |
|            |       |                    |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Dx** | **8,409.4 μs** | **318.00 μs** | **189.24 μs** |  **1.00** |    **0.03** | **1037.05 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Dx |   337.9 μs |  75.54 μs |  49.96 μs |  0.04 |    0.01 |  330.92 KB |        0.32 |
