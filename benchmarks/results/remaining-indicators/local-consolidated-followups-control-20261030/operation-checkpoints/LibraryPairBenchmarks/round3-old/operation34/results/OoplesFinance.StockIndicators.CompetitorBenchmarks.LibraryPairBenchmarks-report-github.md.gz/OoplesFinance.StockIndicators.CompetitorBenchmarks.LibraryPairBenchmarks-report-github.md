```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId              | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adx** | **2,338.5 μs** |  **58.48 μs** |  **38.68 μs** |  **1.00** |    **0.02** | **106.36 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adx |   269.3 μs |  62.66 μs |  41.45 μs |  0.12 |    0.02 |  40.88 KB |        0.38 |
|            |       |                     |            |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adx** | **7,834.0 μs** | **293.47 μs** | **174.64 μs** |  **1.00** |    **0.03** | **1046.3 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adx |   367.2 μs |  37.74 μs |  22.46 μs |  0.05 |    0.00 | 328.95 KB |        0.31 |
