```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDI [22]** | **1,430.2 μs** |    **49.63 μs** |  **32.83 μs** |  **1.00** |    **0.03** |  **105.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDI [22] |   207.1 μs |    17.91 μs |  11.85 μs |  0.14 |    0.01 |    40.6 KB |        0.38 |
|            |       |                      |            |             |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDI [22]** | **4,770.5 μs** | **1,387.55 μs** | **917.78 μs** |  **1.03** |    **0.25** | **1036.77 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDI [22] |   284.4 μs |    20.46 μs |  13.53 μs |  0.06 |    0.01 |  330.64 KB |        0.32 |
