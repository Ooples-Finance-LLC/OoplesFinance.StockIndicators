```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio  | RatioSD | Gen0      | Gen1      | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|-------:|--------:|----------:|----------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)Index [37]** |   **1.139 ms** | **0.0582 ms** | **0.0385 ms** |   **1.00** |    **0.05** |         **-** |         **-** |  **116.91 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)Index [37] |  17.696 ms | 6.5249 ms | 4.3158 ms |  15.55 |    3.65 |         - |         - | 4705.22 KB |       40.25 |
|            |       |                      |            |           |           |        |         |           |           |            |             |
| **Ooples**     | **10000** | **Trady(...)Index [37]** |   **1.151 ms** | **0.0934 ms** | **0.0556 ms** |   **1.00** |    **0.06** |         **-** |         **-** | **1048.91 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)Index [37] | 141.730 ms | 4.4935 ms | 2.3502 ms | 123.36 |    5.71 | 5000.0000 | 1000.0000 | 48262.9 KB |       46.01 |
