```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId           | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |----------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Afirma** |   **626.7 μs** |   **9.75 μs** |   **5.80 μs** |  **1.00** |    **0.01** |  **24.68 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Afirma | 1,034.4 μs |  24.54 μs |  12.84 μs |  1.65 |    0.02 |  55.77 KB |        2.26 |
|            |       |                  |            |           |           |       |         |           |             |
| **Ooples**     | **10000** | **QuanTAlib.Afirma** | **1,657.0 μs** | **163.12 μs** | **107.89 μs** |  **1.00** |    **0.10** | **243.16 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Afirma | 2,732.6 μs | 351.69 μs | 232.62 μs |  1.66 |    0.18 | 477.65 KB |        1.96 |
