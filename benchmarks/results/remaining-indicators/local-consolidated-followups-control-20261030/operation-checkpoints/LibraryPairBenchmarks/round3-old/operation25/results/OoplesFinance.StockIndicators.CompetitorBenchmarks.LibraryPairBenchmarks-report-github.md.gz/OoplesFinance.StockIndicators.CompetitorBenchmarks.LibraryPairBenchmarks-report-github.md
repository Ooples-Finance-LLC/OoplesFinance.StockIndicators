```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId              | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Cci** |   **798.3 μs** |  **49.25 μs** |  **32.58 μs** |  **1.00** |    **0.05** | **109.41 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Cci |   422.3 μs |  12.16 μs |   8.04 μs |  0.53 |    0.02 |  41.11 KB |        0.38 |
|            |       |                     |            |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Cci** | **2,680.3 μs** | **807.61 μs** | **480.59 μs** |  **1.03** |    **0.25** | **1040.8 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Cci |   433.1 μs | 119.82 μs |  79.26 μs |  0.17 |    0.04 | 331.43 KB |        0.32 |
