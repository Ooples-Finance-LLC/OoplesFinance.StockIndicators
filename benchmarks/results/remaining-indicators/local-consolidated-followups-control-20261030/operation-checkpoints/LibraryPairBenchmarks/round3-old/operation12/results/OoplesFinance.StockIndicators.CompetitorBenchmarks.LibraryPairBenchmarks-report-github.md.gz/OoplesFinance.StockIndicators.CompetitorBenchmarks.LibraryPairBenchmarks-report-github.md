```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId          | Mean     | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |---------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetMacd** | **6.013 ms** | **0.0839 ms** | **0.0555 ms** |  **1.00** |    **0.01** |  **371.06 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetMacd | 1.132 ms | 0.2802 ms | 0.1854 ms |  0.19 |    0.03 |  456.73 KB |        1.23 |
|            |       |                 |          |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetMacd** | **8.131 ms** | **0.1729 ms** | **0.1029 ms** |  **1.00** |    **0.02** | **3660.73 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetMacd | 1.449 ms | 0.4564 ms | 0.3019 ms |  0.18 |    0.04 | 4672.18 KB |        1.28 |
