```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)bands [24]** | **10,886.8 μs** | **959.76 μs** | **634.82 μs** |  **1.00** |    **0.08** |         **-** |         **-** |  **3825.14 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)bands [24] |    290.8 μs |   9.27 μs |   4.85 μs |  0.03 |    0.00 |         - |         - |    122.5 KB |        0.03 |
|            |       |                      |             |           |           |       |         |           |           |             |             |
| **Ooples**     | **10000** | **TaLib(...)bands [24]** |  **9,803.4 μs** | **681.38 μs** | **405.48 μs** |  **1.00** |    **0.06** | **4000.0000** | **1000.0000** | **38721.93 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)bands [24] |    375.5 μs | 183.27 μs | 121.22 μs |  0.04 |    0.01 |         - |         - |   1131.6 KB |        0.03 |
