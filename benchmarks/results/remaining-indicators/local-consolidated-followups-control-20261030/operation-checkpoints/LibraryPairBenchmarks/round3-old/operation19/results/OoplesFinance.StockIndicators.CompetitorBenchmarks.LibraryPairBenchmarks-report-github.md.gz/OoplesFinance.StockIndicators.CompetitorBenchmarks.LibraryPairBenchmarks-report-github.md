```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId             | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-----------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.T3** |   **725.6 μs** |    **17.91 μs** |  **10.66 μs** |  **1.00** |    **0.02** |  **105.89 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.T3 |   138.0 μs |    10.18 μs |   6.06 μs |  0.19 |    0.01 |   40.55 KB |        0.38 |
|            |       |                    |            |             |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.T3** | **3,734.8 μs** | **1,094.86 μs** | **651.53 μs** |  **1.02** |    **0.23** | **1036.95 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.T3 |   183.8 μs |    32.84 μs |  19.55 μs |  0.05 |    0.01 |  328.01 KB |        0.32 |
