```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)ogram [59]** |  **5.617 ms** | **0.0956 ms** | **0.0569 ms** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |   **280.09 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)ogram [59] | 11.268 ms | 2.2320 ms | 1.4763 ms |  2.01 |    0.25 |         - |         - |         - |     4824 KB |       17.22 |
|            |       |                      |           |           |           |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)ogram [59]** |  **9.711 ms** | **2.6716 ms** | **1.7671 ms** |  **1.03** |    **0.25** |         **-** |         **-** |         **-** |  **2761.88 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)ogram [59] | 40.324 ms | 8.1770 ms | 5.4086 ms |  4.28 |    0.91 | 3000.0000 | 2000.0000 | 1000.0000 | 36352.77 KB |       13.16 |
