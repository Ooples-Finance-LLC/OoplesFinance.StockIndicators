```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adxr** | **2,512.0 μs** |  **65.54 μs** |  **43.35 μs** |  **1.00** |    **0.02** |  **107.43 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adxr |   255.3 μs |  12.37 μs |   8.18 μs |  0.10 |    0.00 |   48.17 KB |        0.45 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adxr** | **8,213.2 μs** | **187.99 μs** | **111.87 μs** |  **1.00** |    **0.02** | **1047.66 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adxr |   407.8 μs |  33.13 μs |  19.71 μs |  0.05 |    0.00 |  408.48 KB |        0.39 |
