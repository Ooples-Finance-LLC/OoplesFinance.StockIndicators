```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetPvo** |  **7,435.5 μs** | **100.35 μs** |  **52.49 μs** |  **1.00** |    **0.01** |  **503.59 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetPvo |    864.1 μs |  76.16 μs |  39.83 μs |  0.12 |    0.01 |  375.91 KB |        0.75 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetPvo** | **10,231.7 μs** | **285.15 μs** | **169.69 μs** |  **1.00** |    **0.02** | **4998.15 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetPvo |  1,536.0 μs | 162.49 μs |  96.69 μs |  0.15 |    0.01 | 3868.69 KB |        0.77 |
