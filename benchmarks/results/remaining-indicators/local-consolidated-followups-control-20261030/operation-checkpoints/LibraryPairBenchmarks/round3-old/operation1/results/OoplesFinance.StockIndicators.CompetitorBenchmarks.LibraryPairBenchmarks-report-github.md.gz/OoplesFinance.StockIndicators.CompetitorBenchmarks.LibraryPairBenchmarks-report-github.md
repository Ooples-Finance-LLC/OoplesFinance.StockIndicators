```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId              | Mean       | Error       | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Allocated   | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|------------:|----------:|------:|--------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Apo** | **3,067.5 μs** |   **187.01 μs** | **123.69 μs** |  **1.00** |    **0.05** |         **-** |         **-** |  **2007.88 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Apo |   156.9 μs |    13.36 μs |   8.84 μs |  0.05 |    0.00 |         - |         - |    48.88 KB |        0.02 |
|            |       |                     |            |             |           |       |         |           |           |             |             |
| **Ooples**     | **10000** | **TaLib.Functions.Apo** | **6,316.9 μs** | **1,441.46 μs** | **953.44 μs** |  **1.02** |    **0.21** | **2000.0000** | **1000.0000** | **18680.36 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Apo |   187.7 μs |    21.68 μs |  12.90 μs |  0.03 |    0.00 |         - |         - |   409.23 KB |        0.02 |
