```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId            | Mean     | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------ |---------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetZigZag** | **1.363 ms** | **0.0414 ms** | **0.0274 ms** |  **1.00** |    **0.03** |  **575.89 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetZigZag | 1.555 ms | 0.0269 ms | 0.0141 ms |  1.14 |    0.02 |  430.48 KB |        0.75 |
|            |       |                   |          |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetZigZag** | **6.071 ms** | **1.6506 ms** | **1.0918 ms** |  **1.03** |    **0.26** |  **5607.4 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetZigZag | 3.685 ms | 0.9132 ms | 0.6040 ms |  0.63 |    0.15 | 4090.44 KB |        0.73 |
