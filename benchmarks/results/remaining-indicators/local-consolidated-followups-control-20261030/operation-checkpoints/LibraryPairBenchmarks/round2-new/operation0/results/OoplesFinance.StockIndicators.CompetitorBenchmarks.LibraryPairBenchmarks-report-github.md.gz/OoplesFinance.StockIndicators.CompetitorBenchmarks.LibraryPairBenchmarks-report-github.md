```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId             | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |------------------- |-----------:|------------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ma** |   **488.7 μs** |    **47.28 μs** |  **31.27 μs** |  **1.00** |    **0.09** | **132.84 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ma |   123.4 μs |     9.86 μs |   5.87 μs |  0.25 |    0.02 |  41.23 KB |        0.31 |
|            |       |                    |            |             |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ma** | **3,179.7 μs** | **1,376.70 μs** | **910.60 μs** |  **1.09** |    **0.47** | **1064.5 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ma |   168.1 μs |    20.90 μs |  13.83 μs |  0.06 |    0.02 | 331.27 KB |        0.31 |
