```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId           | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |----------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Afirma** |   **627.6 μs** |  **14.08 μs** |   **8.38 μs** |  **1.00** |    **0.02** |  **24.68 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Afirma | 1,362.1 μs | 254.22 μs | 168.15 μs |  2.17 |    0.26 |  55.77 KB |        2.26 |
|            |       |                  |            |           |           |       |         |           |             |
| **Ooples**     | **10000** | **QuanTAlib.Afirma** | **1,268.5 μs** | **251.26 μs** | **166.19 μs** |  **1.01** |    **0.17** | **243.45 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Afirma | 2,964.6 μs | 223.47 μs | 147.81 μs |  2.37 |    0.30 | 477.93 KB |        1.96 |
