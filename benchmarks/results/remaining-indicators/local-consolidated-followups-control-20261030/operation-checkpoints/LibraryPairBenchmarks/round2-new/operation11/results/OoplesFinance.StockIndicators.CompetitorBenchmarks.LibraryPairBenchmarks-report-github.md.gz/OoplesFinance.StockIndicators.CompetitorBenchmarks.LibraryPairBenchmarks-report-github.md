```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)ogram [59]** |  **3.231 ms** | **0.0319 ms** | **0.0167 ms** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |   **240.77 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)ogram [59] |  8.809 ms | 1.6330 ms | 1.0801 ms |  2.73 |    0.32 |         - |         - |         - |  4823.95 KB |       20.04 |
|            |       |                      |           |           |           |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)ogram [59]** |  **7.151 ms** | **1.1717 ms** | **0.7750 ms** |  **1.01** |    **0.15** |         **-** |         **-** |         **-** |  **2368.12 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)ogram [59] | 38.560 ms | 1.7112 ms | 1.1318 ms |  5.45 |    0.60 | 3000.0000 | 2000.0000 | 1000.0000 | 36352.81 KB |       15.35 |
