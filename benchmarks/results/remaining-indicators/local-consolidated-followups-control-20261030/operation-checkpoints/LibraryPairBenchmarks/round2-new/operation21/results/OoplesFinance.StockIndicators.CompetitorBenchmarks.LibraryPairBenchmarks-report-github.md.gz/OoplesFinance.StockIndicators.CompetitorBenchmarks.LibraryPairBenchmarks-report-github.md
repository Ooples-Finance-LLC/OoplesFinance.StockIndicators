```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId            | Mean     | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------ |---------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetZigZag** | **1.115 ms** | **0.0475 ms** | **0.0282 ms** |  **1.00** |    **0.03** |  **479.98 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetZigZag | 2.113 ms | 0.4182 ms | 0.2766 ms |  1.90 |    0.24 |   430.2 KB |        0.90 |
|            |       |                   |          |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetZigZag** | **4.712 ms** | **1.5192 ms** | **1.0048 ms** |  **1.04** |    **0.31** | **4847.78 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetZigZag | 3.873 ms | 0.4577 ms | 0.3027 ms |  0.86 |    0.19 | 4090.77 KB |        0.84 |
