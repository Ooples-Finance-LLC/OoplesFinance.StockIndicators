```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDI [23]** | **1,421.4 μs** |    **55.88 μs** |  **36.96 μs** |  **1.00** |    **0.03** |  **105.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDI [23] |   188.3 μs |    13.22 μs |   7.86 μs |  0.13 |    0.01 |   40.88 KB |        0.39 |
|            |       |                      |            |             |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDI [23]** | **4,473.4 μs** | **1,090.64 μs** | **721.39 μs** |  **1.02** |    **0.22** | **1036.72 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDI [23] |   254.2 μs |    42.22 μs |  22.08 μs |  0.06 |    0.01 |  329.98 KB |        0.32 |
