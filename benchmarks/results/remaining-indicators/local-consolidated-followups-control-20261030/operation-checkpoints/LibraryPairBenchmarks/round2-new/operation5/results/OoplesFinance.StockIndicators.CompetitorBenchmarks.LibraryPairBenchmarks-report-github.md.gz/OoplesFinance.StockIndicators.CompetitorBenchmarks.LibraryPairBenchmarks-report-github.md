```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tochF [22]** | **1,413.3 μs** |  **87.82 μs** |  **52.26 μs** |  **1.00** |    **0.05** |  **482.55 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tochF [22] |   343.0 μs |  32.14 μs |  19.13 μs |  0.24 |    0.02 |   97.66 KB |        0.20 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)tochF [22]** | **6,679.3 μs** | **243.16 μs** | **144.70 μs** |  **1.00** |    **0.03** | **4657.38 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tochF [22] |   416.5 μs |  62.89 μs |  32.89 μs |  0.06 |    0.00 |  888.67 KB |        0.19 |
