```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId             | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Dx** |  **2,457.9 μs** |  **56.47 μs** |  **37.35 μs** |  **1.00** |    **0.02** |  **105.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Dx |    293.5 μs |  77.68 μs |  40.63 μs |  0.12 |    0.02 |   40.88 KB |        0.39 |
|            |       |                    |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Dx** | **10,636.4 μs** | **943.02 μs** | **623.75 μs** |  **1.00** |    **0.08** | **1037.05 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Dx |    405.1 μs |  72.40 μs |  47.89 μs |  0.04 |    0.00 |  330.64 KB |        0.32 |
