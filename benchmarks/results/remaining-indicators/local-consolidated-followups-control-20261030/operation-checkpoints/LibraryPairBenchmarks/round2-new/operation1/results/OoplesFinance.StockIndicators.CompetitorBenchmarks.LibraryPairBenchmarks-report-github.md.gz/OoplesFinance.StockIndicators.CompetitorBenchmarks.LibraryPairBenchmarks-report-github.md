```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId              | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Apo** | **1,257.5 μs** | **104.21 μs** |  **68.93 μs** |  **1.00** |    **0.07** |  **442.76 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Apo |   175.0 μs |  21.98 μs |  13.08 μs |  0.14 |    0.01 |   49.16 KB |        0.11 |
|            |       |                     |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Apo** | **1,921.7 μs** | **756.41 μs** | **500.32 μs** |  **1.05** |    **0.35** | **3623.34 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Apo |   197.4 μs |  95.26 μs |  49.83 μs |  0.11 |    0.04 |  409.52 KB |        0.11 |
