```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId          | Mean     | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |---------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetMacd** | **3.606 ms** | **0.0246 ms** | **0.0147 ms** |  **1.00** |    **0.01** |  **331.73 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetMacd | 1.045 ms | 0.1741 ms | 0.1036 ms |  0.29 |    0.03 |  457.02 KB |        1.38 |
|            |       |                 |          |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetMacd** | **6.907 ms** | **1.2170 ms** | **0.8050 ms** |  **1.01** |    **0.15** | **3266.98 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetMacd | 1.576 ms | 0.3663 ms | 0.2423 ms |  0.23 |    0.04 | 4672.46 KB |        1.43 |
