```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDM [23]** |   **867.3 μs** |  **46.90 μs** |  **31.02 μs** |  **1.00** |    **0.05** |  **105.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDM [23] |   159.3 μs |  30.57 μs |  20.22 μs |  0.18 |    0.02 |   40.88 KB |        0.39 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDM [23]** | **2,870.8 μs** | **623.03 μs** | **412.10 μs** |  **1.02** |    **0.19** | **1036.77 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDM [23] |   247.4 μs |  16.91 μs |  11.19 μs |  0.09 |    0.01 |  330.91 KB |        0.32 |
