```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetCci** |   **830.6 μs** |  **78.04 μs** |  **51.62 μs** |  **1.00** |    **0.08** |  **109.41 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetCci |   279.4 μs |  33.49 μs |  22.15 μs |  0.34 |    0.03 |  178.14 KB |        1.63 |
|            |       |                |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetCci** | **5,009.3 μs** | **445.45 μs** | **294.64 μs** |  **1.00** |    **0.08** |  **1040.8 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetCci | 1,075.1 μs | 203.63 μs | 121.18 μs |  0.22 |    0.03 | 1698.65 KB |        1.63 |
