```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDM [22]** |   **867.2 μs** |  **49.59 μs** |  **32.80 μs** |  **1.00** |    **0.05** |  **105.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDM [22] |   143.5 μs |   8.22 μs |   4.89 μs |  0.17 |    0.01 |   40.88 KB |        0.39 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDM [22]** | **2,799.2 μs** | **529.53 μs** | **350.25 μs** |  **1.01** |    **0.17** | **1036.77 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDM [22] |   227.1 μs |  21.63 μs |  12.87 μs |  0.08 |    0.01 |  330.59 KB |        0.32 |
