```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)cdExt [23]** | **2,163.6 μs** |   **134.36 μs** |  **88.87 μs** |  **1.00** |    **0.06** |  **858.48 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)cdExt [23] |   356.3 μs |    25.69 μs |  17.00 μs |  0.16 |    0.01 |   122.2 KB |        0.14 |
|            |       |                      |            |             |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)cdExt [23]** | **3,967.5 μs** | **1,471.57 μs** | **973.35 μs** |  **1.06** |    **0.37** | **7423.38 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)cdExt [23] |   272.8 μs |    74.40 μs |  44.27 μs |  0.07 |    0.02 | 1132.94 KB |        0.15 |
