```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId          | Mean     | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |---------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetTrix** | **5.426 ms** | **0.0632 ms** | **0.0418 ms** |  **1.00** |    **0.01** |  **211.13 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetTrix | 1.078 ms | 0.2938 ms | 0.1943 ms |  0.20 |    0.03 |  204.02 KB |        0.97 |
|            |       |                 |          |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetTrix** | **8.064 ms** | **0.8319 ms** | **0.5503 ms** |  **1.00** |    **0.09** | **2073.83 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetTrix | 1.246 ms | 0.2896 ms | 0.1916 ms |  0.16 |    0.02 | 1952.72 KB |        0.94 |
