```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)chRsi [24]** | **2,452.2 μs** |   **101.72 μs** |  **67.28 μs** |  **1.00** |    **0.04** |  **264.34 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)chRsi [24] |   346.4 μs |    24.80 μs |  14.76 μs |  0.14 |    0.01 |    89.3 KB |        0.34 |
|            |       |                      |            |             |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)chRsi [24]** | **6,490.9 μs** | **1,029.87 μs** | **612.86 μs** |  **1.01** |    **0.13** | **2610.05 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)chRsi [24] |   567.4 μs |    60.45 μs |  35.97 μs |  0.09 |    0.01 |     810 KB |        0.31 |
