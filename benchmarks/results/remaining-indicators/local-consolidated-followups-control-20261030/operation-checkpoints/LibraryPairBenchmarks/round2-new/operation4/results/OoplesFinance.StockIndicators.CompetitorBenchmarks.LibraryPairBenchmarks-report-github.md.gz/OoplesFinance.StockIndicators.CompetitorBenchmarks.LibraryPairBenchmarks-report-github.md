```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Stoch [21]** | **1,714.6 μs** |   **167.82 μs** |   **111.00 μs** |  **1.00** |    **0.09** |  **742.74 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Stoch [21] |   382.8 μs |    47.16 μs |    24.67 μs |  0.22 |    0.02 |   97.36 KB |        0.13 |
|            |       |                      |            |             |             |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)Stoch [21]** | **3,110.3 μs** | **1,880.54 μs** | **1,119.08 μs** |  **1.09** |    **0.47** | **7167.57 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Stoch [21] |   477.0 μs |    35.12 μs |    20.90 μs |  0.17 |    0.04 |   888.7 KB |        0.12 |
