```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDI [22]** | **1,394.5 μs** |  **67.00 μs** |  **44.32 μs** |  **1.00** |    **0.04** |  **105.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDI [22] |   195.6 μs |  38.66 μs |  25.57 μs |  0.14 |    0.02 |    40.6 KB |        0.38 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDI [22]** | **5,113.5 μs** | **540.23 μs** | **321.48 μs** |  **1.00** |    **0.09** | **1036.77 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDI [22] |   243.1 μs |  16.23 μs |   8.49 μs |  0.05 |    0.00 |  330.92 KB |        0.32 |
