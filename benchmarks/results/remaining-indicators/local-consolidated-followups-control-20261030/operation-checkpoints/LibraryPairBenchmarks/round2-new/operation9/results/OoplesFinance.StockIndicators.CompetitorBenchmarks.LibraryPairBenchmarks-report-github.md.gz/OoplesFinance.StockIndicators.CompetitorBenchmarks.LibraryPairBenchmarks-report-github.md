```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)cdFix [23]** | **3,726.2 μs** |  **59.98 μs** |  **39.68 μs** |  **1.00** |    **0.01** |  **203.25 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)cdFix [23] |   421.9 μs | 145.35 μs |  96.14 μs |  0.11 |    0.02 |  121.36 KB |        0.60 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)cdFix [23]** | **6,379.7 μs** | **814.58 μs** | **538.79 μs** |  **1.01** |    **0.12** | **1995.59 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)cdFix [23] |   369.8 μs |  68.59 μs |  40.81 μs |  0.06 |    0.01 | 1131.82 KB |        0.57 |
