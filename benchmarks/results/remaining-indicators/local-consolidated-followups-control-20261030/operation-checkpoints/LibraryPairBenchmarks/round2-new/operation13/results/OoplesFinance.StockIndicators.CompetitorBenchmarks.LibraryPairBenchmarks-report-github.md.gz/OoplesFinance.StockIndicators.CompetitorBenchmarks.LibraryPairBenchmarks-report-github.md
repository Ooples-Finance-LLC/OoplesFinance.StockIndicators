```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean       | Error      | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|-----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetPvo** | **5,530.1 μs** |   **151.1 μs** |  **89.93 μs** |  **1.00** |    **0.02** |  **290.13 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetPvo |   852.6 μs |   208.1 μs | 137.66 μs |  0.15 |    0.02 |  376.24 KB |        1.30 |
|            |       |                |            |            |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetPvo** | **9,508.8 μs** | **1,385.7 μs** | **916.52 μs** |  **1.01** |    **0.14** | **2855.95 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetPvo | 1,808.9 μs |   313.6 μs | 186.63 μs |  0.19 |    0.03 |  3870.7 KB |        1.36 |
