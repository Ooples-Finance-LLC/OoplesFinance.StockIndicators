```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Trix** | **5,271.0 μs** |  **51.77 μs** |  **27.08 μs** |  **1.00** |    **0.01** |  **192.99 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Trix |   216.4 μs |  49.38 μs |  32.66 μs |  0.04 |    0.01 |   48.41 KB |        0.25 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Trix** | **8,185.9 μs** | **940.89 μs** | **622.34 μs** |  **1.01** |    **0.11** | **1897.77 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Trix |   241.7 μs |  21.43 μs |  12.75 μs |  0.03 |    0.00 |  409.09 KB |        0.22 |
