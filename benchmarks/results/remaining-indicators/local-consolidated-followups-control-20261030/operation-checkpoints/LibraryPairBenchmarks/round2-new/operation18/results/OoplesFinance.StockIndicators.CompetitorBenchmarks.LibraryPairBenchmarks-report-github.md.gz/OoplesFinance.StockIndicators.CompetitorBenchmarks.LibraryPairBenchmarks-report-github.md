```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId        | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetT3** |   **767.2 μs** |  **33.20 μs** |  **21.96 μs** |  **1.00** |    **0.04** |  **105.89 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetT3 | 1,246.3 μs | 195.13 μs | 129.07 μs |  1.63 |    0.17 |  115.37 KB |        1.09 |
|            |       |               |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetT3** | **3,636.1 μs** | **776.49 μs** | **513.60 μs** |  **1.02** |    **0.19** | **1037.23 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetT3 | 1,346.6 μs | 362.81 μs | 239.98 μs |  0.38 |    0.08 | 1071.69 KB |        1.03 |
