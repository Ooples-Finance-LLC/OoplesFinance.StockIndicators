```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Macd** | **3,098.1 μs** |  **47.68 μs** |  **28.37 μs** |  **1.00** |    **0.01** |  **203.19 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Macd |   408.0 μs | 185.36 μs | 122.60 μs |  0.13 |    0.04 |  121.08 KB |        0.60 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Macd** | **5,620.2 μs** | **923.90 μs** | **611.10 μs** |  **1.01** |    **0.15** | **1995.57 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Macd |   383.7 μs | 163.57 μs |  85.55 μs |  0.07 |    0.02 |  1132.1 KB |        0.57 |
