```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|----------:|----------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)bands [24]** | **13,485.1 μs** | **991.48 μs** | **590.01 μs** |  **1.00** |    **0.06** |         **-** |         **-** | **3309.52 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)bands [24] |    356.9 μs |  16.87 μs |  11.16 μs |  0.03 |    0.00 |         - |         - |  120.86 KB |        0.04 |
|            |       |                      |             |           |           |       |         |           |           |            |             |
| **Ooples**     | **10000** | **TaLib(...)bands [24]** |  **9,764.8 μs** | **562.94 μs** | **372.35 μs** |  **1.00** |    **0.05** | **4000.0000** | **1000.0000** | **33497.1 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)bands [24] |    341.1 μs |  68.25 μs |  40.61 μs |  0.03 |    0.00 |         - |         - | 1132.96 KB |        0.03 |
