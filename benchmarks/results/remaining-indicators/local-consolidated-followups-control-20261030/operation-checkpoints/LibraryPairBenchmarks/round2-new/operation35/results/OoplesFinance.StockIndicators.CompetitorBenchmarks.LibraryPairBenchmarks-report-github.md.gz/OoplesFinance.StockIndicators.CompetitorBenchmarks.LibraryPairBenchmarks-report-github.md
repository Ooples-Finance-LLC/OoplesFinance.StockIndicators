```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adxr** | **2,496.7 μs** |  **84.87 μs** |  **56.14 μs** |  **1.00** |    **0.03** |  **107.43 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adxr |   243.0 μs |  14.78 μs |   9.78 μs |  0.10 |    0.00 |   48.45 KB |        0.45 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adxr** | **8,208.5 μs** | **536.76 μs** | **355.03 μs** |  **1.00** |    **0.06** | **1047.38 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adxr |   437.4 μs |  38.42 μs |  25.41 μs |  0.05 |    0.00 |  408.52 KB |        0.39 |
