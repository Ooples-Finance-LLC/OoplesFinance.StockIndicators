```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)vgDev [22]** | **680.43 μs** |  **54.596 μs** |  **32.489 μs** |  **1.00** |    **0.06** |  **97.63 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)vgDev [22] |  57.20 μs |   3.968 μs |   2.361 μs |  0.08 |    0.01 |  23.84 KB |        0.24 |
|            |       |                      |           |            |            |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)vgDev [22]** | **838.15 μs** | **198.477 μs** | **103.808 μs** |  **1.02** |    **0.20** | **668.29 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)vgDev [22] | 397.98 μs |  18.970 μs |  11.289 μs |  0.48 |    0.08 | 164.47 KB |        0.25 |
