```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Fwma** |   **490.5 μs** |  **24.91 μs** |  **16.47 μs** |  **1.00** |    **0.05** |   **15.98 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Fwma |   470.6 μs |  23.31 μs |  12.19 μs |  0.96 |    0.04 |  262.45 KB |       16.43 |
|            |       |                |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Fwma** |   **955.5 μs** | **109.86 μs** |  **72.66 μs** |  **1.01** |    **0.11** |  **164.43 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Fwma | 1,627.3 μs | 178.35 μs | 106.13 μs |  1.71 |    0.17 | 2572.22 KB |       15.64 |
