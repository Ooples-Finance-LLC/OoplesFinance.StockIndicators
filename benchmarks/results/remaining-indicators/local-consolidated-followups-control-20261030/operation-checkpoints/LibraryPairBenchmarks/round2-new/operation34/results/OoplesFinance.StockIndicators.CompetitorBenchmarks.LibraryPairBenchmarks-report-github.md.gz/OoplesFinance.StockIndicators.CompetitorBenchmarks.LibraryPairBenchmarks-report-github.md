```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId              | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adx** | **2,362.4 μs** | **58.41 μs** | **38.63 μs** |  **1.00** |    **0.02** | **106.36 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adx |   243.8 μs | 56.94 μs | 37.66 μs |  0.10 |    0.02 |   40.6 KB |        0.38 |
|            |       |                     |            |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adx** | **7,464.8 μs** | **85.70 μs** | **51.00 μs** |  **1.00** |    **0.01** | **1046.3 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adx |   369.1 μs | 35.28 μs | 23.34 μs |  0.05 |    0.00 | 329.66 KB |        0.32 |
