```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)gence [50]** |  **3.573 ms** | **0.0459 ms** | **0.0240 ms** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |   **290.13 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)gence [50] |  9.950 ms | 1.3112 ms | 0.8673 ms |  2.78 |    0.23 |         - |         - |         - |  4583.54 KB |       15.80 |
|            |       |                      |           |           |           |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)gence [50]** |  **7.428 ms** | **1.0477 ms** | **0.6930 ms** |  **1.01** |    **0.13** |         **-** |         **-** |         **-** |  **2856.93 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)gence [50] | 38.581 ms | 2.0999 ms | 1.3890 ms |  5.24 |    0.51 | 3000.0000 | 2000.0000 | 1000.0000 | 34693.17 KB |       12.14 |
