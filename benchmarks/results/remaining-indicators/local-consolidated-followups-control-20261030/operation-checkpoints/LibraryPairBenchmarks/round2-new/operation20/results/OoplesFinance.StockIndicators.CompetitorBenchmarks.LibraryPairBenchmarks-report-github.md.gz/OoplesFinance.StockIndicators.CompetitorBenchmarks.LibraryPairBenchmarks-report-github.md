```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId       | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------- |-----------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.T3** |   **841.6 μs** |    **38.25 μs** |  **25.30 μs** |  **1.00** |    **0.04** |  **105.89 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.T3 |   372.3 μs |    83.74 μs |  55.39 μs |  0.44 |    0.06 |   73.72 KB |        0.70 |
|            |       |              |            |             |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.T3** | **3,477.3 μs** | **1,382.26 μs** | **914.28 μs** |  **1.05** |    **0.35** | **1037.23 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.T3 |   961.8 μs |   159.14 μs | 105.26 μs |  0.29 |    0.07 |  644.33 KB |        0.62 |
