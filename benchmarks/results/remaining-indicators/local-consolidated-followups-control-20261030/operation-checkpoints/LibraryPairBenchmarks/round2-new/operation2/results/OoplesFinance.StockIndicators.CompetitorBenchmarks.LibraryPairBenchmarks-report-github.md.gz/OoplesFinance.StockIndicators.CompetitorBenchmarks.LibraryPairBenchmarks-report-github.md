```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId              | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0      | Allocated   | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ppo** | **2,438.6 μs** | **140.47 μs** |  **92.91 μs** |  **1.00** |    **0.05** |         **-** |  **1574.81 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ppo |   201.8 μs |  40.47 μs |  26.77 μs |  0.08 |    0.01 |         - |    49.16 KB |        0.03 |
|            |       |                     |            |           |           |       |         |           |             |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ppo** | **4,311.4 μs** | **682.33 μs** | **406.04 μs** |  **1.01** |    **0.12** | **1000.0000** | **15203.24 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ppo |   223.8 μs |  22.30 μs |  13.27 μs |  0.05 |    0.01 |         - |   409.23 KB |        0.03 |
