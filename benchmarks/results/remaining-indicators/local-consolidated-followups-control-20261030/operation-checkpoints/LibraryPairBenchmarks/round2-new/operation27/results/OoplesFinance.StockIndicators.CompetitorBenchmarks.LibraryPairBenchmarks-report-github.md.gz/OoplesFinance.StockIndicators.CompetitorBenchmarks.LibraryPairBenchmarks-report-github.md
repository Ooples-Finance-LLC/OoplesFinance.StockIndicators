```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio  | RatioSD | Gen0      | Gen1      | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|-------:|--------:|----------:|----------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)Index [37]** |   **1.114 ms** | **0.0808 ms** | **0.0534 ms** |   **1.00** |    **0.06** |         **-** |         **-** |  **116.91 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)Index [37] |  21.949 ms | 6.4077 ms | 4.2383 ms |  19.74 |    3.75 |         - |         - | 4704.94 KB |       40.24 |
|            |       |                      |            |           |           |        |         |           |           |            |             |
| **Ooples**     | **10000** | **Trady(...)Index [37]** |   **1.178 ms** | **0.1220 ms** | **0.0726 ms** |   **1.00** |    **0.08** |         **-** |         **-** | **1048.95 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)Index [37] | 183.831 ms | 6.8834 ms | 4.5529 ms | 156.53 |    9.52 | 5000.0000 | 1000.0000 | 48262.9 KB |       46.01 |
