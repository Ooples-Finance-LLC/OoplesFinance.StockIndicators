```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean       | Error    | StdDev    | Ratio | RatioSD | Gen0      | Allocated   | Alloc Ratio |
|----------- |------ |--------------- |-----------:|---------:|----------:|------:|--------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetPrs** | **2,043.9 μs** | **141.8 μs** |  **84.40 μs** |  **1.00** |    **0.06** |         **-** |  **1180.85 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetPrs |   794.4 μs | 112.2 μs |  74.22 μs |  0.39 |    0.04 |         - |   256.27 KB |        0.22 |
|            |       |                |            |          |           |       |         |           |             |             |
| **Ooples**     | **10000** | **Skender.GetPrs** | **3,782.6 μs** | **901.9 μs** | **471.71 μs** |  **1.01** |    **0.16** | **1000.0000** | **10708.27 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetPrs | 1,592.5 μs | 274.7 μs | 163.50 μs |  0.43 |    0.06 |         - |  2461.99 KB |        0.23 |
