```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId              | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Cci** |   **825.4 μs** |  **26.72 μs** |  **13.97 μs** |  **1.00** |    **0.02** |  **109.41 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Cci |   462.0 μs | 107.44 μs |  71.07 μs |  0.56 |    0.08 |   41.06 KB |        0.38 |
|            |       |                     |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Cci** | **1,309.4 μs** | **472.48 μs** | **312.51 μs** |  **1.05** |    **0.33** | **1041.08 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Cci |   440.4 μs | 100.93 μs |  60.06 μs |  0.35 |    0.09 |  331.43 KB |        0.32 |
