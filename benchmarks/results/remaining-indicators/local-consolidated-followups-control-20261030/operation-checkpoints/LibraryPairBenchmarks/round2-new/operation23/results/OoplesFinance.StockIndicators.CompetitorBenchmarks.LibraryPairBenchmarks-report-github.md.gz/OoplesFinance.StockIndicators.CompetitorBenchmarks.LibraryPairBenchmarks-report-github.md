```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)lysis [22]** | **2,215.7 μs** | **121.72 μs** |  **72.43 μs** |  **1.00** |    **0.04** |  **323.37 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)lysis [22] |   581.8 μs |  86.42 μs |  57.16 μs |  0.26 |    0.03 |  291.85 KB |        0.90 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)lysis [22]** | **3,053.8 μs** | **808.54 μs** | **534.80 μs** |  **1.03** |    **0.25** | **2901.27 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)lysis [22] | 1,702.5 μs | 417.80 μs | 276.35 μs |  0.57 |    0.13 | 2823.43 KB |        0.97 |
