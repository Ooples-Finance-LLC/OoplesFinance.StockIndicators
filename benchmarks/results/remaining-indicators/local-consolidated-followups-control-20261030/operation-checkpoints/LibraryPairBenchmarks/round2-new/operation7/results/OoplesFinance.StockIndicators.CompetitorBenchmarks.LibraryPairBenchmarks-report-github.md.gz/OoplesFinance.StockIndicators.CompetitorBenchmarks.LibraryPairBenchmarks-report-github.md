```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Mavp** |   **587.3 μs** |  **64.51 μs** |  **42.67 μs** |  **1.00** |    **0.10** |  **107.52 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Mavp |   450.4 μs | 208.72 μs | 109.16 μs |  0.77 |    0.18 |   60.81 KB |        0.57 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Mavp** | **1,639.8 μs** | **336.95 μs** | **222.87 μs** |  **1.02** |    **0.20** | **1038.53 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Mavp |   625.0 μs |  93.21 μs |  55.47 μs |  0.39 |    0.07 |  526.63 KB |        0.51 |
