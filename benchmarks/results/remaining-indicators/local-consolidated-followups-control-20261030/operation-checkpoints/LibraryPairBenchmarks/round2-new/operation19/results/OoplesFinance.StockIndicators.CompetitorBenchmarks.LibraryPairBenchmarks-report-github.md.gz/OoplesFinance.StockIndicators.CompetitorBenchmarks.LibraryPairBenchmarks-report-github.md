```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId             | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.T3** |   **799.1 μs** |  **72.38 μs** |  **47.88 μs** |  **1.00** |    **0.08** |  **105.89 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.T3 |   123.6 μs |   5.64 μs |   2.95 μs |  0.16 |    0.01 |   40.88 KB |        0.39 |
|            |       |                    |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.T3** | **3,200.0 μs** | **307.82 μs** | **183.18 μs** |  **1.00** |    **0.08** | **1037.23 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.T3 |   228.7 μs |  18.21 μs |  10.83 μs |  0.07 |    0.01 |  330.63 KB |        0.32 |
