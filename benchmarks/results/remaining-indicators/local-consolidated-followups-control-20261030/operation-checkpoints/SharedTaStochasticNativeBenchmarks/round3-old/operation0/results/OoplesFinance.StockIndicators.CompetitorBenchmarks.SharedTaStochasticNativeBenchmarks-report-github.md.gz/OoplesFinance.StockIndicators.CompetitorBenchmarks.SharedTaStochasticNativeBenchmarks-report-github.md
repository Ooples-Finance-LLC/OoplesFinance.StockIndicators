```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0      | Gen1     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|----------:|------:|--------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **1000**  |   **309.45 μs** |   **4.018 μs** |  **2.391 μs** | **24.40** |    **1.01** |  **152.3438** |  **35.1563** |  **1252.67 KB** |       **52.80** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 1000  |   306.11 μs |  17.875 μs | 11.823 μs | 24.14 |    1.33 |  148.4375 |  21.4844 |   1205.1 KB |       50.79 |
| NativeSingle      | TaLib(...)Stoch [21] | 1000  |    12.70 μs |   0.826 μs |  0.546 μs |  1.00 |    0.06 |    2.8687 |   0.1831 |    23.73 KB |        1.00 |
| NativeParallel    | TaLib(...)Stoch [21] | 1000  |    27.52 μs |   2.271 μs |  1.502 μs |  2.17 |    0.14 |   18.7988 |   3.1738 |   124.37 KB |        5.24 |
|                   |                      |       |             |            |           |       |         |           |          |             |             |
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **10000** | **3,195.96 μs** | **133.608 μs** | **88.373 μs** | **16.35** |    **0.56** | **1500.0000** | **250.0000** | **12293.78 KB** |       **52.39** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 10000 | 3,089.40 μs |  90.469 μs | 53.837 μs | 15.80 |    0.44 | 1453.1250 |  31.2500 | 11823.88 KB |       50.38 |
| NativeSingle      | TaLib(...)Stoch [21] | 10000 |   195.58 μs |   7.736 μs |  4.604 μs |  1.00 |    0.03 |   28.3203 |   8.7891 |   234.67 KB |        1.00 |
| NativeParallel    | TaLib(...)Stoch [21] | 10000 |   273.23 μs |   2.985 μs |  1.561 μs |  1.40 |    0.03 |  162.1094 | 115.2344 |  1214.22 KB |        5.17 |
