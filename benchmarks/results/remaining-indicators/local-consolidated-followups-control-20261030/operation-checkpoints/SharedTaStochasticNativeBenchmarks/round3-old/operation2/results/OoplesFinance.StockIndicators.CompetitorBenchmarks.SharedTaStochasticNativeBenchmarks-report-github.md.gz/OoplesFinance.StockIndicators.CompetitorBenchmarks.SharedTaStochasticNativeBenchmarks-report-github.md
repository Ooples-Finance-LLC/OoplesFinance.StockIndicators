```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)chRsi [24]** | **1000**  |   **933.93 μs** | **158.449 μs** | **104.805 μs** | **41.71** |    **4.60** |  **78.1250** |  **15.6250** |   **656.9 KB** |       **21.08** |
| BuilderLatestOnly | TaLib(...)chRsi [24] | 1000  |   810.60 μs |  20.152 μs |  11.992 μs | 36.20 |    1.09 |  70.3125 |        - |  609.34 KB |       19.56 |
| NativeSingle      | TaLib(...)chRsi [24] | 1000  |    22.41 μs |   0.945 μs |   0.625 μs |  1.00 |    0.04 |   3.7842 |   0.2441 |   31.16 KB |        1.00 |
| NativeParallel    | TaLib(...)chRsi [24] | 1000  |    37.76 μs |   0.658 μs |   0.391 μs |  1.69 |    0.05 |  23.6816 |   4.8828 |  157.74 KB |        5.06 |
|                   |                      |       |             |            |            |       |         |          |          |            |             |
| **BuilderFull**       | **TaLib(...)chRsi [24]** | **10000** | **8,179.60 μs** | **191.294 μs** | **113.836 μs** | **29.03** |    **0.65** | **727.2727** | **636.3636** | **6617.68 KB** |       **21.18** |
| BuilderLatestOnly | TaLib(...)chRsi [24] | 10000 | 8,124.67 μs | 270.159 μs | 160.767 μs | 28.84 |    0.75 | 692.3077 | 230.7692 |  6147.7 KB |       19.68 |
| NativeSingle      | TaLib(...)chRsi [24] | 10000 |   281.84 μs |   9.112 μs |   5.422 μs |  1.00 |    0.03 |  37.1094 |   9.7656 |  312.42 KB |        1.00 |
| NativeParallel    | TaLib(...)chRsi [24] | 10000 |   407.25 μs |  13.076 μs |   7.781 μs |  1.45 |    0.04 | 210.9375 | 148.4375 | 1564.02 KB |        5.01 |
