```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)tochF [22]** | **1000**  |   **212.28 μs** |  **4.543 μs** |  **3.005 μs** | **16.83** |    **1.43** |  **85.9375** |  **15.6250** |  **710.39 KB** |       **29.98** |
| BuilderLatestOnly | TaLib(...)tochF [22] | 1000  |   199.44 μs |  2.419 μs |  1.440 μs | 15.81 |    1.33 |  80.0781 |   9.7656 |  662.79 KB |       27.97 |
| NativeSingle      | TaLib(...)tochF [22] | 1000  |    12.69 μs |  1.584 μs |  1.048 μs |  1.01 |    0.12 |   2.8687 |   0.1831 |    23.7 KB |        1.00 |
| NativeParallel    | TaLib(...)tochF [22] | 1000  |    25.29 μs |  0.860 μs |  0.569 μs |  2.01 |    0.17 |  18.7988 |   3.4180 |  123.92 KB |        5.23 |
|                   |                      |       |             |           |           |       |         |          |          |            |             |
| **BuilderFull**       | **TaLib(...)tochF [22]** | **10000** | **2,115.06 μs** | **68.219 μs** | **40.596 μs** | **12.23** |    **0.44** | **843.7500** | **828.1250** | **6970.07 KB** |       **29.71** |
| BuilderLatestOnly | TaLib(...)tochF [22] | 10000 | 1,943.70 μs | 18.056 μs | 10.745 μs | 11.24 |    0.36 | 796.8750 | 265.6250 |  6500.2 KB |       27.70 |
| NativeSingle      | TaLib(...)tochF [22] | 10000 |   173.09 μs |  8.781 μs |  5.808 μs |  1.00 |    0.04 |  28.3203 |   8.7891 |  234.64 KB |        1.00 |
| NativeParallel    | TaLib(...)tochF [22] | 10000 |   256.90 μs |  3.458 μs |  2.058 μs |  1.49 |    0.05 | 162.1094 | 117.1875 | 1213.77 KB |        5.17 |
