```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error       | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |-----------:|------------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Cci** | **1000**  |  **77.048 μs** |  **13.7737 μs** |  **8.1965 μs** |  **2.51** |    **0.26** |  **7.8125** |       **-** |   **68.7 KB** |        **8.89** |
| BuilderLatestOnly | TaLib.Functions.Cci | 1000  |  75.530 μs |   2.4673 μs |  1.4682 μs |  2.46 |    0.06 |  2.4414 |       - |  21.09 KB |        2.73 |
| NativeSingle      | TaLib.Functions.Cci | 1000  |  30.737 μs |   1.1415 μs |  0.5970 μs |  1.00 |    0.03 |  0.7324 |       - |   7.73 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Cci | 1000  |   7.774 μs |   0.1600 μs |  0.0952 μs |  0.25 |    0.01 |  0.9766 |       - |   8.17 KB |        1.06 |
|                   |                     |       |            |             |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Cci** | **10000** | **813.677 μs** |   **3.8745 μs** |  **2.3057 μs** |  **2.67** |    **0.03** | **70.3125** | **62.5000** | **631.63 KB** |        **8.09** |
| BuilderLatestOnly | TaLib.Functions.Cci | 10000 | 742.007 μs | 143.4559 μs | 94.8872 μs |  2.43 |    0.30 | 15.6250 |       - | 161.79 KB |        2.07 |
| NativeSingle      | TaLib.Functions.Cci | 10000 | 305.233 μs |   7.1006 μs |  3.7137 μs |  1.00 |    0.02 |  7.8125 |       - |  78.05 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Cci | 10000 |  53.773 μs |   3.8931 μs |  2.5750 μs |  0.18 |    0.01 |  9.2773 |  1.4648 |  78.49 KB |        1.01 |
