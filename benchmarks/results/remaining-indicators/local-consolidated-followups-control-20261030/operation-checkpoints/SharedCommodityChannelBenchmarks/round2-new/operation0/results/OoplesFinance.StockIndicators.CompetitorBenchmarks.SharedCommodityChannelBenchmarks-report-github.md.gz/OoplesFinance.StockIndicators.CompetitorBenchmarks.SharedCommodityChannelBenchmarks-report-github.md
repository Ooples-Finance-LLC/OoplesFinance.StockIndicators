```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |-----------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Cci** | **1000**  |  **83.968 μs** |  **1.9593 μs** |  **1.1659 μs** |  **2.62** |    **0.10** |  **7.8125** |       **-** |   **68.7 KB** |        **8.89** |
| BuilderLatestOnly | TaLib.Functions.Cci | 1000  |  77.806 μs |  4.6300 μs |  3.0625 μs |  2.43 |    0.13 |  2.4414 |       - |  21.09 KB |        2.73 |
| NativeSingle      | TaLib.Functions.Cci | 1000  |  32.089 μs |  2.1995 μs |  1.3089 μs |  1.00 |    0.05 |  0.7324 |       - |   7.73 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Cci | 1000  |   7.882 μs |  0.3377 μs |  0.2234 μs |  0.25 |    0.01 |  0.9766 |       - |   8.17 KB |        1.06 |
|                   |                     |       |            |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Cci** | **10000** | **814.214 μs** | **81.9577 μs** | **54.2099 μs** |  **2.58** |    **0.18** | **70.3125** | **62.5000** | **631.63 KB** |        **8.09** |
| BuilderLatestOnly | TaLib.Functions.Cci | 10000 | 805.822 μs | 32.4824 μs | 21.4851 μs |  2.55 |    0.10 | 15.6250 |       - | 161.79 KB |        2.07 |
| NativeSingle      | TaLib.Functions.Cci | 10000 | 316.333 μs | 16.1844 μs | 10.7050 μs |  1.00 |    0.05 |  7.8125 |       - |  78.05 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Cci | 10000 |  55.882 μs |  6.4010 μs |  4.2339 μs |  0.18 |    0.01 |  9.2773 |  1.4648 |  78.49 KB |        1.01 |
