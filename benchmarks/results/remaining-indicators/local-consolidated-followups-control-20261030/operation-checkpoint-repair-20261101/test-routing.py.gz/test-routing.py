"""Exercise verifier routing with preserved real results, not new measurements."""
from pathlib import Path
import copy, hashlib, json, math, re, shutil, sys
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root))
from consolidated_acceptance import FIXTURE_PAIRS, methods as fixture_methods
from queue_status_io import read_queue_json,write_queue_json

archive=Path(__file__).parent;raw=archive.parent
source=(root/'verify-consolidated-control-20261030.py').read_text()
section=compile(source[source.index('rounds={}'):source.index('decisions=[]')],'actual-verifier-record-checks','exec')
canonical=lambda pair:{'CommodityChannelIndex':'Trady.Indicator.CommodityChannelIndex','MovingAverageConvergenceDivergence':'Trady.Indicator.MovingAverageConvergenceDivergence','MovingAverageConvergenceDivergenceHistogram':'Trady.Indicator.MovingAverageConvergenceDivergenceHistogram'}.get(pair,pair)
def verify(out,state):
    ns=dict(OUT=out,state=state,hashlib=hashlib,json=json,math=math,re=re,Path=Path,
        FIXTURE_PAIRS=FIXTURE_PAIRS,fixture_methods=fixture_methods,canonical=canonical)
    exec(section,ns)
    return ns['rounds']
state=read_queue_json(archive/'status.json')
assert len(verify(raw,state))==len(state['rounds'])==31
record=copy.deepcopy(next(r for r in state['rounds'] if r['fixture']=='SharedCommodityChannelBenchmarks'))
out=archive/'verifier-test-only';fixture=record['fixture'];index=record['index'];arm=record['arm']
directory=out/'operation-checkpoints'/fixture/f'round{index}-{arm}';directory.mkdir(parents=True,exist_ok=True)
report=directory/'original-report.json';report.write_bytes(Path(record['report']).read_bytes())
log=directory/'original.log';log.write_bytes((raw/f'round{index}-{arm}-{fixture}.log').read_bytes())
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=dict(pair=FIXTURE_PAIRS[fixture][0],report=str(report),sha256=digest(report),log=str(log),log_sha256=digest(log),
    cases=record['cases'],quiet_cpu_samples=record['quiet_cpu_samples'],quiet_build_free_samples=12,build_monitor_observations=record['build_monitor_observations'])
merged=out/'merged.json';merged.write_bytes(report.read_bytes())
(out/f'round{index}-{arm}-{fixture}.log').write_bytes(log.read_bytes())
record.update(report=str(merged),operation_checkpoints=[receipt],checkpoint_format='operation-v1')
new_state=dict(rounds=[record],order=state['order'])
assert len(verify(out,new_state))==1
for label,mutate in [('missing',lambda r:r['operation_checkpoints'].clear()),
                     ('duplicate',lambda r:r['operation_checkpoints'].append(copy.deepcopy(r['operation_checkpoints'][0]))),
                     ('hash',lambda r:r['operation_checkpoints'][0].update(sha256='invalid'))]:
    bad=copy.deepcopy(new_state);mutate(bad['rounds'][0])
    try:verify(out,bad)
    except AssertionError:pass
    else:raise AssertionError(label+' accepted')
for name in ['measure-consolidated-control-20261030.py','verify-consolidated-control-20261030.py','archive-consolidated-control-20261030.py']:
    compile((root/name).read_text(),name,'exec')
assert read_queue_json(archive/'runner-tests/checks.json')['status']=='passed'
checks=dict(status='passed',preserved_rounds_verified=31,
    checks=['unchanged completed rounds pass original verifier body','general-operation checkpoint passes verifier body',
            'missing duplicate and corrupt checkpoints rejected','interruption and restart regression tests pass','changed scripts compile'],
    note='Routing and control-code tests only. Test copies are preserved old measurements, not additional measured cases.')
write_queue_json(archive/'checks.json',checks)
print(json.dumps(checks))
