```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio  | RatioSD | Gen0      | Gen1      | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|-------:|--------:|----------:|----------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)Index [37]** |   **1.070 ms** | **0.0799 ms** | **0.0529 ms** |   **1.00** |    **0.07** |         **-** |         **-** |  **116.91 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)Index [37] |  21.951 ms | 5.5398 ms | 3.6642 ms |  20.56 |    3.42 |         - |         - | 4705.22 KB |       40.25 |
|            |       |                      |            |           |           |        |         |           |           |            |             |
| **Ooples**     | **10000** | **Trady(...)Index [37]** |   **1.213 ms** | **0.0528 ms** | **0.0314 ms** |   **1.00** |    **0.03** |         **-** |         **-** | **1049.23 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)Index [37] | 163.489 ms | 9.3222 ms | 6.1661 ms | 134.85 |    5.88 | 5000.0000 | 1000.0000 | 48262.9 KB |       46.00 |
