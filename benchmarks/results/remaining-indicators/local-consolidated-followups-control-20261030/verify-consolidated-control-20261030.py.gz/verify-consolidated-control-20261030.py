from consolidated_acceptance import PLAN, FIXTURE_PAIRS, MATRIX, TOTAL_CASES, methods as fixture_methods, qualification_valid
from pathlib import Path
import hashlib,json,math,re,subprocess
OUT=Path('C:/Users/cheat/StockIndicators-Recovery-20261021/local-consolidated-followups-control-20261030')
state=json.loads((OUT/'status.json').read_text(encoding='utf-8'))
assert state['status']=='raw-measurements-complete-independent-verification-pending'
assert state['order']==['old','new','new','old'] and len(state['rounds'])==4*len(MATRIX)
manifest=json.loads((OUT/'binary-manifest.json').read_text(encoding='utf-8'))
assert manifest['old'].keys()==manifest['new'].keys()
assert [p for p in manifest['old'] if manifest['old'][p]!=manifest['new'][p]]==['OoplesFinance.StockIndicators.dll']
proof=json.loads((OUT/'provenance.json').read_text(encoding='utf-8'))
repo=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-afirma-word-products-20261030')
paths=['src','tests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','benchmarks/OoplesFinance.StockIndicators.CompetitorTests','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json']
assert proof['candidate_code_source']==proof['qualification']['input_head']
assert proof['qualification']['status']==proof['old_qualification']['status']=='checks-passed-review-and-publication-pending'
assert proof['old_qualification']['gpu_passed']==100
qualification_valid(proof['qualification'])
assert proof['performance_plan']==PLAN
assert proof['qualification_chain']['fixed-kernel-word-followup']==proof['qualification']
for phase in PLAN['qualification_chain']:
 assert proof['qualification_chain'][phase]==json.loads((OUT.parent/'batched-optimization-20261030'/phase/'status.json').read_text())
assert manifest['old']['OoplesFinance.StockIndicators.dll'] in proof['old_qualification']['production_dll_sha256'].values()
assert not subprocess.check_output(['git','diff',proof['old_qualification']['input_head'],proof['old_source'],'--',*paths],cwd=repo)
assert not subprocess.check_output(['git','diff',proof['candidate_code_source'],proof['new_source'],'--',*paths],cwd=repo)
companions = {}
assert proof['sonar_only_companions'] == companions
assert set(subprocess.check_output(['git','diff','--name-only',proof['old_source'],proof['new_source'],'--',*paths],cwd=repo,text=True).splitlines())==set(PLAN["changed_inputs"]) | set(companions)
assert manifest['new']['OoplesFinance.StockIndicators.dll'] in proof['qualification']['production_dll_sha256'].values()
baseline=json.loads((OUT.parent/'consolidated-baseline.json').read_text(encoding='utf-8'))
for arm,folder in [('old',Path(baseline['checkout'])/'benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks/bin/Release/net10.0'),('new',OUT/'new')]:
 assert {p.relative_to(folder).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.rglob('*') if p.is_file()}==manifest[arm]
canonical=lambda pair: {'CommodityChannelIndex':'Trady.Indicator.CommodityChannelIndex','MovingAverageConvergenceDivergence':'Trady.Indicator.MovingAverageConvergenceDivergence','MovingAverageConvergenceDivergenceHistogram':'Trady.Indicator.MovingAverageConvergenceDivergenceHistogram'}.get(pair,pair)
rounds={}
for record in state['rounds']:
 index=record['index'];fixture=record['fixture'];assert record['arm']==state['order'][index]
 assert (fixture,index) not in rounds
 assert len(record['quiet_cpu_samples'])==12 and max(record['quiet_cpu_samples'])<=15
 assert record['quiet_build_free_samples']==12 and record['build_monitor_observations']>=1
 path=Path(record['report']);assert path.is_relative_to(OUT) and 'invalidated-attempts' not in path.parts
 raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()==record['sha256']
 if 'operation_checkpoints' in record:
  if record.get('checkpoint_format')=='operation-v1':
   from successor_checkpoint_runner import combine_reports
   checkpoint_root=OUT/'operation-checkpoints'/fixture/f'round{index}-{record["arm"]}'
  else:
   from directional_checkpoint_runner import combine_reports
   assert fixture=='SharedTaDirectionalBenchmarks' and 'checkpoint_format' not in record
   checkpoint_root=OUT/'directional-checkpoints'
  chunks=record['operation_checkpoints']
  assert [c['pair'] for c in chunks]==FIXTURE_PAIRS[fixture]
  chunk_reports=[];chunk_logs=[]
  for chunk in chunks:
   assert len(chunk['quiet_cpu_samples'])==12 and max(chunk['quiet_cpu_samples'])<=15
   assert chunk['quiet_build_free_samples']==12 and chunk['build_monitor_observations']>=1
   assert chunk['cases']==2*len(fixture_methods(fixture))
   report_path=Path(chunk['report']);log_path=Path(chunk['log'])
   assert report_path.is_relative_to(checkpoint_root) and log_path.is_relative_to(checkpoint_root)
   chunk_raw=report_path.read_bytes();chunk_log=log_path.read_bytes()
   assert hashlib.sha256(chunk_raw).hexdigest()==chunk['sha256']
   assert hashlib.sha256(chunk_log).hexdigest()==chunk['log_sha256']
   chunk_report=json.loads(chunk_raw)
   combine_reports([chunk_report],[chunk['pair']],fixture_methods(fixture))
   chunk_reports.append(chunk_report);chunk_logs.append(log_path.read_text(encoding='utf-8-sig'))
  assert combine_reports(chunk_reports,FIXTURE_PAIRS[fixture],fixture_methods(fixture))==json.loads(raw)
  assert (OUT/f'round{index}-{record["arm"]}-{fixture}.log').read_text(encoding='utf-8-sig')=='\n'.join(chunk_logs)
  assert record['build_monitor_observations']==sum(c['build_monitor_observations'] for c in chunks)
 cases={}
 for case in json.loads(raw)['Benchmarks']:
  name=case['FullName'];assert fixture+'.' in name
  key=canonical(re.search(r'(?:Operation|PairId): "([^"]+)"',name)[1]),int(re.search(r'(?:Count|Bars): (\d+)',name)[1]),case['Method']
  assert key not in cases
  stats=case['Statistics'];values=stats['OriginalValues'];ci=stats['ConfidenceInterval']
  assert len(values)==stats['N']>=7 and all(math.isfinite(v) and v>0 for v in values)
  assert math.isclose(sum(values)/len(values),stats['Mean'],rel_tol=1e-12)
  assert math.isfinite(ci['Lower']) and math.isfinite(ci['Upper']) and ci['Lower']<=stats['Mean']<=ci['Upper']
  cases[key]={'pair':key[0],'bars':key[1],'method':key[2],'mean_ns':stats['Mean'],'lower_ns':ci['Lower'],'upper_ns':ci['Upper'],'samples':stats['N'],'allocated_bytes':case['Memory']['BytesAllocatedPerOperation']}
 methods=fixture_methods(fixture)
 assert cases.keys()=={(canonical(p),n,m) for p in (FIXTURE_PAIRS[fixture]) for n in [1000,10000] for m in methods}
 assert len(cases)==record['cases']
 log=(OUT/f'round{index}-{record['arm']}-{fixture}.log').read_text(encoding='utf-8-sig')
 sections=re.split(r'^// Benchmark: ',log,flags=re.M)[1:]
 assert len(sections)==record['cases']
 for section in sections:
  header=section.splitlines()[0]
  assert 'IterationCount=10' in header and 'WarmupCount=10' in header
  assert len(re.findall(r'^WorkloadWarmup\s+\d+:',section,re.M))==10
  assert len(re.findall(r'^WorkloadActual\s+\d+:',section,re.M))==10
 rounds[fixture,index]=cases
decisions=[]
for fixture in FIXTURE_PAIRS:
 for key in sorted(rounds[fixture,0]):
  if key[2] not in ['BuilderFull','BuilderLatestOnly','Ooples']:continue
  old=[rounds[fixture,i][key] for i in [0,3]];new=[rounds[fixture,i][key] for i in [1,2]]
  verdict='faster' if max(r['upper_ns'] for r in new)<min(r['lower_ns'] for r in old) else 'slower' if min(r['lower_ns'] for r in new)>max(r['upper_ns'] for r in old) else 'inconclusive'
  record={'fixture':fixture,'pair':key[0],'bars':key[1],'method':key[2],'old_means_ms':[r['mean_ns']/1e6 for r in old],'new_means_ms':[r['mean_ns']/1e6 for r in new],'verdict':verdict}
  decisions.append(record);print(json.dumps(record))
summary={'all_1632_cases_verified':True,'measurement_location':'Local Windows','sources':{'old':proof['old_source'],'new':proof['new_source']},'decisions':decisions,'final_candidate_round':2,'final_candidate_rows':{fixture:list(rounds[fixture,2].values()) for fixture in FIXTURE_PAIRS}}
(OUT/'verified-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
