```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **777.98 μs** |  **43.670 μs** |  **22.840 μs** | **54.81** |    **2.05** |       **-** |       **-** |  **65.66 KB** |        **8.67** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   759.03 μs |  39.542 μs |  23.531 μs | 53.48 |    2.07 |       - |       - |   18.1 KB |        2.39 |
| NativeSingle      | TaLib.Functions.Adx | 1000  |    14.20 μs |   0.655 μs |   0.390 μs |  1.00 |    0.04 |  0.8545 |       - |   7.57 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 1000  |    20.12 μs |   0.365 μs |   0.241 μs |  1.42 |    0.04 |  7.0801 |  0.2441 |  41.96 KB |        5.54 |
|                   |                     |       |             |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **7,783.40 μs** | **402.108 μs** | **239.288 μs** | **55.09** |    **1.82** | **76.9231** |       **-** | **638.01 KB** |        **8.19** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 7,557.80 μs | 132.339 μs |  69.216 μs | 53.49 |    0.95 |       - |       - | 168.17 KB |        2.16 |
| NativeSingle      | TaLib.Functions.Adx | 10000 |   141.33 μs |   3.879 μs |   2.309 μs |  1.00 |    0.02 |  8.7891 |  0.9766 |  77.89 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 10000 |   174.09 μs |   3.030 μs |   1.585 μs |  1.23 |    0.02 | 60.5469 | 25.3906 | 428.69 KB |        5.50 |
