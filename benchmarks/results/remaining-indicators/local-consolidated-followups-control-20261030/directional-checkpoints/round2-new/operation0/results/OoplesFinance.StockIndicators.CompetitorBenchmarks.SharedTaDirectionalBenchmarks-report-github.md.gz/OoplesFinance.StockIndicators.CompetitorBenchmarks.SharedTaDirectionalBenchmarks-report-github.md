```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **242.414 μs** |  **25.6317 μs** | **15.2530 μs** | **26.99** |    **1.66** |  **7.8125** |       **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   236.818 μs |  14.9986 μs |  9.9206 μs | 26.37 |    1.12 |  1.9531 |       - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib(...)lusDM [22] | 1000  |     8.984 μs |   0.2072 μs |  0.1371 μs |  1.00 |    0.02 |  0.9155 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 1000  |    15.455 μs |   0.3145 μs |  0.2080 μs |  1.72 |    0.03 |  6.9580 |  0.2441 |  42.76 KB |        5.54 |
|                   |                      |       |              |             |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **2,329.315 μs** | **145.8035 μs** | **86.7653 μs** | **25.60** |    **0.96** | **62.5000** | **15.6250** | **627.99 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 2,234.159 μs |  50.0669 μs | 26.1860 μs | 24.55 |    0.40 | 15.6250 |       - | 158.15 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDM [22] | 10000 |    91.015 μs |   1.7435 μs |  1.1532 μs |  1.00 |    0.02 |  9.2773 |  1.4648 |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 10000 |   123.407 μs |   1.1280 μs |  0.7461 μs |  1.36 |    0.02 | 59.5703 | 21.4844 | 429.48 KB |        5.50 |
