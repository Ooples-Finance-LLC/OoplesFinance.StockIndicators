```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **369.517 μs** |  **10.4833 μs** |   **5.4829 μs** | **51.00** |    **1.65** |       **-** |       **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   371.279 μs |  26.9042 μs |  17.7955 μs | 51.24 |    2.78 |       - |       - |  17.42 KB |        2.26 |
| NativeSingle      | TaLib(...)nusDI [23] | 1000  |     7.252 μs |   0.3840 μs |   0.2285 μs |  1.00 |    0.04 |  0.9155 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 1000  |    13.781 μs |   0.7167 μs |   0.4740 μs |  1.90 |    0.08 |  6.9580 |  0.2441 |  42.79 KB |        5.54 |
|                   |                      |       |              |             |             |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **3,764.376 μs** | **182.0971 μs** | **120.4459 μs** | **51.11** |    **2.96** | **62.5000** | **31.2500** | **628.12 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 3,761.936 μs | 229.2278 μs | 136.4098 μs | 51.08 |    3.07 |       - |       - | 158.28 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDI [23] | 10000 |    73.828 μs |   5.7272 μs |   3.7882 μs |  1.00 |    0.07 |  9.2773 |  1.4648 |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 10000 |   105.807 μs |   2.9282 μs |   1.5315 μs |  1.44 |    0.07 | 60.5469 | 24.4141 | 429.52 KB |        5.50 |
