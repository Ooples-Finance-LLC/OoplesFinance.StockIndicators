```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **220.952 μs** |   **5.7951 μs** |   **3.0309 μs** | **23.39** |    **0.40** |  **7.8125** |       **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   219.031 μs |  12.5730 μs |   7.4820 μs | 23.19 |    0.80 |  1.9531 |       - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDM [23] | 1000  |     9.447 μs |   0.1704 μs |   0.1127 μs |  1.00 |    0.02 |  0.9155 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 1000  |    15.605 μs |   0.3422 μs |   0.2263 μs |  1.65 |    0.03 |  6.9580 |  0.2441 |  42.76 KB |        5.54 |
|                   |                      |       |              |             |             |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **2,268.353 μs** | **186.2737 μs** | **123.2085 μs** | **24.26** |    **1.27** | **62.5000** | **15.6250** |    **628 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 2,128.061 μs |  40.4444 μs |  24.0678 μs | 22.76 |    0.30 | 15.6250 |       - | 158.16 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDM [23] | 10000 |    93.518 μs |   1.1344 μs |   0.7503 μs |  1.00 |    0.01 |  9.2773 |  1.4648 |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 10000 |   136.172 μs |  11.8012 μs |   7.8058 μs |  1.46 |    0.08 | 60.5469 | 24.4141 | 429.48 KB |        5.50 |
