```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **850.27 μs** | **105.570 μs** |  **69.828 μs** | **51.74** |    **4.42** |   **7.8125** |       **-** |  **66.72 KB** |        **4.45** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   767.42 μs |  14.417 μs |   7.540 μs | 46.70 |    1.65 |        - |       - |  19.14 KB |        1.28 |
| NativeSingle      | TaLib.Functions.Adxr | 1000  |    16.45 μs |   1.015 μs |   0.604 μs |  1.00 |    0.05 |   1.8311 |       - |  14.99 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 1000  |    24.96 μs |   0.213 μs |   0.127 μs |  1.52 |    0.05 |  12.2070 |  0.7324 |  75.93 KB |        5.06 |
|                   |                      |       |             |            |            |       |         |          |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **7,985.08 μs** | **368.528 μs** | **192.747 μs** | **48.67** |    **1.43** |  **76.9231** |       **-** | **639.11 KB** |        **4.11** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 7,905.45 μs | 255.290 μs | 151.919 μs | 48.18 |    1.25 |        - |       - | 169.27 KB |        1.09 |
| NativeSingle      | TaLib.Functions.Adxr | 10000 |   164.13 μs |   5.405 μs |   3.217 μs |  1.00 |    0.03 |  18.5547 |  0.9766 | 155.63 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 10000 |   220.94 μs |   4.126 μs |   2.158 μs |  1.35 |    0.03 | 109.3750 | 70.3125 | 779.07 KB |        5.01 |
