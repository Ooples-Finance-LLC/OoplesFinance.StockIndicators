```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error        | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |------------:|-------------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **788.67 μs** |    **19.632 μs** |  **10.268 μs** | **54.12** |    **0.88** |  **7.8125** |       **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   775.41 μs |    20.452 μs |  10.697 μs | 53.21 |    0.90 |       - |       - |  17.42 KB |        2.26 |
| NativeSingle      | TaLib.Functions.Dx | 1000  |    14.57 μs |     0.281 μs |   0.167 μs |  1.00 |    0.02 |  0.8545 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 1000  |    20.57 μs |     0.234 μs |   0.155 μs |  1.41 |    0.02 |  6.9580 |  0.2441 |  42.79 KB |        5.54 |
|                   |                    |       |             |              |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **7,826.85 μs** |   **134.216 μs** |  **70.198 μs** | **51.38** |    **1.74** |       **-** |       **-** |  **628.7 KB** |        **8.06** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 9,043.89 μs | 1,135.985 μs | 751.384 μs | 59.37 |    5.09 |       - |       - | 158.66 KB |        2.03 |
| NativeSingle      | TaLib.Functions.Dx | 10000 |   152.48 μs |     7.967 μs |   5.270 μs |  1.00 |    0.05 |  8.7891 |  0.9766 |  78.04 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 10000 |   178.51 μs |     2.972 μs |   1.769 μs |  1.17 |    0.04 | 60.5469 | 24.4141 | 429.51 KB |        5.50 |
