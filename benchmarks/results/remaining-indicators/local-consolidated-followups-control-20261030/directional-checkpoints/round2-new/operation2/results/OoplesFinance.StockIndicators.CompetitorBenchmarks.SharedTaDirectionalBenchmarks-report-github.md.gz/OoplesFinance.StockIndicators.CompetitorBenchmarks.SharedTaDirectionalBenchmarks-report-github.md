```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **473.999 μs** |  **81.1645 μs** |  **53.6853 μs** | **57.60** |    **8.24** |       **-** |       **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   485.152 μs |  38.4481 μs |  25.4310 μs | 58.95 |    6.25 |       - |       - |  17.42 KB |        2.26 |
| NativeSingle      | TaLib(...)lusDI [22] | 1000  |     8.298 μs |   1.1681 μs |   0.7726 μs |  1.01 |    0.13 |  0.9155 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 1000  |    13.281 μs |   0.1980 μs |   0.1310 μs |  1.61 |    0.15 |  6.9580 |  0.2441 |  42.79 KB |        5.54 |
|                   |                      |       |              |             |             |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **3,957.237 μs** | **187.6888 μs** | **111.6906 μs** | **56.69** |    **1.69** | **62.5000** | **31.2500** | **628.14 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 3,995.092 μs | 383.2495 μs | 253.4958 μs | 57.23 |    3.55 |       - |       - | 158.27 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDI [22] | 10000 |    69.814 μs |   1.8888 μs |   0.9879 μs |  1.00 |    0.02 |  9.2773 |  1.4648 |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 10000 |   102.699 μs |   2.4202 μs |   1.2658 μs |  1.47 |    0.03 | 60.5469 | 22.4609 | 429.52 KB |        5.50 |
