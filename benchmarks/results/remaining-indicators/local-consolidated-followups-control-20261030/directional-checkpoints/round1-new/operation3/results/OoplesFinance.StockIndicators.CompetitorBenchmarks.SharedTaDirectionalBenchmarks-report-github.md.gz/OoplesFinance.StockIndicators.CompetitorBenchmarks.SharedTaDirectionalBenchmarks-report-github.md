```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **375.344 μs** |  **11.5829 μs** |   **6.0581 μs** | **54.14** |    **0.94** |  **7.8125** |       **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   360.102 μs |   7.1360 μs |   3.7322 μs | 51.94 |    0.67 |       - |       - |  17.42 KB |        2.26 |
| NativeSingle      | TaLib(...)nusDI [23] | 1000  |     6.934 μs |   0.1016 μs |   0.0605 μs |  1.00 |    0.01 |  0.9155 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 1000  |    13.405 μs |   0.3558 μs |   0.2354 μs |  1.93 |    0.04 |  6.9580 |  0.2441 |  42.79 KB |        5.54 |
|                   |                      |       |              |             |             |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **4,234.544 μs** | **558.0836 μs** | **369.1378 μs** | **60.62** |    **5.12** | **62.5000** | **31.2500** | **628.13 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 3,669.011 μs | 126.5657 μs |  75.3172 μs | 52.52 |    1.27 |       - |       - | 158.28 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDI [23] | 10000 |    69.872 μs |   1.7913 μs |   1.0660 μs |  1.00 |    0.02 |  9.2773 |  1.4648 |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 10000 |   104.249 μs |   1.6701 μs |   0.9938 μs |  1.49 |    0.03 | 60.5469 | 23.4375 | 429.51 KB |        5.50 |
