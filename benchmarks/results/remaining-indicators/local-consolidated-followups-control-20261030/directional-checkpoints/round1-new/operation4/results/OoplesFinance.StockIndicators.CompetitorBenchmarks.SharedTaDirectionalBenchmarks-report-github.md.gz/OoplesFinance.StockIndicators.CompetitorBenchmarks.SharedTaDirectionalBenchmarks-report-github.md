```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |------------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **826.06 μs** |  **53.928 μs** |  **32.092 μs** | **52.77** |    **3.36** |  **7.8125** |       **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   807.87 μs |  69.839 μs |  46.194 μs | 51.61 |    3.88 |       - |       - |  17.45 KB |        2.26 |
| NativeSingle      | TaLib.Functions.Dx | 1000  |    15.69 μs |   1.274 μs |   0.842 μs |  1.00 |    0.07 |  0.8545 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 1000  |    20.79 μs |   0.605 μs |   0.316 μs |  1.33 |    0.07 |  6.9580 |  0.2441 |  42.79 KB |        5.54 |
|                   |                    |       |             |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **8,037.33 μs** | **302.697 μs** | **180.130 μs** | **54.74** |    **1.26** | **76.9231** |       **-** | **628.48 KB** |        **8.05** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 7,899.87 μs | 274.659 μs | 163.445 μs | 53.80 |    1.16 |       - |       - | 158.68 KB |        2.03 |
| NativeSingle      | TaLib.Functions.Dx | 10000 |   146.84 μs |   2.625 μs |   1.373 μs |  1.00 |    0.01 |  8.7891 |  0.9766 |  78.04 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 10000 |   194.43 μs |  20.002 μs |  13.230 μs |  1.32 |    0.09 | 60.5469 | 27.3438 | 429.52 KB |        5.50 |
