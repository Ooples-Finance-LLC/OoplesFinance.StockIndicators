```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **220.570 μs** |   **5.2161 μs** |   **2.7281 μs** | **24.68** |    **0.35** |  **7.8125** |       **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   204.745 μs |   6.7721 μs |   3.5419 μs | 22.91 |    0.42 |  1.9531 |       - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDM [23] | 1000  |     8.937 μs |   0.1435 μs |   0.0751 μs |  1.00 |    0.01 |  0.9155 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 1000  |    16.075 μs |   0.6271 μs |   0.3732 μs |  1.80 |    0.04 |  6.9580 |  0.2441 |  42.76 KB |        5.54 |
|                   |                      |       |              |             |             |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **2,179.868 μs** | **134.1270 μs** |  **88.7167 μs** | **21.61** |    **1.10** | **62.5000** | **15.6250** | **627.99 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 2,098.778 μs | 158.8416 μs | 105.0639 μs | 20.80 |    1.21 | 15.6250 |       - | 158.13 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDM [23] | 10000 |   100.990 μs |   5.7871 μs |   3.4438 μs |  1.00 |    0.05 |  9.2773 |  1.4648 |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 10000 |   145.647 μs |  21.1458 μs |  12.5836 μs |  1.44 |    0.13 | 60.5469 | 23.4375 | 429.48 KB |        5.50 |
