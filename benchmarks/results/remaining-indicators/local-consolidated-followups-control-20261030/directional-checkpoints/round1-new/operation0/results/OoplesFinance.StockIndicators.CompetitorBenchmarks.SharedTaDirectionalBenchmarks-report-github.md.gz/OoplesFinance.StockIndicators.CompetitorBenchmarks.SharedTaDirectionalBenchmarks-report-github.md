```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **233.623 μs** |   **2.1828 μs** |   **1.1417 μs** | **26.57** |    **0.56** |  **7.8125** |       **-** |  **64.96 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   222.969 μs |   3.0510 μs |   1.8156 μs | 25.36 |    0.55 |  1.9531 |       - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib(...)lusDM [22] | 1000  |     8.796 μs |   0.2873 μs |   0.1901 μs |  1.00 |    0.03 |  0.9155 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 1000  |    15.464 μs |   0.3337 μs |   0.1986 μs |  1.76 |    0.04 |  6.9580 |  0.2441 |  42.76 KB |        5.54 |
|                   |                      |       |              |             |             |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **2,425.825 μs** | **165.3207 μs** | **109.3494 μs** | **26.21** |    **1.31** | **62.5000** | **15.6250** | **627.96 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 2,226.298 μs |  87.3138 μs |  45.6668 μs | 24.06 |    0.76 | 15.6250 |       - | 158.16 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDM [22] | 10000 |    92.596 μs |   4.1354 μs |   2.4609 μs |  1.00 |    0.04 |  9.2773 |  1.4648 |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 10000 |   141.047 μs |  25.2237 μs |  16.6839 μs |  1.52 |    0.18 | 60.5469 | 25.3906 | 429.49 KB |        5.50 |
