```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error        | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|-------------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **744.33 μs** |    **60.677 μs** |  **36.108 μs** | **50.71** |    **2.81** |       **-** |       **-** |  **65.66 KB** |        **8.67** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   717.88 μs |    20.783 μs |  12.368 μs | 48.91 |    1.71 |       - |       - |   18.1 KB |        2.39 |
| NativeSingle      | TaLib.Functions.Adx | 1000  |    14.69 μs |     0.731 μs |   0.484 μs |  1.00 |    0.04 |  0.8545 |       - |   7.57 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 1000  |    20.77 μs |     0.602 μs |   0.358 μs |  1.42 |    0.05 |  6.9580 |  0.2441 |  41.96 KB |        5.54 |
|                   |                     |       |             |              |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **7,416.58 μs** |   **217.520 μs** | **129.443 μs** | **49.74** |    **2.37** | **71.4286** |       **-** | **638.02 KB** |        **8.19** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 7,873.12 μs | 1,244.600 μs | 740.641 μs | 52.81 |    5.27 |       - |       - | 168.16 KB |        2.16 |
| NativeSingle      | TaLib.Functions.Adx | 10000 |   149.40 μs |    11.108 μs |   7.347 μs |  1.00 |    0.06 |  8.7891 |  0.9766 |  77.89 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 10000 |   175.54 μs |     5.252 μs |   3.125 μs |  1.18 |    0.06 | 58.5938 | 25.3906 |  428.7 KB |        5.50 |
