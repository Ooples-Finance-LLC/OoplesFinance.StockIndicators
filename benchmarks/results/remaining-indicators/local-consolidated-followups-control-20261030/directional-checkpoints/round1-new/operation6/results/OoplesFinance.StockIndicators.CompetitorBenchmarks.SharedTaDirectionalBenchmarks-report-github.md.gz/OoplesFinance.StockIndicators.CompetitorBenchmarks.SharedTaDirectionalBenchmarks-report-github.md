```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error        | StdDev     | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-------------:|-----------:|------:|--------:|---------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **787.28 μs** |    **65.333 μs** |  **34.171 μs** | **49.01** |    **2.13** |        **-** |       **-** |  **66.73 KB** |        **4.45** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   770.89 μs |    16.781 μs |   9.986 μs | 47.99 |    0.93 |        - |       - |  19.17 KB |        1.28 |
| NativeSingle      | TaLib.Functions.Adxr | 1000  |    16.07 μs |     0.430 μs |   0.256 μs |  1.00 |    0.02 |   1.8311 |       - |  14.99 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 1000  |    25.70 μs |     0.916 μs |   0.545 μs |  1.60 |    0.04 |  12.2070 |  0.7324 |  75.93 KB |        5.06 |
|                   |                      |       |             |              |            |       |         |          |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **7,915.65 μs** |   **274.405 μs** | **163.294 μs** | **49.30** |    **1.12** |  **76.9231** |       **-** | **639.11 KB** |        **4.11** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 8,728.91 μs | 1,070.788 μs | 708.260 μs | 54.37 |    4.26 |        - |       - | 169.33 KB |        1.09 |
| NativeSingle      | TaLib.Functions.Adxr | 10000 |   160.58 μs |     3.741 μs |   1.957 μs |  1.00 |    0.02 |  18.5547 |  0.9766 | 155.63 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 10000 |   221.45 μs |     7.019 μs |   3.671 μs |  1.38 |    0.03 | 109.3750 | 64.4531 | 779.07 KB |        5.01 |
