```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **479.965 μs** | **101.2384 μs** | **66.9629 μs** | **59.30** |    **9.01** |       **-** |       **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   494.163 μs |  39.6547 μs | 26.2291 μs | 61.05 |    5.41 |       - |       - |  17.42 KB |        2.26 |
| NativeSingle      | TaLib(...)lusDI [22] | 1000  |     8.134 μs |   0.8892 μs |  0.5881 μs |  1.00 |    0.10 |  0.9155 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 1000  |    13.640 μs |   0.2221 μs |  0.1322 μs |  1.69 |    0.12 |  6.9580 |  0.2441 |  42.79 KB |        5.54 |
|                   |                      |       |              |             |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **3,914.634 μs** |  **94.3470 μs** | **56.1444 μs** | **54.93** |    **1.02** | **62.5000** | **31.2500** | **628.13 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 3,847.557 μs | 132.2409 μs | 87.4692 μs | 53.99 |    1.35 |       - |       - | 158.28 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDI [22] | 10000 |    71.281 μs |   1.4167 μs |  0.9371 μs |  1.00 |    0.02 |  9.2773 |  1.4648 |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 10000 |   114.048 μs |  11.4220 μs |  7.5550 μs |  1.60 |    0.10 | 59.5703 | 21.4844 | 429.51 KB |        5.50 |
