```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **318.541 μs** |  **30.5332 μs** |  **20.1958 μs** | **33.46** |    **2.37** |  **7.8125** |       **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   246.577 μs |  17.2646 μs |  10.2739 μs | 25.90 |    1.40 |  1.9531 |       - |  17.39 KB |        2.25 |
| NativeSingle      | TaLib(...)lusDM [22] | 1000  |     9.534 μs |   0.5770 μs |   0.3817 μs |  1.00 |    0.05 |  0.9155 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 1000  |    16.034 μs |   0.4434 μs |   0.2639 μs |  1.68 |    0.07 |  6.9580 |  0.2441 |  42.76 KB |        5.54 |
|                   |                      |       |              |             |             |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **3,295.775 μs** | **371.9351 μs** | **246.0121 μs** | **33.98** |    **2.50** | **62.5000** | **15.6250** |    **628 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 2,700.813 μs | 317.6511 μs | 210.1065 μs | 27.84 |    2.13 | 15.6250 |       - | 158.16 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDM [22] | 10000 |    97.038 μs |   2.8685 μs |   1.8974 μs |  1.00 |    0.03 |  9.2773 |  1.4648 |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 10000 |   132.651 μs |  12.4869 μs |   7.4308 μs |  1.37 |    0.08 | 59.5703 | 26.3672 | 429.48 KB |        5.50 |
