```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **266.378 μs** |  **42.1607 μs** |  **27.8867 μs** | **29.03** |    **2.91** |  **7.8125** |       **-** |  **64.97 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   253.280 μs |  15.1421 μs |  10.0156 μs | 27.60 |    1.06 |  1.9531 |       - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDM [23] | 1000  |     9.176 μs |   0.1277 μs |   0.0668 μs |  1.00 |    0.01 |  0.9155 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 1000  |    15.669 μs |   0.2283 μs |   0.1358 μs |  1.71 |    0.02 |  6.9580 |  0.2441 |  42.76 KB |        5.54 |
|                   |                      |       |              |             |             |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **2,532.830 μs** | **177.5431 μs** | **117.4338 μs** | **27.30** |    **1.26** | **62.5000** | **15.6250** | **627.97 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 2,465.090 μs | 158.4231 μs | 104.7870 μs | 26.57 |    1.13 | 15.6250 |       - | 158.16 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDM [23] | 10000 |    92.808 μs |   2.1575 μs |   1.2839 μs |  1.00 |    0.02 |  9.2773 |  1.4648 |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 10000 |   134.299 μs |  13.1594 μs |   8.7041 μs |  1.45 |    0.09 | 60.5469 | 23.4375 | 429.48 KB |        5.50 |
