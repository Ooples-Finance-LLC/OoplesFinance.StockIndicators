```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **426.793 μs** |  **53.8565 μs** |  **32.0491 μs** | **57.48** |    **4.46** |       **-** |       **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   414.554 μs |  28.1530 μs |  16.7534 μs | 55.84 |    2.74 |       - |       - |  17.42 KB |        2.26 |
| NativeSingle      | TaLib(...)nusDI [23] | 1000  |     7.432 μs |   0.4152 μs |   0.2471 μs |  1.00 |    0.04 |  0.9155 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 1000  |    14.254 μs |   0.5335 μs |   0.3175 μs |  1.92 |    0.07 |  6.9580 |  0.2441 |  42.79 KB |        5.54 |
|                   |                      |       |              |             |             |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **4,222.020 μs** | **281.9034 μs** | **186.4617 μs** | **53.65** |    **2.75** | **62.5000** | **31.2500** | **628.13 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 5,373.806 μs | 619.4748 μs | 409.7442 μs | 68.29 |    5.35 |       - |       - | 158.27 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDI [23] | 10000 |    78.757 μs |   3.7109 μs |   2.4546 μs |  1.00 |    0.04 |  9.2773 |  1.4648 |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 10000 |   110.528 μs |   2.9594 μs |   1.9574 μs |  1.40 |    0.05 | 60.5469 | 23.4375 | 429.52 KB |        5.50 |
