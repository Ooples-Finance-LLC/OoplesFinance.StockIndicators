```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error        | StdDev       | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|-------------:|-------------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **899.83 μs** |   **189.489 μs** |   **125.335 μs** | **62.99** |    **8.55** |       **-** |       **-** |  **65.66 KB** |        **8.67** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   832.71 μs |   112.679 μs |    74.530 μs | 58.30 |    5.23 |       - |       - |  18.07 KB |        2.39 |
| NativeSingle      | TaLib.Functions.Adx | 1000  |    14.30 μs |     0.724 μs |     0.431 μs |  1.00 |    0.04 |  0.8545 |       - |   7.57 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 1000  |    20.43 μs |     0.188 μs |     0.098 μs |  1.43 |    0.04 |  6.9580 |  0.2441 |  41.96 KB |        5.54 |
|                   |                     |       |             |              |              |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **8,465.13 μs** | **1,861.508 μs** | **1,231.272 μs** | **48.95** |    **9.42** |       **-** |       **-** | **638.09 KB** |        **8.19** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 8,381.41 μs |   689.736 μs |   456.218 μs | 48.46 |    6.88 |       - |       - | 168.22 KB |        2.16 |
| NativeSingle      | TaLib.Functions.Adx | 10000 |   175.79 μs |    34.675 μs |    22.935 μs |  1.02 |    0.19 |  8.7891 |  0.9766 |  77.89 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 10000 |   186.34 μs |    10.677 μs |     6.354 μs |  1.08 |    0.15 | 58.5938 | 23.4375 |  428.7 KB |        5.50 |
