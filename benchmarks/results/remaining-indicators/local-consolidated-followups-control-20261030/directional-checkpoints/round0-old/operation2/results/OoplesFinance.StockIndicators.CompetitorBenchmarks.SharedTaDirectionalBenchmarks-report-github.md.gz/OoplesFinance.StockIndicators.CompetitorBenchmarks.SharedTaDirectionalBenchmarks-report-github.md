```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **533.832 μs** |  **50.2678 μs** |  **33.2490 μs** | **68.87** |    **6.02** |       **-** |       **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   497.862 μs |  41.2182 μs |  24.5283 μs | 64.23 |    5.10 |       - |       - |  17.42 KB |        2.26 |
| NativeSingle      | TaLib(...)lusDI [22] | 1000  |     7.783 μs |   0.7906 μs |   0.5229 μs |  1.00 |    0.09 |  0.9155 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 1000  |    13.973 μs |   0.2551 μs |   0.1518 μs |  1.80 |    0.12 |  6.9580 |  0.2441 |  42.79 KB |        5.54 |
|                   |                      |       |              |             |             |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **4,534.572 μs** | **429.8579 μs** | **284.3244 μs** | **61.38** |    **4.08** | **62.5000** | **31.2500** | **628.13 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 4,194.666 μs | 170.7949 μs | 101.6373 μs | 56.78 |    2.10 |       - |       - | 158.28 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDI [22] | 10000 |    73.938 μs |   3.8010 μs |   2.2619 μs |  1.00 |    0.04 |  9.2773 |  1.4648 |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 10000 |   109.911 μs |   5.2303 μs |   2.7356 μs |  1.49 |    0.06 | 60.5469 | 23.4375 | 429.52 KB |        5.50 |
