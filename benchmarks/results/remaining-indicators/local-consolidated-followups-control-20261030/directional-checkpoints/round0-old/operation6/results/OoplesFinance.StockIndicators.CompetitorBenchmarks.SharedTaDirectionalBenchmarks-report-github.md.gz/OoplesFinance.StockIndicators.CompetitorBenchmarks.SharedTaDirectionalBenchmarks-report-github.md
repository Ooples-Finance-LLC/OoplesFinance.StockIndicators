```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error        | StdDev       | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-------------:|-------------:|------:|--------:|---------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **918.39 μs** |   **154.999 μs** |   **102.522 μs** | **57.40** |    **6.15** |        **-** |       **-** |  **66.73 KB** |        **4.45** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   786.02 μs |    43.600 μs |    25.946 μs | 49.13 |    1.64 |        - |       - |  19.17 KB |        1.28 |
| NativeSingle      | TaLib.Functions.Adxr | 1000  |    16.00 μs |     0.328 μs |     0.195 μs |  1.00 |    0.02 |   1.8311 |       - |  14.99 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 1000  |    27.63 μs |     2.251 μs |     1.489 μs |  1.73 |    0.09 |  11.9629 |  0.7324 |  75.93 KB |        5.06 |
|                   |                      |       |             |              |              |       |         |          |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **8,129.57 μs** |   **610.784 μs** |   **363.468 μs** | **40.36** |    **5.90** |        **-** |       **-** | **639.23 KB** |        **4.11** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 8,886.55 μs | 1,516.780 μs | 1,003.256 μs | 44.12 |    7.81 |        - |       - | 169.42 KB |        1.09 |
| NativeSingle      | TaLib.Functions.Adxr | 10000 |   205.15 μs |    42.914 μs |    28.385 μs |  1.02 |    0.20 |  18.5547 |  0.9766 | 155.63 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 10000 |   226.33 μs |     5.599 μs |     3.703 μs |  1.12 |    0.16 | 109.3750 | 66.4063 | 779.07 KB |        5.01 |
