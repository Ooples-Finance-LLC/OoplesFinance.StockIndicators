```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |------------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **882.26 μs** |  **87.495 μs** |  **57.873 μs** | **57.27** |    **4.22** |  **7.8125** |       **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   862.77 μs |  75.832 μs |  45.127 μs | 56.00 |    3.53 |       - |       - |  17.45 KB |        2.26 |
| NativeSingle      | TaLib.Functions.Dx | 1000  |    15.43 μs |   0.943 μs |   0.624 μs |  1.00 |    0.05 |  0.8545 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 1000  |    22.26 μs |   1.671 μs |   1.105 μs |  1.44 |    0.09 |  7.0801 |  0.2441 |  42.79 KB |        5.54 |
|                   |                    |       |             |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **8,483.15 μs** | **512.542 μs** | **268.069 μs** | **54.22** |    **2.68** |       **-** |       **-** | **628.59 KB** |        **8.05** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 8,912.76 μs | 751.589 μs | 447.259 μs | 56.97 |    3.52 |       - |       - | 158.72 KB |        2.03 |
| NativeSingle      | TaLib.Functions.Dx | 10000 |   156.70 μs |  10.053 μs |   6.650 μs |  1.00 |    0.06 |  8.7891 |  0.9766 |  78.04 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 10000 |   192.81 μs |  19.484 μs |  12.888 μs |  1.23 |    0.09 | 60.5469 | 26.3672 | 429.52 KB |        5.50 |
