```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **777.29 μs** |  **14.538 μs** |   **9.616 μs** | **39.96** |    **4.12** |        **-** |       **-** |  **66.73 KB** |        **4.45** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   773.32 μs |  18.012 μs |   9.420 μs | 39.76 |    4.11 |        - |       - |  19.14 KB |        1.28 |
| NativeSingle      | TaLib.Functions.Adxr | 1000  |    19.64 μs |   2.883 μs |   1.907 μs |  1.01 |    0.14 |   1.8311 |       - |  14.99 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 1000  |    24.78 μs |   0.278 μs |   0.184 μs |  1.27 |    0.13 |  11.9629 |  0.7324 |  75.93 KB |        5.06 |
|                   |                      |       |             |            |            |       |         |          |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **7,852.42 μs** | **137.104 μs** |  **71.708 μs** | **48.78** |    **1.25** |  **76.9231** |       **-** | **639.11 KB** |        **4.11** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 7,840.92 μs | 381.774 μs | 227.187 μs | 48.71 |    1.78 |        - |       - | 169.29 KB |        1.09 |
| NativeSingle      | TaLib.Functions.Adxr | 10000 |   161.07 μs |   7.136 μs |   4.247 μs |  1.00 |    0.03 |  17.5781 |  1.9531 | 155.63 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 10000 |   219.66 μs |   4.595 μs |   2.734 μs |  1.36 |    0.04 | 109.3750 | 64.4531 | 779.07 KB |        5.01 |
