```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **753.48 μs** |  **23.796 μs** |  **12.446 μs** | **52.79** |    **2.83** |       **-** |       **-** |  **65.66 KB** |        **8.67** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   740.64 μs |  11.120 μs |   6.617 μs | 51.89 |    2.70 |       - |       - |   18.1 KB |        2.39 |
| NativeSingle      | TaLib.Functions.Adx | 1000  |    14.32 μs |   1.421 μs |   0.845 μs |  1.00 |    0.08 |  0.8545 |       - |   7.57 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 1000  |    20.11 μs |   0.281 μs |   0.186 μs |  1.41 |    0.07 |  6.9580 |  0.2441 |  41.96 KB |        5.54 |
|                   |                     |       |             |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **7,646.92 μs** | **228.543 μs** | **119.533 μs** | **53.33** |    **1.88** | **71.4286** |       **-** | **638.01 KB** |        **8.19** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 7,540.94 μs | 117.699 μs |  70.041 μs | 52.59 |    1.75 |       - |       - | 168.17 KB |        2.16 |
| NativeSingle      | TaLib.Functions.Adx | 10000 |   143.53 μs |   7.379 μs |   4.881 μs |  1.00 |    0.05 |  8.7891 |  0.9766 |  77.89 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 10000 |   175.85 μs |   6.840 μs |   4.524 μs |  1.23 |    0.05 | 60.5469 | 25.3906 | 428.69 KB |        5.50 |
