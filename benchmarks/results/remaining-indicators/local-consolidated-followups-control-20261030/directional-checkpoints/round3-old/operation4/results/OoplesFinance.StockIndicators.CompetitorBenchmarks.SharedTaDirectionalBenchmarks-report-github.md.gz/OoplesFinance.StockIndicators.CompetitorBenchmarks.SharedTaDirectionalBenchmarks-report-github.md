```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |------------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **816.28 μs** |  **46.051 μs** |  **27.404 μs** | **56.22** |    **2.14** |       **-** |       **-** |  **65.01 KB** |        **8.42** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   805.81 μs |  28.431 μs |  14.870 μs | 55.50 |    1.50 |       - |       - |  17.45 KB |        2.26 |
| NativeSingle      | TaLib.Functions.Dx | 1000  |    14.53 μs |   0.537 μs |   0.320 μs |  1.00 |    0.03 |  0.8545 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 1000  |    20.45 μs |   0.191 μs |   0.126 μs |  1.41 |    0.03 |  7.0801 |  0.2441 |  42.79 KB |        5.54 |
|                   |                    |       |             |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **8,270.01 μs** | **314.430 μs** | **164.453 μs** | **57.01** |    **1.36** | **76.9231** |       **-** | **628.48 KB** |        **8.05** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 8,160.31 μs | 228.602 μs | 136.038 μs | 56.25 |    1.21 |       - |       - | 158.68 KB |        2.03 |
| NativeSingle      | TaLib.Functions.Dx | 10000 |   145.10 μs |   4.343 μs |   2.272 μs |  1.00 |    0.02 |  8.7891 |  0.9766 |  78.04 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 10000 |   177.09 μs |   2.923 μs |   1.739 μs |  1.22 |    0.02 | 60.5469 | 24.4141 | 429.52 KB |        5.50 |
