```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **242.701 μs** | **12.5680 μs** |  **8.3129 μs** | **26.96** |    **1.00** |  **7.8125** |       **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   229.848 μs | 10.9838 μs |  6.5363 μs | 25.53 |    0.82 |  1.9531 |       - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib(...)lusDM [22] | 1000  |     9.006 μs |  0.2536 μs |  0.1677 μs |  1.00 |    0.02 |  0.9155 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 1000  |    15.348 μs |  0.0988 μs |  0.0588 μs |  1.70 |    0.03 |  6.9580 |  0.2441 |  42.76 KB |        5.54 |
|                   |                      |       |              |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **2,270.552 μs** | **58.0970 μs** | **30.3859 μs** | **25.28** |    **0.68** | **62.5000** | **15.6250** |    **628 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 2,181.585 μs | 42.2394 μs | 25.1360 μs | 24.29 |    0.63 | 15.6250 |       - | 158.16 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDM [22] | 10000 |    89.877 μs |  3.4244 μs |  2.2650 μs |  1.00 |    0.03 |  9.2773 |  1.4648 |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 10000 |   130.095 μs | 13.9468 μs |  8.2995 μs |  1.45 |    0.09 | 60.5469 | 22.4609 | 429.48 KB |        5.50 |
