```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **247.976 μs** |  **8.7686 μs** |  **5.2180 μs** | **28.08** |    **0.63** |  **7.8125** |       **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   227.385 μs |  4.3928 μs |  2.6141 μs | 25.75 |    0.39 |  1.9531 |       - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDM [23] | 1000  |     8.832 μs |  0.1677 μs |  0.0998 μs |  1.00 |    0.02 |  0.9155 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 1000  |    15.245 μs |  0.1676 μs |  0.1109 μs |  1.73 |    0.02 |  6.9580 |  0.2441 |  42.76 KB |        5.54 |
|                   |                      |       |              |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **2,288.562 μs** | **97.8980 μs** | **58.2575 μs** | **26.12** |    **0.64** | **62.5000** | **15.6250** | **627.99 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 2,155.138 μs | 49.5935 μs | 29.5123 μs | 24.60 |    0.34 | 15.6250 |       - | 158.15 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDM [23] | 10000 |    87.607 μs |  0.7480 μs |  0.3912 μs |  1.00 |    0.01 |  9.2773 |  1.4648 |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 10000 |   124.376 μs |  3.8968 μs |  2.3189 μs |  1.42 |    0.03 | 60.5469 | 24.4141 | 429.48 KB |        5.50 |
