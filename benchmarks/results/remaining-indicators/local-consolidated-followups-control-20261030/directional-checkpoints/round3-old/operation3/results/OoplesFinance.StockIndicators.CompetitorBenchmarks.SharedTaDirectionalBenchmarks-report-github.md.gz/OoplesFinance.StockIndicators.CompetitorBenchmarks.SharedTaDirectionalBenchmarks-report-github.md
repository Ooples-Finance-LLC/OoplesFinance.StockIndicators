```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **418.419 μs** |  **19.3007 μs** |  **12.7662 μs** | **59.92** |    **2.06** |       **-** |       **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   480.747 μs |  56.0006 μs |  37.0409 μs | 68.85 |    5.22 |       - |       - |  17.42 KB |        2.26 |
| NativeSingle      | TaLib(...)nusDI [23] | 1000  |     6.985 μs |   0.2307 μs |   0.1373 μs |  1.00 |    0.03 |  0.9155 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 1000  |    13.205 μs |   0.1039 μs |   0.0687 μs |  1.89 |    0.04 |  6.9580 |  0.2441 |  42.79 KB |        5.54 |
|                   |                      |       |              |             |             |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **4,224.410 μs** | **347.5339 μs** | **229.8722 μs** | **62.03** |    **3.31** | **62.5000** | **31.2500** | **628.13 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 4,077.136 μs | 160.2659 μs |  95.3717 μs | 59.87 |    1.52 |       - |       - | 158.28 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDI [23] | 10000 |    68.109 μs |   1.5195 μs |   0.9042 μs |  1.00 |    0.02 |  9.2773 |  1.4648 |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 10000 |   106.487 μs |  13.4741 μs |   8.0182 μs |  1.56 |    0.11 | 60.5469 | 24.4141 | 429.52 KB |        5.50 |
