```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **413.419 μs** |  **24.2718 μs** | **16.0543 μs** | **60.06** |    **2.41** |       **-** |       **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   406.387 μs |  11.1494 μs |  5.8314 μs | 59.03 |    1.21 |       - |       - |  17.42 KB |        2.26 |
| NativeSingle      | TaLib(...)lusDI [22] | 1000  |     6.886 μs |   0.1920 μs |  0.1143 μs |  1.00 |    0.02 |  0.9155 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 1000  |    13.123 μs |   0.2119 μs |  0.1401 μs |  1.91 |    0.04 |  6.9580 |  0.2441 |  42.79 KB |        5.54 |
|                   |                      |       |              |             |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **4,101.241 μs** |  **92.2311 μs** | **48.2386 μs** | **60.00** |    **1.16** | **62.5000** |       **-** | **628.13 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 4,081.938 μs | 127.0004 μs | 66.4237 μs | 59.72 |    1.31 |       - |       - | 158.28 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDI [22] | 10000 |    68.370 μs |   2.2110 μs |  1.1564 μs |  1.00 |    0.02 |  9.2773 |  1.4648 |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 10000 |   103.021 μs |   3.3455 μs |  1.7497 μs |  1.51 |    0.03 | 60.5469 | 23.4375 | 429.52 KB |        5.50 |
