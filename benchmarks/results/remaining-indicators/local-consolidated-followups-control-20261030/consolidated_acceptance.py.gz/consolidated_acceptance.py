from pathlib import Path
import json
ROOT=Path("C:/Users/cheat/StockIndicators-Recovery-20261021")
PLAN=json.loads((ROOT/"batched-optimization-20261030/performance-plan.json").read_text())
FIXTURE_PAIRS=PLAN["fixture_pairs"]
def methods(fixture):
 return ["Ooples","Competitor"] if fixture=="LibraryPairBenchmarks" else ["BuilderFull","BuilderLatestOnly","NativeSingle","NativeParallel"]
MATRIX=[(f,methods(f),"Bars" if f=="LibraryPairBenchmarks" else "Count",len(p)*2*len(methods(f))) for f,p in FIXTURE_PAIRS.items()]
TOTAL_CASES=4*sum(row[3] for row in MATRIX)
assert TOTAL_CASES==PLAN["cases"]==1632
def qualification_valid(q):
 assert q['status']=='checks-passed-review-and-publication-pending'
 assert q['input_head']==PLAN['candidate_source'] and q['gpu_passed']==100
 assert all(v=='passed' for v in q['checks'].values())
 expected=json.loads((ROOT/'batched-optimization-20261030/fixed-kernel-word-followup-qualification-plan.json').read_text())
 for label in ('unit','parity'):
  counts=q[label]['class_counts'];classes=expected[label+'_classes']
  assert counts.keys()==classes.keys()
  assert all(counts[k]>0 and (v is None or counts[k]==v) for k,v in classes.items())
  assert q[label]['passed']==sum(counts.values())
 for phase,unit,parity in [('candidate',794,381),('stage2',54,72),('scalar',354,301),('tillson',226,145),('word-ema',514,327),('tillson-input',147,26),('classical-input',121,198)]:
  prior=json.loads((ROOT/'batched-optimization-20261030'/phase/'status.json').read_text())
  assert prior['status']=='checks-passed-review-and-publication-pending'
  assert prior['unit']['passed']==unit and prior['parity']['passed']==parity and prior['gpu_passed']==100
  assert all(v=='passed' for v in prior['checks'].values())

 prior=json.loads((ROOT/'batched-optimization-20261030/tillson-certified/status.json').read_text())
 assert prior['status']=='checks-passed-review-and-publication-pending' and prior['gpu_passed']==100
 assert all(v=='passed' for v in prior['checks'].values())

 for phase,unit,parity in [('combined-followup',653,389),('compact-count-recurrence',542,327)]:
  prior=json.loads((ROOT/'batched-optimization-20261030'/phase/'status.json').read_text())
  assert prior['status']=='checks-passed-review-and-publication-pending' and prior['gpu_passed']==100
  assert (prior['unit']['passed'],prior['parity']['passed'])==(unit,parity)
  assert all(v=='passed' for v in prior['checks'].values())

def qualifies(decisions):
 rows=list(decisions)
 pairs=set(FIXTURE_PAIRS['LibraryPairBenchmarks'])
 expected={(p,n,'Ooples') for p in pairs for n in (1000,10000)}
 expected|={(p,n,m) for p in pairs-set(PLAN['snapshot_only_pairs']) for n in (1000,10000) for m in ('BuilderFull','BuilderLatestOnly')}
 assert len(rows)==len(expected)==204
 assert {(r['pair'],r['bars'],r['method']) for r in rows}==expected
 assert all(r['verdict'] in ('faster','slower','inconclusive') for r in rows)
 return any(r['verdict']=='faster' for r in rows) and not any(r['verdict']=='slower' for r in rows)
