from consolidated_acceptance import PLAN, FIXTURE_PAIRS, MATRIX, qualification_valid
from pathlib import Path
from benchmark_process_cleanup import capture_children, stop_owned_benchmark, archive_with_retry
import datetime, hashlib, json, os, psutil, shutil, subprocess, time

ROOT = Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
BASE = Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC')
BASELINE=json.loads((ROOT/'consolidated-baseline.json').read_text(encoding='utf-8'))
OLD = Path(BASELINE['checkout'])
NEW = BASE/'si-afirma-word-products-20261030'
OUT = ROOT/'local-consolidated-followups-control-20261030'
REL = Path('benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks/bin/Release/net10.0')
DLL = 'OoplesFinance.StockIndicators.dll'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def manifest(p): return {f.relative_to(p).as_posix():digest(f) for f in p.rglob('*') if f.is_file()}
def head(p): return subprocess.check_output(['git','rev-parse','HEAD'],cwd=p,text=True).strip()

qualification=json.loads((ROOT/'batched-optimization-20261030/fixed-kernel-word-followup/status.json').read_text(encoding='utf-8'))
assert qualification['status']=='checks-passed-review-and-publication-pending'
qualification_valid(qualification)
old_qualification=json.loads(Path(BASELINE['qualification']).read_text(encoding='utf-8'))
assert old_qualification['gpu_passed']==100 and old_qualification['status']=='checks-passed-review-and-publication-pending'
assert digest(OLD/REL/DLL) in old_qualification['production_dll_sha256'].values()
assert not subprocess.check_output(['git','diff',old_qualification['input_head'],head(OLD),'--','src','tests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','benchmarks/OoplesFinance.StockIndicators.CompetitorTests','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json'],cwd=OLD)
assert digest(NEW/REL/DLL) in qualification['production_dll_sha256'].values()
# Only the consolidated reviewed inputs may differ.
changed=subprocess.check_output(['git','diff','--name-only',head(OLD),head(NEW),'--','src','tests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','benchmarks/OoplesFinance.StockIndicators.CompetitorTests','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json'],cwd=NEW,text=True).splitlines()
source_companions = {}
assert set(changed)==set(PLAN["changed_inputs"]) | set(source_companions),changed
assert head(NEW)==PLAN['candidate_qualified_head']
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=NEW)
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=OLD)
assert old_qualification['unit']['passed']==765 and old_qualification['parity']['passed']==381
assert not subprocess.check_output(['git','diff',qualification['input_head'],head(NEW),'--','src','tests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','benchmarks/OoplesFinance.StockIndicators.CompetitorTests','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json'],cwd=NEW)
original=manifest(OLD/REL)
required_runtime={'OoplesFinance.StockIndicators.CompetitorBenchmarks.dll','OoplesFinance.StockIndicators.CompetitorBenchmarks.deps.json','OoplesFinance.StockIndicators.CompetitorBenchmarks.runtimeconfig.json',DLL}
assert required_runtime<=original.keys(), 'Incomplete benchmark runtime: '+str(required_runtime-original.keys())
arms={'old':OLD/REL,'new':OUT/'new'}
if OUT.exists():
 saved=json.loads((OUT/'provenance.json').read_text(encoding='utf-8'))
 assert saved['old_source']==head(OLD) and saved['new_source']==head(NEW)
 assert saved['candidate_code_source']==qualification['input_head']
 manifests=json.loads((OUT/'binary-manifest.json').read_text(encoding='utf-8'))
 assert all(manifest(arms[a])==manifests[a] for a in ['old','new'])
 state=json.loads((OUT/'status.json').read_text(encoding='utf-8'))
 assert state['status']=='paused-for-independent-correctness'
 assert state['order']==['old','new','new','old']
 for record in state['rounds']:
  assert digest(Path(record['report']))==record['sha256']
else:
 assert shutil.disk_usage(ROOT).free > sum(p.stat().st_size for p in (OLD/REL).rglob('*') if p.is_file()) + 1024**3
 OUT.mkdir()
 original=manifest(OLD/REL)
 arms={'old':OLD/REL,'new':OUT/'new'}
 assert manifest(arms['old'])==original
 shutil.copytree(arms['old'],arms['new'])
 shutil.copy2(NEW/REL/DLL,arms['new']/DLL)
 manifests={arm:manifest(arms[arm]) for arm in ['old','new']}
 assert manifests['old']==original
 assert manifests['old'].keys()==manifests['new'].keys()
 assert [p for p in original if manifests['old'][p]!=manifests['new'][p]]==[DLL]
 (OUT/'binary-manifest.json').write_text(json.dumps(manifests,indent=2),encoding='utf-8')
 (OUT/'provenance.json').write_text(json.dumps({'old_source':head(OLD),'new_source':head(NEW),'candidate_code_source':qualification['input_head'],'qualification':qualification,'qualification_chain':{phase:json.loads((ROOT/'batched-optimization-20261030'/phase/'status.json').read_text()) for phase in PLAN['qualification_chain']},'performance_plan':PLAN,'old_qualification':old_qualification,'measurement_location':'Local Windows; no GitHub Actions measurement','changed_inputs':changed,'sonar_only_companions':source_companions},indent=2),encoding='utf-8')
 state={'status':'starting','order':['old','new','new','old'],'rounds':[]}

space_wait_count=0
def save():
 global space_wait_count
 # Keep the last complete checkpoint if another workload exhausts the drive.
 # Waiting for space does not waive any quiet-window or measurement gate.
 while True:
  if shutil.disk_usage(ROOT).free < 2 * 1024**3:
   space_wait_count+=1
   time.sleep(5)
   continue
  state['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
  temporary=OUT/'status.tmp'
  try:
   with temporary.open('w',encoding='utf-8',newline='\n') as stream:
    stream.write(json.dumps(state,indent=2)+'\n')
    stream.flush()
    os.fsync(stream.fileno())
   temporary.replace(OUT/'status.json')
   return
  except OSError as error:
   if error.errno != 28 and not isinstance(error,PermissionError):
    raise
   space_wait_count+=1
   time.sleep(5)
def active_validation_owners():
 result=[]
 owner_scripts=json.loads((ROOT/'batched-optimization-20261030/validation-owner-scripts.json').read_text())
 for p in psutil.process_iter(['name','cmdline']):
  if (p.info['name'] or '').lower() in ('python.exe','python3.13.exe') and any(script in arg for arg in (p.info['cmdline'] or []) for script in owner_scripts):
   result.append(p.pid)
 return result

env=os.environ.copy();env['TEMP']=env['TMP']=str(ROOT/'temp')
for key in ['COMPARISON_PAIR','COMPARISON_SHARD','COMPARISON_SHARDS']: env.pop(key,None)
def checkpoint_builds():
 return [p.pid for p in psutil.process_iter(['name','cmdline']) if (p.info['name'] or '').lower()=='dotnet.exe' and any(c in (p.info['cmdline'] or []) for c in ['build','test','vstest','publish','restore','pack'])] + active_validation_owners()

def checkpoint_binaries():
 assert all(manifest(arms[a])==manifests[a] for a in ['old','new']), 'Measurement binaries changed'

for index,arm in enumerate(state['order']):
 for fixture,methods,parameter,expected in MATRIX:
  if any(r['index']==index and r['fixture']==fixture for r in state['rounds']): continue
  if fixture == 'SharedTaDirectionalBenchmarks':
   from directional_checkpoint_runner import run_directional
   record=run_directional(out=OUT,index=index,arm=arm,fixture=fixture,
       pairs=FIXTURE_PAIRS[fixture],methods=methods,runtime=arms[arm],env=env,
       state=state,save=save,builds=checkpoint_builds,assert_binaries=checkpoint_binaries)
   assert record['cases']==expected
   state['rounds'].append(record);save()
   continue
  from successor_checkpoint_runner import run_checkpointed
  record=run_checkpointed(out=OUT,index=index,arm=arm,fixture=fixture,
      pairs=FIXTURE_PAIRS[fixture],methods=methods,runtime=arms[arm],env=env,
      state=state,save=save,builds=checkpoint_builds,assert_binaries=checkpoint_binaries)
  assert record['cases']==expected
  record['checkpoint_format']='operation-v1'
  state['rounds'].append(record);save()
assert manifest(arms['old'])==original
assert all(manifest(arms[arm])==manifests[arm] for arm in ['old','new'])
state['status']='raw-measurements-complete-independent-verification-pending';save()
print(state['status'],flush=True)
