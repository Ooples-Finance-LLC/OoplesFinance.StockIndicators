from pathlib import Path
import datetime,hashlib,json,os,psutil,shutil,subprocess,time,sys
ROOT=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
REPO=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
SOURCE=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
FIXTURES={'SharedTaAverageNativeBenchmarks': ['TaLib.Functions.Ma', 'TaLib.Functions.Apo', 'TaLib.Functions.Ppo'], 'SharedTaAdaptiveRateNativeBenchmarks': ['TaLib.Functions.Trix', 'TaLib.Functions.Kama', 'TaLib.Functions.Mavp'], 'SharedTaWindowNativeBenchmarks': ['TaLib.Functions.AvgDev', 'TaLib.Functions.Accbands']}
OUT=ROOT/'local-mapped-batch6-20261022';OUT.mkdir(exist_ok=True)
assert not (OUT/'status.json').exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==SOURCE
assert not subprocess.check_output(['git','status','--porcelain'],cwd=REPO)
qualification=json.loads((REPO/'benchmarks/results/remaining-indicators/publication-combined-integration-certified-20261022-verification.json').read_text())
assert qualification['gpu_passed']==100 and qualification['checks']['build-comparator']=='passed'
assert not subprocess.check_output(['git','diff',qualification['input_head'],SOURCE,'--','src','tests','benchmarks/OoplesFinance.StockIndicators.CompetitorTests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json'],cwd=REPO)
binary=REPO/'benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks/bin/Release/net10.0'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(binary/'OoplesFinance.StockIndicators.dll') in qualification['production_dll_sha256'].values()
assert shutil.disk_usage(ROOT).free>2*1024**3
manifest={p.relative_to(binary).as_posix():digest(p) for p in binary.rglob('*') if p.is_file()}
executed=ROOT/'local-mapped-batch4-20261022/binaries'
assert executed.is_dir()
assert {p.relative_to(executed).as_posix():digest(p) for p in (executed).rglob('*') if p.is_file()}==manifest
(OUT/'binary-manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
(OUT/'provenance.json').write_text(json.dumps({'source_sha':SOURCE,'qualification':qualification,'measurement_location':'Local Windows host; unchanged CPU setup and direct native methods; no hosted-measurement claim.','original_binary_directory':str(binary),'executed_binary_directory':str(executed),'binary_reuse_note':'Reuses identical combined integration binaries captured for mapped batch4; full before/after manifests retained.','copied_binary_manifest_sha256':digest(OUT/'binary-manifest.json')},indent=2),encoding='utf-8')
state={'source_sha':SOURCE,'status':'starting','fixtures':{}}
def save():
 state['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (OUT/'status.json').write_text(json.dumps(state,indent=2),encoding='utf-8')
env=os.environ.copy();env['TEMP']=env['TMP']=str(ROOT/'temp')
for fixture in FIXTURES:
 state.update(status='waiting-quiet-window',fixture=fixture);save()
 samples=[]
 while len(samples)<3 or any(x>15 for x in samples[-3:]):
  builds=[p.pid for p in psutil.process_iter(['name','cmdline']) if (p.info['name'] or '').lower()=='dotnet.exe' and 'build' in (p.info['cmdline'] or [])]
  cpu=psutil.cpu_percent(interval=5);samples.append(cpu)
  if builds:samples=[]
 state['fixtures'][fixture]={'quiet_cpu_samples':samples[-3:]};state['status']='measuring';save()
 filters=[f'*{fixture}.{method}*Count: {count}{end}*' for method in ['BuilderFull','BuilderLatestOnly','NativeSingle','NativeParallel'] for count in [1000,10000] for end in [',',')']]
 if fixture=='SharedTrueRangeBenchmarks':
  filters=[f'*{fixture}.{method}*{pair}*Count: {count}{end}*' for method in ['BuilderFull','BuilderLatestOnly','NativeSingle','NativeParallel'] for pair in FIXTURES[fixture] for count in [1000,10000] for end in [',',')']]
 folder=OUT/fixture
 try:
  with (OUT/(fixture+'.log')).open('wb') as log:
   subprocess.run(['dotnet',str(executed/'OoplesFinance.StockIndicators.CompetitorBenchmarks.dll'),'--filter',*filters,'--warmupCount','10','--iterationCount','10','--exporters','json','--artifacts',str(folder)],cwd=executed,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=1800)
  reports=list((folder/'results').glob('*-report-full-compressed.json'));assert len(reports)==1
  d=json.loads(reports[0].read_bytes());expected=8*len(FIXTURES[fixture])
  assert len(d['Benchmarks'])==expected and all(c.get('Statistics') and c['Statistics']['N']>=7 for c in d['Benchmarks'])
  state['fixtures'][fixture].update(status='raw-measurements-complete',report=str(reports[0]),sha256=digest(reports[0]),cases=expected)
 except Exception as error:
  state['fixtures'][fixture].update(status='failed',error=str(error));save();raise
 save()
assert all(digest(executed/name)==h for name,h in manifest.items())
assert all(digest(binary/name)==h for name,h in manifest.items())
state['status']='raw-measurements-complete-independent-verification-pending';save()
print(state['status'])
