```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |-----------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **Ad**        | **1000**  | **104.984 μs** | **2.3263 μs** | **1.3843 μs** | **57.85** |    **0.77** |  **3.9063** |      **-** |  **64.88 KB** |        **8.24** |
| BuilderLatestOnly | Ad        | 1000  |  99.678 μs | 0.4100 μs | 0.2144 μs | 54.93 |    0.27 |  0.9766 |      - |  17.27 KB |        2.19 |
| NativeSingle      | Ad        | 1000  |   1.815 μs | 0.0163 μs | 0.0085 μs |  1.00 |    0.01 |  0.4730 |      - |   7.88 KB |        1.00 |
| NativeParallel    | Ad        | 1000  |  77.343 μs | 0.7276 μs | 0.4813 μs | 42.62 |    0.32 |  0.4883 |      - |   8.17 KB |        1.04 |
|                   |           |       |            |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **Ad**        | **10000** | **967.895 μs** | **3.3681 μs** | **1.7616 μs** | **58.08** |    **0.40** | **31.2500** | **7.8125** | **627.79 KB** |        **8.03** |
| BuilderLatestOnly | Ad        | 10000 | 948.907 μs | 7.3639 μs | 3.8514 μs | 56.94 |    0.44 |  7.8125 |      - | 157.95 KB |        2.02 |
| NativeSingle      | Ad        | 10000 |  16.667 μs | 0.1956 μs | 0.1164 μs |  1.00 |    0.01 |  4.7607 | 0.8545 |  78.19 KB |        1.00 |
| NativeParallel    | Ad        | 10000 |  95.451 μs | 4.7844 μs | 3.1646 μs |  5.73 |    0.19 |  4.3945 | 0.4883 |  78.48 KB |        1.00 |
