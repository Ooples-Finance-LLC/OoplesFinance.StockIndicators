```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean     | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |---------- |------ |---------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **Ad**        | **1000**  | **104.1 μs** |  **1.34 μs** |  **0.80 μs** |  **3.9063** |      **-** |  **64.88 KB** |
| BuilderLatestOnly | Ad        | 1000  | 100.0 μs |  0.20 μs |  0.11 μs |  0.9766 |      - |  17.27 KB |
| **BuilderFull**       | **Ad**        | **10000** | **988.6 μs** | **51.90 μs** | **34.33 μs** | **31.2500** | **7.8125** | **627.79 KB** |
| BuilderLatestOnly | Ad        | 10000 | 947.6 μs |  5.56 μs |  2.91 μs |  7.8125 |      - | 157.95 KB |
