```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean         | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-------------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ad** |   **132.988 μs** |  **4.9737 μs** |  **2.6013 μs** |  **1.00** |    **0.03** |   **140.7 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ad |     3.422 μs |  0.4097 μs |  0.2438 μs |  0.03 |    0.00 |   10.45 KB |        0.07 |
|            |       |                    |              |            |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ad** | **1,044.460 μs** | **27.8032 μs** | **18.3901 μs** |  **1.00** |    **0.02** | **1711.63 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ad |    18.190 μs |  1.2271 μs |  0.8117 μs |  0.02 |    0.00 |   85.35 KB |        0.05 |
