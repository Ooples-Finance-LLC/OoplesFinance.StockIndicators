```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation            | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------ |--------------------- |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **TaLib(...)ified [29]** |  **87.86 μs** |  **2.556 μs** | **1.521 μs** |  **2.9297** |       **-** |  **62.52 KB** |
| BuilderLatestOnly | 1000  | TaLib(...)ified [29] |  85.28 μs |  1.227 μs | 0.812 μs |  0.4883 |       - |  14.64 KB |
| **BuilderFull**       | **10000** | **TaLib(...)ified [29]** | **175.32 μs** |  **4.706 μs** | **2.461 μs** | **33.2031** | **11.7188** | **555.68 KB** |
| BuilderLatestOnly | 10000 | TaLib(...)ified [29] | 201.93 μs | 11.866 μs | 7.849 μs |  3.9063 |       - |  85.57 KB |
