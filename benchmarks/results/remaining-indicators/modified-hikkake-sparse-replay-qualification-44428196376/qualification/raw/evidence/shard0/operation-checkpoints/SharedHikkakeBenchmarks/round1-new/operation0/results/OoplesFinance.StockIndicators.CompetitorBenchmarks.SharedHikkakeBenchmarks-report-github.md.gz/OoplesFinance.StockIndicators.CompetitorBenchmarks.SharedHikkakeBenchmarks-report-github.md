```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation            | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------ |--------------------- |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **TaLib(...)kkake [21]** |  **90.35 μs** | **3.630 μs** | **2.401 μs** |  **2.9297** |       **-** |  **58.53 KB** |
| BuilderLatestOnly | 1000  | TaLib(...)kkake [21] |  83.77 μs | 1.848 μs | 1.222 μs |  0.4883 |       - |  10.65 KB |
| **BuilderFull**       | **10000** | **TaLib(...)kkake [21]** | **162.18 μs** | **9.163 μs** | **6.061 μs** | **33.2031** | **11.7188** | **551.07 KB** |
| BuilderLatestOnly | 10000 | TaLib(...)kkake [21] | 141.25 μs | 8.898 μs | 5.885 μs |  4.8828 |  0.9766 |  80.96 KB |
