```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)ified [29]** |  **76.67 μs** | **2.990 μs** | **1.564 μs** |  **1.00** |    **0.03** |   **68.1 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)ified [29] |  22.94 μs | 0.646 μs | 0.338 μs |  0.30 |    0.01 |  19.25 KB |        0.28 |
|            |       |                      |           |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)ified [29]** | **153.19 μs** | **5.979 μs** | **3.127 μs** |  **1.00** |    **0.03** | **638.11 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)ified [29] | 211.00 μs | 6.744 μs | 3.527 μs |  1.38 |    0.03 | 124.77 KB |        0.20 |
