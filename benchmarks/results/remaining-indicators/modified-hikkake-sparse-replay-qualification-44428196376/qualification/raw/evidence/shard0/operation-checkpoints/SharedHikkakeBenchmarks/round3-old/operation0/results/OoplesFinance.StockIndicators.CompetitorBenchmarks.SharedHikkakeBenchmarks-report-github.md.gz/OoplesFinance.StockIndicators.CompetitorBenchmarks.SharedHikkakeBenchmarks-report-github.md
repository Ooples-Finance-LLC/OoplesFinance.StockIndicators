```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation            | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------ |--------------------- |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **TaLib(...)kkake [21]** |  **85.79 μs** |  **1.778 μs** | **0.930 μs** |  **2.9297** |       **-** |  **58.53 KB** |
| BuilderLatestOnly | 1000  | TaLib(...)kkake [21] |  83.55 μs |  1.543 μs | 1.021 μs |  0.4883 |       - |  10.64 KB |
| **BuilderFull**       | **10000** | **TaLib(...)kkake [21]** | **160.06 μs** | **10.307 μs** | **6.817 μs** | **33.2031** | **11.7188** | **551.07 KB** |
| BuilderLatestOnly | 10000 | TaLib(...)kkake [21] | 139.98 μs |  6.065 μs | 3.609 μs |  4.8828 |       - |  80.96 KB |
