```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation            | Mean      | Error     | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |------ |--------------------- |----------:|----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **1000**  | **TaLib(...)ified [29]** |  **88.07 μs** |  **2.228 μs** |  **1.326 μs** |  **2.9297** |      **-** |  **62.52 KB** |
| BuilderLatestOnly | 1000  | TaLib(...)ified [29] |  88.73 μs |  0.800 μs |  0.529 μs |  0.4883 |      - |  14.64 KB |
| **BuilderFull**       | **10000** | **TaLib(...)ified [29]** | **242.73 μs** | **26.527 μs** | **15.786 μs** | **33.2031** | **9.7656** | **555.68 KB** |
| BuilderLatestOnly | 10000 | TaLib(...)ified [29] | 191.24 μs | 51.938 μs | 34.354 μs |  3.9063 |      - |  85.57 KB |
