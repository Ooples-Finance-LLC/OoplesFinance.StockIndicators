```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation            | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------ |--------------------- |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **TaLib(...)ified [29]** |  **97.37 μs** |  **5.110 μs** |  **3.380 μs** |  **1.9531** |       **-** |  **60.97 KB** |
| BuilderLatestOnly | 1000  | TaLib(...)ified [29] |  92.00 μs |  0.861 μs |  0.512 μs |       - |       - |  13.09 KB |
| **BuilderFull**       | **10000** | **TaLib(...)ified [29]** | **256.56 μs** | **20.801 μs** | **13.759 μs** | **33.2031** | **13.6719** | **553.52 KB** |
| BuilderLatestOnly | 10000 | TaLib(...)ified [29] | 236.97 μs | 14.266 μs |  9.436 μs |  3.9063 |       - |  83.42 KB |
