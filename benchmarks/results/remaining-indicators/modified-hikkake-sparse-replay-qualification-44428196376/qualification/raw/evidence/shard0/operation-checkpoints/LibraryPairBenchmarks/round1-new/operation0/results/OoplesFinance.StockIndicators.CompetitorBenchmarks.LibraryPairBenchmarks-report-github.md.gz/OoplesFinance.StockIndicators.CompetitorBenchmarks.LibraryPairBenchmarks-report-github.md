```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean      | Error     | StdDev    | Median    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |----------:|----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)kkake [21]** |  **73.98 μs** |  **12.77 μs** |  **7.600 μs** |  **71.40 μs** |  **1.01** |    **0.14** |   **65.8 KB** |        **1.00** |
|        |       |                      |           |           |           |           |       |         |           |             |
| **Ooples** | **10000** | **TaLib(...)kkake [21]** | **187.36 μs** | **119.93 μs** | **71.371 μs** | **149.50 μs** |  **1.10** |    **0.51** | **636.41 KB** |        **1.00** |
