```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)kkake [21]** | **124.69 μs** | **10.050 μs** |  **5.980 μs** |  **1.00** |    **0.06** |   **65.8 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)kkake [21] |  12.10 μs |  1.662 μs |  1.099 μs |  0.10 |    0.01 |  18.27 KB |        0.28 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)kkake [21]** | **136.99 μs** | **23.099 μs** | **13.746 μs** |  **1.01** |    **0.13** | **636.41 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)kkake [21] |  93.40 μs |  2.630 μs |  1.375 μs |  0.69 |    0.06 | 123.78 KB |        0.19 |
