const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const crypto = require('crypto');
(async () => {
  const [htmlPath, csvPath] = process.argv.slice(2);
  const html = fs.readFileSync(htmlPath, 'utf8');
  const data = JSON.parse(html.match(/<script[^>]*id="dataset"[^>]*>([\s\S]*?)<\/script>/)[1]);
  const match = html.match(/function exportCSV\(\)\{[\s\S]*?setTimeout\(\(\)=>URL\.revokeObjectURL\(a\.href\),1000\);\}/g);
  assert(match && match.length === 1);
  let blob, clicked = 0;
  const anchor = { click() { clicked++; } };
  const context = {
    D: data, filtered: data.rows, Blob,
    document: { createElement(name) { assert.equal(name, 'a'); return anchor; } },
    URL: { createObjectURL(value) { blob = value; return 'blob:csv-verification'; }, revokeObjectURL() {} },
    setTimeout(callback) { callback(); }
  };
  vm.runInNewContext(match[0] + '\nexportCSV();', context, { timeout: 2000 });
  assert.equal(clicked, 1);
  assert.equal(anchor.download, 'ooples-competitor-comparisons.csv');
  const bytes = Buffer.from(await blob.text(), 'utf8');
  if (fs.existsSync(csvPath)) assert(fs.readFileSync(csvPath).equals(bytes));
  else fs.writeFileSync(csvPath, bytes, { flag: 'wx' });
  console.log(JSON.stringify({
    exact_candidate_export_function_executed: true, unfiltered_dataset_rows: data.rows.length,
    csv: csvPath, bytes: bytes.length, sha256: crypto.createHash('sha256').update(bytes).digest('hex'),
    browser_layout_or_actual_download_verified: false
  }));
})();
