"""Compose only the accepted Hikkake full qualification; never apply live HTML."""
import argparse,hashlib,json,os,re,subprocess,sys
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--root-review-sha256',required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
OPS=Path(r'C:\Users\cheat\source\stock-indicators-operations');TOOL=Path(r'C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-modified-hikkake-sparse-replay-qualification-20261118');PUB=Path(r'C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-modified-hikkake-sparse-replay-publisher-20261118')
E=OPS/'modified-hikkake-sparse-replay-qualification-20261118/local-evidence/modified-hikkake-sparse-replay-qualification-44428196376'
BASE=OPS/'renko-normalized-grid-composed-report-stage-44396431211/candidate.html';LIVE=Path(r'C:\Users\cheat\Documents\OoplesFinance-Reports\competitor-performance.html')
BASE_SHA='fc847d58976387646e889d3b08fc0cbaf5c60b5cb660f2526119930ad1162837';LIVE_SHA='9dc3d9b721dfaed8f114b6cc5d680d71b726598331236f9a51e0b541d4f81e11';SOURCE='48d238f56c37986b8437e5c31164552cc1362802';HEAD='a4e2cc4e1c8b2bb4da00cf306703da283f36344a';RUN='44428196376';SUMMARY='213d8e3a2c80a5f3eae6c336290d6663ed7366869d97a3728413c4623ae919d5'
PLAN=TOOL/'benchmarks/plans/hosted-modified-hikkake-sparse-replay-qualification-20261118.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_bytes())
def embedded(text,name):return json.loads(re.search(r'<script[^>]*id="'+name+r'"[^>]*>(.*?)</script>',text,re.S)[1])
def rows(d):
 out={(r['pair'],r['bars']):r for r in d['rows']};assert len(out)==len(d['rows'])==802;return out
assert a.root_review_sha256=='40206e4c5358d0d9e25c0b1e8f369f3b5b180c57097f88b411d17eedd5c1d9f0' and sha(E/'root-review.json')==a.root_review_sha256
review=load(E/'root-review.json');assert review['status']=='independently-recollected-full-qualification-accepted'
assert review['source']==SOURCE and review['baseline']=='d9d00ca56ebb857b87ead45044616970b607019c' and review['run_id']==RUN and review['workflow_head']==HEAD and review['summary_sha256']==SUMMARY
assert review['plan_sha256']=='271048d4d5bc7280898a070e474d4235873c4b2b7a659721f62fef8edda11473' and review['independent_authentication_passed'] and review['accepted'] and review['qualification']
assert review['source_gate_passed'] and review['native_progress_gate_passed'] and not review['production_integrated'] and not review['report_imported'] and review['closure_credit']==0
assert not a.out.exists() and sha(BASE)==BASE_SHA and sha(LIVE)==LIVE_SHA and sha(E/'authenticated-summary.json')==SUMMARY
summary=load(E/'authenticated-summary.json');assert summary['accepted'] and summary['qualification'] and summary['source_gate_accepted'] and summary['native_progress_gate_passed']
assert summary['verdicts']=={'inconclusive':8,'faster':4} and (summary['case_count'],summary['decision_count'])==(52,12)
assert sha(PLAN)=='271048d4d5bc7280898a070e474d4235873c4b2b7a659721f62fef8edda11473'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=TOOL,text=True).strip()==HEAD
subprocess.run(['git','diff','--exit-code',SOURCE,'--','src','tests'],cwd=PUB,check=True)
os.environ['HOSTED_TIMING_PLAN']=str(PLAN);sys.path[:0]=[str(TOOL/'scripts'),str(PUB/'benchmarks')]
from hosted_timing.report import stage
candidate=stage(BASE,E/'raw/evidence',PUB,a.out,phase='targeted')
text=candidate.read_text(encoding='utf-8');data=embedded(text,'dataset');before=rows(embedded(BASE.read_text(encoding='utf-8'),'dataset'));after=rows(data)
keys={(p,n) for p in ('TaLib.Candles.Hikkake','TaLib.Candles.HikkakeModified') for n in (1000,10000)}
obsolete={'measurement_kind','baseline_refresh_reason','harness_changed','same_binary_verdict','native_round_classifications','native_consensus','native_control_round','native_control_count','canonical_gpu_source_sha','canonical_gpu_receipt_sha256','production_assembly_sha256'}
for key in keys:
 row=after[key];assert row['source_sha']==SOURCE and str(row['measurement_run_id'])==RUN
 for field in obsolete:row.pop(field,None)
 row.update(measurement_kind='qualified-source-verification',production_assembly_sha256='fdeea3ee60cc5f8e5826933e20dba822477e171ecf1c562eefb7ab00a7ae0258',canonical_gpu_source_sha=SOURCE,canonical_gpu_receipt_sha256='8662a14c8f84f5caacdebabc515492ac342324586a8402f8d862aff58e5a76b6',benchmark_source_sha='d9d00ca56ebb857b87ead45044616970b607019c',benchmark_assembly_sha256='32e9b2a5e92bdd4aabec6b9749a5b891befab3e02a922022c93a4d0c95784e5f',qualification_role='optimization-target',production_optimization=True)
assert before.keys()==after.keys() and {k for k in before if before[k]!=after[k]}==keys
assert embedded(BASE.read_text(encoding='utf-8'),'current-competitor-data')==embedded(text,'current-competitor-data')
before_data=embedded(BASE.read_text(encoding='utf-8'),'dataset');assert before_data['evidence'].get('snapshotMeasurements',[])==data['evidence'].get('snapshotMeasurements',[])
def unrelated_controls(d):
 return [dict(receipt,rows=[r for r in receipt['rows'] if r['pair'] not in {k[0] for k in keys}]) for receipt in d['evidence'].get('builderControlMeasurements',[]) if any(r['pair'] not in {k[0] for k in keys} for r in receipt['rows'])]
assert unrelated_controls(before_data)==unrelated_controls(data)
controls=[receipt for receipt in data['evidence']['builderControlMeasurements'] if receipt['source_sha']==SOURCE and str(receipt['run_id'])==RUN]
assert len(controls)==1 and controls[0]['comparison_kind']=='source-control-only' and len(controls[0]['rows'])==8
expected={(p,n,m) for p,n in keys for m in ('BuilderFull','BuilderLatestOnly')};assert {(r['pair'],r['bars'],r['method']) for r in controls[0]['rows']}==expected
text,count=re.subn(r'(<script[^>]*id="dataset"[^>]*>).*?(</script>)',lambda m:m[1]+json.dumps(data,ensure_ascii=True).replace('<','\\u003c')+m[2],text,flags=re.S);assert count==1;candidate.write_bytes(text.encode())
staged=load(a.out/'staged.json');assert (staged['changed_baseline_rows'],staged['changed_builder_slots'],staged['changed_builder_control_rows'],staged['changed_snapshot_rows'])==(4,0,8,0)
staged['candidate_sha256']=sha(candidate);(a.out/'staged.json').write_bytes((json.dumps(staged,indent=2)+'\n').encode())
assert sha(BASE)==BASE_SHA and sha(LIVE)==LIVE_SHA
live_rows=rows(embedded(LIVE.read_text(encoding='utf-8'),'dataset'));prior={k for k in before if before[k]!=live_rows[k]};assert all(after[k]==before[k] for k in prior-keys)
receipt=dict(status='composed-stage-only-live-import-and-visual-review-pending',source=SOURCE,run_id=RUN,summary_sha256=SUMMARY,root_review_sha256=a.root_review_sha256,base_report=str(BASE),base_report_sha256=BASE_SHA,actual_live_before=str(LIVE),actual_live_before_sha256=LIVE_SHA,candidate_sha256=sha(candidate),changed_baseline_rows=4,added_source_control_rows=8,fresh_builder_native_measurements=0,all_prior_builder_native_rows_preserved=True,preserved_prior_staged_baseline_changes=len(prior-keys),future_live_apply_target=str(LIVE),must_not_apply_to_staged_base=True,live_imported=False,browser_verified=False,published_live_closure_credit=0)
(a.out/'composition-receipt.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode());print(json.dumps(receipt))
