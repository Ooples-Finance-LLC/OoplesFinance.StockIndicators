```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Trix** |   **191.39 μs** |  **3.457 μs** |  **1.808 μs** |  **1.00** |  **192.78 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Trix |    14.70 μs |  0.758 μs |  0.396 μs |  0.08 |   48.41 KB |        0.25 |
|            |       |                      |             |           |           |       |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Trix** | **1,890.24 μs** | **22.373 μs** | **13.314 μs** |  **1.00** | **1897.23 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Trix |   132.22 μs |  5.317 μs |  2.781 μs |  0.07 |  408.81 KB |        0.22 |
