```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **232.7 μs** |  **1.90 μs** | **1.13 μs** |       **-** |       **-** |  **89.09 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   229.4 μs |  1.98 μs | 1.31 μs |  1.9531 |       - |  41.45 KB |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **2,355.2 μs** | **12.76 μs** | **6.68 μs** | **46.8750** | **15.6250** | **862.96 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 2,359.3 μs | 13.20 μs | 7.86 μs | 15.6250 |       - | 393.13 KB |
