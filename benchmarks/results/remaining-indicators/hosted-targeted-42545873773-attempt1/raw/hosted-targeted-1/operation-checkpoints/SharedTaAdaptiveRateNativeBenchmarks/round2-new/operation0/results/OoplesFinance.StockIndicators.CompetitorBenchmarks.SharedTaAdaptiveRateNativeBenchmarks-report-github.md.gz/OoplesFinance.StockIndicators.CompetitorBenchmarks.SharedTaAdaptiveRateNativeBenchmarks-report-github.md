```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **120.65 μs** |  **0.870 μs** |  **0.517 μs** | **11.47** |    **0.09** |       **-** |       **-** |  **89.08 KB** |        **5.75** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   112.70 μs |  0.596 μs |  0.312 μs | 10.71 |    0.08 |  1.9531 |       - |  41.43 KB |        2.68 |
| NativeSingle      | TaLib.Functions.Trix | 1000  |    10.52 μs |  0.113 μs |  0.075 μs |  1.00 |    0.01 |  0.9155 |       - |  15.48 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Trix | 1000  |    98.93 μs |  2.302 μs |  1.522 μs |  9.40 |    0.15 |  2.9297 |       - |  47.61 KB |        3.07 |
|                   |                      |       |             |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **1,186.12 μs** | **40.964 μs** | **27.095 μs** | **11.06** |    **0.28** | **46.8750** | **15.6250** |  **862.9 KB** |        **5.53** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 1,152.18 μs |  4.344 μs |  2.585 μs | 10.75 |    0.15 | 23.4375 |  7.8125 | 393.07 KB |        2.52 |
| NativeSingle      | TaLib.Functions.Trix | 10000 |   107.22 μs |  2.312 μs |  1.529 μs |  1.00 |    0.02 |  8.7891 |  0.9766 | 156.12 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Trix | 10000 |   219.75 μs |  8.771 μs |  5.802 μs |  2.05 |    0.06 | 29.2969 |  7.8125 | 469.49 KB |        3.01 |
