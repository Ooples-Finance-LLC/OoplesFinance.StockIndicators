```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error   | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |-----------:|--------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **167.9 μs** | **3.32 μs** | **1.97 μs** |       **-** |       **-** |  **89.09 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   182.0 μs | 1.09 μs | 0.65 μs |  1.9531 |       - |  41.44 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **1,960.5 μs** | **8.81 μs** | **4.61 μs** | **46.8750** | **15.6250** | **862.94 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 2,037.6 μs | 9.57 μs | 5.69 μs | 15.6250 |       - | 393.09 KB |
