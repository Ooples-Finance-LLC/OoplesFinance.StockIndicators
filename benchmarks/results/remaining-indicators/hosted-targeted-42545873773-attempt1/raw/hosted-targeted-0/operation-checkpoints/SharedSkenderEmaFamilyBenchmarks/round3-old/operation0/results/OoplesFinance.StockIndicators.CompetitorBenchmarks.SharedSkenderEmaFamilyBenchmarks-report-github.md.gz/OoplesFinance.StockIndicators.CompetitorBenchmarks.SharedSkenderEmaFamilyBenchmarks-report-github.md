```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **166.2 μs** |  **1.72 μs** |  **0.90 μs** |       **-** |       **-** |  **89.04 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   173.3 μs |  1.76 μs |  0.92 μs |  1.9531 |       - |  41.45 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **2,021.5 μs** | **18.21 μs** | **10.84 μs** | **46.8750** | **15.6250** | **862.91 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 2,037.4 μs |  6.71 μs |  3.99 μs | 15.6250 |       - | 393.09 KB |
