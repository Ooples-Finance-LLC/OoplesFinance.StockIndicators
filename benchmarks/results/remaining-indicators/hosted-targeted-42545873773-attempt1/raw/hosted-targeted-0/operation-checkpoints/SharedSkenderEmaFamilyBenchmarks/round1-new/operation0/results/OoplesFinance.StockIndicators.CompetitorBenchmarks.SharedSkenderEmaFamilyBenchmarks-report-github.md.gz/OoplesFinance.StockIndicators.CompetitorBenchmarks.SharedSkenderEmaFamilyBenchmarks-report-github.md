```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |  **74.04 μs** |  **3.197 μs** |  **2.115 μs** |  **3.9063** |       **-** |  **89.04 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |  72.54 μs |  5.299 μs |  3.153 μs |  1.9531 |       - |  41.44 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **978.99 μs** | **48.977 μs** | **32.396 μs** | **46.8750** | **15.6250** |  **862.9 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 932.56 μs | 19.012 μs |  9.944 μs | 23.4375 |  7.8125 | 393.05 KB |
