```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |    **71.97 μs** |   **0.602 μs** |   **0.359 μs** |  **2.97** |    **0.05** |   **3.9063** |        **-** |        **-** |   **89.01 KB** |        **0.73** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |    69.49 μs |   0.594 μs |   0.353 μs |  2.87 |    0.05 |   2.4414 |        - |        - |   41.44 KB |        0.34 |
| NativeSingle      | Skender.GetTrix | 1000  |    24.21 μs |   0.581 μs |   0.384 μs |  1.00 |    0.02 |   7.3242 |   1.7090 |        - |  121.49 KB |        1.00 |
| NativeParallel    | Skender.GetTrix | 1000  |   110.62 μs |   6.879 μs |   4.550 μs |  4.57 |    0.19 |  20.5078 |   5.8594 |        - |  312.32 KB |        2.57 |
|                   |                 |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetTrix** | **10000** |   **970.39 μs** |  **10.393 μs** |   **6.185 μs** |  **2.33** |    **0.02** |  **46.8750** |  **15.6250** |        **-** |  **862.87 KB** |        **0.71** |
| BuilderLatestOnly | Skender.GetTrix | 10000 |   925.85 μs |   5.717 μs |   3.402 μs |  2.22 |    0.01 |  23.4375 |   7.8125 |        - |  393.06 KB |        0.32 |
| NativeSingle      | Skender.GetTrix | 10000 |   417.20 μs |   3.164 μs |   1.883 μs |  1.00 |    0.01 |  97.6563 |  97.6563 |  97.6563 | 1212.11 KB |        1.00 |
| NativeParallel    | Skender.GetTrix | 10000 | 1,833.17 μs | 553.837 μs | 366.329 μs |  4.39 |    0.84 | 296.8750 | 234.3750 | 156.2500 | 3109.14 KB |        2.57 |
