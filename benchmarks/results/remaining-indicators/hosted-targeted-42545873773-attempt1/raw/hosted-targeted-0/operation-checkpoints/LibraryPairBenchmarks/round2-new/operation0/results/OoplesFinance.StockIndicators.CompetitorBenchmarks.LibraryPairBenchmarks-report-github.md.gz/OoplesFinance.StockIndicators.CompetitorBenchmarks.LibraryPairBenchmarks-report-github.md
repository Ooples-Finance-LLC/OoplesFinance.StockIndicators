```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId          | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetTrix** |   **159.01 μs** | **13.280 μs** |  **7.903 μs** |  **1.00** |    **0.07** |  **210.95 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetTrix |    45.08 μs |  0.995 μs |  0.520 μs |  0.28 |    0.01 |  203.65 KB |        0.97 |
|            |       |                 |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetTrix** | **1,435.39 μs** | **24.487 μs** | **12.807 μs** |  **1.00** |    **0.01** | **2071.63 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetTrix |   464.23 μs | 47.977 μs | 28.550 μs |  0.32 |    0.02 | 1950.38 KB |        0.94 |
