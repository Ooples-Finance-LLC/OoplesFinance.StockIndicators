```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId          | Mean       | Error    | StdDev  | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |---------------- |-----------:|---------:|--------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetTrix** |   **276.6 μs** | **15.74 μs** | **9.37 μs** |  **1.00** |    **0.04** |  **210.95 KB** |        **1.00** |
|        |       |                 |            |          |         |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetTrix** | **2,571.2 μs** | **13.53 μs** | **7.08 μs** |  **1.00** |    **0.00** | **2071.02 KB** |        **1.00** |
