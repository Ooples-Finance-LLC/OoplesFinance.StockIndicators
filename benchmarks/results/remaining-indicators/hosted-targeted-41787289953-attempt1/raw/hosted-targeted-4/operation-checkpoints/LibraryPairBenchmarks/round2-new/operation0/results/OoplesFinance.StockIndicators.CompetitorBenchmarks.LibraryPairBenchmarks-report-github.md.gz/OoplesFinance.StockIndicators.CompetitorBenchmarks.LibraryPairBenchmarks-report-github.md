```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error        | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)gence [50]** |    **658.3 μs** |     **28.44 μs** |    **16.93 μs** |  **1.00** |    **0.03** |         **-** |         **-** |         **-** |    **290.1 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)gence [50] |  2,625.1 μs |     52.40 μs |    34.66 μs |  3.99 |    0.11 |         - |         - |         - |  3520.52 KB |       12.14 |
|            |       |                      |             |              |             |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)gence [50]** |  **6,386.5 μs** |     **20.94 μs** |    **12.46 μs** |  **1.00** |    **0.00** |         **-** |         **-** |         **-** |  **2857.19 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)gence [50] | 35,912.2 μs | 10,730.83 μs | 7,097.78 μs |  5.62 |    1.06 | 2000.0000 | 1000.0000 | 1000.0000 | 34691.43 KB |       12.14 |
