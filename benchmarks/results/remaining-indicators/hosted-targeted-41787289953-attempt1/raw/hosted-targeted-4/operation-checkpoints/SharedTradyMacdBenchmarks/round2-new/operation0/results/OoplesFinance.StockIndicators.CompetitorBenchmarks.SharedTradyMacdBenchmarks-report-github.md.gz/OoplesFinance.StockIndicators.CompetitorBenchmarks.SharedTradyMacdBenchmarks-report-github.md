```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |    **566.1 μs** |    **56.55 μs** |    **33.65 μs** |  **0.27** |    **0.02** |         **-** |         **-** |         **-** |   **105.04 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |    563.9 μs |    50.28 μs |    33.25 μs |  0.27 |    0.02 |         - |         - |         - |    57.43 KB |        0.02 |
| NativeSingle      | Movin(...)gence [34] | 1000  |  2,080.7 μs |    26.96 μs |    16.04 μs |  1.00 |    0.01 |  203.1250 |  140.6250 |   46.8750 |  3232.15 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 1000  |  1,851.2 μs |    83.79 μs |    49.86 μs |  0.89 |    0.02 |  359.3750 |  171.8750 |         - |  5670.88 KB |        1.75 |
|                   |                      |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** |  **5,385.6 μs** |    **26.01 μs** |    **13.61 μs** |  **0.23** |    **0.02** |   **31.2500** |         **-** |         **-** |  **1019.65 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 |  5,330.1 μs |    22.15 μs |    11.58 μs |  0.23 |    0.02 |   31.2500 |         - |         - |   549.82 KB |        0.02 |
| NativeSingle      | Movin(...)gence [34] | 10000 | 23,703.8 μs | 3,040.87 μs | 2,011.35 μs |  1.01 |    0.12 | 2250.0000 | 1500.0000 | 1250.0000 | 31914.93 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 10000 | 23,867.2 μs | 3,061.23 μs | 2,024.81 μs |  1.01 |    0.12 | 3200.0000 | 2200.0000 | 1400.0000 | 56070.56 KB |        1.76 |
