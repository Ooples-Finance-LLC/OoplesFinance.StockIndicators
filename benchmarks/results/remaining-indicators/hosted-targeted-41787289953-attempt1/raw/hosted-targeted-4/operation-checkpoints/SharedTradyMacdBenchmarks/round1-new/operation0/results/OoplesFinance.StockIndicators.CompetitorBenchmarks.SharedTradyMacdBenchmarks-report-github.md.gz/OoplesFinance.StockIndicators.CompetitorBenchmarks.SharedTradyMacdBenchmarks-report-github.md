```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |   **549.3 μs** |  **2.85 μs** |  **1.70 μs** |       **-** |  **105.04 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |   532.5 μs |  3.24 μs |  1.93 μs |       - |   57.41 KB |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** | **5,341.9 μs** | **20.38 μs** | **10.66 μs** | **31.2500** | **1019.66 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 | 5,301.7 μs | 47.77 μs | 24.98 μs | 31.2500 |  549.85 KB |
