```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error       | StdDev    | Gen0    | Allocated  |
|------------------ |--------------------- |------ |-----------:|------------:|----------:|--------:|-----------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |   **555.1 μs** |    **24.15 μs** |  **14.37 μs** |       **-** |  **104.96 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |   536.6 μs |     3.25 μs |   1.93 μs |       - |   57.39 KB |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** | **5,314.6 μs** |    **21.47 μs** |  **11.23 μs** | **31.2500** | **1019.61 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 | 6,000.4 μs | 1,028.26 μs | 680.13 μs | 31.2500 |  549.83 KB |
