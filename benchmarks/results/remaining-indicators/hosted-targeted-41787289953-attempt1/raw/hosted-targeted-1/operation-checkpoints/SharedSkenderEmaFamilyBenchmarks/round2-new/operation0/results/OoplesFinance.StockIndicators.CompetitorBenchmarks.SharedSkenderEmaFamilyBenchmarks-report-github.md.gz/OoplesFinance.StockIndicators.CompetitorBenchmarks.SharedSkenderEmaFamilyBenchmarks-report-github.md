```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **556.07 μs** |   **3.548 μs** |   **1.856 μs** |  **8.84** |    **0.29** |        **-** |        **-** |        **-** |  **128.55 KB** |        **0.40** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   542.75 μs |   3.463 μs |   2.291 μs |  8.63 |    0.28 |   3.9063 |        - |        - |   80.91 KB |        0.25 |
| NativeSingle      | Skender.GetMacd | 1000  |    62.94 μs |   3.227 μs |   2.135 μs |  1.00 |    0.05 |  19.5313 |   6.3477 |        - |  324.54 KB |        1.00 |
| NativeParallel    | Skender.GetMacd | 1000  |   126.26 μs |   9.179 μs |   6.071 μs |  2.01 |    0.11 |  53.7109 |  21.4844 |        - |  826.62 KB |        2.55 |
|                   |                 |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **5,563.59 μs** |  **38.237 μs** |  **25.291 μs** |  **4.59** |    **0.11** |  **62.5000** |        **-** |        **-** | **1254.13 KB** |        **0.36** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 5,508.86 μs |  74.484 μs |  49.266 μs |  4.55 |    0.11 |  31.2500 |        - |        - |  784.29 KB |        0.23 |
| NativeSingle      | Skender.GetMacd | 10000 | 1,212.65 μs |  44.933 μs |  29.721 μs |  1.00 |    0.03 | 218.7500 | 218.7500 | 218.7500 | 3443.12 KB |        1.00 |
| NativeParallel    | Skender.GetMacd | 10000 | 4,335.64 μs | 522.610 μs | 345.674 μs |  3.58 |    0.28 | 750.0000 | 656.2500 | 312.5000 | 8556.91 KB |        2.49 |
