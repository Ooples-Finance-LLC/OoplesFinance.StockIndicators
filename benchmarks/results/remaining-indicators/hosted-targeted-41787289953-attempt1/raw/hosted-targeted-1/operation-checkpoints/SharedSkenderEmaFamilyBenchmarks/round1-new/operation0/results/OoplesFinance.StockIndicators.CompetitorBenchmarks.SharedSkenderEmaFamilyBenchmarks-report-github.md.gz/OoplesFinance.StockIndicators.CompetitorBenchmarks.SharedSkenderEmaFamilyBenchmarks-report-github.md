```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **545.9 μs** |  **3.72 μs** |  **1.95 μs** |       **-** |  **128.52 KB** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   543.4 μs |  6.55 μs |  3.90 μs |  3.9063 |   80.92 KB |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **5,477.5 μs** | **17.46 μs** | **10.39 μs** | **62.5000** | **1254.07 KB** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 5,552.8 μs | 69.95 μs | 36.58 μs | 31.2500 |  784.28 KB |
