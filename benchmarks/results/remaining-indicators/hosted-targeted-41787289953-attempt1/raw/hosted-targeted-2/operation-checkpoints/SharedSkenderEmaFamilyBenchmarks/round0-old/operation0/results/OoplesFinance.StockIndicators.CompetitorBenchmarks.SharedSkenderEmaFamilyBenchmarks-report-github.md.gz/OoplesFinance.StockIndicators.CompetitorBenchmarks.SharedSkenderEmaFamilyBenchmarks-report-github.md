```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated  |
|------------------ |--------------- |------ |-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **717.8 μs** | **13.86 μs** |  **7.25 μs** |  **105.05 KB** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   698.7 μs | 16.01 μs | 10.59 μs |   57.37 KB |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **6,892.5 μs** | **91.58 μs** | **54.50 μs** | **1019.84 KB** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 7,049.3 μs | 99.13 μs | 58.99 μs |  550.09 KB |
