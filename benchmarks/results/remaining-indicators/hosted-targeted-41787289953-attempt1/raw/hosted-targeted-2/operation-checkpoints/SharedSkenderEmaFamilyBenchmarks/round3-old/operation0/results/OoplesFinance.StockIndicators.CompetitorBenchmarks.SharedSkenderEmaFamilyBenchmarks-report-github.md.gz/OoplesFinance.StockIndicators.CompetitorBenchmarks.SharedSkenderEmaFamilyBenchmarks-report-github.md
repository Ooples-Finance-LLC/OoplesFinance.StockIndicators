```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated  |
|------------------ |--------------- |------ |-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **686.6 μs** |  **4.69 μs** |  **2.79 μs** |  **105.05 KB** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   670.5 μs |  7.80 μs |  4.64 μs |   57.39 KB |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **6,963.4 μs** | **45.47 μs** | **27.06 μs** | **1019.99 KB** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 6,863.7 μs | 89.90 μs | 53.50 μs |  550.13 KB |
