```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **628.85 μs** |   **6.923 μs** |   **4.120 μs** |  **8.33** |    **0.21** |        **-** |        **-** |        **-** |  **105.08 KB** |        **0.37** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   595.31 μs |   5.014 μs |   2.984 μs |  7.88 |    0.20 |        - |        - |        - |   57.42 KB |        0.20 |
| NativeSingle      | Skender.GetPvo | 1000  |    75.57 μs |   2.950 μs |   1.951 μs |  1.00 |    0.03 |  17.0898 |   3.4180 |        - |  285.61 KB |        1.00 |
| NativeParallel    | Skender.GetPvo | 1000  |   145.19 μs |   9.854 μs |   6.518 μs |  1.92 |    0.09 |  46.8750 |  14.6484 |        - |  729.53 KB |        2.55 |
|                   |                |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **6,090.25 μs** |  **22.672 μs** |  **14.996 μs** |  **4.81** |    **0.04** |  **31.2500** |        **-** |        **-** | **1019.64 KB** |        **0.33** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 6,067.95 μs | 106.287 μs |  70.302 μs |  4.80 |    0.07 |  31.2500 |        - |        - |  549.84 KB |        0.18 |
| NativeSingle      | Skender.GetPvo | 10000 | 1,265.37 μs |  23.102 μs |  12.083 μs |  1.00 |    0.01 | 164.0625 | 164.0625 | 164.0625 | 3052.19 KB |        1.00 |
| NativeParallel    | Skender.GetPvo | 10000 | 3,744.51 μs | 237.331 μs | 156.980 μs |  2.96 |    0.12 | 625.0000 | 500.0000 | 250.0000 | 7581.23 KB |        2.48 |
