```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)sform [26]** | **1000**  |   **137.2 μs** |  **1.13 μs** |  **0.59 μs** |  **3.9063** |       **-** |  **81.26 KB** |
| BuilderLatestOnly | Skend(...)sform [26] | 1000  |   136.4 μs |  2.79 μs |  1.66 μs |  1.9531 |       - |  33.69 KB |
| **BuilderFull**       | **Skend(...)sform [26]** | **10000** | **1,330.4 μs** |  **5.44 μs** |  **2.84 μs** | **46.8750** | **23.4375** | **784.78 KB** |
| BuilderLatestOnly | Skend(...)sform [26] | 10000 | 1,320.8 μs | 46.61 μs | 30.83 μs | 15.6250 |  7.8125 |    315 KB |
