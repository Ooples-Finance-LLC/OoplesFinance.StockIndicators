```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error      | StdDev     | Median    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|-----------:|-----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)sform [26]** | **1000**  | **217.47 μs** | **252.302 μs** | **166.882 μs** |  **93.46 μs** |       **-** |       **-** |   **81.3 KB** |
| BuilderLatestOnly | Skend(...)sform [26] | 1000  |  82.51 μs |   1.168 μs |   0.695 μs |  82.28 μs |  1.9531 |       - |  33.69 KB |
| **BuilderFull**       | **Skend(...)sform [26]** | **10000** | **796.95 μs** |   **3.030 μs** |   **1.585 μs** | **797.26 μs** | **46.8750** | **23.4375** | **784.84 KB** |
| BuilderLatestOnly | Skend(...)sform [26] | 10000 | 788.11 μs |  18.122 μs |  11.986 μs | 781.95 μs | 15.6250 |  7.8125 | 314.97 KB |
