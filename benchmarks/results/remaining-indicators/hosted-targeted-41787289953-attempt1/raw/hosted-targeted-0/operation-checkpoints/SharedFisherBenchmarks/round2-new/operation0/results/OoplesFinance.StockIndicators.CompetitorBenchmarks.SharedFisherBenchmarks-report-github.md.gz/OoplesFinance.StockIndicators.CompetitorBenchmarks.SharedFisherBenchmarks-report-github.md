```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)sform [26]** | **1000**  |    **85.56 μs** |   **1.141 μs** |  **0.597 μs** |  **1.48** |    **0.04** |   **3.9063** |        **-** |        **-** |   **81.26 KB** |        **0.67** |
| BuilderLatestOnly | Skend(...)sform [26] | 1000  |    82.54 μs |   1.111 μs |  0.661 μs |  1.42 |    0.03 |   1.9531 |        - |        - |   33.69 KB |        0.28 |
| NativeSingle      | Skend(...)sform [26] | 1000  |    58.04 μs |   2.753 μs |  1.440 μs |  1.00 |    0.03 |   7.3242 |   0.9766 |        - |  121.54 KB |        1.00 |
| NativeParallel    | Skend(...)sform [26] | 1000  |   104.16 μs |   6.901 μs |  4.564 μs |  1.80 |    0.09 |  19.5313 |   3.9063 |        - |  312.72 KB |        2.57 |
|                   |                      |       |             |            |           |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skend(...)sform [26]** | **10000** |   **800.37 μs** |   **6.134 μs** |  **3.650 μs** |  **1.19** |    **0.01** |  **46.8750** |  **23.4375** |        **-** |  **784.79 KB** |        **0.65** |
| BuilderLatestOnly | Skend(...)sform [26] | 10000 |   772.26 μs |   5.866 μs |  3.068 μs |  1.15 |    0.01 |  15.6250 |   7.8125 |        - |  314.98 KB |        0.26 |
| NativeSingle      | Skend(...)sform [26] | 10000 |   670.09 μs |  10.816 μs |  6.436 μs |  1.00 |    0.01 | 136.7188 | 101.5625 |  82.0313 | 1212.07 KB |        1.00 |
| NativeParallel    | Skend(...)sform [26] | 10000 | 1,588.40 μs | 159.096 μs | 94.675 μs |  2.37 |    0.14 | 296.8750 | 250.0000 | 140.6250 |  3109.5 KB |        2.57 |
