```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)sform [26]** |   **156.06 μs** |  **4.667 μs** |  **3.087 μs** |  **1.00** |    **0.03** |  **163.31 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)sform [26] |    88.45 μs | 14.326 μs |  9.476 μs |  0.57 |    0.06 |  178.41 KB |        1.09 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)sform [26]** | **1,302.17 μs** | **21.950 μs** | **13.062 μs** |  **1.00** |    **0.01** | **1595.69 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)sform [26] |   785.21 μs | 16.146 μs |  9.608 μs |  0.60 |    0.01 | 1706.02 KB |        1.07 |
