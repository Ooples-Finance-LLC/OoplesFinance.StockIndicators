```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |-------------:|-----------:|-----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAdx** | **1000**  |  **1,064.54 μs** |  **23.841 μs** |  **14.188 μs** | **13.89** |    **0.22** |        **-** |        **-** |  **113.82 KB** |        **0.57** |
| BuilderLatestOnly | Skender.GetAdx | 1000  |  1,011.74 μs |   7.032 μs |   4.184 μs | 13.20 |    0.14 |        - |        - |   66.18 KB |        0.33 |
| NativeSingle      | Skender.GetAdx | 1000  |     76.63 μs |   1.225 μs |   0.810 μs |  1.00 |    0.01 |  12.2070 |   2.9297 |  199.68 KB |        1.00 |
| NativeParallel    | Skender.GetAdx | 1000  |    133.59 μs |   3.967 μs |   2.624 μs |  1.74 |    0.04 |  32.2266 |  10.7422 |  507.82 KB |        2.54 |
|                   |                |       |              |            |            |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetAdx** | **10000** | **10,127.26 μs** |  **96.021 μs** |  **63.512 μs** | **11.49** |    **0.11** |        **-** |        **-** | **1099.21 KB** |        **0.55** |
| BuilderLatestOnly | Skender.GetAdx | 10000 | 10,236.82 μs | 320.274 μs | 190.590 μs | 11.61 |    0.22 |        - |        - |  629.37 KB |        0.32 |
| NativeSingle      | Skender.GetAdx | 10000 |    881.83 μs |  13.739 μs |   7.186 μs |  1.00 |    0.01 | 117.1875 |  70.3125 |  1992.7 KB |        1.00 |
| NativeParallel    | Skender.GetAdx | 10000 |  1,494.93 μs |  82.711 μs |  54.708 μs |  1.70 |    0.06 | 312.5000 | 257.8125 | 5060.61 KB |        2.54 |
