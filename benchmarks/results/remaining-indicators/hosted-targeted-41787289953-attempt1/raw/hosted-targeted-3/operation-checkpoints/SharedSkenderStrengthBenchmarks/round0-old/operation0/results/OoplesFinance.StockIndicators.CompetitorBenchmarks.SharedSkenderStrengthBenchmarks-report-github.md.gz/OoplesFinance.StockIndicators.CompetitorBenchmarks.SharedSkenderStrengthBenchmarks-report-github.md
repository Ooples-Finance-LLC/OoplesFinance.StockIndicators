```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Allocated  |
|------------------ |--------------- |------ |----------:|----------:|----------:|-----------:|
| **BuilderFull**       | **Skender.GetAdx** | **1000**  |  **1.980 ms** | **0.0160 ms** | **0.0095 ms** |  **113.86 KB** |
| BuilderLatestOnly | Skender.GetAdx | 1000  |  1.299 ms | 0.0062 ms | 0.0041 ms |   66.18 KB |
| **BuilderFull**       | **Skender.GetAdx** | **10000** | **13.321 ms** | **0.0555 ms** | **0.0291 ms** | **1099.29 KB** |
| BuilderLatestOnly | Skender.GetAdx | 10000 | 13.261 ms | 0.0517 ms | 0.0271 ms |  629.47 KB |
