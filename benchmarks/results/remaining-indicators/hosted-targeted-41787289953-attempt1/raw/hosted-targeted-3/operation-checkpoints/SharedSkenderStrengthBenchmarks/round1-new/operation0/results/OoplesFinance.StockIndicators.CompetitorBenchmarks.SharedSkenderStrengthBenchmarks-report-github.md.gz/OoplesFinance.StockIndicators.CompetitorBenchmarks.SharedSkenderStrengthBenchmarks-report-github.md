```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Allocated  |
|------------------ |--------------- |------ |----------:|----------:|----------:|-----------:|
| **BuilderFull**       | **Skender.GetAdx** | **1000**  |  **1.053 ms** | **0.0069 ms** | **0.0036 ms** |  **113.83 KB** |
| BuilderLatestOnly | Skender.GetAdx | 1000  |  1.070 ms | 0.0075 ms | 0.0039 ms |   66.18 KB |
| **BuilderFull**       | **Skender.GetAdx** | **10000** | **10.232 ms** | **0.0462 ms** | **0.0275 ms** | **1099.24 KB** |
| BuilderLatestOnly | Skender.GetAdx | 10000 | 10.459 ms | 0.0508 ms | 0.0302 ms |  629.27 KB |
