```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAdx** |  **1,158.2 μs** | **37.36 μs** | **22.23 μs** |  **1.00** |    **0.03** |  **316.88 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAdx |    111.6 μs | 18.29 μs | 12.10 μs |  0.10 |    0.01 |  339.44 KB |        1.07 |
|            |       |                |             |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAdx** | **11,111.7 μs** | **70.35 μs** | **41.86 μs** |  **1.00** |    **0.01** | **3110.84 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAdx |  1,072.9 μs | 27.30 μs | 14.28 μs |  0.10 |    0.00 | 3301.35 KB |        1.06 |
