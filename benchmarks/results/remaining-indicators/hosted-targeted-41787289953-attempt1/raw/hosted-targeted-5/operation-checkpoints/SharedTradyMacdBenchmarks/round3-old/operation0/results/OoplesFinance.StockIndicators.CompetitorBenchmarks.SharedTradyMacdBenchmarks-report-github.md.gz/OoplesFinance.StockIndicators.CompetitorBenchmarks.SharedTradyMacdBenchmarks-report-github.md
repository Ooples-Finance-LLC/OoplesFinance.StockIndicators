```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |   **393.2 μs** |  **1.16 μs** |  **0.69 μs** |       **-** |  **73.63 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |   394.8 μs | 13.88 μs |  8.26 μs |       - |  26.05 KB |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** | **4,013.9 μs** | **88.09 μs** | **52.42 μs** | **31.2500** | **706.98 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 | 3,934.6 μs | 45.94 μs | 24.03 μs |       - | 237.23 KB |
