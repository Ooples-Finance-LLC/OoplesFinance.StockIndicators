```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |    **391.7 μs** |     **3.54 μs** |     **2.11 μs** |  **0.23** |    **0.00** |         **-** |         **-** |         **-** |    **73.62 KB** |       **0.022** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |    387.5 μs |     2.87 μs |     1.71 μs |  0.22 |    0.00 |         - |         - |         - |    26.06 KB |       0.008 |
| NativeSingle      | Movin(...)ogram [43] | 1000  |  1,732.7 μs |    29.17 μs |    17.36 μs |  1.00 |    0.01 |  203.1250 |  109.3750 |   46.8750 |  3389.04 KB |       1.000 |
| NativeParallel    | Movin(...)ogram [43] | 1000  |  1,515.4 μs |    70.75 μs |    46.80 μs |  0.87 |    0.03 |  359.3750 |  179.6875 |         - |  5597.43 KB |       1.652 |
|                   |                      |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** |  **3,951.6 μs** |    **22.50 μs** |    **13.39 μs** |  **0.21** |    **0.01** |   **31.2500** |         **-** |         **-** |   **706.95 KB** |       **0.021** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 |  4,005.6 μs |    35.28 μs |    20.99 μs |  0.21 |    0.01 |         - |         - |         - |   237.17 KB |       0.007 |
| NativeSingle      | Movin(...)ogram [43] | 10000 | 18,793.6 μs | 1,907.11 μs | 1,134.89 μs |  1.00 |    0.08 | 2000.0000 | 1400.0000 | 1000.0000 | 33358.36 KB |       1.000 |
| NativeParallel    | Movin(...)ogram [43] | 10000 | 19,382.6 μs | 2,190.89 μs | 1,303.76 μs |  1.03 |    0.09 | 3333.3333 | 2500.0000 | 1500.0000 | 55282.66 KB |       1.657 |
