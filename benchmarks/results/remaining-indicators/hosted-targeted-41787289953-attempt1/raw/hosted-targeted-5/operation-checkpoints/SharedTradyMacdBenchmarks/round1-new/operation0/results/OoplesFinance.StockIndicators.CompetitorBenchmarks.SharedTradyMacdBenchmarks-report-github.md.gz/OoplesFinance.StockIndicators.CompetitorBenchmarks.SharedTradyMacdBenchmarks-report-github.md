```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |   **392.0 μs** |  **2.07 μs** |  **1.08 μs** |       **-** |  **73.65 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |   389.2 μs |  1.19 μs |  0.62 μs |       - |  26.06 KB |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** | **4,023.2 μs** | **10.54 μs** |  **5.51 μs** | **31.2500** | **707.03 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 | 3,926.2 μs | 17.46 μs | 10.39 μs |       - | 237.17 KB |
