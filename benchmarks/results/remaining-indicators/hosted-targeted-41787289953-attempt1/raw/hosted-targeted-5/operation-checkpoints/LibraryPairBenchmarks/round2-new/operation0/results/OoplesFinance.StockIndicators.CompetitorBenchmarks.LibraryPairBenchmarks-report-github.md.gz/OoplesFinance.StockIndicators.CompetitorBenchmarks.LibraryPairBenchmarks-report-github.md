```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)ogram [59]** |    **485.1 μs** |   **5.43 μs** |   **2.84 μs** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |   **240.74 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)ogram [59] |  1,970.1 μs |  30.29 μs |  20.04 μs |  4.06 |    0.05 |         - |         - |         - |  3697.05 KB |       15.36 |
|            |       |                      |             |           |           |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)ogram [59]** |  **4,743.2 μs** |  **33.52 μs** |  **19.95 μs** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |  **2365.75 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)ogram [59] | 23,045.8 μs | 725.47 μs | 431.71 μs |  4.86 |    0.09 | 2000.0000 | 1000.0000 | 1000.0000 | 36351.48 KB |       15.37 |
