```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |-----------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **Ad**        | **1000**  | **106.194 μs** | **2.4503 μs** | **1.2816 μs** | **56.95** |    **0.86** |  **3.9063** |      **-** |  **64.88 KB** |        **8.24** |
| BuilderLatestOnly | Ad        | 1000  |  99.915 μs | 0.2879 μs | 0.1506 μs | 53.59 |    0.54 |  0.9766 |      - |  17.27 KB |        2.19 |
| NativeSingle      | Ad        | 1000  |   1.865 μs | 0.0327 μs | 0.0195 μs |  1.00 |    0.01 |  0.4730 |      - |   7.88 KB |        1.00 |
| NativeParallel    | Ad        | 1000  |  77.266 μs | 0.7920 μs | 0.5239 μs | 41.44 |    0.49 |  0.4883 |      - |   8.17 KB |        1.04 |
|                   |           |       |            |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **Ad**        | **10000** | **972.027 μs** | **8.4768 μs** | **5.0444 μs** | **58.35** |    **0.58** | **31.2500** | **7.8125** | **627.77 KB** |        **8.03** |
| BuilderLatestOnly | Ad        | 10000 | 949.402 μs | 3.1126 μs | 1.6279 μs | 57.00 |    0.50 |  7.8125 |      - | 157.94 KB |        2.02 |
| NativeSingle      | Ad        | 10000 |  16.659 μs | 0.2556 μs | 0.1521 μs |  1.00 |    0.01 |  4.7607 | 0.8545 |  78.19 KB |        1.00 |
| NativeParallel    | Ad        | 10000 |  96.090 μs | 5.0235 μs | 3.3227 μs |  5.77 |    0.20 |  4.3945 | 0.4883 |  78.48 KB |        1.00 |
