```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean         | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |------------------- |-------------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ad** |   **148.867 μs** | **13.7339 μs** |  **8.1728 μs** |  **1.00** |    **0.08** | **140.75 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ad |     3.275 μs |  0.4655 μs |  0.2435 μs |  0.02 |    0.00 |   9.79 KB |        0.07 |
|            |       |                    |              |            |            |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ad** | **1,286.963 μs** | **19.9205 μs** | **10.4188 μs** |  **1.00** |    **0.01** |   **1713 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ad |    17.550 μs |  0.7227 μs |  0.3780 μs |  0.01 |    0.00 |  84.04 KB |        0.05 |
