```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId             | Mean       | Error    | StdDev   | Ratio | Allocated  | Alloc Ratio |
|------- |------ |------------------- |-----------:|---------:|---------:|------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Ad** |   **129.6 μs** |  **2.06 μs** |  **1.22 μs** |  **1.00** |  **140.75 KB** |        **1.00** |
|        |       |                    |            |          |          |       |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Ad** | **1,282.0 μs** | **18.90 μs** | **11.24 μs** |  **1.00** | **1714.64 KB** |        **1.00** |
