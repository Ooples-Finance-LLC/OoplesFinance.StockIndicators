from pathlib import Path
import copy,datetime,hashlib,html,json,re,subprocess
ROOT=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
REPO=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
RUN='39740772688';CONTROL='39738942544';SOURCE='0e62018ed67b73a18cd94c6320af6d0612a78af7'
PAIRS={'QuanTAlib.Dema','QuanTAlib.Tema'}
live=Path('C:/Users/cheat/Documents/OoplesFinance-Reports/competitor-performance.html')
out=live.parent/('tema-refresh-'+RUN);out.mkdir(exist_ok=True);assert not (out/'before.html').exists() or (out/'before.html').read_bytes()==live.read_bytes()
original=live.read_bytes();s=original.decode('utf-8')
def embedded(name):return json.loads(re.search(r'<script[^>]*id="'+name+r'"[^>]*>(.*?)</script>',s,re.S)[1])
def replace(name,value):
 global s
 s,n=re.subn(r'(<script[^>]*id="'+name+r'"[^>]*>).*?(</script>)',lambda m:m[1]+json.dumps(value,ensure_ascii=True).replace('<','\\u003c')+m[2],s,flags=re.S);assert n==1
data=embedded('dataset');before=copy.deepcopy(data);builder=embedded('current-competitor-data');oldbuilder=copy.deepcopy(builder);status=embedded('rollout-status-data')
rawdir=ROOT/('tema-library-refresh-'+RUN);verification=json.loads((rawdir/'verified-summary.json').read_text());assert verification['all_8_cases_verified']
d=json.loads((rawdir/'comparison.json').read_text());assert d['complete'] and d['order']==['new'];receipt=d['rounds'][0];assert receipt['source_sha']==SOURCE
raw=(rawdir/Path(receipt['report_file']).relative_to('control')).read_bytes();assert hashlib.sha256(raw).hexdigest()==receipt['report_sha256'];report=json.loads(raw)
url='https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/'+RUN
for row in data['rows']:
 if row['pair'] not in PAIRS:continue
 for method,arm in [('Ooples','ooples'),('Competitor','competitor')]:
  cases=[c for c in report['Benchmarks'] if c['Method']==method and f'Bars: {row["bars"]},' in c['FullName'] and f'PairId: "{row["pair"]}"' in c['FullName']];assert len(cases)==1
  c=cases[0];stats=c['Statistics'];row.update({arm+'_mean_ns':stats['Mean'],arm+'_stddev_ns':stats['StandardDeviation'],arm+'_samples':stats['N'],arm+'_allocated_bytes':c['Memory']['BytesAllocatedPerOperation']})
  row['raw'][method]={'samples':stats['OriginalValues'],'host':report['HostEnvironmentInfo'],'report':receipt['report_file'],'confidence_interval':stats['ConfidenceInterval']}
 row.update(competitor_over_ooples=row['competitor_mean_ns']/row['ooples_mean_ns'],source_sha=SOURCE,measurement_run_url=url)
for pair in sorted(PAIRS):data['evidence']['rowOverrides'].append({'pair':pair,'sourceSha':SOURCE,'runUrl':url,'reportSha256':receipt['report_sha256'],'round':0,'selection':'Single qualified candidate measurement of actual LibraryPair delegates; builder timings are separate.'})
assert sum(a==b for a,b in zip(before['rows'],data['rows'],strict=True))==798
replace('dataset',data)
# Replace only the eight DEMA/TEMA builder slots, selecting the final candidate round.
rawdir=ROOT/('tema-factored-control-'+CONTROL);v=json.loads((rawdir/'verified-summary.json').read_text());assert v['all_64_cases_verified']
d=json.loads((rawdir/'comparison.json').read_text());receipt=d['rounds'][2];assert receipt['version']=='new' and receipt['source_sha']==SOURCE
raw=(rawdir/Path(receipt['report_file']).relative_to('control')).read_bytes();assert hashlib.sha256(raw).hexdigest()==receipt['report_sha256']
cases={(r['pair'],r['bars'],r['method']):r for r in receipt['rows']}
def stats(r):return {k:r[k] for k in ['mean_ns','lower_ns','upper_ns','samples','allocated_bytes']}
comparisons=[]
for pair in sorted(PAIRS):
 for bars in [1000,10000]:
  native={m:stats(cases[pair,bars,m]) for m in ['NativeSingle','NativeParallel']}
  for mode in ['BuilderFull','BuilderLatestOnly']:
   ours=stats(cases[pair,bars,mode]);verdict='faster' if ours['upper_ns']<min(n['lower_ns'] for n in native.values()) else 'slower' if ours['lower_ns']>min(n['upper_ns'] for n in native.values()) else 'inconclusive'
   comparisons.append({'pair':pair,'bars':bars,'mode':mode,'ooples':ours,'native':native,'fastest_native':min(native,key=lambda m:native[m]['mean_ns']),'verdict':verdict})
replaced=0
for r in builder['receipts']:
 keep=[c for c in r['comparisons'] if c['pair'] not in PAIRS];replaced+=len(r['comparisons'])-len(keep);r['comparisons']=keep
assert replaced==8
builder['receipts'].append({'fixture':'SharedNativeEmaBenchmarks','source_sha':SOURCE,'run_id':CONTROL,'workflow_sha':d['workflow_sha'],'round':2,'report_file':receipt['report_file'],'report_sha256':receipt['report_sha256'],'selection':'Chronologically final candidate round, not fastest.','complete':True,'comparisons':comparisons})
rows=[{**c,'run_id':str(r['run_id']),'source_sha':r['source_sha']} for r in builder['receipts'] for c in r['comparisons']]
assert len(rows)==builder['full_comparisons'] and len({(r['pair'],r['bars'],r['mode']) for r in rows})==len(rows)
counts={v:sum(r['verdict']==v for r in rows) for v in ['faster','slower','inconclusive']};builder['verdicts']=counts;builder['status'].update(commit=SOURCE,updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());replace('current-competitor-data',builder)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip();oldhead=status['published_head'];oldcounts=status['measurement_totals'].copy()
status.update(published_head=head,inventory_commit=head,row_overrides=data['evidence']['rowOverrides'],changed_production_files=['src/Helpers/CertifiedMeanRelativeError.cs','src/Indicators/CompensatedExponentialAverage.cs'],inventory_sha256=hashlib.sha256((REPO/'benchmarks/results/remaining-indicators/inventory.json').read_bytes()).hexdigest())
status['measurement_totals'].update(counts);status['builder_measurement_sources'].append({'source_sha':SOURCE,'run_url':'https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/'+CONTROL,'comparisons':8,'replaces_pairs':sorted(PAIRS),'round':2});replace('rollout-status-data',status)
base=data['evidence']['baseSourceSha'];sma=data['evidence']['rowOverrides'][0]['sourceSha'];label=f'Measured builds: {base[:8]} (796 comparisons), {sma[:8]} (two SMA comparisons), {SOURCE[:8]} (four DEMA/TEMA comparisons).'
s=re.sub(r'Measured builds: [^<]*?\.',lambda _:label,s)
oldwins=sum(r['competitor_over_ooples']>1 for r in before['rows'] if r['bars']==10000);wins=sum(r['competitor_over_ooples']>1 for r in data['rows'] if r['bars']==10000)
s=s.replace(f'{oldwins} / 401 APIs at 10,000 bars',f'{wins} / 401 APIs at 10,000 bars')
s=s.replace('The full run predates the SMA change. The two SMA rows use the latest candidate round from e4c3cbf1; the other 800 retain the complete baseline run.','The full run supplies 796 comparisons. Two SMA rows and four DEMA/TEMA rows use separately qualified measurements with per-row source and run links.')
s=s.replace('SMA override:', 'SMA and DEMA/TEMA overrides:').replace('The SMA override retains','The SMA and DEMA/TEMA overrides retain')
s=s.replace('published <code>'+oldhead[:8]+'</code>','published <code>'+head[:8]+'</code>')
old=f"Builder-mode timing: {oldcounts['faster']} faster, {oldcounts['slower']} slower, {oldcounts['inconclusive']} inconclusive, and {oldcounts['pending']} pending."
new=f"Builder-mode timing: {counts['faster']} faster, {counts['slower']} slower, {counts['inconclusive']} inconclusive, and {oldcounts['pending']} pending."
assert old in s;s=s.replace(old,new)
body=[]
for r in sorted(rows,key=lambda r:(r['pair'],r['bars'],r['mode'])):
 values=[r['pair'],f"{r['bars']:,}",'Full history' if r['mode']=='BuilderFull' else 'Latest only',f"{r['ooples']['mean_ns']/1e6:.6f}",f"{r['native']['NativeSingle']['mean_ns']/1e6:.6f}",f"{r['native']['NativeParallel']['mean_ns']/1e6:.6f}",{'faster':'Faster than both','slower':'Slower than at least one','inconclusive':'Inconclusive'}[r['verdict']]]
 body.append('<tr data-builder-pair="'+html.escape(r['pair'],quote=True)+'" data-bars="'+str(r['bars'])+'" data-mode="'+r['mode']+'">'+''.join('<td>'+html.escape(x)+'</td>' for x in values)+'<td><a href="https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/'+r['run_id']+'">'+r['run_id']+'</a></td></tr>')
s,n=re.subn(r'(<table id="builder-current-results">.*?<tbody>).*?(</tbody>)',lambda m:m[1]+''.join(body)+m[2],s,flags=re.S);assert n==1
s=s.replace(f": {oldcounts['faster']} faster, {oldcounts['slower']} slower, {oldcounts['inconclusive']} inconclusive, {oldcounts['pending']} pending.",f": {counts['faster']} faster, {counts['slower']} slower, {counts['inconclusive']} inconclusive, {oldcounts['pending']} pending.")
s=s.replace('Relevant implementations and fixtures match published code; the later SMA error-diagnostics change is separate.','DEMA/TEMA use qualified source '+SOURCE+' and the final candidate round of control '+CONTROL+'. Other builder rows retain their original source; the SMA diagnostics change is separate.')
source_html=f'<p>796 comparisons: <code>{base}</code>, full run 39719116665. Two SMA comparisons: <code>{sma}</code>, final candidate round of 39727929133. Four DEMA/TEMA comparisons: <code>{SOURCE}</code>, <a href="{url}">actual LibraryPair measurement</a>. Per-row details and CSV contain each measurement source and run.</p>'
s,n=re.subn(r"\$\('source'\)\.innerHTML=[^\r\n]*;",lambda _:"$('source').innerHTML="+json.dumps(source_html)+';',s,count=1,flags=re.M);assert n==1
assert embedded('archived-baseline-dataset')==json.loads(re.search(r'<script[^>]*id="archived-baseline-dataset"[^>]*>(.*?)</script>',original.decode('utf-8'),re.S)[1])
(out/'before.html').write_bytes(original);(out/'candidate.html').write_text(s,encoding='utf-8')
(out/'measurement.json').write_text(json.dumps({'source_sha':SOURCE,'run_id':RUN}),encoding='utf-8')
(out/'staged.json').write_text(json.dumps({'before_sha256':hashlib.sha256(original).hexdigest(),'candidate_sha256':hashlib.sha256((out/'candidate.html').read_bytes()).hexdigest(),'changed_baseline_rows':4,'unchanged_baseline_rows':798,'changed_builder_slots':8,'builder_rows':rows,'verdicts':counts},indent=2),encoding='utf-8')
print('Staged actual four baseline rows and eight builder slots',counts)
