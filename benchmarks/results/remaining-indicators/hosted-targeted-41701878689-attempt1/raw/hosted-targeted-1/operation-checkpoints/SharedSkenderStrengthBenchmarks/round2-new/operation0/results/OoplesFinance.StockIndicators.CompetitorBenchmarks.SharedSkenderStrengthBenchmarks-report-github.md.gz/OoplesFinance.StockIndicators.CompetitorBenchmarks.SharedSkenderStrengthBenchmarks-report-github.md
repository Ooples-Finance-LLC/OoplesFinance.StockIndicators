```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean         | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |-------------:|-----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAdx** | **1000**  |  **1,844.46 μs** |  **11.066 μs** |  **6.585 μs** | **22.93** |    **0.32** |        **-** |        **-** |  **113.86 KB** |        **0.57** |
| BuilderLatestOnly | Skender.GetAdx | 1000  |  1,302.37 μs |  10.002 μs |  5.952 μs | 16.19 |    0.23 |        - |        - |   66.18 KB |        0.33 |
| NativeSingle      | Skender.GetAdx | 1000  |     80.44 μs |   2.142 μs |  1.120 μs |  1.00 |    0.02 |  12.2070 |   2.9297 |  199.67 KB |        1.00 |
| NativeParallel    | Skender.GetAdx | 1000  |    140.23 μs |  13.790 μs |  9.121 μs |  1.74 |    0.11 |  32.2266 |  10.7422 |  507.82 KB |        2.54 |
|                   |                |       |              |            |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetAdx** | **10000** | **13,314.58 μs** |  **72.268 μs** | **47.801 μs** | **14.46** |    **0.19** |        **-** |        **-** | **1099.41 KB** |        **0.55** |
| BuilderLatestOnly | Skender.GetAdx | 10000 | 13,337.03 μs | 107.628 μs | 56.291 μs | 14.49 |    0.20 |        - |        - |  629.59 KB |        0.32 |
| NativeSingle      | Skender.GetAdx | 10000 |    920.84 μs |  21.157 μs | 12.590 μs |  1.00 |    0.02 | 117.1875 |  70.3125 |  1992.7 KB |        1.00 |
| NativeParallel    | Skender.GetAdx | 10000 |  1,558.54 μs |  89.076 μs | 58.918 μs |  1.69 |    0.06 | 312.5000 | 257.8125 | 5060.61 KB |        2.54 |
