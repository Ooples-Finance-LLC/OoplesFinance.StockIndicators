```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Allocated  |
|------------------ |--------------- |------ |----------:|----------:|----------:|-----------:|
| **BuilderFull**       | **Skender.GetAdx** | **1000**  |  **2.392 ms** | **0.0451 ms** | **0.0299 ms** |  **113.86 KB** |
| BuilderLatestOnly | Skender.GetAdx | 1000  |  1.364 ms | 0.0062 ms | 0.0037 ms |   66.18 KB |
| **BuilderFull**       | **Skender.GetAdx** | **10000** | **13.679 ms** | **0.1115 ms** | **0.0583 ms** | **1099.49 KB** |
| BuilderLatestOnly | Skender.GetAdx | 10000 | 13.749 ms | 0.0584 ms | 0.0386 ms |  629.64 KB |
