```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Allocated  |
|------------------ |--------------- |------ |----------:|----------:|----------:|-----------:|
| **BuilderFull**       | **Skender.GetAdx** | **1000**  |  **2.344 ms** | **0.0178 ms** | **0.0106 ms** |  **113.86 KB** |
| BuilderLatestOnly | Skender.GetAdx | 1000  |  1.385 ms | 0.0068 ms | 0.0035 ms |   66.18 KB |
| **BuilderFull**       | **Skender.GetAdx** | **10000** | **13.932 ms** | **0.1036 ms** | **0.0617 ms** | **1099.49 KB** |
| BuilderLatestOnly | Skender.GetAdx | 10000 | 14.066 ms | 0.1694 ms | 0.1121 ms |  629.63 KB |
