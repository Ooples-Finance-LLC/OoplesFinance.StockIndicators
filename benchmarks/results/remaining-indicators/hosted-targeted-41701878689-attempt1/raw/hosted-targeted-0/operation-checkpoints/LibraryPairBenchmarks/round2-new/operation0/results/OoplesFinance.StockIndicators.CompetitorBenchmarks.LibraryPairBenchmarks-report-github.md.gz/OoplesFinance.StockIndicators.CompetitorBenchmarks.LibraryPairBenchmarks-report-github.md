```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAdx** |  **1,434.1 μs** | **29.38 μs** | **17.49 μs** |  **1.00** |    **0.02** |  **316.88 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAdx |    126.3 μs | 46.25 μs | 30.59 μs |  0.09 |    0.02 |  338.78 KB |        1.07 |
|            |       |                |             |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAdx** | **14,420.3 μs** | **67.44 μs** | **40.13 μs** |  **1.00** |    **0.00** | **3110.56 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAdx |  1,106.9 μs | 78.37 μs | 51.84 μs |  0.08 |    0.00 |  3301.4 KB |        1.06 |
