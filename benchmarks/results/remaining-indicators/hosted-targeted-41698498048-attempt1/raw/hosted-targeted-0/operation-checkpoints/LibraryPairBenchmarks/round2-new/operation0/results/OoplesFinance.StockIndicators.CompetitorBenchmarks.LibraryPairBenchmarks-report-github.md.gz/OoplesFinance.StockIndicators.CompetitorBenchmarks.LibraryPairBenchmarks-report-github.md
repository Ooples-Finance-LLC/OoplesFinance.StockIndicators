```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId           | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |----------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetStoch** |   **334.0 μs** |  **16.78 μs** |  **9.98 μs** |  **1.00** |    **0.04** |  **214.16 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetStoch |   171.9 μs |   9.97 μs |  5.93 μs |  0.52 |    0.02 |  273.91 KB |        1.28 |
|            |       |                  |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetStoch** | **3,155.1 μs** | **102.62 μs** | **61.07 μs** |  **1.00** |    **0.03** | **2077.14 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetStoch | 1,788.3 μs |  39.15 μs | 23.30 μs |  0.57 |    0.01 | 2655.74 KB |        1.28 |
