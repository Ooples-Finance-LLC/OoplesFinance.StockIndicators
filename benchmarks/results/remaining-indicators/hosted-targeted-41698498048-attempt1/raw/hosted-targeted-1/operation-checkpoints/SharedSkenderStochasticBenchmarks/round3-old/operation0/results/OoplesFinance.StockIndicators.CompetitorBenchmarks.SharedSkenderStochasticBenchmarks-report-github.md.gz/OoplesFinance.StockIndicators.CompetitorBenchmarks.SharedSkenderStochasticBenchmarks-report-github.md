```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean      | Error     | StdDev    | Gen0     | Allocated |
|------------------ |----------------- |------ |----------:|----------:|----------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetStoch** | **1000**  |  **1.998 ms** | **0.7175 ms** | **0.4746 ms** |        **-** |   **1.44 MB** |
| BuilderLatestOnly | Skender.GetStoch | 1000  |  1.449 ms | 0.1015 ms | 0.0604 ms |  15.6250 |   1.39 MB |
| **BuilderFull**       | **Skender.GetStoch** | **10000** | **16.018 ms** | **1.6606 ms** | **1.0984 ms** | **142.8571** |  **14.49 MB** |
| BuilderLatestOnly | Skender.GetStoch | 10000 | 15.736 ms | 2.4590 ms | 1.6265 ms | 142.8571 |  14.03 MB |
