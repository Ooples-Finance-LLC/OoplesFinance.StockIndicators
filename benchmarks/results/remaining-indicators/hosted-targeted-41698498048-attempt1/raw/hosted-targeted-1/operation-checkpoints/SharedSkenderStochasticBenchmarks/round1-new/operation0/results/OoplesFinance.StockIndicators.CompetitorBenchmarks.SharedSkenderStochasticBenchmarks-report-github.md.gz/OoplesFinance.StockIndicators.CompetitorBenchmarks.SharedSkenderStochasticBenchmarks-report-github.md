```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |----------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Skender.GetStoch** | **1000**  |   **285.7 μs** |  **86.10 μs** |  **56.95 μs** |  **95.56 KB** |
| BuilderLatestOnly | Skender.GetStoch | 1000  |   231.1 μs |  17.38 μs |  10.34 μs |  47.96 KB |
| **BuilderFull**       | **Skender.GetStoch** | **10000** | **2,455.7 μs** | **172.44 μs** | **114.06 μs** | **869.44 KB** |
| BuilderLatestOnly | Skender.GetStoch | 10000 | 2,309.3 μs |  34.50 μs |  18.05 μs | 399.71 KB |
