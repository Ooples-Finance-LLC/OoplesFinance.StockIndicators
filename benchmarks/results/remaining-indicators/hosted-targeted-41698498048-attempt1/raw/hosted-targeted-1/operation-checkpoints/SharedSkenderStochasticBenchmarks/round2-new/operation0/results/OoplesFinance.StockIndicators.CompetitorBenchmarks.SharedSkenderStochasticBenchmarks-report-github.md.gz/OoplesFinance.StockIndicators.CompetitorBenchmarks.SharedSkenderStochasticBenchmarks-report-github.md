```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Gen2    | Allocated  | Alloc Ratio |
|------------------ |----------------- |------ |-----------:|----------:|----------:|------:|--------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetStoch** | **1000**  |   **259.2 μs** |  **67.07 μs** |  **39.91 μs** |  **1.88** |    **0.27** |       **-** |       **-** |       **-** |    **95.6 KB** |        **0.52** |
| BuilderLatestOnly | Skender.GetStoch | 1000  |   240.9 μs |  29.20 μs |  19.31 μs |  1.75 |    0.13 |       - |       - |       - |   47.96 KB |        0.26 |
| NativeSingle      | Skender.GetStoch | 1000  |   138.1 μs |   1.50 μs |   0.89 μs |  1.00 |    0.01 |  1.9531 |       - |       - |  184.08 KB |        1.00 |
| NativeParallel    | Skender.GetStoch | 1000  |   103.6 μs |   1.31 μs |   0.86 μs |  0.75 |    0.01 |  1.9531 |       - |       - |  202.84 KB |        1.10 |
|                   |                  |       |            |           |           |       |         |         |         |         |            |             |
| **BuilderFull**       | **Skender.GetStoch** | **10000** | **2,500.8 μs** | **259.31 μs** | **171.52 μs** |  **1.26** |    **0.08** |       **-** |       **-** |       **-** |   **869.4 KB** |        **0.47** |
| BuilderLatestOnly | Skender.GetStoch | 10000 | 2,392.9 μs | 165.86 μs | 109.71 μs |  1.20 |    0.05 |       - |       - |       - |  399.62 KB |        0.22 |
| NativeSingle      | Skender.GetStoch | 10000 | 1,991.4 μs |  36.73 μs |  21.86 μs |  1.00 |    0.01 | 46.8750 | 46.8750 | 46.8750 | 1836.88 KB |        1.00 |
| NativeParallel    | Skender.GetStoch | 10000 |   937.3 μs |  73.62 μs |  48.69 μs |  0.47 |    0.02 | 23.4375 | 15.6250 |       - | 1925.55 KB |        1.05 |
