```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean      | Error     | StdDev    | Gen0     | Allocated |
|------------------ |----------------- |------ |----------:|----------:|----------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetStoch** | **1000**  |  **1.581 ms** | **0.3439 ms** | **0.2275 ms** |        **-** |   **1.44 MB** |
| BuilderLatestOnly | Skender.GetStoch | 1000  |  1.437 ms | 0.0809 ms | 0.0423 ms |  15.6250 |   1.39 MB |
| **BuilderFull**       | **Skender.GetStoch** | **10000** | **15.641 ms** | **1.0879 ms** | **0.6474 ms** | **142.8571** |  **14.49 MB** |
| BuilderLatestOnly | Skender.GetStoch | 10000 | 15.567 ms | 2.4265 ms | 1.6050 ms | 142.8571 |  14.03 MB |
