"""Verify CI build inputs, install changed binaries, and execute actual local GPU contracts."""
import argparse
import gzip
import hashlib
import importlib.util
import io
import json
import platform
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import zipfile

parser=argparse.ArgumentParser()
for name in ('repo','tooling','out'): parser.add_argument('--'+name,type=Path,required=True)
for name in ('run','tooling-ref','source','unit','parity'): parser.add_argument('--'+name,required=True)
parser.add_argument('--dotnet-sdk',type=Path)
a=parser.parse_args();repo=a.repo.resolve();out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
dotnet=['dotnet']
if a.dotnet_sdk:
    sdk=a.dotnet_sdk.resolve();assert sdk.name=='dotnet.dll' and sdk.is_file()
    dotnet+=['exec',str(sdk)]
def gh(*args):return subprocess.check_output(['gh',*args],cwd=repo)
state=json.loads(gh('run','view',a.run,'--json','status,conclusion,headSha'))
assert state==dict(status='completed',conclusion='success',headSha=a.tooling_ref)
helper=a.tooling.resolve()/'scripts/build-candidate-correctness.py'
assert helper.read_bytes().replace(b'\r\n',b'\n')==subprocess.check_output(['git','show',a.tooling_ref+':scripts/build-candidate-correctness.py'],cwd=repo)
spec=importlib.util.spec_from_file_location('ci_inputs',helper);ci=importlib.util.module_from_spec(spec);spec.loader.exec_module(ci)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==a.source
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
gpu=ci.gpu_module(repo);fingerprint=gpu.source_fingerprint(repo)
artifacts=json.loads(gh('api',f'repos/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/{a.run}/artifacts'))['artifacts']
artifacts=[x for x in artifacts if x['name']=='candidate-correctness-inputs' and not x['expired']]
assert len(artifacts)==1;artifact=artifacts[0]
raw=gh('api',f"repos/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/artifacts/{artifact['id']}/zip")
with zipfile.ZipFile(io.BytesIO(raw)) as package:
    names=[n for n in package.namelist() if n=='manifest.json' or n.endswith('/manifest.json')]
    assert len(names)==1;prefix=names[0][:-len('manifest.json')]
    read=lambda name:package.read(prefix+name)
    manifest=json.loads(read('manifest.json'))
    assert manifest['workflow_head']==a.tooling_ref and manifest['run_id']==a.run
    assert manifest['classes']==dict(unit=a.unit.split(','),parity=a.parity.split(','))
    ci.validate_layout(manifest,read,a.source,fingerprint)
    for name,sha in manifest['runtime_files'].items():
        target=(repo/name).resolve();assert target.is_relative_to(repo)
        if target.is_file() and ci.digest(target)==sha:continue
        target.parent.mkdir(parents=True,exist_ok=True)
        temporary=target.with_name(target.name+'.ci-input.tmp')
        temporary.write_bytes(read('blobs/'+sha));assert ci.digest(temporary)==sha
        temporary.replace(target)
    assert all(ci.digest(repo/name)==sha for name,sha in manifest['runtime_files'].items())
    for name in manifest['evidence']:
        target=out/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(read(name))
(out/'ci-manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
sys.path.insert(0,str(a.tooling/'scripts'));from hosted_timing.pipeline import verify_trx
checks={}
for name in ('unit','parity'):
    folder=out/name;folder.mkdir(exist_ok=True);target=folder/(name+'.trx')
    shutil.copyfile(out/'evidence'/(name+'.trx'),target)
    checks[name]=verify_trx(target,manifest['classes'][name]);assert checks[name]==manifest['checks'][name]
shutil.copyfile(out/'evidence/unit-build.log',out/'build-unit.log')
build_origin=dict(run_id=a.run,workflow_head=a.tooling_ref,source=a.source,artifact_id=artifact['id'],
    url='https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/'+a.run)
methods=json.loads(gpu.METHODS.read_text());dll=repo/gpu.PROJECT/'bin/Release/net10.0/OoplesFinance.StockIndicators.CompetitorTests.dll'
with tempfile.TemporaryDirectory(prefix='si-ci-built-gpu-') as folder:
    directory=Path(folder);settings=directory/'serial.runsettings'
    settings.write_text('<RunSettings><RunConfiguration><MaxCpuCount>1</MaxCpuCount></RunConfiguration><xUnit><ParallelizeTestCollections>false</ParallelizeTestCollections><MaxParallelThreads>1</MaxParallelThreads></xUnit></RunSettings>')
    with (out/'build-and-gpu.log').open('wb') as log:
        log.write(b'Comparator build below ran in the pinned CI job; actual GPU invocation follows locally.\n')
        log.write((out/'evidence/comparator-build.log').read_bytes());log.flush()
        subprocess.run([*dotnet,'vstest',str(dll),'/Settings:'+str(settings),'/TestCaseFilter:'+'|'.join('FullyQualifiedName='+m for m in methods),'/Logger:trx;LogFileName=gpu.trx','/ResultsDirectory:'+str(directory)],cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
    trx=(directory/'gpu.trx').read_bytes();count=gpu.contracts.verify_trx(directory/'gpu.trx',methods);assert count==100
assert gpu.source_fingerprint(repo)==fingerprint
assert all(ci.digest(repo/root/ci.DLL)==manifest['runtime_files'][root+'/'+ci.DLL] for root in ci.ROOTS)
receipt=dict(source_sha256=fingerprint,methods=methods,passed_cases=count,trx_sha256=hashlib.sha256(trx).hexdigest(),host=platform.platform(),device='Radeon RX 5500 XT; RequiredGPU fixtures; CI-built verified binaries',dotnet_info=subprocess.check_output([*dotnet,'--info']).decode(),test_assembly_sha256=ci.digest(dll),build_origin=build_origin,note='Actual local RequiredGPU execution using source-bound CI build; correctness evidence, not timing.')
if a.dotnet_sdk:receipt['local_dotnet_launcher']=dotnet
gpu.verify_evidence(receipt,trx,methods,fingerprint)
# Preserve completed actual-GPU evidence on the verification output volume before exporting to the source checkout.
(out/'actual-local-gpu.trx.gz').write_bytes(gzip.compress(trx,mtime=0))
(out/'actual-local-gpu-receipt.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
gpu.EVIDENCE.mkdir(parents=True,exist_ok=True)
(gpu.EVIDENCE/'gpu.trx.gz').write_bytes(gzip.compress(trx,mtime=0))
(gpu.EVIDENCE/'receipt.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
status=dict(source=a.source,repo=str(repo),status='correctness-complete',active=None,unit=checks['unit'],parity=checks['parity'],build_origin=build_origin,compiler_process_isolation=True,dependency_copy_mode='Verified immutable CI artifacts; changed binaries installed without local compilation',steps={name:dict(exit_code=0,location='CI' if name!='build-and-gpu' else 'CI build and actual local GPU') for name in ('build-unit','build-and-gpu','unit','parity')})
(out/'status.json').write_bytes((json.dumps(status,indent=2)+'\n').encode());print(json.dumps(status))
