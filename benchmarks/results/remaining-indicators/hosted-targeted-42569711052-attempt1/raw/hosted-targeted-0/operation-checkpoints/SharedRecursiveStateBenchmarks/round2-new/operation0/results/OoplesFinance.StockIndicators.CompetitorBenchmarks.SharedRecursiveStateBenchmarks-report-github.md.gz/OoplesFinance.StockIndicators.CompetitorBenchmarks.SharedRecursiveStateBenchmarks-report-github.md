```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **134.625 μs** |  **3.0631 μs** |  **1.8228 μs** | **53.76** |    **1.79** |  **3.9063** |      **-** |  **64.88 KB** |        **8.24** |
| BuilderLatestOnly | Ad        | 1000  |   135.464 μs |  1.1562 μs |  0.6880 μs | 54.10 |    1.68 |  0.9766 |      - |  17.27 KB |        2.19 |
| NativeSingle      | Ad        | 1000  |     2.506 μs |  0.1236 μs |  0.0818 μs |  1.00 |    0.04 |  0.4730 |      - |   7.88 KB |        1.00 |
| NativeParallel    | Ad        | 1000  |    89.092 μs |  2.0248 μs |  1.3393 μs | 35.58 |    1.21 |  0.4883 |      - |   8.17 KB |        1.04 |
|                   |           |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **Ad**        | **10000** | **1,228.711 μs** | **11.0297 μs** |  **5.7688 μs** | **56.73** |    **0.50** | **31.2500** | **7.8125** | **627.79 KB** |        **8.03** |
| BuilderLatestOnly | Ad        | 10000 | 1,221.778 μs | 16.4829 μs | 10.9024 μs | 56.41 |    0.65 |  7.8125 |      - | 157.96 KB |        2.02 |
| NativeSingle      | Ad        | 10000 |    21.661 μs |  0.2933 μs |  0.1745 μs |  1.00 |    0.01 |  4.7607 | 0.8545 |  78.19 KB |        1.00 |
| NativeParallel    | Ad        | 10000 |   108.057 μs |  1.7977 μs |  0.9402 μs |  4.99 |    0.06 |  3.9063 |      - |  78.48 KB |        1.00 |
