```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error    | StdDev  | Gen0    | Gen1   | Allocated |
|------------------ |---------- |------ |-----------:|---------:|--------:|--------:|-------:|----------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **135.2 μs** |  **3.73 μs** | **2.22 μs** |  **3.9063** |      **-** |  **64.88 KB** |
| BuilderLatestOnly | Ad        | 1000  |   128.8 μs |  0.60 μs | 0.31 μs |  0.9766 |      - |  17.27 KB |
| **BuilderFull**       | **Ad**        | **10000** | **1,213.7 μs** | **12.00 μs** | **6.28 μs** | **31.2500** | **7.8125** | **627.79 KB** |
| BuilderLatestOnly | Ad        | 10000 | 1,189.3 μs |  3.89 μs | 2.31 μs |  7.8125 |      - | 157.96 KB |
