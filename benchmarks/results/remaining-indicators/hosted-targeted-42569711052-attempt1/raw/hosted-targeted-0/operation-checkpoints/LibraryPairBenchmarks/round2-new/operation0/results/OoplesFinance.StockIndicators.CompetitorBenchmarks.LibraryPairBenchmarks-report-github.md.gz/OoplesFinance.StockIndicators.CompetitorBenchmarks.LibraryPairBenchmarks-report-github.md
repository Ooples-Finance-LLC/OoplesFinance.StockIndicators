```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean         | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-------------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ad** |   **157.189 μs** |  **3.4617 μs** |  **2.0600 μs** |  **1.00** |    **0.02** |  **140.75 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ad |     4.638 μs |  0.4328 μs |  0.2264 μs |  0.03 |    0.00 |    9.79 KB |        0.07 |
|            |       |                    |              |            |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ad** | **1,522.444 μs** | **40.0890 μs** | **23.8563 μs** |  **1.00** |    **0.02** | **1714.64 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ad |    24.070 μs |  2.0877 μs |  1.3809 μs |  0.02 |    0.00 |   85.68 KB |        0.05 |
