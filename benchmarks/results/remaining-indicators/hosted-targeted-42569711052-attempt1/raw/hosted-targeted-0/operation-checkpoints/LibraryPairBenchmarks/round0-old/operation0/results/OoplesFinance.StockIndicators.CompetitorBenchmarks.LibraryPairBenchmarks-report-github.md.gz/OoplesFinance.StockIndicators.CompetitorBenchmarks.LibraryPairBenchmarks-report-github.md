```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId             | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |------------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Ad** |   **165.0 μs** |   **1.93 μs** |  **1.01 μs** |  **1.00** |    **0.01** |  **140.71 KB** |        **1.00** |
|        |       |                    |            |           |          |       |         |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Ad** | **1,564.4 μs** | **128.12 μs** | **76.24 μs** |  **1.00** |    **0.06** | **1714.36 KB** |        **1.00** |
