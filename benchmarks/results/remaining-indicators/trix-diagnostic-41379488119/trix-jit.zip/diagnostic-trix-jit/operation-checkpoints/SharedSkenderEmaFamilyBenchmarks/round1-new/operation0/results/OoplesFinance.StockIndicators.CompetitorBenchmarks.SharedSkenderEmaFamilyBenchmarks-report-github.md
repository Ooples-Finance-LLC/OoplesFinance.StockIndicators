```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **931.6 μs** |  **12.81 μs** |   **6.70 μs** |       **-** |  **89.26 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   519.0 μs |   4.49 μs |   2.35 μs |       - |  41.64 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **5,187.3 μs** |  **22.15 μs** |  **11.59 μs** | **31.2500** | **863.23 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 5,281.1 μs | 185.67 μs | 110.49 μs |       - |  393.4 KB |
