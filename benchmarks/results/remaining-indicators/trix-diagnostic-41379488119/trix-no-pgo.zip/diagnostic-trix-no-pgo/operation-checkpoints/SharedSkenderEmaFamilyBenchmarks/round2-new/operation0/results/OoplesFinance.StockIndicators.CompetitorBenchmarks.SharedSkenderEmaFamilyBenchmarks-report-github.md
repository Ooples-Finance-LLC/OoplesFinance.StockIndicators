```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **685.7 μs** |  **1.42 μs** |  **0.74 μs** |  **89.22 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   702.2 μs | 20.59 μs | 13.62 μs |   41.6 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **6,901.1 μs** | **26.43 μs** | **15.73 μs** | **863.53 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 6,953.6 μs | 29.26 μs | 15.30 μs | 393.68 KB |
