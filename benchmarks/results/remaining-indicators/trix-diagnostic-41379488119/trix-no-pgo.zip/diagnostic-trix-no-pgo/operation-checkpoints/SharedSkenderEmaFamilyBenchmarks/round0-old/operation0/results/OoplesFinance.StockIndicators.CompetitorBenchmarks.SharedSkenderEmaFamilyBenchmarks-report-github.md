```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0   | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **694.5 μs** |  **2.66 μs** |  **1.58 μs** | **3.9063** |  **89.22 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   682.1 μs | 14.61 μs |  9.67 μs |      - |   41.6 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **6,844.9 μs** | **85.61 μs** | **50.94 μs** |      **-** | **863.55 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 6,776.2 μs | 28.94 μs | 17.22 μs |      - | 393.68 KB |
