```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0   | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **686.4 μs** |  **1.62 μs** |  **0.85 μs** | **3.9063** |  **89.22 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   686.3 μs |  3.25 μs |  2.15 μs |      - |   41.6 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **6,836.1 μs** | **34.07 μs** | **17.82 μs** |      **-** | **863.03 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 6,869.5 μs | 22.59 μs | 13.44 μs |      - |  393.7 KB |
