```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetAwesome** | **1000**  |  **63.66 μs** |  **8.339 μs** |  **5.515 μs** |  **3.9063** |       **-** |  **86.82 KB** |
| BuilderLatestOnly | Skender.GetAwesome | 1000  |  55.84 μs |  7.693 μs |  5.089 μs |  2.4414 |       - |  39.22 KB |
| **BuilderFull**       | **Skender.GetAwesome** | **10000** | **395.17 μs** | **52.213 μs** | **31.071 μs** | **46.8750** | **19.5313** | **790.33 KB** |
| BuilderLatestOnly | Skender.GetAwesome | 10000 | 402.14 μs | 45.007 μs | 26.783 μs | 19.5313 |  7.8125 | 320.49 KB |
