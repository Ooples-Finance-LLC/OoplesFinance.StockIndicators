```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetAwesome** | **1000**  |  **95.65 μs** | **14.870 μs** |  **9.836 μs** |  **3.9063** |       **-** |  **86.83 KB** |
| BuilderLatestOnly | Skender.GetAwesome | 1000  |  74.40 μs |  4.779 μs |  3.161 μs |  2.4414 |       - |  39.22 KB |
| **BuilderFull**       | **Skender.GetAwesome** | **10000** | **572.63 μs** | **66.042 μs** | **43.683 μs** | **46.8750** | **19.5313** | **790.34 KB** |
| BuilderLatestOnly | Skender.GetAwesome | 10000 | 608.57 μs | 64.246 μs | 42.494 μs | 19.5313 |  7.8125 | 320.49 KB |
