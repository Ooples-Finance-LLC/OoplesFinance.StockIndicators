```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetAwesome** | **1000**  |  **82.32 μs** | **10.733 μs** |  **7.099 μs** |  **3.9063** |       **-** |  **86.82 KB** |
| BuilderLatestOnly | Skender.GetAwesome | 1000  |  73.93 μs |  2.813 μs |  1.861 μs |  2.4414 |       - |  39.22 KB |
| **BuilderFull**       | **Skender.GetAwesome** | **10000** | **571.56 μs** | **61.438 μs** | **40.637 μs** | **46.8750** | **19.5313** | **790.33 KB** |
| BuilderLatestOnly | Skender.GetAwesome | 10000 | 565.45 μs | 57.839 μs | 38.257 μs | 19.5313 |  7.8125 |  320.5 KB |
