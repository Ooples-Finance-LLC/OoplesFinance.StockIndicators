```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Gen2    | Allocated  | Alloc Ratio |
|------------------ |------------------- |------ |----------:|-----------:|----------:|------:|--------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAwesome** | **1000**  |  **70.05 μs** |   **7.847 μs** |  **5.191 μs** |  **1.71** |    **0.12** |  **3.9063** |       **-** |       **-** |   **86.79 KB** |        **0.76** |
| BuilderLatestOnly | Skender.GetAwesome | 1000  |  56.37 μs |   3.987 μs |  2.637 μs |  1.38 |    0.07 |  2.4414 |       - |       - |   39.22 KB |        0.34 |
| NativeSingle      | Skender.GetAwesome | 1000  |  40.91 μs |   1.258 μs |  0.749 μs |  1.00 |    0.02 |  6.8359 |  1.2207 |       - |   113.7 KB |        1.00 |
| NativeParallel    | Skender.GetAwesome | 1000  |  29.71 μs |   3.524 μs |  2.331 μs |  0.73 |    0.06 |  9.0332 |  1.7090 |       - |  134.18 KB |        1.18 |
|                   |                    |       |           |            |           |       |         |         |         |         |            |             |
| **BuilderFull**       | **Skender.GetAwesome** | **10000** | **521.56 μs** | **128.664 μs** | **85.103 μs** |  **0.82** |    **0.13** | **46.8750** | **21.4844** |       **-** |  **790.27 KB** |        **0.70** |
| BuilderLatestOnly | Skender.GetAwesome | 10000 | 360.52 μs |  31.872 μs | 21.081 μs |  0.57 |    0.03 | 19.5313 |  5.8594 |       - |  320.49 KB |        0.28 |
| NativeSingle      | Skender.GetAwesome | 10000 | 635.63 μs |   6.355 μs |  3.782 μs |  1.00 |    0.01 | 97.6563 | 97.6563 | 97.6563 | 1134.02 KB |        1.00 |
| NativeParallel    | Skender.GetAwesome | 10000 | 271.01 μs |  12.930 μs |  8.553 μs |  0.43 |    0.01 | 80.0781 | 33.2031 |       - | 1224.04 KB |        1.08 |
