```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAwesome** | **136.17 μs** | **23.800 μs** | **15.742 μs** |  **1.01** |    **0.16** |  **165.36 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAwesome |  77.33 μs |  2.259 μs |  1.182 μs |  0.58 |    0.07 |   170.9 KB |        1.03 |
|            |       |                    |           |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAwesome** | **848.08 μs** | **15.912 μs** |  **8.322 μs** |  **1.00** |    **0.01** | **1597.63 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAwesome | 817.51 μs | 23.924 μs | 14.237 μs |  0.96 |    0.02 | 1630.49 KB |        1.02 |
