from pathlib import Path
import ast,collections,gzip,hashlib,json,re,subprocess
ROOT=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
REPO=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
OPERATIONS=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-fibonacci-builder-measurement-20261022')
RUN='39746134672';WORKFLOW='2e8a6a4f123964edd96a700cd918d0b0fc28bb20';SOURCE='29a41d8b7956a05812a5950631f07b84bcb04ee0'
code=ast.parse(subprocess.check_output(['git','show',WORKFLOW+':scripts/measure-cpu-builder-batch12.py'],cwd=OPERATIONS,text=True))
fixtures=ast.literal_eval(next(n.value for n in code.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='FIXTURES' for t in n.targets)))
prefixes=ast.literal_eval(next(n.value for n in code.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PREFIXES' for t in n.targets)))
run=json.loads(subprocess.check_output(['gh','run','view',RUN,'--repo','Ooples-Finance-LLC/OoplesFinance.StockIndicators','--json','status,conclusion,headSha,jobs']))
assert run['status']=='completed' and run['conclusion']=='failure' and run['headSha']==WORKFLOW
jobs={j['name']:j for j in run['jobs']}
assert jobs['measure (SharedPriceRangeBenchmarks)']['conclusion']=='failure'
fixtures.pop('SharedPriceRangeBenchmarks')
assert all(jobs['measure ('+name+')']['conclusion']=='success' for name in fixtures)
changes=subprocess.check_output(['git','diff','--name-only',SOURCE,'HEAD','--','src','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks'],cwd=REPO,text=True).splitlines();assert changes==['src/Helpers/CertifiedMeanRelativeError.cs','src/Indicators/CompensatedExponentialAverage.cs']
output=REPO/'benchmarks/results/remaining-indicators';folder=ROOT/('cpu-builder12-'+RUN);seen=set();all_rows=[];manifests=[];archives=[]
for name,pairs in fixtures.items():
 path=folder/('builder-'+name);d=json.loads((path/'comparison.json').read_text());assert d['complete'] and d['fixture']==name and d['run_id']==RUN and d['workflow_sha']==WORKFLOW and d['source_sha']==SOURCE
 raw=(path/d['report_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==d['report_sha256'];report=json.loads(raw);cases={}
 for row in report['Benchmarks']:
  assert name+'.' in row['FullName'];operation=re.search(r'Operation: "([^"]+)"',row['FullName']);assert operation is not None;pair=operation[1] if operation else fixtures[name][0];pair=prefixes.get(name,'')+pair if operation else pair;count=int(re.search(r'Count: (\d+)',row['FullName'])[1]);key=pair,count,row['Method'];assert key not in cases;cases[key]=row
 assert set(cases)=={(p,n,m) for p in pairs for n in [1000,10000] for m in ['BuilderFull','BuilderLatestOnly','NativeSingle','NativeParallel']}
 assert {(r['pair'],r['bars'],r['mode']) for r in d['comparisons']}=={(p,n,m) for p in pairs for n in [1000,10000] for m in ['BuilderFull','BuilderLatestOnly']}
 for r in d['comparisons']:
  key=r['pair'],r['bars'],r['mode'];assert key not in seen;seen.add(key)
  for method,summary in [(r['mode'],r['ooples']),*r['native'].items()]:
   original=cases[r['pair'],r['bars'],method];s=original['Statistics'];ci=s['ConfidenceInterval']
   assert summary==dict(mean_ns=s['Mean'],lower_ns=ci['Lower'],upper_ns=ci['Upper'],samples=s['N'],allocated_bytes=original['Memory']['BytesAllocatedPerOperation'])
   assert s['N']==len(s['OriginalValues']) and s['N']>=7
  ours=r['ooples'];native=list(r['native'].values());verdict='faster' if ours['upper_ns']<min(n['lower_ns'] for n in native) else 'slower' if ours['lower_ns']>min(n['upper_ns'] for n in native) else 'inconclusive';assert r['verdict']==verdict
 all_rows.extend(d['comparisons']);manifests.append(json.loads((path/'binary-manifest.json').read_text()));stem='cpu-builder-'+RUN+'-'+name
 (output/(stem+'-raw.json.gz')).write_bytes(gzip.compress(raw,mtime=0));d['raw_archive']='benchmarks/results/remaining-indicators/'+stem+'-raw.json.gz'
 for file in ['provenance.json','binary-manifest.json']:
  raw=(path/file).read_bytes();(output/(stem+'-'+file+'.gz')).write_bytes(gzip.compress(raw,mtime=0));d[file]={'archive':stem+'-'+file+'.gz','sha256':hashlib.sha256(raw).hexdigest()}
 d['source_note']='Qualified baseline binaries reused; selected fixture and implementation code is unchanged; the later SMA diagnostics and standalone compensated EMA changes do not participate in these fixtures.'
 (output/(stem+'.json')).write_text(json.dumps(d,indent=2)+'\n');archives.append(stem+'.json')
assert len(seen)==124 and len({r['pair'] for r in all_rows})==31 and all(m==manifests[0] for m in manifests)
summary={'run_id':RUN,'workflow_sha':WORKFLOW,'source_sha':SOURCE,'apis':31,'comparisons':124,'excluded_failed_fixtures':['SharedPriceRangeBenchmarks'],'verdicts':dict(collections.Counter(r['verdict'] for r in all_rows)),'receipt_files':archives,'changed_production_files_since_baseline':changes,'note':'Matched same-runner native serial/parallel comparison for each default-period fixture; no universal superiority claim.'}
(output/('cpu-builder-'+RUN+'-summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
