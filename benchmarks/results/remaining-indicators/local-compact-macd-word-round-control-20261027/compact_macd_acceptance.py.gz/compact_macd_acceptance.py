"""Require a gain in changed MACD/PVO code, never solely in SMA controls."""
AFFECTED_PAIRS = frozenset({
    'TaLib.Functions.Macd', 'TaLib.Functions.MacdFix',
    'Trady.Indicator.MovingAverageConvergenceDivergence',
    'Trady.Indicator.MovingAverageConvergenceDivergenceHistogram',
    'Skender.GetMacd', 'Skender.GetPvo',
})


def qualifies(decisions):
    rows = list(decisions)
    assert all(row['verdict'] in {'faster', 'slower', 'inconclusive'} for row in rows)
    return (not any(row['verdict'] == 'slower' for row in rows)
            and any(row['verdict'] == 'faster' and row['pair'] in AFFECTED_PAIRS
                    for row in rows))


if __name__ == '__main__':
    def row(pair, verdict):
        return {'pair': pair, 'verdict': verdict}
    gain = row('TaLib.Functions.Macd', 'faster')
    assert qualifies([gain])
    assert not qualifies([row('TaLib.Functions.Apo', 'faster')])
    assert not qualifies([gain, row('TaLib.Functions.Apo', 'slower')])
    assert not qualifies([row('Skender.GetMacd', 'inconclusive')])
    assert not qualifies([])
    print('5 acceptance policy checks passed')
