from pathlib import Path
import datetime,hashlib,json,re
out=Path('C:/Users/cheat/Documents/OoplesFinance-Reports/cpu-builder-refresh-39738109586');live=out.parent/'competitor-performance.html';candidate=out/'candidate.html'
s=json.loads((out/'staged.json').read_text());v=json.loads((out/'browser-verification.json').read_text());b=json.loads((out/'builder-verification.json').read_text())
assert s['candidate_sha256']==v['report_sha256']==b['report_sha256']==hashlib.sha256(candidate.read_bytes()).hexdigest()
assert s['before_sha256']==hashlib.sha256(live.read_bytes()).hexdigest()
assert v['comparisons']==v['displayed_table_comparisons']==v['exported_comparisons']==802 and not v['javascript_errors']
assert b['run_id']=='39738109586' and b['builder_comparisons']==392 and b['new_builder_comparisons']==124 and b['unchanged_baseline_comparisons']==802 and not b['javascript_errors']
def data(p,n):return json.loads(re.search(r'<script[^>]*id="'+n+r'"[^>]*>(.*?)</script>',p.read_text(encoding='utf-8'),re.S)[1])
for n in ['dataset','archived-baseline-dataset']:assert data(live,n)==data(candidate,n)
tmp=live.with_suffix('.builder-update.tmp');assert not tmp.exists();tmp.write_bytes(candidate.read_bytes());tmp.replace(live)
assert hashlib.sha256(live.read_bytes()).hexdigest()==s['candidate_sha256']
(out/'imported.json').write_text(json.dumps({**s,'browser_verified':True,'imported_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
print('Imported verified builder392 results; baseline802 unchanged',s['candidate_sha256'])
