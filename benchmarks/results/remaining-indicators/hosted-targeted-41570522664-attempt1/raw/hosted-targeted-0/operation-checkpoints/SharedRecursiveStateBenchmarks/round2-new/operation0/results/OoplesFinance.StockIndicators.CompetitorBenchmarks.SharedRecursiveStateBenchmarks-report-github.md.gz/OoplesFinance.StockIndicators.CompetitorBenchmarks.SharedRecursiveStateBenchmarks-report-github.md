```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean         | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |-------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **141.331 μs** | **5.5814 μs** | **2.9192 μs** | **58.46** |    **2.02** |  **3.9063** |      **-** |  **64.93 KB** |        **8.25** |
| BuilderLatestOnly | Ad        | 1000  |   136.412 μs | 0.8827 μs | 0.5253 μs | 56.42 |    1.63 |  0.9766 |      - |  17.33 KB |        2.20 |
| NativeSingle      | Ad        | 1000  |     2.420 μs | 0.1111 μs | 0.0735 μs |  1.00 |    0.04 |  0.4730 |      - |   7.88 KB |        1.00 |
| NativeParallel    | Ad        | 1000  |     5.598 μs | 0.4333 μs | 0.2866 μs |  2.32 |    0.13 |  0.4883 |      - |   8.16 KB |        1.04 |
|                   |           |       |              |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **Ad**        | **10000** | **1,288.799 μs** | **9.0120 μs** | **4.7134 μs** | **61.04** |    **0.34** | **31.2500** | **7.8125** | **627.84 KB** |        **8.03** |
| BuilderLatestOnly | Ad        | 10000 | 1,283.123 μs | 5.7359 μs | 3.4134 μs | 60.77 |    0.30 |  7.8125 |      - | 158.01 KB |        2.02 |
| NativeSingle      | Ad        | 10000 |    21.116 μs | 0.1839 μs | 0.0962 μs |  1.00 |    0.01 |  4.7607 | 0.8545 |  78.19 KB |        1.00 |
| NativeParallel    | Ad        | 10000 |    42.124 μs | 4.0699 μs | 2.1286 μs |  1.99 |    0.10 |  4.3945 | 0.4883 |  78.48 KB |        1.00 |
