```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error    | StdDev  | Gen0    | Gen1   | Allocated |
|------------------ |---------- |------ |-----------:|---------:|--------:|--------:|-------:|----------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **137.4 μs** |  **9.93 μs** | **5.91 μs** |  **3.9063** |      **-** |  **64.84 KB** |
| BuilderLatestOnly | Ad        | 1000  |   133.0 μs |  1.27 μs | 0.66 μs |  0.9766 |      - |  17.27 KB |
| **BuilderFull**       | **Ad**        | **10000** | **1,216.1 μs** | **11.37 μs** | **6.77 μs** | **31.2500** | **7.8125** | **627.75 KB** |
| BuilderLatestOnly | Ad        | 10000 | 1,192.2 μs | 10.85 μs | 6.46 μs |  7.8125 |      - | 157.96 KB |
