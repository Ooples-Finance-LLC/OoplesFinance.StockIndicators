```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)nLine [44]** |   **172.4 μs** |  **2.57 μs** |  **1.53 μs** |  **1.00** |    **0.01** |  **105.77 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)nLine [44] | 1,168.2 μs | 38.57 μs | 25.51 μs |  6.78 |    0.15 |  903.67 KB |        8.54 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Trady(...)nLine [44]** | **1,584.5 μs** | **45.99 μs** | **27.37 μs** |  **1.00** |    **0.02** | **1037.77 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)nLine [44] | 9,216.8 μs | 70.34 μs | 41.86 μs |  5.82 |    0.10 | 8810.82 KB |        8.49 |
