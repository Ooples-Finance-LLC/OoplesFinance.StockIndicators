```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean         | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |------------------- |-------------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ad** |   **160.972 μs** |  **1.8153 μs** |  **1.0803 μs** |  **1.00** |    **0.01** |  **73.38 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ad |     3.975 μs |  0.1695 μs |  0.0886 μs |  0.02 |    0.00 |   9.79 KB |        0.13 |
|            |       |                    |              |            |            |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ad** | **1,432.500 μs** | **34.2734 μs** | **20.3955 μs** |  **1.00** |    **0.02** | **714.02 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ad |    22.113 μs |  0.1895 μs |  0.0991 μs |  0.02 |    0.00 |  86.29 KB |        0.12 |
