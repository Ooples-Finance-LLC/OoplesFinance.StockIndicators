```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |    **60.56 μs** |  **0.584 μs** |  **0.306 μs** |  **0.75** |    **0.01** |   **3.9063** |        **-** |   **88.31 KB** |        **0.50** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |    56.60 μs |  0.460 μs |  0.274 μs |  0.70 |    0.01 |   2.4414 |        - |    40.7 KB |        0.23 |
| NativeSingle      | Skender.GetAdl | 1000  |    80.72 μs |  1.893 μs |  1.252 μs |  1.00 |    0.02 |  10.7422 |   2.4414 |  176.21 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 1000  |   149.53 μs |  9.915 μs |  6.558 μs |  1.85 |    0.08 |  27.3438 |   7.8125 |  449.41 KB |        2.55 |
|                   |                |       |             |           |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetAdl** | **10000** |   **586.16 μs** |  **8.834 μs** |  **5.257 μs** |  **0.63** |    **0.02** |  **50.7813** |  **15.6250** |  **862.13 KB** |        **0.49** |
| BuilderLatestOnly | Skender.GetAdl | 10000 |   551.08 μs |  6.271 μs |  3.280 μs |  0.59 |    0.01 |  23.4375 |   7.8125 |  392.31 KB |        0.22 |
| NativeSingle      | Skender.GetAdl | 10000 |   938.36 μs | 35.726 μs | 23.631 μs |  1.00 |    0.03 | 101.5625 |  62.5000 |  1758.3 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 10000 | 1,525.71 μs | 97.204 μs | 64.294 μs |  1.63 |    0.08 | 273.4375 | 179.6875 | 4474.84 KB |        2.54 |
