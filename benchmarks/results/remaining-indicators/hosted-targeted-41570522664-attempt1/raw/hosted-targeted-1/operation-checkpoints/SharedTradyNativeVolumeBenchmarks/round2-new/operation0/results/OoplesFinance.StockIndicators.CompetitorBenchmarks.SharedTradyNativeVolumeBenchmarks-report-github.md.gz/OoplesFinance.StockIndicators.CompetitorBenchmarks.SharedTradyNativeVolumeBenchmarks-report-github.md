```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|----------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Accum(...)nLine [28]** | **1000**  |   **162.0 μs** |  **23.68 μs** |  **14.09 μs** |  **0.30** |    **0.02** |         **-** |        **-** |        **-** |   **65.14 KB** |        **0.11** |
| BuilderLatestOnly | Accum(...)nLine [28] | 1000  |   138.5 μs |   1.16 μs |   0.69 μs |  0.26 |    0.00 |    0.9766 |        - |        - |   17.49 KB |        0.03 |
| NativeSingle      | Accum(...)nLine [28] | 1000  |   539.1 μs |   3.65 μs |   2.41 μs |  1.00 |    0.01 |   35.1563 |  11.7188 |        - |  594.33 KB |        1.00 |
| NativeParallel    | Accum(...)nLine [28] | 1000  |   470.6 μs |   6.55 μs |   3.43 μs |  0.87 |    0.01 |   54.6875 |  15.6250 |        - |  894.29 KB |        1.50 |
|                   |                      |       |            |           |           |       |         |           |          |          |            |             |
| **BuilderFull**       | **Accum(...)nLine [28]** | **10000** | **1,400.8 μs** |  **11.61 μs** |   **6.91 μs** |  **0.22** |    **0.01** |   **31.2500** |   **7.8125** |        **-** |  **628.01 KB** |        **0.11** |
| BuilderLatestOnly | Accum(...)nLine [28] | 10000 | 1,351.7 μs |   3.79 μs |   1.98 μs |  0.22 |    0.01 |    7.8125 |        - |        - |  158.18 KB |        0.03 |
| NativeSingle      | Accum(...)nLine [28] | 10000 | 6,247.2 μs | 323.03 μs | 213.66 μs |  1.00 |    0.05 |  687.5000 | 500.0000 | 468.7500 | 5824.36 KB |        1.00 |
| NativeParallel    | Accum(...)nLine [28] | 10000 | 6,175.9 μs | 432.45 μs | 257.35 μs |  0.99 |    0.05 | 1125.0000 | 937.5000 | 843.7500 | 8717.33 KB |        1.50 |
