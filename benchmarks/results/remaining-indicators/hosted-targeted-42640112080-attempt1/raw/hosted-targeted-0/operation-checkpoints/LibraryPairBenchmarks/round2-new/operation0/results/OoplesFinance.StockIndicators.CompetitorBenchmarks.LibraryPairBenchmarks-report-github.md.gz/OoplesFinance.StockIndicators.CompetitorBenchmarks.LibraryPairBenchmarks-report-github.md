```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error    | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|---------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAdl** |   **156.12 μs** | **11.03 μs** |  **6.566 μs** |  **1.00** |    **0.06** |  **159.04 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAdl |    69.94 μs | 12.06 μs |  6.308 μs |  0.45 |    0.04 |  271.03 KB |        1.70 |
|            |       |                |             |          |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAdl** | **1,106.32 μs** | **20.23 μs** | **12.037 μs** |  **1.00** |    **0.01** | **1508.15 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAdl |   710.71 μs | 18.42 μs |  9.636 μs |  0.64 |    0.01 | 2652.87 KB |        1.76 |
