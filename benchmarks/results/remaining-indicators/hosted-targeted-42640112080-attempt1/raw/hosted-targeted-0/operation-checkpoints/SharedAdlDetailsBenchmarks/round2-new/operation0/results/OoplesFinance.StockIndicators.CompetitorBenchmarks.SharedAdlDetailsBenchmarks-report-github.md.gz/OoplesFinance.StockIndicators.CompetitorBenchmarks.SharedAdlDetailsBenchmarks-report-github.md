```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |    **35.89 μs** |   **0.226 μs** |   **0.118 μs** |  **0.60** |    **0.01** |   **5.3711** |   **0.9766** |   **88.28 KB** |        **0.50** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |    26.14 μs |   0.147 μs |   0.077 μs |  0.44 |    0.00 |   2.4414 |   0.2441 |    40.7 KB |        0.23 |
| NativeSingle      | Skender.GetAdl | 1000  |    59.56 μs |   0.950 μs |   0.628 μs |  1.00 |    0.01 |  10.7422 |   2.4414 |  176.21 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 1000  |   154.71 μs |   6.501 μs |   3.869 μs |  2.60 |    0.07 |  27.3438 |   7.8125 |  449.41 KB |        2.55 |
|                   |                |       |             |            |            |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetAdl** | **10000** |   **472.86 μs** |   **7.983 μs** |   **5.281 μs** |  **0.71** |    **0.02** |  **50.7813** |  **15.6250** |   **862.1 KB** |        **0.49** |
| BuilderLatestOnly | Skender.GetAdl | 10000 |   248.73 μs |   2.977 μs |   1.557 μs |  0.37 |    0.01 |  23.4375 |   9.7656 |  392.29 KB |        0.22 |
| NativeSingle      | Skender.GetAdl | 10000 |   664.03 μs |  33.235 μs |  17.383 μs |  1.00 |    0.03 | 105.4688 |  66.4063 | 1758.26 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 10000 | 1,492.61 μs | 200.067 μs | 132.332 μs |  2.25 |    0.20 | 273.4375 | 203.1250 | 4474.84 KB |        2.55 |
