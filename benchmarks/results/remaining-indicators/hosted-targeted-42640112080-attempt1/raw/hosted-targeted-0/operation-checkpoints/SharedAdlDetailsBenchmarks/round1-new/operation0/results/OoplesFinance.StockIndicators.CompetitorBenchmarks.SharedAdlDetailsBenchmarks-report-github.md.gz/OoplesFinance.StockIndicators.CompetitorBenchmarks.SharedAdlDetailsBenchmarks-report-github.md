```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |  **29.48 μs** | **0.709 μs** | **0.422 μs** |  **5.3711** |  **0.9766** |  **88.31 KB** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |  26.36 μs | 0.306 μs | 0.202 μs |  2.4414 |  0.2441 |   40.7 KB |
| **BuilderFull**       | **Skender.GetAdl** | **10000** | **334.69 μs** | **2.421 μs** | **1.601 μs** | **50.7813** | **17.5781** | **862.11 KB** |
| BuilderLatestOnly | Skender.GetAdl | 10000 | 247.78 μs | 3.140 μs | 1.642 μs | 23.4375 |  9.7656 | 392.29 KB |
