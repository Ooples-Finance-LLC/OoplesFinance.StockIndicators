```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Median     | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|-----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)Bands [25]** | **1000**  |   **298.1 μs** | **167.81 μs** | **111.00 μs** |   **229.0 μs** |  **2.11** |    **0.75** |        **-** |        **-** |       **-** |  **132.97 KB** |        **0.39** |
| BuilderLatestOnly | Skend(...)Bands [25] | 1000  |   150.3 μs |  16.77 μs |   8.77 μs |   147.2 μs |  1.06 |    0.06 |   1.9531 |        - |       - |   85.37 KB |        0.25 |
| NativeSingle      | Skend(...)Bands [25] | 1000  |   141.6 μs |   2.95 μs |   1.95 μs |   140.6 μs |  1.00 |    0.02 |  13.6719 |   2.9297 |       - |  344.64 KB |        1.00 |
| NativeParallel    | Skend(...)Bands [25] | 1000  |   115.5 μs |   1.82 μs |   1.20 μs |   115.3 μs |  0.82 |    0.01 |  14.6484 |   3.9063 |       - |   363.4 KB |        1.05 |
|                   |                      |       |            |           |           |            |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)Bands [25]** | **10000** | **1,306.4 μs** | **177.10 μs** | **117.14 μs** | **1,232.2 μs** |  **0.57** |    **0.07** |  **46.8750** |  **23.4375** |       **-** | **1258.38 KB** |        **0.36** |
| BuilderLatestOnly | Skend(...)Bands [25] | 10000 | 1,221.2 μs | 171.92 μs | 113.71 μs | 1,153.6 μs |  0.53 |    0.06 |  31.2500 |   7.8125 |       - |  788.56 KB |        0.23 |
| NativeSingle      | Skend(...)Bands [25] | 10000 | 2,310.7 μs | 276.82 μs | 183.10 μs | 2,352.5 μs |  1.01 |    0.11 | 203.1250 | 140.6250 | 78.1250 | 3474.27 KB |        1.00 |
| NativeParallel    | Skend(...)Bands [25] | 10000 |   951.3 μs |  36.44 μs |  19.06 μs |   947.3 μs |  0.41 |    0.03 | 148.4375 |  70.3125 |       - | 3562.67 KB |        1.03 |
