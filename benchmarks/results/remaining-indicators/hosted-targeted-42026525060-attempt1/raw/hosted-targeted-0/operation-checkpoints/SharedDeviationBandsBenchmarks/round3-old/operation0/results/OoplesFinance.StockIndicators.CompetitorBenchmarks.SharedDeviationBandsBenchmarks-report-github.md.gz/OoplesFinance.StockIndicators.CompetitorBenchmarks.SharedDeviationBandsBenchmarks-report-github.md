```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Skend(...)Bands [25]** | **1000**  |   **202.8 μs** | **63.82 μs** | **42.21 μs** |  **3.9063** |       **-** |  **132.93 KB** |
| BuilderLatestOnly | Skend(...)Bands [25] | 1000  |   198.8 μs | 39.40 μs | 26.06 μs |  1.9531 |       - |   85.37 KB |
| **BuilderFull**       | **Skend(...)Bands [25]** | **10000** | **1,402.1 μs** | **50.59 μs** | **26.46 μs** | **46.8750** | **15.6250** | **1258.42 KB** |
| BuilderLatestOnly | Skend(...)Bands [25] | 10000 | 1,374.5 μs | 36.31 μs | 18.99 μs | 31.2500 |       - |  788.63 KB |
