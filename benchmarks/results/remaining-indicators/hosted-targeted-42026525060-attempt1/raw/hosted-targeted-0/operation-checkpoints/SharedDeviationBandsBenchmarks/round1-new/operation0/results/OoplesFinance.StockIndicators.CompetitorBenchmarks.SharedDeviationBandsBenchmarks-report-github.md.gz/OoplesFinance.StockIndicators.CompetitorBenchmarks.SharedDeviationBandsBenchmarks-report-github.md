```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Skend(...)Bands [25]** | **1000**  |   **205.9 μs** |  **47.71 μs** |  **31.56 μs** |       **-** |       **-** |  **132.93 KB** |
| BuilderLatestOnly | Skend(...)Bands [25] | 1000  |   148.2 μs |   4.16 μs |   2.18 μs |  1.9531 |       - |   85.37 KB |
| **BuilderFull**       | **Skend(...)Bands [25]** | **10000** | **1,334.8 μs** | **190.70 μs** | **126.14 μs** | **46.8750** | **23.4375** | **1258.35 KB** |
| BuilderLatestOnly | Skend(...)Bands [25] | 10000 | 1,181.9 μs |  71.96 μs |  37.64 μs | 31.2500 |  7.8125 |  788.54 KB |
