```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Skend(...)Bands [25]** | **1000**  |   **196.6 μs** |  **20.81 μs** |  **10.88 μs** |       **-** |       **-** |     **133 KB** |
| BuilderLatestOnly | Skend(...)Bands [25] | 1000  |   175.5 μs |  28.72 μs |  17.09 μs |  1.9531 |       - |   85.37 KB |
| **BuilderFull**       | **Skend(...)Bands [25]** | **10000** | **1,453.2 μs** | **189.88 μs** | **125.59 μs** | **46.8750** | **23.4375** | **1258.38 KB** |
| BuilderLatestOnly | Skend(...)Bands [25] | 10000 | 1,390.8 μs | 132.84 μs |  87.86 μs | 31.2500 |  7.8125 |  788.55 KB |
