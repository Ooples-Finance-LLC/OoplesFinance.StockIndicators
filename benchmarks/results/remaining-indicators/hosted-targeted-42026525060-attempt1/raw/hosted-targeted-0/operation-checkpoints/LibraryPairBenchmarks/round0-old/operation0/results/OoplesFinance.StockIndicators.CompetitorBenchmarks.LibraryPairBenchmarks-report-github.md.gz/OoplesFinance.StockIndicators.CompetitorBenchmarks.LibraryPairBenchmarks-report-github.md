```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean       | Error    | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |-----------:|---------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skend(...)Bands [25]** |   **446.7 μs** | **108.6 μs** |  **71.86 μs** |  **1.02** |    **0.22** |  **374.59 KB** |        **1.00** |
|        |       |                      |            |          |           |       |         |            |             |
| **Ooples** | **10000** | **Skend(...)Bands [25]** | **3,514.8 μs** | **801.7 μs** | **530.27 μs** |  **1.02** |    **0.21** | **3670.19 KB** |        **1.00** |
