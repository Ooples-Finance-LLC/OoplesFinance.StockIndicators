```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)Bands [25]** |   **366.1 μs** |  **21.35 μs** |  **11.17 μs** |  **1.00** |    **0.04** |  **374.59 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)Bands [25] |   181.8 μs |  17.04 μs |  10.14 μs |  0.50 |    0.03 |  501.53 KB |        1.34 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)Bands [25]** | **2,956.6 μs** | **465.47 μs** | **307.88 μs** |  **1.01** |    **0.14** | **3669.91 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)Bands [25] | 2,195.6 μs |  62.06 μs |  41.05 μs |  0.75 |    0.07 | 4949.13 KB |        1.35 |
