```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Trady(...)Width [34]** | **1000**  |   **241.3 μs** |  **70.88 μs** |  **46.88 μs** |  **7.8125** |       **-** |  **132.97 KB** |
| BuilderLatestOnly | Trady(...)Width [34] | 1000  |   121.7 μs |   2.93 μs |   1.53 μs |  3.9063 |       - |   85.37 KB |
| **BuilderFull**       | **Trady(...)Width [34]** | **10000** | **1,134.8 μs** | **164.36 μs** | **108.72 μs** | **70.3125** | **62.5000** | **1258.39 KB** |
| BuilderLatestOnly | Trady(...)Width [34] | 10000 | 1,210.7 μs | 352.74 μs | 233.32 μs | 46.8750 | 15.6250 |  788.55 KB |
