```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Median      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Trady(...)Width [34]** | **1000**  |    **487.0 μs** |   **447.37 μs** |   **295.91 μs** |    **375.4 μs** |  **0.30** |    **0.17** |    **7.8125** |         **-** |         **-** |   **133.01 KB** |        **0.08** |
| BuilderLatestOnly | Trady(...)Width [34] | 1000  |    121.9 μs |     1.51 μs |     0.79 μs |    121.9 μs |  0.07 |    0.00 |    4.8828 |    0.9766 |         - |    85.36 KB |        0.05 |
| NativeSingle      | Trady(...)Width [34] | 1000  |  1,626.3 μs |    18.79 μs |     9.83 μs |  1,627.6 μs |  1.00 |    0.01 |   93.7500 |   78.1250 |   46.8750 |  1710.64 KB |        1.00 |
| NativeParallel    | Trady(...)Width [34] | 1000  |    967.8 μs |   142.43 μs |    94.21 μs |    973.5 μs |  0.60 |    0.06 |  101.5625 |   31.2500 |         - |  1656.16 KB |        0.97 |
|                   |                      |       |             |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **Trady(...)Width [34]** | **10000** |  **1,035.6 μs** |    **34.97 μs** |    **18.29 μs** |  **1,028.2 μs** |  **0.06** |    **0.00** |   **70.3125** |   **62.5000** |         **-** |   **1258.4 KB** |        **0.08** |
| BuilderLatestOnly | Trady(...)Width [34] | 10000 |  1,115.3 μs |   146.49 μs |    96.90 μs |  1,095.5 μs |  0.07 |    0.01 |   46.8750 |   23.4375 |         - |   788.57 KB |        0.05 |
| NativeSingle      | Trady(...)Width [34] | 10000 | 16,178.0 μs |   139.99 μs |    73.22 μs | 16,165.4 μs |  1.00 |    0.01 | 1285.7143 | 1000.0000 |  857.1429 | 16576.18 KB |        1.00 |
| NativeParallel    | Trady(...)Width [34] | 10000 | 11,236.4 μs | 1,826.21 μs | 1,207.92 μs | 11,079.0 μs |  0.69 |    0.07 | 1700.0000 | 1400.0000 | 1000.0000 | 16212.98 KB |        0.98 |
