```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Trady(...)Width [34]** | **1000**  |   **219.2 μs** |  **29.93 μs** |  **15.65 μs** |  **7.8125** |       **-** |  **132.93 KB** |
| BuilderLatestOnly | Trady(...)Width [34] | 1000  |   134.7 μs |   1.36 μs |   0.71 μs |  3.9063 |       - |   85.37 KB |
| **BuilderFull**       | **Trady(...)Width [34]** | **10000** | **1,188.9 μs** |  **73.83 μs** |  **43.94 μs** | **70.3125** | **62.5000** | **1258.36 KB** |
| BuilderLatestOnly | Trady(...)Width [34] | 10000 | 1,248.8 μs | 161.22 μs | 106.64 μs | 46.8750 | 23.4375 |  788.56 KB |
