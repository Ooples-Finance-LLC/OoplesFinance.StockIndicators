```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Trady(...)Width [34]** | **1000**  |   **194.7 μs** |  **65.50 μs** |  **38.98 μs** |  **7.8125** |       **-** |  **133.01 KB** |
| BuilderLatestOnly | Trady(...)Width [34] | 1000  |   146.2 μs |  14.28 μs |   8.50 μs |  3.9063 |       - |   85.37 KB |
| **BuilderFull**       | **Trady(...)Width [34]** | **10000** | **1,324.4 μs** | **233.15 μs** | **154.21 μs** | **70.3125** | **62.5000** | **1258.37 KB** |
| BuilderLatestOnly | Trady(...)Width [34] | 10000 | 1,444.4 μs | 195.24 μs | 129.14 μs | 46.8750 | 15.6250 |  788.62 KB |
