```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)Width [34]** |    **218.4 μs** |  **13.33 μs** |   **7.93 μs** |  **1.00** |    **0.05** |  **329.45 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)Width [34] |  2,146.1 μs |  49.69 μs |  25.99 μs |  9.84 |    0.35 | 2025.59 KB |        6.15 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Trady(...)Width [34]** |  **2,126.0 μs** |  **63.86 μs** |  **38.00 μs** |  **1.00** |    **0.02** | **3230.24 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)Width [34] | 19,928.9 μs | 217.56 μs | 129.46 μs |  9.38 |    0.17 | 19633.1 KB |        6.08 |
