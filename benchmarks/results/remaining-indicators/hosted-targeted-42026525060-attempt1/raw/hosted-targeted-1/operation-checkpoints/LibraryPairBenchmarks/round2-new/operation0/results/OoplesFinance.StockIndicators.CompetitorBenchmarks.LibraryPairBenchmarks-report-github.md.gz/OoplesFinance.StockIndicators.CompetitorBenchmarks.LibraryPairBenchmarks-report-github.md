```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)Bands [30]** |    **306.8 μs** |  **43.18 μs** |  **25.70 μs** |  **1.01** |    **0.11** |   **347.41 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)Bands [30] |  2,287.7 μs |  60.65 μs |  40.12 μs |  7.50 |    0.56 |  1968.28 KB |        5.67 |
|            |       |                      |             |           |           |       |         |             |             |
| **Ooples**     | **10000** | **Trady(...)Bands [30]** |  **3,150.4 μs** | **814.56 μs** | **538.78 μs** |  **1.03** |    **0.24** |  **3406.69 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)Bands [30] | 21,239.2 μs |  86.68 μs |  45.34 μs |  6.93 |    1.18 | 19149.12 KB |        5.62 |
