```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Trady(...)Bands [30]** | **1000**  |   **243.2 μs** |  **80.03 μs** |  **52.93 μs** |  **7.8125** |       **-** |  **132.97 KB** |
| BuilderLatestOnly | Trady(...)Bands [30] | 1000  |   202.0 μs |  34.34 μs |  22.71 μs |  3.9063 |       - |   85.37 KB |
| **BuilderFull**       | **Trady(...)Bands [30]** | **10000** | **1,528.1 μs** | **135.70 μs** |  **70.97 μs** | **62.5000** | **46.8750** | **1258.46 KB** |
| BuilderLatestOnly | Trady(...)Bands [30] | 10000 | 1,596.9 μs | 163.58 μs | 108.20 μs | 46.8750 | 15.6250 |  788.57 KB |
