```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Trady(...)Bands [30]** | **1000**  |   **211.0 μs** |  **24.29 μs** |  **12.70 μs** |  **7.8125** |       **-** | **133.01 KB** |
| BuilderLatestOnly | Trady(...)Bands [30] | 1000  |   161.9 μs |   8.79 μs |   5.23 μs |  3.9063 |       - |  85.37 KB |
| **BuilderFull**       | **Trady(...)Bands [30]** | **10000** | **1,479.1 μs** | **199.28 μs** | **131.81 μs** | **70.3125** | **62.5000** | **1258.4 KB** |
| BuilderLatestOnly | Trady(...)Bands [30] | 10000 | 1,437.5 μs | 203.52 μs | 134.61 μs | 46.8750 | 23.4375 | 788.57 KB |
