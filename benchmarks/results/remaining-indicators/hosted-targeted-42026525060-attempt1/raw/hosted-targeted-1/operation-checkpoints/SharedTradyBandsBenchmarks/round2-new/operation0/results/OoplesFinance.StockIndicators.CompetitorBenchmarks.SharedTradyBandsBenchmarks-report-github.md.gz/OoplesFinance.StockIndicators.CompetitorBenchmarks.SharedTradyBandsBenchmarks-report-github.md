```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|---------:|---------:|------------:|------------:|
| **BuilderFull**       | **Trady(...)Bands [30]** | **1000**  |    **237.6 μs** |  **76.65 μs** |  **50.70 μs** |  **0.13** |    **0.03** |    **7.8125** |        **-** |        **-** |   **133.01 KB** |        **0.09** |
| BuilderLatestOnly | Trady(...)Bands [30] | 1000  |    179.9 μs |  28.87 μs |  19.09 μs |  0.10 |    0.01 |    3.9063 |        - |        - |    85.37 KB |        0.05 |
| NativeSingle      | Trady(...)Bands [30] | 1000  |  1,764.2 μs |  14.47 μs |   8.61 μs |  1.00 |    0.01 |   93.7500 |  78.1250 |  46.8750 |  1554.23 KB |        1.00 |
| NativeParallel    | Trady(...)Bands [30] | 1000  |    858.1 μs |  17.70 μs |   9.26 μs |  0.49 |    0.01 |   93.7500 |  31.2500 |        - |  1567.77 KB |        1.01 |
|                   |                      |       |             |           |           |       |         |           |          |          |             |             |
| **BuilderFull**       | **Trady(...)Bands [30]** | **10000** |  **1,450.9 μs** | **211.03 μs** | **139.59 μs** |  **0.08** |    **0.01** |   **70.3125** |  **62.5000** |        **-** |   **1258.4 KB** |        **0.08** |
| BuilderLatestOnly | Trady(...)Bands [30] | 10000 |  1,407.9 μs | 140.95 μs |  93.23 μs |  0.08 |    0.01 |   46.8750 |  23.4375 |        - |   788.57 KB |        0.05 |
| NativeSingle      | Trady(...)Bands [30] | 10000 | 17,256.8 μs | 360.31 μs | 214.42 μs |  1.00 |    0.02 | 1166.6667 | 833.3333 | 666.6667 | 15128.96 KB |        1.00 |
| NativeParallel    | Trady(...)Bands [30] | 10000 | 11,743.6 μs | 895.05 μs | 532.63 μs |  0.68 |    0.03 | 1222.2222 | 888.8889 | 666.6667 | 15357.06 KB |        1.02 |
