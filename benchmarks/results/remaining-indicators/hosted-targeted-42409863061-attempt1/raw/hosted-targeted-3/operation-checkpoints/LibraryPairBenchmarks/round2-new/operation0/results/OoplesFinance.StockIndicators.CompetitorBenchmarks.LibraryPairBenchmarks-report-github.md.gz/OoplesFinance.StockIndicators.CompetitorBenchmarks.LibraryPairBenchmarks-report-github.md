```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)ngTop [25]** | **105.86 μs** |  **7.580 μs** |  **4.511 μs** |  **1.00** |    **0.06** |  **67.02 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)ngTop [25] |  50.29 μs | 12.297 μs |  8.134 μs |  0.48 |    0.08 |  19.25 KB |        0.29 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)ngTop [25]** | **495.66 μs** | **57.005 μs** | **33.923 μs** |  **1.00** |    **0.09** | **640.25 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)ngTop [25] | 450.54 μs | 37.197 μs | 22.135 μs |  0.91 |    0.07 | 123.73 KB |        0.19 |
