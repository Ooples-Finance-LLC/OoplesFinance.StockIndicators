```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean      | Error     | StdDev   | Gen0   | Allocated |
|------------------ |------------ |------ |----------:|----------:|---------:|-------:|----------:|
| **BuilderFull**       | **SpinningTop** | **1000**  |  **76.67 μs** |  **2.962 μs** | **1.959 μs** |      **-** |  **58.24 KB** |
| BuilderLatestOnly | SpinningTop | 1000  |  63.76 μs |  2.548 μs | 1.686 μs |      - |  10.39 KB |
| **BuilderFull**       | **SpinningTop** | **10000** | **417.89 μs** | **14.113 μs** | **7.381 μs** | **3.9063** | **556.06 KB** |
| BuilderLatestOnly | SpinningTop | 10000 | 381.64 μs | 16.479 μs | 8.619 μs |      - |     86 KB |
