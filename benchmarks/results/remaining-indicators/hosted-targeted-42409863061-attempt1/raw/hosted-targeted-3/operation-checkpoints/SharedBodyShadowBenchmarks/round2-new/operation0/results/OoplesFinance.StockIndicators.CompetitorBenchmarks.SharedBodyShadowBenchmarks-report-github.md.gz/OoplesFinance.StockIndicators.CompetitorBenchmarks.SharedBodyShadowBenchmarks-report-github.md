```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |------------ |------ |----------:|----------:|----------:|------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **SpinningTop** | **1000**  |  **92.27 μs** |  **1.900 μs** |  **1.257 μs** |  **3.90** |    **0.12** |      **-** |  **58.93 KB** |       **14.99** |
| BuilderLatestOnly | SpinningTop | 1000  |  63.72 μs |  0.770 μs |  0.403 μs |  2.69 |    0.08 |      - |  11.05 KB |        2.81 |
| NativeSingle      | SpinningTop | 1000  |  23.68 μs |  1.079 μs |  0.714 μs |  1.00 |    0.04 |      - |   3.93 KB |        1.00 |
| NativeParallel    | SpinningTop | 1000  |  93.66 μs |  1.926 μs |  1.274 μs |  3.96 |    0.12 |      - |   4.22 KB |        1.07 |
|                   |             |       |           |           |           |       |         |        |           |             |
| **BuilderFull**       | **SpinningTop** | **10000** | **529.01 μs** | **57.780 μs** | **38.218 μs** |  **2.31** |    **0.16** | **3.9063** | **558.71 KB** |       **14.29** |
| BuilderLatestOnly | SpinningTop | 10000 | 405.89 μs | 18.062 μs |  9.447 μs |  1.78 |    0.04 |      - |  88.63 KB |        2.27 |
| NativeSingle      | SpinningTop | 10000 | 228.62 μs |  2.907 μs |  1.730 μs |  1.00 |    0.01 |      - |   39.1 KB |        1.00 |
| NativeParallel    | SpinningTop | 10000 | 200.92 μs |  4.204 μs |  2.199 μs |  0.88 |    0.01 |      - |  39.39 KB |        1.01 |
