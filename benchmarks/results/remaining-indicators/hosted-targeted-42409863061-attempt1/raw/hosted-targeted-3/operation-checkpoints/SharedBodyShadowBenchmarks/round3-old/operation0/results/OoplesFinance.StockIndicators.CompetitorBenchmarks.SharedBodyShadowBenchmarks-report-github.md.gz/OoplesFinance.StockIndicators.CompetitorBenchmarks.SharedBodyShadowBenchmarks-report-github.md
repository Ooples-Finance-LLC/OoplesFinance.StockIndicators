```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean      | Error    | StdDev   | Gen0   | Allocated |
|------------------ |------------ |------ |----------:|---------:|---------:|-------:|----------:|
| **BuilderFull**       | **SpinningTop** | **1000**  |  **68.08 μs** | **1.781 μs** | **1.178 μs** |      **-** |  **58.27 KB** |
| BuilderLatestOnly | SpinningTop | 1000  |  62.66 μs | 1.250 μs | 0.827 μs |      - |  10.39 KB |
| **BuilderFull**       | **SpinningTop** | **10000** | **412.35 μs** | **6.627 μs** | **3.466 μs** | **3.9063** | **556.09 KB** |
| BuilderLatestOnly | SpinningTop | 10000 | 378.18 μs | 7.356 μs | 3.847 μs |      - |     86 KB |
