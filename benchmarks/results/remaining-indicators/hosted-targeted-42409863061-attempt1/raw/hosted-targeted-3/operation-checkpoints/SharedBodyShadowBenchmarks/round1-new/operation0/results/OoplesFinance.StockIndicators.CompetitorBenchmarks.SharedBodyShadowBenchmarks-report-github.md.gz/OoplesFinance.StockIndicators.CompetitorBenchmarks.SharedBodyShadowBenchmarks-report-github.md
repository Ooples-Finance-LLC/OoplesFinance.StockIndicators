```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |------------ |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **SpinningTop** | **1000**  |  **71.01 μs** |  **1.392 μs** |  **0.728 μs** |      **-** |  **58.93 KB** |
| BuilderLatestOnly | SpinningTop | 1000  |  70.44 μs |  2.545 μs |  1.515 μs |      - |  11.05 KB |
| **BuilderFull**       | **SpinningTop** | **10000** | **435.84 μs** | **15.586 μs** |  **8.152 μs** | **3.9063** | **558.71 KB** |
| BuilderLatestOnly | SpinningTop | 10000 | 435.40 μs | 40.654 μs | 26.890 μs |      - |  88.63 KB |
