```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **LongLine**  | **1000**  | **156.2 μs** |  **0.64 μs** |  **0.38 μs** |       **-** |       **-** |  **58.32 KB** |
| BuilderLatestOnly | LongLine  | 1000  | 103.5 μs |  1.05 μs |  0.62 μs |       - |       - |   10.4 KB |
| **BuilderFull**       | **LongLine**  | **10000** | **670.2 μs** | **62.88 μs** | **41.59 μs** | **31.2500** | **11.7188** |  **556.1 KB** |
| BuilderLatestOnly | LongLine  | 10000 | 652.3 μs | 60.72 μs | 40.16 μs |  3.9063 |       - |     86 KB |
