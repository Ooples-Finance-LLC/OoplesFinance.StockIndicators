```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |----------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **LongLine**  | **1000**  |  **95.97 μs** |  **1.545 μs** |  **0.919 μs** |  **1.89** |    **0.02** |       **-** |      **-** |  **58.89 KB** |       **14.97** |
| BuilderLatestOnly | LongLine  | 1000  |  94.02 μs |  0.273 μs |  0.163 μs |  1.85 |    0.00 |  0.4883 |      - |  11.05 KB |        2.81 |
| NativeSingle      | LongLine  | 1000  |  50.75 μs |  0.147 μs |  0.077 μs |  1.00 |    0.00 |       - |      - |   3.93 KB |        1.00 |
| NativeParallel    | LongLine  | 1000  | 117.75 μs |  6.099 μs |  3.629 μs |  2.32 |    0.07 |       - |      - |   4.23 KB |        1.07 |
|                   |           |       |           |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **LongLine**  | **10000** | **602.09 μs** | **56.383 μs** | **37.294 μs** |  **1.17** |    **0.07** | **31.2500** | **7.8125** | **558.69 KB** |       **14.28** |
| BuilderLatestOnly | LongLine  | 10000 | 555.90 μs |  6.288 μs |  3.289 μs |  1.08 |    0.01 |  3.9063 |      - |  88.63 KB |        2.27 |
| NativeSingle      | LongLine  | 10000 | 516.27 μs |  3.019 μs |  1.796 μs |  1.00 |    0.00 |       - |      - |  39.12 KB |        1.00 |
| NativeParallel    | LongLine  | 10000 | 368.04 μs | 36.357 μs | 24.048 μs |  0.71 |    0.04 |  1.9531 |      - |  39.39 KB |        1.01 |
