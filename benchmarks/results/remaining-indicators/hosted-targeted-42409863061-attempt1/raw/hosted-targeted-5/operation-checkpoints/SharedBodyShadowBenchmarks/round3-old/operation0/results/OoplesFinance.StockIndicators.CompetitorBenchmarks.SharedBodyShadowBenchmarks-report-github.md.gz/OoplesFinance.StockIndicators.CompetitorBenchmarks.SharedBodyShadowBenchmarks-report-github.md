```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **LongLine**  | **1000**  | **151.8 μs** |  **1.70 μs** |  **0.89 μs** |       **-** |       **-** |  **58.32 KB** |
| BuilderLatestOnly | LongLine  | 1000  | 102.8 μs |  0.39 μs |  0.20 μs |       - |       - |   10.4 KB |
| **BuilderFull**       | **LongLine**  | **10000** | **648.4 μs** | **61.85 μs** | **40.91 μs** | **31.2500** | **11.7188** |  **556.1 KB** |
| BuilderLatestOnly | LongLine  | 10000 | 623.4 μs | 57.36 μs | 34.13 μs |       - |       - |  86.03 KB |
