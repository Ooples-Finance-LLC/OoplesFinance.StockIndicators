```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)gLine [22]** | **133.46 μs** | **14.639 μs** |  **8.712 μs** |  **1.00** |    **0.09** |  **67.02 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)gLine [22] |  90.45 μs |  1.174 μs |  0.614 μs |  0.68 |    0.04 |  19.63 KB |        0.29 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)gLine [22]** | **623.11 μs** | **46.978 μs** | **24.570 μs** |  **1.00** |    **0.05** | **640.25 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)gLine [22] | 905.88 μs | 29.554 μs | 19.548 μs |  1.46 |    0.06 | 125.09 KB |        0.20 |
