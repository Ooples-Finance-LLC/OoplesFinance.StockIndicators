```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean     | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |---------- |------ |---------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **ShortLine** | **1000**  | **125.0 μs** |  **2.63 μs** |  **1.56 μs** |       **-** |      **-** |  **58.28 KB** |
| BuilderLatestOnly | ShortLine | 1000  | 101.1 μs |  1.54 μs |  0.92 μs |       - |      - |   10.4 KB |
| **BuilderFull**       | **ShortLine** | **10000** | **681.1 μs** | **92.50 μs** | **61.19 μs** | **19.5313** | **7.8125** | **556.09 KB** |
| BuilderLatestOnly | ShortLine | 10000 | 671.7 μs | 86.11 μs | 56.96 μs |       - |      - |     86 KB |
