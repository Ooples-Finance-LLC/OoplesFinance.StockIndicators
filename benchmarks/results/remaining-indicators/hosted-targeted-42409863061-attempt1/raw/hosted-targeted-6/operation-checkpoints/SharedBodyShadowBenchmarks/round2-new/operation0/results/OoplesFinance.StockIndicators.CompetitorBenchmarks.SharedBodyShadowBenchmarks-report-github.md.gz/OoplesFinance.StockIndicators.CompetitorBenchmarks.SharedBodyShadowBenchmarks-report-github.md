```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |----------:|-----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **ShortLine** | **1000**  | **108.39 μs** |   **9.278 μs** |  **5.521 μs** |  **2.20** |    **0.11** |       **-** |      **-** |  **58.89 KB** |       **14.97** |
| BuilderLatestOnly | ShortLine | 1000  |  93.37 μs |   2.533 μs |  1.675 μs |  1.89 |    0.04 |       - |      - |  11.05 KB |        2.81 |
| NativeSingle      | ShortLine | 1000  |  49.32 μs |   0.857 μs |  0.510 μs |  1.00 |    0.01 |       - |      - |   3.93 KB |        1.00 |
| NativeParallel    | ShortLine | 1000  | 108.24 μs |  11.337 μs |  6.746 μs |  2.19 |    0.13 |       - |      - |   4.23 KB |        1.07 |
|                   |           |       |           |            |           |       |         |         |        |           |             |
| **BuilderFull**       | **ShortLine** | **10000** | **656.69 μs** | **145.368 μs** | **96.152 μs** |  **1.23** |    **0.17** | **15.6250** | **7.8125** | **558.71 KB** |       **14.28** |
| BuilderLatestOnly | ShortLine | 10000 | 604.53 μs | 126.978 μs | 83.988 μs |  1.13 |    0.15 |       - |      - |  88.63 KB |        2.27 |
| NativeSingle      | ShortLine | 10000 | 533.73 μs |   3.841 μs |  2.009 μs |  1.00 |    0.01 |       - |      - |  39.12 KB |        1.00 |
| NativeParallel    | ShortLine | 10000 | 371.80 μs |  58.404 μs | 38.631 μs |  0.70 |    0.07 |       - |      - |  39.41 KB |        1.01 |
