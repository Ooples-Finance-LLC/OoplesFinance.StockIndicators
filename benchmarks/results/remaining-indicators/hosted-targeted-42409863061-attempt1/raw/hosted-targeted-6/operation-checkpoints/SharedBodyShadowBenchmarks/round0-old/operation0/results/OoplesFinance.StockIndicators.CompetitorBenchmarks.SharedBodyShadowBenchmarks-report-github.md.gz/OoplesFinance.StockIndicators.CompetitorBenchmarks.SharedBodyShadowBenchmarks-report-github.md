```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0    | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **ShortLine** | **1000**  | **106.04 μs** |  **4.994 μs** |  **2.612 μs** |       **-** |  **58.28 KB** |
| BuilderLatestOnly | ShortLine | 1000  |  99.11 μs |  1.257 μs |  0.748 μs |       - |   10.4 KB |
| **BuilderFull**       | **ShortLine** | **10000** | **666.28 μs** | **20.185 μs** | **10.557 μs** | **15.6250** | **556.13 KB** |
| BuilderLatestOnly | ShortLine | 10000 | 658.35 μs | 82.487 μs | 54.560 μs |       - |     86 KB |
