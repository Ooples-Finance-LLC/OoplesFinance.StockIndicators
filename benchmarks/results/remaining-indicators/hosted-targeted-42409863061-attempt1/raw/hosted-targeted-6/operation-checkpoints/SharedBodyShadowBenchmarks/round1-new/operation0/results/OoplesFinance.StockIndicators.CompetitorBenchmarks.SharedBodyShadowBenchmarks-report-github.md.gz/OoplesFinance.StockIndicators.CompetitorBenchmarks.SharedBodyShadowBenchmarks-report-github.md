```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **ShortLine** | **1000**  |  **89.35 μs** |  **0.889 μs** |  **0.529 μs** |       **-** |      **-** |  **58.93 KB** |
| BuilderLatestOnly | ShortLine | 1000  |  90.18 μs |  0.388 μs |  0.257 μs |       - |      - |  11.05 KB |
| **BuilderFull**       | **ShortLine** | **10000** | **611.03 μs** | **93.877 μs** | **55.865 μs** | **19.5313** | **3.9063** | **558.72 KB** |
| BuilderLatestOnly | ShortLine | 10000 | 537.87 μs | 57.937 μs | 38.322 μs |       - |      - |  88.63 KB |
