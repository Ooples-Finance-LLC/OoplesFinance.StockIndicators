```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tLine [23]** | **296.80 μs** | **151.757 μs** | **100.378 μs** |  **1.09** |    **0.48** |  **67.02 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tLine [23] |  88.56 μs |   3.994 μs |   2.377 μs |  0.33 |    0.09 |  18.97 KB |        0.28 |
|            |       |                      |           |            |            |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)tLine [23]** | **700.22 μs** |  **54.382 μs** |  **32.362 μs** |  **1.00** |    **0.06** | **640.25 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tLine [23] | 839.86 μs |  31.219 μs |  20.649 μs |  1.20 |    0.06 | 125.09 KB |        0.20 |
