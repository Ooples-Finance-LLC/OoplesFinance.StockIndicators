```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev   | Allocated |
|------------------ |---------- |------ |----------:|----------:|---------:|----------:|
| **BuilderFull**       | **BeltHold**  | **1000**  |  **81.66 μs** |  **0.705 μs** | **0.419 μs** |  **58.93 KB** |
| BuilderLatestOnly | BeltHold  | 1000  |  76.59 μs |  0.864 μs | 0.514 μs |  11.05 KB |
| **BuilderFull**       | **BeltHold**  | **10000** | **474.29 μs** | **14.926 μs** | **7.807 μs** | **558.68 KB** |
| BuilderLatestOnly | BeltHold  | 10000 | 461.73 μs | 11.485 μs | 6.007 μs |  88.63 KB |
