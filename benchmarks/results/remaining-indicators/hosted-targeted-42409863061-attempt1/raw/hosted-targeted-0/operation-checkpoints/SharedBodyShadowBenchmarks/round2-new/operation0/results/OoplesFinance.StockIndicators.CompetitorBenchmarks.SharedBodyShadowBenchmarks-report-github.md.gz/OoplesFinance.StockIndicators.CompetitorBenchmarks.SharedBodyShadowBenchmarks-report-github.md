```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |----------:|----------:|----------:|------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **BeltHold**  | **1000**  |  **80.32 μs** |  **1.172 μs** |  **0.613 μs** |  **2.01** |    **0.02** |      **-** |  **58.93 KB** |       **14.99** |
| BuilderLatestOnly | BeltHold  | 1000  |  77.25 μs |  0.788 μs |  0.412 μs |  1.93 |    0.02 |      - |  11.05 KB |        2.81 |
| NativeSingle      | BeltHold  | 1000  |  39.94 μs |  0.530 μs |  0.316 μs |  1.00 |    0.01 |      - |   3.93 KB |        1.00 |
| NativeParallel    | BeltHold  | 1000  |  80.16 μs |  4.727 μs |  3.126 μs |  2.01 |    0.08 |      - |   4.22 KB |        1.07 |
|                   |           |       |           |           |           |       |         |        |           |             |
| **BuilderFull**       | **BeltHold**  | **10000** | **475.18 μs** |  **9.968 μs** |  **5.213 μs** |  **1.19** |    **0.01** | **3.9063** | **558.71 KB** |       **14.28** |
| BuilderLatestOnly | BeltHold  | 10000 | 498.76 μs | 66.699 μs | 44.117 μs |  1.24 |    0.11 |      - |  88.63 KB |        2.27 |
| NativeSingle      | BeltHold  | 10000 | 400.96 μs |  3.735 μs |  1.954 μs |  1.00 |    0.01 |      - |  39.12 KB |        1.00 |
| NativeParallel    | BeltHold  | 10000 | 303.51 μs | 29.655 μs | 19.615 μs |  0.76 |    0.05 |      - |  39.39 KB |        1.01 |
