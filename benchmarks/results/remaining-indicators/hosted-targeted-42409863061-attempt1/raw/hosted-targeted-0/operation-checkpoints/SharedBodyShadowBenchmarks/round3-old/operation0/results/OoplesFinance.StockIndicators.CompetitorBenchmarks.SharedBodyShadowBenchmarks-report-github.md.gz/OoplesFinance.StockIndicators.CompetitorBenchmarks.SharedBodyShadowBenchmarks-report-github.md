```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **BeltHold**  | **1000**  |  **76.96 μs** |  **2.366 μs** |  **1.408 μs** |      **-** |  **58.27 KB** |
| BuilderLatestOnly | BeltHold  | 1000  |  70.91 μs |  0.667 μs |  0.349 μs |      - |  10.39 KB |
| **BuilderFull**       | **BeltHold**  | **10000** | **500.87 μs** | **60.846 μs** | **40.246 μs** | **3.9063** | **556.09 KB** |
| BuilderLatestOnly | BeltHold  | 10000 | 445.33 μs | 59.851 μs | 39.588 μs |      - |     86 KB |
