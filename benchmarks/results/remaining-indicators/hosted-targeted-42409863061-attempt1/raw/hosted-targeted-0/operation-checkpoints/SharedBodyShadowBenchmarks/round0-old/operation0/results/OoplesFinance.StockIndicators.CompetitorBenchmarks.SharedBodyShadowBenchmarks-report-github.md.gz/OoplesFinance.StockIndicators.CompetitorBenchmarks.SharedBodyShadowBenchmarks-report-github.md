```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **BeltHold**  | **1000**  |  **76.47 μs** |  **0.905 μs** |  **0.474 μs** |      **-** |  **58.27 KB** |
| BuilderLatestOnly | BeltHold  | 1000  |  70.40 μs |  0.473 μs |  0.282 μs |      - |  10.39 KB |
| **BuilderFull**       | **BeltHold**  | **10000** | **483.01 μs** |  **9.678 μs** |  **5.062 μs** | **3.9063** | **556.09 KB** |
| BuilderLatestOnly | BeltHold  | 10000 | 479.09 μs | 54.432 μs | 36.004 μs |      - |     86 KB |
