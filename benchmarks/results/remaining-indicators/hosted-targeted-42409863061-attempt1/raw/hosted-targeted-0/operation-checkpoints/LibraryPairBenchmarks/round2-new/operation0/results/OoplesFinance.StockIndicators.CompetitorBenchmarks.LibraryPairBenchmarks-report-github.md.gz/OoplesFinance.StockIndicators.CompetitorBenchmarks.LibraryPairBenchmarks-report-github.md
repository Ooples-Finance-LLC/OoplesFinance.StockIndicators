```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tHold [22]** | **110.02 μs** |   **9.863 μs** |   **5.870 μs** |  **1.00** |    **0.07** |  **67.02 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tHold [22] |  70.40 μs |  17.213 μs |  11.385 μs |  0.64 |    0.10 |  15.36 KB |        0.23 |
|            |       |                      |           |            |            |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)tHold [22]** | **773.46 μs** | **191.713 μs** | **126.806 μs** |  **1.03** |    **0.26** | **640.25 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tHold [22] | 596.45 μs |  32.089 μs |  21.225 μs |  0.79 |    0.15 | 123.45 KB |        0.19 |
