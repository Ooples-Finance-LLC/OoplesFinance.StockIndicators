```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |----------:|----------:|----------:|------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **HighWave**  | **1000**  |  **69.84 μs** |  **2.288 μs** |  **1.197 μs** |  **1.68** |    **0.03** |      **-** |  **58.93 KB** |       **14.99** |
| BuilderLatestOnly | HighWave  | 1000  |  82.90 μs |  2.160 μs |  1.286 μs |  2.00 |    0.03 |      - |  11.05 KB |        2.81 |
| NativeSingle      | HighWave  | 1000  |  41.47 μs |  0.272 μs |  0.142 μs |  1.00 |    0.00 |      - |   3.93 KB |        1.00 |
| NativeParallel    | HighWave  | 1000  |  82.06 μs |  5.012 μs |  3.315 μs |  1.98 |    0.08 |      - |   4.22 KB |        1.07 |
|                   |           |       |           |           |           |       |         |        |           |             |
| **BuilderFull**       | **HighWave**  | **10000** | **422.79 μs** | **34.497 μs** | **20.529 μs** |  **1.02** |    **0.05** | **3.9063** | **558.71 KB** |       **14.28** |
| BuilderLatestOnly | HighWave  | 10000 | 384.84 μs | 23.970 μs | 12.537 μs |  0.93 |    0.03 |      - |  88.63 KB |        2.27 |
| NativeSingle      | HighWave  | 10000 | 414.45 μs |  4.863 μs |  2.894 μs |  1.00 |    0.01 |      - |  39.12 KB |        1.00 |
| NativeParallel    | HighWave  | 10000 | 288.68 μs | 34.989 μs | 23.143 μs |  0.70 |    0.05 |      - |  39.39 KB |        1.01 |
