```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **HighWave**  | **1000**  |  **68.12 μs** |  **1.306 μs** |  **0.777 μs** |      **-** |  **58.93 KB** |
| BuilderLatestOnly | HighWave  | 1000  |  65.21 μs |  1.641 μs |  1.086 μs |      - |  11.05 KB |
| **BuilderFull**       | **HighWave**  | **10000** | **471.77 μs** | **31.843 μs** | **18.949 μs** | **3.9063** | **558.71 KB** |
| BuilderLatestOnly | HighWave  | 10000 | 368.51 μs |  9.982 μs |  5.221 μs |      - |  88.63 KB |
