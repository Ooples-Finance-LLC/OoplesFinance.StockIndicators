```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **HighWave**  | **1000**  |  **69.53 μs** |  **0.623 μs** |  **0.371 μs** |      **-** |  **58.27 KB** |
| BuilderLatestOnly | HighWave  | 1000  |  62.84 μs |  0.476 μs |  0.249 μs |      - |  10.39 KB |
| **BuilderFull**       | **HighWave**  | **10000** | **417.75 μs** | **26.319 μs** | **13.765 μs** | **3.9063** | **556.09 KB** |
| BuilderLatestOnly | HighWave  | 10000 | 374.68 μs |  8.285 μs |  4.333 μs |      - |     86 KB |
