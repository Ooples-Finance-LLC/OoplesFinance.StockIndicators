```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **HighWave**  | **1000**  |  **69.13 μs** |  **0.600 μs** |  **0.357 μs** |      **-** |  **58.27 KB** |
| BuilderLatestOnly | HighWave  | 1000  |  81.82 μs |  0.567 μs |  0.297 μs |      - |  10.39 KB |
| **BuilderFull**       | **HighWave**  | **10000** | **421.63 μs** | **19.010 μs** |  **9.942 μs** | **3.9063** | **556.09 KB** |
| BuilderLatestOnly | HighWave  | 10000 | 396.23 μs | 35.058 μs | 23.188 μs |      - |  85.98 KB |
