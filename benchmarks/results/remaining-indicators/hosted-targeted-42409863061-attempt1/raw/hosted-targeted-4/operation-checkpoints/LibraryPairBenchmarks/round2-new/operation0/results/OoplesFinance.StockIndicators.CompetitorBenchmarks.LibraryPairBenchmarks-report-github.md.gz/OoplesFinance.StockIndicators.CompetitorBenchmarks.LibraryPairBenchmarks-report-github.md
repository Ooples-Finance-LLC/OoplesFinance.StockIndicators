```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)hWave [22]** | **154.08 μs** | **37.727 μs** | **24.954 μs** |  **1.02** |    **0.22** |  **67.05 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)hWave [22] |  71.72 μs |  1.408 μs |  0.838 μs |  0.48 |    0.07 |  19.63 KB |        0.29 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)hWave [22]** | **474.97 μs** | **38.957 μs** | **23.183 μs** |  **1.00** |    **0.07** | **640.25 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)hWave [22] | 711.81 μs | 24.282 μs | 16.061 μs |  1.50 |    0.08 | 123.78 KB |        0.19 |
