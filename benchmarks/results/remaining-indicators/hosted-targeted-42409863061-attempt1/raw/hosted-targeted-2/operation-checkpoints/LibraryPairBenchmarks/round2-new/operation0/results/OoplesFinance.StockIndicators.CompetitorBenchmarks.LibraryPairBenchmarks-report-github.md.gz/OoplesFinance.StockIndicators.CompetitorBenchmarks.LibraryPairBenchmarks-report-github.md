```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)ubozu [29]** | **126.88 μs** | **34.346 μs** | **22.717 μs** |  **1.03** |    **0.23** |  **67.02 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)ubozu [29] |  61.93 μs |  2.412 μs |  1.435 μs |  0.50 |    0.07 |   19.3 KB |        0.29 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)ubozu [29]** | **537.61 μs** | **31.962 μs** | **19.020 μs** |  **1.00** |    **0.05** | **640.25 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)ubozu [29] | 603.98 μs | 23.578 μs | 15.596 μs |  1.12 |    0.05 | 124.44 KB |        0.19 |
