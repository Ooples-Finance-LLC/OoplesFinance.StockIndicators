```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |---------------- |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **ClosingMarubozu** | **1000**  | **102.40 μs** |  **2.258 μs** |  **1.344 μs** |      **-** |  **58.93 KB** |
| BuilderLatestOnly | ClosingMarubozu | 1000  |  76.93 μs |  0.455 μs |  0.301 μs |      - |  11.05 KB |
| **BuilderFull**       | **ClosingMarubozu** | **10000** | **568.40 μs** | **61.693 μs** | **40.806 μs** | **3.9063** | **558.71 KB** |
| BuilderLatestOnly | ClosingMarubozu | 10000 | 447.67 μs |  5.285 μs |  2.764 μs |      - |  88.63 KB |
