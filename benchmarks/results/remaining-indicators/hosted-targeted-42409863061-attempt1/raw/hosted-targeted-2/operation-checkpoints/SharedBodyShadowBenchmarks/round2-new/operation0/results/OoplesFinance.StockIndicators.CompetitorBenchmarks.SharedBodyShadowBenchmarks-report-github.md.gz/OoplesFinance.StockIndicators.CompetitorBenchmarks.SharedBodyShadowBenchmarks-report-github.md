```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |---------------- |------ |----------:|----------:|----------:|------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **ClosingMarubozu** | **1000**  | **104.23 μs** |  **0.957 μs** |  **0.569 μs** |  **2.32** |    **0.25** |      **-** |  **58.93 KB** |       **14.98** |
| BuilderLatestOnly | ClosingMarubozu | 1000  |  94.72 μs |  0.493 μs |  0.258 μs |  2.11 |    0.23 |      - |  11.05 KB |        2.81 |
| NativeSingle      | ClosingMarubozu | 1000  |  45.40 μs |  8.420 μs |  5.570 μs |  1.01 |    0.16 |      - |   3.93 KB |        1.00 |
| NativeParallel    | ClosingMarubozu | 1000  |  84.01 μs |  8.932 μs |  5.908 μs |  1.87 |    0.24 |      - |   4.22 KB |        1.07 |
|                   |                 |       |           |           |           |       |         |        |           |             |
| **BuilderFull**       | **ClosingMarubozu** | **10000** | **497.60 μs** | **44.169 μs** | **26.284 μs** |  **1.17** |    **0.06** | **3.9063** | **558.71 KB** |       **14.28** |
| BuilderLatestOnly | ClosingMarubozu | 10000 | 498.99 μs | 17.591 μs |  9.201 μs |  1.17 |    0.02 |      - |  88.63 KB |        2.27 |
| NativeSingle      | ClosingMarubozu | 10000 | 424.79 μs |  9.152 μs |  5.446 μs |  1.00 |    0.02 |      - |  39.12 KB |        1.00 |
| NativeParallel    | ClosingMarubozu | 10000 | 290.14 μs | 41.980 μs | 27.767 μs |  0.68 |    0.06 |      - |  39.39 KB |        1.01 |
