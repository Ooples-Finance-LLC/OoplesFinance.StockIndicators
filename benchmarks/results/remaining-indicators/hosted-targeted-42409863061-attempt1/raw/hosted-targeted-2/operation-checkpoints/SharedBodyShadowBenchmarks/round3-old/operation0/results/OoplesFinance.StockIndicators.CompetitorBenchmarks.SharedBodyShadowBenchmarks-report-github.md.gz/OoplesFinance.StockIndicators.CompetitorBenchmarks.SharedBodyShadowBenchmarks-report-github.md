```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |---------------- |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **ClosingMarubozu** | **1000**  |  **79.65 μs** |  **0.826 μs** |  **0.492 μs** |      **-** |  **58.27 KB** |
| BuilderLatestOnly | ClosingMarubozu | 1000  |  74.65 μs |  0.753 μs |  0.448 μs |      - |  10.39 KB |
| **BuilderFull**       | **ClosingMarubozu** | **10000** | **535.46 μs** | **59.093 μs** | **39.086 μs** | **3.9063** | **556.09 KB** |
| BuilderLatestOnly | ClosingMarubozu | 10000 | 483.24 μs | 31.123 μs | 16.278 μs |      - |     86 KB |
