```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |----------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **Marubozu**  | **1000**  |  **94.57 μs** |  **0.631 μs** |  **0.330 μs** |  **1.91** |    **0.01** |       **-** |      **-** |  **58.93 KB** |       **14.98** |
| BuilderLatestOnly | Marubozu  | 1000  |  90.35 μs |  0.632 μs |  0.418 μs |  1.83 |    0.01 |       - |      - |  11.05 KB |        2.81 |
| NativeSingle      | Marubozu  | 1000  |  49.50 μs |  0.208 μs |  0.109 μs |  1.00 |    0.00 |       - |      - |   3.93 KB |        1.00 |
| NativeParallel    | Marubozu  | 1000  | 113.13 μs |  4.110 μs |  2.719 μs |  2.29 |    0.05 |       - |      - |   4.23 KB |        1.07 |
|                   |           |       |           |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **Marubozu**  | **10000** | **597.18 μs** | **57.645 μs** | **38.128 μs** |  **1.22** |    **0.07** | **31.2500** | **7.8125** | **558.72 KB** |       **14.28** |
| BuilderLatestOnly | Marubozu  | 10000 | 559.80 μs | 51.830 μs | 30.843 μs |  1.15 |    0.06 |  3.9063 |      - |  88.63 KB |        2.27 |
| NativeSingle      | Marubozu  | 10000 | 488.06 μs |  3.075 μs |  1.830 μs |  1.00 |    0.01 |       - |      - |  39.12 KB |        1.00 |
| NativeParallel    | Marubozu  | 10000 | 348.12 μs | 25.199 μs | 16.668 μs |  0.71 |    0.03 |  1.9531 |      - |  39.39 KB |        1.01 |
