```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Marubozu**  | **1000**  |  **90.24 μs** |  **0.483 μs** | **0.288 μs** |       **-** |       **-** |  **58.28 KB** |
| BuilderLatestOnly | Marubozu  | 1000  |  90.63 μs | 10.179 μs | 6.733 μs |       - |       - |   10.4 KB |
| **BuilderFull**       | **Marubozu**  | **10000** | **552.38 μs** | **14.962 μs** | **7.826 μs** | **31.2500** | **11.7188** |  **556.1 KB** |
| BuilderLatestOnly | Marubozu  | 10000 | 526.66 μs | 17.874 μs | 9.348 μs |  3.9063 |       - |     86 KB |
