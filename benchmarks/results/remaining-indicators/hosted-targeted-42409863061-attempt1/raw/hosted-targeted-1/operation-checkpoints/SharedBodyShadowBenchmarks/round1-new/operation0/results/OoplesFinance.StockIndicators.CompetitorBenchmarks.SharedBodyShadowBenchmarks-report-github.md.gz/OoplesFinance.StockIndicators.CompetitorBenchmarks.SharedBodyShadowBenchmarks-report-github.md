```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **Marubozu**  | **1000**  |  **92.27 μs** |  **1.101 μs** |  **0.576 μs** |       **-** |      **-** |  **58.93 KB** |
| BuilderLatestOnly | Marubozu  | 1000  |  88.45 μs |  0.276 μs |  0.164 μs |       - |      - |  11.05 KB |
| **BuilderFull**       | **Marubozu**  | **10000** | **581.56 μs** | **52.201 μs** | **34.528 μs** | **31.2500** | **7.8125** | **558.72 KB** |
| BuilderLatestOnly | Marubozu  | 10000 | 585.10 μs | 55.130 μs | 36.465 μs |  3.9063 |      - |  88.63 KB |
