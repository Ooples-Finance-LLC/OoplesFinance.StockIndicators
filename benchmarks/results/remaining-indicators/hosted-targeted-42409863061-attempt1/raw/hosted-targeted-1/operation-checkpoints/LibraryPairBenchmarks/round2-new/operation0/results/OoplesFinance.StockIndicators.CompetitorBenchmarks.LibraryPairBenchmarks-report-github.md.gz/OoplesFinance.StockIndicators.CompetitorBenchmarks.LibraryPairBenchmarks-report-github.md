```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error      | StdDev     | Median    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|-----------:|-----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)ubozu [22]** | **150.46 μs** |  **12.167 μs** |   **7.240 μs** | **146.90 μs** |  **1.00** |    **0.06** |  **67.05 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)ubozu [22] |  85.36 μs |   3.069 μs |   1.605 μs |  84.75 μs |  0.57 |    0.03 |  19.25 KB |        0.29 |
|            |       |                      |           |            |            |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)ubozu [22]** | **713.43 μs** | **364.975 μs** | **241.408 μs** | **568.25 μs** |  **1.09** |    **0.45** | **639.92 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)ubozu [22] | 863.56 μs |  50.569 μs |  33.448 μs | 861.25 μs |  1.31 |    0.34 | 125.38 KB |        0.20 |
