```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=20000  

```
| Method | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Candles.Harami** |  **32.32 μs** |  **4.384 μs** | **2.609 μs** |  **1.01** |    **0.11** |  **68.31 KB** |        **1.00** |
|        |       |                      |           |           |          |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Candles.Harami** | **232.92 μs** | **11.132 μs** | **6.624 μs** |  **1.00** |    **0.04** | **636.39 KB** |        **1.00** |
