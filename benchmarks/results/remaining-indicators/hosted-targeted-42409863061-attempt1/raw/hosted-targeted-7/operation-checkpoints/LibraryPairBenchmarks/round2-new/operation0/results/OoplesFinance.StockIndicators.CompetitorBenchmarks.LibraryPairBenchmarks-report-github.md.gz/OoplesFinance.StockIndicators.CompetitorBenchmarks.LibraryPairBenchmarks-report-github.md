```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=20000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Candles.Harami** |  **31.19 μs** |  **2.572 μs** |  **1.345 μs** |  **1.00** |    **0.06** |   **68.3 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Candles.Harami |  38.72 μs |  1.095 μs |  0.651 μs |  1.24 |    0.05 |  15.69 KB |        0.23 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Candles.Harami** | **224.78 μs** | **12.526 μs** |  **6.551 μs** |  **1.00** |    **0.04** | **635.35 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Candles.Harami | 386.78 μs | 16.003 μs | 10.585 μs |  1.72 |    0.06 |  118.2 KB |        0.19 |
