```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib.Candles.Harami** | **1000**  |  **36.50 μs** |  **0.900 μs** |  **0.595 μs** |  **1.00** |    **0.02** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Harami | 1000  |  80.21 μs |  1.729 μs |  1.144 μs |  2.20 |    0.05 |  0.4883 |       - |    8.4 KB |        2.12 |
| BuilderFull       | TaLib.Candles.Harami | 1000  |  86.72 μs |  1.577 μs |  1.043 μs |  2.38 |    0.05 |  3.9063 |       - |   63.7 KB |       16.05 |
| BuilderLatestOnly | TaLib.Candles.Harami | 1000  |  84.21 μs |  2.870 μs |  1.501 μs |  2.31 |    0.05 |  0.9766 |       - |  15.81 KB |        3.98 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib.Candles.Harami** | **10000** | **268.95 μs** |  **3.066 μs** |  **1.825 μs** |  **1.00** |    **0.01** |  **1.9531** |       **-** |  **39.13 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Harami | 10000 | 213.53 μs | 24.421 μs | 16.153 μs |  0.79 |    0.06 |  5.8594 |       - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib.Candles.Harami | 10000 | 267.08 μs | 36.668 μs | 24.253 μs |  0.99 |    0.09 | 33.2031 | 13.6719 | 556.24 KB |       14.22 |
| BuilderLatestOnly | TaLib.Candles.Harami | 10000 | 240.81 μs | 16.292 μs | 10.776 μs |  0.90 |    0.04 |  3.9063 |       - |  86.14 KB |        2.20 |
