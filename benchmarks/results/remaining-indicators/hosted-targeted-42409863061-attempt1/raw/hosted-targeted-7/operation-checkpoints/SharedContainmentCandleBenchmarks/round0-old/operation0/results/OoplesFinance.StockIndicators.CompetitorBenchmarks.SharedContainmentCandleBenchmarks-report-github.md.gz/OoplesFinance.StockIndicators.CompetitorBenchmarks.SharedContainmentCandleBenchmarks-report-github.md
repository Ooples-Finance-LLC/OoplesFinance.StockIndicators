```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Candles.Harami** | **1000**  |  **90.01 μs** |  **2.381 μs** |  **1.245 μs** |  **3.9063** |       **-** |  **63.69 KB** |
| BuilderLatestOnly | TaLib.Candles.Harami | 1000  |  86.48 μs |  3.111 μs |  1.851 μs |  0.9766 |       - |  15.81 KB |
| **BuilderFull**       | **TaLib.Candles.Harami** | **10000** | **257.42 μs** |  **8.166 μs** |  **4.860 μs** | **33.2031** | **13.6719** | **556.24 KB** |
| BuilderLatestOnly | TaLib.Candles.Harami | 10000 | 248.28 μs | 17.106 μs | 11.314 μs |  3.9063 |       - |  86.13 KB |
