```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Candles.Harami** | **1000**  |  **87.89 μs** |  **3.203 μs** | **1.906 μs** |  **3.9063** |       **-** |  **63.69 KB** |
| BuilderLatestOnly | TaLib.Candles.Harami | 1000  |  85.00 μs |  3.336 μs | 2.207 μs |  0.9766 |       - |  15.81 KB |
| **BuilderFull**       | **TaLib.Candles.Harami** | **10000** | **240.95 μs** |  **8.903 μs** | **5.298 μs** | **33.2031** | **13.6719** | **556.24 KB** |
| BuilderLatestOnly | TaLib.Candles.Harami | 10000 | 233.60 μs | 13.558 μs | 8.068 μs |  3.9063 |       - |  86.14 KB |
