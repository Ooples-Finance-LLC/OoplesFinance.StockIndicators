from pathlib import Path
import sys
import gzip,hashlib,json
ROOT=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
name='dpo-direct-difference'
RUN=f'local-{name}-control-20261023'
RAW=ROOT/RUN
REPO=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
OUT=REPO/'benchmarks/results/remaining-indicators'/RUN
summary=json.loads((RAW/'verified-summary.json').read_text(encoding='utf-8'))
count=16
assert summary[f'all_{count}_cases_verified']
proof=json.loads((RAW/'provenance.json').read_text(encoding='utf-8'))
accepted=not any(r['verdict']=='slower' for r in summary['decisions']) and any(r['verdict']=='faster' for r in summary['decisions'])
state=json.loads((RAW/'status.json').read_text(encoding='utf-8'))
paths=['status.json','provenance.json','binary-manifest.json','verified-summary.json']
paths += [Path(r['report']).relative_to(RAW).as_posix() for r in state['rounds']]
paths += [p.name for p in RAW.glob('*.log')]
OUT.mkdir(exist_ok=True)
manifest={}
for relative in paths:
 data=(RAW/relative).read_bytes();target=OUT/(relative+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(gzip.compress(data,mtime=0));manifest[relative]={'sha256':hashlib.sha256(data).hexdigest(),'archive':target.relative_to(REPO).as_posix()}
scripts={}
for script in [f'measure-{name}-control.py',f'verify-{name}-control.py']:
 data=(ROOT/script).read_bytes();(OUT/(script+'.gz')).write_bytes(gzip.compress(data,mtime=0));scripts[script]=hashlib.sha256(data).hexdigest()
(OUT/'decision.json').write_text(json.dumps({'status':'candidate-qualified-for-integration' if accepted else 'candidate-rejected-or-inconclusive','sources':summary['sources'],'candidate_code_source':proof['candidate_code_source'],'measurement_location':'Local Windows; preserved source-qualified binaries; only production DLL differs','decisions':summary['decisions'],'archives':manifest,'scripts':scripts,'report_imported':False,'production_integrated':False},indent=2)+'\n',encoding='utf-8',newline='\n')
(OUT/'.gitattributes').write_bytes(b'* -text\n')
print('Archived',count,'cases; qualified for integration:',accepted)
