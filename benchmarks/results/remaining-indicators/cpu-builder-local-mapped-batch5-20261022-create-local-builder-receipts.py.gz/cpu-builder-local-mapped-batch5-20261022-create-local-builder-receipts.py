from pathlib import Path
import json,re,subprocess,sys
ROOT=Path('C:/Users/cheat/StockIndicators-Recovery-20261021');REPO=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
run=sys.argv[1];assert re.fullmatch(r'[A-Za-z0-9-]+',run)
summary=json.loads((ROOT/run/'verified-summary.json').read_text(encoding='utf-8'));head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
manifest='benchmarks/results/remaining-indicators/'+run+'/manifest.json';subprocess.run(['git','cat-file','-e',head+':'+manifest],cwd=REPO,check=True)
url='https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/blob/'+head+'/'+manifest
out=REPO/'benchmarks/results/remaining-indicators';files=[]
for receipt in summary['receipts']:
 receipt['measurement_url']=url
 name='cpu-builder-'+run+'-'+receipt['fixture']+'.json';assert not (out/name).exists()
 (out/name).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8');files.append(name)
result={'run_id':run,'run_url':url,'source_sha':summary['source_sha'],'receipt_files':files,'comparisons':sum(len(r['comparisons']) for r in summary['receipts']),'verdicts':summary['verdicts'],'changed_production_files_since_baseline':['src/Helpers/CertifiedMeanRelativeError.cs','src/Indicators/CompensatedExponentialAverage.cs'],'measurement_location':'Local Windows; CPU builder and native paths; unchanged setup checks','raw_archive_commit':head}
result.update(partial=summary.get('partial',False),excluded_fixtures=summary.get('excluded_fixtures',[]))
(out/('cpu-builder-'+run+'-summary.json')).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print('Created matched receipts:',result['comparisons'],result['verdicts'])
