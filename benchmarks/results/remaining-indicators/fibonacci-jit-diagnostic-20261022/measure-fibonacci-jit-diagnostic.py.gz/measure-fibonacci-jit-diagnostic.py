from pathlib import Path
import datetime,hashlib,json,math,os,psutil,re,subprocess
ROOT=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
REPO=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
BIN=ROOT/'local-mapped-batch4-20261022/binaries'
OUT=ROOT/'fibonacci-jit-diagnostic-20261022';assert not OUT.exists()
qualification=json.loads((ROOT/'combined-certified-integration-20261022/status.json').read_text())
paths=['src','tests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','benchmarks/OoplesFinance.StockIndicators.CompetitorTests','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json']
assert not subprocess.check_output(['git','diff',qualification['input_head'],'HEAD','--',*paths],cwd=REPO)
def manifest():return {p.relative_to(BIN).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in BIN.rglob('*') if p.is_file()}
before=manifest();assert before['OoplesFinance.StockIndicators.dll'] in qualification['production_dll_sha256'].values()
keys=['DOTNET_TieredCompilation','COMPlus_TieredCompilation']
assert all(os.environ.get(k) in [None,'1'] for k in keys)
OUT.mkdir();state={'status':'starting','source_sha':qualification['input_head'],'order':['default','optimized','optimized','default'],'rounds':[],'scope':'Diagnostic only: same qualified binary, only tiered compilation settings differ. Not report replacement or new implementation qualification.','default_runtime_settings':{k:os.environ.get(k) for k in keys}}
(OUT/'binary-manifest.json').write_text(json.dumps(before,indent=2),encoding='utf-8')
def save():
 state['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(OUT/'status.json').write_text(json.dumps(state,indent=2),encoding='utf-8')
try:
 for index,arm in enumerate(state['order']):
  state.update(status='waiting-quiet-window',round=index,arm=arm);save();samples=[]
  while len(samples)<3 or max(samples[-3:])>15:
   builds=[p.pid for p in psutil.process_iter(['name','cmdline']) if (p.info['name'] or '').lower()=='dotnet.exe' and 'build' in (p.info['cmdline'] or [])]
   samples.append(psutil.cpu_percent(interval=5))
   if builds:samples=[]
  env=os.environ.copy();env['TEMP']=env['TMP']=str(ROOT/'temp')
  for k in ['COMPARISON_PAIR','COMPARISON_SHARD','COMPARISON_SHARDS']:env.pop(k,None)
  if arm=='optimized':
   for key in keys:env[key]='0'
  folder=OUT/f'round{index}-{arm}';state['status']='measuring';save()
  filters=[f'*LibraryPairBenchmarks.{m}*QuanTAlib.Fwma*' for m in ['Ooples','Competitor']]
  with folder.with_suffix('.log').open('wb') as log:subprocess.run(['dotnet',str(BIN/'OoplesFinance.StockIndicators.CompetitorBenchmarks.dll'),'--filter',*filters,'--warmupCount','10','--iterationCount','10','--exporters','json','--artifacts',str(folder)],cwd=BIN,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=300)
  files=list((folder/'results').glob('*-report-full-compressed.json'));assert len(files)==1;raw=files[0].read_bytes();report=json.loads(raw);cases={}
  for case in report['Benchmarks']:
   name=case['FullName'];assert 'QuanTAlib.Fwma' in name
   key=int(re.search(r'Bars: (\d+)',name)[1]),case['Method'];assert key not in cases
   stats=case['Statistics'];values=stats['OriginalValues'];assert len(values)==stats['N']>=7 and all(math.isfinite(v) and v>0 for v in values)
   assert math.isclose(sum(values)/len(values),stats['Mean'],rel_tol=1e-12)
   ci=stats['ConfidenceInterval'];assert math.isfinite(ci['Lower']) and math.isfinite(ci['Upper']) and ci['Lower']<=stats['Mean']<=ci['Upper']
   cases[key]={'bars':key[0],'method':key[1],'mean_ms':stats['Mean']/1e6,'lower_ms':ci['Lower']/1e6,'upper_ms':ci['Upper']/1e6,'samples':stats['N']}
  assert cases.keys()=={(n,m) for n in [1000,10000] for m in ['Ooples','Competitor']}
  state['rounds'].append({'index':index,'arm':arm,'quiet_cpu_samples':samples[-3:],'report':str(files[0]),'sha256':hashlib.sha256(raw).hexdigest(),'cases':list(cases.values()),'runtime_settings':{k:env.get(k) for k in keys}});save()
 assert manifest()==before
 state.update(status='diagnostic-complete-review-required',verified_cases=16);save();print(json.dumps(state['rounds']),flush=True)
except Exception as error:
 state.update(status='failed-preserved-for-inspection',error=repr(error));save();raise
