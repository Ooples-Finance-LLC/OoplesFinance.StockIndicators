```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)inOsc [21]** |   **278.85 μs** | **11.339 μs** |  **6.748 μs** |  **1.00** |    **0.03** |  **259.67 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)inOsc [21] |    58.21 μs |  3.835 μs |  2.006 μs |  0.21 |    0.01 |  486.98 KB |        1.88 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)inOsc [21]** | **2,620.05 μs** | **24.464 μs** | **16.181 μs** |  **1.00** |    **0.01** | **2545.16 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)inOsc [21] |   711.08 μs | 99.123 μs | 58.987 μs |  0.27 |    0.02 | 4849.97 KB |        1.91 |
