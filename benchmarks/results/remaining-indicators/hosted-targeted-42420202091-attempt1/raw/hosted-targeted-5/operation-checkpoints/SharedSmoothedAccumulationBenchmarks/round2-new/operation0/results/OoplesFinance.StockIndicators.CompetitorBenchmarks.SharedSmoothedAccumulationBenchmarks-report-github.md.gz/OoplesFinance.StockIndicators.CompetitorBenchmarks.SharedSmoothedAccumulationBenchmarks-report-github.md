```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **185.81 μs** |   **4.105 μs** |   **2.443 μs** |  **3.03** |    **0.05** |        **-** |        **-** |       **-** |   **97.02 KB** |        **0.26** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   183.78 μs |  12.986 μs |   7.728 μs |  3.00 |    0.12 |   1.9531 |        - |       - |   49.41 KB |        0.13 |
| NativeSingle      | Skend(...)inOsc [21] | 1000  |    61.34 μs |   0.931 μs |   0.554 μs |  1.00 |    0.01 |  22.9492 |   6.8359 |       - |   379.7 KB |        1.00 |
| NativeParallel    | Skend(...)inOsc [21] | 1000  |   159.83 μs |   9.368 μs |   5.575 μs |  2.61 |    0.09 |  59.5703 |  19.5313 |       - |  958.68 KB |        2.52 |
|                   |                      |       |             |            |            |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **1,896.82 μs** |  **68.435 μs** |  **45.265 μs** |  **2.38** |    **0.06** |  **46.8750** |  **15.6250** |       **-** |  **941.19 KB** |        **0.25** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 1,792.00 μs |  72.380 μs |  43.072 μs |  2.25 |    0.05 |  15.6250 |        - |       - |  471.37 KB |        0.12 |
| NativeSingle      | Skend(...)inOsc [21] | 10000 |   796.98 μs |  10.327 μs |   5.401 μs |  1.00 |    0.01 | 242.1875 | 148.4375 | 46.8750 | 3790.23 KB |        1.00 |
| NativeParallel    | Skend(...)inOsc [21] | 10000 | 2,131.07 μs | 200.377 μs | 119.241 μs |  2.67 |    0.14 | 593.7500 | 531.2500 | 78.1250 | 9555.11 KB |        2.52 |
