```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **175.7 μs** |  **2.78 μs** |  **1.65 μs** |       **-** |       **-** |  **97.02 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   171.0 μs |  1.46 μs |  0.87 μs |  1.9531 |       - |  49.41 KB |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **1,786.3 μs** | **22.75 μs** | **13.54 μs** | **46.8750** | **15.6250** | **941.18 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 1,772.5 μs | 42.15 μs | 25.08 μs | 15.6250 |       - | 471.32 KB |
