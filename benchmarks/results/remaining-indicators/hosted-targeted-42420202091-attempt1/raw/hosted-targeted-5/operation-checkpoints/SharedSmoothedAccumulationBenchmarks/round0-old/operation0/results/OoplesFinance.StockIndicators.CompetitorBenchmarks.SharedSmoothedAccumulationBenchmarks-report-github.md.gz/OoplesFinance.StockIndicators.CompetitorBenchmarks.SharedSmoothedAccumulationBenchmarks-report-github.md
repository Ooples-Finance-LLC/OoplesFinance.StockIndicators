```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **170.2 μs** | **16.49 μs** |  **9.81 μs** |       **-** |       **-** |  **97.02 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   164.0 μs |  7.18 μs |  4.75 μs |  1.9531 |       - |  49.42 KB |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **1,640.7 μs** | **44.46 μs** | **26.46 μs** | **46.8750** | **15.6250** | **941.17 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 1,675.8 μs | 38.55 μs | 22.94 μs | 15.6250 |       - | 471.35 KB |
