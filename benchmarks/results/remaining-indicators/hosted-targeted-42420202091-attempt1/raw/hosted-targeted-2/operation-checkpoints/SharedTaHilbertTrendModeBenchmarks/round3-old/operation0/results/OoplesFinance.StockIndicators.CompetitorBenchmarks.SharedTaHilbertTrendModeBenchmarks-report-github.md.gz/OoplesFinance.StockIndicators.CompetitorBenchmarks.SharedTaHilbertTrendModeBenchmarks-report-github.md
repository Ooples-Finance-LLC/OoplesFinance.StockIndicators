```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |   **741.0 μs** |   **6.81 μs** |   **3.56 μs** |   **71.6 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |   761.0 μs |  41.10 μs |  27.19 μs |  24.03 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **8,148.0 μs** | **540.96 μs** | **321.92 μs** | **634.47 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 8,396.9 μs | 678.29 μs | 403.64 μs | 164.66 KB |
