```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |   **753.9 μs** |   **4.53 μs** |  **2.69 μs** |  **72.05 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |   789.2 μs |   6.53 μs |  3.89 μs |  24.47 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **8,459.4 μs** | **189.46 μs** | **99.09 μs** | **635.17 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 8,115.3 μs |  36.01 μs | 18.84 μs | 165.42 KB |
