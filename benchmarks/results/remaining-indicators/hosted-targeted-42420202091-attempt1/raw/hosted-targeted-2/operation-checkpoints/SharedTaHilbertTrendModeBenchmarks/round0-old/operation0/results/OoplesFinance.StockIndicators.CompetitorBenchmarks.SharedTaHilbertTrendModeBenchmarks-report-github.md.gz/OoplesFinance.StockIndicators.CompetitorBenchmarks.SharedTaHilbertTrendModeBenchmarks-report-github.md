```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |   **736.3 μs** | **17.04 μs** | **11.27 μs** | **3.9063** |   **71.6 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |   738.4 μs | 23.28 μs | 15.40 μs |      - |  24.02 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **7,854.2 μs** | **60.89 μs** | **36.23 μs** |      **-** | **634.72 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 7,829.8 μs | 39.03 μs | 23.22 μs |      - | 164.96 KB |
