```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |   **738.1 μs** |   **2.83 μs** |  **1.69 μs** |  **1.99** |    **0.00** | **3.9063** |  **72.05 KB** |       **15.29** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |   734.5 μs |   3.55 μs |  2.11 μs |  1.98 |    0.01 |      - |  24.46 KB |        5.19 |
| NativeSingle      | TaLib(...)dMode [27] | 1000  |   370.4 μs |   0.62 μs |  0.32 μs |  1.00 |    0.00 |      - |   4.71 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 1000  |   531.9 μs |   9.32 μs |  4.88 μs |  1.44 |    0.01 |      - |  17.39 KB |        3.69 |
|                   |                      |       |            |           |          |       |         |        |           |             |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **7,906.7 μs** |  **34.90 μs** | **20.77 μs** |  **1.96** |    **0.01** |      **-** | **635.35 KB** |       **15.85** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 7,940.9 μs |  57.11 μs | 37.78 μs |  1.97 |    0.01 |      - | 165.69 KB |        4.13 |
| NativeSingle      | TaLib(...)dMode [27] | 10000 | 4,037.9 μs |  31.61 μs | 16.53 μs |  1.00 |    0.01 |      - |  40.07 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 10000 | 5,767.2 μs | 151.22 μs | 79.09 μs |  1.43 |    0.02 |      - |  140.6 KB |        3.51 |
