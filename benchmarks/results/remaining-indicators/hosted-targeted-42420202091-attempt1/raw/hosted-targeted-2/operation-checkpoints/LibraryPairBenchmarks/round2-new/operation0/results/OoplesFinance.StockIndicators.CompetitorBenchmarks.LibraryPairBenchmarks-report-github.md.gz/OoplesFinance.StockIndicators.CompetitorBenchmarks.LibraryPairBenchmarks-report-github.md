```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Median     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dMode [27]** |   **801.5 μs** |  **20.61 μs** |  **10.78 μs** |   **804.4 μs** |  **1.00** |    **0.02** |  **113.18 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dMode [27] |   556.4 μs | 348.70 μs | 230.65 μs |   403.4 μs |  0.69 |    0.27 |   37.85 KB |        0.33 |
|            |       |                      |            |           |           |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)dMode [27]** | **8,084.9 μs** |  **35.67 μs** |  **23.59 μs** | **8,088.3 μs** |  **1.00** |    **0.00** | **1036.36 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dMode [27] | 4,080.7 μs |  13.68 μs |   9.05 μs | 4,080.6 μs |  0.50 |    0.00 |  284.91 KB |        0.27 |
