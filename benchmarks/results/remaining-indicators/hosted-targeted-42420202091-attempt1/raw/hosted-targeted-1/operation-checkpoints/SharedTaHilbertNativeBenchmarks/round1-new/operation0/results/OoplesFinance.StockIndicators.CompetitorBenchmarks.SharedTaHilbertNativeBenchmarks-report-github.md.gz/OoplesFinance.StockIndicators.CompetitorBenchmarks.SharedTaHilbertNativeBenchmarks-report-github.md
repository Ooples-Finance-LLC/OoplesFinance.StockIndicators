```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **465.5 μs** |   **4.90 μs** |   **2.56 μs** |       **-** |  **85.28 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   462.9 μs |  13.44 μs |   8.00 μs |       - |  37.67 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **5,097.1 μs** | **202.99 μs** | **134.27 μs** | **31.2500** |  **788.9 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 5,138.6 μs | 273.86 μs | 181.14 μs |       - | 319.02 KB |
