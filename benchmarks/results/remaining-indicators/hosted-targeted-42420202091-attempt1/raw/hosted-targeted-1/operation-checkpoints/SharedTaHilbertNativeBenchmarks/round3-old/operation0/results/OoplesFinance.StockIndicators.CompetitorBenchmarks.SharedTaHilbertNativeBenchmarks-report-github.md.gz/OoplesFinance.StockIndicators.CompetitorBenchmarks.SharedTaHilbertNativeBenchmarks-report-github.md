```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **443.9 μs** |  **16.79 μs** |  **11.10 μs** |       **-** |  **84.83 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   437.9 μs |  24.28 μs |  14.45 μs |       - |  37.22 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **4,885.5 μs** | **157.24 μs** | **104.00 μs** | **31.2500** | **788.42 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 4,739.6 μs | 115.62 μs |  68.81 μs |       - | 318.64 KB |
