```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Ratio | RatioSD | Gen0    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **457.5 μs** |   **6.78 μs** |  **3.55 μs** |  **1.28** |    **0.02** |  **3.9063** |  **85.28 KB** |        **5.42** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   423.1 μs |   5.80 μs |  3.03 μs |  1.18 |    0.02 |       - |  37.68 KB |        2.40 |
| NativeSingle      | TaLib(...)tSine [22] | 1000  |   357.4 μs |   8.96 μs |  5.93 μs |  1.00 |    0.02 |       - |  15.72 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 1000  |   530.2 μs |  28.83 μs | 17.15 μs |  1.48 |    0.05 |       - |  55.96 KB |        3.56 |
|                   |                      |       |            |           |          |       |         |         |           |             |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **4,680.1 μs** | **119.64 μs** | **71.20 μs** |  **1.23** |    **0.02** | **31.2500** | **788.95 KB** |        **5.04** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 4,634.9 μs |  32.61 μs | 17.05 μs |  1.22 |    0.01 |       - | 319.07 KB |        2.04 |
| NativeSingle      | TaLib(...)tSine [22] | 10000 | 3,792.8 μs |  30.71 μs | 16.06 μs |  1.00 |    0.01 |       - | 156.46 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 10000 | 5,791.7 μs | 126.77 μs | 66.30 μs |  1.53 |    0.02 | 31.2500 | 548.35 KB |        3.50 |
