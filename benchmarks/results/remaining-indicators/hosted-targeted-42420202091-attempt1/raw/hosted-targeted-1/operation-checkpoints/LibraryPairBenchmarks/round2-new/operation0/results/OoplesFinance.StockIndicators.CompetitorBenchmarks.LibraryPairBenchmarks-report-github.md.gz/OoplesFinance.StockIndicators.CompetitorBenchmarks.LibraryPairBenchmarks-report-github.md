```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tSine [22]** |   **490.7 μs** | **22.39 μs** | **13.32 μs** |  **1.00** |    **0.04** |  **166.99 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tSine [22] |   377.2 μs |  6.24 μs |  3.71 μs |  0.77 |    0.02 |   66.73 KB |        0.40 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)tSine [22]** | **5,319.0 μs** | **96.50 μs** | **57.43 μs** |  **1.00** |    **0.01** | **1591.07 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tSine [22] | 3,952.8 μs | 50.62 μs | 33.48 μs |  0.74 |    0.01 |  646.48 KB |        0.41 |
