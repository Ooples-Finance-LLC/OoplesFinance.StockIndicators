```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **800.7 μs** |  **2.56 μs** |  **1.52 μs** |   **69.4 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   804.8 μs |  6.85 μs |  4.08 μs |  21.84 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **8,331.0 μs** | **22.12 μs** | **11.57 μs** | **632.86 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 8,353.9 μs | 43.45 μs | 22.73 μs | 163.05 KB |
