```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **801.1 μs** |   **4.11 μs** |  **2.15 μs** |  **68.95 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   797.4 μs |   8.35 μs |  4.97 μs |  21.39 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **8,341.9 μs** | **102.09 μs** | **60.75 μs** | **632.39 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 8,273.5 μs |  43.54 μs | 25.91 μs | 162.65 KB |
