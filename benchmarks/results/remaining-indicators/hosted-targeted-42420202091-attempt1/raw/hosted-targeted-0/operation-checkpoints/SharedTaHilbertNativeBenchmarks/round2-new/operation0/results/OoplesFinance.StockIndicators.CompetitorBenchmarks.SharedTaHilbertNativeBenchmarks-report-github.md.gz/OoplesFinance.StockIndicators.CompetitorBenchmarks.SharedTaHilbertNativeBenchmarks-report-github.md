```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **813.7 μs** |   **5.30 μs** |   **2.77 μs** |  **1.57** |    **0.01** |  **69.36 KB** |        **8.27** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   808.4 μs |   3.10 μs |   1.62 μs |  1.56 |    0.00 |  21.84 KB |        2.60 |
| NativeSingle      | TaLib(...)Phase [25] | 1000  |   518.1 μs |   1.75 μs |   1.16 μs |  1.00 |    0.00 |   8.39 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 1000  |   740.0 μs |  21.47 μs |  12.78 μs |  1.43 |    0.02 |  30.19 KB |        3.60 |
|                   |                      |       |            |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **8,511.1 μs** |  **83.92 μs** |  **49.94 μs** |  **1.51** |    **0.01** | **632.85 KB** |        **8.02** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 8,459.9 μs |  63.61 μs |  37.85 μs |  1.50 |    0.01 | 163.08 KB |        2.07 |
| NativeSingle      | TaLib(...)Phase [25] | 10000 | 5,624.5 μs |  24.07 μs |  12.59 μs |  1.00 |    0.00 |  78.92 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 10000 | 7,867.1 μs | 277.00 μs | 183.22 μs |  1.40 |    0.03 | 276.82 KB |        3.51 |
