```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **801.5 μs** |   **3.28 μs** |   **1.95 μs** |  **68.95 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   802.9 μs |   7.55 μs |   3.95 μs |  21.39 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **8,512.6 μs** | **173.16 μs** | **103.05 μs** | **632.46 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 8,305.0 μs |  35.22 μs |  20.96 μs | 162.58 KB |
