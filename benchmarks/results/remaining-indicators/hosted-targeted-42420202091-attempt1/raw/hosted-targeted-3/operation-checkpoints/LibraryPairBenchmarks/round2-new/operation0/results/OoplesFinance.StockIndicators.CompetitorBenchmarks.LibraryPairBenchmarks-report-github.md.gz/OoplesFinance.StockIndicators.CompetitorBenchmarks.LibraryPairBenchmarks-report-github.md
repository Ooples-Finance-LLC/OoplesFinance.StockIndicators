```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean         | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-------------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ad** |   **230.238 μs** |  **2.2965 μs** |  **1.2011 μs** |  **1.00** |    **0.01** |  **140.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ad |     4.211 μs |  0.4068 μs |  0.2421 μs |  0.02 |    0.00 |    8.76 KB |        0.06 |
|            |       |                    |              |            |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ad** | **1,570.560 μs** | **36.6068 μs** | **24.2131 μs** |  **1.00** |    **0.02** | **1714.36 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ad |    22.275 μs |  0.9574 μs |  0.5007 μs |  0.01 |    0.00 |   85.96 KB |        0.05 |
