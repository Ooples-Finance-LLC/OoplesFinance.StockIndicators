```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **329.3 μs** |  **9.67 μs** |  **5.06 μs** |       **-** |  **73.52 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   326.8 μs |  9.02 μs |  5.36 μs |       - |  25.92 KB |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **3,301.0 μs** | **42.13 μs** | **25.07 μs** | **31.2500** | **706.92 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 3,296.8 μs | 41.06 μs | 24.43 μs |       - | 237.09 KB |
