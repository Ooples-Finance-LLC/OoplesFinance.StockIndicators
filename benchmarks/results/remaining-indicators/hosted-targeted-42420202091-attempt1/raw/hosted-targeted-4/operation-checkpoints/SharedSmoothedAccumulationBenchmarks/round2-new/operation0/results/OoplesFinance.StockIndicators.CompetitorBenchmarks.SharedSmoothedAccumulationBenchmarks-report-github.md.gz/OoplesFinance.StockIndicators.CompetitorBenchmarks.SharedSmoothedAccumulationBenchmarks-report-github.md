```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **321.380 μs** |  **3.8245 μs** |  **2.2759 μs** | **97.69** |    **1.87** |       **-** |      **-** |  **73.52 KB** |        **9.42** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   319.770 μs |  1.8943 μs |  0.9908 μs | 97.20 |    1.77 |       - |      - |  25.91 KB |        3.32 |
| NativeSingle      | TaLib(...)AdOsc [21] | 1000  |     3.291 μs |  0.0928 μs |  0.0614 μs |  1.00 |    0.03 |  0.4578 |      - |    7.8 KB |        1.00 |
| NativeParallel    | TaLib(...)AdOsc [21] | 1000  |    91.265 μs |  2.3303 μs |  1.5413 μs | 27.74 |    0.67 |  1.9531 |      - |  27.57 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **3,243.380 μs** | **46.5271 μs** | **27.6876 μs** | **99.99** |    **1.12** | **31.2500** |      **-** | **706.91 KB** |        **9.05** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 3,108.755 μs | 12.7962 μs |  7.6148 μs | 95.84 |    0.78 |       - |      - | 236.96 KB |        3.03 |
| NativeSingle      | TaLib(...)AdOsc [21] | 10000 |    32.439 μs |  0.5117 μs |  0.2676 μs |  1.00 |    0.01 |  4.6387 |      - |  78.12 KB |        1.00 |
| NativeParallel    | TaLib(...)AdOsc [21] | 10000 |   137.229 μs |  6.9100 μs |  4.5705 μs |  4.23 |    0.14 | 17.5781 | 3.9063 | 273.66 KB |        3.50 |
