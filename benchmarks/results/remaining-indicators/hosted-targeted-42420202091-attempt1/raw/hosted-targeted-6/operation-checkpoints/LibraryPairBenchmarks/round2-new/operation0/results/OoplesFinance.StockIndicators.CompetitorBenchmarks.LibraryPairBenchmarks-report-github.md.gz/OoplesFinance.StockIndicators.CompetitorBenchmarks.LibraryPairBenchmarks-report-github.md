```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAdx** |   **998.5 μs** |  **35.51 μs** | **21.13 μs** |  **1.00** |    **0.03** |  **316.88 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAdx |   121.8 μs |   4.80 μs |  2.51 μs |  0.12 |    0.00 |  339.77 KB |        1.07 |
|            |       |                |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAdx** | **9,547.2 μs** | **125.86 μs** | **74.90 μs** |  **1.00** |    **0.01** | **3111.22 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAdx | 1,174.9 μs |  44.57 μs | 26.52 μs |  0.12 |    0.00 | 3300.41 KB |        1.06 |
