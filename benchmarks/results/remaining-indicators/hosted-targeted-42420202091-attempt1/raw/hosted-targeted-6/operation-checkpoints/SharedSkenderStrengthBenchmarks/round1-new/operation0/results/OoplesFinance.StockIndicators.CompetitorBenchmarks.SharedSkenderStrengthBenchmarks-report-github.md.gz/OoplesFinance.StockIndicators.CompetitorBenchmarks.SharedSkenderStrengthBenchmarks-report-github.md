```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated  |
|------------------ |--------------- |------ |-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetAdx** | **1000**  | **1,216.7 μs** | **87.89 μs** | **52.30 μs** |  **113.81 KB** |
| BuilderLatestOnly | Skender.GetAdx | 1000  |   829.8 μs |  7.60 μs |  3.97 μs |   66.18 KB |
| **BuilderFull**       | **Skender.GetAdx** | **10000** | **8,347.3 μs** | **90.90 μs** | **54.09 μs** | **1098.98 KB** |
| BuilderLatestOnly | Skender.GetAdx | 10000 | 8,375.5 μs | 46.81 μs | 27.85 μs |   629.3 KB |
