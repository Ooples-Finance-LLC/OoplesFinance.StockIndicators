```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated  |
|------------------ |--------------- |------ |-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetAdx** | **1000**  |   **945.7 μs** |  **3.69 μs** |  **2.19 μs** |  **113.81 KB** |
| BuilderLatestOnly | Skender.GetAdx | 1000  |   935.1 μs | 23.87 μs | 14.20 μs |   66.18 KB |
| **BuilderFull**       | **Skender.GetAdx** | **10000** | **9,324.1 μs** | **75.49 μs** | **39.48 μs** | **1099.13 KB** |
| BuilderLatestOnly | Skender.GetAdx | 10000 | 9,400.1 μs | 65.09 μs | 43.05 μs |  629.39 KB |
