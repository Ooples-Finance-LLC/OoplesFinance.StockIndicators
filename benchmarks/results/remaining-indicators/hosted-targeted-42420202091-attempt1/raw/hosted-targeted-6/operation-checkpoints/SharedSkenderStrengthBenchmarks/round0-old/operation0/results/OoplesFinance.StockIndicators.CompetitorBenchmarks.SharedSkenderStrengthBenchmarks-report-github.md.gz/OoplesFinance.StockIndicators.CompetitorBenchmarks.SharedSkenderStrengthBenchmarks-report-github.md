```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated  |
|------------------ |--------------- |------ |-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetAdx** | **1000**  |   **952.8 μs** | **13.29 μs** |  **7.91 μs** |  **113.81 KB** |
| BuilderLatestOnly | Skender.GetAdx | 1000  |   930.3 μs |  7.44 μs |  3.89 μs |   66.18 KB |
| **BuilderFull**       | **Skender.GetAdx** | **10000** | **9,372.7 μs** | **87.39 μs** | **52.00 μs** | **1099.17 KB** |
| BuilderLatestOnly | Skender.GetAdx | 10000 | 9,379.8 μs | 41.85 μs | 24.90 μs |  629.39 KB |
