```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAdx** | **1000**  |   **880.42 μs** |  **6.038 μs** |  **3.593 μs** | **11.18** |    **0.12** |        **-** |        **-** |  **113.81 KB** |        **0.57** |
| BuilderLatestOnly | Skender.GetAdx | 1000  |   876.54 μs |  8.049 μs |  4.790 μs | 11.13 |    0.12 |        - |        - |   66.18 KB |        0.33 |
| NativeSingle      | Skender.GetAdx | 1000  |    78.75 μs |  1.367 μs |  0.814 μs |  1.00 |    0.01 |  12.2070 |   2.9297 |  199.68 KB |        1.00 |
| NativeParallel    | Skender.GetAdx | 1000  |   188.37 μs |  6.476 μs |  3.387 μs |  2.39 |    0.05 |  31.2500 |   9.7656 |  507.81 KB |        2.54 |
|                   |                |       |             |           |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetAdx** | **10000** | **8,636.28 μs** | **77.527 μs** | **40.548 μs** |  **9.61** |    **0.07** |        **-** |        **-** | **1099.14 KB** |        **0.55** |
| BuilderLatestOnly | Skender.GetAdx | 10000 | 8,609.67 μs | 59.687 μs | 35.519 μs |  9.58 |    0.07 |        - |        - |  629.39 KB |        0.32 |
| NativeSingle      | Skender.GetAdx | 10000 |   898.92 μs |  8.941 μs |  5.914 μs |  1.00 |    0.01 | 117.1875 |  70.3125 |  1992.7 KB |        1.00 |
| NativeParallel    | Skender.GetAdx | 10000 | 1,892.65 μs | 70.786 μs | 46.821 μs |  2.11 |    0.05 | 312.5000 | 265.6250 | 5060.67 KB |        2.54 |
