```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)Cross [25]** |  **57.74 μs** |  **6.017 μs** | **3.147 μs** |  **1.00** |    **0.07** |  **68.35 KB** |        **1.00** |
|        |       |                      |           |           |          |       |         |           |             |
| **Ooples** | **10000** | **TaLib(...)Cross [25]** | **384.54 μs** | **14.367 μs** | **7.514 μs** |  **1.00** |    **0.03** | **638.36 KB** |        **1.00** |
