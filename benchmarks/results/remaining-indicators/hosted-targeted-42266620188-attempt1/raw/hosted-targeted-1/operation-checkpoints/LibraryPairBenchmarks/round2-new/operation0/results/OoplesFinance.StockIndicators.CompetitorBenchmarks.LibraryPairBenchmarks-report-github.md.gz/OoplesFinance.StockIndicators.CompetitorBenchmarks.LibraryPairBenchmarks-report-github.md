```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Cross [25]** | **169.43 μs** |  **3.349 μs** |  **1.752 μs** |  **1.00** |    **0.01** |  **68.38 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Cross [25] |  53.55 μs |  1.115 μs |  0.583 μs |  0.32 |    0.00 |  15.69 KB |        0.23 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Cross [25]** | **380.34 μs** |  **9.615 μs** |  **5.029 μs** |  **1.00** |    **0.02** | **638.34 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Cross [25] | 518.86 μs | 17.630 μs | 11.661 μs |  1.36 |    0.03 | 122.75 KB |        0.19 |
