```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)Cross [25]** | **1000**  |  **38.59 μs** |  **0.127 μs** |  **0.066 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)Cross [25] | 1000  |  30.54 μs |  4.625 μs |  3.059 μs |  0.79 |    0.08 |  0.4883 |       - |    8.4 KB |        2.12 |
| BuilderFull       | TaLib(...)Cross [25] | 1000  |  56.26 μs |  3.035 μs |  2.007 μs |  1.46 |    0.05 |  3.9063 |  0.4883 |  63.69 KB |       16.05 |
| BuilderLatestOnly | TaLib(...)Cross [25] | 1000  |  55.48 μs |  1.739 μs |  1.035 μs |  1.44 |    0.03 |  0.9766 |       - |  15.81 KB |        3.98 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)Cross [25]** | **10000** | **387.22 μs** |  **1.610 μs** |  **0.958 μs** |  **1.00** |    **0.00** |       **-** |       **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)Cross [25] | 10000 | 268.85 μs | 38.487 μs | 25.457 μs |  0.69 |    0.06 |  5.8594 |       - |  78.72 KB |        2.01 |
| BuilderFull       | TaLib(...)Cross [25] | 10000 | 317.03 μs |  5.929 μs |  3.101 μs |  0.82 |    0.01 | 31.2500 | 11.7188 | 556.25 KB |       14.21 |
| BuilderLatestOnly | TaLib(...)Cross [25] | 10000 | 322.30 μs | 16.652 μs |  9.909 μs |  0.83 |    0.02 |  3.9063 |       - |  86.14 KB |        2.20 |
