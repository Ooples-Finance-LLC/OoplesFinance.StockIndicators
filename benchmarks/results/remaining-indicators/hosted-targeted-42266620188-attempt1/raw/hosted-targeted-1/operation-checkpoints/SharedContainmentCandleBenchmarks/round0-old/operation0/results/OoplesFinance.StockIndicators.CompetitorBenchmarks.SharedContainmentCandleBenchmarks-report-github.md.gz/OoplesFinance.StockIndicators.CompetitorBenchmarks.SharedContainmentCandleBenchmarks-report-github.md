```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)Cross [25]** | **1000**  | **120.68 μs** | **70.483 μs** | **46.620 μs** |  **3.9063** |       **-** |  **63.72 KB** |
| BuilderLatestOnly | TaLib(...)Cross [25] | 1000  |  53.85 μs |  6.186 μs |  4.091 μs |  0.9766 |       - |  15.84 KB |
| **BuilderFull**       | **TaLib(...)Cross [25]** | **10000** | **401.80 μs** | **62.875 μs** | **41.588 μs** | **31.2500** | **11.7188** | **556.28 KB** |
| BuilderLatestOnly | TaLib(...)Cross [25] | 10000 | 385.31 μs | 32.204 μs | 21.301 μs |  3.9063 |       - |  86.16 KB |
