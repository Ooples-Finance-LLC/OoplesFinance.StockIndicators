```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)Cross [25]** | **1000**  |  **74.50 μs** | **35.301 μs** | **18.463 μs** |  **3.9063** |       **-** |  **63.72 KB** |
| BuilderLatestOnly | TaLib(...)Cross [25] | 1000  |  55.05 μs |  9.384 μs |  6.207 μs |  0.9766 |       - |  15.84 KB |
| **BuilderFull**       | **TaLib(...)Cross [25]** | **10000** | **390.73 μs** | **35.224 μs** | **20.961 μs** | **31.2500** | **11.7188** | **556.28 KB** |
| BuilderLatestOnly | TaLib(...)Cross [25] | 10000 | 380.10 μs | 44.227 μs | 26.319 μs |  3.9063 |       - |  86.16 KB |
