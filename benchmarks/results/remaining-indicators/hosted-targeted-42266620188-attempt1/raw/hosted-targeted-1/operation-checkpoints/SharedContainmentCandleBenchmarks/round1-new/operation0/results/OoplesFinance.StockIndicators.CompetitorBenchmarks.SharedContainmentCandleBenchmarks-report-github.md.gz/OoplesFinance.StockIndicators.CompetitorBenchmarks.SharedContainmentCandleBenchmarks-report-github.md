```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error      | StdDev     | Median    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|-----------:|-----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)Cross [25]** | **1000**  | **114.45 μs** | **172.009 μs** | **102.360 μs** |  **68.12 μs** |  **3.9063** |       **-** |  **63.69 KB** |
| BuilderLatestOnly | TaLib(...)Cross [25] | 1000  |  55.42 μs |   2.307 μs |   1.526 μs |  55.78 μs |  0.9766 |       - |  15.81 KB |
| **BuilderFull**       | **TaLib(...)Cross [25]** | **10000** | **351.26 μs** |  **47.827 μs** |  **31.635 μs** | **357.70 μs** | **31.2500** | **11.7188** | **556.25 KB** |
| BuilderLatestOnly | TaLib(...)Cross [25] | 10000 | 397.34 μs |  70.290 μs |  46.493 μs | 391.12 μs |  3.9063 |       - |  86.13 KB |
