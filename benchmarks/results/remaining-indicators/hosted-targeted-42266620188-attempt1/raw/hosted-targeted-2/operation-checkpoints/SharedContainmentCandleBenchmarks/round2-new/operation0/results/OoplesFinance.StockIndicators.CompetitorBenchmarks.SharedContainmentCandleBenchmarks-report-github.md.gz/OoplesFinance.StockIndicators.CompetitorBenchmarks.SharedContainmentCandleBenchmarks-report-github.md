```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)igeon [26]** | **1000**  |  **49.75 μs** |  **0.949 μs** |  **0.565 μs** |  **1.00** |    **0.02** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)igeon [26] | 1000  |  25.90 μs |  1.933 μs |  1.011 μs |  0.52 |    0.02 |  0.4883 |       - |    8.4 KB |        2.12 |
| BuilderFull       | TaLib(...)igeon [26] | 1000  |  44.61 μs |  4.242 μs |  2.524 μs |  0.90 |    0.05 |  3.9063 |  0.4883 |  63.69 KB |       16.05 |
| BuilderLatestOnly | TaLib(...)igeon [26] | 1000  |  41.48 μs |  6.044 μs |  3.997 μs |  0.83 |    0.08 |  0.9766 |       - |  15.81 KB |        3.98 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)igeon [26]** | **10000** | **373.02 μs** | **86.033 μs** | **56.906 μs** |  **1.02** |    **0.20** |       **-** |       **-** |  **39.16 KB** |        **1.00** |
| NativeParallel    | TaLib(...)igeon [26] | 10000 | 228.46 μs | 44.723 μs | 29.582 μs |  0.62 |    0.11 |  5.8594 |       - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib(...)igeon [26] | 10000 | 346.50 μs | 42.321 μs | 25.184 μs |  0.95 |    0.14 | 33.2031 | 13.6719 | 556.24 KB |       14.21 |
| BuilderLatestOnly | TaLib(...)igeon [26] | 10000 | 359.32 μs | 59.383 μs | 39.278 μs |  0.98 |    0.16 |  3.9063 |       - |  86.14 KB |        2.20 |
