```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)igeon [26]** | **1000**  |  **56.06 μs** |  **5.754 μs** |  **3.806 μs** |  **3.9063** |       **-** |  **63.69 KB** |
| BuilderLatestOnly | TaLib(...)igeon [26] | 1000  |  42.97 μs |  4.351 μs |  2.589 μs |  0.9766 |       - |  15.81 KB |
| **BuilderFull**       | **TaLib(...)igeon [26]** | **10000** | **395.14 μs** | **38.098 μs** | **25.200 μs** | **33.2031** | **13.6719** | **556.24 KB** |
| BuilderLatestOnly | TaLib(...)igeon [26] | 10000 | 378.90 μs | 39.035 μs | 23.229 μs |  3.9063 |       - |  86.14 KB |
