```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)igeon [26]** | **1000**  | **149.55 μs** | **38.568 μs** | **25.510 μs** |  **3.9063** |       **-** |  **63.73 KB** |
| BuilderLatestOnly | TaLib(...)igeon [26] | 1000  |  73.79 μs |  7.307 μs |  4.833 μs |  0.9766 |       - |  15.84 KB |
| **BuilderFull**       | **TaLib(...)igeon [26]** | **10000** | **541.32 μs** | **83.107 μs** | **54.970 μs** | **31.2500** | **11.7188** | **556.25 KB** |
| BuilderLatestOnly | TaLib(...)igeon [26] | 10000 | 516.86 μs | 68.874 μs | 40.986 μs |  3.9063 |       - |  86.18 KB |
