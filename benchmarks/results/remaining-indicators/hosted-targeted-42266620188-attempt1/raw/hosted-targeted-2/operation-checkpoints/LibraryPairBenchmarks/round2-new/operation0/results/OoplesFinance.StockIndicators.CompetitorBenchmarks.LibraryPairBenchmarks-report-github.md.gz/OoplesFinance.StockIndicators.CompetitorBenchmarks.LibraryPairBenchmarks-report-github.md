```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)igeon [26]** | **110.90 μs** |  **34.777 μs** |  **23.003 μs** |  **1.04** |    **0.30** |  **68.38 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)igeon [26] |  46.29 μs |   0.820 μs |   0.429 μs |  0.43 |    0.09 |  19.63 KB |        0.29 |
|            |       |                      |           |            |            |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)igeon [26]** | **528.13 μs** | **197.519 μs** | **130.647 μs** |  **1.07** |    **0.39** |    **639 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)igeon [26] | 490.90 μs |  25.755 μs |  15.326 μs |  0.99 |    0.27 | 125.05 KB |        0.20 |
