```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error      | StdDev     | Median    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|-----------:|-----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Candles.Harami** | **1000**  | **124.63 μs** | **190.730 μs** | **113.500 μs** |  **72.53 μs** |  **3.9063** |       **-** |  **63.72 KB** |
| BuilderLatestOnly | TaLib.Candles.Harami | 1000  |  55.41 μs |   7.112 μs |   4.704 μs |  54.55 μs |  0.9766 |       - |  15.84 KB |
| **BuilderFull**       | **TaLib.Candles.Harami** | **10000** | **398.15 μs** |  **61.743 μs** |  **36.742 μs** | **379.46 μs** | **31.2500** | **11.7188** | **556.28 KB** |
| BuilderLatestOnly | TaLib.Candles.Harami | 10000 | 358.76 μs |   5.541 μs |   2.898 μs | 358.76 μs |  3.9063 |       - |  86.18 KB |
