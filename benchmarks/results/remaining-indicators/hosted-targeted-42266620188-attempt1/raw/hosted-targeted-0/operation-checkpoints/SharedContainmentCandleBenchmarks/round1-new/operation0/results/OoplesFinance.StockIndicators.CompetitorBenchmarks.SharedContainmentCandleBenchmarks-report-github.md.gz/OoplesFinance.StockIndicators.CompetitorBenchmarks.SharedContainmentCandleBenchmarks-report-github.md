```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error      | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|-----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Candles.Harami** | **1000**  |  **55.26 μs** |  **15.596 μs** | **10.316 μs** |  **3.9063** |       **-** |  **63.69 KB** |
| BuilderLatestOnly | TaLib.Candles.Harami | 1000  |  37.61 μs |   2.929 μs |  1.743 μs |  0.9766 |       - |  15.81 KB |
| **BuilderFull**       | **TaLib.Candles.Harami** | **10000** | **332.08 μs** | **104.547 μs** | **69.151 μs** | **31.2500** | **11.7188** | **556.25 KB** |
| BuilderLatestOnly | TaLib.Candles.Harami | 10000 | 253.60 μs |  26.029 μs | 15.489 μs |  3.9063 |       - |  86.14 KB |
