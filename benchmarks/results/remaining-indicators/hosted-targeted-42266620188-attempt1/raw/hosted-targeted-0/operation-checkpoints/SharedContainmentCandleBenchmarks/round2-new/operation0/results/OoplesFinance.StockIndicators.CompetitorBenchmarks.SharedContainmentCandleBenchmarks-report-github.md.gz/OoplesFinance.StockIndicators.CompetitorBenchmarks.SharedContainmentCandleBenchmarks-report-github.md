```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib.Candles.Harami** | **1000**  |  **38.86 μs** |  **0.480 μs** |  **0.286 μs** |  **1.00** |    **0.01** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Harami | 1000  |  25.37 μs |  1.970 μs |  1.031 μs |  0.65 |    0.03 |  0.4883 |       - |    8.4 KB |        2.12 |
| BuilderFull       | TaLib.Candles.Harami | 1000  |  34.72 μs |  2.633 μs |  1.567 μs |  0.89 |    0.04 |  3.9063 |  0.4883 |  63.69 KB |       16.05 |
| BuilderLatestOnly | TaLib.Candles.Harami | 1000  |  34.61 μs |  3.521 μs |  2.329 μs |  0.89 |    0.06 |  0.9766 |       - |  15.81 KB |        3.98 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib.Candles.Harami** | **10000** | **381.14 μs** |  **1.728 μs** |  **0.904 μs** |  **1.00** |    **0.00** |  **1.9531** |       **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Harami | 10000 | 283.56 μs | 23.427 μs | 15.496 μs |  0.74 |    0.04 |  5.8594 |       - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib.Candles.Harami | 10000 | 269.29 μs | 32.313 μs | 21.373 μs |  0.71 |    0.05 | 33.2031 | 13.6719 | 556.24 KB |       14.21 |
| BuilderLatestOnly | TaLib.Candles.Harami | 10000 | 246.31 μs | 19.523 μs | 11.618 μs |  0.65 |    0.03 |  3.9063 |       - |  86.14 KB |        2.20 |
