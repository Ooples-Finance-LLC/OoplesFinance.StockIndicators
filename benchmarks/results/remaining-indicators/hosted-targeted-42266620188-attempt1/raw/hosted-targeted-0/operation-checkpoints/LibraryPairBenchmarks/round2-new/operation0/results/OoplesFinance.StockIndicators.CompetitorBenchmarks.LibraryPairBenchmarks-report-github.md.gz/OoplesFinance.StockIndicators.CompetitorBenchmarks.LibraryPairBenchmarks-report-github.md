```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Candles.Harami** | **297.63 μs** | **90.395 μs** | **59.791 μs** |  **1.03** |    **0.26** |  **68.38 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Candles.Harami |  56.19 μs |  0.505 μs |  0.264 μs |  0.19 |    0.03 |  19.91 KB |        0.29 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Candles.Harami** | **429.20 μs** | **21.570 μs** | **14.268 μs** |  **1.00** |    **0.05** |    **639 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Candles.Harami | 515.71 μs | 16.271 μs | 10.762 μs |  1.20 |    0.05 | 124.39 KB |        0.19 |
