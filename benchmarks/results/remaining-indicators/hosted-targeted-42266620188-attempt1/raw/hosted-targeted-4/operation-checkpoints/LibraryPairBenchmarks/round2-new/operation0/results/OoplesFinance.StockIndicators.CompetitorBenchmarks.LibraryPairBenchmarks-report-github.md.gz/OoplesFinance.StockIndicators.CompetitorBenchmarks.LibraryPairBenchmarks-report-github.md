```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Mfi** |  **98.82 μs** | **17.743 μs** | **10.559 μs** |  **1.01** |    **0.14** |   **105.6 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Mfi |  22.25 μs |  1.409 μs |  0.737 μs |  0.23 |    0.02 |   40.61 KB |        0.38 |
|            |       |                     |           |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Mfi** | **759.81 μs** | **47.524 μs** | **31.434 μs** |  **1.00** |    **0.06** | **1036.28 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Mfi | 178.98 μs | 14.840 μs |  8.831 μs |  0.24 |    0.01 |   323.1 KB |        0.31 |
