```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId              | Mean     | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |-------------------- |---------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Mfi** | **110.8 μs** | **15.28 μs** | **10.11 μs** |  **1.01** |    **0.13** |   **105.6 KB** |        **1.00** |
|        |       |                     |          |          |          |       |         |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Mfi** | **758.6 μs** | **92.30 μs** | **48.27 μs** |  **1.00** |    **0.08** | **1036.66 KB** |        **1.00** |
