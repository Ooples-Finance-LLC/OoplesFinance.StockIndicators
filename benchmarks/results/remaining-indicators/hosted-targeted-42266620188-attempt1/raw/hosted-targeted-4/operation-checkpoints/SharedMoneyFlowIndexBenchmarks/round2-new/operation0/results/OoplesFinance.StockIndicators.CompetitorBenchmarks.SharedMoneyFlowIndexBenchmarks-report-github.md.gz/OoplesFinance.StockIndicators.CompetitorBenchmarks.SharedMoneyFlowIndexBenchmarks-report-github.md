```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0   | Gen1   | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |-----------:|-----------:|-----------:|------:|--------:|-------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Mfi** | **1000**  |  **42.820 μs** |  **0.3639 μs** |  **0.2165 μs** |  **6.48** |    **0.05** |      **-** |      **-** |  **65.12 KB** |        **8.13** |
| BuilderLatestOnly | TaLib.Functions.Mfi | 1000  |  31.587 μs |  5.2920 μs |  3.5004 μs |  4.78 |    0.51 |      - |      - |  17.47 KB |        2.18 |
| NativeSingle      | TaLib.Functions.Mfi | 1000  |   6.613 μs |  0.0723 μs |  0.0478 μs |  1.00 |    0.01 | 0.0610 |      - |   8.01 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mfi | 1000  |   6.062 μs |  0.4098 μs |  0.2711 μs |  0.92 |    0.04 | 0.0916 |      - |   9.02 KB |        1.13 |
|                   |                     |       |            |            |            |       |         |        |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Mfi** | **10000** | **286.661 μs** | **52.3019 μs** | **34.5944 μs** |  **4.81** |    **0.55** | **5.8594** | **1.9531** | **627.93 KB** |        **8.02** |
| BuilderLatestOnly | TaLib.Functions.Mfi | 10000 | 247.362 μs | 33.6847 μs | 22.2803 μs |  4.15 |    0.36 |      - |      - | 158.11 KB |        2.02 |
| NativeSingle      | TaLib.Functions.Mfi | 10000 |  59.582 μs |  0.4021 μs |  0.2103 μs |  1.00 |    0.00 | 0.4883 |      - |  78.32 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mfi | 10000 |  42.554 μs |  4.1380 μs |  2.4625 μs |  0.71 |    0.04 | 0.9766 |      - |  79.34 KB |        1.01 |
