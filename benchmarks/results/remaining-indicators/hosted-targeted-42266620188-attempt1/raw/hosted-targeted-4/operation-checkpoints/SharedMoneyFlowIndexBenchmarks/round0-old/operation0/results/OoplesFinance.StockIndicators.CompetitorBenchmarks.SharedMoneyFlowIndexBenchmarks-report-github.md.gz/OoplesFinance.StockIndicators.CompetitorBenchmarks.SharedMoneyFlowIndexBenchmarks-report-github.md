```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean      | Error     | StdDev    | Gen0   | Gen1   | Allocated |
|------------------ |-------------------- |------ |----------:|----------:|----------:|-------:|-------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mfi** | **1000**  |  **45.45 μs** |  **0.382 μs** |  **0.227 μs** |      **-** |      **-** |  **65.12 KB** |
| BuilderLatestOnly | TaLib.Functions.Mfi | 1000  |  34.03 μs |  5.618 μs |  3.716 μs |      - |      - |  17.47 KB |
| **BuilderFull**       | **TaLib.Functions.Mfi** | **10000** | **281.68 μs** | **39.920 μs** | **26.404 μs** | **5.8594** | **1.9531** | **627.89 KB** |
| BuilderLatestOnly | TaLib.Functions.Mfi | 10000 | 237.95 μs | 16.524 μs |  9.833 μs |      - |      - | 158.11 KB |
