```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean      | Error     | StdDev    | Gen0   | Gen1   | Allocated |
|------------------ |-------------------- |------ |----------:|----------:|----------:|-------:|-------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mfi** | **1000**  |  **53.28 μs** | **13.843 μs** |  **9.156 μs** |      **-** |      **-** |  **65.12 KB** |
| BuilderLatestOnly | TaLib.Functions.Mfi | 1000  |  33.16 μs |  5.389 μs |  3.564 μs |      - |      - |  17.47 KB |
| **BuilderFull**       | **TaLib.Functions.Mfi** | **10000** | **358.47 μs** | **60.604 μs** | **40.086 μs** | **5.8594** | **1.9531** | **627.92 KB** |
| BuilderLatestOnly | TaLib.Functions.Mfi | 10000 | 297.07 μs | 61.899 μs | 40.942 μs |      - |      - |  158.1 KB |
