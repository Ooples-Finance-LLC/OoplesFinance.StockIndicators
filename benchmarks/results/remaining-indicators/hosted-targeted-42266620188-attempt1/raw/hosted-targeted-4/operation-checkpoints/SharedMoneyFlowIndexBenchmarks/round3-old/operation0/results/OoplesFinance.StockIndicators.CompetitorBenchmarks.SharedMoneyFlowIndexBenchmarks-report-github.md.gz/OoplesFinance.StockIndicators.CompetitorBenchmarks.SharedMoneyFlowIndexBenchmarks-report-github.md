```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean      | Error     | StdDev    | Gen0   | Gen1   | Allocated |
|------------------ |-------------------- |------ |----------:|----------:|----------:|-------:|-------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mfi** | **1000**  |  **67.44 μs** | **38.501 μs** | **25.466 μs** |      **-** |      **-** |  **65.12 KB** |
| BuilderLatestOnly | TaLib.Functions.Mfi | 1000  |  32.00 μs |  2.814 μs |  1.861 μs |      - |      - |  17.47 KB |
| **BuilderFull**       | **TaLib.Functions.Mfi** | **10000** | **265.82 μs** | **28.685 μs** | **17.070 μs** | **5.8594** | **1.9531** | **627.92 KB** |
| BuilderLatestOnly | TaLib.Functions.Mfi | 10000 | 268.86 μs | 47.302 μs | 31.287 μs |      - |      - | 158.11 KB |
