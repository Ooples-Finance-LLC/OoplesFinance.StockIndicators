```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetMfi** | **1000**  |  **45.98 μs** |  **0.470 μs** |  **0.280 μs** |  **3.9063** |       **-** |  **65.08 KB** |
| BuilderLatestOnly | Skender.GetMfi | 1000  |  29.33 μs |  4.430 μs |  2.317 μs |  0.9766 |       - |  17.47 KB |
| **BuilderFull**       | **Skender.GetMfi** | **10000** | **322.79 μs** | **46.020 μs** | **30.440 μs** | **37.1094** | **13.6719** | **627.95 KB** |
| BuilderLatestOnly | Skender.GetMfi | 10000 | 304.49 μs | 35.794 μs | 21.300 μs |  7.8125 |  1.9531 | 158.11 KB |
