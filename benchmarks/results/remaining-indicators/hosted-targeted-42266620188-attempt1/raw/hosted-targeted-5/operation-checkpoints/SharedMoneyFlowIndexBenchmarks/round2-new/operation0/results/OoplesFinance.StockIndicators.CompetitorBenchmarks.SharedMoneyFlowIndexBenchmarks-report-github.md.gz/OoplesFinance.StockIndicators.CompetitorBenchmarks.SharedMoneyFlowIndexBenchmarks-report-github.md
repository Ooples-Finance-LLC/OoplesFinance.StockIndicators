```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetMfi** | **1000**  |  **48.20 μs** |  **4.158 μs** |  **2.474 μs** |  **0.70** |    **0.04** |  **3.9063** |       **-** |   **65.12 KB** |        **0.42** |
| BuilderLatestOnly | Skender.GetMfi | 1000  |  34.56 μs |  7.339 μs |  4.367 μs |  0.50 |    0.06 |  0.9766 |       - |   17.47 KB |        0.11 |
| NativeSingle      | Skender.GetMfi | 1000  |  68.73 μs |  1.254 μs |  0.829 μs |  1.00 |    0.02 |  9.2773 |  1.9531 |  156.75 KB |        1.00 |
| NativeParallel    | Skender.GetMfi | 1000  |  51.55 μs |  6.192 μs |  4.095 μs |  0.75 |    0.06 | 10.2539 |  1.9531 |  165.09 KB |        1.05 |
|                   |                |       |           |           |           |       |         |         |         |            |             |
| **BuilderFull**       | **Skender.GetMfi** | **10000** | **346.66 μs** | **81.351 μs** | **53.808 μs** |  **0.44** |    **0.07** | **35.1563** | **11.7188** |  **627.96 KB** |        **0.40** |
| BuilderLatestOnly | Skender.GetMfi | 10000 | 315.00 μs | 40.894 μs | 27.049 μs |  0.40 |    0.03 |  7.8125 |  1.9531 |  158.12 KB |        0.10 |
| NativeSingle      | Skender.GetMfi | 10000 | 783.27 μs |  9.300 μs |  4.864 μs |  1.00 |    0.01 | 93.7500 | 46.8750 | 1563.06 KB |        1.00 |
| NativeParallel    | Skender.GetMfi | 10000 | 679.70 μs | 53.597 μs | 35.451 μs |  0.87 |    0.04 | 97.6563 | 42.9688 | 1571.37 KB |        1.01 |
