```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetMfi** |   **109.0 μs** |   **4.81 μs** |  **3.18 μs** |  **1.00** |    **0.04** |   **105.6 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetMfi |   156.3 μs |   4.89 μs |  2.56 μs |  1.44 |    0.05 |   189.2 KB |        1.79 |
|            |       |                |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetMfi** | **1,099.8 μs** |  **89.90 μs** | **59.46 μs** |  **1.00** |    **0.07** | **1036.66 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetMfi | 1,614.2 μs | 103.34 μs | 61.50 μs |  1.47 |    0.10 | 1815.18 KB |        1.75 |
