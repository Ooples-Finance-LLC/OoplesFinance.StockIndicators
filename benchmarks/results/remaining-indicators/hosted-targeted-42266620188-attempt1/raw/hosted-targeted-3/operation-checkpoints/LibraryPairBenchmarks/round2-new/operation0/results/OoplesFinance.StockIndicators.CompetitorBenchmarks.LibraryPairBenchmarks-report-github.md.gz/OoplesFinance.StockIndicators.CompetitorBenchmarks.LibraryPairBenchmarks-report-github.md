```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean     | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |---------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)iStar [22]** | **602.7 μs** | **208.93 μs** | **138.20 μs** |  **1.05** |    **0.31** |  **68.38 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)iStar [22] | 117.1 μs |   1.80 μs |   1.07 μs |  0.20 |    0.04 |   19.3 KB |        0.28 |
|            |       |                      |          |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)iStar [22]** | **436.3 μs** |   **3.00 μs** |   **1.78 μs** |  **1.00** |    **0.01** |    **639 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)iStar [22] | 690.2 μs |  25.68 μs |  16.99 μs |  1.58 |    0.04 | 125.09 KB |        0.20 |
