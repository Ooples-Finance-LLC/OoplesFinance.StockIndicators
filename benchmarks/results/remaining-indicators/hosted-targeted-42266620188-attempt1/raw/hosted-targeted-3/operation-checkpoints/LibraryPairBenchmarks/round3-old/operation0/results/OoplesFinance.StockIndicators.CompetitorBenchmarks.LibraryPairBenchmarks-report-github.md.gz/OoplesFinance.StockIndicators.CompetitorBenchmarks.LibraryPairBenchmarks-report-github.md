```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean     | Error     | StdDev    | Median    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |---------:|----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)iStar [22]** | **100.8 μs** |   **3.49 μs** |   **2.07 μs** |  **99.90 μs** |  **1.00** |    **0.03** |   **68.4 KB** |        **1.00** |
|        |       |                      |          |           |           |           |       |         |           |             |
| **Ooples** | **10000** | **TaLib(...)iStar [22]** | **821.3 μs** | **435.12 μs** | **287.81 μs** | **621.60 μs** |  **1.10** |    **0.50** | **639.02 KB** |        **1.00** |
