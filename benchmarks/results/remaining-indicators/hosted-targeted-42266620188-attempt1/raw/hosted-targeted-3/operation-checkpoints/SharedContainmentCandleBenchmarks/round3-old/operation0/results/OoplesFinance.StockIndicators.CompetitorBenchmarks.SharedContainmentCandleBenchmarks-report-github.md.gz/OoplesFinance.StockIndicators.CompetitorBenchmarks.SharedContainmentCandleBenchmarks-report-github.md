```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)iStar [22]** | **1000**  | **112.52 μs** | **21.619 μs** | **14.300 μs** |  **3.9063** |       **-** |  **63.76 KB** |
| BuilderLatestOnly | TaLib(...)iStar [22] | 1000  |  71.14 μs |  8.994 μs |  5.949 μs |  0.9766 |       - |  15.84 KB |
| **BuilderFull**       | **TaLib(...)iStar [22]** | **10000** | **520.21 μs** | **39.845 μs** | **20.840 μs** | **31.2500** | **11.7188** | **556.29 KB** |
| BuilderLatestOnly | TaLib(...)iStar [22] | 10000 | 506.86 μs | 47.933 μs | 28.524 μs |  3.9063 |       - |  86.17 KB |
