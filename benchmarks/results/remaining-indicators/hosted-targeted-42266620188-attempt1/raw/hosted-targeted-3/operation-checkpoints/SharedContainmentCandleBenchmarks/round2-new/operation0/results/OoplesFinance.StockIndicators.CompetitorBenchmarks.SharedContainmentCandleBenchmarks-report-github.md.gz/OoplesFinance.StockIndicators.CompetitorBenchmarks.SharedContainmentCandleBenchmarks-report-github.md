```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|-----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)iStar [22]** | **1000**  | **136.30 μs** |   **0.496 μs** |  **0.259 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)iStar [22] | 1000  |  31.56 μs |   4.257 μs |  2.533 μs |  0.23 |    0.02 |  0.4883 |       - |    8.4 KB |        2.12 |
| BuilderFull       | TaLib(...)iStar [22] | 1000  |  59.82 μs |   5.184 μs |  3.429 μs |  0.44 |    0.02 |  3.9063 |  0.4883 |  63.66 KB |       16.04 |
| BuilderLatestOnly | TaLib(...)iStar [22] | 1000  |  60.02 μs |   7.587 μs |  5.018 μs |  0.44 |    0.04 |  0.9766 |       - |  15.81 KB |        3.98 |
|                   |                      |       |           |            |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)iStar [22]** | **10000** | **444.45 μs** |   **2.958 μs** |  **1.547 μs** |  **1.00** |    **0.00** |       **-** |       **-** |  **39.16 KB** |        **1.00** |
| NativeParallel    | TaLib(...)iStar [22] | 10000 | 316.07 μs |  58.222 μs | 38.510 μs |  0.71 |    0.08 |  5.8594 |       - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib(...)iStar [22] | 10000 | 499.63 μs |  92.456 μs | 61.154 μs |  1.12 |    0.13 | 31.2500 | 11.7188 | 556.22 KB |       14.21 |
| BuilderLatestOnly | TaLib(...)iStar [22] | 10000 | 500.48 μs | 109.709 μs | 72.566 μs |  1.13 |    0.16 |  3.9063 |       - |  86.15 KB |        2.20 |
