```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)iStar [22]** | **1000**  |  **90.72 μs** | **10.430 μs** |  **5.455 μs** |  **3.9063** |       **-** |  **63.76 KB** |
| BuilderLatestOnly | TaLib(...)iStar [22] | 1000  |  72.96 μs |  9.018 μs |  5.965 μs |  0.9766 |       - |  15.84 KB |
| **BuilderFull**       | **TaLib(...)iStar [22]** | **10000** | **536.71 μs** | **79.904 μs** | **52.851 μs** | **31.2500** | **11.7188** | **556.29 KB** |
| BuilderLatestOnly | TaLib(...)iStar [22] | 10000 | 532.55 μs | 82.685 μs | 54.691 μs |  3.9063 |       - |  86.18 KB |
