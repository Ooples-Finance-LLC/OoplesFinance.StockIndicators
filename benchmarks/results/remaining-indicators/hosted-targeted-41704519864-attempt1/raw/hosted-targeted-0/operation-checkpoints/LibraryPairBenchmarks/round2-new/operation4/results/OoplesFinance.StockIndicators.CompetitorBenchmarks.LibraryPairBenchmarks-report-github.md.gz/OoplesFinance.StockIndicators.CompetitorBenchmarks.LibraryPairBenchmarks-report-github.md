```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)gStar [29]** |   **793.9 μs** | **33.06 μs** | **21.86 μs** |  **1.00** |    **0.04** |   **74.45 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)gStar [29] | 1,101.2 μs | 45.55 μs | 27.10 μs |  1.39 |    0.05 |  900.77 KB |       12.10 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Trady(...)gStar [29]** | **3,756.4 μs** | **66.45 μs** | **34.76 μs** |  **1.00** |    **0.01** |  **655.98 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)gStar [29] | 6,462.1 μs | 59.18 μs | 35.21 μs |  1.72 |    0.02 | 8751.52 KB |       13.34 |
