```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)iStar [33]** |   **518.1 μs** |  **20.61 μs** | **13.63 μs** |  **1.00** |    **0.04** |   **71.67 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)iStar [33] | 1,103.3 μs |  54.32 μs | 35.93 μs |  2.13 |    0.09 |  932.06 KB |       13.00 |
|            |       |                      |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **Trady(...)iStar [33]** | **2,321.7 μs** |  **44.96 μs** | **26.75 μs** |  **1.00** |    **0.02** |  **649.39 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)iStar [33] | 6,587.4 μs | 111.12 μs | 58.12 μs |  2.84 |    0.04 | 9065.61 KB |       13.96 |
