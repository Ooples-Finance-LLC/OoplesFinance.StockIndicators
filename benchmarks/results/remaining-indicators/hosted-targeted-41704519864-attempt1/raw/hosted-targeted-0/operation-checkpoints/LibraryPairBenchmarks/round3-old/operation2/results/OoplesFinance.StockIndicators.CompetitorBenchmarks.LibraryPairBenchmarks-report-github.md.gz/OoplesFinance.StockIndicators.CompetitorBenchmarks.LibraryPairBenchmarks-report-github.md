```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **Trady(...)iStar [34]** |   **348.6 μs** |  **31.11 μs** |  **20.58 μs** |  **1.00** |    **0.08** |  **69.86 KB** |        **1.00** |
|        |       |                      |            |           |           |       |         |           |             |
| **Ooples** | **10000** | **Trady(...)iStar [34]** | **1,923.5 μs** | **549.86 μs** | **363.70 μs** |  **1.04** |    **0.28** | **645.77 KB** |        **1.00** |
