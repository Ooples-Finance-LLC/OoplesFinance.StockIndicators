```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)iStar [33]** |   **561.9 μs** |  **76.31 μs** | **50.48 μs** |  **1.01** |    **0.12** |   **71.67 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)iStar [33] | 1,095.2 μs |  55.95 μs | 33.29 μs |  1.96 |    0.18 |   963.7 KB |       13.45 |
|            |       |                      |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **Trady(...)iStar [33]** | **2,872.6 μs** |  **72.75 μs** | **38.05 μs** |  **1.00** |    **0.02** |  **650.38 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)iStar [33] | 6,628.1 μs | 156.83 μs | 82.02 μs |  2.31 |    0.04 | 9377.23 KB |       14.42 |
