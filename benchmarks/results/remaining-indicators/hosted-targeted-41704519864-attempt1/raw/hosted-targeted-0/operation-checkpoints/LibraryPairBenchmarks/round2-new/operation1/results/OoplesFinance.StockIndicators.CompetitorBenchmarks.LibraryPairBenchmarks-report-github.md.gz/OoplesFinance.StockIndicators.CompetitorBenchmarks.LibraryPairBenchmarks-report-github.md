```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)gStar [29]** |   **898.8 μs** |  **22.66 μs** |  **14.99 μs** |  **1.00** |    **0.02** |  **74.49 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)gStar [29] | 1,131.8 μs |  57.12 μs |  33.99 μs |  1.26 |    0.04 | 901.43 KB |       12.10 |
|            |       |                      |            |           |           |       |         |           |             |
| **Ooples**     | **10000** | **Trady(...)gStar [29]** | **4,423.2 μs** | **557.21 μs** | **368.56 μs** |  **1.01** |    **0.11** | **656.02 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)gStar [29] | 6,319.8 μs |  55.80 μs |  29.19 μs |  1.44 |    0.11 | 8751.8 KB |       13.34 |
