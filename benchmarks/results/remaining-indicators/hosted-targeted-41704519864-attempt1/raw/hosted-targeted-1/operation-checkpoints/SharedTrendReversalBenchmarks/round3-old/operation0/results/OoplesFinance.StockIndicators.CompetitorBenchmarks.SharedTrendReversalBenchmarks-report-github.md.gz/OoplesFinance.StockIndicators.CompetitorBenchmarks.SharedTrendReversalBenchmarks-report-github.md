```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |---------------- |------ |-----------:|----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **EveningDojiStar** | **1000**  |   **350.1 μs** |   **1.06 μs** |   **0.55 μs** |       **-** |      **-** |  **61.49 KB** |
| BuilderLatestOnly | EveningDojiStar | 1000  |   260.4 μs |   2.87 μs |   1.50 μs |       - |      - |  13.53 KB |
| **BuilderFull**       | **EveningDojiStar** | **10000** | **1,395.6 μs** | **147.37 μs** |  **97.47 μs** | **31.2500** | **7.8125** | **568.24 KB** |
| BuilderLatestOnly | EveningDojiStar | 10000 | 1,475.0 μs | 166.84 μs | 110.35 μs |       - |      - |  98.16 KB |
