```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **EveningDojiStar** | **1000**  |   **351.8 μs** |   **3.93 μs** |   **2.34 μs** |       **-** |       **-** |  **61.52 KB** |
| BuilderLatestOnly | EveningDojiStar | 1000  |   273.5 μs |   1.89 μs |   1.12 μs |       - |       - |  13.53 KB |
| **BuilderFull**       | **EveningDojiStar** | **10000** | **1,384.4 μs** |  **73.57 μs** |  **38.48 μs** | **31.2500** | **15.6250** | **568.35 KB** |
| BuilderLatestOnly | EveningDojiStar | 10000 | 1,359.9 μs | 180.41 μs | 119.33 μs |       - |       - |  98.17 KB |
