```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |------------ |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **MorningStar** | **1000**  |   **292.1 μs** |   **1.42 μs** |   **0.84 μs** |       **-** |  **63.32 KB** |
| BuilderLatestOnly | MorningStar | 1000  |   284.0 μs |  11.34 μs |   6.75 μs |       - |  15.44 KB |
| **BuilderFull**       | **MorningStar** | **10000** | **1,536.8 μs** | **171.36 μs** | **101.97 μs** | **31.2500** | **576.02 KB** |
| BuilderLatestOnly | MorningStar | 10000 | 1,552.5 μs | 166.70 μs | 110.26 μs |       - | 105.82 KB |
