```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0       | Gen1      | Allocated    | Alloc Ratio |
|------------------ |---------------- |------ |-------------:|------------:|------------:|------:|--------:|-----------:|----------:|-------------:|------------:|
| **BuilderFull**       | **MorningDojiStar** | **1000**  |     **533.4 μs** |    **22.66 μs** |    **13.48 μs** |  **0.05** |    **0.00** |          **-** |         **-** |     **63.18 KB** |       **0.002** |
| BuilderLatestOnly | MorningDojiStar | 1000  |     583.0 μs |     4.46 μs |     2.65 μs |  0.06 |    0.00 |          - |         - |     15.36 KB |       0.001 |
| NativeSingle      | MorningDojiStar | 1000  |  10,410.1 μs |   187.37 μs |   111.50 μs |  1.00 |    0.01 |  1500.0000 |  125.0000 |  26324.38 KB |       1.000 |
| NativeParallel    | MorningDojiStar | 1000  |   6,579.2 μs |   284.70 μs |   169.42 μs |  0.63 |    0.02 |  1625.0000 |  312.5000 |  26330.69 KB |       1.000 |
|                   |                 |       |              |             |             |       |         |            |           |              |             |
| **BuilderFull**       | **MorningDojiStar** | **10000** |   **2,762.9 μs** |    **81.16 μs** |    **48.30 μs** |  **0.03** |    **0.00** |    **31.2500** |         **-** |    **575.57 KB** |       **0.002** |
| BuilderLatestOnly | MorningDojiStar | 10000 |   2,970.4 μs |   148.38 μs |    98.15 μs |  0.03 |    0.00 |          - |         - |     105.5 KB |       0.000 |
| NativeSingle      | MorningDojiStar | 10000 | 105,900.0 μs | 2,455.85 μs | 1,624.39 μs |  1.00 |    0.02 | 16250.0000 | 1500.0000 | 266747.74 KB |       1.000 |
| NativeParallel    | MorningDojiStar | 10000 |  66,261.0 μs | 3,321.95 μs | 2,197.26 μs |  0.63 |    0.02 | 16750.0000 | 3250.0000 | 266810.44 KB |       1.000 |
