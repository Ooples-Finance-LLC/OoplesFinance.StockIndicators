```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |----------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **MoringinDojiStar** | **1000**  |   **681.1 μs** |  **4.59 μs** |  **2.40 μs** |       **-** |  **63.22 KB** |
| BuilderLatestOnly | MoringinDojiStar | 1000  |   527.3 μs |  8.60 μs |  5.12 μs |       - |  15.36 KB |
| **BuilderFull**       | **MoringinDojiStar** | **10000** | **2,768.4 μs** | **98.84 μs** | **65.38 μs** | **31.2500** |  **575.6 KB** |
| BuilderLatestOnly | MoringinDojiStar | 10000 | 2,781.2 μs | 62.72 μs | 41.49 μs |       - | 105.48 KB |
