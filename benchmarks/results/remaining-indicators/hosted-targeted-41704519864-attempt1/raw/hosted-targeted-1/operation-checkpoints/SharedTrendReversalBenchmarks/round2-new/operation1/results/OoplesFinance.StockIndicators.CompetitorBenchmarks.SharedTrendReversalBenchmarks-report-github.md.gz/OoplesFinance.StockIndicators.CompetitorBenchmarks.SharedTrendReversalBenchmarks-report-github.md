```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0       | Gen1      | Allocated    | Alloc Ratio |
|------------------ |------------ |------ |-------------:|------------:|------------:|------:|--------:|-----------:|----------:|-------------:|------------:|
| **BuilderFull**       | **EveningStar** | **1000**  |     **788.8 μs** |    **76.17 μs** |    **45.32 μs** |  **0.04** |    **0.00** |          **-** |         **-** |     **66.09 KB** |       **0.001** |
| BuilderLatestOnly | EveningStar | 1000  |     658.4 μs |     1.97 μs |     1.03 μs |  0.03 |    0.00 |          - |         - |     18.18 KB |       0.000 |
| NativeSingle      | EveningStar | 1000  |  20,456.1 μs |   583.92 μs |   347.48 μs |  1.00 |    0.02 |  3000.0000 |  200.0000 |  50316.32 KB |       1.000 |
| NativeParallel    | EveningStar | 1000  |  12,473.9 μs |   329.94 μs |   196.34 μs |  0.61 |    0.01 |  3125.0000 |  500.0000 |  50333.56 KB |       1.000 |
|                   |             |       |              |             |             |       |         |            |           |              |             |
| **BuilderFull**       | **EveningStar** | **10000** |   **3,953.9 μs** |   **261.12 μs** |   **172.72 μs** |  **0.02** |    **0.00** |    **31.2500** |         **-** |    **587.06 KB** |       **0.001** |
| BuilderLatestOnly | EveningStar | 10000 |   3,722.7 μs |    50.56 μs |    26.44 μs |  0.02 |    0.00 |          - |         - |    116.94 KB |       0.000 |
| NativeSingle      | EveningStar | 10000 | 205,768.8 μs | 3,998.49 μs | 2,644.75 μs |  1.00 |    0.02 | 31000.0000 | 2750.0000 | 510236.35 KB |       1.000 |
| NativeParallel    | EveningStar | 10000 | 126,177.1 μs | 5,033.22 μs | 3,329.16 μs |  0.61 |    0.02 | 32000.0000 | 6000.0000 | 510427.36 KB |       1.000 |
