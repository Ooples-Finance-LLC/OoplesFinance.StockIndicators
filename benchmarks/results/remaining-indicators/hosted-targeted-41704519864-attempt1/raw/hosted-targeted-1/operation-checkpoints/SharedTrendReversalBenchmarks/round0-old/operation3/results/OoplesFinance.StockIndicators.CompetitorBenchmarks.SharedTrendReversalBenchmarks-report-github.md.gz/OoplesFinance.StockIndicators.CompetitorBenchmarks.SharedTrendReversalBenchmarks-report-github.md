```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **MorningDojiStar** | **1000**  |   **354.2 μs** |   **3.74 μs** |   **2.23 μs** |       **-** |       **-** |   **61.6 KB** |
| BuilderLatestOnly | MorningDojiStar | 1000  |   263.4 μs |   3.45 μs |   2.28 μs |       - |       - |  13.53 KB |
| **BuilderFull**       | **MorningDojiStar** | **10000** | **1,439.3 μs** | **239.20 μs** | **158.22 μs** | **31.2500** | **15.6250** | **568.37 KB** |
| BuilderLatestOnly | MorningDojiStar | 10000 | 2,070.3 μs | 269.27 μs | 178.10 μs |       - |       - |  98.25 KB |
