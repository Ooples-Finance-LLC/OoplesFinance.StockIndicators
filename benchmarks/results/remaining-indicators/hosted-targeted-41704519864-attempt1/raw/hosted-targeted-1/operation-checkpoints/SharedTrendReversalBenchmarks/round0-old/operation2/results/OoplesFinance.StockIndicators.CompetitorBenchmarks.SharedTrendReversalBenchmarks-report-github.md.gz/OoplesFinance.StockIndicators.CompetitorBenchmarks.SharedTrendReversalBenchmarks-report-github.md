```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |----------------- |------ |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **MoringinDojiStar** | **1000**  |   **371.6 μs** |  **24.95 μs** |  **14.84 μs** |       **-** |       **-** |  **61.48 KB** |
| BuilderLatestOnly | MoringinDojiStar | 1000  |   257.9 μs |   2.17 μs |   1.13 μs |       - |       - |  13.52 KB |
| **BuilderFull**       | **MoringinDojiStar** | **10000** | **1,371.0 μs** | **162.61 μs** |  **85.05 μs** | **31.2500** | **15.6250** | **568.34 KB** |
| BuilderLatestOnly | MoringinDojiStar | 10000 | 1,364.9 μs | 202.09 μs | 133.67 μs |       - |       - |  98.23 KB |
