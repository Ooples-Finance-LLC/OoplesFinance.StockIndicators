```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |------------ |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **EveningStar** | **1000**  |   **717.2 μs** |   **2.15 μs** |   **1.28 μs** |       **-** |  **66.04 KB** |
| BuilderLatestOnly | EveningStar | 1000  |   670.6 μs |   8.42 μs |   5.01 μs |       - |  18.18 KB |
| **BuilderFull**       | **EveningStar** | **10000** | **3,645.5 μs** | **173.03 μs** | **114.45 μs** | **31.2500** | **586.88 KB** |
| BuilderLatestOnly | EveningStar | 10000 | 3,701.4 μs | 120.41 μs |  62.98 μs |       - | 116.95 KB |
