```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |------------ |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **EveningStar** | **1000**  |   **383.6 μs** |   **3.90 μs** |   **2.32 μs** |       **-** |  **63.36 KB** |
| BuilderLatestOnly | EveningStar | 1000  |   281.1 μs |   2.40 μs |   1.59 μs |       - |  15.44 KB |
| **BuilderFull**       | **EveningStar** | **10000** | **1,507.8 μs** |  **38.57 μs** |  **20.17 μs** | **31.2500** | **576.02 KB** |
| BuilderLatestOnly | EveningStar | 10000 | 1,570.4 μs | 191.51 μs | 126.67 μs |       - | 105.83 KB |
