```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0       | Gen1      | Allocated    | Alloc Ratio |
|------------------ |---------------- |------ |-------------:|------------:|------------:|------:|--------:|-----------:|----------:|-------------:|------------:|
| **BuilderFull**       | **EveningDojiStar** | **1000**  |     **554.2 μs** |    **12.92 μs** |     **8.54 μs** |  **0.05** |    **0.00** |          **-** |         **-** |     **63.22 KB** |       **0.002** |
| BuilderLatestOnly | EveningDojiStar | 1000  |     541.3 μs |     2.39 μs |     1.25 μs |  0.05 |    0.00 |          - |         - |     15.36 KB |       0.001 |
| NativeSingle      | EveningDojiStar | 1000  |  10,921.4 μs |   348.54 μs |   207.41 μs |  1.00 |    0.03 |  1555.5556 |  111.1111 |     26474 KB |       1.000 |
| NativeParallel    | EveningDojiStar | 1000  |   6,746.8 μs |   208.78 μs |   124.24 μs |  0.62 |    0.02 |  1600.0000 |  266.6667 |  26483.31 KB |       1.000 |
|                   |                 |       |              |             |             |       |         |            |           |              |             |
| **BuilderFull**       | **EveningDojiStar** | **10000** |   **2,857.9 μs** |   **122.69 μs** |    **81.15 μs** |  **0.03** |    **0.00** |    **31.2500** |         **-** |    **575.61 KB** |       **0.002** |
| BuilderLatestOnly | EveningDojiStar | 10000 |   2,846.3 μs |   179.10 μs |   118.47 μs |  0.03 |    0.00 |          - |         - |     105.5 KB |       0.000 |
| NativeSingle      | EveningDojiStar | 10000 | 106,744.6 μs | 1,744.87 μs |   912.60 μs |  1.00 |    0.01 | 16250.0000 | 1500.0000 | 267591.16 KB |       1.000 |
| NativeParallel    | EveningDojiStar | 10000 |  66,882.0 μs | 1,963.69 μs | 1,298.86 μs |  0.63 |    0.01 | 16750.0000 | 3250.0000 | 267686.12 KB |       1.000 |
