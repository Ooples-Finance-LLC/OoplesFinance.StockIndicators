```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |------------ |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **MorningStar** | **1000**  |   **372.4 μs** |   **1.58 μs** |   **0.83 μs** |       **-** |   **63.4 KB** |
| BuilderLatestOnly | MorningStar | 1000  |   285.9 μs |   2.69 μs |   1.41 μs |       - |  15.44 KB |
| **BuilderFull**       | **MorningStar** | **10000** | **1,465.9 μs** |  **45.58 μs** |  **23.84 μs** | **31.2500** | **576.01 KB** |
| BuilderLatestOnly | MorningStar | 10000 | 1,551.8 μs | 151.77 μs | 100.39 μs |       - | 105.82 KB |
