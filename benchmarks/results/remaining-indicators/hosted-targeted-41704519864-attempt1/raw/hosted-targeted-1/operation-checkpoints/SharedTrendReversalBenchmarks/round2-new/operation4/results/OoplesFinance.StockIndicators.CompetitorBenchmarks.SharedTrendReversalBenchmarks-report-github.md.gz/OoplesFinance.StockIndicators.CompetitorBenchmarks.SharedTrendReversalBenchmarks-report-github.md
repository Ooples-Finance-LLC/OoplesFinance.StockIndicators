```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0       | Gen1      | Allocated    | Alloc Ratio |
|------------------ |------------ |------ |-------------:|------------:|------------:|------:|--------:|-----------:|----------:|-------------:|------------:|
| **BuilderFull**       | **MorningStar** | **1000**  |     **710.8 μs** |    **12.71 μs** |     **7.56 μs** |  **0.04** |    **0.00** |          **-** |         **-** |     **66.09 KB** |       **0.001** |
| BuilderLatestOnly | MorningStar | 1000  |     674.5 μs |     6.44 μs |     3.83 μs |  0.03 |    0.00 |          - |         - |     18.18 KB |       0.000 |
| NativeSingle      | MorningStar | 1000  |  19,930.8 μs |   456.20 μs |   301.75 μs |  1.00 |    0.02 |  3000.0000 |  250.0000 |  50073.01 KB |       1.000 |
| NativeParallel    | MorningStar | 1000  |  12,833.9 μs |   451.54 μs |   298.66 μs |  0.64 |    0.02 |  3125.0000 |  500.0000 |  50093.76 KB |       1.000 |
|                   |             |       |              |             |             |       |         |            |           |              |             |
| **BuilderFull**       | **MorningStar** | **10000** |   **3,920.2 μs** |   **172.98 μs** |   **114.41 μs** |  **0.02** |    **0.00** |    **31.2500** |         **-** |    **587.05 KB** |       **0.001** |
| BuilderLatestOnly | MorningStar | 10000 |   3,637.5 μs |   224.76 μs |   148.67 μs |  0.02 |    0.00 |          - |         - |    116.94 KB |       0.000 |
| NativeSingle      | MorningStar | 10000 | 204,607.5 μs | 5,209.17 μs | 3,445.54 μs |  1.00 |    0.02 | 31000.0000 | 2750.0000 | 510413.38 KB |       1.000 |
| NativeParallel    | MorningStar | 10000 | 126,980.1 μs | 2,783.50 μs | 1,841.11 μs |  0.62 |    0.01 | 32000.0000 | 5750.0000 | 510601.96 KB |       1.000 |
