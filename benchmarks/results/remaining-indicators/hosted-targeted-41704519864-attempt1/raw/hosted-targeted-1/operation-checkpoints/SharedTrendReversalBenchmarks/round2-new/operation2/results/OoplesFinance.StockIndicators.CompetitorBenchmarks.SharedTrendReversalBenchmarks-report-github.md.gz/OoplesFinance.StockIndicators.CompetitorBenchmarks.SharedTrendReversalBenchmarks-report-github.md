```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0       | Gen1      | Allocated    | Alloc Ratio |
|------------------ |----------------- |------ |-------------:|------------:|------------:|------:|--------:|-----------:|----------:|-------------:|------------:|
| **BuilderFull**       | **MoringinDojiStar** | **1000**  |     **541.8 μs** |     **3.35 μs** |     **1.99 μs** |  **0.05** |    **0.00** |          **-** |         **-** |     **63.22 KB** |       **0.002** |
| BuilderLatestOnly | MoringinDojiStar | 1000  |     539.2 μs |     2.46 μs |     1.28 μs |  0.05 |    0.00 |          - |         - |     15.36 KB |       0.001 |
| NativeSingle      | MoringinDojiStar | 1000  |  10,334.6 μs |   651.34 μs |   430.82 μs |  1.00 |    0.06 |  1500.0000 |  125.0000 |  26324.21 KB |       1.000 |
| NativeParallel    | MoringinDojiStar | 1000  |   6,657.6 μs |   348.03 μs |   230.20 μs |  0.65 |    0.03 |  1600.0000 |  266.6667 |  26330.42 KB |       1.000 |
|                   |                  |       |              |             |             |       |         |            |           |              |             |
| **BuilderFull**       | **MoringinDojiStar** | **10000** |   **3,075.4 μs** |   **180.94 μs** |   **119.68 μs** |  **0.03** |    **0.00** |    **31.2500** |         **-** |    **575.74 KB** |       **0.002** |
| BuilderLatestOnly | MoringinDojiStar | 10000 |   2,977.7 μs |    88.24 μs |    46.15 μs |  0.03 |    0.00 |          - |         - |    105.48 KB |       0.000 |
| NativeSingle      | MoringinDojiStar | 10000 | 102,976.2 μs | 2,411.85 μs | 1,435.25 μs |  1.00 |    0.02 | 16250.0000 | 1500.0000 | 266747.51 KB |       1.000 |
| NativeParallel    | MoringinDojiStar | 10000 |  65,142.8 μs | 1,121.85 μs |   667.59 μs |  0.63 |    0.01 | 16750.0000 | 3250.0000 | 266835.85 KB |       1.000 |
