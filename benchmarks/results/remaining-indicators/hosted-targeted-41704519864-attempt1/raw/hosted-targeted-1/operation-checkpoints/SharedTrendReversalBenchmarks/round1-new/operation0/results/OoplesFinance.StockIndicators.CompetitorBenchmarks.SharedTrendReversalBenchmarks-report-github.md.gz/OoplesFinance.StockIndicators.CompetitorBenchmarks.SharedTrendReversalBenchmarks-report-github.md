```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **EveningDojiStar** | **1000**  |   **552.0 μs** |   **8.52 μs** |  **4.46 μs** |       **-** |  **63.22 KB** |
| BuilderLatestOnly | EveningDojiStar | 1000  |   546.6 μs |   1.65 μs |  0.86 μs |       - |  15.36 KB |
| **BuilderFull**       | **EveningDojiStar** | **10000** | **2,834.2 μs** | **154.10 μs** | **91.71 μs** | **31.2500** | **575.76 KB** |
| BuilderLatestOnly | EveningDojiStar | 10000 | 3,038.9 μs | 149.81 μs | 99.09 μs |       - | 105.35 KB |
