```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |-------------------- |------------:|----------:|----------:|------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Curvature** |    **751.6 μs** |  **36.20 μs** |  **23.94 μs** |  **1.00** |    **0.04** |  **1151.02 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Curvature |    262.6 μs |  12.42 μs |   7.39 μs |  0.35 |    0.01 |   897.68 KB |        0.78 |
|            |       |                     |             |           |           |       |         |             |             |
| **Ooples**     | **10000** | **QuanTAlib.Curvature** | **17,262.2 μs** | **208.61 μs** | **124.14 μs** |  **1.00** |    **0.01** | **14102.15 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Curvature |  2,735.3 μs | 144.93 μs |  95.87 μs |  0.16 |    0.01 |  9011.11 KB |        0.64 |
