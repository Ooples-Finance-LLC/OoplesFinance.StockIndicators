```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error       | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |------ |-----------:|------------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **1000**  |   **581.4 μs** |    **60.91 μs** |  **40.29 μs** |  **23.4375** |   **3.9063** |  **418.64 KB** |
| BuilderLatestOnly | 1000  |   588.1 μs |    55.66 μs |  36.82 μs |  19.5313 |   3.9063 |  371.03 KB |
| **BuilderFull**       | **10000** | **5,644.2 μs** |   **767.30 μs** | **456.61 μs** | **218.7500** | **156.2500** | **4009.71 KB** |
| BuilderLatestOnly | 10000 | 6,575.3 μs | 1,081.56 μs | 715.38 μs | 187.5000 |  62.5000 | 3539.85 KB |
