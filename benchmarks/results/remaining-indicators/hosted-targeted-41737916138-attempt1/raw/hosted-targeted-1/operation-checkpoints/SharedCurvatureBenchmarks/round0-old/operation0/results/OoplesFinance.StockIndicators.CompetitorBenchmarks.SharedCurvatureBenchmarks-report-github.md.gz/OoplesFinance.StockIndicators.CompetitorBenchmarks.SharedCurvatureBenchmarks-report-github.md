```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |------ |-----------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **1000**  |   **580.7 μs** |  **62.69 μs** |  **41.47 μs** |  **23.4375** |   **3.9063** |  **418.64 KB** |
| BuilderLatestOnly | 1000  |   587.0 μs |  35.19 μs |  23.27 μs |  19.5313 |   3.9063 |  371.03 KB |
| **BuilderFull**       | **10000** | **5,107.5 μs** | **462.82 μs** | **306.13 μs** | **218.7500** | **156.2500** | **4009.68 KB** |
| BuilderLatestOnly | 10000 | 4,982.8 μs | 442.16 μs | 292.46 μs | 187.5000 |  62.5000 | 3539.85 KB |
