```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |------ |-----------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **1000**  |   **820.5 μs** | **207.72 μs** | **137.40 μs** |  **3.32** |    **0.54** |        **-** |        **-** |        **-** |  **418.74 KB** |        **0.51** |
| BuilderLatestOnly | 1000  |   593.9 μs |  59.06 μs |  39.07 μs |  2.40 |    0.17 |  19.5313 |   3.9063 |        - |  371.04 KB |        0.45 |
| NativeSingle      | 1000  |   247.8 μs |  14.97 μs |   9.90 μs |  1.00 |    0.05 |  48.8281 |   5.8594 |        - |  817.36 KB |        1.00 |
| NativeParallel    | 1000  |   181.3 μs |   5.85 μs |   3.48 μs |  0.73 |    0.03 |  52.7344 |   5.8594 |        - |  881.55 KB |        1.08 |
|                   |       |            |           |           |       |         |          |          |          |            |             |
| **BuilderFull**       | **10000** | **5,189.0 μs** | **325.42 μs** | **215.25 μs** |  **1.39** |    **0.09** | **218.7500** | **156.2500** |        **-** | **4009.69 KB** |        **0.49** |
| BuilderLatestOnly | 10000 | 5,208.1 μs | 498.29 μs | 329.59 μs |  1.40 |    0.11 | 187.5000 |  62.5000 |        - | 3539.85 KB |        0.43 |
| NativeSingle      | 10000 | 3,731.9 μs | 271.19 μs | 179.37 μs |  1.00 |    0.07 | 593.7500 | 125.0000 | 125.0000 | 8250.59 KB |        1.00 |
| NativeParallel    | 10000 | 2,272.9 μs | 258.19 μs | 170.78 μs |  0.61 |    0.05 | 593.7500 | 125.0000 | 125.0000 | 8315.02 KB |        1.01 |
