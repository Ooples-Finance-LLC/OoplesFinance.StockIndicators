```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |------ |-----------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **1000**  |   **560.6 μs** |  **31.59 μs** |  **16.52 μs** |  **23.4375** |   **3.9063** |  **418.64 KB** |
| BuilderLatestOnly | 1000  |   563.1 μs |  31.88 μs |  16.67 μs |  19.5313 |   3.9063 |  371.03 KB |
| **BuilderFull**       | **10000** | **5,435.7 μs** | **586.20 μs** | **387.74 μs** | **218.7500** | **156.2500** | **4009.67 KB** |
| BuilderLatestOnly | 10000 | 6,855.5 μs | 633.98 μs | 377.27 μs | 187.5000 |  62.5000 | 3539.85 KB |
