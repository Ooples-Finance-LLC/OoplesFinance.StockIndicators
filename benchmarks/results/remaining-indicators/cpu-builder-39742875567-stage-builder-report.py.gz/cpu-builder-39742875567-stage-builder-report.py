from pathlib import Path
import datetime,hashlib,html,json,re,subprocess,sys
ROOT=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
REPO=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
runs=sys.argv[1:];assert runs and all(r.isdigit() for r in runs)
live=Path('C:/Users/cheat/Documents/OoplesFinance-Reports/competitor-performance.html')
out=live.parent/('cpu-builder-refresh-'+runs[-1]);out.mkdir(exist_ok=True)
original=live.read_bytes();assert not (out/'before.html').exists() or (out/'before.html').read_bytes()==original
s=original.decode('utf-8')
def embedded(name):return json.loads(re.search(r'<script[^>]*id="'+name+r'"[^>]*>(.*?)</script>',s,re.S)[1])
def replace(name,value):
 global s
 s,n=re.subn(r'(<script[^>]*id="'+name+r'"[^>]*>).*?(</script>)',lambda m:m[1]+json.dumps(value,ensure_ascii=True).replace('<','\\u003c')+m[2],s,flags=re.S);assert n==1
baseline=embedded('dataset');archive=embedded('archived-baseline-dataset');builder=embedded('current-competitor-data');status=embedded('rollout-status-data')
oldcounts=status['measurement_totals'].copy();oldreceipts=len(builder['receipts']);evidence=REPO/'benchmarks/results/remaining-indicators'
added=0
for run in runs:
 summary=json.loads((evidence/('cpu-builder-'+run+'-summary.json')).read_text(encoding='utf-8'));assert summary['run_id']==run
 receipts=[json.loads((evidence/n).read_text(encoding='utf-8')) for n in summary['receipt_files']]
 assert sum(len(r['comparisons']) for r in receipts)==summary['comparisons']
 assert all(r['complete'] and str(r['run_id'])==run for r in receipts)
 builder['receipts'].extend(receipts);added+=summary['comparisons']
 status['builder_measurement_sources'].append({'source_sha':summary['source_sha'],'run_url':'https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/'+run,'comparisons':summary['comparisons'],'changed_production_files_since_baseline':summary['changed_production_files_since_baseline']})
rows=[{**r,'run_id':str(receipt['run_id']),'source_sha':receipt['source_sha']} for receipt in builder['receipts'] for r in receipt['comparisons']]
assert len(rows)==oldcounts['measured']+added
assert len({(r['pair'],r['bars'],r['mode']) for r in rows})==len(rows)
assert all(r['pair'] in {b['pair'] for b in baseline['rows']} for r in rows)
counts={v:sum(r['verdict']==v for r in rows) for v in ['faster','slower','inconclusive']}
total=len(rows);pending=1604-total;pairs=len({r['pair'] for r in rows});assert total==pairs*4 and pending>=0
now=datetime.datetime.now(datetime.timezone.utc).isoformat();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
oldhead=status['published_head'];status.update(updated_utc=now,published_head=head,inventory_commit=head);status['measurement_totals'].update(**counts,measured=total,pending=pending)
builder.update(full_comparisons=total,verdicts=counts);builder['status'].update(updated_utc=now,status='partial-coverage-measured',qualification='Matched native serial/parallel measurements; partial coverage, not universal superiority.')
replace('current-competitor-data',builder);replace('rollout-status-data',status)
m=re.search(r'<section id="rollout-status".*?</section>',s,re.S);panel=m[0]
old=f"<b>{oldcounts['measured']} / 1604</b>";assert old in panel;panel=panel.replace(old,f'<b>{total} / 1604</b>')
old=f"Builder-mode timing: {oldcounts['faster']} faster, {oldcounts['slower']} slower, {oldcounts['inconclusive']} inconclusive, and {oldcounts['pending']} pending.";assert old in panel
panel=panel.replace(old,f"Builder-mode timing: {counts['faster']} faster, {counts['slower']} slower, {counts['inconclusive']} inconclusive, and {pending} pending.")
panel=re.sub(r'[A-Z][a-z -]+ API pairs have matched builder measurements',f'{pairs} API pairs have matched builder measurements',panel)
panel=panel.replace(oldhead[:8],head[:8]);s=s[:m.start()]+panel+s[m.end():]
body=[]
for r in sorted(rows,key=lambda r:(r['pair'],r['bars'],r['mode'])):
 values=[r['pair'],f"{r['bars']:,}",'Full history' if r['mode']=='BuilderFull' else 'Latest only',f"{r['ooples']['mean_ns']/1e6:.6f}",f"{r['native']['NativeSingle']['mean_ns']/1e6:.6f}",f"{r['native']['NativeParallel']['mean_ns']/1e6:.6f}",{'faster':'Faster than both','slower':'Slower than at least one','inconclusive':'Inconclusive'}[r['verdict']]]
 body.append('<tr data-builder-pair="'+html.escape(r['pair'],quote=True)+'" data-bars="'+str(r['bars'])+'" data-mode="'+r['mode']+'">'+''.join('<td>'+html.escape(v)+'</td>' for v in values)+'<td><a href="https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/'+r['run_id']+'">'+r['run_id']+'</a></td></tr>')
s,n=re.subn(r'(<table id="builder-current-results">.*?<tbody>).*?(</tbody>)',lambda m:m[1]+''.join(body)+m[2],s,flags=re.S);assert n==1
text=f"{total} / 1604 matched slots measured across {pairs} API pairs: {counts['faster']} faster, {counts['slower']} slower, {counts['inconclusive']} inconclusive, {pending} pending."
s,n=re.subn(r'\d+ / 1604 matched slots measured across \d+ API pairs: \d+ faster, \d+ slower, \d+ inconclusive, \d+ pending\.',lambda _:text,s);assert n==1
s,n=re.subn(r'(<tr><td>Current matched candidate</td><td>)\d+ / 1604',lambda m:m[1]+str(total)+' / 1604',s);assert n==1
assert embedded('dataset')==baseline and embedded('archived-baseline-dataset')==archive
(out/'before.html').write_bytes(original);(out/'candidate.html').write_text(s,encoding='utf-8')
(out/'staged.json').write_text(json.dumps({'before_sha256':hashlib.sha256(original).hexdigest(),'candidate_sha256':hashlib.sha256((out/'candidate.html').read_bytes()).hexdigest(),'builder_run_id':runs[-1],'builder_runs':runs,'builder_comparisons':total,'new_builder_comparisons':added,'prior_receipts':oldreceipts,'unchanged_baseline_comparisons':802,'rows':rows,'verdicts':counts},indent=2),encoding='utf-8')
print('Staged builder results',total,counts,'pending',pending)
