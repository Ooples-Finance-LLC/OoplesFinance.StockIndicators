```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)ltOsc [22]** | **1000**  | **128.8 μs** | **14.18 μs** |  **9.38 μs** |  **3.9063** |       **-** |  **65.12 KB** |
| BuilderLatestOnly | TaLib(...)ltOsc [22] | 1000  | 117.9 μs |  1.23 μs |  0.64 μs |  0.9766 |       - |  17.52 KB |
| **BuilderFull**       | **TaLib(...)ltOsc [22]** | **10000** | **398.0 μs** | **18.49 μs** | **11.00 μs** | **35.1563** | **11.7188** |    **628 KB** |
| BuilderLatestOnly | TaLib(...)ltOsc [22] | 10000 | 384.1 μs | 25.21 μs | 16.68 μs |  7.8125 |  1.9531 | 158.15 KB |
