```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)ltOsc [22]** | **1000**  | **123.08 μs** |  **5.837 μs** |  **3.474 μs** |  **5.93** |    **0.16** |  **3.9063** |       **-** |  **65.12 KB** |        **8.50** |
| BuilderLatestOnly | TaLib(...)ltOsc [22] | 1000  | 117.47 μs |  3.434 μs |  2.044 μs |  5.66 |    0.10 |  0.9766 |       - |  17.52 KB |        2.29 |
| NativeSingle      | TaLib(...)ltOsc [22] | 1000  |  20.76 μs |  0.190 μs |  0.126 μs |  1.00 |    0.01 |  0.3662 |       - |   7.66 KB |        1.00 |
| NativeParallel    | TaLib(...)ltOsc [22] | 1000  |  95.27 μs |  2.153 μs |  1.424 μs |  4.59 |    0.07 |       - |       - |   7.95 KB |        1.04 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)ltOsc [22]** | **10000** | **401.37 μs** | **31.007 μs** | **20.509 μs** |  **1.94** |    **0.09** | **37.1094** | **13.6719** | **627.99 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)ltOsc [22] | 10000 | 376.85 μs | 20.549 μs | 13.592 μs |  1.82 |    0.06 |  7.8125 |  1.9531 | 158.15 KB |        2.03 |
| NativeSingle      | TaLib(...)ltOsc [22] | 10000 | 207.29 μs |  1.291 μs |  0.768 μs |  1.00 |    0.00 |  3.9063 |       - |  77.98 KB |        1.00 |
| NativeParallel    | TaLib(...)ltOsc [22] | 10000 | 186.92 μs | 16.567 μs | 10.958 μs |  0.90 |    0.05 |  3.9063 |       - |  78.27 KB |        1.00 |
