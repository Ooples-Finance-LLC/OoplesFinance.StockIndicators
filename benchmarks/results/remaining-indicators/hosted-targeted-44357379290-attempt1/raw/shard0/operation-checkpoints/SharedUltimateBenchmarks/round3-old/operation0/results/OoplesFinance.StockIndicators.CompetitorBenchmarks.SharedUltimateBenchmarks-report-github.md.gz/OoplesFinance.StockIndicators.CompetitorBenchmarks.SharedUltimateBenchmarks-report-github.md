```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)ltOsc [22]** | **1000**  | **127.8 μs** | **11.34 μs** |  **7.50 μs** |  **3.9063** |       **-** |  **65.12 KB** |
| BuilderLatestOnly | TaLib(...)ltOsc [22] | 1000  | 118.3 μs |  1.86 μs |  0.97 μs |  0.9766 |       - |  17.51 KB |
| **BuilderFull**       | **TaLib(...)ltOsc [22]** | **10000** | **401.0 μs** | **28.74 μs** | **19.01 μs** | **37.1094** | **13.6719** | **627.99 KB** |
| BuilderLatestOnly | TaLib(...)ltOsc [22] | 10000 | 385.8 μs | 22.80 μs | 15.08 μs |  7.8125 |  1.9531 | 158.15 KB |
