```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetUltimate** | **1000**  |   **128.51 μs** | **13.861 μs** |  **9.168 μs** |  **1.35** |    **0.09** |  **3.9063** |       **-** |   **65.12 KB** |        **0.43** |
| BuilderLatestOnly | Skender.GetUltimate | 1000  |   117.29 μs |  3.363 μs |  2.224 μs |  1.24 |    0.03 |  0.9766 |       - |   17.52 KB |        0.11 |
| NativeSingle      | Skender.GetUltimate | 1000  |    94.97 μs |  1.599 μs |  0.951 μs |  1.00 |    0.01 |  9.2773 |  1.9531 |  152.82 KB |        1.00 |
| NativeParallel    | Skender.GetUltimate | 1000  |   145.90 μs |  8.102 μs |  4.822 μs |  1.54 |    0.05 |  9.7656 |  1.9531 |  167.33 KB |        1.09 |
|                   |                     |       |             |           |           |       |         |         |         |            |             |
| **BuilderFull**       | **Skender.GetUltimate** | **10000** |   **385.30 μs** | **22.674 μs** | **14.997 μs** |  **0.37** |    **0.01** | **37.1094** | **13.6719** |  **627.99 KB** |        **0.41** |
| BuilderLatestOnly | Skender.GetUltimate | 10000 |   375.97 μs | 28.934 μs | 19.138 μs |  0.36 |    0.02 |  7.8125 |  1.9531 |  158.15 KB |        0.10 |
| NativeSingle      | Skender.GetUltimate | 10000 | 1,041.75 μs | 17.503 μs | 11.577 μs |  1.00 |    0.01 | 85.9375 | 46.8750 | 1523.97 KB |        1.00 |
| NativeParallel    | Skender.GetUltimate | 10000 |   740.31 μs | 52.878 μs | 34.976 μs |  0.71 |    0.03 | 97.6563 | 46.8750 | 1538.44 KB |        1.01 |
