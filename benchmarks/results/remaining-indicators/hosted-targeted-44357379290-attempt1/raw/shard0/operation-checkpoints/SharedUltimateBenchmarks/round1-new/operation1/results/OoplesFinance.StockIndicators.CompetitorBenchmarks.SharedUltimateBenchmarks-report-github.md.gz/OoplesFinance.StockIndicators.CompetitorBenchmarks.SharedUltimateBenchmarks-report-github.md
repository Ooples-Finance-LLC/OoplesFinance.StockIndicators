```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |-------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetUltimate** | **1000**  | **127.5 μs** | **13.46 μs** |  **8.90 μs** |  **3.9063** |       **-** |  **65.12 KB** |
| BuilderLatestOnly | Skender.GetUltimate | 1000  | 118.6 μs |  3.92 μs |  2.59 μs |  0.9766 |       - |  17.52 KB |
| **BuilderFull**       | **Skender.GetUltimate** | **10000** | **374.6 μs** |  **7.90 μs** |  **4.13 μs** | **35.1563** | **11.7188** |    **628 KB** |
| BuilderLatestOnly | Skender.GetUltimate | 10000 | 375.3 μs | 26.78 μs | 17.71 μs |  7.8125 |  1.9531 | 158.15 KB |
