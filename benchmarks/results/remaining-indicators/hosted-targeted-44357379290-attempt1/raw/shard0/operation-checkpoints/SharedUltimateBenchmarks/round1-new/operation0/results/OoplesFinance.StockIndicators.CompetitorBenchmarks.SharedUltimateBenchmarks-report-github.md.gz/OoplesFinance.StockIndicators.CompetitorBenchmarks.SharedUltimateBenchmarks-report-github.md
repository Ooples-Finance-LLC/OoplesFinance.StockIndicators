```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error   | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |---------:|--------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)ltOsc [22]** | **1000**  | **126.1 μs** | **9.79 μs** | **5.12 μs** |  **3.9063** |       **-** |  **65.12 KB** |
| BuilderLatestOnly | TaLib(...)ltOsc [22] | 1000  | 120.3 μs | 7.84 μs | 5.18 μs |  0.9766 |       - |  17.52 KB |
| **BuilderFull**       | **TaLib(...)ltOsc [22]** | **10000** | **382.6 μs** | **7.39 μs** | **3.87 μs** | **35.1563** | **11.7188** |    **628 KB** |
| BuilderLatestOnly | TaLib(...)ltOsc [22] | 10000 | 366.5 μs | 5.90 μs | 3.51 μs |  7.8125 |       - | 158.17 KB |
