```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)ltOsc [22]** | **158.88 μs** |  **4.802 μs** |  **2.858 μs** |  **1.00** |    **0.02** | **105.68 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)ltOsc [22] |  22.73 μs |  1.434 μs |  0.750 μs |  0.14 |    0.01 |  40.27 KB |        0.38 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)ltOsc [22]** | **881.64 μs** | **30.731 μs** | **18.287 μs** |  **1.00** |    **0.03** | **1047.2 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)ltOsc [22] | 209.20 μs |  4.767 μs |  2.493 μs |  0.24 |    0.01 | 330.63 KB |        0.32 |
