```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId              | Mean       | Error    | StdDev   | Ratio | Allocated  | Alloc Ratio |
|------- |------ |-------------------- |-----------:|---------:|---------:|------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetUltimate** |   **261.9 μs** |  **4.12 μs** |  **2.45 μs** |  **1.00** |   **121.6 KB** |        **1.00** |
|        |       |                     |            |          |          |       |            |             |
| **Ooples** | **10000** | **Skender.GetUltimate** | **2,732.9 μs** | **17.92 μs** | **10.66 μs** |  **1.00** | **1062.47 KB** |        **1.00** |
