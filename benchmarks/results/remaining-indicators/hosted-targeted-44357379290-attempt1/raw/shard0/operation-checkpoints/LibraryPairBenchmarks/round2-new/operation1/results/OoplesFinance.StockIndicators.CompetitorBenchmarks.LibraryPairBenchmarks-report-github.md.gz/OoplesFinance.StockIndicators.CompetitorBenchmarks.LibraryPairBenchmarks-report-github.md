```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetUltimate** |   **125.7 μs** | **19.72 μs** | **13.05 μs** |  **1.01** |    **0.14** |  **105.68 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetUltimate |   169.2 μs | 16.13 μs |  9.60 μs |  1.36 |    0.15 |  185.97 KB |        1.76 |
|            |       |                     |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetUltimate** |   **853.8 μs** | **41.72 μs** | **24.83 μs** |  **1.00** |    **0.04** | **1047.53 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetUltimate | 1,814.4 μs | 22.55 μs | 13.42 μs |  2.13 |    0.06 | 1776.79 KB |        1.70 |
