"""Scoped CLI data/CSV/static builder verification, no browser claims."""
import argparse,collections,csv,hashlib,html,json,re
from html.parser import HTMLParser
from pathlib import Path
p=argparse.ArgumentParser()
for n in ('stage','csv','summary'):p.add_argument('--'+n,type=Path,required=True)
p.add_argument('--run',required=True);p.add_argument('--source',required=True);a=p.parse_args()
assert a.run=='44357379290' and a.source=='c5bfd4950982aa80dddbfd2db6358ad43ddb9e4c'
def emb(t,n):return json.loads(re.search(r'<script[^>]*id="'+n+r'"[^>]*>(.*?)</script>',t,re.S)[1])
before=(a.stage/'before.html').read_text(encoding='utf-8');after=(a.stage/'candidate.html').read_text(encoding='utf-8')
bdata,ndata=emb(before,'dataset'),emb(after,'dataset')
keys={(pair,size) for pair in ('TaLib.Functions.UltOsc','Skender.GetUltimate') for size in (1000,10000)}
def base(d):
 x={(r['pair'],r['bars']):r for r in d['rows']};assert len(x)==len(d['rows'])==802;return x
b,n=base(bdata),base(ndata);assert {k for k in b if b[k]!=n[k]}==keys
assert all(b[k]==n[k] for k in b.keys()-keys)
def builders(t):
 rows=[c for r in emb(t,'current-competitor-data')['receipts'] for c in r['comparisons']]
 x={(r['pair'],r['bars'],r['mode']):r for r in rows};assert len(x)==len(rows)==1544;return x
bb,bn=builders(before),builders(after);bkeys={(p,s,m) for p,s in keys for m in ('BuilderFull','BuilderLatestOnly')}
runids={(c['pair'],c['bars'],c['mode']):r['run_id'] for r in emb(after,'current-competitor-data')['receipts'] for c in r['comparisons']}
assert {k for k in bb if bb[k]!=bn[k]}==bkeys and all(bb[k]==bn[k] for k in bb.keys()-bkeys)
summary=json.loads(a.summary.read_text());assert summary['accepted'] and summary['qualification'] and not summary['production_integrated'] and not summary['report_imported']
raw={(r['pair'],r['bars'],r['method']):r for r in summary['final_candidate_rows']['LibraryPairBenchmarks']}
for key in keys:
 row=n[key];assert row['source_sha']==a.source and str(row['measurement_run_id'])==a.run
 assert row['measurement_kind']=='qualified-source-verification'
 assert row['benchmark_source_sha']=='9e914007c3438d9f251f3fab9ef321d49c22de83' and row['benchmark_assembly_sha256']=='07e764bd27110b4452e1f181f466a6ea0e60b4ae4667d01b6c75f468ae8aee07'
 for method,arm in [('Ooples','ooples'),('Competitor','competitor')]:
  expected=raw[(*key,method)]
  assert row[arm+'_mean_ns']==expected['mean_ns'] and row[arm+'_samples']==expected['samples'] and row[arm+'_allocated_bytes']==expected['allocated_bytes']
  assert len(row['raw'][method]['samples'])==expected['samples']
 assert not any(k in row for k in ('same_binary_verdict','native_consensus','baseline_refresh_reason','harness_changed'))
rows=list(csv.DictReader(a.csv.open(encoding='utf-8-sig',newline='')));assert len(rows)==802
export={(r['pair'],int(r['bars'])):r for r in rows};assert len(export)==802 and export.keys()==n.keys()
for key,row in export.items():
 for field in ('ooples_mean_ns','competitor_mean_ns','competitor_over_ooples'):assert float(row[field])==n[key][field],(key,field)
 for field in ('source_sha','measurement_kind','canonical_gpu_receipt_sha256','production_assembly_sha256','benchmark_source_sha','benchmark_assembly_sha256'):
  assert row.get(field,'')==str(n[key].get(field,'') or ''),(key,field)

class BuilderTable(HTMLParser):
 def __init__(self):super().__init__();self.active=False;self.rows={};self.key=None;self.cells=None;self.cell=None
 def handle_starttag(self,tag,attrs):
  attrs=dict(attrs)
  if tag=='table' and attrs.get('id')=='builder-current-results':self.active=True
  if self.active and tag=='tr' and 'data-builder-pair' in attrs:self.key=(attrs['data-builder-pair'],int(attrs['data-bars']),attrs['data-mode']);self.cells=[]
  if self.active and self.cells is not None and tag=='td':self.cell=''
 def handle_data(self,d):
  if self.cell is not None:self.cell+=d
 def handle_endtag(self,tag):
  if tag=='td' and self.cell is not None:self.cells.append(self.cell);self.cell=None
  if tag=='tr' and self.key is not None:assert self.key not in self.rows;self.rows[self.key]=self.cells;self.key=self.cells=None
  if tag=='table' and self.active:self.active=False
t=BuilderTable();t.feed(after);assert t.rows.keys()==bn.keys()
for key,cells in t.rows.items():
 r=bn[key];assert len(cells)==8 and cells[0]==key[0] and int(cells[1].replace(',',''))==key[1]
 for cell,sample in [(3,r['ooples']),(4,r['native']['NativeSingle']),(5,r['native']['NativeParallel'])]:assert cells[cell]==f"{sample['mean_ns']/1e6:.6f}"
 assert cells[6]=={'faster':'Faster than both','slower':'Slower than at least one','inconclusive':'Inconclusive'}[r['verdict']]
 assert str(runids[key]) in cells[7]
def counts(d):return {str(s):dict(rows=sum(r['bars']==s for r in d['rows']),point_wins=sum(r['bars']==s and r['competitor_over_ooples']>1 for r in d['rows'])) for s in (1000,10000)}
def bc(d):return dict(verdicts=dict(collections.Counter(r['verdict'] for r in d.values())),point_wins=sum(r['ooples']['mean_ns']<min(x['mean_ns'] for x in r['native'].values()) for r in d.values()))
result=dict(status='cli-data-csv-and-static-builder-table-verified',candidate_sha256=hashlib.sha256((a.stage/'candidate.html').read_bytes()).hexdigest(),baseline_before=counts(bdata),baseline_after=counts(ndata),builder_before=bc(bb),builder_after=bc(bn),changed_baseline_rows=4,preserved_baseline_rows=798,replaced_builder_slots=8,preserved_builder_slots=1536,csv_rows_verified=802,builder_html_rows_verified=1544,csv_sha256=hashlib.sha256(a.csv.read_bytes()).hexdigest(),browser_verified=False,live_imported=False)
(a.stage/'cli-data-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
