"""Stage the qualified Ultimate rows on the pending verified TripleBody report. Never import."""
import copy,hashlib,json,os,re,subprocess,sys,tempfile
from pathlib import Path

OPS=Path(r'C:\Users\cheat\source\stock-indicators-operations')
TOOLING=Path(r'C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-lagged-five-roi-tooling-20261118')
SOURCE_REPO=Path(r'C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-ultimate-wider-long-20261118')
PUBLICATION=Path(r'C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-ultimate-direct-long-publication-20261118')
ROOT=OPS/'ultimate-direct-long-qualification-20261118'
EVIDENCE=ROOT/'local-evidence/ultimate-direct-long-qualification-44357379290'
INPUTS=ROOT/'hosted-inputs-44357379290'
PRIOR=OPS/'triple-body-current-0151-report-stage-44222776323'
OUT=OPS/'ultimate-direct-long-composed-report-stage-44357379290'
LIVE=Path(r'C:\Users\cheat\Documents\OoplesFinance-Reports\competitor-performance.html')
RUN='44357379290';SOURCE='c5bfd4950982aa80dddbfd2db6358ad43ddb9e4c'
BASE='f36781297872d2c496e59dd4edff9e702815dc97'
OLD='9e914007c3438d9f251f3fab9ef321d49c22de83'
HEAD='f57f39fb1379acfd7497d562b495cb9aba7f8ae9'
PLAN='benchmarks/plans/hosted-ultimate-direct-long-qualification-20261118.json'
PLAN_SHA='b00904a2ae5a3c534cde95f24f8be7f2b4555645fa7f748c2d14835693f95402'
LIVE_SHA='9dc3d9b721dfaed8f114b6cc5d680d71b726598331236f9a51e0b541d4f81e11'
PRIOR_SHA='36ccf07fdec5721bed8e88a65aa06e6461c8cdc72f1bf16f00d831c907d0558b'
SUMMARY_SHA='da26977f3894f83c515b11339599f659fc0122d085d67b70297c6b6cdaee78a7'
REVIEW_SHA='0c2faeef03c088174e2d013dea5eaab0475cb2ac023338231d45dd9d7ed38431'
CORE='e6aa9aacff74acd49eeebb322cc3f8714d7c40488f450a7d31e215947638d7a8'
GPU='597cbf384a25243db4928bdeac05b2dae771ba3f09e13bcef7f24be046a9b2a7'
HARNESS='07e764bd27110b4452e1f181f466a6ea0e60b4ae4667d01b6c75f468ae8aee07'
PAIRS={'TaLib.Functions.UltOsc','Skender.GetUltimate'}
TRIPLE={'TaLib.Candles.'+name for name in ('ThreeInside','TwoCrows','UpsideGapTwoCrows','UniqueThreeRiver')}
KEYS={(p,n) for p in PAIRS for n in (1000,10000)}
OLD_KEYS={(p,n) for p in TRIPLE for n in (1000,10000)}

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_bytes())
def git(repo,*args):return subprocess.check_output(['git',*args],cwd=repo)
def embedded(text,name):return json.loads(re.search(r'<script[^>]*id="'+name+r'"[^>]*>(.*?)</script>',text,re.S)[1])
def rows(data):
    result={(r['pair'],r['bars']):r for r in data['rows']};assert len(result)==len(data['rows'])==802
    return result
def builders(data):
    result={}
    for receipt in data['receipts']:
        for item in receipt['comparisons']:
            key=item['pair'],item['bars'],item['mode'];assert key not in result
            result[key]=dict(item,receipt_source=receipt['source_sha'],receipt_run=receipt['run_id'])
    assert len(result)==1544
    return result

assert not OUT.exists() and digest(LIVE)==LIVE_SHA
assert digest(PRIOR/'candidate.html')==PRIOR_SHA
assert read(PRIOR/'normalization-receipt.json')['before_sha256']==LIVE_SHA
assert digest(EVIDENCE/'authenticated-summary.json')==SUMMARY_SHA
assert digest(EVIDENCE/'root-review.json')==REVIEW_SHA
review=read(EVIDENCE/'root-review.json');assert review['independent_recollection_matches'] and review['source_gate_passed'] and review['native_progress_gate_passed']
assert git(TOOLING,'rev-parse','HEAD').decode().strip()==HEAD and not git(TOOLING,'status','--porcelain')
assert git(SOURCE_REPO,'rev-parse','HEAD').decode().strip()==SOURCE
assert not git(SOURCE_REPO,'diff','--','src','tests')
assert git(PUBLICATION,'rev-parse','HEAD').decode().strip()==BASE
assert not git(PUBLICATION,'diff',SOURCE,'--','src','tests')
assert digest(TOOLING/PLAN)==PLAN_SHA
assert digest(PUBLICATION/'benchmarks/results/shared-rollout/local-gpu-contracts/receipt.json')==GPU

# Reuse publisher report helpers without adding them to the sparse source checkout.
SUPPORT=OPS/'ultimate-direct-long-report-support-20261118';SUPPORT.mkdir(exist_ok=True)
helper_pins={}
for name in ('primary_baseline_report.py','hosted_performance_results.py'):
    raw=git(PUBLICATION,'show',BASE+':benchmarks/'+name);target=SUPPORT/name
    if target.exists():assert target.read_bytes()==raw
    else:target.write_bytes(raw)
    helper_pins[name]=hashlib.sha256(raw).hexdigest()
os.environ['HOSTED_TIMING_PLAN']=str(TOOLING/PLAN)
sys.path[:0]=[str(TOOLING/'scripts'),str(SUPPORT)]
from hosted_timing import pipeline as pipeline,ultimate_direct_long_qualification as qualification
from hosted_timing.report import stage
proof=pipeline.verify_inputs(INPUTS)
assert proof['production_sha256']['successor']==CORE and proof['common_manifest']['OoplesFinance.StockIndicators.CompetitorBenchmarks.dll']==HARNESS
assert digest(INPUTS/'evidence/successor-original-gpu-receipt.json')==GPU
candidate=stage(PRIOR/'candidate.html',EVIDENCE/'raw/evidence',SOURCE_REPO,OUT,phase='targeted',inputs=INPUTS)

document=candidate.read_text(encoding='utf-8');data=embedded(document,'dataset');before=rows(embedded((PRIOR/'candidate.html').read_text(encoding='utf-8'),'dataset'));current=rows(data)
obsolete={'measurement_kind','baseline_refresh_reason','harness_changed','same_binary_verdict','native_round_classifications','native_consensus','native_control_round','native_control_count','canonical_gpu_source_sha','canonical_gpu_receipt_sha256','production_assembly_sha256'}
for key in KEYS:
    row=current[key];assert row['source_sha']==SOURCE and str(row['measurement_run_id'])==RUN
    for field in obsolete:row.pop(field,None)
    row.update(measurement_kind='qualified-source-verification',production_assembly_sha256=CORE,
        canonical_gpu_source_sha=SOURCE,canonical_gpu_receipt_sha256=GPU,
        benchmark_source_sha=OLD,benchmark_assembly_sha256=HARNESS,
        qualification_role='optimization-target',production_optimization=True)
assert all(current[key]==before[key] for key in before.keys()-KEYS)
assert all(current[key]==before[key] and current[key]['source_sha']==OLD and str(current[key]['measurement_run_id'])=='44222776323' for key in OLD_KEYS)
document,count=re.subn(r'(<script[^>]*id="dataset"[^>]*>).*?(</script>)',lambda m:m[1]+json.dumps(data,ensure_ascii=True).replace('<','\\u003c')+m[2],document,flags=re.S);assert count==1
candidate.write_bytes(document.encode())
staged=read(OUT/'staged.json');assert tuple(staged[k] for k in ('changed_baseline_rows','unchanged_baseline_rows','changed_builder_slots','replaced_builder_slots','added_builder_slots'))==(4,798,8,8,0)
staged['candidate_sha256']=digest(candidate);(OUT/'staged.json').write_text(json.dumps(staged,indent=2)+'\n')
prior_builders=builders(embedded((PRIOR/'candidate.html').read_text(encoding='utf-8'),'current-competitor-data'))
after_builders=builders(embedded(document,'current-competitor-data'))
ultimate_builders={(p,n,m) for p in PAIRS for n in (1000,10000) for m in ('BuilderFull','BuilderLatestOnly')}
assert all(after_builders[k]==prior_builders[k] for k in prior_builders.keys()-ultimate_builders)
anchor=LIVE.read_text(encoding='utf-8');anchor_rows=rows(embedded(anchor,'dataset'));anchor_builders=builders(embedded(anchor,'current-competitor-data'))
assert {key for key in current if current[key]!=anchor_rows[key]}==KEYS|OLD_KEYS
changed_builders={key for key in after_builders if after_builders[key]!=anchor_builders[key]}
assert changed_builders==ultimate_builders|{(p,n,m) for p in TRIPLE for n in (1000,10000) for m in ('BuilderFull','BuilderLatestOnly')}
assert digest(LIVE)==LIVE_SHA and not (OUT/'browser-verification.json').exists()
receipt=dict(status='composed-staged-only-browser-and-import-pending',source=SOURCE,publisher_base=BASE,run_id=RUN,
    actual_live_before_sha256=LIVE_SHA,pending_triplebody_input_sha256=PRIOR_SHA,candidate_sha256=digest(candidate),
    accepted_summary_sha256=SUMMARY_SHA,root_review_sha256=REVIEW_SHA,plan_sha256=PLAN_SHA,
    production_sha256=CORE,gpu_receipt_sha256=GPU,canonical_harness_sha256=HARNESS,canonical_harness_source=OLD,
    new_ultimate_baseline_rows=4,new_ultimate_builder_slots=8,preserved_pending_triplebody_rows=8,preserved_pending_triplebody_builder_slots=16,
    total_changed_from_live_baseline_rows=12,total_changed_from_live_builder_slots=24,unchanged_from_live_baseline_rows=790,
    unrelated_builder_slots_preserved=1536,report_helpers=helper_pins,live_imported=False,browser_verified=False,published_closure_credit=0)
(OUT/'composition-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
