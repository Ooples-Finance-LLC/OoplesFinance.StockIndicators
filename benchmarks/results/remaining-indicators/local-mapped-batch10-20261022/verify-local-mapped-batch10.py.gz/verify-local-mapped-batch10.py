from pathlib import Path
import collections,hashlib,json,math,re,subprocess
ROOT=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
OUT=ROOT/'local-mapped-batch10-20261022'
REPO=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
SOURCE=json.loads((OUT/'provenance.json').read_text(encoding='utf-8'))['source_sha']
assert not (OUT/'invalidated.json').exists()
state=json.loads((OUT/'status.json').read_text());assert state['status']=='raw-measurements-complete-independent-verification-pending'
proof=json.loads((OUT/'provenance.json').read_text());assert proof['source_sha']==state['source_sha']==SOURCE
paths=['src','tests','benchmarks/OoplesFinance.StockIndicators.CompetitorTests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json']
assert not subprocess.check_output(['git','diff',SOURCE,'HEAD','--',*paths],cwd=REPO)
assert not subprocess.check_output(['git','diff',proof['qualification']['input_head'],SOURCE,'--',*paths],cwd=REPO)
assert proof['qualification']['gpu_passed']==100 and proof['qualification']['parity']['passed']==78
assert proof['qualification']['status']=='checks-passed-review-and-publication-pending'
manifest=json.loads((OUT/'binary-manifest.json').read_text())
assert hashlib.sha256((OUT/'binary-manifest.json').read_bytes()).hexdigest()==proof['copied_binary_manifest_sha256']
for name,h in manifest.items():
 assert hashlib.sha256((Path(proof['executed_binary_directory'])/name).read_bytes()).hexdigest()==h
 assert hashlib.sha256((Path(proof['original_binary_directory'])/name).read_bytes()).hexdigest()==h
fixtures={'SharedContainmentCandleBenchmarks': ['TaLib.Candles.Harami', 'TaLib.Candles.HaramiCross', 'TaLib.Candles.HomingPigeon', 'TaLib.Candles.DojiStar'], 'SharedContextReversalBenchmarks': ['TaLib.Candles.Hammer', 'TaLib.Candles.HangingMan', 'TaLib.Candles.InvertedHammer', 'TaLib.Candles.ShootingStar'], 'SharedKickingCandleBenchmarks': ['TaLib.Candles.Kicking', 'TaLib.Candles.KickingByLength'], 'SharedNeckCandleBenchmarks': ['TaLib.Candles.OnNeck', 'TaLib.Candles.InNeck', 'TaLib.Candles.Thrusting']}
prefixes={}
aliases={}
receipts=[]
for fixture,pairs in fixtures.items():
 status=state['fixtures'][fixture];assert status['status']=='raw-measurements-complete' and len(status['quiet_cpu_samples'])==3 and max(status['quiet_cpu_samples'])<=15
 raw=Path(status['report']).read_bytes();assert hashlib.sha256(raw).hexdigest()==status['sha256'];report=json.loads(raw);cases={}
 assert 'Windows' in report['HostEnvironmentInfo']['OsVersion']
 for c in report['Benchmarks']:
  full=c['FullName'];assert fixture+'.' in full
  operation=re.search(r'Operation: "([^"]+)"',full);assert operation is not None
  pair=operation[1];bars=int(re.search(r'Count: (\d+)',full)[1]);key=pair,bars,c['Method'];assert key not in cases
  s=c['Statistics'];ci=s['ConfidenceInterval'];values=s['OriginalValues'];assert s['N']==len(values)>=7
  assert all(math.isfinite(x) and x>0 for x in values) and math.isclose(sum(values)/len(values),s['Mean'],rel_tol=1e-12)
  assert math.isfinite(ci['Lower']) and ci['Lower']<=s['Mean']<=ci['Upper']
  cases[key]={'mean_ns':s['Mean'],'lower_ns':ci['Lower'],'upper_ns':ci['Upper'],'samples':s['N'],'allocated_bytes':c['Memory']['BytesAllocatedPerOperation']}
 assert cases.keys()=={(pair,bars,method) for pair in pairs for bars in [1000,10000] for method in ['BuilderFull','BuilderLatestOnly','NativeSingle','NativeParallel']}
 comparisons=[]
 for pair in pairs:
  for bars in [1000,10000]:
   native={m:cases[pair,bars,m] for m in ['NativeSingle','NativeParallel']}
   for mode in ['BuilderFull','BuilderLatestOnly']:
    ours=cases[pair,bars,mode];verdict='faster' if ours['upper_ns']<min(n['lower_ns'] for n in native.values()) else 'slower' if ours['lower_ns']>min(n['upper_ns'] for n in native.values()) else 'inconclusive'
    comparisons.append({'pair':pair,'bars':bars,'mode':mode,'ooples':ours,'native':native,'fastest_native':min(native,key=lambda m:native[m]['mean_ns']),'verdict':verdict})
 receipts.append({'fixture':fixture,'source_sha':SOURCE,'run_id':'local-mapped-batch10-20261022','measurement_location':'Local Windows host; unchanged CPU setup and direct native methods.','host':report['HostEnvironmentInfo'],'report_sha256':status['sha256'],'report_file':str(Path(status['report']).relative_to(OUT)),'quiet_cpu_samples':status['quiet_cpu_samples'],'complete':True,'comparisons':comparisons})
summary={'source_sha':SOURCE,'all_104_cases_verified':True,'matched_current_source_paths':paths,'receipts':receipts,'verdicts':dict(collections.Counter(r['verdict'] for x in receipts for r in x['comparisons']))}
(OUT/'verified-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print('Verified104 cases and52 comparison slots',summary['verdicts'])
