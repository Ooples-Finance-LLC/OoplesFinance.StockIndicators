$ErrorActionPreference = 'Stop'
$runtimeT3 = 'C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-t3-state-checked-regions-20261113\benchmarks\OoplesFinance.StockIndicators.CompetitorBenchmarks\bin\Release\net10.0'
$expectedT3 = '8c5f517a7076c17469d1fcb85f88335559fd41344bbe8e54be362befa4d4eff7'
if ((Get-FileHash -LiteralPath (Join-Path $runtimeT3 'OoplesFinance.StockIndicators.dll')).Hash.ToLowerInvariant() -ne $expectedT3) { throw 'Production hash mismatch' }
Add-Type -TypeDefinition @'
using System;
using System.Collections;
using System.Linq;
using System.Linq.Expressions;
using System.IO;
using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
public static class T3NestedPoolCheck {
 const BindingFlags Flags=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Static|BindingFlags.Instance;
 static string Fingerprint(object series) {
  var text=new StringBuilder();
  foreach(var entry in (IEnumerable)series.GetType().GetProperty("Outputs",Flags).GetValue(series)) {
   var type=entry.GetType();var value=type.GetProperty("Value").GetValue(entry);var vt=value.GetType();
   text.Append(type.GetProperty("Key").GetValue(entry)).Append(':').Append(vt.GetProperty("FirstValid").GetValue(value)).Append(';');
   foreach(double number in (double[])vt.GetProperty("Values").GetValue(value))text.Append(BitConverter.DoubleToInt64Bits(number).ToString("X16"));
   var mask=(bool[])vt.GetProperty("Present").GetValue(value);
   text.Append(mask==null?"null":string.Concat(mask.Select(x=>x?'1':'0')));
  }
  return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(text.ToString()))).ToLowerInvariant();
 }
 public static string Run(string runtime,string productionHash) {
  AssemblyLoadContext.Default.Resolving+=(c,n)=>{var p=Path.Combine(runtime,n.Name+".dll");return File.Exists(p)?c.LoadFromAssemblyPath(p):null;};
  var benchmark=AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(runtime,"OoplesFinance.StockIndicators.CompetitorBenchmarks.dll"));
  var tensor=AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(runtime,"AiDotNet.Tensors.dll"));
  var settings=tensor.GetType("AiDotNet.Tensors.Helpers.CpuParallelSettings",true);
  var degree=settings.GetProperty("MaxDegreeOfParallelism",Flags);var prior=degree.GetValue(null);
  const string ns="OoplesFinance.StockIndicators.CompetitorBenchmarks.";
  var pair=benchmark.GetType(ns+"ComparisonPairs",true).GetMethod("Get",Flags).Invoke(null,new object[]{"TaLib.Functions.T3"});
  var data=benchmark.GetType(ns+"ComparisonVerifier",true).GetMethod("BenchmarkFixture",Flags).Invoke(null,new object[]{pair,10003});
  var call=Expression.Call(Expression.Constant(pair),pair.GetType().GetMethod("Ooples",Flags),Expression.Constant(data),Expression.Constant(20));
  var run=Expression.Lambda<Func<object>>(Expression.Convert(call,typeof(object))).Compile();
  var parallel=(Action<int,int,Action<int>>)settings.GetMethod("LightweightParallel",Flags,null,new[]{typeof(int),typeof(int),typeof(Action<int>)},null).CreateDelegate(typeof(Action<int,int,Action<int>>));
  try {
   degree.SetValue(null,1);var expected=Fingerprint(run());
   var reference=(Delegate)pair.GetType().GetProperty("Reference",Flags).GetValue(pair);
   if(expected!=Fingerprint(reference.DynamicInvoke(data,20)))throw new Exception("Serial result differs from independent reference");
   degree.SetValue(null,8);var results=new string[4];var threads=new int[4];
   var job=Task.Run(()=>parallel(4,4,i=>{threads[i]=Environment.CurrentManagedThreadId;results[i]=Fingerprint(run());}));
   if(!job.Wait(TimeSpan.FromSeconds(20)))throw new TimeoutException("Nested pool call did not complete");
   if(results.Any(x=>x!=expected))throw new Exception("Nested result differs bit for bit");
   if(threads.Distinct().Count()<2)throw new Exception("Outer persistent worker path was not exercised");
   return JsonSerializer.Serialize(new{productionSha256=productionHash,bars=10003,period=20,outerPoolCalls=4,workerLimit=8,outerThreadIds=threads,referenceSha256=expected,independentReferenceMatched=true,allNestedResultsMatched=true,completedWithinSeconds=20,performanceEvidence=false},new JsonSerializerOptions{WriteIndented=true});
  } finally {degree.SetValue(null,prior);}
 }
}
'@
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 't3-nested-pool-check-20261113.json'), [T3NestedPoolCheck]::Run($runtimeT3,$expectedT3))
