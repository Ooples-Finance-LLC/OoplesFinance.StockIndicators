```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |------ |-----------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **1000**  |   **567.4 μs** |   **2.36 μs** |   **1.24 μs** |  **2.89** |    **0.01** |        **-** |        **-** |        **-** |  **418.71 KB** |        **0.51** |
| BuilderLatestOnly | 1000  |   466.3 μs |  33.20 μs |  21.96 μs |  2.37 |    0.11 |  19.5313 |   3.9063 |        - |  371.03 KB |        0.45 |
| NativeSingle      | 1000  |   196.4 μs |   1.50 μs |   0.89 μs |  1.00 |    0.01 |  48.8281 |   5.8594 |        - |  817.35 KB |        1.00 |
| NativeParallel    | 1000  |   150.4 μs |   3.44 μs |   2.05 μs |  0.77 |    0.01 |  53.7109 |   6.8359 |        - |  881.55 KB |        1.08 |
|                   |       |            |           |           |       |         |          |          |          |            |             |
| **BuilderFull**       | **10000** | **4,065.7 μs** | **436.83 μs** | **288.94 μs** |  **1.21** |    **0.14** | **218.7500** | **156.2500** |        **-** | **4009.68 KB** |        **0.49** |
| BuilderLatestOnly | 10000 | 4,025.4 μs | 354.08 μs | 234.21 μs |  1.20 |    0.13 | 187.5000 |  62.5000 |        - | 3539.74 KB |        0.43 |
| NativeSingle      | 10000 | 3,392.6 μs | 498.24 μs | 329.55 μs |  1.01 |    0.13 | 593.7500 | 125.0000 | 125.0000 | 8250.47 KB |        1.00 |
| NativeParallel    | 10000 | 2,228.1 μs | 266.10 μs | 158.35 μs |  0.66 |    0.08 | 593.7500 | 125.0000 | 125.0000 | 8315.13 KB |        1.01 |
