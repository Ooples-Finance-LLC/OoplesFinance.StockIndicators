```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |------ |-----------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **1000**  |   **542.6 μs** |  **76.82 μs** |  **45.72 μs** |        **-** |        **-** |  **418.68 KB** |
| BuilderLatestOnly | 1000  |   464.5 μs |  31.62 μs |  20.91 μs |  19.5313 |   3.9063 |  371.03 KB |
| **BuilderFull**       | **10000** | **3,738.9 μs** |  **55.70 μs** |  **29.13 μs** | **218.7500** | **156.2500** | **4009.58 KB** |
| BuilderLatestOnly | 10000 | 3,856.0 μs | 257.40 μs | 170.25 μs | 187.5000 |  62.5000 | 3539.85 KB |
