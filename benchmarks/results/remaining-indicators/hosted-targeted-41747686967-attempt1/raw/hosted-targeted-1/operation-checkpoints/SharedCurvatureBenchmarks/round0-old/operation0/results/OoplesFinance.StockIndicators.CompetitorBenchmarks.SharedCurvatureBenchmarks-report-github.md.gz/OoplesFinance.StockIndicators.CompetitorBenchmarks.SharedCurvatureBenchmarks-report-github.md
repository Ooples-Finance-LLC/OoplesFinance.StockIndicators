```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |------ |-----------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **1000**  |   **506.4 μs** |  **56.85 μs** |  **37.60 μs** |  **15.6250** |        **-** |  **418.64 KB** |
| BuilderLatestOnly | 1000  |   498.2 μs |  16.70 μs |  11.05 μs |  19.5313 |   3.9063 |  371.03 KB |
| **BuilderFull**       | **10000** | **4,043.3 μs** | **182.05 μs** | **120.41 μs** | **218.7500** | **156.2500** | **4009.62 KB** |
| BuilderLatestOnly | 10000 | 3,954.6 μs | 172.53 μs |  90.24 μs | 187.5000 |  62.5000 | 3539.85 KB |
