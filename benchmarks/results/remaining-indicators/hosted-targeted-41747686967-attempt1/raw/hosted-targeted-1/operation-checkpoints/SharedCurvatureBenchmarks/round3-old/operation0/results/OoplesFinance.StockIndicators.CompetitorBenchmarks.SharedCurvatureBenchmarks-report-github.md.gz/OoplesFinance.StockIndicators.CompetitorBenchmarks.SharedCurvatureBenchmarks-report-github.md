```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |------ |-----------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **1000**  |   **479.7 μs** |  **99.02 μs** |  **65.50 μs** |        **-** |        **-** |  **418.71 KB** |
| BuilderLatestOnly | 1000  |   467.9 μs |  26.34 μs |  15.67 μs |  19.5313 |   3.9063 |  371.03 KB |
| **BuilderFull**       | **10000** | **3,738.1 μs** |  **54.38 μs** |  **28.44 μs** | **218.7500** | **156.2500** | **4009.63 KB** |
| BuilderLatestOnly | 10000 | 3,900.7 μs | 329.28 μs | 217.80 μs | 187.5000 |  62.5000 | 3539.85 KB |
