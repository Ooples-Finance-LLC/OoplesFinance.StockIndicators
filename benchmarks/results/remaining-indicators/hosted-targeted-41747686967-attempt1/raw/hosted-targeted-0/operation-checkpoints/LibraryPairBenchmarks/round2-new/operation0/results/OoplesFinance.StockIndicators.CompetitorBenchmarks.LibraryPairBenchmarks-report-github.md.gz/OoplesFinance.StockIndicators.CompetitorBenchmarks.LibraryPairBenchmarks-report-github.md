```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|----------:|---------:|------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Curvature** |   **762.4 μs** |  **42.05 μs** | **27.81 μs** |  **1.00** |    **0.05** |  **1151.02 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Curvature |   256.6 μs |   1.10 μs |  0.57 μs |  0.34 |    0.01 |   898.99 KB |        0.78 |
|            |       |                     |            |           |          |       |         |             |             |
| **Ooples**     | **10000** | **QuanTAlib.Curvature** | **7,705.5 μs** | **112.91 μs** | **67.19 μs** |  **1.00** |    **0.01** | **14181.18 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Curvature | 2,706.3 μs |  37.31 μs | 22.20 μs |  0.35 |    0.00 |  9011.39 KB |        0.64 |
