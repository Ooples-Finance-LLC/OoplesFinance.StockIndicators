```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)iLine [24]** | **1000**  |  **72.96 μs** | **0.817 μs** | **0.486 μs** |       **-** |       **-** |  **57.26 KB** |
| BuilderLatestOnly | TaLib(...)iLine [24] | 1000  |  69.78 μs | 0.675 μs | 0.447 μs |  0.4883 |       - |   9.38 KB |
| **BuilderFull**       | **TaLib(...)iLine [24]** | **10000** | **680.76 μs** | **1.551 μs** | **0.923 μs** | **31.2500** | **11.7188** | **549.83 KB** |
| BuilderLatestOnly | TaLib(...)iLine [24] | 10000 | 643.67 μs | 1.910 μs | 0.999 μs |  3.9063 |       - |  79.72 KB |
