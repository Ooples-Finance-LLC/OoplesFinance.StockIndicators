```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)iLine [24]** | **1000**  |  **95.31 μs** |  **0.907 μs** |  **0.474 μs** |  **1.00** |    **0.01** |       **-** |      **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)iLine [24] | 1000  |  62.58 μs |  5.482 μs |  3.262 μs |  0.66 |    0.03 |  0.4883 |      - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib(...)iLine [24] | 1000  |  73.94 μs |  1.535 μs |  0.914 μs |  0.78 |    0.01 |  3.4180 | 0.4883 |  57.26 KB |       14.43 |
| BuilderLatestOnly | TaLib(...)iLine [24] | 1000  |  69.48 μs |  2.468 μs |  1.633 μs |  0.73 |    0.02 |  0.4883 |      - |   9.38 KB |        2.36 |
|                   |                      |       |           |           |           |       |         |         |        |           |             |
| **NativeSingle**      | **TaLib(...)iLine [24]** | **10000** | **754.59 μs** | **23.379 μs** | **13.912 μs** |  **1.00** |    **0.02** |       **-** |      **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)iLine [24] | 10000 | 466.12 μs | 55.745 μs | 33.173 μs |  0.62 |    0.04 |  3.9063 |      - |  78.71 KB |        2.01 |
| BuilderFull       | TaLib(...)iLine [24] | 10000 | 835.97 μs |  3.228 μs |  1.688 μs |  1.11 |    0.02 | 31.2500 | 7.8125 | 549.85 KB |       14.04 |
| BuilderLatestOnly | TaLib(...)iLine [24] | 10000 | 627.26 μs |  3.644 μs |  1.906 μs |  0.83 |    0.01 |  3.9063 |      - |  79.72 KB |        2.04 |
