```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)iLine [24]** |  **85.40 μs** |  **9.188 μs** |  **4.806 μs** |  **1.00** |    **0.07** |  **65.32 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)iLine [24] |  74.36 μs |  3.596 μs |  1.881 μs |  0.87 |    0.05 |  18.92 KB |        0.29 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)iLine [24]** | **629.42 μs** | **25.907 μs** | **15.417 μs** |  **1.00** |    **0.03** | **632.37 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)iLine [24] | 725.88 μs | 23.450 μs | 15.511 μs |  1.15 |    0.03 | 122.42 KB |        0.19 |
