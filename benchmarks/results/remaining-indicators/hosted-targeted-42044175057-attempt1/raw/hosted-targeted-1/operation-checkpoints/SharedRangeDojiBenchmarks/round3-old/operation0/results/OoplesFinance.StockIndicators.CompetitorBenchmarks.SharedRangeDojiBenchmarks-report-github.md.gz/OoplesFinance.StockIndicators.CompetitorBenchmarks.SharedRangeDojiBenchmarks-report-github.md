```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)yDoji [27]** | **1000**  |  **42.33 μs** |  **0.873 μs** |  **0.519 μs** |  **3.4180** |  **0.4883** |  **57.26 KB** |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 1000  |  39.99 μs |  0.733 μs |  0.436 μs |  0.4883 |       - |   9.38 KB |
| **BuilderFull**       | **TaLib(...)yDoji [27]** | **10000** | **403.80 μs** | **12.189 μs** |  **8.062 μs** | **31.2500** | **11.7188** |  **549.8 KB** |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 10000 | 418.90 μs | 43.615 μs | 28.849 μs |  3.9063 |       - |  79.69 KB |
