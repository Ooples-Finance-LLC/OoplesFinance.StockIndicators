```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)yDoji [27]** | **1000**  |  **47.68 μs** | **2.736 μs** | **1.431 μs** |  **1.9531** |       **-** |  **57.26 KB** |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 1000  |  39.08 μs | 1.152 μs | 0.686 μs |  0.4883 |       - |   9.38 KB |
| **BuilderFull**       | **TaLib(...)yDoji [27]** | **10000** | **382.72 μs** | **4.986 μs** | **3.298 μs** | **31.2500** | **11.7188** | **549.81 KB** |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 10000 | 362.07 μs | 3.811 μs | 1.993 μs |  3.9063 |       - |   79.7 KB |
