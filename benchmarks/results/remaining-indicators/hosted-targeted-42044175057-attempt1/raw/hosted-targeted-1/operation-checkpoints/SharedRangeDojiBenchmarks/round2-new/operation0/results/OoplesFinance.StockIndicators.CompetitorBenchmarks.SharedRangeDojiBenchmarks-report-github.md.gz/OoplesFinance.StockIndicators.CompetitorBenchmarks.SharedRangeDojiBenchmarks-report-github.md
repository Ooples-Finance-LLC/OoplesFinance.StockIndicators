```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)yDoji [27]** | **1000**  |  **28.69 μs** |  **0.346 μs** |  **0.206 μs** |  **1.00** |    **0.01** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)yDoji [27] | 1000  |  22.21 μs |  2.638 μs |  1.745 μs |  0.77 |    0.06 |  0.4883 |       - |    8.4 KB |        2.12 |
| BuilderFull       | TaLib(...)yDoji [27] | 1000  |  40.13 μs |  1.246 μs |  0.652 μs |  1.40 |    0.02 |  3.4180 |  0.4883 |  57.26 KB |       14.43 |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 1000  |  41.53 μs |  2.343 μs |  1.550 μs |  1.45 |    0.05 |  0.4883 |       - |   9.38 KB |        2.36 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)yDoji [27]** | **10000** | **286.56 μs** |  **4.474 μs** |  **2.340 μs** |  **1.00** |    **0.01** |  **1.9531** |       **-** |  **39.13 KB** |        **1.00** |
| NativeParallel    | TaLib(...)yDoji [27] | 10000 | 229.39 μs | 43.236 μs | 28.598 μs |  0.80 |    0.10 |  6.8359 |  0.9766 |  78.72 KB |        2.01 |
| BuilderFull       | TaLib(...)yDoji [27] | 10000 | 408.13 μs |  6.804 μs |  3.559 μs |  1.42 |    0.02 | 31.2500 | 11.7188 | 549.81 KB |       14.05 |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 10000 | 384.19 μs |  8.298 μs |  5.489 μs |  1.34 |    0.02 |  3.9063 |       - |  79.71 KB |        2.04 |
