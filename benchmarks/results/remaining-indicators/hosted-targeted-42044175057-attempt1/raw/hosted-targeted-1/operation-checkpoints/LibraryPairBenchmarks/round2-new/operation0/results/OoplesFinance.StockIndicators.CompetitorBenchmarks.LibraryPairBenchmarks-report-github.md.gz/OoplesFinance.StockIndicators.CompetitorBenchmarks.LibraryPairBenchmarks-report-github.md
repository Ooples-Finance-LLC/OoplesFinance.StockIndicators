```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)yDoji [27]** |  **56.78 μs** |  **4.303 μs** | **2.561 μs** |  **1.00** |    **0.06** |  **65.36 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)yDoji [27] |  29.62 μs |  0.652 μs | 0.341 μs |  0.52 |    0.02 |  12.08 KB |        0.18 |
|            |       |                      |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)yDoji [27]** | **388.58 μs** | **16.125 μs** | **9.596 μs** |  **1.00** |    **0.03** | **628.48 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)yDoji [27] | 307.37 μs |  3.478 μs | 2.069 μs |  0.79 |    0.02 | 117.55 KB |        0.19 |
