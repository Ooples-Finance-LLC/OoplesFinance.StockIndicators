```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)dDoji [28]** | **1000**  |  **91.28 μs** |  **1.645 μs** |  **0.860 μs** |  **1.00** |    **0.01** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)dDoji [28] | 1000  |  52.05 μs |  5.842 μs |  3.864 μs |  0.57 |    0.04 |  0.4883 |       - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib(...)dDoji [28] | 1000  |  58.81 μs |  0.689 μs |  0.410 μs |  0.64 |    0.01 |  3.4180 |  0.4883 |  57.26 KB |       14.43 |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 1000  |  53.99 μs |  0.479 μs |  0.285 μs |  0.59 |    0.01 |  0.4883 |       - |   9.38 KB |        2.36 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)dDoji [28]** | **10000** | **602.05 μs** |  **1.346 μs** |  **0.801 μs** |  **1.00** |    **0.00** |       **-** |       **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)dDoji [28] | 10000 | 418.35 μs | 61.155 μs | 40.450 μs |  0.69 |    0.06 |  3.9063 |       - |  78.72 KB |        2.01 |
| BuilderFull       | TaLib(...)dDoji [28] | 10000 | 614.91 μs |  7.112 μs |  4.704 μs |  1.02 |    0.01 | 31.2500 | 11.7188 | 549.83 KB |       14.04 |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 10000 | 492.07 μs |  2.063 μs |  1.079 μs |  0.82 |    0.00 |  3.9063 |       - |  79.72 KB |        2.04 |
