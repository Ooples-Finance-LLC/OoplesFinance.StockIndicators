```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dDoji [28]** | **101.37 μs** |  **1.572 μs** |  **0.935 μs** |  **1.00** |    **0.01** |  **65.36 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dDoji [28] |  80.74 μs |  0.973 μs |  0.579 μs |  0.80 |    0.01 |  13.72 KB |        0.21 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)dDoji [28]** | **619.64 μs** | **43.702 μs** | **26.006 μs** |  **1.00** |    **0.06** | **634.01 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dDoji [28] | 826.00 μs | 25.292 μs | 16.729 μs |  1.34 |    0.06 | 124.11 KB |        0.20 |
