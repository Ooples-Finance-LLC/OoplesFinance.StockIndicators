```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Candles.Doji** | **1000**  |  **54.06 μs** | **0.411 μs** | **0.215 μs** |  **1.9531** |       **-** |  **57.26 KB** |
| BuilderLatestOnly | TaLib.Candles.Doji | 1000  |  47.52 μs | 0.251 μs | 0.131 μs |  0.4883 |       - |   9.38 KB |
| **BuilderFull**       | **TaLib.Candles.Doji** | **10000** | **480.58 μs** | **3.946 μs** | **2.610 μs** | **31.2500** | **11.7188** | **549.83 KB** |
| BuilderLatestOnly | TaLib.Candles.Doji | 10000 | 425.52 μs | 2.084 μs | 1.090 μs |  3.9063 |       - |  79.72 KB |
