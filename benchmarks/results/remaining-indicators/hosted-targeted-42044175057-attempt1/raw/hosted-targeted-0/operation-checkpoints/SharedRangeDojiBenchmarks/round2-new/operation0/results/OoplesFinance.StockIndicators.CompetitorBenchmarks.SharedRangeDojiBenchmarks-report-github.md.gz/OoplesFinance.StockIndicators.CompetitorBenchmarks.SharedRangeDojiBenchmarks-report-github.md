```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib.Candles.Doji** | **1000**  |  **26.36 μs** |  **0.219 μs** |  **0.114 μs** |  **1.00** |    **0.01** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Doji | 1000  |  17.75 μs |  2.665 μs |  1.763 μs |  0.67 |    0.06 |  0.4883 |       - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib.Candles.Doji | 1000  |  52.97 μs |  0.657 μs |  0.435 μs |  2.01 |    0.02 |  3.4180 |  0.4883 |  57.26 KB |       14.43 |
| BuilderLatestOnly | TaLib.Candles.Doji | 1000  |  48.55 μs |  0.381 μs |  0.227 μs |  1.84 |    0.01 |  0.4883 |       - |   9.38 KB |        2.36 |
|                   |                    |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib.Candles.Doji** | **10000** | **261.58 μs** |  **1.074 μs** |  **0.710 μs** |  **1.00** |    **0.00** |  **1.9531** |       **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Doji | 10000 | 203.02 μs | 32.392 μs | 21.425 μs |  0.78 |    0.08 |  5.8594 |       - |   78.7 KB |        2.01 |
| BuilderFull       | TaLib.Candles.Doji | 10000 | 479.93 μs |  6.259 μs |  3.725 μs |  1.83 |    0.01 | 31.2500 | 11.7188 | 549.83 KB |       14.05 |
| BuilderLatestOnly | TaLib.Candles.Doji | 10000 | 437.83 μs |  2.113 μs |  1.257 μs |  1.67 |    0.01 |  3.9063 |       - |  79.72 KB |        2.04 |
