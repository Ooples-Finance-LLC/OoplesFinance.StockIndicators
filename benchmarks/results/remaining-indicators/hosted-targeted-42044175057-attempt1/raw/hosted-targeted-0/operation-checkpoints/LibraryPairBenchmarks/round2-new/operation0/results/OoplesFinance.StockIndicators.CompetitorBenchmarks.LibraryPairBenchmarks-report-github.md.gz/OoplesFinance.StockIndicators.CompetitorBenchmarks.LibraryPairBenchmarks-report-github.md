```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Candles.Doji** | **129.50 μs** | **22.705 μs** | **15.018 μs** |  **1.01** |    **0.15** |  **65.36 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Candles.Doji |  32.01 μs |  0.505 μs |  0.264 μs |  0.25 |    0.03 |  19.58 KB |        0.30 |
|            |       |                    |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Candles.Doji** | **580.68 μs** | **21.525 μs** | **12.809 μs** |  **1.00** |    **0.03** | **634.05 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Candles.Doji | 298.73 μs |  2.755 μs |  1.441 μs |  0.51 |    0.01 | 123.73 KB |        0.20 |
