```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean     | Error   | StdDev  | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |---------:|--------:|--------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)eDoji [28]** | **111.0 μs** | **9.18 μs** | **4.80 μs** |  **1.00** |    **0.06** |  **65.33 KB** |        **1.00** |
|        |       |                      |          |         |         |       |         |           |             |
| **Ooples** | **10000** | **TaLib(...)eDoji [28]** | **628.3 μs** | **9.40 μs** | **5.59 μs** |  **1.00** |    **0.01** | **635.34 KB** |        **1.00** |
