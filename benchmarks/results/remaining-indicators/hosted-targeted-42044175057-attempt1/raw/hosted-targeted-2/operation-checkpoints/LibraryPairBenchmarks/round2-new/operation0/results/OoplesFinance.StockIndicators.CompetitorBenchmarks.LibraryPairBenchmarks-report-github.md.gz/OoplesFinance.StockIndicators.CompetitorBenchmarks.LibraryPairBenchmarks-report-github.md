```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)eDoji [28]** |  **85.44 μs** |  **4.352 μs** |  **2.276 μs** |  **1.00** |    **0.04** |  **65.32 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)eDoji [28] |  73.45 μs | 25.975 μs | 17.181 μs |  0.86 |    0.19 |  19.58 KB |        0.30 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)eDoji [28]** | **643.19 μs** | **32.681 μs** | **19.448 μs** |  **1.00** |    **0.04** | **632.37 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)eDoji [28] | 564.47 μs |  6.111 μs |  3.637 μs |  0.88 |    0.03 | 122.42 KB |        0.19 |
