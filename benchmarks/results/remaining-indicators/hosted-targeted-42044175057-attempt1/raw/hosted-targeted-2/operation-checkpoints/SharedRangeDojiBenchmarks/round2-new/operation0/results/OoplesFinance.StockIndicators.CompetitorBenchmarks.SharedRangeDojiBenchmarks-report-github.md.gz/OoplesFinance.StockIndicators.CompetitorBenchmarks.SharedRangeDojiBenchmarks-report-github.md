```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)eDoji [28]** | **1000**  |  **58.38 μs** |  **0.420 μs** |  **0.250 μs** |  **1.00** |    **0.01** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)eDoji [28] | 1000  |  47.52 μs |  4.910 μs |  3.248 μs |  0.81 |    0.05 |  0.4883 |       - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib(...)eDoji [28] | 1000  |  71.25 μs |  0.683 μs |  0.357 μs |  1.22 |    0.01 |  3.4180 |  0.4883 |  57.26 KB |       14.43 |
| BuilderLatestOnly | TaLib(...)eDoji [28] | 1000  |  65.69 μs |  0.506 μs |  0.335 μs |  1.13 |    0.01 |  0.4883 |       - |   9.38 KB |        2.36 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)eDoji [28]** | **10000** | **589.12 μs** | **16.820 μs** | **10.010 μs** |  **1.00** |    **0.02** |       **-** |       **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib(...)eDoji [28] | 10000 | 368.20 μs | 66.819 μs | 44.196 μs |  0.63 |    0.07 |  5.8594 |       - |   78.7 KB |        2.01 |
| BuilderFull       | TaLib(...)eDoji [28] | 10000 | 638.10 μs |  8.326 μs |  4.955 μs |  1.08 |    0.02 | 31.2500 | 11.7188 | 549.82 KB |       14.05 |
| BuilderLatestOnly | TaLib(...)eDoji [28] | 10000 | 599.97 μs |  2.627 μs |  1.374 μs |  1.02 |    0.02 |  3.9063 |       - |  79.72 KB |        2.04 |
