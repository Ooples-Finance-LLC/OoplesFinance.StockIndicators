```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId           | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |----------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetStoch** |   **190.3 μs** | **14.07 μs** |  **8.37 μs** |  **1.00** |    **0.06** |  **214.16 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetStoch |   108.8 μs | 13.35 μs |  8.83 μs |  0.57 |    0.05 |  271.33 KB |        1.27 |
|            |       |                  |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetStoch** | **1,753.2 μs** | **17.20 μs** | **11.38 μs** |  **1.00** |    **0.01** | **2075.55 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetStoch | 1,103.2 μs | 24.98 μs | 14.86 μs |  0.63 |    0.01 | 2652.84 KB |        1.28 |
