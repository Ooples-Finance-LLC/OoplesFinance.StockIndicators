```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |----------------- |------ |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetStoch** | **1000**  |   **403.2 μs** | **157.82 μs** | **104.39 μs** |       **-** |       **-** |   **95.6 KB** |
| BuilderLatestOnly | Skender.GetStoch | 1000  |   198.1 μs |  12.73 μs |   8.42 μs |  1.9531 |       - |  47.96 KB |
| **BuilderFull**       | **Skender.GetStoch** | **10000** | **2,128.2 μs** | **116.40 μs** |  **76.99 μs** | **46.8750** | **15.6250** | **869.44 KB** |
| BuilderLatestOnly | Skender.GetStoch | 10000 | 2,209.5 μs | 161.30 μs | 106.69 μs | 15.6250 |       - | 399.61 KB |
