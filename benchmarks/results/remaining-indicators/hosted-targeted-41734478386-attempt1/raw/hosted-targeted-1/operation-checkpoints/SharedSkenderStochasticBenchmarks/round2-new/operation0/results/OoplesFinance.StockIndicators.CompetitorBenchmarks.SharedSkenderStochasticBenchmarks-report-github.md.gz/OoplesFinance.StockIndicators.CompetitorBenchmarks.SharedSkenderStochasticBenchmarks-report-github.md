```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Gen2    | Allocated  | Alloc Ratio |
|------------------ |----------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetStoch** | **1000**  |   **186.77 μs** |   **2.676 μs** |  **1.400 μs** |  **2.56** |    **0.03** |        **-** |       **-** |       **-** |    **95.6 KB** |        **0.52** |
| BuilderLatestOnly | Skender.GetStoch | 1000  |   182.52 μs |   4.309 μs |  2.254 μs |  2.50 |    0.04 |   1.9531 |       - |       - |   47.96 KB |        0.26 |
| NativeSingle      | Skender.GetStoch | 1000  |    72.96 μs |   1.223 μs |  0.809 μs |  1.00 |    0.01 |  11.2305 |  2.4414 |       - |  184.07 KB |        1.00 |
| NativeParallel    | Skender.GetStoch | 1000  |    58.44 μs |   6.103 μs |  4.037 μs |  0.80 |    0.05 |  12.6953 |  2.9297 |       - |  202.83 KB |        1.10 |
|                   |                  |       |             |            |           |       |         |          |         |         |            |             |
| **BuilderFull**       | **Skender.GetStoch** | **10000** | **2,079.54 μs** | **141.452 μs** | **93.562 μs** |  **1.33** |    **0.06** |  **46.8750** | **15.6250** |       **-** |  **869.48 KB** |        **0.47** |
| BuilderLatestOnly | Skender.GetStoch | 10000 | 2,083.25 μs |  80.901 μs | 48.143 μs |  1.33 |    0.03 |  15.6250 |       - |       - |   399.6 KB |        0.22 |
| NativeSingle      | Skender.GetStoch | 10000 | 1,564.44 μs |   6.868 μs |  4.087 μs |  1.00 |    0.00 | 125.0000 | 93.7500 | 46.8750 | 1836.83 KB |        1.00 |
| NativeParallel    | Skender.GetStoch | 10000 |   791.35 μs |  49.689 μs | 32.866 μs |  0.51 |    0.02 | 121.0938 | 54.6875 |       - | 1925.51 KB |        1.05 |
