```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |----------------- |------ |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetStoch** | **1000**  |   **237.3 μs** |  **50.77 μs** |  **33.58 μs** |       **-** |       **-** |   **95.6 KB** |
| BuilderLatestOnly | Skender.GetStoch | 1000  |   211.2 μs |  20.82 μs |  13.77 μs |  1.9531 |       - |  47.96 KB |
| **BuilderFull**       | **Skender.GetStoch** | **10000** | **2,189.5 μs** | **203.45 μs** | **134.57 μs** | **46.8750** | **15.6250** | **869.45 KB** |
| BuilderLatestOnly | Skender.GetStoch | 10000 | 2,104.2 μs |  79.19 μs |  47.12 μs | 15.6250 |       - |  399.6 KB |
