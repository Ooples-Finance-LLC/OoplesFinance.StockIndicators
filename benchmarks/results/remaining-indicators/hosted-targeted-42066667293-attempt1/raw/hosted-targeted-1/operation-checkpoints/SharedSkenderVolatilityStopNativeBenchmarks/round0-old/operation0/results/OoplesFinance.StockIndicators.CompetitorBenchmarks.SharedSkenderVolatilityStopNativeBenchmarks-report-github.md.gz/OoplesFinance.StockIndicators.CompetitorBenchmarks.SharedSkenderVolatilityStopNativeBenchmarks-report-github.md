```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method   | Count | Operation            | Mean       | Error     | StdDev    | Gen0     | Gen1     | Gen2    | Allocated  |
|--------- |------ |--------------------- |-----------:|----------:|----------:|---------:|---------:|--------:|-----------:|
| **Snapshot** | **1000**  | **Skend(...)yStop [25]** |   **623.6 μs** |  **18.74 μs** |  **11.15 μs** |  **46.8750** |        **-** |       **-** |  **875.81 KB** |
| **Snapshot** | **10000** | **Skend(...)yStop [25]** | **9,005.0 μs** | **398.50 μs** | **263.58 μs** | **583.3333** | **250.0000** | **83.3333** | **8848.05 KB** |
