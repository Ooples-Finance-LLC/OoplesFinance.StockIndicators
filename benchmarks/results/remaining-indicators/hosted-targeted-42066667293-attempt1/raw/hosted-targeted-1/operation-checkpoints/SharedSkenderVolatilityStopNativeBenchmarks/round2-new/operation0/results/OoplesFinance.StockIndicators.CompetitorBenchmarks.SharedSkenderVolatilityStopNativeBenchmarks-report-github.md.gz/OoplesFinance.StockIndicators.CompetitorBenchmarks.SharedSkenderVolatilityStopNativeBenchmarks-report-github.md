```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method         | Count | Operation            | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|--------------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **Snapshot**       | **1000**  | **Skend(...)yStop [25]** |   **508.3 μs** | **140.37 μs** |  **83.53 μs** |  **4.77** |    **0.76** |  **31.2500** |        **-** |       **-** |  **600.47 KB** |        **2.07** |
| NativeSingle   | 1000  | Skend(...)yStop [25] |   106.6 μs |   5.80 μs |   3.84 μs |  1.00 |    0.05 |  17.5781 |   4.8828 |       - |  290.21 KB |        1.00 |
| NativeParallel | 1000  | Skend(...)yStop [25] |   176.4 μs |   4.59 μs |   2.40 μs |  1.66 |    0.06 |  46.8750 |  17.5781 |       - |  735.36 KB |        2.53 |
|                |       |                      |            |           |           |       |         |          |          |         |            |             |
| **Snapshot**       | **10000** | **Skend(...)yStop [25]** | **6,335.2 μs** | **311.07 μs** | **205.75 μs** |  **4.56** |    **0.16** | **400.0000** | **266.6667** | **66.6667** | **6039.68 KB** |        **2.09** |
| NativeSingle   | 10000 | Skend(...)yStop [25] | 1,390.0 μs |  35.08 μs |  20.87 μs |  1.00 |    0.02 | 195.3125 | 148.4375 | 46.8750 | 2892.19 KB |        1.00 |
| NativeParallel | 10000 | Skend(...)yStop [25] | 2,401.7 μs | 161.38 μs |  96.03 μs |  1.73 |    0.07 | 500.0000 | 375.0000 | 78.1250 | 7310.42 KB |        2.53 |
