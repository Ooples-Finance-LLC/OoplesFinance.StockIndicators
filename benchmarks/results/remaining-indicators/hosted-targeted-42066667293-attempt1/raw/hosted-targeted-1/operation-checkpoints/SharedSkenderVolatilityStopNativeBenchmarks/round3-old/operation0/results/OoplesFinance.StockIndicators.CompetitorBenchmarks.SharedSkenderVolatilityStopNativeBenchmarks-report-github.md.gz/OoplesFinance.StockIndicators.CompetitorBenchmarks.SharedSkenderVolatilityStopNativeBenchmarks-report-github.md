```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method   | Count | Operation            | Mean       | Error     | StdDev    | Gen0     | Gen1     | Gen2    | Allocated |
|--------- |------ |--------------------- |-----------:|----------:|----------:|---------:|---------:|--------:|----------:|
| **Snapshot** | **1000**  | **Skend(...)yStop [25]** |   **660.9 μs** |  **65.00 μs** |  **42.99 μs** |  **46.8750** |        **-** |       **-** | **875.81 KB** |
| **Snapshot** | **10000** | **Skend(...)yStop [25]** | **8,467.7 μs** | **341.71 μs** | **226.02 μs** | **538.4615** | **230.7692** | **76.9231** | **8847.9 KB** |
