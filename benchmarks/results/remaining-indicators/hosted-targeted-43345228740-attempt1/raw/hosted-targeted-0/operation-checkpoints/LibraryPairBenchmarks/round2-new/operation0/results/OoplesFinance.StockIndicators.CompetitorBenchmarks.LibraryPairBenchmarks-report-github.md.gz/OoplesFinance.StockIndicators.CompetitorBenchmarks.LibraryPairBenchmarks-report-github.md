```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |------------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ad** | **140.522 μs** | **4.5042 μs** | **2.6804 μs** |  **1.00** |    **0.03** |  **72.95 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ad |   4.540 μs | 0.4361 μs | 0.2885 μs |  0.03 |    0.00 |  10.16 KB |        0.14 |
|            |       |                    |            |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ad** | **261.633 μs** | **2.0478 μs** | **1.2186 μs** |  **1.00** |    **0.01** | **713.24 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ad |  24.775 μs | 0.9184 μs | 0.4803 μs |  0.09 |    0.00 |  86.29 KB |        0.12 |
