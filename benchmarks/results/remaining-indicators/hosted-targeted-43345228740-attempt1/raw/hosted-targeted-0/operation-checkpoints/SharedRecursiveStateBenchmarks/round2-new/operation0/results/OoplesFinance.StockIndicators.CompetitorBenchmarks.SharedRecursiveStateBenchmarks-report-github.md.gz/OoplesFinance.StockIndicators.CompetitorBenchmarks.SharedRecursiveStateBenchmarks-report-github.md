```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean         | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |-------------:|-----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **139.170 μs** |  **6.5039 μs** | **3.8704 μs** | **54.81** |    **1.49** |  **3.9063** |      **-** |  **64.89 KB** |        **8.24** |
| BuilderLatestOnly | Ad        | 1000  |   130.856 μs |  1.4692 μs | 0.8743 μs | 51.54 |    0.46 |  0.9766 |      - |  17.28 KB |        2.19 |
| NativeSingle      | Ad        | 1000  |     2.539 μs |  0.0324 μs | 0.0170 μs |  1.00 |    0.01 |  0.4730 |      - |   7.88 KB |        1.00 |
| NativeParallel    | Ad        | 1000  |    88.944 μs |  1.3685 μs | 0.9052 μs | 35.03 |    0.41 |  0.4883 |      - |   8.17 KB |        1.04 |
|                   |           |       |              |            |           |       |         |         |        |           |             |
| **BuilderFull**       | **Ad**        | **10000** | **1,218.620 μs** |  **8.0096 μs** | **4.7664 μs** | **56.00** |    **0.47** | **31.2500** | **7.8125** | **627.79 KB** |        **8.03** |
| BuilderLatestOnly | Ad        | 10000 | 1,214.599 μs | 10.9078 μs | 5.7050 μs | 55.81 |    0.49 |  7.8125 |      - | 157.97 KB |        2.02 |
| NativeSingle      | Ad        | 10000 |    21.764 μs |  0.2931 μs | 0.1744 μs |  1.00 |    0.01 |  4.7607 | 0.8545 |  78.19 KB |        1.00 |
| NativeParallel    | Ad        | 10000 |   111.929 μs |  4.4708 μs | 2.9572 μs |  5.14 |    0.14 |  3.9063 |      - |  78.48 KB |        1.00 |
