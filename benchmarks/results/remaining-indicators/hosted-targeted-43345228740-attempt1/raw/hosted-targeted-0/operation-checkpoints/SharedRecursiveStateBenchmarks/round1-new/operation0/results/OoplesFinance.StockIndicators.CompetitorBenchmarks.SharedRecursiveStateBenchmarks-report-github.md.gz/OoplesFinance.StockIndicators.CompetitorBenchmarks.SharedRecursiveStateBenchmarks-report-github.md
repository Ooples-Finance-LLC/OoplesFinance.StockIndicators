```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error    | StdDev  | Gen0    | Gen1   | Allocated |
|------------------ |---------- |------ |-----------:|---------:|--------:|--------:|-------:|----------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **133.9 μs** |  **2.15 μs** | **1.28 μs** |  **3.9063** |      **-** |  **64.85 KB** |
| BuilderLatestOnly | Ad        | 1000  |   130.0 μs |  1.32 μs | 0.69 μs |  0.9766 |      - |  17.28 KB |
| **BuilderFull**       | **Ad**        | **10000** | **1,222.6 μs** | **13.92 μs** | **7.28 μs** | **31.2500** | **7.8125** | **627.76 KB** |
| BuilderLatestOnly | Ad        | 10000 | 1,228.1 μs |  4.28 μs | 2.55 μs |  7.8125 |      - | 157.97 KB |
