```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |---------- |------ |-----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **134.7 μs** |  **2.79 μs** |  **1.46 μs** |  **3.9063** |      **-** |  **64.89 KB** |
| BuilderLatestOnly | Ad        | 1000  |   130.7 μs |  1.24 μs |  0.74 μs |  0.9766 |      - |  17.28 KB |
| **BuilderFull**       | **Ad**        | **10000** | **1,234.7 μs** | **19.50 μs** | **12.90 μs** | **31.2500** | **7.8125** | **627.79 KB** |
| BuilderLatestOnly | Ad        | 10000 | 1,189.2 μs |  5.14 μs |  3.06 μs |  7.8125 |      - | 157.97 KB |
