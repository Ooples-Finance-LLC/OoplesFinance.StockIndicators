from pathlib import Path
import hashlib,json,math,re
OUT=Path('C:/Users/cheat/StockIndicators-Recovery-20261021/local-fibonacci-certified-control-20261022')
state=json.loads((OUT/'status.json').read_text(encoding='utf-8'))
assert state['status']=='raw-measurements-complete-independent-verification-pending'
assert state['order']==['old','new','new','old'] and len(state['rounds'])==4
manifest=json.loads((OUT/'binary-manifest.json').read_text(encoding='utf-8'))
assert manifest['old'].keys()==manifest['new'].keys()
assert [p for p in manifest['old'] if manifest['old'][p]!=manifest['new'][p]]==['OoplesFinance.StockIndicators.dll']
proof=json.loads((OUT/'provenance.json').read_text(encoding='utf-8'))
assert proof['old_source'].startswith('c851480a8')
assert proof['candidate_code_source'].startswith('ed0701e92')
assert manifest['new']['OoplesFinance.StockIndicators.dll'] in proof['qualification']['production_dll_sha256'].values()
for arm,folder in [('old',OUT.parent/'local-t3-certified-control-20261022/new'),('new',OUT/'new')]:
 assert {p.relative_to(folder).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.rglob('*') if p.is_file()}==manifest[arm]
rounds={}
for record in state['rounds']:
 index=record['index'];fixture=record['fixture'];assert record['arm']==state['order'][index]
 assert (fixture,index) not in rounds
 assert len(record['quiet_cpu_samples'])==3 and max(record['quiet_cpu_samples'])<=15
 path=Path(record['report']);assert path.is_relative_to(OUT)
 raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()==record['sha256']
 cases={}
 for case in json.loads(raw)['Benchmarks']:
  name=case['FullName'];assert fixture+'.' in name
  key=re.search(r'(?:Operation|PairId): "([^"]+)"',name)[1],int(re.search(r'(?:Count|Bars): (\d+)',name)[1]),case['Method']
  assert key not in cases
  stats=case['Statistics'];values=stats['OriginalValues'];ci=stats['ConfidenceInterval']
  assert len(values)==stats['N']>=7 and all(math.isfinite(v) and v>0 for v in values)
  assert math.isclose(sum(values)/len(values),stats['Mean'],rel_tol=1e-12)
  assert math.isfinite(ci['Lower']) and math.isfinite(ci['Upper']) and ci['Lower']<=stats['Mean']<=ci['Upper']
  cases[key]={'pair':key[0],'bars':key[1],'method':key[2],'mean_ns':stats['Mean'],'lower_ns':ci['Lower'],'upper_ns':ci['Upper'],'samples':stats['N'],'allocated_bytes':case['Memory']['BytesAllocatedPerOperation']}
 methods=['Ooples','Competitor'] if fixture=='LibraryPairBenchmarks' else ['BuilderFull','BuilderLatestOnly','NativeSingle','NativeParallel']
 assert cases.keys()=={(p,n,m) for p in ['QuanTAlib.Fwma'] for n in [1000,10000] for m in methods}
 assert len(cases)==record['cases']
 rounds[fixture,index]=cases
decisions=[]
for fixture in ['LibraryPairBenchmarks']:
 for key in sorted(rounds[fixture,0]):
  if key[2] not in ['BuilderFull','BuilderLatestOnly','Ooples']:continue
  old=[rounds[fixture,i][key] for i in [0,3]];new=[rounds[fixture,i][key] for i in [1,2]]
  verdict='faster' if max(r['upper_ns'] for r in new)<min(r['lower_ns'] for r in old) else 'slower' if min(r['lower_ns'] for r in new)>max(r['upper_ns'] for r in old) else 'inconclusive'
  record={'fixture':fixture,'pair':key[0],'bars':key[1],'method':key[2],'old_means_ms':[r['mean_ns']/1e6 for r in old],'new_means_ms':[r['mean_ns']/1e6 for r in new],'verdict':verdict}
  decisions.append(record);print(json.dumps(record))
summary={'all_16_cases_verified':True,'measurement_location':'Local Windows','sources':{'old':proof['old_source'],'new':proof['new_source']},'decisions':decisions,'final_candidate_round':2,'final_candidate_rows':{fixture:list(rounds[fixture,2].values()) for fixture in ['LibraryPairBenchmarks']}}
(OUT/'verified-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
