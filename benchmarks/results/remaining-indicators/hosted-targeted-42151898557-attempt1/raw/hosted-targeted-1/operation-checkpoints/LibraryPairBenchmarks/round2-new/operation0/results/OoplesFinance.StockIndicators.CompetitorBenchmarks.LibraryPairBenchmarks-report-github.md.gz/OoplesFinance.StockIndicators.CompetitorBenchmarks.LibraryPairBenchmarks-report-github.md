```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetRenkoAtr** |   **234.7 μs** |  **1.72 μs** |  **1.03 μs** |  **1.00** |    **0.01** |   **91.89 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetRenkoAtr |   162.9 μs |  9.43 μs |  4.93 μs |  0.69 |    0.02 |  225.44 KB |        2.45 |
|            |       |                     |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetRenkoAtr** | **2,231.5 μs** | **17.12 μs** |  **8.95 μs** |  **1.00** |    **0.01** |  **894.61 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetRenkoAtr | 1,689.7 μs | 44.35 μs | 29.34 μs |  0.76 |    0.01 | 2148.81 KB |        2.40 |
