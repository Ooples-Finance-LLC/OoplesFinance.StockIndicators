```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId              | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |-------------------- |-----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetRenkoAtr** |   **259.6 μs** | **18.29 μs** | **12.10 μs** |  **1.00** |    **0.06** |  **91.89 KB** |        **1.00** |
|        |       |                     |            |          |          |       |         |           |             |
| **Ooples** | **10000** | **Skender.GetRenkoAtr** | **2,247.2 μs** | **19.32 μs** | **11.50 μs** |  **1.00** |    **0.01** | **894.66 KB** |        **1.00** |
