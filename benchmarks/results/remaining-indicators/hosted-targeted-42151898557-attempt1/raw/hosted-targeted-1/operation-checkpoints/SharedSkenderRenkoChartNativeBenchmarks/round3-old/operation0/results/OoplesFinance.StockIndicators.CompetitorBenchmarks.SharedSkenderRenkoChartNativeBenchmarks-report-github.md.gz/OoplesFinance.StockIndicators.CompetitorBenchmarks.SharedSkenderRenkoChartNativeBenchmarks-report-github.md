```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method   | Count | Operation           | Mean       | Error    | StdDev   | Gen0    | Allocated |
|--------- |------ |-------------------- |-----------:|---------:|---------:|--------:|----------:|
| **Snapshot** | **1000**  | **Skender.GetRenkoAtr** |   **253.6 μs** |  **2.45 μs** |  **1.28 μs** |       **-** |  **86.43 KB** |
| **Snapshot** | **10000** | **Skender.GetRenkoAtr** | **2,588.8 μs** | **69.16 μs** | **41.16 μs** | **46.8750** | **857.63 KB** |
