```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method         | Count | Operation           | Mean       | Error     | StdDev   | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|--------------- |------ |-------------------- |-----------:|----------:|---------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **Snapshot**       | **1000**  | **Skender.GetRenkoAtr** |   **277.2 μs** |  **84.85 μs** | **56.12 μs** |  **1.89** |    **0.37** |        **-** |       **-** |   **86.45 KB** |        **0.41** |
| NativeSingle   | 1000  | Skender.GetRenkoAtr |   146.7 μs |   3.20 μs |  1.90 μs |  1.00 |    0.02 |  11.7188 |  1.9531 |  208.68 KB |        1.00 |
| NativeParallel | 1000  | Skender.GetRenkoAtr |   199.6 μs |  17.08 μs |  8.94 μs |  1.36 |    0.06 |  17.5781 |  1.9531 |  270.48 KB |        1.30 |
|                |       |                     |            |           |          |       |         |          |         |            |             |
| **Snapshot**       | **10000** | **Skender.GetRenkoAtr** | **2,256.6 μs** |  **27.17 μs** | **16.17 μs** |  **1.29** |    **0.01** |  **46.8750** |       **-** |  **857.64 KB** |        **0.41** |
| NativeSingle   | 10000 | Skender.GetRenkoAtr | 1,752.2 μs |  16.93 μs | 10.08 μs |  1.00 |    0.01 | 125.0000 | 62.5000 | 2078.58 KB |        1.00 |
| NativeParallel | 10000 | Skender.GetRenkoAtr | 2,161.8 μs | 145.82 μs | 96.45 μs |  1.23 |    0.05 | 156.2500 | 62.5000 | 2686.36 KB |        1.29 |
