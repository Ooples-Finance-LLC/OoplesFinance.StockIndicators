```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId           | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |----------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetRenko** |   **161.5 μs** | **23.68 μs** | **14.09 μs** |  **1.01** |    **0.11** |  **114.33 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetRenko |   115.5 μs | 12.70 μs |  7.56 μs |  0.72 |    0.07 |   82.47 KB |        0.72 |
|            |       |                  |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetRenko** | **1,476.4 μs** | **24.72 μs** | **14.71 μs** |  **1.00** |    **0.01** | **1117.58 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetRenko | 1,094.0 μs | 33.21 μs | 19.76 μs |  0.74 |    0.01 |  730.72 KB |        0.65 |
