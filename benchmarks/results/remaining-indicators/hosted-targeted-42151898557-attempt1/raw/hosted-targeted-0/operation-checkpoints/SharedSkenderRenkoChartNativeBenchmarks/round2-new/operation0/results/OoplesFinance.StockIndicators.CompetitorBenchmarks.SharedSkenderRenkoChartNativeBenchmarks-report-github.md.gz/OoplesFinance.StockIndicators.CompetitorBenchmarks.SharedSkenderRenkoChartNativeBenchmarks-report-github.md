```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method         | Count | Operation        | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|--------------- |------ |----------------- |------------:|----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **Snapshot**       | **1000**  | **Skender.GetRenko** |   **147.09 μs** |  **0.805 μs** |  **0.479 μs** |  **1.89** |    **0.01** |  **3.9063** |       **-** |  **102.51 KB** |        **1.99** |
| NativeSingle   | 1000  | Skender.GetRenko |    78.02 μs |  0.875 μs |  0.520 μs |  1.00 |    0.01 |       - |       - |   51.43 KB |        1.00 |
| NativeParallel | 1000  | Skender.GetRenko |   146.16 μs | 10.095 μs |  6.677 μs |  1.87 |    0.08 |  8.7891 |  0.9766 |  130.01 KB |        2.53 |
|                |       |                  |             |           |           |       |         |         |         |            |             |
| **Snapshot**       | **10000** | **Skender.GetRenko** | **1,453.56 μs** | **80.734 μs** | **48.043 μs** |  **1.49** |    **0.05** | **54.6875** |       **-** | **1015.19 KB** |        **1.98** |
| NativeSingle   | 10000 | Skender.GetRenko |   974.52 μs | 18.502 μs | 11.010 μs |  1.00 |    0.02 | 31.2500 |  7.8125 |  513.33 KB |        1.00 |
| NativeParallel | 10000 | Skender.GetRenko | 1,313.97 μs | 80.076 μs | 52.965 μs |  1.35 |    0.05 | 78.1250 | 39.0625 | 1309.58 KB |        2.55 |
