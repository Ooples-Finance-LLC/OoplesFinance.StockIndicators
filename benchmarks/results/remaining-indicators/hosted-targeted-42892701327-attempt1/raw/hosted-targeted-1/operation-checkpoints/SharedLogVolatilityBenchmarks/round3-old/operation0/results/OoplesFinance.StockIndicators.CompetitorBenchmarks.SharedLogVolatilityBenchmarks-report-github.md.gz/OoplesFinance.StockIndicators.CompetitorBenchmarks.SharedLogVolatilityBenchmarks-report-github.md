```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **QuanTAlib.Realized** | **1000**  | **1,998.8 μs** | **31.76 μs** | **21.01 μs** |  **66.01 KB** |
| BuilderLatestOnly | QuanTAlib.Realized | 1000  |   815.7 μs |  6.59 μs |  3.92 μs |  18.32 KB |
| **BuilderFull**       | **QuanTAlib.Realized** | **10000** | **8,180.5 μs** | **37.78 μs** | **22.48 μs** | **629.29 KB** |
| BuilderLatestOnly | QuanTAlib.Realized | 10000 | 8,065.9 μs | 27.07 μs | 14.16 μs | 159.53 KB |
