```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **QuanTAlib.Realized** | **1000**  | **3,060.5 μs** | **134.08 μs** | **88.69 μs** |  **66.01 KB** |
| BuilderLatestOnly | QuanTAlib.Realized | 1000  |   794.2 μs |   5.59 μs |  3.33 μs |  18.32 KB |
| **BuilderFull**       | **QuanTAlib.Realized** | **10000** | **8,100.9 μs** |  **75.32 μs** | **39.40 μs** | **629.44 KB** |
| BuilderLatestOnly | QuanTAlib.Realized | 10000 | 7,917.0 μs |  57.64 μs | 34.30 μs | 159.57 KB |
