```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0   | Allocated  | Alloc Ratio |
|------------------ |------------------- |------ |------------:|-----------:|-----------:|------:|--------:|-------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Realized** | **1000**  | **2,154.22 μs** |  **36.044 μs** |  **21.449 μs** | **33.73** |    **0.43** |      **-** |   **66.01 KB** |        **1.39** |
| BuilderLatestOnly | QuanTAlib.Realized | 1000  |   795.83 μs |   3.947 μs |   2.349 μs | 12.46 |    0.11 |      - |   18.32 KB |        0.39 |
| NativeSingle      | QuanTAlib.Realized | 1000  |    63.87 μs |   0.867 μs |   0.573 μs |  1.00 |    0.01 | 0.4883 |   47.47 KB |        1.00 |
| NativeParallel    | QuanTAlib.Realized | 1000  |   128.86 μs |  17.244 μs |  11.406 μs |  2.02 |    0.17 | 0.9766 |  107.95 KB |        2.27 |
|                   |                    |       |             |            |            |       |         |        |            |             |
| **BuilderFull**       | **QuanTAlib.Realized** | **10000** | **8,057.63 μs** |  **70.049 μs** |  **36.637 μs** | **12.66** |    **0.08** |      **-** |  **629.32 KB** |        **1.34** |
| BuilderLatestOnly | QuanTAlib.Realized | 10000 | 7,941.25 μs |  34.750 μs |  18.175 μs | 12.47 |    0.06 |      - |  159.53 KB |        0.34 |
| NativeSingle      | QuanTAlib.Realized | 10000 |   636.60 μs |   5.396 μs |   2.822 μs |  1.00 |    0.01 | 3.9063 |  469.37 KB |        1.00 |
| NativeParallel    | QuanTAlib.Realized | 10000 | 1,379.66 μs | 223.172 μs | 132.806 μs |  2.17 |    0.20 | 7.8125 | 1057.23 KB |        2.25 |
