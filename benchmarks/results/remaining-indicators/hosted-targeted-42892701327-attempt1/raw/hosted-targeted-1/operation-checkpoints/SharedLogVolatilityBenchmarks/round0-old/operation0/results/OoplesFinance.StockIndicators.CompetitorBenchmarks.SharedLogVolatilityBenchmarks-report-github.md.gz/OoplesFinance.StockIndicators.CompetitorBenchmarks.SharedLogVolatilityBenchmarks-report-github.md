```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **QuanTAlib.Realized** | **1000**  | **1,253.6 μs** | **29.85 μs** | **19.74 μs** |  **66.01 KB** |
| BuilderLatestOnly | QuanTAlib.Realized | 1000  |   801.4 μs | 22.32 μs | 13.29 μs |  18.32 KB |
| **BuilderFull**       | **QuanTAlib.Realized** | **10000** | **8,031.4 μs** | **88.59 μs** | **46.34 μs** | **629.35 KB** |
| BuilderLatestOnly | QuanTAlib.Realized | 10000 | 7,955.1 μs | 99.26 μs | 65.65 μs | 159.53 KB |
