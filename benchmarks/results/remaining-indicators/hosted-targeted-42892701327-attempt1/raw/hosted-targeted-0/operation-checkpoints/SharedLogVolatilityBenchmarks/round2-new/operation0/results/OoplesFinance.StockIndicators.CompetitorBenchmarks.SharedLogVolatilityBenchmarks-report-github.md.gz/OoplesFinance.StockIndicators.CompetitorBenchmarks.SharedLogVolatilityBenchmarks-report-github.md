```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev   | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|---------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Historical** | **1000**  |  **2,289.9 μs** |  **31.11 μs** | **20.58 μs** |  **6.29** |    **0.11** |        **-** |       **-** |   **66.03 KB** |        **0.16** |
| BuilderLatestOnly | QuanTAlib.Historical | 1000  |  1,363.2 μs |   6.27 μs |  3.73 μs |  3.74 |    0.06 |        - |       - |    18.3 KB |        0.04 |
| NativeSingle      | QuanTAlib.Historical | 1000  |    364.2 μs |   8.52 μs |  5.64 μs |  1.00 |    0.02 |  23.4375 |       - |  414.07 KB |        1.00 |
| NativeParallel    | QuanTAlib.Historical | 1000  |    284.0 μs |  19.52 μs | 12.91 μs |  0.78 |    0.04 |  25.3906 |       - |  418.64 KB |        1.01 |
|                   |                      |       |             |           |          |       |         |          |         |            |             |
| **BuilderFull**       | **QuanTAlib.Historical** | **10000** | **13,688.2 μs** |  **51.97 μs** | **27.18 μs** |  **3.70** |    **0.02** |        **-** |       **-** |  **629.76 KB** |        **0.15** |
| BuilderLatestOnly | QuanTAlib.Historical | 10000 | 13,614.5 μs |  72.76 μs | 38.05 μs |  3.68 |    0.02 |        - |       - |  159.94 KB |        0.04 |
| NativeSingle      | QuanTAlib.Historical | 10000 |  3,703.4 μs |  35.94 μs | 21.38 μs |  1.00 |    0.01 | 250.0000 | 31.2500 | 4200.61 KB |        1.00 |
| NativeParallel    | QuanTAlib.Historical | 10000 |  2,283.3 μs | 110.13 μs | 57.60 μs |  0.62 |    0.02 | 250.0000 | 46.8750 | 4205.43 KB |        1.00 |
