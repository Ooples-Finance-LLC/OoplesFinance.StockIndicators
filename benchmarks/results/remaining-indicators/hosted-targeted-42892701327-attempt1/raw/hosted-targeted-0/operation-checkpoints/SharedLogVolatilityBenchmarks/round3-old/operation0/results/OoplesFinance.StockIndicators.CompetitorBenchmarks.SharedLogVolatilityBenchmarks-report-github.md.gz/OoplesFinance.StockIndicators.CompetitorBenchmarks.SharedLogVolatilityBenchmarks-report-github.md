```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **QuanTAlib.Historical** | **1000**  |  **2.245 ms** | **0.0100 ms** | **0.0059 ms** |  **66.03 KB** |
| BuilderLatestOnly | QuanTAlib.Historical | 1000  |  1.318 ms | 0.0072 ms | 0.0043 ms |   18.3 KB |
| **BuilderFull**       | **QuanTAlib.Historical** | **10000** | **13.312 ms** | **0.0461 ms** | **0.0241 ms** | **629.64 KB** |
| BuilderLatestOnly | QuanTAlib.Historical | 10000 | 13.162 ms | 0.0642 ms | 0.0336 ms | 159.54 KB |
