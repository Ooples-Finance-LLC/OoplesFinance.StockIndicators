```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **QuanTAlib.Historical** | **1000**  |  **3.091 ms** | **0.0479 ms** | **0.0317 ms** |  **66.03 KB** |
| BuilderLatestOnly | QuanTAlib.Historical | 1000  |  1.345 ms | 0.0119 ms | 0.0062 ms |   18.3 KB |
| **BuilderFull**       | **QuanTAlib.Historical** | **10000** | **13.364 ms** | **0.0410 ms** | **0.0244 ms** | **629.63 KB** |
| BuilderLatestOnly | QuanTAlib.Historical | 10000 | 13.212 ms | 0.0651 ms | 0.0388 ms |  159.7 KB |
