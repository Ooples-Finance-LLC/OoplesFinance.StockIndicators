"""Freeze one exact-envelope publication consumer after fresh correctness/GPU."""
import argparse, copy, datetime, hashlib, json, subprocess, sys
from pathlib import Path

parser = argparse.ArgumentParser()
for name in ('baseline', 'reference_run', 'reference_source'):
    parser.add_argument(name)
a = parser.parse_args()
r = Path.cwd()
sys.path.insert(0, str(r / 'scripts'))
from hosted_timing.targeted import verify_reference

out = Path(__file__).parent / 'envelope-band-certificate-20261103'
status = json.loads((out / 'status.json').read_text())
assert status['status'] == 'correctness-complete'
candidate = Path(status['repo'])
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=candidate, text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=candidate)
subprocess.run(['git', 'diff', '--exit-code', status['source'], source, '--', 'src', 'tests'], cwd=candidate, check=True)
assert set(status['unit']['classes']) == {'EnvelopeSharedExecutionTests', 'EnvelopeBandCertificateTests'}
assert status['unit']['classes']['EnvelopeBandCertificateTests'] == 6
assert set(status['parity']['classes']) == {'EnvelopeComparisonTests', 'SharedEnvelopeBenchmarkTests',
    'SharedSkenderDiagnosticsBenchmarkTests', 'RemainingAverageEnvelopeBenchmarkTests', 'RemainingRecursiveEnvelopeBenchmarkTests'}
gpu = json.loads((candidate / 'benchmarks/results/shared-rollout/local-gpu-contracts/receipt.json').read_text())
assert gpu['passed_cases'] == 100
p = json.loads((r / 'benchmarks/plans/hosted-pvo-certified-ema-20261103.json').read_text())
receipt = f'benchmarks/results/remaining-indicators/hosted-targeted-{a.reference_run}-attempt1/decision.json'
raw = subprocess.check_output(['git', 'show', a.baseline + ':' + receipt], cwd=r)
p['sources'].update(published=a.baseline, old=a.baseline, successor=source)
p['gpu_sources'].update(old=a.baseline, successor=source)
p['cpu_test_classes'] = dict(old=['EnvelopeSharedExecutionTests'], successor=['EnvelopeSharedExecutionTests', 'EnvelopeBandCertificateTests'])
p['targeted_reference'] = dict(scope='envelope-band-certificate', run_id=a.reference_run, decision=receipt,
    sha256=hashlib.sha256(raw).hexdigest(), qualified_source=a.reference_source)
p['affected_pairs'] = ['Skender.GetMaEnvelopes']
p['targeted_shards'] = copy.deepcopy(p['targeted_shards'][:2])
for index, shard in enumerate(p['targeted_shards']):
    task = shard['tasks'][0]
    task.update(fixture='LibraryPairBenchmarks' if index == 0 else 'SharedSkenderDiagnosticsBenchmarks',
        implicit_pair=False, operations=[dict(raw='Skender.GetMaEnvelopes', pair='Skender.GetMaEnvelopes')],
        cases=10 if index == 0 else 20, decisions=2 if index == 0 else 4)
    shard.update(index=index, tasks=[task], cases=task['cases'], decisions=task['decisions'])
p['matrix'].update(shards=2, max_parallel=2)
p['cases'], p['decisions'] = 30,6
p['source_correctness'] = dict(unit=status['unit']['passed'], comparator=status['parity']['passed'],
    actual_local_gpu=100, source_sha256=gpu['source_sha256'], cpu_build_run=status['build_origin']['run_id'],
    cpu_build_workflow_head=status['build_origin']['workflow_head'])
p['scope'] = 'Private exact envelope band certificate using exact coefficient sums, guarded FMA residuals, one adjacent retry and strict rounding cells; original exact fallback unchanged.'
p['call_graph'] = ['WindowAverageEnvelope.State publishes all nine average modes through this private band stage. Skender.GetMaEnvelopes and canonical SharedSkenderDiagnosticsBenchmarks cover the mapped pair and four builder arms. All nine modes retain exact CPU correctness; shared arithmetic helpers and legacy framework arithmetic are unchanged.']
p['limits'] = ['Exactly two source/test paths; fresh complete 30-case / 6-decision qualification.',
    'At least one faster and zero slower; no pooling; existing SDK/runtime/warmup/iteration/CPU/build/hash/source gates retained.']
p['created_utc'] = p['frozen_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
verify_reference(p)
path = r / 'benchmarks/plans/hosted-envelope-band-certificate-20261103.json'
assert not path.exists()
path.write_text(json.dumps(p, indent=2)+'\n', newline='\n')
w = r / '.github/workflows/cpu-kernel-performance.yml'
s = w.read_text()
needle = 'benchmarks/plans/hosted-pvo-certified-ema-20261103.json]'
assert s.count(needle) == 1
w.write_text(s.replace(needle, needle[:-1]+', '+path.relative_to(r).as_posix()+']'), newline='\n')
attributes = r / '.gitattributes'
attributes.write_text(attributes.read_text()+path.relative_to(r).as_posix()+' text eol=lf\n', newline='\n')
print(source, hashlib.sha256(path.read_bytes()).hexdigest())
