"""Stage one root-authenticated rejected qualification archive; never commit or push."""
import copy
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess

OPS = Path(r'C:\Users\cheat\source\stock-indicators-operations')
PUB = Path(r'C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-ultimate-direct-long-publication-20261118')
QUAL = Path(r'C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-cmf-alma-combined-qualification-20261118')
ROOT = OPS / 'cmf-alma-combined-qualification-20261118'
RUN = '44380429057'
BASE = '9c0d3be4f658688fbb5307fc881f72d0c3561f0e'
OLD = 'c5bfd4950982aa80dddbfd2db6358ad43ddb9e4c'
NEW = '409c5f5eea78724f83c999469b76bacbbb193911'
HEAD = 'a76d97c39edae8f49a4fa9729bfdb36a0b802671'
BRANCH = 'evidence/cmf-alma-combined-rejected-20261118'
PLAN = 'benchmarks/plans/hosted-cmf-alma-combined-qualification-20261118.json'
PLAN_SHA = '79d3d03be390c855e69558937755d22b9fb1f1ec6db47bf07239d94992d79a77'
SUMMARY_SHA = 'bd6cb2ae0a5e1b89c81eb0eef6b4200f68c198a5930cba22ccca36ae481d3233'
RECEIPT_SHA = '87d625dcf4722c02dda3c3973e2cf67e02858b7ab7fb0c7cb0385c8513f3b3d3'
REVIEW_SHA = '97c6facf29e3b2339b184918c1cf53f69f3b5c13817a53453ef5cb9137361617'
ZIP_SHA = '6d2c0db66140a16899d7cbbb9af3f2f89f4bf42afe54e636986808fea14dea0f'
COLLECTOR_SHA = 'b05164cb58deb0ff82db8baee22c4a9ff55e406bc8e023a6ca2dfe6ca97b3a3f'
EVIDENCE = ROOT / 'local-evidence' / ('cmf-alma-combined-qualification-' + RUN)
PREP = ROOT / ('hosted-inputs-' + RUN)
RAW = EVIDENCE / 'raw/evidence'
REL = 'benchmarks/results/remaining-indicators/hosted-targeted-' + RUN + '-attempt1'
OUT = PUB / REL
REVIEW_OUT = OPS / 'cmf-alma-combined-rejection-archive-20261118.review.json'
DIFF_OUT = OPS / 'cmf-alma-combined-rejection-archive-20261118.complete.diff'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*args, repo=PUB):
    return subprocess.check_output(['git', *args], cwd=repo)


def render(value):
    return (json.dumps(value, indent=2) + '\n').encode()


def pinned(path, expected):
    raw = path.read_bytes()
    assert sha(raw) == expected, str(path)
    return raw


assert git('rev-parse', 'HEAD').decode().strip() == BASE
assert git('symbolic-ref', '--short', 'HEAD').decode().strip() == BRANCH
assert not git('status', '--porcelain'), 'Preserve existing changes'
assert not git('diff', OLD, BASE, '--', 'src', 'tests')
assert git('rev-parse', 'refs/heads/perf/ultimate-direct-long-publication-20261118').decode().strip() == BASE
assert git('rev-parse', 'refs/remotes/origin/perf/remaining-indicator-rollout').decode().strip() == BASE
remote_ref = git('ls-remote', '--heads', 'origin', 'refs/heads/perf/remaining-indicator-rollout')
assert remote_ref.decode().split() == [BASE, 'refs/heads/perf/remaining-indicator-rollout']
assert OUT.resolve().is_relative_to(PUB.resolve()) and not OUT.exists()
assert not git('ls-tree', '-r', '--name-only', BASE, '--', REL)
assert not REVIEW_OUT.exists() and not DIFF_OUT.exists()
assert shutil.disk_usage(PUB).free >= 64 * 1024**2

summary_raw = pinned(EVIDENCE / 'authenticated-summary.json', SUMMARY_SHA)
assert (EVIDENCE / 'uploaded-summary.json').read_bytes() == summary_raw
summary = json.loads(summary_raw)
receipt_raw = pinned(EVIDENCE / 'collection-receipt.json', RECEIPT_SHA)
receipt = json.loads(receipt_raw)
root_raw = pinned(EVIDENCE / 'root-review.json', REVIEW_SHA)
root_review = json.loads(root_raw)
assert summary['accepted'] is False and summary['qualification'] is True
assert summary['source_gate_accepted'] is True and summary['native_progress_gate_passed'] is False
assert summary['verdicts'] == {'inconclusive': 15, 'faster': 5}
assert len(summary['decisions']) == 20 and (summary['case_count'], summary['decision_count']) == (100, 20)
gate = summary['native_progress_gate']
assert not gate['new_10000_target_wins'] and not gate['at_least_one_new_10000_target_win']
assert gate['protected_ultimate_native_wins_preserved'] and gate['net_10000_point_progress']
assert gate['all_library_pair_source_comparisons_no_regression'] and not gate['prior_native_win_reopenings']
assert receipt['status'] == 'actual-cmf-alma-combined-qualification-authenticated'
assert receipt['artifact_id'] == 14466196667 and receipt['artifact_zip_sha256'] == ZIP_SHA
assert receipt['head'] == HEAD and receipt['plan_sha256'] == PLAN_SHA and receipt['summary_sha256'] == SUMMARY_SHA
assert root_review['status'] == 'root-independent-recollection-passed'
assert root_review['summary_sha256'] == SUMMARY_SHA and root_review['collection_receipt_sha256'] == RECEIPT_SHA
assert root_review['artifact_zip_sha256'] == ZIP_SHA and root_review['plan_sha256'] == PLAN_SHA
assert root_review['accepted'] is False and root_review['new_native_wins'] == 0
assert root_review['verdicts'] == dict(faster=5, inconclusive=15, slower=0)
assert root_review['retained_evidence_files_changed'] == root_review['new_builds'] == root_review['new_measurements'] == 0
assert (root_review['verified_zip_files'], root_review['verified_prepared_files'], root_review['verified_raw_files']) == (1180, 757, 222)

plan_raw = git('show', HEAD + ':' + PLAN, repo=QUAL)
assert sha(plan_raw) == PLAN_SHA
collector = OPS / 'collect-cmf-alma-combined-qualification-20261118.py'
pinned(collector, COLLECTOR_SHA)
source_patch = git('diff', '--binary', OLD, NEW, '--', 'src', 'tests')
assert sha(source_patch) == '69daa15e17e44016c916fd7d1076c6757f8ad629b8900ec7f2b5802d2847858e'

all_prepared = sorted(p for p in PREP.rglob('*') if p.is_file())
prepared = [p for p in all_prepared if p.relative_to(PREP).parts[0] not in ('common', 'production') and 'blobs' not in p.relative_to(PREP).parts]
raw_files = sorted(p for p in RAW.rglob('*') if p.is_file())
assert len(all_prepared) == 757 and len(prepared) == 30 and len(raw_files) == 222
assert sum(p.stat().st_size for p in prepared + raw_files) < 48 * 1024**2
assert all(not p.is_symlink() for p in prepared + raw_files)
assert all(p.suffix.lower() not in ('.dll', '.exe', '.pdb', '.so', '.dylib') for p in prepared + raw_files)
tooling_paths = git('ls-tree', '-r', '--name-only', HEAD, '--', 'scripts/hosted_timing', repo=QUAL).decode().splitlines()
tooling_paths += ['scripts/build-candidate-correctness.py', 'scripts/verify-competitor-local-gpu.py',
    'scripts/run-competitor-contracts.py', 'scripts/competitor-gpu-methods.json',
    'scripts/test_hosted_cmf_alma_combined_qualification.py', '.github/workflows/cmf-alma-combined-qualification.yml']
assert len(tooling_paths) == len(set(tooling_paths))
tooling = {p: git('show', HEAD + ':' + p, repo=QUAL) for p in tooling_paths}

OUT.mkdir(parents=True)
files = []


def store(name, raw, source, compress=True):
    rel = PurePosixPath(name)
    assert not rel.is_absolute() and '..' not in rel.parts and '\\' not in name
    assert not any(part in ('blobs', 'common', 'production') for part in rel.parts)
    archive_name = name + '.gz' if compress else name
    encoded = gzip.compress(raw, mtime=0) if compress else raw
    dest = OUT / archive_name
    assert dest.resolve().is_relative_to(OUT.resolve()) and not dest.exists()
    dest.parent.mkdir(parents=True, exist_ok=True)
    with dest.open('xb') as stream:
        stream.write(encoded)
    files.append(dict(path=archive_name, source=source, source_sha256=sha(raw), source_bytes=len(raw),
        sha256=sha(encoded), bytes=len(encoded), encoding='gzip' if compress else 'identity'))


store('.gitattributes', b'*.gz -text\n*.json text eol=lf\nroot-review.json -text whitespace=cr-at-eol\n', 'archive policy', False)
for path in prepared:
    store('prepared/' + path.relative_to(PREP).as_posix(), path.read_bytes(), str(path))
for path in raw_files:
    store('raw/' + path.relative_to(RAW).as_posix(), path.read_bytes(), str(path))
for name in ['authenticated-summary.json', 'uploaded-summary.json', 'collection-receipt.json', 'artifact-api.json', 'run-api.json', 'storage-budget.json']:
    store(name, (EVIDENCE / name).read_bytes(), str(EVIDENCE / name))
store('root-review.json', root_raw, str(EVIDENCE / 'root-review.json'), False)
store('plan.json', plan_raw, HEAD + ':' + PLAN)
store('candidate-source.patch', source_patch, OLD + '..' + NEW + ' -- src tests')
for name, raw in tooling.items():
    store('tooling/' + name, raw, HEAD + ':' + name)
store('tooling/' + collector.name, collector.read_bytes(), str(collector))
store('tooling/' + Path(__file__).name, Path(__file__).read_bytes(), str(Path(__file__)))

failures = [dict(pair='QuanTAlib.Alma', bars=10000, source_verdict='inconclusive',
    reason='Round 2 candidate upper interval exceeds native lower interval; the own-source LibraryPair verdict is inconclusive.'),
    dict(pair='Skender.GetCmf', bars=10000, source_verdict='inconclusive',
    reason='Round 2 candidate mean is slower than native and fails the 10% margin and interval separation; own-source LibraryPair verdict is inconclusive.'),
    dict(pair='Skender.GetAlma', bars=10000, source_verdict='faster',
    reason='Both candidate round means remain slower than native despite an own-source improvement.')]
decision = copy.deepcopy(summary)
decision.update(status='rejected-native-progress-gate', run_id=RUN, run_attempt='1', workflow_head=HEAD,
    plan_sha256=PLAN_SHA, summary_sha256=SUMMARY_SHA, artifact_id=14466196667, artifact_zip_sha256=ZIP_SHA,
    collection_receipt_sha256=RECEIPT_SHA, root_review_sha256=REVIEW_SHA,
    verdicts=dict(faster=5, inconclusive=15, slower=0), native_gate_failure_details=failures,
    measurement_url='https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/' + RUN,
    root_independent_recollection_matches=True, production_integrated=False, report_imported=False,
    new_native_wins=0, closure_credit=0, new_builds=0, new_measurements=0, retries=0,
    production_source_preserved=OLD, publisher_base=BASE,
    note='Rejected evidence only. Fresh point progress and five own-source faster decisions do not satisfy the unchanged new-native-win gate. The combined source patch is archived for review and is not applied. Published C5 source, tests, GPU contracts and PR266 history remain unchanged.')
store('decision.json', render(decision), 'root-authenticated summary plus explicit rejection metadata', False)
replay = dict(status='retained-rejection-replay-map', workflow_head=HEAD, plan_sha256=PLAN_SHA,
    measurement_run=RUN, raw_root='raw/', prepared_metadata_root='prepared/',
    summary='authenticated-summary.json.gz', root_review='root-review.json',
    parser_module='scripts/hosted_timing/cmf_alma_combined_qualification.py',
    tooling_snapshot='tooling/', compression='Each .gz restores the exact source bytes recorded in archive-index.json.',
    runtime_payload_archived=False, excluded_prepared_payload_files=len(all_prepared) - len(prepared),
    runtime_recovery='Prepared manifests/provenance retain exact runtime/CAS and original artifact identities. Existing OPS authenticated inputs and CAS remain retained; no DLL or CAS blob payload is copied into this archive.',
    scope='Decompress and replay collection/parsing with the pinned tooling/source refs and retained authenticated inputs. Do not rerun timing, rebuild, change the gate or claim qualification from this rejection.')
store('replay.json', render(replay), 'archive replay instructions', False)

index = dict(status='root-authenticated-rejected-native-progress-gate', run_id=RUN, run_attempt='1',
    workflow_head=HEAD, candidate_source=NEW, baseline=OLD, publisher_base=BASE, tooling=HEAD,
    candidate_source_fingerprint='3d5c4ed70533fa52c29bb2ad19754857837b4a333855acb610563d149f3b3fac',
    preserved_published_source_fingerprint='4b348074bcf3350f0af46261beb830cfe0cd50001ad2c06756c54cb5a1b054f4',
    preserved_gpu_receipt_sha256=sha(git('show', BASE + ':benchmarks/results/shared-rollout/local-gpu-contracts/receipt.json')),
    cases=100, decisions=20, verdicts=dict(faster=5, inconclusive=15, slower=0), accepted=False,
    source_gate_passed=True, native_progress_gate_passed=False, root_independent_recollection_matches=True,
    plan_sha256=PLAN_SHA, summary_sha256=SUMMARY_SHA, collection_receipt_sha256=RECEIPT_SHA,
    root_review_sha256=REVIEW_SHA, artifact_id=14466196667, artifact_zip_sha256=ZIP_SHA,
    prepared_metadata_files=len(prepared), raw_files=len(raw_files), tooling_files=len(tooling) + 2,
    excluded_prepared_runtime_payload_files=len(all_prepared) - len(prepared), runtime_dlls_archived=0,
    runtime_payload_bytes_archived=0, source_patch_applied=False, production_committed=False,
    production_integrated=False, report_imported=False, published_closure_credit=0, files=files)
with (OUT / 'archive-index.json').open('xb') as stream:
    stream.write(render(index))

# Verify every archive payload against its original-content and stored-byte pins.
for item in files:
    encoded = (OUT / item['path']).read_bytes()
    assert len(encoded) == item['bytes'] and sha(encoded) == item['sha256']
    decoded = gzip.decompress(encoded) if item['encoding'] == 'gzip' else encoded
    assert len(decoded) == item['source_bytes'] and sha(decoded) == item['source_sha256']
assert len(list(OUT.rglob('*'))) >= len(files) + 1
subprocess.run(['git', 'add', '--sparse', '--', REL], cwd=PUB, check=True)
subprocess.run(['git', 'diff', '--cached', '--check'], cwd=PUB, check=True)
changed = git('diff', '--cached', '--name-status', BASE).decode().splitlines()
assert len(changed) == len(files) + 1
assert all(line.startswith('A\t' + REL + '/') for line in changed)
assert not git('diff', '--cached', BASE, '--', 'src', 'tests', 'benchmarks/results/shared-rollout/local-gpu-contracts')
assert not git('diff'), 'No unstaged tracked changes'
assert git('rev-parse', 'refs/heads/perf/ultimate-direct-long-publication-20261118').decode().strip() == BASE
assert git('rev-parse', 'refs/remotes/origin/perf/remaining-indicator-rollout').decode().strip() == BASE
assert git('ls-remote', '--heads', 'origin', 'refs/heads/perf/remaining-indicator-rollout') == remote_ref
complete_diff = git('diff', '--cached', '--binary', '--no-ext-diff', '--no-textconv', BASE)
with DIFF_OUT.open('xb') as stream:
    stream.write(complete_diff)
review = dict(status='staged-rejected-evidence-only-awaiting-root-review-before-commit-push',
    worktree=str(PUB), branch=BRANCH, parent=BASE, remote_pr_head_preserved=BASE,
    archive=REL, changed_files=len(changed), archive_bytes=sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file()),
    archive_index_sha256=sha((OUT / 'archive-index.json').read_bytes()), archive_payload_hashes_checked=len(files),
    raw_files=len(raw_files), prepared_metadata_files=len(prepared), runtime_payload_files_archived=0,
    source_tests_gpu_unchanged=True, all_prior_archive_entries_preserved=True,
    summary_sha256=SUMMARY_SHA, root_review_sha256=REVIEW_SHA, accepted=False,
    verdicts=dict(faster=5, inconclusive=15, slower=0), native_credit=0,
    complete_diff=str(DIFF_OUT), complete_diff_sha256=sha(complete_diff), complete_diff_bytes=len(complete_diff),
    committed=False, pushed=False, pr_created=False, main_pr_updated=False, new_builds=0, new_measurements=0)
with REVIEW_OUT.open('xb') as stream:
    stream.write(render(review))
print(json.dumps(review, indent=2))
