```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean     | Error    | StdDev   | Gen0   | Allocated |
|------------------ |--------------- |------ |---------:|---------:|---------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetCmf** | **1000**  | **116.3 μs** |  **7.09 μs** |  **3.71 μs** |      **-** |  **85.73 KB** |
| BuilderLatestOnly | Skender.GetCmf | 1000  | 113.6 μs |  7.30 μs |  4.83 μs |      - |  38.13 KB |
| **BuilderFull**       | **Skender.GetCmf** | **10000** | **523.8 μs** | **12.75 μs** |  **6.67 μs** | **7.8125** | **784.44 KB** |
| BuilderLatestOnly | Skender.GetCmf | 10000 | 528.9 μs | 62.50 μs | 41.34 μs |      - | 314.62 KB |
