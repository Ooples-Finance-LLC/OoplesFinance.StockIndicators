```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean     | Error    | StdDev   | Gen0   | Gen1   | Allocated |
|------------------ |--------------- |------ |---------:|---------:|---------:|-------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetCmf** | **1000**  | **117.4 μs** | **13.22 μs** |  **7.87 μs** |      **-** |      **-** |  **85.73 KB** |
| BuilderLatestOnly | Skender.GetCmf | 1000  | 113.6 μs |  9.02 μs |  5.96 μs |      - |      - |  38.13 KB |
| **BuilderFull**       | **Skender.GetCmf** | **10000** | **562.3 μs** | **77.43 μs** | **51.22 μs** | **7.8125** | **3.9063** | **789.22 KB** |
| BuilderLatestOnly | Skender.GetCmf | 10000 | 512.0 μs | 10.43 μs |  5.46 μs | 3.9063 |      - |  319.4 KB |
