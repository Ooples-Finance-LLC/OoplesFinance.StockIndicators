```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev   | Ratio | RatioSD | Gen0    | Gen1    | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |-----------:|----------:|---------:|------:|--------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetCmf** | **1000**  |   **125.1 μs** |  **21.41 μs** | **14.16 μs** |  **0.89** |    **0.10** |       **-** |       **-** |       **-** |   **85.73 KB** |        **0.29** |
| BuilderLatestOnly | Skender.GetCmf | 1000  |   112.8 μs |   9.12 μs |  6.04 μs |  0.80 |    0.04 |       - |       - |       - |   38.13 KB |        0.13 |
| NativeSingle      | Skender.GetCmf | 1000  |   140.4 μs |   2.85 μs |  1.89 μs |  1.00 |    0.02 |  2.9297 |       - |       - |   297.9 KB |        1.00 |
| NativeParallel    | Skender.GetCmf | 1000  |   151.0 μs |  11.90 μs |  7.87 μs |  1.08 |    0.06 |  3.9063 |  0.9766 |       - |   326.3 KB |        1.10 |
|                   |                |       |            |           |          |       |         |         |         |         |            |             |
| **BuilderFull**       | **Skender.GetCmf** | **10000** |   **508.0 μs** |  **11.57 μs** |  **6.05 μs** |  **0.26** |    **0.01** |  **7.8125** |       **-** |       **-** |  **784.44 KB** |        **0.26** |
| BuilderLatestOnly | Skender.GetCmf | 10000 |   525.7 μs |  70.93 μs | 46.92 μs |  0.27 |    0.03 |       - |       - |       - |  314.62 KB |        0.11 |
| NativeSingle      | Skender.GetCmf | 10000 | 1,936.0 μs | 131.05 μs | 86.68 μs |  1.00 |    0.06 | 46.8750 | 46.8750 | 46.8750 | 2970.29 KB |        1.00 |
| NativeParallel    | Skender.GetCmf | 10000 | 1,055.2 μs |  84.66 μs | 55.99 μs |  0.55 |    0.04 | 39.0625 | 31.2500 |       - | 3068.54 KB |        1.03 |
