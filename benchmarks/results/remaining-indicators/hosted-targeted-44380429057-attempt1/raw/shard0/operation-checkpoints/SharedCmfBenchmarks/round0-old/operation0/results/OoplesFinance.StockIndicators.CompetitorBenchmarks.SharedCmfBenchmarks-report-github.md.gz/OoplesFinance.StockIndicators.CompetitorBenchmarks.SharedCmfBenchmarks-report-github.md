```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean     | Error     | StdDev    | Gen0   | Gen1   | Allocated |
|------------------ |--------------- |------ |---------:|----------:|----------:|-------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetCmf** | **1000**  | **142.2 μs** |   **2.77 μs** |   **1.65 μs** |      **-** |      **-** |  **85.73 KB** |
| BuilderLatestOnly | Skender.GetCmf | 1000  | 139.9 μs |   3.95 μs |   2.61 μs |      - |      - |  38.13 KB |
| **BuilderFull**       | **Skender.GetCmf** | **10000** | **693.1 μs** | **153.87 μs** | **101.78 μs** | **7.8125** | **3.9063** | **789.22 KB** |
| BuilderLatestOnly | Skender.GetCmf | 10000 | 702.3 μs |  66.11 μs |  43.73 μs | 3.9063 |      - |  319.4 KB |
