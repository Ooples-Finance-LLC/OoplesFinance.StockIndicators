```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetCmf** |   **226.1 μs** |  **35.13 μs** |  **18.37 μs** |  **1.01** |    **0.11** |  **189.85 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetCmf |   142.2 μs |  11.40 μs |   6.78 μs |  0.63 |    0.05 |  387.09 KB |        2.04 |
|            |       |                |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetCmf** | **1,569.1 μs** | **161.00 μs** | **106.49 μs** |  **1.00** |    **0.09** | **1840.16 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetCmf | 1,558.5 μs |  72.68 μs |  43.25 μs |  1.00 |    0.07 |  3790.1 KB |        2.06 |
