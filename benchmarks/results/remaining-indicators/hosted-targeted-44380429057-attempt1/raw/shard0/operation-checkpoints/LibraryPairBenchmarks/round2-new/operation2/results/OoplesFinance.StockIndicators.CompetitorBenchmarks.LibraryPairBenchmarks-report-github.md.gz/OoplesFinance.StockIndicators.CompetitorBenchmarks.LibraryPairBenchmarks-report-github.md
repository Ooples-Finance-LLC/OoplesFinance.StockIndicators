```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId          | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAlma** |   **392.75 μs** | **104.28 μs** | **68.973 μs** |  **1.03** |    **0.25** |  **111.39 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAlma |    82.69 μs |  12.12 μs |  7.212 μs |  0.22 |    0.04 |  115.52 KB |        1.04 |
|            |       |                 |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAlma** | **1,499.03 μs** |  **41.61 μs** | **21.762 μs** |  **1.00** |    **0.02** | **1040.05 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAlma |   731.65 μs |  31.89 μs | 21.091 μs |  0.49 |    0.01 | 1073.25 KB |        1.03 |
