```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Alma** |   **364.7 μs** |  **72.03 μs** |  **42.86 μs** |  **1.01** |    **0.15** |  **126.05 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Alma |   312.6 μs |  17.24 μs |  10.26 μs |  0.87 |    0.09 |   72.31 KB |        0.57 |
|            |       |                |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Alma** | **2,370.4 μs** | **831.85 μs** | **550.22 μs** |  **1.06** |    **0.36** | **1056.66 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Alma | 3,093.4 μs |  20.13 μs |  13.31 μs |  1.38 |    0.35 |  644.26 KB |        0.61 |
