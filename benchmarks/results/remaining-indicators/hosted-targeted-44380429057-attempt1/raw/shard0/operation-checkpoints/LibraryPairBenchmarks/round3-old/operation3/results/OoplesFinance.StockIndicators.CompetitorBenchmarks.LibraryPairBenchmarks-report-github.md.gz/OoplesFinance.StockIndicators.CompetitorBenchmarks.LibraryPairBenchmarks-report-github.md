```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId              | Mean       | Error     | StdDev    | Median   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |-------------------- |-----------:|----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetUltimate** |   **118.4 μs** |   **8.84 μs** |   **5.26 μs** | **117.8 μs** |  **1.00** |    **0.06** |  **105.68 KB** |        **1.00** |
|        |       |                     |            |           |           |          |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetUltimate** | **1,200.0 μs** | **878.64 μs** | **581.16 μs** | **865.7 μs** |  **1.17** |    **0.68** | **1047.53 KB** |        **1.00** |
