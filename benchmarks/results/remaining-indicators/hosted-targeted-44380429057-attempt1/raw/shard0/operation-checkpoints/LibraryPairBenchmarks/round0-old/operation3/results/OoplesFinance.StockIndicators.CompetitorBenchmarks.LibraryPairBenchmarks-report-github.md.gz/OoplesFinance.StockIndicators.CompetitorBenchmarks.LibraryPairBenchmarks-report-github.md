```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId              | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |-------------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetUltimate** |   **141.8 μs** |  **60.19 μs** |  **35.82 μs** |  **1.05** |    **0.33** | **105.68 KB** |        **1.00** |
|        |       |                     |            |           |           |       |         |           |             |
| **Ooples** | **10000** | **Skender.GetUltimate** | **1,332.7 μs** | **582.62 μs** | **385.37 μs** |  **1.08** |    **0.44** | **1047.2 KB** |        **1.00** |
