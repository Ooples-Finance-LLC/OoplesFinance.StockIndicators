```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetUltimate** |   **131.4 μs** | **21.46 μs** | **11.23 μs** |  **1.01** |    **0.12** |  **105.68 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetUltimate |   190.2 μs |  5.75 μs |  3.42 μs |  1.46 |    0.12 |  185.64 KB |        1.76 |
|            |       |                     |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetUltimate** |   **840.3 μs** | **84.52 μs** | **44.21 μs** |  **1.00** |    **0.07** | **1047.53 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetUltimate | 2,058.4 μs | 98.36 μs | 58.53 μs |  2.46 |    0.14 |  1775.8 KB |        1.70 |
