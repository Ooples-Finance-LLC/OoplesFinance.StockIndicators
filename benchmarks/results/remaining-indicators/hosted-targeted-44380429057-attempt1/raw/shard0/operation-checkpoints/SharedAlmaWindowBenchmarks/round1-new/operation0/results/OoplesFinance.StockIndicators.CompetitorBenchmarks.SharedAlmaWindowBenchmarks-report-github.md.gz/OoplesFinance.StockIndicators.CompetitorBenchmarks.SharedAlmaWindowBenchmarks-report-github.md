```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **QuanTAlib.Alma** | **1000**  |   **881.3 μs** |  **11.41 μs** |   **5.97 μs** |  **91.44 KB** |
| BuilderLatestOnly | QuanTAlib.Alma | 1000  |   366.0 μs |   8.72 μs |   4.56 μs |  43.77 KB |
| **BuilderFull**       | **QuanTAlib.Alma** | **10000** | **1,559.4 μs** | **113.19 μs** |  **67.36 μs** | **650.26 KB** |
| BuilderLatestOnly | QuanTAlib.Alma | 10000 | 1,617.3 μs | 172.99 μs | 114.43 μs | 180.38 KB |
