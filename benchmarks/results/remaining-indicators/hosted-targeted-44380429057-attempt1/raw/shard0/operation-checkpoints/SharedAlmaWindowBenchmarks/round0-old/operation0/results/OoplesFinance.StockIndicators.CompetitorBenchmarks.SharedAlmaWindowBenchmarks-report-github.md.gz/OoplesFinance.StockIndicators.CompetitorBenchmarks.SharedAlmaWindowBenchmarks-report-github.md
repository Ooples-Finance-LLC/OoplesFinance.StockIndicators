```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **QuanTAlib.Alma** | **1000**  |   **542.5 μs** | **155.99 μs** | **103.18 μs** |  **91.43 KB** |
| BuilderLatestOnly | QuanTAlib.Alma | 1000  |   364.2 μs |   8.05 μs |   4.21 μs |  43.77 KB |
| **BuilderFull**       | **QuanTAlib.Alma** | **10000** | **2,827.6 μs** | **250.48 μs** | **165.68 μs** | **654.31 KB** |
| BuilderLatestOnly | QuanTAlib.Alma | 10000 | 2,719.2 μs | 128.75 μs |  67.34 μs | 184.62 KB |
