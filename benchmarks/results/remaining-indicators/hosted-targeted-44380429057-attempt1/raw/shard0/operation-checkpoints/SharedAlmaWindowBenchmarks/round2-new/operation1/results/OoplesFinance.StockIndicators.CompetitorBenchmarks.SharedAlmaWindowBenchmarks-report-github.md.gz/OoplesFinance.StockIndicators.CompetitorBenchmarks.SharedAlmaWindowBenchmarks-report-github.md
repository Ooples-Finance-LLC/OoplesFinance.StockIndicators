```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error        | StdDev       | Median      | Ratio | RatioSD | Gen0    | Gen1    | Gen2    | Allocated | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-------------:|-------------:|------------:|------:|--------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **Skender.GetAlma** | **1000**  | **2,880.55 μs** | **4,947.944 μs** | **3,272.759 μs** | **1,118.26 μs** | **45.91** |   **49.78** |       **-** |       **-** |       **-** |  **76.78 KB** |        **0.78** |
| BuilderLatestOnly | Skender.GetAlma | 1000  |   310.26 μs |    18.044 μs |     9.437 μs |   306.65 μs |  4.94 |    0.22 |       - |       - |       - |  29.11 KB |        0.30 |
| NativeSingle      | Skender.GetAlma | 1000  |    62.82 μs |     3.393 μs |     2.244 μs |    61.84 μs |  1.00 |    0.05 |  0.9766 |       - |       - |  98.29 KB |        1.00 |
| NativeParallel    | Skender.GetAlma | 1000  |    92.25 μs |     8.504 μs |     5.625 μs |    88.54 μs |  1.47 |    0.10 |  0.9766 |       - |       - | 105.26 KB |        1.07 |
|                   |                 |       |             |              |              |             |       |         |         |         |         |           |             |
| **BuilderFull**       | **Skender.GetAlma** | **10000** | **1,564.19 μs** |   **153.680 μs** |   **101.650 μs** | **1,569.81 μs** |  **1.84** |    **0.16** |       **-** |       **-** |       **-** | **633.58 KB** |        **0.65** |
| BuilderLatestOnly | Skender.GetAlma | 10000 | 1,549.06 μs |   146.336 μs |    96.792 μs | 1,489.43 μs |  1.82 |    0.16 |       - |       - |       - | 163.77 KB |        0.17 |
| NativeSingle      | Skender.GetAlma | 10000 |   852.23 μs |    97.005 μs |    57.726 μs |   851.85 μs |  1.00 |    0.09 | 85.9375 | 78.1250 | 78.1250 |  977.9 KB |        1.00 |
| NativeParallel    | Skender.GetAlma | 10000 |   410.01 μs |    16.684 μs |     8.726 μs |   410.44 μs |  0.48 |    0.03 | 11.7188 |  7.8125 |       - |  984.2 KB |        1.01 |
