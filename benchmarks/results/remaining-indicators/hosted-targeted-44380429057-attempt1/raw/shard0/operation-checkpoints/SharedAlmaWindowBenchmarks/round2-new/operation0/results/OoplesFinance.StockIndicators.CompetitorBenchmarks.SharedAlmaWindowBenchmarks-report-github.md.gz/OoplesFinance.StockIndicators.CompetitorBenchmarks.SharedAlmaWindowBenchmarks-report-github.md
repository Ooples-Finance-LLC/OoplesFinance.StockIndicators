```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error       | StdDev      | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------- |------ |-----------:|------------:|------------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Alma** | **1000**  | **4,320.3 μs** | **5,714.56 μs** | **3,779.83 μs** | **16.94** |   **14.14** |  **91.44 KB** |        **1.92** |
| BuilderLatestOnly | QuanTAlib.Alma | 1000  |   371.1 μs |    15.85 μs |     8.29 μs |  1.45 |    0.03 |  43.75 KB |        0.92 |
| NativeSingle      | QuanTAlib.Alma | 1000  |   255.1 μs |     3.06 μs |     1.82 μs |  1.00 |    0.01 |  47.63 KB |        1.00 |
| NativeParallel    | QuanTAlib.Alma | 1000  |   212.2 μs |    12.86 μs |     6.73 μs |  0.83 |    0.03 |  52.15 KB |        1.09 |
|                   |                |       |            |             |             |       |         |           |             |
| **BuilderFull**       | **QuanTAlib.Alma** | **10000** | **1,625.5 μs** |   **196.51 μs** |   **129.98 μs** |  **0.64** |    **0.05** | **650.26 KB** |        **1.38** |
| BuilderLatestOnly | QuanTAlib.Alma | 10000 | 1,561.3 μs |   127.69 μs |    84.46 μs |  0.61 |    0.03 | 180.38 KB |        0.38 |
| NativeSingle      | QuanTAlib.Alma | 10000 | 2,553.6 μs |    24.71 μs |    12.93 μs |  1.00 |    0.01 | 469.61 KB |        1.00 |
| NativeParallel    | QuanTAlib.Alma | 10000 | 1,555.6 μs |    75.57 μs |    39.53 μs |  0.61 |    0.01 | 474.13 KB |        1.01 |
