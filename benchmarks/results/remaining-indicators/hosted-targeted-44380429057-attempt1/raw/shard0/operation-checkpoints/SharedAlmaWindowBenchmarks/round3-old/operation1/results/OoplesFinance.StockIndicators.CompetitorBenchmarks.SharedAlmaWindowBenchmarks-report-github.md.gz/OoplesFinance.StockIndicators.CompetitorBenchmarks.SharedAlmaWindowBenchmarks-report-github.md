```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error       | StdDev      | Median     | Allocated |
|------------------ |---------------- |------ |-----------:|------------:|------------:|-----------:|----------:|
| **BuilderFull**       | **Skender.GetAlma** | **1000**  | **3,994.2 μs** | **5,195.13 μs** | **3,436.26 μs** | **3,039.1 μs** |  **76.78 KB** |
| BuilderLatestOnly | Skender.GetAlma | 1000  |   303.6 μs |     4.39 μs |     2.29 μs |   303.5 μs |   29.1 KB |
| **BuilderFull**       | **Skender.GetAlma** | **10000** | **2,794.3 μs** |   **292.07 μs** |   **193.18 μs** | **2,702.5 μs** | **639.64 KB** |
| BuilderLatestOnly | Skender.GetAlma | 10000 | 2,744.0 μs |   239.38 μs |   158.33 μs | 2,647.5 μs | 169.83 KB |
