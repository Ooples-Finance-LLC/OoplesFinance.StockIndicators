```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |---------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Skender.GetAlma** | **1000**  | **1,043.8 μs** |  **44.49 μs** |  **26.48 μs** |  **76.77 KB** |
| BuilderLatestOnly | Skender.GetAlma | 1000  |   422.9 μs | 122.80 μs |  81.23 μs |  29.11 KB |
| **BuilderFull**       | **Skender.GetAlma** | **10000** | **4,631.5 μs** |  **79.44 μs** |  **47.27 μs** | **639.77 KB** |
| BuilderLatestOnly | Skender.GetAlma | 10000 | 4,679.8 μs | 267.16 μs | 139.73 μs | 169.96 KB |
