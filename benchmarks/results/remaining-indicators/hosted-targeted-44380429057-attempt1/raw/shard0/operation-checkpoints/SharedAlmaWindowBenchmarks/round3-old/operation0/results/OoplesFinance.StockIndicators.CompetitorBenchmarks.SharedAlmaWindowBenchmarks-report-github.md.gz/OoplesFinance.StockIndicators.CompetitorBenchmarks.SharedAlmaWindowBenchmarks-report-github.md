```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **QuanTAlib.Alma** | **1000**  |   **410.0 μs** |  **26.38 μs** |  **17.45 μs** |  **91.43 KB** |
| BuilderLatestOnly | QuanTAlib.Alma | 1000  |   369.8 μs |  19.01 μs |   9.94 μs |  43.77 KB |
| **BuilderFull**       | **QuanTAlib.Alma** | **10000** | **2,780.4 μs** |  **82.65 μs** |  **49.19 μs** | **654.41 KB** |
| BuilderLatestOnly | QuanTAlib.Alma | 10000 | 2,869.8 μs | 257.07 μs | 170.04 μs |  184.5 KB |
