```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |---------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetAlma** | **1000**  |   **349.9 μs** |  **14.05 μs** |  **8.36 μs** |  **76.77 KB** |
| BuilderLatestOnly | Skender.GetAlma | 1000  |   304.9 μs |   5.19 μs |  2.71 μs |  29.11 KB |
| **BuilderFull**       | **Skender.GetAlma** | **10000** | **1,518.4 μs** |  **31.65 μs** | **16.55 μs** | **633.65 KB** |
| BuilderLatestOnly | Skender.GetAlma | 10000 | 1,550.2 μs | 148.98 μs | 98.54 μs | 163.77 KB |
