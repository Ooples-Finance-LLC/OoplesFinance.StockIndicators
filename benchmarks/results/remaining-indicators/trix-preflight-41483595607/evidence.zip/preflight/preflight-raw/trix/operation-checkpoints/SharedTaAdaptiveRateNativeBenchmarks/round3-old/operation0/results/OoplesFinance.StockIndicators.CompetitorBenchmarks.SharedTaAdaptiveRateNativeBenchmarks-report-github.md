```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **585.2 μs** |  **5.60 μs** |  **2.93 μs** |       **-** |  **89.26 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   573.7 μs |  5.73 μs |  3.00 μs |       - |   41.6 KB |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **6,014.0 μs** | **39.72 μs** | **20.77 μs** | **31.2500** | **863.22 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 5,848.6 μs | 24.73 μs | 12.93 μs |       - | 393.25 KB |
