```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **301.2 μs** | **11.45 μs** |  **6.81 μs** |       **-** |       **-** |   **89.1 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   297.4 μs |  1.75 μs |  0.91 μs |  1.9531 |       - |   41.5 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **3,084.3 μs** | **10.86 μs** |  **7.18 μs** | **46.8750** | **15.6250** | **863.02 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 3,059.7 μs | 20.17 μs | 13.34 μs | 15.6250 |       - | 393.18 KB |
