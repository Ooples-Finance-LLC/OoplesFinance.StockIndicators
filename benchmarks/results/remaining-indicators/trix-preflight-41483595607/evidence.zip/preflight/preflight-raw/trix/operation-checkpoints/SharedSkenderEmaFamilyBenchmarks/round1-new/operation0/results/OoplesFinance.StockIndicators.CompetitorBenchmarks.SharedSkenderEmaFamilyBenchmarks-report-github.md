```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **303.4 μs** |  **2.81 μs** |  **1.67 μs** |       **-** |       **-** |   **89.1 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   301.3 μs |  3.94 μs |  2.61 μs |  1.9531 |       - |   41.5 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **3,092.2 μs** |  **8.76 μs** |  **5.21 μs** | **46.8750** | **15.6250** | **863.02 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 3,084.0 μs | 26.79 μs | 15.94 μs | 15.6250 |       - | 393.18 KB |
