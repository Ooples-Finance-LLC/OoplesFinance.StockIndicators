```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **291.4 μs** |  **1.13 μs** |  **0.67 μs** |       **-** |       **-** |  **89.07 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   297.6 μs |  1.97 μs |  1.03 μs |  1.9531 |       - |   41.5 KB |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **3,029.5 μs** | **13.02 μs** |  **7.75 μs** | **46.8750** | **15.6250** | **862.99 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 3,380.0 μs | 28.86 μs | 19.09 μs |       - |       - |  393.3 KB |
