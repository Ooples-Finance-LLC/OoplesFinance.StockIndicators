```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **533.2 μs** |  **4.97 μs** |  **2.96 μs** |       **-** |  **89.26 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   525.1 μs | 18.38 μs | 12.16 μs |       - |   41.6 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **5,260.1 μs** | **56.54 μs** | **33.65 μs** | **31.2500** | **863.22 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 5,216.2 μs | 63.89 μs | 42.26 μs |       - |  393.3 KB |
