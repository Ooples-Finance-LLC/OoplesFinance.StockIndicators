```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetMfi** |   **156.2 μs** |  **5.96 μs** |  **3.12 μs** |  **1.00** |    **0.03** |  **105.64 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetMfi |   118.2 μs |  9.34 μs |  5.56 μs |  0.76 |    0.04 |  186.63 KB |        1.77 |
|            |       |                |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetMfi** |   **822.4 μs** | **25.20 μs** | **14.99 μs** |  **1.00** |    **0.02** | **1036.61 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetMfi | 1,209.0 μs | 13.54 μs |  7.08 μs |  1.47 |    0.03 | 1814.57 KB |        1.75 |
