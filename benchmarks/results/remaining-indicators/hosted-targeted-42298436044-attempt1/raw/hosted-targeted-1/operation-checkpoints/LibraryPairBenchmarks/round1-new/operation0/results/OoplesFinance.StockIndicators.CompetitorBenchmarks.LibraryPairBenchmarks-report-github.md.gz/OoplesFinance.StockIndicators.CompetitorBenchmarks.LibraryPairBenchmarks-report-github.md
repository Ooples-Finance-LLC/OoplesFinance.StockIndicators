```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId         | Mean     | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------- |---------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetMfi** | **100.5 μs** |  **6.90 μs** |  **4.11 μs** |  **1.00** |    **0.05** |  **105.64 KB** |        **1.00** |
|        |       |                |          |          |          |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetMfi** | **818.0 μs** | **21.65 μs** | **11.32 μs** |  **1.00** |    **0.02** | **1036.33 KB** |        **1.00** |
