```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId         | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetMfi** |   **116.0 μs** |   **5.66 μs** |   **2.96 μs** |  **1.00** |    **0.03** |  **105.57 KB** |        **1.00** |
|        |       |                |            |           |           |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetMfi** | **1,045.2 μs** | **262.29 μs** | **173.49 μs** |  **1.03** |    **0.24** | **1036.58 KB** |        **1.00** |
