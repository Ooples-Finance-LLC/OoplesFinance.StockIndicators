```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetMfi** | **1000**  |  **97.19 μs** |  **4.520 μs** |  **2.990 μs** |  **1.76** |    **0.08** |  **3.9063** |       **-** |   **65.08 KB** |        **0.42** |
| BuilderLatestOnly | Skender.GetMfi | 1000  |  92.89 μs |  1.035 μs |  0.541 μs |  1.69 |    0.06 |  0.9766 |       - |   17.48 KB |        0.11 |
| NativeSingle      | Skender.GetMfi | 1000  |  55.17 μs |  2.992 μs |  1.979 μs |  1.00 |    0.05 |  9.2773 |  1.9531 |  156.75 KB |        1.00 |
| NativeParallel    | Skender.GetMfi | 1000  | 109.74 μs |  4.041 μs |  2.673 μs |  1.99 |    0.08 |  9.7656 |  1.9531 |  165.09 KB |        1.05 |
|                   |                |       |           |           |           |       |         |         |         |            |             |
| **BuilderFull**       | **Skender.GetMfi** | **10000** | **258.14 μs** | **21.393 μs** | **14.150 μs** |  **0.43** |    **0.02** | **37.1094** | **13.6719** |  **627.95 KB** |        **0.40** |
| BuilderLatestOnly | Skender.GetMfi | 10000 | 243.39 μs | 22.989 μs | 15.206 μs |  0.40 |    0.02 |  7.8125 |  1.9531 |  158.11 KB |        0.10 |
| NativeSingle      | Skender.GetMfi | 10000 | 605.50 μs | 16.778 μs | 11.098 μs |  1.00 |    0.02 | 93.7500 | 46.8750 | 1563.03 KB |        1.00 |
| NativeParallel    | Skender.GetMfi | 10000 | 474.26 μs | 40.762 μs | 26.961 μs |  0.78 |    0.04 | 97.6563 | 46.8750 | 1571.37 KB |        1.01 |
