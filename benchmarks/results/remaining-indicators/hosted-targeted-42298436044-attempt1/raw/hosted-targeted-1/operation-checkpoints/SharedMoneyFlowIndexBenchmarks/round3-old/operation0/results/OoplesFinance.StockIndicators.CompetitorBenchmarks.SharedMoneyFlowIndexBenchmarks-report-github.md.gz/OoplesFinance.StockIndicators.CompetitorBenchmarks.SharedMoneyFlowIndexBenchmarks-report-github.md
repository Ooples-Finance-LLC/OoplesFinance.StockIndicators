```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetMfi** | **1000**  |  **99.10 μs** |  **7.819 μs** |  **5.171 μs** |  **3.9063** |       **-** |  **65.08 KB** |
| BuilderLatestOnly | Skender.GetMfi | 1000  |  93.92 μs |  3.508 μs |  2.321 μs |  0.9766 |       - |  17.48 KB |
| **BuilderFull**       | **Skender.GetMfi** | **10000** | **254.88 μs** | **16.964 μs** | **11.220 μs** | **37.1094** | **13.6719** | **627.95 KB** |
| BuilderLatestOnly | Skender.GetMfi | 10000 | 240.22 μs | 21.302 μs | 14.090 μs |  7.8125 |  1.9531 | 158.12 KB |
