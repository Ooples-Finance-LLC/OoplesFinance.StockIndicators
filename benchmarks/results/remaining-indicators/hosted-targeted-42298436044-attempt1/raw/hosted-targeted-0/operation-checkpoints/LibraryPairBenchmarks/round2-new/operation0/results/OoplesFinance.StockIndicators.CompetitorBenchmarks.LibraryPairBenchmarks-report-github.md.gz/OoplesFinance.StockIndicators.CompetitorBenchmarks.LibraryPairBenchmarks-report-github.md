```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Mfi** |   **162.26 μs** | **10.206 μs** |  **5.338 μs** |  **1.00** |    **0.04** |   **105.6 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Mfi |    21.24 μs |  0.568 μs |  0.297 μs |  0.13 |    0.00 |   40.61 KB |        0.38 |
|            |       |                     |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Mfi** | **1,068.37 μs** | **81.690 μs** | **48.612 μs** |  **1.00** |    **0.06** | **1036.61 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Mfi |   191.33 μs |  3.355 μs |  1.996 μs |  0.18 |    0.01 |   330.6 KB |        0.32 |
