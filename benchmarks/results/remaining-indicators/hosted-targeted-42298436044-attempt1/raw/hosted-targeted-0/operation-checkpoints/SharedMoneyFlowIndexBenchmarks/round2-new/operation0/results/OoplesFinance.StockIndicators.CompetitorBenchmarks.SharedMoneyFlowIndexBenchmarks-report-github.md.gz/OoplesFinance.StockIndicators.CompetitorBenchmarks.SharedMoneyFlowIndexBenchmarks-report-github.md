```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |-----------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Mfi** | **1000**  | **115.124 μs** | **10.9761 μs** |  **7.2600 μs** | **12.09** |    **0.75** |  **3.9063** |       **-** |  **65.08 KB** |        **8.13** |
| BuilderLatestOnly | TaLib.Functions.Mfi | 1000  | 109.261 μs |  3.5436 μs |  2.1087 μs | 11.48 |    0.26 |  0.9766 |       - |  17.48 KB |        2.18 |
| NativeSingle      | TaLib.Functions.Mfi | 1000  |   9.520 μs |  0.2301 μs |  0.1369 μs |  1.00 |    0.02 |  0.4883 |       - |   8.01 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mfi | 1000  |  94.961 μs |  3.6908 μs |  2.4413 μs |  9.98 |    0.28 |  0.4883 |       - |   9.03 KB |        1.13 |
|                   |                     |       |            |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Mfi** | **10000** | **319.088 μs** | **23.2225 μs** | **15.3603 μs** |  **3.44** |    **0.18** | **37.1094** | **13.6719** | **627.95 KB** |        **8.02** |
| BuilderLatestOnly | TaLib.Functions.Mfi | 10000 | 295.386 μs | 24.5850 μs | 16.2615 μs |  3.18 |    0.19 |  7.8125 |  1.9531 | 158.12 KB |        2.02 |
| NativeSingle      | TaLib.Functions.Mfi | 10000 |  92.917 μs |  4.1124 μs |  2.7201 μs |  1.00 |    0.04 |  4.3945 |  0.4883 |  78.32 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mfi | 10000 | 133.536 μs |  2.5324 μs |  1.5070 μs |  1.44 |    0.04 |  3.9063 |       - |  79.34 KB |        1.01 |
