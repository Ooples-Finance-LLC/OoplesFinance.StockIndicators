```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |-------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mfi** | **1000**  | **116.7 μs** |  **6.23 μs** |  **3.26 μs** |  **3.9063** |       **-** |  **65.12 KB** |
| BuilderLatestOnly | TaLib.Functions.Mfi | 1000  | 108.3 μs |  1.75 μs |  0.92 μs |  0.9766 |       - |  17.48 KB |
| **BuilderFull**       | **TaLib.Functions.Mfi** | **10000** | **324.1 μs** | **29.12 μs** | **19.26 μs** | **37.1094** | **13.6719** | **627.95 KB** |
| BuilderLatestOnly | TaLib.Functions.Mfi | 10000 | 304.0 μs | 29.76 μs | 19.68 μs |  7.8125 |  1.9531 | 158.12 KB |
