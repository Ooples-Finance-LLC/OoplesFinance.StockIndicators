```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Candles.Harami** | **1000**  | **123.7 μs** | **10.60 μs** |  **6.31 μs** |  **3.9063** |       **-** |  **63.73 KB** |
| BuilderLatestOnly | TaLib.Candles.Harami | 1000  | 116.1 μs |  5.71 μs |  3.40 μs |  0.9766 |       - |  15.81 KB |
| **BuilderFull**       | **TaLib.Candles.Harami** | **10000** | **390.4 μs** | **27.99 μs** | **18.52 μs** | **33.2031** | **13.6719** | **556.24 KB** |
| BuilderLatestOnly | TaLib.Candles.Harami | 10000 | 371.1 μs | 28.48 μs | 16.95 μs |  3.9063 |       - |  86.15 KB |
