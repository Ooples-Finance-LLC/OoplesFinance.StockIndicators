```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Candles.Harami** | **1000**  | **122.5 μs** |  **6.64 μs** |  **3.95 μs** |  **3.9063** |       **-** |  **63.69 KB** |
| BuilderLatestOnly | TaLib.Candles.Harami | 1000  | 115.3 μs |  1.61 μs |  0.84 μs |  0.9766 |       - |  15.81 KB |
| **BuilderFull**       | **TaLib.Candles.Harami** | **10000** | **399.2 μs** | **29.76 μs** | **19.69 μs** | **33.2031** | **13.6719** | **556.24 KB** |
| BuilderLatestOnly | TaLib.Candles.Harami | 10000 | 374.0 μs |  6.24 μs |  3.26 μs |  3.9063 |       - |  86.15 KB |
