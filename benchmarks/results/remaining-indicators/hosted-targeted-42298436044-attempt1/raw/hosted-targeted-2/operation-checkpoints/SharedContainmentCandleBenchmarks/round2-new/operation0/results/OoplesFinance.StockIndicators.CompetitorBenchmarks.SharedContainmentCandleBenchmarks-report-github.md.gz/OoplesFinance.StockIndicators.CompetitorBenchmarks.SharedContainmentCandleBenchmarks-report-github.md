```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib.Candles.Harami** | **1000**  |  **43.95 μs** |  **0.147 μs** |  **0.087 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Harami | 1000  | 108.89 μs |  3.373 μs |  2.231 μs |  2.48 |    0.05 |       - |       - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib.Candles.Harami | 1000  | 121.18 μs |  2.635 μs |  1.378 μs |  2.76 |    0.03 |  3.9063 |       - |   63.7 KB |       16.05 |
| BuilderLatestOnly | TaLib.Candles.Harami | 1000  | 115.58 μs |  2.191 μs |  1.146 μs |  2.63 |    0.03 |  0.9766 |       - |  15.81 KB |        3.98 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib.Candles.Harami** | **10000** | **446.72 μs** |  **1.669 μs** |  **0.993 μs** |  **1.00** |    **0.00** |       **-** |       **-** |  **39.16 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Harami | 10000 | 329.14 μs | 21.086 μs | 13.947 μs |  0.74 |    0.03 |  5.8594 |       - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib.Candles.Harami | 10000 | 407.10 μs | 24.426 μs | 14.535 μs |  0.91 |    0.03 | 31.2500 | 11.7188 | 556.26 KB |       14.21 |
| BuilderLatestOnly | TaLib.Candles.Harami | 10000 | 366.72 μs |  8.685 μs |  5.168 μs |  0.82 |    0.01 |  3.9063 |       - |  86.15 KB |        2.20 |
