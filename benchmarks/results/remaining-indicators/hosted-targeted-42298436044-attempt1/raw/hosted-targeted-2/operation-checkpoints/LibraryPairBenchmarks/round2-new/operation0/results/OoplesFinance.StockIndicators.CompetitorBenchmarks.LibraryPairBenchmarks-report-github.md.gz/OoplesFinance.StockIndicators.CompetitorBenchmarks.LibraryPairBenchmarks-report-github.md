```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Candles.Harami** | **377.60 μs** | **29.401 μs** | **19.447 μs** |  **1.00** |    **0.07** |  **68.38 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Candles.Harami |  65.79 μs | 13.540 μs |  8.956 μs |  0.17 |    0.02 |  19.25 KB |        0.28 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Candles.Harami** | **371.62 μs** | **23.845 μs** | **14.190 μs** |  **1.00** |    **0.05** |    **639 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Candles.Harami | 603.52 μs |  3.627 μs |  1.897 μs |  1.63 |    0.06 | 125.09 KB |        0.20 |
