```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)ubozu [29]** | **110.22 μs** |  **1.507 μs** |  **0.897 μs** |  **1.00** |    **0.01** |  **66.15 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)ubozu [29] |  61.32 μs |  9.071 μs |  6.000 μs |  0.56 |    0.05 |  17.94 KB |        0.27 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)ubozu [29]** | **361.33 μs** | **29.929 μs** | **17.810 μs** |  **1.00** |    **0.06** | **637.48 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)ubozu [29] | 607.67 μs | 21.899 μs | 14.485 μs |  1.69 |    0.08 | 121.48 KB |        0.19 |
