```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **ClosingMarubozu** | **1000**  |  **82.73 μs** | **15.030 μs** |  **7.861 μs** |  **1.91** |    **0.17** |       **-** |      **-** |  **58.06 KB** |       **14.77** |
| BuilderLatestOnly | ClosingMarubozu | 1000  |  56.20 μs |  0.210 μs |  0.110 μs |  1.30 |    0.03 |  0.4883 |      - |  10.17 KB |        2.59 |
| NativeSingle      | ClosingMarubozu | 1000  |  43.37 μs |  1.403 μs |  0.928 μs |  1.00 |    0.03 |       - |      - |   3.93 KB |        1.00 |
| NativeParallel    | ClosingMarubozu | 1000  |  96.59 μs |  1.045 μs |  0.547 μs |  2.23 |    0.05 |       - |      - |   4.23 KB |        1.08 |
|                   |                 |       |           |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **ClosingMarubozu** | **10000** | **383.94 μs** | **21.173 μs** | **12.600 μs** |  **0.93** |    **0.03** | **31.2500** | **7.8125** | **555.22 KB** |       **14.20** |
| BuilderLatestOnly | ClosingMarubozu | 10000 | 386.77 μs | 19.829 μs | 13.116 μs |  0.94 |    0.03 |  3.9063 |      - |  85.11 KB |        2.18 |
| NativeSingle      | ClosingMarubozu | 10000 | 413.15 μs |  1.811 μs |  0.947 μs |  1.00 |    0.00 |       - |      - |  39.11 KB |        1.00 |
| NativeParallel    | ClosingMarubozu | 10000 | 290.06 μs |  5.775 μs |  3.021 μs |  0.70 |    0.01 |  1.9531 |      - |  39.39 KB |        1.01 |
