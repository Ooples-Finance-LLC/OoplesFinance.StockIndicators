```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **ClosingMarubozu** | **1000**  |  **66.93 μs** |  **0.696 μs** |  **0.364 μs** |       **-** |       **-** |  **58.28 KB** |
| BuilderLatestOnly | ClosingMarubozu | 1000  |  65.02 μs |  0.364 μs |  0.191 μs |  0.4883 |       - |  10.39 KB |
| **BuilderFull**       | **ClosingMarubozu** | **10000** | **425.87 μs** | **19.574 μs** | **11.648 μs** | **31.2500** | **11.7188** |  **556.1 KB** |
| BuilderLatestOnly | ClosingMarubozu | 10000 | 404.13 μs |  9.613 μs |  5.028 μs |  3.9063 |       - |     86 KB |
