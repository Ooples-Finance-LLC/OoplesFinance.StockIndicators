```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **ClosingMarubozu** | **1000**  |  **65.44 μs** |  **0.239 μs** | **0.142 μs** |       **-** |       **-** |  **58.28 KB** |
| BuilderLatestOnly | ClosingMarubozu | 1000  |  65.40 μs |  0.265 μs | 0.138 μs |  0.4883 |       - |  10.39 KB |
| **BuilderFull**       | **ClosingMarubozu** | **10000** | **416.49 μs** | **11.088 μs** | **5.799 μs** | **31.2500** | **11.7188** |  **556.1 KB** |
| BuilderLatestOnly | ClosingMarubozu | 10000 | 409.84 μs |  9.853 μs | 5.153 μs |  3.9063 |       - |     86 KB |
