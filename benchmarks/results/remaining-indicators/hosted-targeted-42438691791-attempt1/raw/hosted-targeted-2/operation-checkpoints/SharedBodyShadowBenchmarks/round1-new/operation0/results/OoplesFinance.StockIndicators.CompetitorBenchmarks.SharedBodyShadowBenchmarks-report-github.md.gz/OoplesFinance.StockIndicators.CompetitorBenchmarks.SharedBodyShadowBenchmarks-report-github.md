```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |---------------- |------ |----------:|----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **ClosingMarubozu** | **1000**  |  **57.77 μs** |  **0.561 μs** |  **0.334 μs** |       **-** |      **-** |  **58.02 KB** |
| BuilderLatestOnly | ClosingMarubozu | 1000  |  57.71 μs |  0.304 μs |  0.159 μs |  0.4883 |      - |  10.17 KB |
| **BuilderFull**       | **ClosingMarubozu** | **10000** | **395.05 μs** | **35.608 μs** | **23.552 μs** | **33.2031** | **9.7656** | **555.17 KB** |
| BuilderLatestOnly | ClosingMarubozu | 10000 | 370.48 μs | 14.684 μs |  7.680 μs |  3.9063 |      - |  85.13 KB |
