```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib.Candles.Harami** | **1000**  |  **22.65 μs** |  **0.990 μs** |  **0.589 μs** |  **1.00** |    **0.03** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Harami | 1000  |  75.56 μs |  3.071 μs |  2.032 μs |  3.34 |    0.12 |  0.4883 |       - |    8.4 KB |        2.12 |
| BuilderFull       | TaLib.Candles.Harami | 1000  |  80.78 μs |  2.153 μs |  1.424 μs |  3.57 |    0.10 |  3.9063 |  0.4883 |  63.69 KB |       16.05 |
| BuilderLatestOnly | TaLib.Candles.Harami | 1000  |  78.84 μs |  2.403 μs |  1.430 μs |  3.48 |    0.10 |  0.9766 |       - |  15.81 KB |        3.98 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib.Candles.Harami** | **10000** | **227.82 μs** |  **4.483 μs** |  **2.345 μs** |  **1.00** |    **0.01** |  **1.9531** |       **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Harami | 10000 | 198.13 μs | 11.399 μs |  5.962 μs |  0.87 |    0.03 |  5.8594 |       - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib.Candles.Harami | 10000 | 236.41 μs | 24.069 μs | 14.323 μs |  1.04 |    0.06 | 33.2031 | 13.6719 | 556.24 KB |       14.21 |
| BuilderLatestOnly | TaLib.Candles.Harami | 10000 | 229.40 μs |  7.012 μs |  3.668 μs |  1.01 |    0.02 |  3.9063 |       - |  86.14 KB |        2.20 |
