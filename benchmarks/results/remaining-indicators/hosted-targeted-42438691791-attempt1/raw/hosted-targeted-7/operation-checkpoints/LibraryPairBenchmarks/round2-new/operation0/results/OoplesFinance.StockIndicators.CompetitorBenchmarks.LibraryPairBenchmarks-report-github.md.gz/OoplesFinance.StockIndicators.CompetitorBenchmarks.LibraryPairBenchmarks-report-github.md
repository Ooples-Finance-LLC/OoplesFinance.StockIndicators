```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=20000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Candles.Harami** |  **27.71 μs** |  **1.307 μs** | **0.683 μs** |  **1.00** |    **0.03** |   **68.3 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Candles.Harami |  33.57 μs |  0.897 μs | 0.534 μs |  1.21 |    0.03 |  12.08 KB |        0.18 |
|            |       |                      |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Candles.Harami** | **199.27 μs** |  **2.828 μs** | **1.683 μs** |  **1.00** |    **0.01** | **632.45 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Candles.Harami | 344.28 μs | 11.936 μs | 7.895 μs |  1.73 |    0.04 | 117.55 KB |        0.19 |
