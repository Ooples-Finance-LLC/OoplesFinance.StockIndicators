```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)ngTop [25]** |  **66.04 μs** | **9.123 μs** | **4.771 μs** |  **1.00** |    **0.09** |  **66.15 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)ngTop [25] |  26.74 μs | 0.249 μs | 0.130 μs |  0.41 |    0.02 |  19.25 KB |        0.29 |
|            |       |                      |           |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)ngTop [25]** | **241.83 μs** | **9.483 μs** | **5.643 μs** |  **1.00** |    **0.03** |  **636.5 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)ngTop [25] | 270.44 μs | 4.240 μs | 2.217 μs |  1.12 |    0.03 | 120.13 KB |        0.19 |
