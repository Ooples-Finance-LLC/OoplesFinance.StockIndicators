```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------------ |------ |----------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **SpinningTop** | **1000**  |  **45.04 μs** |  **9.396 μs** |  **6.215 μs** |  **3.06** |    **0.41** |  **1.9531** |      **-** |  **58.03 KB** |       **14.77** |
| BuilderLatestOnly | SpinningTop | 1000  |  34.96 μs |  1.179 μs |  0.780 μs |  2.37 |    0.07 |  0.4883 |      - |  10.17 KB |        2.59 |
| NativeSingle      | SpinningTop | 1000  |  14.74 μs |  0.571 μs |  0.340 μs |  1.00 |    0.03 |  0.1221 |      - |   3.93 KB |        1.00 |
| NativeParallel    | SpinningTop | 1000  |  70.21 μs |  0.923 μs |  0.611 μs |  4.76 |    0.11 |       - |      - |   4.22 KB |        1.07 |
|                   |             |       |           |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **SpinningTop** | **10000** | **248.78 μs** | **10.038 μs** |  **5.974 μs** |  **1.61** |    **0.06** | **33.2031** | **9.7656** | **555.18 KB** |       **14.20** |
| BuilderLatestOnly | SpinningTop | 10000 | 246.87 μs | 17.083 μs | 11.299 μs |  1.60 |    0.08 |  3.9063 |      - |  85.11 KB |        2.18 |
| NativeSingle      | SpinningTop | 10000 | 154.73 μs |  7.085 μs |  4.686 μs |  1.00 |    0.04 |  1.9531 |      - |  39.09 KB |        1.00 |
| NativeParallel    | SpinningTop | 10000 | 169.04 μs |  7.629 μs |  5.046 μs |  1.09 |    0.04 |  1.9531 |      - |  39.38 KB |        1.01 |
