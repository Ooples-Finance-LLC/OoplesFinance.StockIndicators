```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean      | Error     | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |------------ |------ |----------:|----------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **SpinningTop** | **1000**  |  **45.78 μs** |  **1.074 μs** | **0.639 μs** |  **1.9531** |      **-** |  **58.06 KB** |
| BuilderLatestOnly | SpinningTop | 1000  |  35.24 μs |  1.222 μs | 0.727 μs |  0.4883 |      - |  10.17 KB |
| **BuilderFull**       | **SpinningTop** | **10000** | **244.58 μs** |  **8.482 μs** | **4.436 μs** | **33.2031** | **9.7656** | **555.21 KB** |
| BuilderLatestOnly | SpinningTop | 10000 | 241.65 μs | 10.830 μs | 6.445 μs |  3.9063 |      - |  85.11 KB |
