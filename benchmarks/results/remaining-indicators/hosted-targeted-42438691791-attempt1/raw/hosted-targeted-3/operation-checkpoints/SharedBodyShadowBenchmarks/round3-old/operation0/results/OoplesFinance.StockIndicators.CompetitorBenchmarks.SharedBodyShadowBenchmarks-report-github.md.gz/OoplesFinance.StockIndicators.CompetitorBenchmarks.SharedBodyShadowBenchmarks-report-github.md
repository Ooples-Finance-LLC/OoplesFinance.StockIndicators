```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------ |------ |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **SpinningTop** | **1000**  |  **42.26 μs** |  **0.697 μs** | **0.415 μs** |  **3.4180** |  **0.4883** |  **58.27 KB** |
| BuilderLatestOnly | SpinningTop | 1000  |  41.40 μs |  1.005 μs | 0.526 μs |  0.4883 |       - |  10.39 KB |
| **BuilderFull**       | **SpinningTop** | **10000** | **278.55 μs** | **11.150 μs** | **6.635 μs** | **33.2031** | **13.6719** | **556.08 KB** |
| BuilderLatestOnly | SpinningTop | 10000 | 270.04 μs | 10.563 μs | 6.987 μs |  3.9063 |       - |  85.98 KB |
