```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon 6973P-C 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |----------:|----------:|----------:|------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **LongLine**  | **1000**  |  **72.36 μs** |  **4.696 μs** |  **2.795 μs** |  **2.11** |    **0.11** |      **-** |  **58.06 KB** |       **14.77** |
| BuilderLatestOnly | LongLine  | 1000  |  49.36 μs |  0.533 μs |  0.317 μs |  1.44 |    0.06 |      - |  10.18 KB |        2.59 |
| NativeSingle      | LongLine  | 1000  |  34.32 μs |  2.225 μs |  1.324 μs |  1.00 |    0.05 |      - |   3.93 KB |        1.00 |
| NativeParallel    | LongLine  | 1000  |  97.37 μs |  1.836 μs |  1.092 μs |  2.84 |    0.11 |      - |   4.23 KB |        1.08 |
|                   |           |       |           |           |           |       |         |        |           |             |
| **BuilderFull**       | **LongLine**  | **10000** | **430.12 μs** | **42.700 μs** | **28.244 μs** |  **1.32** |    **0.08** | **3.9063** | **555.21 KB** |       **14.20** |
| BuilderLatestOnly | LongLine  | 10000 | 350.34 μs | 19.020 μs | 12.580 μs |  1.08 |    0.04 |      - |  85.11 KB |        2.18 |
| NativeSingle      | LongLine  | 10000 | 324.78 μs |  1.998 μs |  1.322 μs |  1.00 |    0.01 |      - |  39.09 KB |        1.00 |
| NativeParallel    | LongLine  | 10000 | 279.44 μs | 32.621 μs | 21.577 μs |  0.86 |    0.06 |      - |  39.39 KB |        1.01 |
