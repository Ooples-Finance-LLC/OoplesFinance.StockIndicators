```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon 6973P-C 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **LongLine**  | **1000**  |  **87.67 μs** | **11.854 μs** |  **7.841 μs** | **0.4883** |  **58.27 KB** |
| BuilderLatestOnly | LongLine  | 1000  |  74.23 μs |  4.223 μs |  2.793 μs |      - |  10.39 KB |
| **BuilderFull**       | **LongLine**  | **10000** | **569.37 μs** | **19.112 μs** |  **9.996 μs** |      **-** | **556.12 KB** |
| BuilderLatestOnly | LongLine  | 10000 | 483.48 μs | 45.685 μs | 30.218 μs |      - |     86 KB |
