```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon 6973P-C 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **LongLine**  | **1000**  |  **55.03 μs** |  **0.832 μs** |  **0.495 μs** | **0.4883** |  **58.05 KB** |
| BuilderLatestOnly | LongLine  | 1000  |  51.58 μs |  1.531 μs |  1.013 μs |      - |  10.18 KB |
| **BuilderFull**       | **LongLine**  | **10000** | **445.54 μs** | **51.688 μs** | **30.759 μs** | **3.9063** | **555.21 KB** |
| BuilderLatestOnly | LongLine  | 10000 | 361.00 μs | 23.966 μs | 15.852 μs |      - |  85.11 KB |
