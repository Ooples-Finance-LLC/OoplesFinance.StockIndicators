```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon 6973P-C 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **LongLine**  | **1000**  |  **78.67 μs** |  **3.004 μs** |  **1.788 μs** |      **-** |  **58.27 KB** |
| BuilderLatestOnly | LongLine  | 1000  |  76.02 μs |  3.517 μs |  2.327 μs |      - |   10.4 KB |
| **BuilderFull**       | **LongLine**  | **10000** | **545.12 μs** | **44.581 μs** | **26.530 μs** | **3.9063** | **556.09 KB** |
| BuilderLatestOnly | LongLine  | 10000 | 440.81 μs |  6.284 μs |  3.286 μs |      - |     86 KB |
