```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon 6973P-C 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean      | Error    | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |----------:|---------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)gLine [22]** |  **96.01 μs** | **14.38 μs** |  **8.556 μs** |  **1.01** |    **0.12** |  **66.14 KB** |        **1.00** |
|        |       |                      |           |          |           |       |         |           |             |
| **Ooples** | **10000** | **TaLib(...)gLine [22]** | **373.10 μs** | **29.41 μs** | **17.500 μs** |  **1.00** |    **0.06** | **637.84 KB** |        **1.00** |
