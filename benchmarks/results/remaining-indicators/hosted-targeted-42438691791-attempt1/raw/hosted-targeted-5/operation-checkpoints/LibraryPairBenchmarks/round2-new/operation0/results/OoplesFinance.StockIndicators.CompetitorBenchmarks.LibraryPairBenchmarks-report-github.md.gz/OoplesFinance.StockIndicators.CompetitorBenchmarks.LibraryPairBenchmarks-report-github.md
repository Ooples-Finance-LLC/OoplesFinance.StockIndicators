```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon 6973P-C 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)gLine [22]** |  **91.12 μs** | **13.761 μs** |  **8.189 μs** |  **1.01** |    **0.12** |  **66.11 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)gLine [22] |  61.08 μs |  0.587 μs |  0.349 μs |  0.67 |    0.05 |  15.64 KB |        0.24 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)gLine [22]** | **371.66 μs** | **17.113 μs** | **10.184 μs** |  **1.00** |    **0.04** | **638.47 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)gLine [22] | 600.68 μs | 24.834 μs | 16.426 μs |  1.62 |    0.06 | 125.38 KB |        0.20 |
