```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **BeltHold**  | **1000**  |  **89.30 μs** |  **0.611 μs** |  **0.320 μs** |       **-** |       **-** |  **58.28 KB** |
| BuilderLatestOnly | BeltHold  | 1000  |  91.16 μs |  0.664 μs |  0.439 μs |       - |       - |   10.4 KB |
| **BuilderFull**       | **BeltHold**  | **10000** | **560.80 μs** | **55.281 μs** | **36.565 μs** | **31.2500** | **11.7188** |  **556.1 KB** |
| BuilderLatestOnly | BeltHold  | 10000 | 545.23 μs | 51.826 μs | 30.841 μs |  3.9063 |       - |     86 KB |
