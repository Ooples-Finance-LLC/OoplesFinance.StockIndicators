```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **BeltHold**  | **1000**  |  **78.88 μs** |  **0.329 μs** |  **0.196 μs** |       **-** |      **-** |  **58.06 KB** |
| BuilderLatestOnly | BeltHold  | 1000  |  76.07 μs |  0.534 μs |  0.318 μs |  0.4883 |      - |  10.18 KB |
| **BuilderFull**       | **BeltHold**  | **10000** | **485.85 μs** |  **4.767 μs** |  **2.493 μs** | **31.2500** | **7.8125** | **555.22 KB** |
| BuilderLatestOnly | BeltHold  | 10000 | 489.38 μs | 54.098 μs | 35.782 μs |  3.9063 |      - |  85.12 KB |
