```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |----------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **BeltHold**  | **1000**  | **104.76 μs** |  **1.173 μs** |  **0.698 μs** |  **2.17** |    **0.01** |       **-** |      **-** |  **58.06 KB** |       **14.76** |
| BuilderLatestOnly | BeltHold  | 1000  |  75.82 μs |  0.442 μs |  0.292 μs |  1.57 |    0.01 |  0.4883 |      - |  10.18 KB |        2.59 |
| NativeSingle      | BeltHold  | 1000  |  48.37 μs |  0.227 μs |  0.119 μs |  1.00 |    0.00 |       - |      - |   3.93 KB |        1.00 |
| NativeParallel    | BeltHold  | 1000  | 116.43 μs |  5.399 μs |  3.571 μs |  2.41 |    0.07 |       - |      - |   4.23 KB |        1.07 |
|                   |           |       |           |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **BeltHold**  | **10000** | **517.41 μs** | **68.096 μs** | **45.041 μs** |  **1.02** |    **0.08** | **31.2500** | **7.8125** | **555.22 KB** |       **14.19** |
| BuilderLatestOnly | BeltHold  | 10000 | 470.11 μs |  4.898 μs |  2.562 μs |  0.92 |    0.01 |  3.9063 |      - |  85.13 KB |        2.18 |
| NativeSingle      | BeltHold  | 10000 | 508.80 μs |  2.080 μs |  1.238 μs |  1.00 |    0.00 |       - |      - |  39.12 KB |        1.00 |
| NativeParallel    | BeltHold  | 10000 | 359.95 μs | 24.667 μs | 16.316 μs |  0.71 |    0.03 |  1.9531 |      - |  39.39 KB |        1.01 |
