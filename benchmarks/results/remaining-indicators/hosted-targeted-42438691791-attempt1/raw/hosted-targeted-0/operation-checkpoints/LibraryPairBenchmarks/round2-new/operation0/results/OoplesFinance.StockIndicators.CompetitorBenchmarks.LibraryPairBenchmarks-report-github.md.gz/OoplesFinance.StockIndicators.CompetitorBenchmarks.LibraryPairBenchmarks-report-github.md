```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tHold [22]** | **132.38 μs** |   **3.802 μs** |   **1.988 μs** |  **1.00** |    **0.02** |  **66.18 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tHold [22] |  89.62 μs |  10.826 μs |   6.442 μs |  0.68 |    0.05 |  19.25 KB |        0.29 |
|            |       |                      |           |            |            |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)tHold [22]** | **603.20 μs** | **259.481 μs** | **171.630 μs** |  **1.07** |    **0.40** | **638.17 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tHold [22] | 909.29 μs |  32.260 μs |  21.338 μs |  1.61 |    0.40 | 123.73 KB |        0.19 |
