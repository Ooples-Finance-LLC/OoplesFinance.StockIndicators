```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **HighWave**  | **1000**  |  **58.05 μs** |  **0.315 μs** |  **0.187 μs** |       **-** |       **-** |  **58.28 KB** |
| BuilderLatestOnly | HighWave  | 1000  |  55.48 μs |  0.218 μs |  0.130 μs |  0.4883 |       - |  10.39 KB |
| **BuilderFull**       | **HighWave**  | **10000** | **363.32 μs** |  **3.925 μs** |  **2.053 μs** | **31.2500** | **11.7188** |  **556.1 KB** |
| BuilderLatestOnly | HighWave  | 10000 | 361.44 μs | 16.110 μs | 10.656 μs |  3.9063 |       - |  85.99 KB |
