```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |----------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **HighWave**  | **1000**  |  **50.72 μs** |  **0.226 μs** |  **0.135 μs** |  **1.18** |    **0.02** |       **-** |      **-** |  **58.06 KB** |       **14.77** |
| BuilderLatestOnly | HighWave  | 1000  |  48.50 μs |  0.233 μs |  0.122 μs |  1.13 |    0.02 |  0.4883 |      - |  10.17 KB |        2.59 |
| NativeSingle      | HighWave  | 1000  |  42.83 μs |  1.250 μs |  0.827 μs |  1.00 |    0.03 |       - |      - |   3.93 KB |        1.00 |
| NativeParallel    | HighWave  | 1000  |  99.27 μs |  5.308 μs |  3.511 μs |  2.32 |    0.09 |       - |      - |   4.23 KB |        1.08 |
|                   |           |       |           |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **HighWave**  | **10000** | **337.93 μs** | **23.768 μs** | **15.721 μs** |  **0.81** |    **0.04** | **33.2031** | **9.7656** | **555.21 KB** |       **14.20** |
| BuilderLatestOnly | HighWave  | 10000 | 319.11 μs | 17.992 μs | 11.900 μs |  0.76 |    0.03 |  3.9063 |      - |  85.11 KB |        2.18 |
| NativeSingle      | HighWave  | 10000 | 418.47 μs |  1.746 μs |  1.039 μs |  1.00 |    0.00 |       - |      - |  39.11 KB |        1.00 |
| NativeParallel    | HighWave  | 10000 | 299.30 μs | 18.360 μs | 12.144 μs |  0.72 |    0.03 |  1.9531 |      - |  39.39 KB |        1.01 |
