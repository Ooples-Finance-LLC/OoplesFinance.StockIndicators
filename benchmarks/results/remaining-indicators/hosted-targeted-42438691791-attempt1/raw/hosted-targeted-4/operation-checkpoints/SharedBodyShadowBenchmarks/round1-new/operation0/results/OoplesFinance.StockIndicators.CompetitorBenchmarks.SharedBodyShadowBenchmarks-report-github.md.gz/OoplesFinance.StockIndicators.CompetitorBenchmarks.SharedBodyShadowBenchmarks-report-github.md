```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **HighWave**  | **1000**  |  **51.46 μs** |  **0.200 μs** |  **0.105 μs** |       **-** |      **-** |  **58.06 KB** |
| BuilderLatestOnly | HighWave  | 1000  |  48.62 μs |  0.659 μs |  0.392 μs |  0.4883 |      - |  10.17 KB |
| **BuilderFull**       | **HighWave**  | **10000** | **340.13 μs** | **22.026 μs** | **13.107 μs** | **33.2031** | **9.7656** | **555.21 KB** |
| BuilderLatestOnly | HighWave  | 10000 | 321.19 μs |  4.209 μs |  2.201 μs |  3.9063 |      - |  85.13 KB |
