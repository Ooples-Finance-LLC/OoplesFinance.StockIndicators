```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)hWave [22]** |  **95.49 μs** | **11.605 μs** | **6.906 μs** |  **1.00** |    **0.09** |  **66.18 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)hWave [22] |  71.87 μs | 12.134 μs | 8.026 μs |  0.76 |    0.09 |  17.28 KB |        0.26 |
|            |       |                      |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)hWave [22]** | **331.42 μs** | **12.890 μs** | **7.671 μs** |  **1.00** |    **0.03** |  **638.5 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)hWave [22] | 634.55 μs |  7.092 μs | 3.709 μs |  1.92 |    0.04 | 121.77 KB |        0.19 |
