```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |----------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **Marubozu**  | **1000**  |  **77.65 μs** |  **0.139 μs** |  **0.083 μs** |  **1.62** |    **0.00** |       **-** |      **-** |  **58.06 KB** |       **14.76** |
| BuilderLatestOnly | Marubozu  | 1000  |  83.38 μs |  0.291 μs |  0.173 μs |  1.74 |    0.00 |  0.4883 |      - |  10.18 KB |        2.59 |
| NativeSingle      | Marubozu  | 1000  |  48.05 μs |  0.154 μs |  0.092 μs |  1.00 |    0.00 |       - |      - |   3.93 KB |        1.00 |
| NativeParallel    | Marubozu  | 1000  | 114.13 μs |  3.972 μs |  2.364 μs |  2.38 |    0.05 |       - |      - |   4.23 KB |        1.07 |
|                   |           |       |           |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **Marubozu**  | **10000** | **500.02 μs** | **18.858 μs** |  **9.863 μs** |  **1.02** |    **0.02** | **31.2500** | **7.8125** | **555.22 KB** |       **14.19** |
| BuilderLatestOnly | Marubozu  | 10000 | 501.77 μs | 66.647 μs | 44.083 μs |  1.03 |    0.09 |  3.9063 |      - |  85.13 KB |        2.18 |
| NativeSingle      | Marubozu  | 10000 | 488.31 μs |  3.551 μs |  2.349 μs |  1.00 |    0.01 |       - |      - |  39.12 KB |        1.00 |
| NativeParallel    | Marubozu  | 10000 | 347.46 μs | 28.000 μs | 18.520 μs |  0.71 |    0.04 |  1.9531 |      - |  39.39 KB |        1.01 |
