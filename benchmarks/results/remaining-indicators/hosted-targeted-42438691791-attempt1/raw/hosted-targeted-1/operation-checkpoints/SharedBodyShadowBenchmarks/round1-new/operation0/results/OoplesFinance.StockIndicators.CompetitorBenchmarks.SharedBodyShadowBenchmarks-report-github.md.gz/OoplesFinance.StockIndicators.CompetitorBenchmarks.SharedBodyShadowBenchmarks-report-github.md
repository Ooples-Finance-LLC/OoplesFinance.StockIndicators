```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error      | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|-----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Marubozu**  | **1000**  |  **78.87 μs** |   **0.925 μs** |  **0.551 μs** |       **-** |       **-** |  **58.06 KB** |
| BuilderLatestOnly | Marubozu  | 1000  |  77.85 μs |   0.383 μs |  0.200 μs |  0.4883 |       - |  10.17 KB |
| **BuilderFull**       | **Marubozu**  | **10000** | **525.85 μs** |  **37.811 μs** | **25.010 μs** | **31.2500** | **11.7188** | **555.22 KB** |
| BuilderLatestOnly | Marubozu  | 10000 | 622.09 μs | 145.858 μs | 96.476 μs |  3.9063 |       - |  85.13 KB |
