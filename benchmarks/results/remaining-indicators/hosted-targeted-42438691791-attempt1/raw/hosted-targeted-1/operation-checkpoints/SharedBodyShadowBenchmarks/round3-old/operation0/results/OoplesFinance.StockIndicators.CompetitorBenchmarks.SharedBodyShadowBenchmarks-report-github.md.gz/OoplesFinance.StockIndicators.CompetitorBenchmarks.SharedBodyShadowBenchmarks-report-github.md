```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Marubozu**  | **1000**  |  **88.23 μs** |  **0.318 μs** |  **0.166 μs** |       **-** |       **-** |  **58.28 KB** |
| BuilderLatestOnly | Marubozu  | 1000  |  86.76 μs |  1.202 μs |  0.629 μs |  0.4883 |       - |  10.39 KB |
| **BuilderFull**       | **Marubozu**  | **10000** | **578.45 μs** | **51.159 μs** | **33.839 μs** | **31.2500** | **11.7188** |  **556.1 KB** |
| BuilderLatestOnly | Marubozu  | 10000 | 562.28 μs | 45.993 μs | 30.421 μs |  3.9063 |       - |  85.97 KB |
