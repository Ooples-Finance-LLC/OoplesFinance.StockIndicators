```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tLine [23]** | **115.60 μs** |   **3.108 μs** |   **1.849 μs** |  **1.00** |    **0.02** |  **66.18 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tLine [23] |  81.42 μs |   6.898 μs |   4.105 μs |  0.70 |    0.04 |   19.3 KB |        0.29 |
|            |       |                      |           |            |            |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)tLine [23]** | **575.67 μs** | **175.778 μs** | **116.266 μs** |  **1.04** |    **0.31** | **637.52 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tLine [23] | 726.80 μs |  22.048 μs |  14.583 μs |  1.32 |    0.30 | 122.14 KB |        0.19 |
