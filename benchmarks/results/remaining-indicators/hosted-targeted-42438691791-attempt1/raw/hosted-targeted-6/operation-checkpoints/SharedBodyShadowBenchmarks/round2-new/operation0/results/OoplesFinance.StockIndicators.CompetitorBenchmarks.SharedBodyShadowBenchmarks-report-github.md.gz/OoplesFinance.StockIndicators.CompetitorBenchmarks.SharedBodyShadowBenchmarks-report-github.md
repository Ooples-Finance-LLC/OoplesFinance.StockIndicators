```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |----------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **ShortLine** | **1000**  |  **60.57 μs** |  **0.457 μs** |  **0.272 μs** |  **1.41** |    **0.01** |       **-** |      **-** |  **58.06 KB** |       **14.77** |
| BuilderLatestOnly | ShortLine | 1000  |  57.69 μs |  0.251 μs |  0.150 μs |  1.34 |    0.01 |  0.4883 |      - |  10.17 KB |        2.59 |
| NativeSingle      | ShortLine | 1000  |  42.96 μs |  0.322 μs |  0.191 μs |  1.00 |    0.01 |       - |      - |   3.93 KB |        1.00 |
| NativeParallel    | ShortLine | 1000  |  99.92 μs |  3.843 μs |  2.542 μs |  2.33 |    0.06 |       - |      - |   4.22 KB |        1.07 |
|                   |           |       |           |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **ShortLine** | **10000** | **378.48 μs** |  **8.612 μs** |  **4.504 μs** |  **0.87** |    **0.01** | **31.2500** | **7.8125** | **555.22 KB** |       **14.19** |
| BuilderLatestOnly | ShortLine | 10000 | 379.65 μs | 22.632 μs | 14.970 μs |  0.87 |    0.03 |  3.9063 |      - |  85.11 KB |        2.18 |
| NativeSingle      | ShortLine | 10000 | 436.32 μs |  4.435 μs |  2.639 μs |  1.00 |    0.01 |       - |      - |  39.12 KB |        1.00 |
| NativeParallel    | ShortLine | 10000 | 304.63 μs | 15.962 μs |  9.499 μs |  0.70 |    0.02 |  1.9531 |      - |  39.39 KB |        1.01 |
