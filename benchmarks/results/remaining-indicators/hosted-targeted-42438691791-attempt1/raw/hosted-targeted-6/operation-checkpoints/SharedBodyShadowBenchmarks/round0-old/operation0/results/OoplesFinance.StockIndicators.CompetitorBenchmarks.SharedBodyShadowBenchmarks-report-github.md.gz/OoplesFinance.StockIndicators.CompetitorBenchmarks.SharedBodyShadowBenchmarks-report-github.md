```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **ShortLine** | **1000**  |  **80.33 μs** |  **0.327 μs** |  **0.195 μs** |       **-** |       **-** |  **58.28 KB** |
| BuilderLatestOnly | ShortLine | 1000  |  81.08 μs |  2.374 μs |  1.570 μs |  0.4883 |       - |  10.39 KB |
| **BuilderFull**       | **ShortLine** | **10000** | **499.54 μs** | **10.407 μs** |  **5.443 μs** | **31.2500** | **11.7188** |  **556.1 KB** |
| BuilderLatestOnly | ShortLine | 10000 | 523.18 μs | 32.658 μs | 21.601 μs |  3.9063 |       - |     86 KB |
