```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tSine [22]** |   **907.2 μs** |  **21.13 μs** |  **12.57 μs** |  **1.00** |    **0.02** |  **166.46 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tSine [22] |   567.2 μs |  18.55 μs |  12.27 μs |  0.63 |    0.02 |   74.28 KB |        0.45 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)tSine [22]** | **9,404.0 μs** | **241.98 μs** | **160.05 μs** |  **1.00** |    **0.02** | **1598.77 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tSine [22] | 5,955.7 μs |  32.15 μs |  19.13 μs |  0.63 |    0.01 |  653.66 KB |        0.41 |
