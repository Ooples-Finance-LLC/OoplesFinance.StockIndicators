```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **828.6 μs** |   **9.97 μs** |   **5.93 μs** |  **1.53** |    **0.01** |  **84.81 KB** |        **5.39** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   824.0 μs |   7.00 μs |   3.66 μs |  1.52 |    0.01 |  37.27 KB |        2.37 |
| NativeSingle      | TaLib(...)tSine [22] | 1000  |   542.4 μs |   2.15 μs |   1.13 μs |  1.00 |    0.00 |  15.74 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 1000  |   770.0 μs |  17.17 μs |   8.98 μs |  1.42 |    0.02 |  55.96 KB |        3.55 |
|                   |                      |       |            |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **8,568.1 μs** |  **73.56 μs** |  **48.66 μs** |  **1.46** |    **0.01** | **788.89 KB** |        **5.04** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 8,501.1 μs |  28.44 μs |  16.92 μs |  1.45 |    0.01 | 319.09 KB |        2.04 |
| NativeSingle      | TaLib(...)tSine [22] | 10000 | 5,865.7 μs |  38.05 μs |  19.90 μs |  1.00 |    0.00 | 156.58 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 10000 | 8,153.3 μs | 308.84 μs | 204.28 μs |  1.39 |    0.03 | 548.69 KB |        3.50 |
