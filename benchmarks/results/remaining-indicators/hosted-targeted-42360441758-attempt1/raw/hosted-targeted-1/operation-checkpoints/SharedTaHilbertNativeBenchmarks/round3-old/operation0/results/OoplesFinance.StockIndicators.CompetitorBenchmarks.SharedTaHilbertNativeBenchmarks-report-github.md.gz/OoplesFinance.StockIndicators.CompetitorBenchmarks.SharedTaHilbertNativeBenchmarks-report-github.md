```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **1.027 ms** | **0.0149 ms** | **0.0089 ms** |  **84.84 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1.028 ms | 0.0081 ms | 0.0048 ms |  37.27 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **10.676 ms** | **0.0873 ms** | **0.0520 ms** | **789.06 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 10.610 ms | 0.0667 ms | 0.0441 ms | 319.28 KB |
