```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **838.8 μs** |  **1.66 μs** |  **0.87 μs** |  **84.84 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   830.0 μs |  4.70 μs |  2.80 μs |  37.27 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **8,700.5 μs** | **81.18 μs** | **48.31 μs** | **788.92 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 8,586.3 μs | 63.29 μs | 37.66 μs | 319.14 KB |
