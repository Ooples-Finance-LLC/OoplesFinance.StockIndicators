```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dMode [27]** |  **1,443.2 μs** |  **53.25 μs** | **35.22 μs** |  **1.00** |    **0.03** |  **112.73 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dMode [27] |    608.8 μs |  12.70 μs |  7.55 μs |  0.42 |    0.01 |   32.32 KB |        0.29 |
|            |       |                      |             |           |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)dMode [27]** | **14,529.2 μs** | **159.63 μs** | **94.99 μs** |  **1.00** |    **0.01** | **1043.73 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dMode [27] |  6,404.1 μs |  36.15 μs | 21.51 μs |  0.44 |    0.00 |  292.78 KB |        0.28 |
