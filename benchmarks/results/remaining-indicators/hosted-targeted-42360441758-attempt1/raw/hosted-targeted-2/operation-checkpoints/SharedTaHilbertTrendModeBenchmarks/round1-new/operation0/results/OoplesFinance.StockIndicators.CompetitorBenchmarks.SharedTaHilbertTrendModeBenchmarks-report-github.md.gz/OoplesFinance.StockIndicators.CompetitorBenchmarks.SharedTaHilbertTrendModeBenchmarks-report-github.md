```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1.435 ms** | **0.0337 ms** | **0.0223 ms** |   **71.7 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1.423 ms | 0.0109 ms | 0.0065 ms |  24.05 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **14.486 ms** | **0.0554 ms** | **0.0290 ms** | **635.55 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 14.271 ms | 0.0430 ms | 0.0225 ms | 165.59 KB |
