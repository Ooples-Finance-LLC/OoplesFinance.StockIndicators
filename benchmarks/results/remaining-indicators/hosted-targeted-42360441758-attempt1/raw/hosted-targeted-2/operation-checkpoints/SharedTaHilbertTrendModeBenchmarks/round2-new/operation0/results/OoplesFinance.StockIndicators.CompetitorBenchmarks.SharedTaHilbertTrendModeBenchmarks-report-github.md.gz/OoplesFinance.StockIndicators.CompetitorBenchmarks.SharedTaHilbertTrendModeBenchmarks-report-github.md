```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1,442.6 μs** |     **4.21 μs** |     **2.50 μs** |  **2.47** |    **0.01** |   **71.7 KB** |       **15.15** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1,434.5 μs |    31.56 μs |    20.87 μs |  2.46 |    0.03 |  24.05 KB |        5.08 |
| NativeSingle      | TaLib(...)dMode [27] | 1000  |    583.5 μs |     1.77 μs |     1.05 μs |  1.00 |    0.00 |   4.73 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 1000  |    829.4 μs |    23.74 μs |    14.13 μs |  1.42 |    0.02 |  17.43 KB |        3.68 |
|                   |                      |       |             |             |             |       |         |           |             |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **14,666.9 μs** |    **88.10 μs** |    **58.27 μs** |  **2.30** |    **0.01** | **635.63 KB** |       **15.76** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 16,013.3 μs | 1,900.67 μs | 1,257.18 μs |  2.51 |    0.19 | 166.02 KB |        4.12 |
| NativeSingle      | TaLib(...)dMode [27] | 10000 |  6,368.8 μs |    37.61 μs |    22.38 μs |  1.00 |    0.00 |  40.33 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 10000 |  8,911.5 μs |   466.34 μs |   308.46 μs |  1.40 |    0.05 | 141.02 KB |        3.50 |
