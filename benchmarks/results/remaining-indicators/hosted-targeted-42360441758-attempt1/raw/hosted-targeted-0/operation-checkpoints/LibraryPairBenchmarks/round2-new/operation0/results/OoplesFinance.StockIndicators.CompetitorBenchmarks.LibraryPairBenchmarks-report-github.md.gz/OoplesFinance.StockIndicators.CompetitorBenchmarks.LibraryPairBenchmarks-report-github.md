```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Phase [25]** |   **457.6 μs** |  **5.03 μs** |  **2.63 μs** |  **1.00** |  **110.06 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Phase [25] |   350.4 μs |  7.42 μs |  3.88 μs |  0.77 |   34.63 KB |        0.31 |
|            |       |                      |            |          |          |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)Phase [25]** | **4,524.8 μs** | **27.41 μs** | **16.31 μs** |  **1.00** | **1033.24 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Phase [25] | 3,658.1 μs | 17.90 μs | 11.84 μs |  0.81 |  324.02 KB |        0.31 |
