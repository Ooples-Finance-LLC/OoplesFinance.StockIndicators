```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **501.7 μs** | **24.02 μs** | **15.89 μs** |  **3.9063** |  **68.93 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   493.1 μs | 14.27 μs |  8.49 μs |       - |  21.34 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **5,906.3 μs** | **82.57 μs** | **49.14 μs** | **31.2500** | **631.96 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 5,847.3 μs | 35.91 μs | 18.78 μs |       - | 162.12 KB |
