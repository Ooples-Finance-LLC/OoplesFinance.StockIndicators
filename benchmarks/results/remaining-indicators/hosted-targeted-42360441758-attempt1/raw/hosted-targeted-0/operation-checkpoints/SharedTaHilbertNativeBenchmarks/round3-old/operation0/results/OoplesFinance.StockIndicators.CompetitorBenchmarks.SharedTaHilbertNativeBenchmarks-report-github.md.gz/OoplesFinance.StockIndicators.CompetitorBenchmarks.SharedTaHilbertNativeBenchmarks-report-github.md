```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **498.3 μs** |   **5.79 μs** |  **3.03 μs** |  **3.9063** |   **68.9 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   497.5 μs |  10.64 μs |  6.33 μs |       - |  21.34 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **5,997.8 μs** | **139.60 μs** | **92.33 μs** | **31.2500** |  **631.9 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 5,832.8 μs |  41.56 μs | 21.74 μs |       - | 162.15 KB |
