```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **414.6 μs** |   **5.19 μs** |   **3.09 μs** |  **1.20** |    **0.02** |       **-** |  **68.94 KB** |        **8.25** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   413.3 μs |  16.42 μs |  10.86 μs |  1.20 |    0.04 |       - |  21.34 KB |        2.55 |
| NativeSingle      | TaLib(...)Phase [25] | 1000  |   345.0 μs |   8.82 μs |   5.83 μs |  1.00 |    0.02 |       - |   8.36 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 1000  |   518.0 μs |  20.88 μs |  13.81 μs |  1.50 |    0.05 |       - |  30.19 KB |        3.61 |
|                   |                      |       |            |           |           |       |         |         |           |             |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **4,568.8 μs** | **188.57 μs** | **124.73 μs** |  **1.24** |    **0.04** | **31.2500** | **631.92 KB** |        **8.02** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 4,483.2 μs | 172.47 μs | 114.08 μs |  1.22 |    0.04 |       - | 162.12 KB |        2.06 |
| NativeSingle      | TaLib(...)Phase [25] | 10000 | 3,678.6 μs |  99.58 μs |  65.86 μs |  1.00 |    0.02 |       - |  78.79 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 10000 | 5,183.2 μs | 171.14 μs | 101.84 μs |  1.41 |    0.04 |       - | 276.47 KB |        3.51 |
