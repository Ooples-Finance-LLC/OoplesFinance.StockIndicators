```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |------ |------------:|-----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **1000**  |   **325.42 μs** |  **13.623 μs** |  **9.011 μs** |  **3.86** |    **0.11** |        **-** |       **-** |   **57.74 KB** |        **0.27** |
| BuilderLatestOnly | 1000  |   305.38 μs |   4.099 μs |  2.144 μs |  3.63 |    0.03 |        - |       - |    9.85 KB |        0.05 |
| NativeSingle      | 1000  |    84.22 μs |   0.884 μs |  0.585 μs |  1.00 |    0.01 |   8.3008 |       - |  214.78 KB |        1.00 |
| NativeParallel    | 1000  |   157.50 μs |   6.245 μs |  4.130 μs |  1.87 |    0.05 |  20.5078 |       - |  520.94 KB |        2.43 |
|                   |       |             |            |           |       |         |          |         |            |             |
| **BuilderFull**       | **10000** | **3,121.89 μs** | **134.062 μs** | **79.778 μs** |  **3.56** |    **0.09** |        **-** |       **-** |  **550.44 KB** |        **0.25** |
| BuilderLatestOnly | 10000 | 2,882.94 μs |  30.332 μs | 15.864 μs |  3.29 |    0.03 |        - |       - |   80.28 KB |        0.04 |
| NativeSingle      | 10000 |   877.22 μs |  10.608 μs |  7.017 μs |  1.00 |    0.01 |  85.9375 | 15.6250 | 2173.04 KB |        1.00 |
| NativeParallel    | 10000 | 1,346.46 μs |  76.225 μs | 50.418 μs |  1.53 |    0.06 | 210.9375 | 39.0625 | 5311.21 KB |        2.44 |
