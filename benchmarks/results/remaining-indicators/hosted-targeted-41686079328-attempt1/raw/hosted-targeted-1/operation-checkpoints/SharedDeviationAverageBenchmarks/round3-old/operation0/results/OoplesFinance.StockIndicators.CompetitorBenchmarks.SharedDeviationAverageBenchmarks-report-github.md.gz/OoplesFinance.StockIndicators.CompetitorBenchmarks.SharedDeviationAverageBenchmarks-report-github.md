```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **1000**  |   **476.2 μs** |   **7.77 μs** |   **4.63 μs** |  **57.71 KB** |
| BuilderLatestOnly | 1000  |   465.3 μs |   3.63 μs |   1.90 μs |   9.85 KB |
| **BuilderFull**       | **10000** | **4,707.3 μs** | **123.43 μs** |  **81.64 μs** | **550.47 KB** |
| BuilderLatestOnly | 10000 | 4,599.6 μs | 160.05 μs | 105.86 μs |  80.37 KB |
