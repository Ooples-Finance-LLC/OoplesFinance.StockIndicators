```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **1000**  |   **589.0 μs** |  **5.03 μs** |  **2.63 μs** |  **57.78 KB** |
| BuilderLatestOnly | 1000  |   469.1 μs |  5.49 μs |  3.26 μs |   9.85 KB |
| **BuilderFull**       | **10000** | **4,690.8 μs** | **54.91 μs** | **28.72 μs** | **550.47 KB** |
| BuilderLatestOnly | 10000 | 4,583.7 μs | 36.37 μs | 19.02 μs |  80.34 KB |
