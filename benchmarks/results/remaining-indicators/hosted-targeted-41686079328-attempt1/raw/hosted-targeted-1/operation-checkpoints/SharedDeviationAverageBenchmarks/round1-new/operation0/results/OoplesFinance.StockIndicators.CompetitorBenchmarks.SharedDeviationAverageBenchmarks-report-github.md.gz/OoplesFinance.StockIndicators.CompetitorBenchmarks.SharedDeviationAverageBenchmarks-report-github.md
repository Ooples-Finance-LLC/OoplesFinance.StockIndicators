```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **1000**  |   **317.6 μs** |  **4.42 μs** |  **2.31 μs** |  **57.73 KB** |
| BuilderLatestOnly | 1000  |   293.8 μs |  3.52 μs |  1.84 μs |   9.85 KB |
| **BuilderFull**       | **10000** | **2,971.2 μs** | **37.31 μs** | **22.21 μs** | **550.49 KB** |
| BuilderLatestOnly | 10000 | 2,889.0 μs | 20.87 μs | 12.42 μs |  80.28 KB |
