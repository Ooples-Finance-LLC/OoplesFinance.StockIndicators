```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)bands [24]** | **1000**  |   **575.80 μs** | **10.590 μs** |  **7.005 μs** | **43.75** |    **0.58** |  **3.9063** |       **-** |   **99.47 KB** |        **2.54** |
| BuilderLatestOnly | TaLib(...)bands [24] | 1000  |   570.62 μs |  9.628 μs |  5.729 μs | 43.36 |    0.50 |       - |       - |   51.88 KB |        1.33 |
| NativeSingle      | TaLib(...)bands [24] | 1000  |    13.16 μs |  0.171 μs |  0.089 μs |  1.00 |    0.01 |  1.5869 |  0.1221 |   39.09 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [24] | 1000  |    27.49 μs |  0.931 μs |  0.616 μs |  2.09 |    0.05 |  5.3711 |  0.7324 |  122.26 KB |        3.13 |
|                   |                      |       |             |           |           |       |         |         |         |            |             |
| **BuilderFull**       | **TaLib(...)bands [24]** | **10000** | **3,144.86 μs** | **68.128 μs** | **35.632 μs** | **26.16** |    **0.45** | **31.2500** |       **-** |  **953.27 KB** |        **2.44** |
| BuilderLatestOnly | TaLib(...)bands [24] | 10000 | 3,039.86 μs | 55.735 μs | 29.151 μs | 25.29 |    0.41 |       - |       - |  483.48 KB |        1.24 |
| NativeSingle      | TaLib(...)bands [24] | 10000 |   120.24 μs |  2.546 μs |  1.684 μs |  1.00 |    0.02 | 15.6250 |  7.8125 |  390.66 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [24] | 10000 |   207.77 μs | 13.734 μs |  9.084 μs |  1.73 |    0.08 | 50.7813 | 25.3906 | 1212.12 KB |        3.10 |
