```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)bands [24]** | **1000**  |   **613.1 μs** |  **29.25 μs** |  **19.35 μs** |       **-** |  **99.54 KB** |
| BuilderLatestOnly | TaLib(...)bands [24] | 1000  |   564.9 μs |  23.90 μs |  15.81 μs |       - |  51.88 KB |
| **BuilderFull**       | **TaLib(...)bands [24]** | **10000** | **3,124.6 μs** |  **72.00 μs** |  **37.66 μs** | **31.2500** | **953.33 KB** |
| BuilderLatestOnly | TaLib(...)bands [24] | 10000 | 3,250.0 μs | 412.17 μs | 272.63 μs | 15.6250 |  483.4 KB |
