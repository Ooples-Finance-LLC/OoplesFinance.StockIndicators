```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Dsma** |   **754.2 μs** | **28.56 μs** | **18.89 μs** |  **1.00** |    **0.03** |  **512.61 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Dsma |   126.7 μs |  2.22 μs |  1.32 μs |  0.17 |    0.00 |  221.74 KB |        0.43 |
|            |       |                |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Dsma** | **8,571.9 μs** | **47.03 μs** | **27.99 μs** |  **1.00** |    **0.00** | **8104.09 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Dsma | 1,250.3 μs | 25.52 μs | 15.19 μs |  0.15 |    0.00 | 2179.29 KB |        0.27 |
