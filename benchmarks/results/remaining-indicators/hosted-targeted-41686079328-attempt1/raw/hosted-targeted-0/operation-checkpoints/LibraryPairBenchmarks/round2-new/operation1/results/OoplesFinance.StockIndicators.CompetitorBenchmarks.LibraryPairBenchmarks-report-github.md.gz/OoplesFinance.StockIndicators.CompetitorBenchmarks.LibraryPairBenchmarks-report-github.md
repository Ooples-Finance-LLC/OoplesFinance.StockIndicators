```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)bands [24]** |   **807.01 μs** | **17.241 μs** | **11.404 μs** |  **1.00** |    **0.02** |  **221.38 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)bands [24] |    28.88 μs |  7.711 μs |  5.100 μs |  0.04 |    0.01 |  121.52 KB |        0.55 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)bands [24]** | **4,412.65 μs** | **45.254 μs** | **23.669 μs** |  **1.00** |    **0.01** | **2158.01 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)bands [24] |   194.57 μs |  7.322 μs |  3.829 μs |  0.04 |    0.00 | 1130.29 KB |        0.52 |
