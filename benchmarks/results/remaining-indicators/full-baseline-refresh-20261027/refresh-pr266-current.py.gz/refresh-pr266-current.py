from pathlib import Path
import json,subprocess
root=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
body=(root/'pr266-current-body.txt').read_text(encoding='utf-8')
current=json.loads(subprocess.check_output(['gh','api','repos/Ooples-Finance-LLC/OoplesFinance.StockIndicators/pulls/266']))
assert ('published through `'+current['head']['sha'][:9]+'`') in body and current['base']['ref']=='master'
patch=root/'pr266-patch.json';patch.write_text(json.dumps({'body':body}),encoding='utf-8')
subprocess.run(['gh','api','--method','PATCH','repos/Ooples-Finance-LLC/OoplesFinance.StockIndicators/pulls/266','--input',str(patch),'--jq','{number:.number,base:.base.ref,head:.head.sha}'],check=True)
