import csv
import io
import json
from pathlib import Path
import re
import sys
import hashlib
import psutil
import statistics
from playwright.sync_api import sync_playwright

root = Path('C:/Users/cheat/Documents/OoplesFinance-Reports')
assert len(sys.argv) == 5, 'Usage: verify REPORT SOURCE_SHA RUN_ID OUTPUT_DIRECTORY'
report = Path(sys.argv[1]).resolve()
expected_source = sys.argv[2]
expected_run = sys.argv[3]
out = Path(sys.argv[4]).resolve()
out.mkdir(parents=True, exist_ok=True)
document = report.read_text(encoding='utf-8')
def embedded(name):
    return json.loads(re.search(r'<script[^>]*id="' + name + r'"[^>]*>(.*?)</script>', document, re.S)[1])
data, old = embedded('dataset'), embedded('archived-baseline-dataset')
new_source = expected_source
stage = json.loads((out/'stage-receipt.json').read_text(encoding='utf-8'))
assert stage['status']=='staged-browser-verification-and-import-pending'
assert stage['source_sha']==expected_source and stage['run_id']==int(expected_run)
assert stage['candidate_sha256']==hashlib.sha256(report.read_bytes()).hexdigest()
assert data['evidence']['sourceSha']==expected_source
assert data['evidence']['runUrl']==stage['run_url']
assert len(data['rows'])==802 and len({r['pair'] for r in data['rows']})==401
assert all(row['source_sha']==expected_source and row['measurement_run_url']==stage['run_url'] for row in data['rows'])
assert not any(any('OoplesFinance.StockIndicators.CompetitorBenchmarks.dll' in arg for arg in p.info['cmdline'] or []) for p in psutil.process_iter(['cmdline'])), 'Local measurement active'
old_rows = {(r['pair'],r['bars']):r for r in old['rows']}
changed = {arm: sum(r[arm+'_mean_ns'] != old_rows[r['pair'],r['bars']][arm+'_mean_ns'] for r in data['rows'])
           for arm in ['ooples', 'competitor']}
summary = []
for library in sorted({r['library'] for r in data['rows']}):
    for bars in [1000,10000]:
        rows = [r for r in data['rows'] if r['library'] == library and r['bars'] == bars]
        lower = sum(r['competitor_over_ooples'] > 1 for r in rows)
        higher = sum(r['competitor_over_ooples'] < 1 for r in rows)
        equal = len(rows)-lower-higher
        summary.append(dict(library=library,bars=bars,comparisons=len(rows),lower=lower,higher=higher,equal=equal))
assert sum(r['comparisons'] for r in summary) == 802
with sync_playwright() as pw:
    browser = pw.chromium.launch(channel='msedge',headless=True)
    page = browser.new_page(viewport={'width':1440,'height':1000},accept_downloads=True)
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto(report.as_uri())
    page.wait_for_selector('#rows tr')
    for bars in [1000,10000]:
        page.locator(f'[data-size="{bars}"]').click()
        wins = sum(r['lower'] for r in summary if r['bars']==bars)
        assert page.locator('#wins').inner_text() == f'{wins} / 401'
        assert page.locator('#librarycards .libcard').count() == 4
        for card in page.locator('#librarycards .libcard').all():
            library=card.locator('.name').inner_text()
            rows=[r for r in data['rows'] if r['library']==library and r['bars']==bars]
            lower=sum(r['competitor_over_ooples']>1 for r in rows)
            assert card.locator('.small b').inner_text()==f'{lower} / {len(rows)}'
            assert card.locator('.rail').get_attribute('aria-label')==f'{lower} of {len(rows)} lower Ooples means'
            expected_median=statistics.median(r['competitor_over_ooples'] for r in rows)
            assert card.locator('.ratio').inner_text()==page.evaluate('value => ratio(value)',expected_median)
            assert card.locator('.version').inner_text()==f"v{data['versions'][library]} · {len(rows)} paired APIs"

    page.locator('#size').select_option('all')
    assert page.locator('#resultcount').inner_text() == '802 size comparisons · 401 APIs'
    # Traverse the complete paginated results table, not only the export or hero cards.
    formatted = page.evaluate("rows => rows.map(r => ({pair:r.pair,bars:r.bars,values:[time(r.ooples_mean_ns),time(r.competitor_mean_ns),ratio(r.competitor_over_ooples)]}))", data['rows'])
    expected_cells = {(r['pair'],r['bars']):r['values'] for r in formatted}
    table_keys = set()
    while True:
        visible = page.locator('#rows tr').evaluate_all("rows => rows.map(r => ({pair:r.querySelector('[data-pair]').dataset.pair,bars:Number(r.cells[1].textContent.replace(/[^0-9]/g,'')),values:[r.cells[2].textContent,r.cells[3].textContent,r.cells[4].textContent]}))")
        for row in visible:
            key = (row['pair'], row['bars'])
            assert key not in table_keys, key
            assert row['values'] == expected_cells[key], (key,row['values'],expected_cells[key])
            table_keys.add(key)
        if page.locator('#next').is_disabled(): break
        page.locator('#next').click()
    assert len(table_keys) == 802
    while not page.locator('#prev').is_disabled(): page.locator('#prev').click()
    with page.expect_download() as download:
        page.locator('#export').click()
    exported=list(csv.DictReader(Path(download.value.path()).read_text(encoding='utf-8').splitlines()))
    assert len(exported)==802
    expected={(r['pair'],r['bars']):r for r in data['rows']}
    for row in exported:
        actual=expected[row['pair'],int(row['bars'])]
        for key in ['ooples_mean_ns','competitor_mean_ns','competitor_over_ooples']:
            assert float(row[key])==actual[key]
        assert row['source_sha']==actual['source_sha'] and row['measurement_run_url']==actual['measurement_run_url']
    page.locator('#rows [data-pair]').first.click()
    assert page.locator('#detail').is_visible()
    assert 'Sample 3 (ns)' in page.locator('#detailbody').inner_text()
    page.locator('#close').click()
    page.evaluate('window.scrollTo(0,0)')
    page.screenshot(path=str(out/'refreshed-baseline.png'))
    updated_pair=next(r['pair'] for r in data['rows'] if r['source_sha']==new_source)
    page.locator('#query').fill(updated_pair)
    # Search is a substring filter: Ad also matches AdOsc. Verify those results,
    # then select the exact updated pair for its provenance and sample checks.
    matches=[r for r in data['rows'] if updated_pair.lower() in (r['pair']+' '+r['ooples_indicator']).lower()]
    assert page.locator('#rows tr').count()==len(matches)
    updated_links=page.locator(f'#rows [data-pair="{updated_pair}"]')
    assert updated_links.count()==2
    updated_links.first.click()
    body=page.locator('#detailbody').inner_text()
    assert new_source[:8] in body and 'Sample 3 (ns)' in body
    # Formula notes may describe native NaN behavior; measured cells must stay finite.
    for numeric_table in page.locator('#detailbody table').all_inner_texts():
        assert 'NaN' not in numeric_table and 'undefined' not in numeric_table
    page.screenshot(path=str(out/'updated-pair-details.png'))
    visible_html=re.sub(r'<script.*?</script>','',document,flags=re.S)
    assert f'{sum(r["lower"] for r in summary if r["bars"]==10000)} / 401 APIs at 10,000 bars' in visible_html
    builder=embedded('current-competitor-data')
    stage={'builder_rows':[{**row,'measurement_url':receipt.get('measurement_url','https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/'+str(receipt['run_id']))} for receipt in builder['receipts'] for row in receipt['comparisons']]}
    assert len(stage['builder_rows'])==builder['full_comparisons']
    assert page.locator('#ema-constructor-table tbody tr').count()==8
    assert page.locator('#builder-current-results tbody tr').count()==len(stage['builder_rows'])
    for r in stage['builder_rows']:
        row=page.locator(f'#builder-current-results tr[data-builder-pair="{r["pair"]}"][data-bars="{r["bars"]}"][data-mode="{r["mode"]}"]')
        cells=row.locator('td').all_inner_texts()
        assert cells[3:6]==[f'{r["ooples"]["mean_ns"]/1e6:.6f}',f'{r["native"]["NativeSingle"]["mean_ns"]/1e6:.6f}',f'{r["native"]["NativeParallel"]["mean_ns"]/1e6:.6f}']
        assert cells[6]=={'faster':'Faster than both','slower':'Slower than at least one','inconclusive':'Inconclusive'}[r['verdict']]
        assert row.locator('a').get_attribute('href') == r['measurement_url']
    assert not errors,errors
    browser.close()
receipt=dict(source=data['evidence']['sourceSha'],run_id=expected_run,report_sha256=hashlib.sha256(report.read_bytes()).hexdigest(),changed_means=changed,summary=summary,
    comparisons=802,displayed_table_comparisons=len(table_keys),exported_comparisons=len(exported),javascript_errors=errors)
(out/'browser-verification.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt))
