"""Stage all measured baseline numbers; never overwrite the live report."""
import argparse
import hashlib
import json
from pathlib import Path
import psutil
import re
import subprocess
import sys

REPO = Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
LIVE = Path('C:/Users/cheat/Documents/OoplesFinance-Reports/competitor-performance.html')
SLUG = 'Ooples-Finance-LLC/OoplesFinance.StockIndicators'


def capture(args):
    return subprocess.check_output(args, cwd=REPO, timeout=120)


def verify_run(run, jobs, source):
    assert run['head_sha'] == source and run['event'] == 'workflow_dispatch'
    assert run['path'] == '.github/workflows/competitor-library.yml'
    assert run['status'] == 'completed' and run['conclusion'] == 'success'
    by_name = {job['name']: job for job in jobs}
    assert len(by_name) == len(jobs), 'Ambiguous job attempts'
    required = {'build', 'complete-union', 'performance-summary'}
    required |= {f'{family} ({i})' for family in ['contracts', 'correctness', 'performance'] for i in range(20)}
    assert required <= by_name.keys(), 'Missing required job results'
    assert all(by_name[name]['conclusion'] == 'success' for name in required)
    return sorted(required)


def stage_document(document, dataset, report):
    names = re.findall(r'<script[^>]*id="([^"]+)"[^>]*type="application/json"', document)
    preserved = {name: report.embedded(document, name) for name in names if name != 'dataset'}
    candidate = report.replace_primary(document, dataset)
    assert report.embedded(candidate, 'dataset') == dataset
    for name, original in preserved.items():
        assert report.embedded(candidate, name) == original, name
    constructors = re.search(r'<section\b[^>]*id="ema-constructor-results"[^>]*>.*?</section>', document, re.S)
    if constructors:
        assert constructors[0] in candidate, 'Constructor-specific results changed'
    wins = sum(row['bars'] == 10000 and row['competitor_over_ooples'] > 1 for row in dataset['rows'])
    assert f'<b id="wins">{wins} / 401</b>' in candidate
    return candidate, sorted(preserved), wins


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--summary', required=True, type=Path)
    parser.add_argument('--source', required=True)
    parser.add_argument('--run-id', required=True, type=int)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    assert re.fullmatch('[0-9a-f]{40}', args.source)
    assert not args.output.exists(), 'Preserve prior attempts; use a new output directory'
    assert not any(any('OoplesFinance.StockIndicators.CompetitorBenchmarks.dll' in arg
                      for arg in proc.info['cmdline'] or []) for proc in psutil.process_iter(['cmdline'])), 'Local timing active'
    run = json.loads(capture(['gh', 'api', f'repos/{SLUG}/actions/runs/{args.run_id}']))
    pages = json.loads(capture(['gh', 'api', '--paginate', '--slurp',
                               f'repos/{SLUG}/actions/runs/{args.run_id}/jobs?per_page=100']))
    jobs = [job for page in pages for job in page['jobs']]
    verified_jobs = verify_run(run, jobs, args.source)
    assert capture(['git', 'rev-parse', 'HEAD']).decode().strip() == args.source, 'Published source changed'
    manifest = capture(['git', 'show', args.source + ':benchmarks/competitor-library-manifest.json'])
    packages = capture(['git', 'show', args.source + ':benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks.csproj']).decode('utf-8-sig')
    versions = {}
    for label, package in [('Skender', 'Skender.Stock.Indicators'), ('TaLib', 'TALib.NETCore'), ('Trady', 'Trady.Analysis'), ('QuanTAlib', 'QuanTAlib')]:
        match = re.search(r'Include="' + re.escape(package) + r'"\s+Version="([^"]+)"', packages, re.I)
        assert match, package
        versions[label] = match[1]
    sys.path.insert(0, str(REPO / 'benchmarks'))
    import primary_baseline_report as report
    dataset = report.measured_dataset(args.summary, args.source, args.run_id, manifest, versions)
    assert len(dataset['rows']) == 802 and dataset['evidence']['measuredArms'] == 1604
    assert len({row['pair'] for row in dataset['rows']}) == 401
    original = LIVE.read_bytes()
    candidate, preserved, wins = stage_document(original.decode('utf-8'), dataset, report)
    assert LIVE.read_bytes() == original
    args.output.mkdir(parents=True, exist_ok=False)
    path = args.output / 'candidate.html'
    path.write_text(candidate, encoding='utf-8', newline='\n')
    receipt = dict(status='staged-browser-verification-and-import-pending', source_sha=args.source,
                   run_id=args.run_id, run_url=run['html_url'], verified_jobs=verified_jobs,
                   baseline_rows_replaced=802, measured_arms=1604, point_estimate_wins_10000=wins,
                   preserved_datasets=preserved, before_sha256=hashlib.sha256(original).hexdigest(),
                   candidate_sha256=hashlib.sha256(path.read_bytes()).hexdigest(), full_goal_complete=False)
    (args.output / 'stage-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
