from pathlib import Path
import argparse,hashlib,json,re,subprocess
ROOT=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
REPO=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
LIVE=Path('C:/Users/cheat/Documents/OoplesFinance-Reports/competitor-performance.html')
parser=argparse.ArgumentParser();parser.add_argument('--verification-directory',type=Path,required=True);args=parser.parse_args()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
import time
for attempt in range(40):
 pr=json.loads(subprocess.check_output(['gh','api','repos/Ooples-Finance-LLC/OoplesFinance.StockIndicators/pulls/266']))
 assert pr['base']['ref']=='master'
 if pr['head']['sha']==head:break
 if attempt==39:raise RuntimeError('PR head did not converge to the verified local/pushed head')
 time.sleep(3)
assert pr['head']['sha']==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=REPO,text=True).strip()
v=json.loads((args.verification_directory/'browser-verification.json').read_text())
assert v['report_sha256']==hashlib.sha256(LIVE.read_bytes()).hexdigest() and not v['javascript_errors']
assert v.get('comparisons',v.get('baseline_comparisons'))==v['displayed_table_comparisons']==v['exported_comparisons']==802
html=LIVE.read_text(encoding='utf-8')
def data(name):return json.loads(re.search(r'<script[^>]*id="'+name+r'"[^>]*>(.*?)</script>',html,re.S)[1])
d=data('dataset');b=data('current-competitor-data');counts=b['verdicts']
assert len(d['rows'])==802 and sum(counts.values())==b['full_comparisons']
inventory=json.loads((REPO/'benchmarks/results/remaining-indicators/inventory.json').read_text())
recorded=sum(bool(row.get('batch_contract_receipts') or row.get('contract_receipts')) for row in inventory['batch_formulas'])
pending_facades=sum(row['status']=='pending-assessment' for row in inventory['handwritten_facades'])
wins={n:sum(row['competitor_over_ooples']>1 for row in d['rows'] if row['bars']==n) for n in [1000,10000]}
url=f'https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/blob/{head}/benchmarks/results/remaining-indicators/'
body=f"""Repeated window replay, intermediate histories, and wide-number arithmetic make many indicators expensive. This rollout adds shared execution, rolling windows, and certified arithmetic fast paths with exact fallback, preserving the established output, signal, input-selection, preview, reset, and overflow contracts in the qualified batches.

Targets `master`, published through `{head[:9]}`. Integrated changes include exact rolling Fibonacci weights, bounded Hilbert projections and CCI deviations, compact SMA diagnostics, and exact machine-word T3 smoothing. Unsupported numerical ranges retain the original exact paths.

Performance work is **unfinished**. The report currently shows lower Ooples batch means for **{wins[1000]}/401 comparisons at 1,000 bars** and **{wins[10000]}/401 at 10,000 bars**. Builder results are **{counts['faster']} faster, {counts['slower']} slower, {counts['inconclusive']} inconclusive, and {1604-b['full_comparisons']} pending**. Batch and builder results measure distinct execution paths.

Latest measured 10,000-bar results (milliseconds):

| API pair | Ooples | Competitor |
|---|---:|---:|
"""
selected={'TaLib.Functions.HtDcPhase','TaLib.Functions.HtSine','QuanTAlib.Fwma','Skender.GetSmaAnalysis','TaLib.Functions.Cci','TaLib.Functions.HtTrendMode','TaLib.Functions.Sar','TaLib.Functions.T3','TaLib.Functions.UltOsc','Skender.GetUltimate','TaLib.Functions.Ad','Skender.GetChaikinOsc','TaLib.Functions.Macd','TaLib.Functions.Ppo','Skender.GetPvo','TaLib.Candles.MorningStar','TaLib.Candles.AbandonedBaby','TaLib.Candles.ThreeInside','TaLib.Candles.ThreeStarsInSouth'}
for row in d['rows']:
 if row['bars']==10000 and row['pair'] in selected:
  body+=f"| {row['pair']} | {row['ooples_mean_ns']/1e6:.5f} | {row['competitor_mean_ns']/1e6:.5f} |\n"
body+="\nRecent integrated qualification:\n\n"
for name,date,units,parity,cases in [('t3-word-binade','20261024',46,26,144),('hilbert-coefficient-domain','20261025',20,43,144),('ultimate-certified-ratio','20261025',18,15,96),('money-flow-compact-product','20261025',0,0,288),('roc-round-units-compact','20261025',0,0,480),('ultimate-bounded-weights','20261026',18,15,96),('star-reversal-equal-sums','20261026',16,0,240),('triple-body-equal-sums','20261026',14,0,192),('exhaustion-equal-windows','20261026',7,0,144),('adl-direct-dispatch','20261026',0,0,288),('adl-identity-signal','20261026',0,0,48),('t3-direct-dispatch','20261026',57,0,192),('crow-soldier-equal-ranges','20261026',0,0,144),('roc-integer-units','20261026',0,0,480),('roc-power-two-units','20261026',0,0,480),('hilbert-direct-dispatch','20261027',0,0,240),('cci-exact-operands','20261027',39,20,80),('macd-early-dispatch','20261027',245,167,240)]:
 path=REPO/f'benchmarks/results/remaining-indicators/local-{name}-control-{date}/decision.json'
 if not path.exists():continue
 decision=json.loads(path.read_text())
 if not decision['production_integrated']:continue
 if (REPO/f'benchmarks/results/remaining-indicators/publication-{name}-certified-{date}-verification.json').exists():
  qualification=json.loads((REPO/f'benchmarks/results/remaining-indicators/publication-{name}-certified-{date}-verification.json').read_text())
  units=qualification['unit']['passed'];parity=qualification['parity']['passed']
 assert decision['report_imported'] and not any(row['verdict']=='slower' for row in decision['decisions'])
 faster=sum(row['verdict']=='faster' for row in decision['decisions']);inconclusive=sum(row['verdict']=='inconclusive' for row in decision['decisions'])
 body+=f"- {name}: {units} unit cases, {parity} parity cases, 100 GPU contracts, and eight inventory tests passed; all {cases} controlled cases verified, with {faster} improved configurations, {inconclusive} inconclusive, and none regressed. [Evidence]({url}local-{name}-control-{date}/decision.json).\n"
body+=f"""
Qualified source and binary fingerprints are checked before integration. The report's actual measured rows and CSV were browser-verified across all 802 batch comparisons with no JavaScript errors; each row retains its measurement source. Report SHA256: `{v['report_sha256']}`. Historical contract receipts are recorded for {recorded}/{inventory['counts']['batch_formulas']} batch formulas; {pending_facades} handwritten facades still await assessment. [Inventory]({url}inventory.json).

Remaining work: close measured competitor gaps, finish facade and builder coverage, and clear the remaining CI gates. Three approved Sonar false-positive dispositions remain unapplied because authenticated access is unavailable. This PR does not yet establish superiority over every competitor.
"""
# Retain the separately qualified EMA constructor coverage and its evidence.
marker='<!-- compensated-ema-qualification -->'
assert marker in (pr['body'] or '')
ema_section=(pr['body'] or '').split(marker,1)[1]
assert 'Compensated EMA coverage' in ema_section
body+='\n\n'+marker+ema_section

output=ROOT/'pr266-current-body.txt';output.write_text(body,encoding='utf-8',newline='\n');print(json.dumps({'body_file':str(output),'head':head,'report_sha256':v['report_sha256'],'characters':len(body)}))
