```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Trix** |   **253.54 μs** |  **4.164 μs** |  **2.178 μs** |  **1.00** |  **192.81 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Trix |    13.03 μs |  0.661 μs |  0.437 μs |  0.05 |   45.79 KB |        0.24 |
|            |       |                      |             |           |           |       |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Trix** | **2,600.43 μs** | **33.675 μs** | **20.040 μs** |  **1.00** | **1895.34 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Trix |   117.32 μs |  9.210 μs |  5.481 μs |  0.05 |  405.48 KB |        0.21 |
