```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation            | Mean       | Error   | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |------ |--------------------- |-----------:|--------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **TaLib.Functions.Trix** |   **181.1 μs** | **1.83 μs** | **1.09 μs** |       **-** |       **-** |  **89.09 KB** |
| BuilderLatestOnly | 1000  | TaLib.Functions.Trix |   171.8 μs | 0.79 μs | 0.41 μs |  1.9531 |       - |  41.44 KB |
| **BuilderFull**       | **10000** | **TaLib.Functions.Trix** | **2,006.5 μs** | **9.83 μs** | **5.14 μs** | **46.8750** | **15.6250** | **862.97 KB** |
| BuilderLatestOnly | 10000 | TaLib.Functions.Trix | 2,016.5 μs | 8.63 μs | 5.13 μs | 15.6250 |       - |  393.1 KB |
