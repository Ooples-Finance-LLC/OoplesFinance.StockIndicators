```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId          | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetTrix** |   **316.91 μs** | **37.575 μs** | **22.360 μs** |  **1.00** |    **0.09** |  **210.95 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetTrix |    59.44 μs |  5.769 μs |  3.017 μs |  0.19 |    0.01 |  201.73 KB |        0.96 |
|            |       |                 |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetTrix** | **2,956.72 μs** | **42.191 μs** | **25.107 μs** |  **1.00** |    **0.01** | **2072.62 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetTrix |   612.82 μs | 24.183 μs | 15.995 μs |  0.21 |    0.01 | 1953.05 KB |        0.94 |
