```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation       | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------------- |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Skender.GetTrix** |   **244.9 μs** | **19.27 μs** | **11.47 μs** |       **-** |       **-** |  **89.09 KB** |
| BuilderLatestOnly | 1000  | Skender.GetTrix |   239.2 μs | 12.32 μs |  8.15 μs |  1.9531 |       - |  41.44 KB |
| **BuilderFull**       | **10000** | **Skender.GetTrix** | **2,455.3 μs** | **52.09 μs** | **31.00 μs** | **46.8750** | **15.6250** | **862.95 KB** |
| BuilderLatestOnly | 10000 | Skender.GetTrix | 2,426.7 μs | 26.29 μs | 13.75 μs | 15.6250 |       - | 393.12 KB |
