```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation       | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |------ |---------------- |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Skender.GetTrix** |   **321.6 μs** | **19.79 μs** | **11.77 μs** |       **-** |  **89.21 KB** |
| BuilderLatestOnly | 1000  | Skender.GetTrix |   315.9 μs |  1.26 μs |  0.66 μs |  1.9531 |   41.6 KB |
| **BuilderFull**       | **10000** | **Skender.GetTrix** | **3,227.5 μs** | **11.25 μs** |  **5.88 μs** | **31.2500** | **863.24 KB** |
| BuilderLatestOnly | 10000 | Skender.GetTrix | 3,236.8 μs | 23.62 μs | 14.05 μs |       - | 393.38 KB |
