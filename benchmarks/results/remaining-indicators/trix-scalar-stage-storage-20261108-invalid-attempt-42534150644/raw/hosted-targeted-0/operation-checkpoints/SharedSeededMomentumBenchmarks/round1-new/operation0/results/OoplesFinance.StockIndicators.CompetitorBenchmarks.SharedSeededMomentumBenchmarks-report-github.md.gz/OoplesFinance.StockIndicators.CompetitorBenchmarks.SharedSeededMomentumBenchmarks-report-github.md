```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation       | Mean       | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------------- |-----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Skender.GetTrix** |   **242.6 μs** |   **2.00 μs** |  **1.19 μs** |       **-** |       **-** |  **89.09 KB** |
| BuilderLatestOnly | 1000  | Skender.GetTrix |   237.6 μs |   5.79 μs |  3.44 μs |  1.9531 |       - |  41.45 KB |
| **BuilderFull**       | **10000** | **Skender.GetTrix** | **2,551.9 μs** |  **76.21 μs** | **50.41 μs** | **46.8750** | **15.6250** | **862.96 KB** |
| BuilderLatestOnly | 10000 | Skender.GetTrix | 2,561.6 μs | 128.14 μs | 84.75 μs | 15.6250 |       - | 393.12 KB |
