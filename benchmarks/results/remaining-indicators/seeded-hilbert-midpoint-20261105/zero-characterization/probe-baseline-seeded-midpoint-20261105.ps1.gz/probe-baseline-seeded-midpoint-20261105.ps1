$ErrorActionPreference = 'Stop'
$probeDll = 'C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-sum-directional-normalization-20261104/src/bin/Release/net10.0/OoplesFinance.StockIndicators.dll'
if ((Get-FileHash -LiteralPath $probeDll -Algorithm SHA256).Hash.ToLowerInvariant() -ne '9ae13bf0915b27f978f42feac96751bff88e00195066c5f82c577537656eb6f7') { throw 'Baseline DLL mismatch' }
$probeAsm = [Reflection.Assembly]::LoadFrom($probeDll)
$probeFlags = [Reflection.BindingFlags]'Public,NonPublic,Static,Instance'
$probeOwnerType = $probeAsm.GetType('OoplesFinance.StockIndicators.Indicators.SeededHilbertTrendline', $true)
$probeOwner = [Activator]::CreateInstance($probeOwnerType, [object[]]@($true))
$probeCreate = $probeOwnerType.GetMethod('CreateState', $probeFlags)
$probeState = $probeCreate.Invoke($probeOwner, $null)
$probeStateType = $probeState.GetType()
$probeInterface = $probeStateType.GetInterfaces() | Where-Object Name -eq 'IMultiOutputState'
$probeUpdate = $probeInterface.GetMethod('Update')
$probeBarType = $probeUpdate.GetParameters()[0].ParameterType.GetElementType()
$probeCtor = $probeBarType.GetConstructors() | Where-Object { $_.GetParameters().Count -eq 6 }
$probeSpanCtor = [Span[double]].GetConstructor([type[]]@([double[]]))
$probeDynamic = [Reflection.Emit.DynamicMethod]::new('BaselineSeededUpdate', [void], [type[]]@([object], $probeBarType, [double[]]), $probeStateType.Module, $true)
$probeIl = $probeDynamic.GetILGenerator()
$probeIl.Emit([Reflection.Emit.OpCodes]::Ldarg_0)
$probeIl.Emit([Reflection.Emit.OpCodes]::Castclass, $probeInterface)
$probeIl.Emit([Reflection.Emit.OpCodes]::Ldarga_S, [byte]1)
$probeIl.Emit([Reflection.Emit.OpCodes]::Ldarg_2)
$probeIl.Emit([Reflection.Emit.OpCodes]::Newobj, $probeSpanCtor)
$probeIl.Emit([Reflection.Emit.OpCodes]::Callvirt, $probeUpdate)
$probeIl.Emit([Reflection.Emit.OpCodes]::Ret)
$probeAction = [Action[object,object,object]].GetGenericTypeDefinition().MakeGenericType([type[]]@([object], $probeBarType, [double[]]))
$probeCall = $probeDynamic.CreateDelegate($probeAction)
$probeReset = $probeStateType.GetMethod('Reset', $probeFlags)
$probeFraction = $probeAsm.GetType('OoplesFinance.StockIndicators.Validation.ReferenceFraction', $true)
$probeFrom = $probeFraction.GetMethod('FromDouble', $probeFlags)
$probePlus = $probeFraction.GetMethod('op_Addition', $probeFlags)
$probeDivide = $probeFraction.GetMethod('op_Division', $probeFlags)
$probeTo = $probeFraction.GetMethod('ToDouble', $probeFlags)
$probeTwo = $probeFrom.Invoke($null, [object[]]@(2.0))
$probeReference = $probeAsm.GetType('OoplesFinance.StockIndicators.Validation.SeededHilbertTrendReference', $true).GetMethod('Values', $probeFlags)
$probeBoundary = [Math]::ScaleB(1.0, -1021)
$probeValues = [double[]]@(0.0, [BitConverter]::Int64BitsToDouble([long]::MinValue), [double]::Epsilon, -[double]::Epsilon,
    [Math]::BitDecrement($probeBoundary), $probeBoundary, [Math]::BitIncrement($probeBoundary),
    -[Math]::BitDecrement($probeBoundary), -$probeBoundary, -[Math]::BitIncrement($probeBoundary),
    [Math]::BitDecrement(1.0), 1.0, [Math]::BitIncrement(1.0), [double]::MaxValue, -[double]::MaxValue)
$probeBars = [Collections.Generic.List[object]]::new()
foreach ($probeHigh in $probeValues) {
    foreach ($probeLow in $probeValues) {
        $probeBars.Add($probeCtor.Invoke([object[]]@([DateTime]::UnixEpoch.AddMinutes($probeBars.Count), 100.0, $probeHigh, $probeLow, (100.0 + $probeBars.Count % 13 / 8.0), 1.0)))
    }
}
for ($probeIndex = 0; $probeIndex -lt 129; $probeIndex++) {
    $probeClose = 100.0 + ($probeIndex * 17 % 31) / 8.0
    $probeBars.Add($probeCtor.Invoke([object[]]@([DateTime]::UnixEpoch.AddMinutes($probeBars.Count), $probeClose, ($probeClose + 2), ($probeClose - 1), $probeClose, 1.0)))
}
$probeMismatch = [Collections.Generic.List[object]]::new()
$probeCompared = 0
foreach ($probeMidpoint in @($false, $true)) {
    $probeReferenceBars = [Array]::CreateInstance($probeBarType, $probeBars.Count)
    for ($probeIndex = 0; $probeIndex -lt $probeBars.Count; $probeIndex++) {
        $probeBar = $probeBars[$probeIndex]
        $probePrice = $probeBar.Close
        if ($probeMidpoint) {
            $probeHighFraction = $probeFrom.Invoke($null, [object[]]@($probeBar.High))
            $probeLowFraction = $probeFrom.Invoke($null, [object[]]@($probeBar.Low))
            $probeSum = $probePlus.Invoke($null, [object[]]@($probeHighFraction, $probeLowFraction))
            $probeHalf = $probeDivide.Invoke($null, [object[]]@($probeSum, $probeTwo))
            $probePrice = [double]$probeTo.Invoke($probeHalf, $null)
        }
        if ([BitConverter]::DoubleToInt64Bits($probePrice) -eq [long]::MinValue) { $probePrice = 0.0 }
        $probeReferenceBars.SetValue($probeCtor.Invoke([object[]]@($probeBar.Time, $probePrice, $probePrice, $probePrice, $probePrice, $probeBar.Volume)), $probeIndex)
    }
    $probeArgs = [object[]]::new(2)
    $probeArgs[0] = $probeReferenceBars
    $probeArgs[1] = $false
    $probeExpected = $probeReference.Invoke($null, $probeArgs)
    $probeState = $probeCreate.Invoke([Activator]::CreateInstance($probeOwnerType, [object[]]@($probeMidpoint)), $null)
    $probeOutput = [double[]]::new(6)
    $probeFrame = [object[]]::new(3)
    $probeFrame[0] = $probeState
    $probeFrame[2] = $probeOutput
    for ($probeReplay = 0; $probeReplay -lt 2; $probeReplay++) {
        $probeReset.Invoke($probeState, $null)
        for ($probeIndex = 0; $probeIndex -lt $probeBars.Count; $probeIndex++) {
            $probeFrame[1] = $probeBars[$probeIndex]
            $probeCall.DynamicInvoke($probeFrame)
            for ($probeSlot = 0; $probeSlot -lt 3; $probeSlot++) {
                $probeValue = $probeExpected[$probeSlot][$probeIndex]
                $probeMask = if ($null -eq $probeValue) { 0.0 } else { 1.0 }
                $probeExpectedBits = if ($null -eq $probeValue) { 0L } else { [BitConverter]::DoubleToInt64Bits([double]$probeValue) }
                if ($probeExpectedBits -eq [long]::MinValue) { $probeExpectedBits = 0L }
                $probeActualBits = [BitConverter]::DoubleToInt64Bits($probeOutput[$probeSlot])
                $probeCompared += 2
                if ($probeExpectedBits -ne $probeActualBits -or $probeOutput[$probeSlot + 3] -ne $probeMask) {
                    $probeMismatch.Add(@{midpoint=$probeMidpoint; replay=$probeReplay; index=$probeIndex; slot=$probeSlot; expected=$probeExpectedBits; actual=$probeActualBits; mask=$probeOutput[$probeSlot + 3]; expected_mask=$probeMask})
                }
            }
        }
    }
}
@{bars=$probeBars.Count; compared=$probeCompared; mismatch_count=$probeMismatch.Count; examples=@($probeMismatch | Select-Object -First 8); runtime=[Runtime.InteropServices.RuntimeInformation]::FrameworkDescription} | ConvertTo-Json -Depth 5
if ($probeMismatch.Count -ne 0) { exit 1 }
