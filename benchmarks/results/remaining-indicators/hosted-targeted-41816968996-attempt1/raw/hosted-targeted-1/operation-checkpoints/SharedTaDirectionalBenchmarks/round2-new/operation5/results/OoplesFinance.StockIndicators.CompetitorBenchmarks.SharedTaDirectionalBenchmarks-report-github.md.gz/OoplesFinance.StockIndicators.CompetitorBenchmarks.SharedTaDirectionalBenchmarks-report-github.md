```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **399.04 μs** | **14.208 μs** |  **7.431 μs** | **33.80** |    **0.63** |       **-** |      **-** |  **65.22 KB** |        **8.62** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   390.49 μs |  7.029 μs |  4.183 μs | 33.07 |    0.40 |       - |      - |  17.63 KB |        2.33 |
| NativeSingle      | TaLib.Functions.Adx | 1000  |    11.81 μs |  0.140 μs |  0.083 μs |  1.00 |    0.01 |  0.4272 |      - |   7.57 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 1000  |    21.62 μs |  1.679 μs |  1.110 μs |  1.83 |    0.09 |  1.8311 |      - |  26.71 KB |        3.53 |
|                   |                     |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **4,375.74 μs** | **18.768 μs** |  **9.816 μs** | **37.76** |    **0.15** | **31.2500** |      **-** | **630.87 KB** |        **8.10** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 4,346.69 μs | 33.797 μs | 20.112 μs | 37.51 |    0.21 |       - |      - |    161 KB |        2.07 |
| NativeSingle      | TaLib.Functions.Adx | 10000 |   115.89 μs |  0.702 μs |  0.417 μs |  1.00 |    0.00 |  3.9063 |      - |  77.89 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 10000 |   180.25 μs | 18.532 μs | 12.258 μs |  1.56 |    0.10 | 17.5781 | 3.9063 | 272.81 KB |        3.50 |
