```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **475.14 μs** | **11.231 μs** |  **6.683 μs** | **35.44** |    **0.53** |       **-** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   464.61 μs |  4.183 μs |  2.489 μs | 34.66 |    0.30 |       - |      - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib.Functions.Dx | 1000  |    13.41 μs |  0.147 μs |  0.097 μs |  1.00 |    0.01 |  0.3662 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 1000  |    20.46 μs |  0.964 μs |  0.573 μs |  1.53 |    0.04 |  1.8311 |      - |  27.24 KB |        3.53 |
|                   |                    |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **5,194.16 μs** | **49.801 μs** | **32.940 μs** | **39.67** |    **0.26** | **31.2500** |      **-** |  **628.1 KB** |        **8.05** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 5,136.82 μs | 34.947 μs | 18.278 μs | 39.23 |    0.16 |       - |      - | 158.17 KB |        2.03 |
| NativeSingle      | TaLib.Functions.Dx | 10000 |   130.93 μs |  0.540 μs |  0.321 μs |  1.00 |    0.00 |  3.9063 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 10000 |   187.39 μs |  8.054 μs |  5.327 μs |  1.43 |    0.04 | 17.5781 | 3.9063 | 273.34 KB |        3.50 |
