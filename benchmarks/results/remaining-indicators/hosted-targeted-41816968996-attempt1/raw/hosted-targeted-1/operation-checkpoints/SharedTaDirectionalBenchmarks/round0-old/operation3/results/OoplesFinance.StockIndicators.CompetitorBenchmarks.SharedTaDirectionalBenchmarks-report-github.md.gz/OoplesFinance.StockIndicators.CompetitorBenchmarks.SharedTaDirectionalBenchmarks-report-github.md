```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **224.6 μs** |  **2.74 μs** |  **1.43 μs** |       **-** |  **64.96 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   227.1 μs |  1.66 μs |  0.87 μs |       - |   17.4 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **2,500.8 μs** | **21.36 μs** | **11.17 μs** | **31.2500** | **627.93 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,496.5 μs | 94.11 μs | 62.25 μs |       - | 158.11 KB |
