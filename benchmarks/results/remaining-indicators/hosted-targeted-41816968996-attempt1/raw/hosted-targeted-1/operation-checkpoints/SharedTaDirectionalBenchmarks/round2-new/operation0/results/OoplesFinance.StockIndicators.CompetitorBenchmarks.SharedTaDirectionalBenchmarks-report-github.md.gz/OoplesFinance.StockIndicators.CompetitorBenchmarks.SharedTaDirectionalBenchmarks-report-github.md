```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **140.411 μs** | **16.9104 μs** | **10.0631 μs** | **14.87** |    **1.01** |       **-** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   111.944 μs |  0.8756 μs |  0.4580 μs | 11.86 |    0.06 |  0.9766 |      - |  17.39 KB |        2.25 |
| NativeSingle      | TaLib(...)lusDM [22] | 1000  |     9.442 μs |  0.0493 μs |  0.0293 μs |  1.00 |    0.00 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 1000  |    12.516 μs |  0.6149 μs |  0.3659 μs |  1.33 |    0.04 |  1.8311 |      - |  27.23 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **1,293.655 μs** | **15.2421 μs** |  **7.9719 μs** | **14.20** |    **0.11** | **31.2500** | **7.8125** | **627.85 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 1,248.720 μs |  3.5978 μs |  1.8817 μs | 13.71 |    0.08 |  7.8125 |      - | 158.02 KB |        2.02 |
| NativeSingle      | TaLib(...)lusDM [22] | 10000 |    91.074 μs |  0.8758 μs |  0.5212 μs |  1.00 |    0.01 |  4.3945 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 10000 |   136.300 μs |  2.6794 μs |  1.5945 μs |  1.50 |    0.02 | 17.5781 | 3.9063 | 273.33 KB |        3.50 |
