```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **437.4 μs** | **13.39 μs** |  **8.86 μs** |       **-** |  **66.26 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   427.1 μs |  5.83 μs |  3.85 μs |       - |   18.7 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **4,803.3 μs** | **31.26 μs** | **18.60 μs** | **31.2500** | **631.84 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 4,785.4 μs | 92.64 μs | 61.28 μs |       - | 162.07 KB |
