```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **397.7 μs** | **18.00 μs** | **10.71 μs** |       **-** |  **65.22 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   389.9 μs |  4.30 μs |  2.56 μs |       - |  17.63 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **4,447.1 μs** | **53.03 μs** | **31.56 μs** | **31.2500** | **630.86 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 4,346.3 μs | 13.09 μs |  7.79 μs |       - | 161.02 KB |
