```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **475.1 μs** |  **6.47 μs** |  **3.85 μs** |       **-** |     **65 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   473.2 μs |  3.52 μs |  2.10 μs |       - |  17.41 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **5,229.2 μs** | **25.87 μs** | **13.53 μs** | **31.2500** | **628.04 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 5,127.3 μs | 17.13 μs |  8.96 μs |       - | 158.15 KB |
