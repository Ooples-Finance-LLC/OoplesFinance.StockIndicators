```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **212.917 μs** |  **4.3922 μs** |  **2.2972 μs** | **34.37** |    **0.65** |       **-** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   210.336 μs |  0.8023 μs |  0.5307 μs | 33.95 |    0.54 |       - |      - |  17.39 KB |        2.25 |
| NativeSingle      | TaLib(...)lusDI [22] | 1000  |     6.197 μs |  0.1759 μs |  0.1046 μs |  1.00 |    0.02 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 1000  |     9.558 μs |  0.3405 μs |  0.2027 μs |  1.54 |    0.04 |  1.8311 | 0.0610 |  27.24 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **2,391.312 μs** | **52.4185 μs** | **34.6716 μs** | **39.30** |    **0.62** | **31.2500** |      **-** | **627.95 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,343.975 μs | 19.0591 μs | 11.3418 μs | 38.52 |    0.35 |       - |      - | 158.14 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDI [22] | 10000 |    60.857 μs |  0.7517 μs |  0.4972 μs |  1.00 |    0.01 |  4.3945 |      - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 10000 |   112.548 μs |  3.2812 μs |  2.1703 μs |  1.85 |    0.04 | 18.5547 | 4.8828 | 273.34 KB |        3.50 |
