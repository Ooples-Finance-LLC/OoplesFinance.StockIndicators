```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **215.646 μs** |  **1.4791 μs** |  **0.7736 μs** | **33.72** |    **0.19** |       **-** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   211.907 μs |  1.6044 μs |  0.8391 μs | 33.14 |    0.19 |       - |      - |  17.39 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDI [23] | 1000  |     6.395 μs |  0.0571 μs |  0.0299 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 1000  |    10.018 μs |  0.3627 μs |  0.2399 μs |  1.57 |    0.04 |  1.8311 | 0.0610 |  27.24 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **2,376.995 μs** | **49.2165 μs** | **29.2879 μs** | **39.15** |    **0.49** | **31.2500** |      **-** | **627.94 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,394.221 μs | 69.8412 μs | 46.1956 μs | 39.43 |    0.75 |       - |      - | 158.11 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDI [23] | 10000 |    60.716 μs |  0.4652 μs |  0.2768 μs |  1.00 |    0.01 |  4.3945 |      - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 10000 |   111.059 μs |  1.7291 μs |  1.1437 μs |  1.83 |    0.02 | 18.5547 | 3.9063 | 273.34 KB |        3.50 |
