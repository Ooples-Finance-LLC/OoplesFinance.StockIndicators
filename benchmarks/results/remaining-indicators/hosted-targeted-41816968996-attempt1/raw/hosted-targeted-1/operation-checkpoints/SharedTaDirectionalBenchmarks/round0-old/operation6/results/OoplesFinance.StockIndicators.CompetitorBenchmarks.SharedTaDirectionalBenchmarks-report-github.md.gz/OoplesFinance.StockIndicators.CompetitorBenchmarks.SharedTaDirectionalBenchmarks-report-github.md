```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **467.0 μs** |   **5.01 μs** |   **2.62 μs** |       **-** |  **66.72 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   462.3 μs |   6.41 μs |   4.24 μs |       - |  19.12 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **5,182.1 μs** |  **46.25 μs** |  **27.52 μs** | **31.2500** | **638.62 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 5,189.1 μs | 159.82 μs | 105.71 μs |       - | 168.79 KB |
