```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **212.8 μs** |  **3.15 μs** |  **1.65 μs** |       **-** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   216.5 μs |  1.93 μs |  1.15 μs |       - |  17.39 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **2,351.7 μs** | **15.30 μs** |  **9.10 μs** | **31.2500** | **627.95 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,343.6 μs | 61.10 μs | 40.41 μs |       - | 158.11 KB |
