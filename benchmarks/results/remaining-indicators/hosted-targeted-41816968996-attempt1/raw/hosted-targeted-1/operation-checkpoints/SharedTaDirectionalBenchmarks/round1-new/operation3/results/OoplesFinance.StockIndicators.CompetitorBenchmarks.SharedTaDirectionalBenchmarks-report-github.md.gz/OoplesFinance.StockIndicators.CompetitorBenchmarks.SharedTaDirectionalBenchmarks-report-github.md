```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **217.7 μs** |  **2.20 μs** |  **1.15 μs** |       **-** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   215.0 μs |  2.12 μs |  1.26 μs |       - |   17.4 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **2,405.3 μs** | **40.99 μs** | **27.11 μs** | **31.2500** | **627.93 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,334.9 μs |  6.27 μs |  3.73 μs |       - |  158.1 KB |
