```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **520.4 μs** |  **5.23 μs** |  **2.73 μs** |       **-** |     **65 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   510.6 μs |  5.32 μs |  3.16 μs |       - |  17.41 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **5,646.9 μs** | **29.55 μs** | **15.46 μs** | **31.2500** | **628.01 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 5,718.4 μs | 40.93 μs | 24.36 μs |       - | 158.26 KB |
