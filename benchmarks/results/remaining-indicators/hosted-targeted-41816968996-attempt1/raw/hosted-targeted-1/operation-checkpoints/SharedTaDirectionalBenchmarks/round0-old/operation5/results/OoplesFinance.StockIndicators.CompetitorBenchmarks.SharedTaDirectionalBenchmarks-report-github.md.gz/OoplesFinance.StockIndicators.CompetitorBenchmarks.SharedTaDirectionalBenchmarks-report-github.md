```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **467.3 μs** |  **5.32 μs** |  **2.78 μs** |       **-** |  **65.65 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   459.8 μs |  5.37 μs |  2.81 μs |       - |  18.05 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **4,996.4 μs** | **49.49 μs** | **25.88 μs** | **31.2500** | **637.57 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 4,998.8 μs | 35.77 μs | 18.71 μs |       - |  167.7 KB |
