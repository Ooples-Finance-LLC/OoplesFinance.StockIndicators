```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **122.455 μs** |  **1.2124 μs** |  **0.7215 μs** | **13.12** |    **0.10** |       **-** |      **-** |  **65.04 KB** |        **8.43** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   119.361 μs |  1.1865 μs |  0.6206 μs | 12.79 |    0.09 |  0.9766 |      - |  17.39 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDM [23] | 1000  |     9.335 μs |  0.0881 μs |  0.0524 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 1000  |    12.504 μs |  0.6881 μs |  0.4095 μs |  1.34 |    0.04 |  1.8311 |      - |  27.23 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,343.585 μs** | **23.1028 μs** | **13.7481 μs** | **14.70** |    **0.16** | **31.2500** | **7.8125** |  **627.9 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 1,232.794 μs |  4.2666 μs |  2.2315 μs | 13.48 |    0.07 |  7.8125 |      - | 158.06 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDM [23] | 10000 |    91.433 μs |  0.7310 μs |  0.4835 μs |  1.00 |    0.01 |  4.3945 |      - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 10000 |   132.651 μs |  2.3653 μs |  1.4075 μs |  1.45 |    0.02 | 17.5781 | 3.9063 | 273.33 KB |        3.50 |
