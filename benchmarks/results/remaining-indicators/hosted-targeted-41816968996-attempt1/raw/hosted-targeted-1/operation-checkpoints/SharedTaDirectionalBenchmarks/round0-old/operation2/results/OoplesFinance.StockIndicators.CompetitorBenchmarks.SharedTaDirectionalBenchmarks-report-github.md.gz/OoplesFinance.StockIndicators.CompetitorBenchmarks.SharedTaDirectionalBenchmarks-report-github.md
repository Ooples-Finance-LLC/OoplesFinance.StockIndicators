```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **218.6 μs** |  **1.26 μs** |  **0.66 μs** |       **-** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   221.0 μs |  2.40 μs |  1.43 μs |       - |  17.39 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **2,492.3 μs** |  **9.11 μs** |  **5.42 μs** | **31.2500** | **627.96 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,511.8 μs | 84.25 μs | 55.73 μs |       - | 158.11 KB |
