```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **434.09 μs** |  **9.509 μs** |  **4.973 μs** | **32.34** |    **0.37** |       **-** |      **-** |  **66.29 KB** |        **4.42** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   425.72 μs |  4.139 μs |  2.463 μs | 31.72 |    0.22 |       - |      - |   18.7 KB |        1.25 |
| NativeSingle      | TaLib.Functions.Adxr | 1000  |    13.42 μs |  0.095 μs |  0.056 μs |  1.00 |    0.01 |  0.8545 |      - |  14.99 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 1000  |    23.94 μs |  1.168 μs |  0.772 μs |  1.78 |    0.06 |  2.9297 |      - |  45.43 KB |        3.03 |
|                   |                      |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **4,742.03 μs** | **34.455 μs** | **18.021 μs** | **35.84** |    **0.21** | **31.2500** |      **-** | **631.96 KB** |        **4.06** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 4,718.70 μs | 22.355 μs | 13.303 μs | 35.66 |    0.19 |       - |      - | 162.13 KB |        1.04 |
| NativeSingle      | TaLib.Functions.Adxr | 10000 |   132.31 μs |  1.201 μs |  0.628 μs |  1.00 |    0.01 |  8.7891 | 0.9766 | 155.62 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 10000 |   196.91 μs |  9.426 μs |  6.235 μs |  1.49 |    0.05 | 30.2734 | 8.7891 | 467.31 KB |        3.00 |
