```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDM [22]** |   **206.35 μs** |  **2.427 μs** |  **1.269 μs** |  **1.00** |  **105.67 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDM [22] |    17.63 μs |  0.713 μs |  0.424 μs |  0.09 |   40.55 KB |        0.38 |
|            |       |                      |             |           |           |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDM [22]** | **1,851.98 μs** | **17.120 μs** | **11.324 μs** |  **1.00** | **1036.73 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDM [22] |   154.03 μs |  2.630 μs |  1.565 μs |  0.08 |  330.63 KB |        0.32 |
