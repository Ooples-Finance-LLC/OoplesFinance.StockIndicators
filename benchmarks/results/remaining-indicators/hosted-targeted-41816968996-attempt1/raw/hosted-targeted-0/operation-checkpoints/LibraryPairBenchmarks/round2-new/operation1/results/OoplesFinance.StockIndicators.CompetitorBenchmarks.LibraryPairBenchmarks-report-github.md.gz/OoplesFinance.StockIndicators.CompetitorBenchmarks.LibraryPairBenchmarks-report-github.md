```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev   | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|---------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDM [23]** |   **200.95 μs** |  **1.156 μs** | **0.605 μs** |  **1.00** |  **105.67 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDM [23] |    17.62 μs |  1.178 μs | 0.779 μs |  0.09 |   40.22 KB |        0.38 |
|            |       |                      |             |           |          |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDM [23]** | **1,808.42 μs** | **14.029 μs** | **8.348 μs** |  **1.00** | **1036.73 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDM [23] |   159.50 μs | 11.791 μs | 7.799 μs |  0.09 |  330.91 KB |        0.32 |
