```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)nusDM [23]** |   **215.3 μs** | **27.35 μs** | **18.09 μs** |  **1.01** |    **0.11** |  **105.67 KB** |        **1.00** |
|        |       |                      |            |          |          |       |         |            |             |
| **Ooples** | **10000** | **TaLib(...)nusDM [23]** | **1,857.4 μs** | **21.45 μs** | **12.76 μs** |  **1.00** |    **0.01** | **1037.01 KB** |        **1.00** |
