```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Dx** |   **716.42 μs** | **37.571 μs** | **22.358 μs** |  **1.00** |    **0.04** |  **105.67 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Dx |    21.75 μs |  0.501 μs |  0.262 μs |  0.03 |    0.00 |    40.6 KB |        0.38 |
|            |       |                    |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Dx** | **6,718.67 μs** | **32.854 μs** | **21.731 μs** |  **1.00** |    **0.00** | **1036.68 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Dx |   202.96 μs |  2.878 μs |  1.505 μs |  0.03 |    0.00 |  330.92 KB |        0.32 |
