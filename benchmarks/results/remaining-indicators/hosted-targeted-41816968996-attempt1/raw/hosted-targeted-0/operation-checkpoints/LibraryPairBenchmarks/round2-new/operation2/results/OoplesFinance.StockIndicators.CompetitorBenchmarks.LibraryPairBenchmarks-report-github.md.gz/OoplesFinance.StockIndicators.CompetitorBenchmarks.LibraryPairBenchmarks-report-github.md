```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDI [22]** |   **323.38 μs** |  **3.509 μs** |  **1.835 μs** |  **1.00** |  **105.67 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDI [22] |    17.67 μs |  1.421 μs |  0.846 μs |  0.05 |   40.27 KB |        0.38 |
|            |       |                      |             |           |           |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDI [22]** | **3,073.59 μs** | **43.960 μs** | **26.160 μs** |  **1.00** | **1037.01 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDI [22] |   158.88 μs |  5.711 μs |  2.987 μs |  0.05 |  330.59 KB |        0.32 |
