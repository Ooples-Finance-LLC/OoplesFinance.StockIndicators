```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Qema** |   **379.8 μs** | **13.00 μs** |  **7.74 μs** |  **1.00** |    **0.03** |  **365.92 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Qema |   122.7 μs |  7.74 μs |  4.61 μs |  0.32 |    0.01 |  211.13 KB |        0.58 |
|            |       |                |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Qema** | **1,477.4 μs** | **25.43 μs** | **15.13 μs** |  **1.00** |    **0.01** |  **931.98 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Qema | 1,149.0 μs | 15.89 μs |  8.31 μs |  0.78 |    0.01 | 2038.92 KB |        2.19 |
