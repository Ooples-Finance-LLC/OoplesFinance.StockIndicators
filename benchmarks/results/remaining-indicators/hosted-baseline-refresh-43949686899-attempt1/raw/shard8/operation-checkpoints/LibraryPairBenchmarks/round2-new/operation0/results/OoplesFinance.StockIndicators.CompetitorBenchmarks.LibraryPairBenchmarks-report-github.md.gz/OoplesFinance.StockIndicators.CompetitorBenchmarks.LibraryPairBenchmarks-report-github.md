```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dDoji [28]** | **108.97 μs** | **30.688 μs** | **20.298 μs** |  **1.03** |    **0.24** |  **65.41 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dDoji [28] |  80.33 μs |  0.889 μs |  0.529 μs |  0.76 |    0.12 |  19.63 KB |        0.30 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)dDoji [28]** | **314.98 μs** | **17.034 μs** | **10.137 μs** |  **1.00** |    **0.04** | **637.03 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dDoji [28] | 777.20 μs | 17.187 μs | 11.368 μs |  2.47 |    0.08 | 124.77 KB |        0.20 |
