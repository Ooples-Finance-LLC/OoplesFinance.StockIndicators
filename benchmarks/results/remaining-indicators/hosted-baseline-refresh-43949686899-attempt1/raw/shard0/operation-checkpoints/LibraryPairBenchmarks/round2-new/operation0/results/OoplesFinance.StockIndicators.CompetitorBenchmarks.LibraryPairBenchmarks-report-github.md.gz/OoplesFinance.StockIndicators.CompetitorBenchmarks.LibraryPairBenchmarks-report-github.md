```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Smma** | **274.40 μs** | **11.643 μs** |  **6.929 μs** |  **1.00** |    **0.03** |  **64.82 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Smma |  39.17 μs |  0.668 μs |  0.349 μs |  0.14 |    0.00 |  49.84 KB |        0.77 |
|            |       |                |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **QuanTAlib.Smma** | **340.16 μs** | **21.330 μs** | **12.693 μs** |  **1.00** |    **0.05** | **632.86 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Smma | 362.44 μs |  1.546 μs |  0.809 μs |  1.07 |    0.04 | 474.29 KB |        0.75 |
