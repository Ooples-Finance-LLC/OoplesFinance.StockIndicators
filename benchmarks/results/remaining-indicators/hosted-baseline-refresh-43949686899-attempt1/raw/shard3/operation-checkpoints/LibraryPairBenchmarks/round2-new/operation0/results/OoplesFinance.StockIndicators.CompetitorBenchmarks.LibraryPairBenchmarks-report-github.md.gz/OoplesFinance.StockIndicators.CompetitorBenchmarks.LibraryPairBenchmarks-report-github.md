```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Lines [29]** |  **98.03 μs** |  **1.124 μs** |  **0.669 μs** |  **1.00** |    **0.01** |  **72.84 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Lines [29] |  67.66 μs |  0.491 μs |  0.292 μs |  0.69 |    0.01 |  18.27 KB |        0.25 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Lines [29]** | **686.36 μs** | **23.181 μs** | **12.124 μs** |  **1.00** |    **0.02** | **643.46 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Lines [29] | 646.91 μs | 29.792 μs | 19.706 μs |  0.94 |    0.03 | 124.39 KB |        0.19 |
