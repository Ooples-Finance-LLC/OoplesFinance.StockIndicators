```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)alled [21]** |   **122.31 μs** |  **21.009 μs** |  **12.502 μs** |  **1.01** |    **0.14** |  **73.16 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)alled [21] |    99.11 μs |   1.405 μs |   0.836 μs |  0.82 |    0.08 |  19.58 KB |        0.27 |
|            |       |                      |             |            |            |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)alled [21]** | **1,216.18 μs** | **497.142 μs** | **328.828 μs** |  **1.08** |    **0.42** | **643.54 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)alled [21] |   993.52 μs |  55.299 μs |  32.908 μs |  0.88 |    0.26 | 125.38 KB |        0.19 |
