```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error       | StdDev      | Ratio | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |--------------- |-----------:|------------:|------------:|------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Skew** |   **526.7 μs** |    **40.72 μs** |    **26.94 μs** |  **1.00** |    **0.07** |   **956.55 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Skew |   919.1 μs |    26.99 μs |    17.85 μs |  1.75 |    0.09 |   401.12 KB |        0.42 |
|            |       |                |            |             |             |       |         |             |             |
| **Ooples**     | **10000** | **QuanTAlib.Skew** | **6,589.7 μs** | **2,186.80 μs** | **1,446.43 μs** |  **1.04** |    **0.30** | **10966.16 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Skew | 9,188.9 μs |    73.88 μs |    43.96 μs |  1.45 |    0.28 |  3976.79 KB |        0.36 |
