```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId          | Mean      | Error    | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |---------------- |----------:|---------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetSmma** |  **97.51 μs** | **12.76 μs** |  **7.595 μs** |  **1.01** |    **0.10** |  **64.82 KB** |        **1.00** |
|        |       |                 |           |          |           |       |         |           |             |
| **Ooples** | **10000** | **Skender.GetSmma** | **450.08 μs** | **24.29 μs** | **14.453 μs** |  **1.00** |    **0.04** | **627.61 KB** |        **1.00** |
