```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId          | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |---------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetSmma** | **100.20 μs** |  **5.982 μs** |  **3.129 μs** |  **1.00** |    **0.04** |  **64.82 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetSmma |  51.20 μs | 14.489 μs |  9.584 μs |  0.51 |    0.09 |  97.66 KB |        1.51 |
|            |       |                 |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **Skender.GetSmma** | **450.64 μs** | **27.518 μs** | **16.376 μs** |  **1.00** |    **0.05** | **635.16 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetSmma | 435.27 μs | 34.870 μs | 23.064 μs |  0.97 |    0.06 | 904.94 KB |        1.42 |
