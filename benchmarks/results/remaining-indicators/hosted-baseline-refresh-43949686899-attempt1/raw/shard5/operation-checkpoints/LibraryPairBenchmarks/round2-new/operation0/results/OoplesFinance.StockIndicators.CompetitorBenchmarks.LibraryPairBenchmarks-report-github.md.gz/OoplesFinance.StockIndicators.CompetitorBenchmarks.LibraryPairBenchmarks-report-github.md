```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean      | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |----------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetDynamic** | **219.18 μs** | **178.286 μs** | **117.925 μs** |  **1.34** |    **1.08** |   **99.09 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetDynamic |  59.12 μs |   5.214 μs |   3.449 μs |  0.36 |    0.20 |  107.78 KB |        1.09 |
|            |       |                    |           |            |            |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetDynamic** | **494.34 μs** |   **6.071 μs** |   **3.613 μs** |  **1.00** |    **0.01** |  **868.98 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetDynamic | 546.60 μs |   9.797 μs |   6.480 μs |  1.11 |    0.01 | 1072.96 KB |        1.23 |
