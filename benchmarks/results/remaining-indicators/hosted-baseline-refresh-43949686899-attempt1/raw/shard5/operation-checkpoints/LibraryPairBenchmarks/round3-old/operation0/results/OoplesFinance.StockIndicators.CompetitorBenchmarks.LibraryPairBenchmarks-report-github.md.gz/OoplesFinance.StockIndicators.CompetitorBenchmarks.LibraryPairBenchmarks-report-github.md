```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId             | Mean     | Error   | StdDev  | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |------------------- |---------:|--------:|--------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetDynamic** | **106.1 μs** | **9.71 μs** | **5.78 μs** |  **1.00** |    **0.07** |  **99.09 KB** |        **1.00** |
|        |       |                    |          |         |         |       |         |           |             |
| **Ooples** | **10000** | **Skender.GetDynamic** | **478.2 μs** | **8.57 μs** | **5.10 μs** |  **1.00** |    **0.01** | **871.61 KB** |        **1.00** |
