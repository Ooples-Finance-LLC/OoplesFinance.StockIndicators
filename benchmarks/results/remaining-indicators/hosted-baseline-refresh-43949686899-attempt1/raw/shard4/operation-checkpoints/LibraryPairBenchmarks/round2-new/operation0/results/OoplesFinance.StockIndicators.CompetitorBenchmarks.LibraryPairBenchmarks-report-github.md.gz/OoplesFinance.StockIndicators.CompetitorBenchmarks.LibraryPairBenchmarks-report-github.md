```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Crows [31]** | **434.01 μs** | **35.225 μs** | **20.962 μs** |  **1.00** |    **0.07** |  **68.66 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Crows [31] |  48.96 μs |  0.793 μs |  0.472 μs |  0.11 |    0.01 |  17.94 KB |        0.26 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Crows [31]** | **524.61 μs** | **31.230 μs** | **16.334 μs** |  **1.00** |    **0.04** | **639.28 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Crows [31] | 522.63 μs | 26.925 μs | 16.023 μs |  1.00 |    0.04 | 125.38 KB |        0.20 |
