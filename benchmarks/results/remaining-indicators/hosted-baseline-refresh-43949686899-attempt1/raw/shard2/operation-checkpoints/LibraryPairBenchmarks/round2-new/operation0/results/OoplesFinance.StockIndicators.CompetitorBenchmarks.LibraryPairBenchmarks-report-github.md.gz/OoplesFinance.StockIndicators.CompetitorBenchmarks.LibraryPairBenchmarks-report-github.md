```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)South [31]** |  **54.81 μs** |  **1.804 μs** |  **0.943 μs** |  **1.00** |    **0.02** |  **71.66 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)South [31] |  55.92 μs |  0.466 μs |  0.277 μs |  1.02 |    0.02 |  16.95 KB |        0.24 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)South [31]** | **326.18 μs** |  **3.313 μs** |  **1.733 μs** |  **1.00** |    **0.01** | **641.26 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)South [31] | 543.63 μs | 16.432 μs | 10.869 μs |  1.67 |    0.03 | 122.75 KB |        0.19 |
