from pathlib import Path
import collections,datetime,hashlib,html,json,re,shutil
ROOT=Path('C:/Users/cheat/StockIndicators-Recovery-20261021');REPO=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022');RUN='39731236000'
live=Path('C:/Users/cheat/Documents/OoplesFinance-Reports/competitor-performance.html');out=live.parent/('cpu-builder-refresh-'+RUN);out.mkdir(exist_ok=True);assert not (out/'before.html').exists()
original=live.read_bytes();s=original.decode('utf-8')
def embedded(name):return json.loads(re.search(r'<script[^>]*id="'+name+r'"[^>]*>(.*?)</script>',s,re.S)[1])
def replace(name,value):
 global s
 s,n=re.subn(r'(<script[^>]*id="'+name+r'"[^>]*>).*?(</script>)',lambda m:m[1]+json.dumps(value,ensure_ascii=True).replace('<','\\u003c')+m[2],s,flags=re.S);assert n==1
baseline=embedded('dataset');archive=embedded('archived-baseline-dataset');builder=embedded('current-competitor-data');status=embedded('rollout-status-data')
assert len(builder['receipts'])==1 and builder['verdicts']=={'faster':4,'slower':0,'inconclusive':0}
evidence=REPO/'benchmarks/results/remaining-indicators';summary=json.loads((evidence/('cpu-builder-'+RUN+'-summary.json')).read_text());assert summary['comparisons']==76 and summary['apis']==19
receipts=builder['receipts']+[json.loads((evidence/n).read_text()) for n in summary['receipt_files']]
seen=set();rows=[]
for receipt in receipts:
 assert receipt['complete'] and receipt['source_sha']=='29a41d8b7956a05812a5950631f07b84bcb04ee0' and str(receipt['run_id']).isdigit()
 for r in receipt['comparisons']:
  key=r['pair'],r['bars'],r['mode'];assert key not in seen;seen.add(key);rows.append({**r,'run_id':str(receipt['run_id']),'source_sha':receipt['source_sha']})
assert len(rows)==80 and len({r['pair'] for r in rows})==20
counts={v:sum(r['verdict']==v for r in rows) for v in ['faster','slower','inconclusive']};assert counts=={'faster':27,'slower':53,'inconclusive':0}
now=datetime.datetime.now(datetime.timezone.utc).isoformat();builder.update(receipts=receipts,full_comparisons=80,verdicts=counts,status={'commit':summary['source_sha'],'status':'seven-fixtures-measured','updated_utc':now,'completed':['SharedFibonacciWeightedBenchmarks']+[r['fixture'] for r in receipts[1:]],'failed':[],'qualification':'Matched native serial/parallel measurements; partial coverage, not universal superiority.','run_url':'https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/'+RUN});replace('current-competitor-data',builder)
assert status['measurement_totals']['expected']==1604 and status['measurement_totals']['measured']==4
oldhead=status['published_head'];head='1c08e682ca53a8cb23fcd742d05377af0c64eabd';status.update(updated_utc=now,published_head=head,inventory_commit=head)
status['builder_measurement_sources'].append({'source_sha':summary['source_sha'],'run_url':builder['status']['run_url'],'comparisons':76,'changed_production_files_since_baseline':summary['changed_production_files_since_baseline']})
status['measurement_totals'].update(**counts,measured=80,pending=1524);replace('rollout-status-data',status)
m=re.search(r'<section id="rollout-status".*?</section>',s,re.S);panel=m[0];assert '<b>4 / 1604</b>' in panel;panel=panel.replace('<b>4 / 1604</b>','<b>80 / 1604</b>')
old='Builder-mode timing: 4 faster, 0 slower, 0 inconclusive, and 1600 pending.';assert old in panel;panel=panel.replace(old,'Builder-mode timing: 27 faster, 53 slower, 0 inconclusive, and 1524 pending.')
panel=panel.replace('Fibonacci has matched measurements at period 20 in both history modes; its public batch snapshot is a separate, slower path.','Twenty API pairs have matched builder measurements in both sizes and history modes. Public batch snapshots are separate paths; their timings remain in the baseline above.').replace(oldhead[:8],head[:8]);s=s[:m.start()]+panel+s[m.end():]
body=[]
for r in sorted(rows,key=lambda r:(r['pair'],r['bars'],r['mode'])):
 verdict={'faster':'Faster than both','slower':'Slower than at least one','inconclusive':'Inconclusive'}[r['verdict']]
 values=[r['pair'],f"{r['bars']:,}",'Full history' if r['mode']=='BuilderFull' else 'Latest only',f"{r['ooples']['mean_ns']/1e6:.6f}",f"{r['native']['NativeSingle']['mean_ns']/1e6:.6f}",f"{r['native']['NativeParallel']['mean_ns']/1e6:.6f}",verdict]
 link='<a href="https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/'+r['run_id']+'">'+r['run_id']+'</a>'
 body.append('<tr data-builder-pair="'+html.escape(r['pair'],quote=True)+'" data-bars="'+str(r['bars'])+'" data-mode="'+r['mode']+'">'+''.join('<td>'+html.escape(x)+'</td>' for x in values)+'<td>'+link+'</td></tr>')
headers=['API','Bars','Builder history','Ooples ms','Native serial ms','Native parallel ms','Confidence verdict','Run']
section='<section id="current-competitors" class="section"><h2>Builder-mode qualification progress</h2><p>80 / 1604 matched slots measured across 20 API pairs: 27 faster, 53 slower, 0 inconclusive, 1524 pending. These count API pair × input size × history mode and are separate from the 802 batch comparisons above.</p><p>Both history modes are measured against serial and parallel native calls on the same runner for each fixture. Faster requires the builder confidence interval to lie below both native intervals; slower means at least one native interval lies below the builder interval. Ten warmups and ten requested iterations; raw reports retain the samples and intervals.</p><p>Fibonacci demonstrates why paths are separate: its exact rolling builder is faster, while its public batch snapshot rescans windows and remains slower. Neither a builder win nor a batch win qualifies the other path.</p><div class="panel tablewrap"><table id="builder-current-results"><thead><tr>'+''.join('<th>'+x+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join(body)+'</tbody></table></div><p>Measured source <code>'+summary['source_sha']+'</code>. Relevant implementations and fixtures match published code; the later SMA error-diagnostics change is separate. Qualification covers these registered configurations, two sizes, and two history modes, not every parameter or universal superiority.</p></section>'
s,n=re.subn(r'<section id="current-competitors".*?</section>',lambda _:section,s,flags=re.S);assert n==1
s,n=re.subn(r'<tr><td>Current matched candidate</td>.*?</tr>',lambda _:'<tr><td>Current matched candidate</td><td>80 / 1604</td><td>API pair × two sizes × two history modes</td><td>Only qualified same-run measurements; pending is not a win</td></tr>',s,count=1,flags=re.S)
assert embedded('dataset')==baseline and embedded('archived-baseline-dataset')==archive
(out/'before.html').write_bytes(original);(out/'candidate.html').write_text(s,encoding='utf-8');shutil.copyfile(live.parent/'sma-refresh-39727929133/measurement.json',out/'measurement.json')
(out/'staged.json').write_text(json.dumps({'before_sha256':hashlib.sha256(original).hexdigest(),'candidate_sha256':hashlib.sha256((out/'candidate.html').read_bytes()).hexdigest(),'builder_run_id':RUN,'builder_comparisons':80,'new_builder_comparisons':76,'unchanged_baseline_comparisons':802,'rows':rows,'verdicts':counts},indent=2))
print('Staged80 builder slots:27faster/53slower/1524pending; baseline802 unchanged')
