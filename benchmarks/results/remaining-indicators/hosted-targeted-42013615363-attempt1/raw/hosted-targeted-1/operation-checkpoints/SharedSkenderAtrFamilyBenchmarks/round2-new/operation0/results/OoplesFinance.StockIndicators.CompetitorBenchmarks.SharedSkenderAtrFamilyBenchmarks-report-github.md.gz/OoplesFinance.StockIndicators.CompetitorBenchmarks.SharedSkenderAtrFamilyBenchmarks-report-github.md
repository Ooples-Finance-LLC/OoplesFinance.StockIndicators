```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)Bands [21]** | **1000**  |   **207.12 μs** |  **3.776 μs** |  **2.247 μs** |  **2.21** |    **0.03** |        **-** |        **-** |       **-** |   **97.39 KB** |        **0.30** |
| BuilderLatestOnly | Skend(...)Bands [21] | 1000  |   210.45 μs |  6.235 μs |  4.124 μs |  2.24 |    0.04 |   1.9531 |        - |       - |   49.79 KB |        0.15 |
| NativeSingle      | Skend(...)Bands [21] | 1000  |    93.76 μs |  1.030 μs |  0.539 μs |  1.00 |    0.01 |  20.0195 |   5.3711 |       - |  329.24 KB |        1.00 |
| NativeParallel    | Skend(...)Bands [21] | 1000  |   160.46 μs | 13.263 μs |  8.773 μs |  1.71 |    0.09 |  52.7344 |  19.5313 |       - |  832.71 KB |        2.53 |
|                   |                      |       |             |           |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)Bands [21]** | **10000** | **2,257.24 μs** | **18.375 μs** | **10.935 μs** |  **1.80** |    **0.03** |  **46.8750** |  **15.6250** |       **-** |  **941.56 KB** |        **0.29** |
| BuilderLatestOnly | Skend(...)Bands [21] | 10000 | 2,263.85 μs | 48.629 μs | 32.165 μs |  1.81 |    0.04 |  15.6250 |        - |       - |  471.76 KB |        0.14 |
| NativeSingle      | Skend(...)Bands [21] | 10000 | 1,252.50 μs | 29.527 μs | 19.530 μs |  1.00 |    0.02 | 195.3125 | 148.4375 | 46.8750 | 3282.76 KB |        1.00 |
| NativeParallel    | Skend(...)Bands [21] | 10000 | 2,348.86 μs | 54.520 μs | 32.444 μs |  1.88 |    0.04 | 515.6250 | 453.1250 | 78.1250 | 8286.56 KB |        2.52 |
