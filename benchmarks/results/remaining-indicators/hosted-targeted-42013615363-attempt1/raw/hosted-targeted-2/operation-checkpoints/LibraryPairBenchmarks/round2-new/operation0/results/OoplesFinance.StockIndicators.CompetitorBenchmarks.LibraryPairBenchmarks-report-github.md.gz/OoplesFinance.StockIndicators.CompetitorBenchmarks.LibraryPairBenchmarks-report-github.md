```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)nnels [31]** |    **388.1 μs** |    **31.44 μs** |    **20.79 μs** |  **1.00** |    **0.07** |         **-** |         **-** |         **-** |   **218.84 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)nnels [31] |  2,201.8 μs |    39.10 μs |    25.86 μs |  5.69 |    0.29 |         - |         - |         - |  3460.72 KB |       15.81 |
|            |       |                      |             |             |             |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)nnels [31]** |  **3,380.6 μs** |    **53.68 μs** |    **31.94 μs** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |   **2151.2 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)nnels [31] | 32,977.4 μs | 9,370.64 μs | 6,198.10 μs |  9.76 |    1.75 | 1000.0000 | 1000.0000 | 1000.0000 | 33800.76 KB |       15.71 |
