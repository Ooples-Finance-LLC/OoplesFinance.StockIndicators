```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **KeltnerChannels** | **1000**  |   **274.3 μs** |  **9.83 μs** |  **5.85 μs** |  **96.83 KB** |
| BuilderLatestOnly | KeltnerChannels | 1000  |   266.7 μs |  2.59 μs |  1.71 μs |  49.21 KB |
| **BuilderFull**       | **KeltnerChannels** | **10000** | **2,836.8 μs** | **27.06 μs** | **14.15 μs** | **941.02 KB** |
| BuilderLatestOnly | KeltnerChannels | 10000 | 2,780.6 μs | 39.90 μs | 26.39 μs | 471.18 KB |
