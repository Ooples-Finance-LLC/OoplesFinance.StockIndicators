```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **KeltnerChannels** | **1000**  |   **273.2 μs** |  **3.11 μs** |  **1.85 μs** |  **96.83 KB** |
| BuilderLatestOnly | KeltnerChannels | 1000  |   264.7 μs |  1.93 μs |  1.01 μs |  49.23 KB |
| **BuilderFull**       | **KeltnerChannels** | **10000** | **2,817.0 μs** | **27.36 μs** | **14.31 μs** | **941.03 KB** |
| BuilderLatestOnly | KeltnerChannels | 10000 | 2,734.7 μs | 25.51 μs | 15.18 μs | 471.21 KB |
