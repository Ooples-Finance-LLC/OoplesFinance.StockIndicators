```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **KeltnerChannels** | **1000**  |   **282.2 μs** | **14.04 μs** |  **8.35 μs** |  **96.83 KB** |
| BuilderLatestOnly | KeltnerChannels | 1000  |   263.9 μs |  2.24 μs |  1.48 μs |  49.21 KB |
| **BuilderFull**       | **KeltnerChannels** | **10000** | **2,786.2 μs** | **14.59 μs** |  **7.63 μs** | **941.15 KB** |
| BuilderLatestOnly | KeltnerChannels | 10000 | 2,708.0 μs | 20.86 μs | 10.91 μs |  471.2 KB |
