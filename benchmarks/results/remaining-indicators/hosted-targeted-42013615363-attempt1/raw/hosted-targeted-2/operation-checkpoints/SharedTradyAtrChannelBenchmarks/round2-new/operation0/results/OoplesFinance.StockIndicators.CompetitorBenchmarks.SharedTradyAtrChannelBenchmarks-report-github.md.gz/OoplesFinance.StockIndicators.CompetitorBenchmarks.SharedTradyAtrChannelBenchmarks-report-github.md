```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |---------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **KeltnerChannels** | **1000**  |    **276.3 μs** |     **2.71 μs** |     **1.42 μs** |  **0.16** |    **0.01** |         **-** |         **-** |         **-** |    **96.83 KB** |        **0.04** |
| BuilderLatestOnly | KeltnerChannels | 1000  |    264.9 μs |     2.61 μs |     1.37 μs |  0.15 |    0.01 |         - |         - |         - |    49.23 KB |        0.02 |
| NativeSingle      | KeltnerChannels | 1000  |  1,763.2 μs |   116.08 μs |    76.78 μs |  1.00 |    0.06 |   46.8750 |   46.8750 |   46.8750 |  2743.29 KB |        1.00 |
| NativeParallel    | KeltnerChannels | 1000  |  1,293.8 μs |    60.79 μs |    40.21 μs |  0.74 |    0.04 |   54.6875 |   46.8750 |         - |  4354.12 KB |        1.59 |
|                   |                 |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **KeltnerChannels** | **10000** |  **2,807.6 μs** |    **47.94 μs** |    **28.53 μs** |  **0.12** |    **0.01** |         **-** |         **-** |         **-** |   **941.03 KB** |        **0.04** |
| BuilderLatestOnly | KeltnerChannels | 10000 |  2,707.0 μs |    32.49 μs |    16.99 μs |  0.12 |    0.00 |         - |         - |         - |   471.21 KB |        0.02 |
| NativeSingle      | KeltnerChannels | 10000 | 22,927.2 μs | 1,864.14 μs |   974.98 μs |  1.00 |    0.06 | 1000.0000 | 1000.0000 | 1000.0000 | 26655.43 KB |        1.00 |
| NativeParallel    | KeltnerChannels | 10000 | 23,687.4 μs | 3,450.53 μs | 2,282.31 μs |  1.03 |    0.10 | 1400.0000 | 1200.0000 | 1200.0000 | 42688.96 KB |        1.60 |
