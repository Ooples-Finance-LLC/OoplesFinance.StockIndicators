```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated  |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetKeltner** | **1000**  |   **187.5 μs** |  **5.19 μs** |  **3.09 μs** |       **-** |       **-** |  **104.66 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 1000  |   186.5 μs |  4.54 μs |  3.00 μs |  2.9297 |       - |   57.05 KB |
| **BuilderFull**       | **Skender.GetKeltner** | **10000** | **1,887.2 μs** | **36.45 μs** | **24.11 μs** | **46.8750** | **15.6250** | **1019.15 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 10000 | 1,876.5 μs | 45.11 μs | 26.84 μs | 31.2500 | 15.6250 |  549.31 KB |
