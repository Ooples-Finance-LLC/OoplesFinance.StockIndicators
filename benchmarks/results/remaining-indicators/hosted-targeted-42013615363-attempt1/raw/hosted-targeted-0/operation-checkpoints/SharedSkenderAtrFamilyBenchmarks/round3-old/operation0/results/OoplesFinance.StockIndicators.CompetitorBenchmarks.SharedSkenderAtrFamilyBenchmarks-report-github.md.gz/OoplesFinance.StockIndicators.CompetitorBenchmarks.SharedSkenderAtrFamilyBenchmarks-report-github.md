```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated  |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetKeltner** | **1000**  |   **188.2 μs** |  **5.40 μs** |  **3.21 μs** |       **-** |       **-** |  **104.66 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 1000  |   194.2 μs |  8.98 μs |  5.94 μs |  2.9297 |       - |   57.05 KB |
| **BuilderFull**       | **Skender.GetKeltner** | **10000** | **1,909.3 μs** | **60.21 μs** | **39.82 μs** | **46.8750** | **15.6250** | **1019.15 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 10000 | 1,853.7 μs | 21.16 μs | 13.99 μs | 31.2500 | 15.6250 |  549.33 KB |
