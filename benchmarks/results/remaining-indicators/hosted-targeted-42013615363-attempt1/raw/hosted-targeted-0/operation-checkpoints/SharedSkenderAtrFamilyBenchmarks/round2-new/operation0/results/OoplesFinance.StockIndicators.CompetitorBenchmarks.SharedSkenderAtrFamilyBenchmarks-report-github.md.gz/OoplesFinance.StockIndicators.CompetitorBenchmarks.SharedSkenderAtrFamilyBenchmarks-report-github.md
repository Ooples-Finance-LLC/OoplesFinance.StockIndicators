```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |------------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetKeltner** | **1000**  |   **167.62 μs** |   **2.519 μs** |  **1.499 μs** |  **2.88** |    **0.10** |        **-** |        **-** |       **-** |  **104.66 KB** |        **0.29** |
| BuilderLatestOnly | Skender.GetKeltner | 1000  |   169.48 μs |   2.156 μs |  1.426 μs |  2.91 |    0.10 |   2.9297 |        - |       - |   57.05 KB |        0.16 |
| NativeSingle      | Skender.GetKeltner | 1000  |    58.28 μs |   3.469 μs |  2.065 μs |  1.00 |    0.05 |  21.9727 |   6.3477 |       - |  360.53 KB |        1.00 |
| NativeParallel    | Skender.GetKeltner | 1000  |   109.89 μs |   5.815 μs |  3.846 μs |  1.89 |    0.09 |  57.6172 |  22.4609 |       - |  910.99 KB |        2.53 |
|                   |                    |       |             |            |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skender.GetKeltner** | **10000** | **1,678.69 μs** |  **19.878 μs** | **11.829 μs** |  **2.07** |    **0.05** |  **46.8750** |  **15.6250** |       **-** | **1019.15 KB** |        **0.28** |
| BuilderLatestOnly | Skender.GetKeltner | 10000 | 1,661.72 μs |  12.272 μs |  7.303 μs |  2.05 |    0.05 |  31.2500 |  15.6250 |       - |  549.31 KB |        0.15 |
| NativeSingle      | Skender.GetKeltner | 10000 |   812.07 μs |  33.755 μs | 20.087 μs |  1.00 |    0.03 | 218.7500 | 164.0625 | 46.8750 | 3595.29 KB |        1.00 |
| NativeParallel    | Skender.GetKeltner | 10000 | 1,604.38 μs | 135.579 μs | 89.677 μs |  1.98 |    0.11 | 593.7500 | 484.3750 | 78.1250 |  9068.2 KB |        2.52 |
