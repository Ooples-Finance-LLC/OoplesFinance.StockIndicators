```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated  |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetKeltner** | **1000**  |   **165.9 μs** |  **3.93 μs** |  **2.06 μs** |  **3.9063** |       **-** |  **104.66 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 1000  |   168.3 μs |  3.82 μs |  2.27 μs |  2.9297 |       - |   57.05 KB |
| **BuilderFull**       | **Skender.GetKeltner** | **10000** | **1,698.7 μs** | **27.24 μs** | **16.21 μs** | **46.8750** | **15.6250** | **1019.15 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 10000 | 1,704.7 μs | 14.91 μs |  8.87 μs | 31.2500 | 15.6250 |  549.33 KB |
