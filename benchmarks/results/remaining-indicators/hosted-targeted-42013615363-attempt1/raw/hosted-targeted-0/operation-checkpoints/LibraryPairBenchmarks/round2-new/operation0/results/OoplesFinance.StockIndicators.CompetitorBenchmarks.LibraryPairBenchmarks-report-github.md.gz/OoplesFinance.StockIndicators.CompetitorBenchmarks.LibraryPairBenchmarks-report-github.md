```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean        | Error    | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |------------:|---------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetKeltner** |   **243.00 μs** | **14.14 μs** |  **8.413 μs** |  **1.00** |    **0.05** |  **267.51 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetKeltner |    65.72 μs | 11.60 μs |  6.904 μs |  0.27 |    0.03 |  470.56 KB |        1.76 |
|            |       |                    |             |          |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetKeltner** | **2,224.70 μs** | **15.38 μs** |  **9.152 μs** |  **1.00** |    **0.01** | **2623.64 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetKeltner |   698.74 μs | 27.55 μs | 16.397 μs |  0.31 |    0.01 |  4653.5 KB |        1.77 |
