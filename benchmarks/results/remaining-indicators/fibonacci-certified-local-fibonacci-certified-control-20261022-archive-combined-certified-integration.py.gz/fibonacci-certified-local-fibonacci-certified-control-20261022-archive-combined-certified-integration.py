"""Preserve merged-source checks without replacing historical qualifications."""
from pathlib import Path
import sys
import gzip
import hashlib
import importlib.util
import json
import subprocess
import xml.etree.ElementTree as ET

name='combined-integration'
expected={'combined-integration':(74,78)}
assert name in expected
repo=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC')/'si-parabolic-array-rollback-20261022'
root=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')/'combined-certified-integration-20261022'
state = json.loads((root / 'status.json').read_text())
assert state['status'] == 'checks-passed-review-and-publication-pending'
assert state['input_head'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert state['gpu_passed'] == 100
assert all(state['checks'][k] == 'passed' for k in ('build-benchmark', 'build-comparator', 'parity', 'gpu-source-verification', 'inventory-tests'))
assert state['checks']['build-unit']=='passed' and state['checks']['unit']=='passed'
assert (state['unit']['passed'],state['parity']['passed'])==expected[name]
assert len(set(state['production_dll_sha256'].values())) == 1
stem = f'benchmarks/results/remaining-indicators/publication-{name}-certified-20261022'
if 'hosted_build' in state:
    raw=(root/'hosted-build-provenance.json').read_bytes()
    proof=json.loads(raw)
    assert proof['manifest']['source_sha']==state['input_head']
    assert proof['run']['conclusion']==proof['job']['conclusion']=='success'
    assert proof['run']['id']==state['hosted_build']['run_id']
    path=stem+'-hosted-build-provenance.json.gz'
    (repo/path).write_bytes(gzip.compress(raw,mtime=0))
    state['hosted_build']['archived_file']=path
    state['hosted_build']['sha256']=hashlib.sha256(raw).hexdigest()

for label in ('unit', 'parity'):
    raw = Path(state[label]['trx']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == state[label]['sha256']
    tree = ET.fromstring(raw)
    assert tree.find('.//{*}ResultSummary').attrib['outcome'] == 'Completed'
    results = tree.findall('.//{*}UnitTestResult')
    assert len(results) == state[label]['passed'] and all(r.attrib['outcome'] == 'Passed' for r in results)
    path = stem + '-' + label + '.trx.gz'
    (repo / path).write_bytes(gzip.compress(raw, mtime=0))
    state[label]['archived_file'] = path

spec = importlib.util.spec_from_file_location('gpu', repo / 'scripts/verify-competitor-local-gpu.py')
gpu = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gpu)
receipt = json.loads((gpu.EVIDENCE / 'receipt.json').read_text())
raw = gzip.decompress((gpu.EVIDENCE / 'gpu.trx.gz').read_bytes())
gpu.verify_evidence(receipt, raw, json.loads(gpu.METHODS.read_text()), gpu.source_fingerprint(repo))
state['source_fingerprint_sha256'] = receipt['source_sha256']
state['inventory_tests_passed'] = 8
state['performance'] = 'Individual candidate controlled measurements remain independently archived; combined verification establishes correctness, not new timing values.'
state['evidence_note'] = state['batch_note']+' Combined correctness checks passed; individual controlled measurements retain their original source identities.'
(repo / (stem + '-verification.json')).write_text(json.dumps(state, indent=2) + '\n')
subprocess.run(['git', 'diff', '--check'], cwd=repo, check=True)
print(f'Archived verified {name} correctness checks; controlled timing and publication pending.')
