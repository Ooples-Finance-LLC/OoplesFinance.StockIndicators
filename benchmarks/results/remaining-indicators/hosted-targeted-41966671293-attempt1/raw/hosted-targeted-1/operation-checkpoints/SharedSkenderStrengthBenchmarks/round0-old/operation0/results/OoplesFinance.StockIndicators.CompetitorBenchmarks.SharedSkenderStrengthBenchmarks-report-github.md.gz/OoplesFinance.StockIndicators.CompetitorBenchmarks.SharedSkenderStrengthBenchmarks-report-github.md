```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev   | Allocated  |
|------------------ |--------------- |------ |-----------:|----------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetAdx** | **1000**  | **1,002.3 μs** |  **43.07 μs** | **28.49 μs** |  **113.81 KB** |
| BuilderLatestOnly | Skender.GetAdx | 1000  |   955.7 μs |  10.90 μs |  6.49 μs |   66.18 KB |
| **BuilderFull**       | **Skender.GetAdx** | **10000** | **9,894.9 μs** | **108.49 μs** | **64.56 μs** | **1099.17 KB** |
| BuilderLatestOnly | Skender.GetAdx | 10000 | 9,962.5 μs |  83.47 μs | 49.67 μs |  629.36 KB |
