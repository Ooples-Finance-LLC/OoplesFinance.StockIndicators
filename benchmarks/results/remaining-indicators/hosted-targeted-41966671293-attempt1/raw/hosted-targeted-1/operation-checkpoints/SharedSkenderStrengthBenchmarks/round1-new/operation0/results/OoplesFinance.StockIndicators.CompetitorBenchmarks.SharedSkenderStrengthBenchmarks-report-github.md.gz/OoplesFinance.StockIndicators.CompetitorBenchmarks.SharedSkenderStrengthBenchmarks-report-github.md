```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Allocated  |
|------------------ |--------------- |------ |-----------:|----------:|----------:|-----------:|
| **BuilderFull**       | **Skender.GetAdx** | **1000**  |   **866.4 μs** |  **12.75 μs** |   **7.59 μs** |  **113.73 KB** |
| BuilderLatestOnly | Skender.GetAdx | 1000  |   865.5 μs |  10.28 μs |   6.12 μs |   66.18 KB |
| **BuilderFull**       | **Skender.GetAdx** | **10000** | **9,091.0 μs** | **447.23 μs** | **266.14 μs** | **1099.14 KB** |
| BuilderLatestOnly | Skender.GetAdx | 10000 | 8,783.3 μs | 107.35 μs |  71.01 μs |   629.3 KB |
