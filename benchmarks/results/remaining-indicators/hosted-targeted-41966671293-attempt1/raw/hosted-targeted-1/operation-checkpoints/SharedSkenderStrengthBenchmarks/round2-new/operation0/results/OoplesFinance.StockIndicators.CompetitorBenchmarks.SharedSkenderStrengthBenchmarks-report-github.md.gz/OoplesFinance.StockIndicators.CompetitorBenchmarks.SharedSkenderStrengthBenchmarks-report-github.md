```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAdx** | **1000**  |   **867.72 μs** |  **51.205 μs** | **33.869 μs** | **11.21** |    **0.43** |        **-** |        **-** |  **113.81 KB** |        **0.57** |
| BuilderLatestOnly | Skender.GetAdx | 1000  |   834.15 μs |   9.881 μs |  6.536 μs | 10.78 |    0.13 |        - |        - |   66.18 KB |        0.33 |
| NativeSingle      | Skender.GetAdx | 1000  |    77.39 μs |   1.137 μs |  0.752 μs |  1.00 |    0.01 |   7.8125 |   2.4414 |  199.68 KB |        1.00 |
| NativeParallel    | Skender.GetAdx | 1000  |   140.81 μs |  15.204 μs | 10.057 μs |  1.82 |    0.13 |  21.4844 |   7.8125 |  507.82 KB |        2.54 |
|                   |                |       |             |            |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetAdx** | **10000** | **8,625.16 μs** |  **85.495 μs** | **50.877 μs** |  **9.25** |    **0.08** |        **-** |        **-** | **1099.11 KB** |        **0.55** |
| BuilderLatestOnly | Skender.GetAdx | 10000 | 8,453.85 μs | 115.128 μs | 76.150 μs |  9.07 |    0.10 |        - |        - |   629.3 KB |        0.32 |
| NativeSingle      | Skender.GetAdx | 10000 |   932.47 μs |   9.327 μs |  6.169 μs |  1.00 |    0.01 |  78.1250 |  31.2500 |  1992.7 KB |        1.00 |
| NativeParallel    | Skender.GetAdx | 10000 | 1,602.26 μs |  73.302 μs | 38.338 μs |  1.72 |    0.04 | 203.1250 | 125.0000 | 5060.67 KB |        2.54 |
