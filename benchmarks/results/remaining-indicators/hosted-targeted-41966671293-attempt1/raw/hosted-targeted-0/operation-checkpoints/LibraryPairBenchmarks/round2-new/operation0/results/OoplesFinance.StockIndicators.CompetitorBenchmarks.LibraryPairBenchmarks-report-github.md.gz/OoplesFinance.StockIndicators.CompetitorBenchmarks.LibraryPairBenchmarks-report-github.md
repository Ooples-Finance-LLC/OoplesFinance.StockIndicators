```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAdx** |  **1,125.2 μs** | **78.14 μs** | **46.50 μs** |  **1.00** |    **0.05** |  **316.88 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAdx |    102.5 μs |  4.13 μs |  2.16 μs |  0.09 |    0.00 |  339.11 KB |        1.07 |
|            |       |                |             |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAdx** | **10,798.5 μs** | **71.82 μs** | **37.56 μs** |  **1.00** |    **0.00** | **3110.89 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAdx |  1,072.7 μs | 32.51 μs | 19.35 μs |  0.10 |    0.00 | 3301.07 KB |        1.06 |
