"""Small synthetic fixtures for the diagnostic launch gate and bounded extraction."""
import importlib.util
import math
from pathlib import Path
import tempfile
import unittest
import zipfile

spec = importlib.util.spec_from_file_location('reviewed_roi_collector',
    Path(__file__).with_name('collect-reviewed-roi-artifact-20261116.py'))
collector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(collector)


def sample(mean, lower=None, upper=None):
    return dict(mean_ns=mean, lower_ns=mean - 2 if lower is None else lower,
                upper_ns=mean + 2 if upper is None else upper, samples=9, allocated_bytes=0)


def fixture(configs):
    measurements = {}
    decisions = []
    for pair, config in configs.items():
        old = config.get('old', (120, 120))
        new = config.get('new', (70, 70))
        for bars in (1000, 10000):
            measurements[pair, bars] = {
                0: {'Ooples': sample(old[0])},
                1: {'Ooples': sample(new[0], upper=config.get('first_upper', new[0] + 2))},
                2: {'Ooples': sample(new[1]), 'Competitor': sample(100, 95, 105)},
                3: {'Ooples': sample(old[1])}}
            decisions.append(dict(fixture='LibraryPairBenchmarks', pair=pair, bars=bars,
                method='Ooples', verdict=config.get('verdict', 'faster'),
                old_means_ms=[value / 1e6 for value in old],
                new_means_ms=[value / 1e6 for value in new]))
    return measurements, decisions


def analyze(configs, sentinels=(), required=1):
    measurements, decisions = fixture(configs)
    return collector.analyze_native_gate(measurements, decisions, sentinels=set(sentinels),
        required_crossovers=required, expected_cases=10 * len(configs),
        expected_decisions=2 * len(configs))


class NativeGateTests(unittest.TestCase):
    def test_one_overlapping_candidate_round_cannot_be_hidden_by_final_round(self):
        result = analyze({'Candidate': dict(new=(80, 70), first_upper=96)})
        self.assertFalse(result['native_gate_met'])
        row = next(row for row in result['rows'] if row['bars'] == 10000)
        self.assertFalse(row['candidate_rounds'][0]['intervals_separated'])
        self.assertTrue(row['candidate_rounds'][0]['minimum_ten_percent_margin'])
        self.assertTrue(row['candidate_rounds'][1]['intervals_separated'])
        self.assertEqual([], result['strongest_new_10k_crossovers'])

    def test_mixed_or_already_winning_baselines_are_not_new_crossovers(self):
        result = analyze({'Mixed': dict(old=(90, 120)), 'OldWinner': dict(old=(80, 85))})
        rows = {row['pair']: row for row in result['rows'] if row['bars'] == 10000}
        self.assertEqual('mixed_old_rounds_uncertain', rows['Mixed']['baseline_classification'])
        self.assertEqual('wins_both_old_rounds', rows['OldWinner']['baseline_classification'])
        self.assertTrue(all(row['both_candidates_clear_native_gate'] for row in rows.values()))
        self.assertEqual([], result['strongest_new_10k_crossovers'])
        self.assertFalse(result['native_gate_met'])

    def test_source_slower_sentinel_blocks_an_otherwise_qualifying_new_crossover(self):
        result = analyze({'Candidate': {}, 'EmaSentinel': dict(old=(60, 60), new=(70, 70),
            verdict='slower')}, sentinels=['EmaSentinel'])
        self.assertEqual(['Candidate'], result['strongest_new_10k_crossovers'])
        self.assertEqual(2, len(result['source_slower_decisions']))
        self.assertEqual(2, len(result['sentinel_decisions']))
        self.assertFalse(result['native_gate_met'])

    def test_required_count_only_counts_ten_thousand_bar_non_sentinels(self):
        result = analyze({'Candidate': {}, 'OtherCandidate': {}, 'Control': {}},
            sentinels=['Control'], required=2)
        self.assertEqual(['Candidate', 'OtherCandidate'], result['strongest_new_10k_crossovers'])
        self.assertTrue(result['native_gate_met'])
        self.assertEqual((30, 6), (result['case_count'], result['decision_count']))
        self.assertEqual({1000, 10000}, {row['bars'] for row in result['rows']})
        self.assertFalse(result['qualification'] or result['accepted'] or result['report_imported'])

    def test_margin_is_required_even_with_separated_intervals(self):
        result = analyze({'Candidate': dict(new=(91, 91))})
        row = result['rows'][0]
        self.assertTrue(all(round['intervals_separated'] for round in row['candidate_rounds']))
        self.assertFalse(row['both_candidates_clear_native_gate'])

    def test_exact_margin_boundary_is_inclusive_without_rounding_an_overrun_down(self):
        self.assertTrue(analyze({'Candidate': dict(new=(90, 90))})['native_gate_met'])
        above = math.nextafter(90, math.inf)
        self.assertFalse(analyze({'Candidate': dict(new=(above, above))})['native_gate_met'])

    def test_native_outside_round_two_or_missing_cases_fail_closed(self):
        measurements, decisions = fixture({'Candidate': {}})
        measurements['Candidate', 10000][1]['Competitor'] = sample(100)
        with self.assertRaises(AssertionError):
            collector.analyze_native_gate(measurements, decisions, sentinels=set(),
                required_crossovers=1, expected_cases=10, expected_decisions=2)
        measurements, decisions = fixture({'Candidate': {}})
        with self.assertRaises(AssertionError):
            collector.analyze_native_gate(measurements, decisions, sentinels=set(),
                required_crossovers=1, expected_cases=11, expected_decisions=2)


class SafeExtractionTests(unittest.TestCase):
    def test_only_timing_and_small_provenance_are_extracted(self):
        with tempfile.TemporaryDirectory() as work:
            root = Path(work)
            archive = root / 'artifact.zip'
            names = ['pilot-diagnostic/summary.json', 'pilot-inputs/provenance.json',
                'pilot-diagnostic/evidence/shard0/provenance.json',
                'pilot-diagnostic/evidence/shard0/status.json',
                'pilot-diagnostic/evidence/shard0/operation0.log',
                'pilot-inputs/common/large.dll',
                'pilot-diagnostic/evidence/shard0-runtime-old/large.dll',
                'pilot-diagnostic/evidence/shard0/unused.dll']
            with zipfile.ZipFile(archive, 'w') as package:
                for name in names:
                    package.writestr(name, '{}')
            out = root / 'selected'; out.mkdir()
            selected = collector.extract_selected(archive, out, 'pilot-diagnostic')
            self.assertEqual(set(names[:5]), {item['path'] for item in selected})
            self.assertFalse(list(out.rglob('*.dll')))

    def test_case_aliased_selected_members_cannot_overwrite_evidence(self):
        with tempfile.TemporaryDirectory() as work:
            root = Path(work); archive = root / 'artifact.zip'; out = root / 'selected'; out.mkdir()
            with zipfile.ZipFile(archive, 'w') as package:
                package.writestr('pilot-diagnostic/evidence/shard0/status.json', '{}')
                package.writestr('pilot-diagnostic/evidence/shard0/STATUS.json', '{}')
            with self.assertRaisesRegex(AssertionError, 'Duplicate/case-aliased'):
                collector.extract_selected(archive, out, 'pilot-diagnostic')

    def test_windows_aliases_and_zip_traversal_are_rejected(self):
        for name in ['../escape', '/absolute', 'C:/escape', 'a\\b', 'a/../b',
                     'a/NUL.txt', 'a/CON .txt', 'a/COM\u00b9.txt', 'a/stream:alternate',
                     'a/file. ', 'a//b', 'a/invalid?.txt']:
            with self.subTest(name=name), self.assertRaises(AssertionError):
                collector.safe_parts(name)


if __name__ == '__main__':
    unittest.main()
