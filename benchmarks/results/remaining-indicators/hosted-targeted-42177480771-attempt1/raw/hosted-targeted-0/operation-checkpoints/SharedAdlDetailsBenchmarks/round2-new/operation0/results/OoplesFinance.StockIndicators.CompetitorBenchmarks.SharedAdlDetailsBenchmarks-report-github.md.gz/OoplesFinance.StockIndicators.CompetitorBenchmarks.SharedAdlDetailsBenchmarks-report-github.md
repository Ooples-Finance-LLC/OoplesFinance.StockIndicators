```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |    **39.49 μs** |   **0.510 μs** |  **0.303 μs** |  **0.52** |    **0.01** |   **4.8828** |   **0.9766** |   **88.31 KB** |        **0.50** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |    36.06 μs |   0.553 μs |  0.366 μs |  0.47 |    0.01 |   2.4414 |   0.2441 |    40.7 KB |        0.23 |
| NativeSingle      | Skender.GetAdl | 1000  |    76.31 μs |   2.364 μs |  1.407 μs |  1.00 |    0.02 |  10.7422 |   2.4414 |  176.21 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 1000  |   146.86 μs |  11.985 μs |  7.132 μs |  1.93 |    0.09 |  27.3438 |   7.8125 |  449.41 KB |        2.55 |
|                   |                |       |             |            |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetAdl** | **10000** |   **371.55 μs** |   **3.603 μs** |  **2.144 μs** |  **0.43** |    **0.00** |  **50.7813** |  **17.5781** |  **862.12 KB** |        **0.49** |
| BuilderLatestOnly | Skender.GetAdl | 10000 |   344.78 μs |   3.861 μs |  2.019 μs |  0.40 |    0.00 |  23.4375 |   9.7656 |  392.29 KB |        0.22 |
| NativeSingle      | Skender.GetAdl | 10000 |   859.97 μs |  12.211 μs |  7.266 μs |  1.00 |    0.01 | 101.5625 |  54.6875 |  1758.3 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 10000 | 1,440.42 μs | 116.248 μs | 76.891 μs |  1.68 |    0.09 | 273.4375 | 187.5000 | 4474.84 KB |        2.54 |
