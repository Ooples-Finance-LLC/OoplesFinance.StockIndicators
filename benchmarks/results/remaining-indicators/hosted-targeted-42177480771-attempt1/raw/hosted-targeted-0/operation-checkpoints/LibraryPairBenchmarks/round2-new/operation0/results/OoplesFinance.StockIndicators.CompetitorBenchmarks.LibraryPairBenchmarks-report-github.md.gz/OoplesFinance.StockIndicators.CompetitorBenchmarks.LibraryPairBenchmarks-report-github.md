```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAdl** |   **289.28 μs** | **22.980 μs** | **15.200 μs** |  **1.00** |    **0.07** |  **246.88 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAdl |    88.46 μs |  0.249 μs |  0.130 μs |  0.31 |    0.02 |  274.31 KB |        1.11 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAdl** | **2,269.04 μs** | **16.565 μs** |  **8.664 μs** |  **1.00** |    **0.01** | **2814.28 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAdl |   941.07 μs | 31.369 μs | 18.667 μs |  0.41 |    0.01 |  2656.2 KB |        0.94 |
