```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33828/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Allocated | Alloc Ratio |
|------------------ |----------------- |------ |-----------:|----------:|----------:|------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Afirma** | **1000**  |   **420.6 μs** |  **82.23 μs** |  **54.39 μs** |  **2.86** |    **0.35** |       **-** |  **61.72 KB** |        **1.29** |
| BuilderLatestOnly | QuanTAlib.Afirma | 1000  |   370.1 μs |  53.75 μs |  35.56 μs |  2.52 |    0.23 |       - |  13.56 KB |        0.28 |
| NativeSingle      | QuanTAlib.Afirma | 1000  |   147.1 μs |   0.96 μs |   0.57 μs |  1.00 |    0.01 |  0.9766 |  47.83 KB |        1.00 |
| NativeParallel    | QuanTAlib.Afirma | 1000  |   189.2 μs |  38.69 μs |  23.03 μs |  1.29 |    0.15 |  1.9531 |  53.11 KB |        1.11 |
|                   |                  |       |            |           |           |       |         |         |           |             |
| **BuilderFull**       | **QuanTAlib.Afirma** | **10000** | **2,897.4 μs** | **334.77 μs** | **221.43 μs** |  **1.95** |    **0.14** | **15.6250** | **554.07 KB** |        **1.18** |
| BuilderLatestOnly | QuanTAlib.Afirma | 10000 | 2,747.7 μs | 185.09 μs |  96.81 μs |  1.85 |    0.06 |       - |  84.11 KB |        0.18 |
| NativeSingle      | QuanTAlib.Afirma | 10000 | 1,484.1 μs |  34.79 μs |  18.20 μs |  1.00 |    0.02 | 15.6250 | 469.75 KB |        1.00 |
| NativeParallel    | QuanTAlib.Afirma | 10000 | 1,081.1 μs |  67.40 μs |  40.11 μs |  0.73 |    0.03 | 15.6250 | 475.04 KB |        1.01 |
