```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33828/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |---------- |------ |------------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Sinema**    | **1000**  |   **130.59 μs** | **27.831 μs** | **18.409 μs** |  **1.36** |    **0.19** |        **-** |       **-** |   **80.29 KB** |        **0.32** |
| BuilderLatestOnly | Sinema    | 1000  |   113.47 μs |  9.101 μs |  6.020 μs |  1.18 |    0.08 |   0.9766 |       - |   32.42 KB |        0.13 |
| NativeSingle      | Sinema    | 1000  |    96.01 μs |  7.697 μs |  5.091 μs |  1.00 |    0.07 |  10.2539 |       - |  254.32 KB |        1.00 |
| NativeParallel    | Sinema    | 1000  |   147.84 μs | 10.608 μs |  7.016 μs |  1.54 |    0.10 |   9.7656 |       - |  261.98 KB |        1.03 |
|                   |           |       |             |           |           |       |         |          |         |            |             |
| **BuilderFull**       | **Sinema**    | **10000** |   **370.06 μs** | **32.644 μs** | **21.592 μs** |  **0.36** |    **0.03** |  **21.4844** |  **7.8125** |  **572.83 KB** |        **0.22** |
| BuilderLatestOnly | Sinema    | 10000 |   344.70 μs | 44.142 μs | 29.197 μs |  0.34 |    0.03 |   3.9063 |       - |  102.74 KB |        0.04 |
| NativeSingle      | Sinema    | 10000 | 1,018.56 μs | 67.018 μs | 44.328 μs |  1.00 |    0.06 | 101.5625 | 15.6250 | 2564.14 KB |        1.00 |
| NativeParallel    | Sinema    | 10000 |   768.55 μs | 45.897 μs | 27.312 μs |  0.76 |    0.04 | 101.5625 | 19.5313 | 2571.95 KB |        1.00 |
