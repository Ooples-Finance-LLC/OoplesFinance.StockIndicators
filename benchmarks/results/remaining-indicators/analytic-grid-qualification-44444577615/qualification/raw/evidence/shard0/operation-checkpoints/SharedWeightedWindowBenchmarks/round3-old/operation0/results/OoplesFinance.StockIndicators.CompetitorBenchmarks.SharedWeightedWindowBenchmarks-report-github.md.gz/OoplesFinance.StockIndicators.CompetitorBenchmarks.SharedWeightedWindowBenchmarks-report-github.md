```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33828/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |---------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Gma**       | **1000**  |   **479.2 μs** |  **61.72 μs** |  **40.83 μs** |  **64.74 KB** |
| BuilderLatestOnly | Gma       | 1000  |   437.9 μs |  44.12 μs |  26.26 μs |  16.82 KB |
| **BuilderFull**       | **Gma**       | **10000** | **3,777.5 μs** | **200.07 μs** | **104.64 μs** | **557.44 KB** |
| BuilderLatestOnly | Gma       | 10000 | 4,014.6 μs | 490.65 μs | 324.53 μs |  87.36 KB |
