```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33828/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |----------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Afirma** | **1000**  |   **411.3 μs** |  **54.32 μs** |  **32.33 μs** |       **-** |  **61.73 KB** |
| BuilderLatestOnly | QuanTAlib.Afirma | 1000  |   347.9 μs |  12.02 μs |   6.29 μs |       - |  13.56 KB |
| **BuilderFull**       | **QuanTAlib.Afirma** | **10000** | **2,964.9 μs** | **274.80 μs** | **181.76 μs** | **15.6250** | **554.03 KB** |
| BuilderLatestOnly | QuanTAlib.Afirma | 10000 | 2,789.9 μs | 312.80 μs | 186.14 μs |       - |  83.97 KB |
