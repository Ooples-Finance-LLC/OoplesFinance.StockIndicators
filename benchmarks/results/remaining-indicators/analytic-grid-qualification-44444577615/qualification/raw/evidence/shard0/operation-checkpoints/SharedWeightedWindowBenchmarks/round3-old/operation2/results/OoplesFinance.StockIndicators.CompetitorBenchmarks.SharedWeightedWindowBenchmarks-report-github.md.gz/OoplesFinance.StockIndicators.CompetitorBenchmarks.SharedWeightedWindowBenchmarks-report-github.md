```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33828/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean     | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |------------ |------ |---------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **Convolution** | **1000**  | **119.4 μs** | **16.03 μs** | **10.60 μs** |  **1.9531** |      **-** |  **60.53 KB** |
| BuilderLatestOnly | Convolution | 1000  | 103.8 μs |  3.52 μs |  1.84 μs |       - |      - |  12.66 KB |
| **BuilderFull**       | **Convolution** | **10000** | **360.6 μs** | **28.86 μs** | **19.09 μs** | **21.4844** | **9.7656** | **553.07 KB** |
| BuilderLatestOnly | Convolution | 10000 | 312.7 μs | 28.66 μs | 17.06 μs |  1.9531 |      - |  82.98 KB |
