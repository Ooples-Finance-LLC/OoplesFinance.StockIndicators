```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33828/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |------------ |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Convolution** | **1000**  | **116.66 μs** | **15.166 μs** | **10.031 μs** |  **1.56** |    **0.13** |  **1.9531** |       **-** |   **60.53 KB** |        **0.28** |
| BuilderLatestOnly | Convolution | 1000  | 102.86 μs |  1.474 μs |  0.771 μs |  1.37 |    0.03 |       - |       - |   12.66 KB |        0.06 |
| NativeSingle      | Convolution | 1000  |  75.03 μs |  2.952 μs |  1.544 μs |  1.00 |    0.03 |  8.3008 |       - |  215.11 KB |        1.00 |
| NativeParallel    | Convolution | 1000  | 137.19 μs |  8.860 μs |  5.860 μs |  1.83 |    0.08 |  8.7891 |       - |   220.1 KB |        1.02 |
|                   |             |       |           |           |           |       |         |         |         |            |             |
| **BuilderFull**       | **Convolution** | **10000** | **343.96 μs** | **14.510 μs** |  **7.589 μs** |  **0.46** |    **0.01** | **19.5313** |  **7.8125** |  **553.09 KB** |        **0.25** |
| BuilderLatestOnly | Convolution | 10000 | 321.06 μs | 39.231 μs | 25.949 μs |  0.43 |    0.03 |  1.9531 |       - |   82.98 KB |        0.04 |
| NativeSingle      | Convolution | 10000 | 750.09 μs | 15.518 μs | 10.264 μs |  1.00 |    0.02 | 85.9375 | 15.6250 | 2173.34 KB |        1.00 |
| NativeParallel    | Convolution | 10000 | 629.19 μs | 48.861 μs | 32.318 μs |  0.84 |    0.04 | 85.9375 | 15.6250 | 2178.51 KB |        1.00 |
