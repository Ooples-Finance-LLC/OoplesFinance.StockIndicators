```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33828/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId           | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |----------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Sinema** |   **115.6 μs** |  **21.05 μs** |  **12.53 μs** |  **1.01** |    **0.17** |   **76.66 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Sinema |   202.9 μs |  25.29 μs |  15.05 μs |  1.78 |    0.27 |  261.95 KB |        3.42 |
|            |       |                  |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Sinema** |   **626.7 μs** | **342.89 μs** | **226.80 μs** |  **1.11** |    **0.52** |  **647.31 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Sinema | 1,391.6 μs | 256.08 μs | 169.38 μs |  2.46 |    0.80 | 2571.99 KB |        3.97 |
