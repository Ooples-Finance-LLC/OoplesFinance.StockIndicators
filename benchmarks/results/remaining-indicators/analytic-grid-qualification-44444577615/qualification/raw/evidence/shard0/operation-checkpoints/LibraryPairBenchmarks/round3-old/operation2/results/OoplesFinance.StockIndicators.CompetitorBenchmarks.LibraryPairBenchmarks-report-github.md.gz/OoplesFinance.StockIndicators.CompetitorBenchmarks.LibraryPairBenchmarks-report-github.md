```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33828/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean     | Error     | StdDev    | Median   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |---------:|----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **QuanT(...)ution [21]** | **147.6 μs** |  **37.96 μs** |  **19.85 μs** | **153.8 μs** |  **1.02** |    **0.22** |  **67.15 KB** |        **1.00** |
|        |       |                      |          |           |           |          |       |         |           |             |
| **Ooples** | **10000** | **QuanT(...)ution [21]** | **567.5 μs** | **403.46 μs** | **266.86 μs** | **399.9 μs** |  **1.17** |    **0.68** | **637.44 KB** |        **1.00** |
