```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33828/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId        | Mean       | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |-------------- |-----------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **QuanTAlib.Gma** |   **618.5 μs** |   **309.6 μs** |   **204.8 μs** |  **1.09** |    **0.46** |  **68.85 KB** |        **1.00** |
|        |       |               |            |            |            |       |         |           |             |
| **Ooples** | **10000** | **QuanTAlib.Gma** | **5,370.6 μs** | **1,948.9 μs** | **1,289.0 μs** |  **1.06** |    **0.38** | **639.51 KB** |        **1.00** |
