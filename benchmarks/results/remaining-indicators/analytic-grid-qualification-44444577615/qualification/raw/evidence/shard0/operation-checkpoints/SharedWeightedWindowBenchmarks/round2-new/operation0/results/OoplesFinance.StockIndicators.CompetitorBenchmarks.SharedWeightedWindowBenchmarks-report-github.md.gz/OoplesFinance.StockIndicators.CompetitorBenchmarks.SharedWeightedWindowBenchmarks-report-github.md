```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33828/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |---------- |------ |----------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Gma**       | **1000**  | **146.10 μs** | **27.303 μs** | **18.059 μs** |  **1.50** |    **0.18** |        **-** |       **-** |    **80.3 KB** |        **0.32** |
| BuilderLatestOnly | Gma       | 1000  | 109.75 μs |  3.522 μs |  1.842 μs |  1.13 |    0.03 |   0.9766 |       - |   32.42 KB |        0.13 |
| NativeSingle      | Gma       | 1000  |  97.31 μs |  3.768 μs |  2.492 μs |  1.00 |    0.03 |   9.7656 |       - |  254.33 KB |        1.00 |
| NativeParallel    | Gma       | 1000  | 152.55 μs | 12.792 μs |  8.461 μs |  1.57 |    0.09 |   9.7656 |       - |  261.98 KB |        1.03 |
|                   |           |       |           |           |           |       |         |          |         |            |             |
| **BuilderFull**       | **Gma**       | **10000** | **401.66 μs** | **42.953 μs** | **28.411 μs** |  **0.40** |    **0.03** |  **21.4844** |  **7.8125** |  **572.84 KB** |        **0.22** |
| BuilderLatestOnly | Gma       | 10000 | 392.79 μs | 57.492 μs | 38.028 μs |  0.40 |    0.04 |   3.9063 |       - |  102.76 KB |        0.04 |
| NativeSingle      | Gma       | 10000 | 994.64 μs | 42.378 μs | 22.164 μs |  1.00 |    0.03 | 101.5625 | 15.6250 | 2564.15 KB |        1.00 |
| NativeParallel    | Gma       | 10000 | 780.48 μs | 36.945 μs | 19.323 μs |  0.79 |    0.02 | 101.5625 | 15.6250 | 2571.98 KB |        1.00 |
