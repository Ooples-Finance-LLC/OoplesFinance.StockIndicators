```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33828/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanT(...)ution [21]** |   **172.6 μs** |  **18.13 μs** |  **10.79 μs** |  **1.00** |    **0.08** |   **67.15 KB** |        **1.00** |
| Competitor | 1000  | QuanT(...)ution [21] |   140.9 μs |  11.31 μs |   7.48 μs |  0.82 |    0.06 |   223.1 KB |        3.32 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanT(...)ution [21]** |   **696.2 μs** | **372.39 μs** | **221.60 μs** |  **1.08** |    **0.45** |  **637.77 KB** |        **1.00** |
| Competitor | 10000 | QuanT(...)ution [21] | 1,023.0 μs |  39.04 μs |  23.23 μs |  1.59 |    0.43 | 2181.63 KB |        3.42 |
