```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33828/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |----------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Afirma** | **1000**  |   **939.7 μs** | **125.33 μs** |  **82.90 μs** |       **-** |  **61.72 KB** |
| BuilderLatestOnly | QuanTAlib.Afirma | 1000  |   351.6 μs |  14.07 μs |   7.36 μs |       - |  13.56 KB |
| **BuilderFull**       | **QuanTAlib.Afirma** | **10000** | **2,959.5 μs** | **290.67 μs** | **192.26 μs** | **15.6250** | **554.07 KB** |
| BuilderLatestOnly | QuanTAlib.Afirma | 10000 | 2,734.3 μs | 280.39 μs | 146.65 μs |       - |  84.11 KB |
