```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33828/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId        | Mean       | Error      | StdDev      | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |-------------- |-----------:|-----------:|------------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **QuanTAlib.Gma** |   **525.1 μs** |   **127.2 μs** |    **66.53 μs** |  **1.01** |    **0.17** |  **68.85 KB** |        **1.00** |
|        |       |               |            |            |             |       |         |           |             |
| **Ooples** | **10000** | **QuanTAlib.Gma** | **5,669.8 μs** | **1,650.5 μs** | **1,091.68 μs** |  **1.04** |    **0.28** |  **636.6 KB** |        **1.00** |
