```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33828/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Gma**       | **1000**  | **114.2 μs** |  **8.05 μs** |  **4.21 μs** |       **-** |       **-** |   **80.3 KB** |
| BuilderLatestOnly | Gma       | 1000  | 110.6 μs |  2.11 μs |  1.10 μs |  0.9766 |       - |  32.42 KB |
| **BuilderFull**       | **Gma**       | **10000** | **372.3 μs** | **31.24 μs** | **20.66 μs** | **21.4844** | **15.6250** | **572.84 KB** |
| BuilderLatestOnly | Gma       | 10000 | 325.6 μs | 12.35 μs |  6.46 μs |  3.9063 |       - | 102.76 KB |
