```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33828/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean     | Error     | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |------------ |------ |---------:|----------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **Convolution** | **1000**  | **119.9 μs** |  **17.03 μs** | **11.27 μs** |  **1.9531** |      **-** |   **60.5 KB** |
| BuilderLatestOnly | Convolution | 1000  | 115.2 μs |  13.34 μs |  8.83 μs |       - |      - |  12.66 KB |
| **BuilderFull**       | **Convolution** | **10000** | **485.5 μs** | **119.66 μs** | **79.15 μs** | **19.5313** | **7.8125** | **553.06 KB** |
| BuilderLatestOnly | Convolution | 10000 | 476.7 μs |  60.24 μs | 39.85 μs |  1.9531 |      - |  82.98 KB |
