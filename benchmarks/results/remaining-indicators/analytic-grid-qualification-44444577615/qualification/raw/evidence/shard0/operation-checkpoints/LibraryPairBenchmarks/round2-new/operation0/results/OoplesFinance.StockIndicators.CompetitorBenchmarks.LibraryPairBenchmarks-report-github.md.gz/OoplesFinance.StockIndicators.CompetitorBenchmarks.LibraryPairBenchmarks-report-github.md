```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33828/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId        | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Gma** |   **131.1 μs** |  **37.35 μs** |  **22.23 μs** |  **1.02** |    **0.23** |   **76.66 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Gma |   198.9 μs |  36.79 μs |  21.89 μs |  1.55 |    0.28 |  261.95 KB |        3.42 |
|            |       |               |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Gma** |   **590.4 μs** | **241.32 μs** | **159.62 μs** |  **1.06** |    **0.38** |  **647.32 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Gma | 1,311.7 μs | 202.92 μs | 134.22 μs |  2.36 |    0.61 | 2572.04 KB |        3.97 |
