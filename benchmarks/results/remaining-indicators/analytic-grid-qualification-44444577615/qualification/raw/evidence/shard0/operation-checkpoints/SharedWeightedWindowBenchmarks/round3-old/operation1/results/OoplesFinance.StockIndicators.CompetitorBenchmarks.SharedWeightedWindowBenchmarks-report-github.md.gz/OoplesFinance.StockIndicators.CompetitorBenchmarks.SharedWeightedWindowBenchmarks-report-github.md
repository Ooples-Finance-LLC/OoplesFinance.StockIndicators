```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33828/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |---------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Sinema**    | **1000**  |   **449.8 μs** |  **49.07 μs** |  **32.45 μs** |  **64.73 KB** |
| BuilderLatestOnly | Sinema    | 1000  |   402.1 μs |  15.98 μs |   8.36 μs |  16.81 KB |
| **BuilderFull**       | **Sinema**    | **10000** | **3,703.9 μs** | **161.71 μs** |  **84.58 μs** | **557.44 KB** |
| BuilderLatestOnly | Sinema    | 10000 | 3,739.0 μs | 196.68 μs | 102.87 μs |  87.35 KB |
