```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33828/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |----------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **QuanTAlib.Afirma** | **1000**  |   **373.6 μs** |  **28.88 μs** |  **17.18 μs** |  **61.72 KB** |
| BuilderLatestOnly | QuanTAlib.Afirma | 1000  |   347.6 μs |  21.66 μs |  11.33 μs |  13.56 KB |
| **BuilderFull**       | **QuanTAlib.Afirma** | **10000** | **2,749.2 μs** | **133.81 μs** |  **79.63 μs** | **554.19 KB** |
| BuilderLatestOnly | QuanTAlib.Afirma | 10000 | 2,850.8 μs | 348.27 μs | 230.36 μs |  83.97 KB |
