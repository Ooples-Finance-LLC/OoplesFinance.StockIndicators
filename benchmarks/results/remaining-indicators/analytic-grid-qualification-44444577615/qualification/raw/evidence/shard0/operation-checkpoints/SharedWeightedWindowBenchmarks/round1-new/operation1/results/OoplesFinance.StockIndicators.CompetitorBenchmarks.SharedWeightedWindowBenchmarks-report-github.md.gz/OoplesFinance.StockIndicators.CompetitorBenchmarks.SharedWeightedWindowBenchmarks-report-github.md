```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33828/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Sinema**    | **1000**  | **130.0 μs** | **35.76 μs** | **23.66 μs** |       **-** |       **-** |  **80.29 KB** |
| BuilderLatestOnly | Sinema    | 1000  | 110.1 μs |  2.18 μs |  1.14 μs |  0.9766 |       - |  32.42 KB |
| **BuilderFull**       | **Sinema**    | **10000** | **386.9 μs** | **35.78 μs** | **23.66 μs** | **21.4844** | **15.6250** | **572.83 KB** |
| BuilderLatestOnly | Sinema    | 10000 | 340.0 μs | 37.95 μs | 25.10 μs |  3.9063 |       - | 102.74 KB |
