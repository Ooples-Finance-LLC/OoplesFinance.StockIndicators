```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33828/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |---------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Gma**       | **1000**  |   **971.1 μs** | **464.68 μs** | **307.36 μs** |  **64.74 KB** |
| BuilderLatestOnly | Gma       | 1000  |   445.9 μs |  11.63 μs |   6.08 μs |  16.82 KB |
| **BuilderFull**       | **Gma**       | **10000** | **3,902.5 μs** | **167.36 μs** |  **87.53 μs** | **557.44 KB** |
| BuilderLatestOnly | Gma       | 10000 | 3,897.6 μs | 322.35 μs | 191.83 μs |  87.36 KB |
