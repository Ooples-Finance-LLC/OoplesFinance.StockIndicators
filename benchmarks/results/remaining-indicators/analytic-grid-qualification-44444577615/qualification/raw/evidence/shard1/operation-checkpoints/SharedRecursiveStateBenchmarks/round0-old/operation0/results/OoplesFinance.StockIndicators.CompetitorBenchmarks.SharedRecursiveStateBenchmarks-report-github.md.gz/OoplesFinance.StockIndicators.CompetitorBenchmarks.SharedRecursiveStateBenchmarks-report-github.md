```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Ema**       | **1000**  |  **55.15 μs** |  **0.910 μs** |  **0.476 μs** |  **1.9531** |       **-** |  **56.74 KB** |
| BuilderLatestOnly | Ema       | 1000  |  30.82 μs |  0.319 μs |  0.190 μs |  0.4883 |       - |   8.85 KB |
| **BuilderFull**       | **Ema**       | **10000** | **291.55 μs** |  **2.281 μs** |  **1.357 μs** | **33.2031** | **13.6719** | **549.29 KB** |
| BuilderLatestOnly | Ema       | 10000 | 305.21 μs | 22.916 μs | 15.157 μs |  3.9063 |       - |  79.18 KB |
