```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean       | Error      | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|-----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ema** |  **99.667 μs** | **13.8549 μs** | **8.2448 μs** |  **1.01** |    **0.11** |  **64.84 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ema |   5.275 μs |  0.2451 μs | 0.1282 μs |  0.05 |    0.00 |  18.31 KB |        0.28 |
|            |       |                     |            |            |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ema** | **420.611 μs** | **15.1046 μs** | **8.9885 μs** |  **1.00** |    **0.03** | **635.13 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ema |  37.867 μs |  1.0461 μs | 0.6225 μs |  0.09 |    0.00 | 163.81 KB |        0.26 |
