```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |----------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Fwma** | **1000**  | **139.52 μs** | **18.068 μs** | **11.951 μs** |  **1.71** |    **0.14** |        **-** |       **-** |   **60.35 KB** |        **0.24** |
| BuilderLatestOnly | QuanTAlib.Fwma | 1000  | 127.70 μs |  3.878 μs |  2.028 μs |  1.56 |    0.03 |        - |       - |   12.47 KB |        0.05 |
| NativeSingle      | QuanTAlib.Fwma | 1000  |  81.76 μs |  1.035 μs |  0.541 μs |  1.00 |    0.01 |  15.1367 |  0.4883 |   254.5 KB |        1.00 |
| NativeParallel    | QuanTAlib.Fwma | 1000  | 140.30 μs |  4.048 μs |  2.677 μs |  1.72 |    0.03 |  15.6250 |       - |   262.7 KB |        1.03 |
|                   |                |       |           |           |           |       |         |          |         |            |             |
| **BuilderFull**       | **QuanTAlib.Fwma** | **10000** | **493.91 μs** | **48.023 μs** | **31.764 μs** |  **0.59** |    **0.04** |  **31.2500** | **11.7188** |  **552.91 KB** |        **0.22** |
| BuilderLatestOnly | QuanTAlib.Fwma | 10000 | 463.16 μs | 12.763 μs |  6.675 μs |  0.55 |    0.02 |   3.9063 |       - |   82.81 KB |        0.03 |
| NativeSingle      | QuanTAlib.Fwma | 10000 | 840.85 μs | 41.907 μs | 27.719 μs |  1.00 |    0.04 | 156.2500 | 31.2500 | 2564.33 KB |        1.00 |
| NativeParallel    | QuanTAlib.Fwma | 10000 | 604.18 μs | 38.289 μs | 25.326 μs |  0.72 |    0.04 | 156.2500 | 31.2500 | 2572.67 KB |        1.00 |
