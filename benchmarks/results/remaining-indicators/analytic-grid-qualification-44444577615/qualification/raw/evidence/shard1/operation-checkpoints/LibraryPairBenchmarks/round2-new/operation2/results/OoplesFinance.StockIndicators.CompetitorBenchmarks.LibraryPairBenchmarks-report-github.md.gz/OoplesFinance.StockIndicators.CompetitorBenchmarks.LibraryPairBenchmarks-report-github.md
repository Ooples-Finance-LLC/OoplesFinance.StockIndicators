```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.T3** |   **219.52 μs** |  **7.832 μs** |  **4.661 μs** |  **1.00** |    **0.03** |  **105.92 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.T3 |    11.23 μs |  2.545 μs |  1.683 μs |  0.05 |    0.01 |   37.69 KB |        0.36 |
|            |       |                    |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.T3** | **1,281.90 μs** | **68.496 μs** | **40.761 μs** |  **1.00** |    **0.04** | **1038.59 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.T3 |    63.36 μs |  5.143 μs |  2.690 μs |  0.05 |    0.00 |  330.63 KB |        0.32 |
