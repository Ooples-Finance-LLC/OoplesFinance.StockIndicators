```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |-----------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.T3** | **1000**  | **149.135 μs** |  **5.0749 μs** |  **3.3567 μs** | **40.39** |    **0.89** |  **3.9063** |       **-** |  **65.25 KB** |        **9.35** |
| BuilderLatestOnly | TaLib.Functions.T3 | 1000  | 142.952 μs |  3.8149 μs |  2.5233 μs | 38.71 |    0.68 |  0.9766 |       - |  17.64 KB |        2.53 |
| NativeSingle      | TaLib.Functions.T3 | 1000  |   3.693 μs |  0.0297 μs |  0.0177 μs |  1.00 |    0.01 |  0.3967 |       - |   6.98 KB |        1.00 |
| NativeParallel    | TaLib.Functions.T3 | 1000  |  90.716 μs |  1.8130 μs |  1.1992 μs | 24.57 |    0.33 |  1.4648 |       - |  24.66 KB |        3.53 |
|                   |                    |       |            |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.T3** | **10000** | **965.291 μs** | **78.6106 μs** | **51.9960 μs** | **25.21** |    **1.42** | **31.2500** |  **7.8125** | **630.78 KB** |        **8.16** |
| BuilderLatestOnly | TaLib.Functions.T3 | 10000 | 942.603 μs | 25.4915 μs | 13.3325 μs | 24.62 |    0.65 | 31.2500 | 15.6250 | 630.09 KB |        8.15 |
| NativeSingle      | TaLib.Functions.T3 | 10000 |  38.314 μs |  1.4303 μs |  0.9461 μs |  1.00 |    0.03 |  4.6387 |       - |  77.29 KB |        1.00 |
| NativeParallel    | TaLib.Functions.T3 | 10000 | 136.721 μs |  2.3672 μs |  1.2381 μs |  3.57 |    0.09 | 17.5781 |  3.9063 | 270.76 KB |        3.50 |
