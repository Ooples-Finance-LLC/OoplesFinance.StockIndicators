```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |---------- |------ |-----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **Ema**       | **1000**  |  **54.393 μs** | **1.1164 μs** | **0.6644 μs** | **17.58** |    **0.25** |  **1.9531** |       **-** |  **56.74 KB** |        **7.35** |
| BuilderLatestOnly | Ema       | 1000  |  31.372 μs | 0.1927 μs | 0.1275 μs | 10.14 |    0.09 |  0.4883 |       - |   8.85 KB |        1.15 |
| NativeSingle      | Ema       | 1000  |   3.095 μs | 0.0391 μs | 0.0259 μs |  1.00 |    0.01 |  0.4578 |       - |   7.72 KB |        1.00 |
| NativeParallel    | Ema       | 1000  |  88.240 μs | 0.8041 μs | 0.5319 μs | 28.52 |    0.28 |  0.4883 |       - |   7.99 KB |        1.03 |
|                   |           |       |            |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **Ema**       | **10000** | **292.121 μs** | **1.2004 μs** | **0.7143 μs** |  **9.99** |    **0.03** | **33.2031** | **13.6719** | **549.29 KB** |        **7.04** |
| BuilderLatestOnly | Ema       | 10000 | 280.876 μs | 2.5857 μs | 1.5387 μs |  9.61 |    0.05 |  3.9063 |       - |  79.18 KB |        1.01 |
| NativeSingle      | Ema       | 10000 |  29.241 μs | 0.0722 μs | 0.0430 μs |  1.00 |    0.00 |  4.6387 |  0.7324 |  78.03 KB |        1.00 |
| NativeParallel    | Ema       | 10000 | 116.247 μs | 2.9756 μs | 1.7707 μs |  3.98 |    0.06 |  3.9063 |       - |   78.3 KB |        1.00 |
