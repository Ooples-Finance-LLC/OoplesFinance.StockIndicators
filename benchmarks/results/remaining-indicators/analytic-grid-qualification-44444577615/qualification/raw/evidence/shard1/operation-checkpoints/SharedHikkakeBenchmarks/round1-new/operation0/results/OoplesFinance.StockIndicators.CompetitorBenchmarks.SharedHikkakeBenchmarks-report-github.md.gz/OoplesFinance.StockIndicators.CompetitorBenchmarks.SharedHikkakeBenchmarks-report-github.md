```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation            | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------ |--------------------- |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **TaLib(...)ified [29]** | **105.85 μs** | **17.163 μs** | **8.976 μs** |  **1.9531** |       **-** |  **62.52 KB** |
| BuilderLatestOnly | 1000  | TaLib(...)ified [29] |  98.49 μs |  4.005 μs | 2.649 μs |       - |       - |  14.64 KB |
| **BuilderFull**       | **10000** | **TaLib(...)ified [29]** | **219.06 μs** |  **5.298 μs** | **2.771 μs** | **33.2031** | **13.6719** | **555.68 KB** |
| BuilderLatestOnly | 10000 | TaLib(...)ified [29] | 212.85 μs | 11.586 μs | 7.663 μs |  3.9063 |       - |  85.57 KB |
