```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)ified [29]** | **131.72 μs** |  **3.997 μs** |  **2.091 μs** |  **1.00** |    **0.02** |   **68.1 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)ified [29] |  26.43 μs |  0.653 μs |  0.432 μs |  0.20 |    0.00 |  18.64 KB |        0.27 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)ified [29]** | **178.89 μs** | **23.511 μs** | **13.991 μs** |  **1.01** |    **0.10** | **638.68 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)ified [29] | 250.34 μs |  5.023 μs |  2.627 μs |  1.41 |    0.10 | 125.09 KB |        0.20 |
