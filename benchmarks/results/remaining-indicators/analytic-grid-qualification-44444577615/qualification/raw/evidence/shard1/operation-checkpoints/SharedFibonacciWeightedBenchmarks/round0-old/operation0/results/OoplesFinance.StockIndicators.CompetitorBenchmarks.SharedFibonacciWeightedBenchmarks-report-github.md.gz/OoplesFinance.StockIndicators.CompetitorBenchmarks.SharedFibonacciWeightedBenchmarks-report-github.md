```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean     | Error    | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |---------:|---------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Fwma** | **1000**  | **133.6 μs** | **11.32 μs** | **7.49 μs** |  **1.9531** |       **-** |  **60.31 KB** |
| BuilderLatestOnly | QuanTAlib.Fwma | 1000  | 129.4 μs |  4.32 μs | 2.86 μs |       - |       - |  12.47 KB |
| **BuilderFull**       | **QuanTAlib.Fwma** | **10000** | **472.4 μs** | **10.68 μs** | **5.59 μs** | **31.2500** | **11.7188** | **552.87 KB** |
| BuilderLatestOnly | QuanTAlib.Fwma | 10000 | 483.9 μs |  7.15 μs | 3.74 μs |  3.9063 |       - |  82.81 KB |
