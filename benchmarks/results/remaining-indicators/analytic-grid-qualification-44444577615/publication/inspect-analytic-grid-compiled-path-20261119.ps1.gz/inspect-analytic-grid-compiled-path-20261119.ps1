param([string]$Role,[string]$Runtime,[string]$ExpectedCore,[string]$ExpectedHarness,[string]$Out,[int]$Calls=1000,[string]$Pair)
$ErrorActionPreference='Stop'
if(Test-Path -LiteralPath $Out){throw 'No overwrite'}
$core=Join-Path $Runtime 'OoplesFinance.StockIndicators.dll';$harness=Join-Path $Runtime 'OoplesFinance.StockIndicators.CompetitorBenchmarks.dll'
if((Get-FileHash $core).Hash.ToLowerInvariant() -ne $ExpectedCore -or (Get-FileHash $harness).Hash.ToLowerInvariant() -ne $ExpectedHarness){throw 'Pin mismatch'}
[System.Runtime.Loader.AssemblyLoadContext]::Default.add_Resolving([Func[System.Runtime.Loader.AssemblyLoadContext,System.Reflection.AssemblyName,System.Reflection.Assembly]]{param($ctx,$name) $f=Join-Path $Runtime ($name.Name+'.dll');if(Test-Path $f){return $ctx.LoadFromAssemblyPath($f)};return $null})
$a=[Reflection.Assembly]::LoadFrom($core);$b=[Reflection.Assembly]::LoadFrom($harness);$flags=[Reflection.BindingFlags]'Public,NonPublic,Instance,Static'
if([Environment]::Version.ToString() -ne '10.0.15' -or $env:AIDOTNET_DISABLE_GPU -ne '1'){throw 'Wrong CLR/CPU observer bootstrap'}
$tensor=[Reflection.Assembly]::LoadFrom((Join-Path $Runtime 'AiDotNet.Tensors.dll'))
$engine=$tensor.GetType('AiDotNet.Tensors.Engines.AiDotNetEngine',$true).GetProperty('Current',$flags).GetValue($null)
if($engine.GetType().FullName -ne 'AiDotNet.Tensors.Engines.CpuEngine'){throw 'Wrong actual engine'}
$workerProperty=$tensor.GetType('AiDotNet.Tensors.Helpers.CpuParallelSettings',$true).GetProperty('MaxDegreeOfParallelism',$flags)
$workerDefault=[int]$workerProperty.GetValue($null)

$ops=@{};foreach($f in [Reflection.Emit.OpCodes].GetFields([Reflection.BindingFlags]'Public,Static')){$o=$f.GetValue($null);$ops[[int]$o.Value -band 65535]=$o}
$rows=[Collections.Generic.List[object]]::new()
foreach($t in $a.GetTypes()|Where-Object{$_.FullName -like '*ValuesBarExecution*' -or $_.FullName -like '*NormalizedKernelState*'}){
 foreach($m in $t.GetMethods($flags)|Where-Object{$_.DeclaringType -eq $t -and ($_.Name -in @('ComputeBoundedRegion','FillBoundedWindow') -or $_.Name -like '*FillBoundedWindow*' -or ($t.FullName -match 'AnalyticGridBatchState|StateWindowKernel|NormalizedKernelState' -and $_.Name -in @('Create','Update','Reset','Flush','Replay','CertifyWeights','Publish')))}){
  $body=$m.GetMethodBody();if($null -eq $body){continue};$il=$body.GetILAsByteArray();$lines=[Collections.Generic.List[string]]::new();$i=0
  while($i -lt $il.Length){$offset=$i;$v=[int]$il[$i++];if($v -eq 254){$v=65024+[int]$il[$i++]};$op=$ops[$v];if($null -eq $op){throw ('Unknown opcode '+$v+' offset '+$offset+' method '+$m)};$operand='';$size=0
   switch($op.OperandType.ToString()){
    'InlineNone'{}
    'ShortInlineBrTarget'{$size=1;$operand=[string]($i+1+[sbyte]::Parse($il[$i].ToString('X2'),[Globalization.NumberStyles]::HexNumber))}
    'InlineBrTarget'{$size=4;$operand=[string]($i+4+[BitConverter]::ToInt32($il,$i))}
    'ShortInlineI'{$size=1;$operand=[string]$il[$i]}
    'ShortInlineVar'{$size=1;$operand=[string]$il[$i]}
    'InlineVar'{$size=2;$operand=[string][BitConverter]::ToUInt16($il,$i)}
    'InlineI'{$size=4;$operand=[string][BitConverter]::ToInt32($il,$i)}
    'InlineI8'{$size=8;$operand=[string][BitConverter]::ToInt64($il,$i)}
    'ShortInlineR'{$size=4;$operand=[string][BitConverter]::ToSingle($il,$i)}
    'InlineR'{$size=8;$operand=[string][BitConverter]::ToDouble($il,$i)}
    'InlineSwitch'{$n=[BitConverter]::ToInt32($il,$i);$size=4+4*$n;$operand='switch '+$n}
    default{$size=4;$token=[BitConverter]::ToInt32($il,$i);try{$member=$m.Module.ResolveMember($token,$t.GetGenericArguments(),$m.GetGenericArguments());$operand=$member.DeclaringType.FullName+'::'+$member.ToString()}catch{$operand='token:'+ $token}}
   };$i+=$size;$lines.Add(('{0:D4} {1} {2}' -f $offset,$op.Name,$operand))
  }
  $rows.Add([ordered]@{type=$t.FullName;method=$m.ToString();il_length=$il.Length;max_stack=$body.MaxStackSize;locals=@($body.LocalVariables|ForEach-Object{$_.LocalType.ToString()});impl_flags=$m.GetMethodImplementationFlags().ToString();normalized_il=$lines})
 }
}
# Actual full adapter calls; no direct factory probes, no production instrumentation.
if($Pair -notin @('QuanTAlib.Gma','QuanTAlib.Sinema')){throw 'Unreviewed pair'}
$bt=$b.GetType('OoplesFinance.StockIndicators.CompetitorBenchmarks.LibraryPairBenchmarks',$true)
$reach=[Collections.Generic.List[object]]::new()
foreach($count in @(1000,10000)){
 $fixture=[Activator]::CreateInstance($bt);$bt.GetProperty('PairId').SetValue($fixture,$Pair);$bt.GetProperty('Bars').SetValue($fixture,$count)
 $null=$bt.GetMethod('Setup').Invoke($fixture,$null);$result=$null
 for($call=0;$call -lt $Calls;$call++){$result=$bt.GetMethod('Ooples').Invoke($fixture,$null)}
 $data=$bt.GetField('_data',$flags).GetValue($fixture);$hashes=@{}
 foreach($column in @('Opens','Highs','Lows','Closes','Volumes')){
  $array=[double[]]$data.GetType().GetProperty($column).GetValue($data);$bytes=[byte[]]::new($array.Length*8);[Buffer]::BlockCopy($array,0,$bytes,0,$bytes.Length)
  $hashes[$column]=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant()
 }
 if($result.Outputs.Count -ne 1 -or !$result.Outputs.ContainsKey('Value')){throw 'Wrong returned column set'}
 $column=$result.Outputs['Value'];$values=[double[]]$column.Values
 if($values.Length -ne $count -or $null -ne $column.Present){throw 'Wrong complete returned alignment'}
 if([int]$workerProperty.GetValue($null) -ne $workerDefault){throw 'Actual calls changed default worker setting'}
 $bytes=[byte[]]::new($count*8);[Buffer]::BlockCopy($values,0,$bytes,0,$bytes.Length)
 $reach.Add(@{pair=$Pair;bars=$count;lp_period=[int]$bt.GetField('Period',$flags).GetRawConstantValue();actual_data_bits=$hashes;full_returned_output_sha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant();first_valid=$column.FirstValid;present_is_null=($null -eq $column.Present)})
}
if((Get-FileHash $core).Hash.ToLowerInvariant() -ne $ExpectedCore -or (Get-FileHash $harness).Hash.ToLowerInvariant() -ne $ExpectedHarness){throw 'Pin changed'}
$workerEnd=[int]$workerProperty.GetValue($null);if($workerEnd -ne $workerDefault){throw 'Default worker setting changed'}
[IO.File]::WriteAllText($Out,([ordered]@{role=$Role;pair=$Pair;core=$ExpectedCore;harness=$ExpectedHarness;builds=0;timing_samples=0;actual_clr=[Environment]::Version.ToString();cpu_engine=$engine.GetType().FullName;default_worker_setting_before=$workerDefault;default_worker_setting_after=$workerEnd;default_worker_setting_unchanged=$true;calls_per_api_and_size=$Calls;reachability=$reach;methods=$rows}|ConvertTo-Json -Depth 10))
