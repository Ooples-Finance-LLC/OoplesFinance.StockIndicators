"""Four bounded source-bound compiled observers; no build, benchmark or source instrumentation."""
import argparse,hashlib,json,os,subprocess,time,traceback
from pathlib import Path
P=argparse.ArgumentParser();P.add_argument('--root-cpu-review-sha256',required=True);P.add_argument('--execute-root-reviewed-observer',action='store_true');args=P.parse_args();assert args.execute_root_reviewed_observer
OPS=Path(__file__).resolve().parent;OUT=OPS/'analytic-grid-compiled-checks-20261119';SCRIPT=OPS/'inspect-analytic-grid-compiled-path-20261119.ps1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(SCRIPT)=='3f04727d71b8e8249bc6ac65ec8d1df9ccb672456cce274e62659555254dcb9b'
PREFIX='benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks/bin/Release/net10.0/'
REPOS=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC')
CASES=[dict(role='baseline',source='48d238f56c37986b8437e5c31164552cc1362802',head='c398c4d0dad6f7868f84734bca2e42da20e2dbc5',folder='si-modified-hikkake-sparse-replay-gpu-only-20261118',ops='modified-hikkake-sparse-replay-correctness-20261118',run='44419618060',review='4f5fb8e82f58866cd02f74322b59b4af752eac24c3007f27ed7f6a730754e92a'),dict(role='candidate',source='d3d5c905a5d75b666b440aa6c5f6b4c24b42dc91',head='d3d5c905a5d75b666b440aa6c5f6b4c24b42dc91',folder='si-analytic-split-grid-gpu-only-20261119',ops='analytic-split-grid-correctness-20261119',run='44432145585',review=args.root_cpu_review_sha256)]
LOCAL_PINS={Path('C:/Program Files/PowerShell/7/pwsh.exe'):'e94166ed9f376559c1359bafb08bc49e463a494c330f67644ec1d9f1ffeb5ee5',Path('C:/Program Files/PowerShell/7/coreclr.dll'):'a6988fc77326c245873986446de4f15218df929664750d333cb2d42486c071da',Path('C:/Program Files/PowerShell/7/hostpolicy.dll'):'20405152b719ccb8d4e0361f3259db8875d8d4f3c97d1fbea4e1ca6cc6d21902'}
for p,pin in LOCAL_PINS.items():assert sha(p)==pin
# Read actual root CPU schema, not an invented combined receipt schema.
for c in CASES:
 repo=REPOS/c['folder'];cpu=OPS/c['ops']/('cpu-'+c['run']);review=cpu/'root-review.json';assert sha(review)==c['review'];root=json.loads(review.read_bytes());assert root['status']=='root-independent-cpu-authentication-passed' and root['source']==c['source'] and root['run_id']==c['run']
 actual=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();expected=subprocess.check_output(['git','rev-parse',c['head']],cwd=repo,text=True).strip();assert actual==expected
 # Evidence-only commits may differ only outside all production/harness/script fingerprint inputs.
 paths=['src','tests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','benchmarks/OoplesFinance.StockIndicators.CompetitorTests','scripts','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json','NuGet.Config','nuget.config']
 assert not subprocess.check_output(['git','diff',c['source'],actual,'--',*paths],cwd=repo)
 assert not subprocess.check_output(['git','status','--porcelain','--',*paths],cwd=repo)
 manifest_path=OPS/c['ops']/('authenticated-input-'+c['run'])/'manifest.json';assert sha(manifest_path)==root['manifest_sha256'];m=json.loads(manifest_path.read_bytes());assert m['source']==c['source'] and m['source_sha256']==root['source_fingerprint']
 assert m['runtime_files'][PREFIX+'OoplesFinance.StockIndicators.dll']==root['core_sha256'] and m['runtime_files'][PREFIX+'OoplesFinance.StockIndicators.CompetitorBenchmarks.dll']==root['actual_harness_sha256']
 gpu=OPS/c['ops']/('actual-gpu-'+c['run'])/'root-review.json';gr=json.loads(gpu.read_bytes());assert gr['status']=='root-independent-actual-gpu-authentication-passed' and gr['source']==c['source'] and gr['run_id']==c['run'] and gr['passed_cases']==100
 c.update(repo=repo,actual_head=actual,runtime=repo/PREFIX,files={k[len(PREFIX):]:v for k,v in m['runtime_files'].items() if k.startswith(PREFIX)},manifest=root['manifest_sha256'],gpu_review_sha256=sha(gpu));assert len(c['files'])==100
assert not OUT.exists(),'Fresh output only; no retry/overwrite';OUT.mkdir();receipts=[]
LIMIT_BYTES=16*1024*1024;DEADLINE_SECONDS=60
try:
 for c in CASES:
  for pair in ['Gma','Sinema']:
   stem=c['role']+'-'+pair
   def verify():
    for name,pin in c['files'].items():assert sha(c['runtime']/name)==pin,name
   verify();env=os.environ.copy();removed=[k for k in env if k.upper().startswith(('COMPLUS_','DOTNET_TIERED','DOTNET_TC_','DOTNET_JIT','DOTNET_READYTORUN','DOTNET_ENABLE','DOTNET_GC')) or k.upper()=='DOTNET_PROCESSOR_COUNT']
   assert not removed,'Ambient runtime overrides require preflight stop; never silently clear'
   env['AIDOTNET_DISABLE_GPU']='1';env['DOTNET_JitDisasm']='*ComputeBoundedRegion* *FillBoundedWindow* *AnalyticGridBatchState* *StateWindowKernel* *NormalizedKernelState* *ScalarMultiplyAdd*';env['DOTNET_JitStdOutFile']=str(OUT/(stem+'-jit.txt'))
   command=['C:/Program Files/PowerShell/7/pwsh.exe','-NoProfile','-NonInteractive','-File',str(SCRIPT),'-Role',c['role'],'-Runtime',str(c['runtime']),'-ExpectedCore',c['files']['OoplesFinance.StockIndicators.dll'],'-ExpectedHarness',c['files']['OoplesFinance.StockIndicators.CompetitorBenchmarks.dll'],'-Out',str(OUT/(stem+'-proof.json')),'-Calls','1000','-Pair','QuanTAlib.'+pair]
   hidden=subprocess.STARTUPINFO();hidden.dwFlags|=subprocess.STARTF_USESHOWWINDOW;hidden.wShowWindow=0;owned=None
   try:
    with (OUT/(stem+'-process.log')).open('xb') as log:
     owned=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW|subprocess.CREATE_NEW_PROCESS_GROUP,startupinfo=hidden);deadline=time.monotonic()+DEADLINE_SECONDS
     while owned.poll() is None:
      assert sum(p.stat().st_size for p in OUT.iterdir() if p.is_file())<=LIMIT_BYTES,'Live output cap';assert time.monotonic()<deadline,'Owned process60second deadline';time.sleep(.1)
     assert owned.returncode==0,'Observer failed; no retry';assert sum(p.stat().st_size for p in OUT.iterdir() if p.is_file())<=LIMIT_BYTES
   finally:
    if owned is not None and owned.poll() is None:owned.kill();owned.wait(timeout=10)
    verify()
   receipts.append(dict(role=c['role'],pair=pair,source=c['source'],checkout_head=c['actual_head'],source_scope_equal=True,manifest_sha256=c['manifest'],gpu_review_sha256=c['gpu_review_sha256'],runtime_files_verified_before_and_after=100,pid=owned.pid,removed_runtime_overrides=removed,deadline_seconds=DEADLINE_SECONDS,live_total_output_cap_bytes=LIMIT_BYTES,command=command))
 for pair in ['Gma','Sinema']:
  a,b=[json.loads((OUT/(role+'-'+pair+'-proof.json')).read_bytes()) for role in ['baseline','candidate']];assert a['default_worker_setting_unchanged'] is b['default_worker_setting_unchanged'] is True;assert a['reachability']==b['reachability']
 receipt=dict(status='inspection-completed-pending-root-review-no-latency-claim',builds=0,timing_samples=0,new_gpu_runs=0,processes=receipts,files={p.name:sha(p) for p in OUT.iterdir() if p.is_file()});(OUT/'inspection-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
except BaseException as error:
 (OUT/'inspection-failure.json').write_text(json.dumps(dict(status='inspection-failed-preserved-no-retry',error=str(error),traceback=traceback.format_exc(),automatic_retry_allowed=False),indent=2)+'\n');raise
