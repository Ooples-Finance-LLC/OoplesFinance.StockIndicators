```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated | Alloc Ratio |
|------------------ |--------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|----------:|------------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |    **35.50 μs** |  **0.500 μs** |  **0.261 μs** |  **0.44** |    **0.01** |   **4.8828** |   **0.9766** |  **88.31 KB** |        **0.50** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |    32.22 μs |  1.170 μs |  0.696 μs |  0.40 |    0.01 |   2.4414 |   0.2441 |   40.7 KB |        0.23 |
| NativeSingle      | Skender.GetAdl | 1000  |    80.07 μs |  2.939 μs |  1.944 μs |  1.00 |    0.03 |  10.7422 |   2.4414 | 176.21 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 1000  |   195.27 μs | 12.293 μs |  8.131 μs |  2.44 |    0.11 |  27.3438 |   7.8125 | 449.41 KB |        2.55 |
|                   |                |       |             |           |           |       |         |          |          |           |             |
| **BuilderFull**       | **Skender.GetAdl** | **10000** |   **345.78 μs** | **13.645 μs** |  **9.025 μs** |  **0.38** |    **0.01** |  **50.7813** |  **17.5781** | **862.12 KB** |        **0.49** |
| BuilderLatestOnly | Skender.GetAdl | 10000 |   306.85 μs |  4.299 μs |  2.248 μs |  0.33 |    0.01 |  23.4375 |   9.7656 | 392.29 KB |        0.22 |
| NativeSingle      | Skender.GetAdl | 10000 |   919.86 μs | 41.100 μs | 24.458 μs |  1.00 |    0.04 | 101.5625 |  62.5000 | 1758.3 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 10000 | 1,860.23 μs | 24.933 μs | 13.041 μs |  2.02 |    0.05 | 265.6250 | 203.1250 | 4474.9 KB |        2.55 |
