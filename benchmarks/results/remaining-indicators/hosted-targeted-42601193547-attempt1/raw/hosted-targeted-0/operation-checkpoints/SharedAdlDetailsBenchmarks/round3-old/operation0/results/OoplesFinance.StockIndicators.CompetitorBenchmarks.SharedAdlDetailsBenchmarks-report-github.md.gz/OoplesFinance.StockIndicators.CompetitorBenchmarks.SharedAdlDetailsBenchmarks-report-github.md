```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |  **40.63 μs** |  **0.809 μs** |  **0.423 μs** |  **5.3711** |  **0.9766** |  **88.28 KB** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |  37.79 μs |  0.896 μs |  0.592 μs |  2.4414 |  0.2441 |   40.7 KB |
| **BuilderFull**       | **Skender.GetAdl** | **10000** | **400.87 μs** | **16.279 μs** | **10.768 μs** | **50.7813** | **15.6250** |  **862.1 KB** |
| BuilderLatestOnly | Skender.GetAdl | 10000 | 363.07 μs |  7.143 μs |  4.724 μs | 23.4375 |  9.7656 | 392.29 KB |
