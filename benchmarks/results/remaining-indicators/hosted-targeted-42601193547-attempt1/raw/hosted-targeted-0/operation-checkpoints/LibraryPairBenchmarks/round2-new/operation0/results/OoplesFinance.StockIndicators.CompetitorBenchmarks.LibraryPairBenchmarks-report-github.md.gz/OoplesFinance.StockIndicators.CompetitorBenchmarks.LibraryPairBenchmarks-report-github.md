```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAdl** |   **258.24 μs** |  **7.115 μs** |  **3.721 μs** |  **1.00** |    **0.02** |     **159 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAdl |    91.90 μs |  3.369 μs |  1.762 μs |  0.36 |    0.01 |  273.98 KB |        1.72 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAdl** | **1,314.46 μs** | **53.694 μs** | **31.953 μs** |  **1.00** |    **0.03** | **1511.05 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAdl |   954.92 μs | 46.657 μs | 30.861 μs |  0.73 |    0.03 | 2656.15 KB |        1.76 |
