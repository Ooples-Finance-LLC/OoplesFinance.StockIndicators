```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |    **28.22 μs** |  **0.501 μs** |  **0.262 μs** |  **0.48** |    **0.01** |   **5.3711** |   **0.9766** |   **88.31 KB** |        **0.50** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |    25.69 μs |  0.393 μs |  0.234 μs |  0.44 |    0.01 |   2.4414 |   0.2441 |    40.7 KB |        0.23 |
| NativeSingle      | Skender.GetAdl | 1000  |    58.93 μs |  1.749 μs |  1.157 μs |  1.00 |    0.03 |  10.7422 |   2.4414 |  176.21 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 1000  |   152.67 μs |  9.547 μs |  6.315 μs |  2.59 |    0.11 |  28.3203 |   8.7891 |   449.4 KB |        2.55 |
|                   |                |       |             |           |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetAdl** | **10000** |   **263.55 μs** |  **1.389 μs** |  **0.727 μs** |  **0.41** |    **0.01** |  **50.7813** |  **17.5781** |  **862.12 KB** |        **0.49** |
| BuilderLatestOnly | Skender.GetAdl | 10000 |   245.81 μs |  6.460 μs |  3.379 μs |  0.38 |    0.01 |  23.4375 |   9.7656 |  392.29 KB |        0.22 |
| NativeSingle      | Skender.GetAdl | 10000 |   645.01 μs | 40.523 μs | 24.115 μs |  1.00 |    0.05 | 105.4688 |  66.4063 | 1758.26 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 10000 | 1,354.40 μs | 37.853 μs | 22.526 μs |  2.10 |    0.08 | 273.4375 | 195.3125 | 4474.84 KB |        2.55 |
