```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAdl** | **137.93 μs** |  **3.052 μs** |  **1.596 μs** |  **1.00** |    **0.02** |  **159.01 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAdl |  71.34 μs |  5.222 μs |  3.454 μs |  0.52 |    0.02 |  271.36 KB |        1.71 |
|            |       |                |           |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAdl** | **695.76 μs** | **25.727 μs** | **15.310 μs** |  **1.00** |    **0.03** | **1508.44 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAdl | 716.10 μs | 48.464 μs | 28.840 μs |  1.03 |    0.04 | 2654.18 KB |        1.76 |
