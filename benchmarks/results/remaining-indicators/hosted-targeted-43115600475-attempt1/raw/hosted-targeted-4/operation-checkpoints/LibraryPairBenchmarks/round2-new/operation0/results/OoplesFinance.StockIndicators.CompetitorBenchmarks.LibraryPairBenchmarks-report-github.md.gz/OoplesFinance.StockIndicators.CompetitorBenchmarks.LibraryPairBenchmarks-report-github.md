```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tSine [22]** |   **815.0 μs** | **44.36 μs** | **29.34 μs** |  **1.00** |    **0.05** | **166.88 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tSine [22] |   565.6 μs | 21.08 μs | 12.54 μs |  0.69 |    0.03 |  74.56 KB |        0.45 |
|            |       |                      |            |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)tSine [22]** | **7,937.5 μs** | **41.66 μs** | **24.79 μs** |  **1.00** |    **0.00** | **1599.2 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tSine [22] | 5,998.4 μs | 67.08 μs | 44.37 μs |  0.76 |    0.01 | 654.64 KB |        0.41 |
