```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|------------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **719.4 μs** |     **7.61 μs** |   **3.98 μs** |  **1.32** |    **0.01** |  **85.26 KB** |        **5.42** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   710.5 μs |     2.56 μs |   1.52 μs |  1.30 |    0.01 |   37.7 KB |        2.40 |
| NativeSingle      | TaLib(...)tSine [22] | 1000  |   546.4 μs |     4.26 μs |   2.54 μs |  1.00 |    0.01 |  15.74 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 1000  |   789.0 μs |    31.22 μs |  16.33 μs |  1.44 |    0.03 |  55.99 KB |        3.56 |
|                   |                      |       |            |             |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **7,389.0 μs** |    **81.96 μs** |  **42.87 μs** |  **1.10** |    **0.13** | **789.28 KB** |        **5.04** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 7,383.1 μs |    27.42 μs |  16.32 μs |  1.10 |    0.13 | 319.47 KB |        2.04 |
| NativeSingle      | TaLib(...)tSine [22] | 10000 | 6,787.2 μs | 1,287.23 μs | 851.42 μs |  1.01 |    0.17 | 156.58 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 10000 | 8,184.6 μs |   197.14 μs | 103.11 μs |  1.22 |    0.14 | 548.99 KB |        3.51 |
