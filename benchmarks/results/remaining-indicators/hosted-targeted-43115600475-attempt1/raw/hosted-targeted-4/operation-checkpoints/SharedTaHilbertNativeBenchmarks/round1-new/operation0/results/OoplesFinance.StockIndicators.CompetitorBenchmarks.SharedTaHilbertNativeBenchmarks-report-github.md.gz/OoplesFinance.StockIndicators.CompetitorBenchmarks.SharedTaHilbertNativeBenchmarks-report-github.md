```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error       | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|------------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **829.6 μs** |   **183.31 μs** | **121.25 μs** |  **85.26 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   808.1 μs |    90.71 μs |  60.00 μs |   37.7 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **8,465.8 μs** | **1,085.32 μs** | **645.86 μs** | **789.35 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 7,978.5 μs |   585.37 μs | 387.19 μs | 319.59 KB |
