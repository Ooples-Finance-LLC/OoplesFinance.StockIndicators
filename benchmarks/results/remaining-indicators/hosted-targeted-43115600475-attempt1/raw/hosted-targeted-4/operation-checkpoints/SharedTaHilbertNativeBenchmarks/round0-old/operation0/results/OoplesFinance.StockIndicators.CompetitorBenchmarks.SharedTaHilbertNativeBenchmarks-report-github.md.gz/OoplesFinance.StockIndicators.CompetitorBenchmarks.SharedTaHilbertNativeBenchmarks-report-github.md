```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **840.2 μs** |   **6.35 μs** |  **3.78 μs** |  **84.84 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   858.1 μs |  57.38 μs | 37.96 μs |  37.27 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **8,689.8 μs** | **126.99 μs** | **66.42 μs** | **788.96 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 8,661.8 μs |  82.20 μs | 54.37 μs | 319.14 KB |
