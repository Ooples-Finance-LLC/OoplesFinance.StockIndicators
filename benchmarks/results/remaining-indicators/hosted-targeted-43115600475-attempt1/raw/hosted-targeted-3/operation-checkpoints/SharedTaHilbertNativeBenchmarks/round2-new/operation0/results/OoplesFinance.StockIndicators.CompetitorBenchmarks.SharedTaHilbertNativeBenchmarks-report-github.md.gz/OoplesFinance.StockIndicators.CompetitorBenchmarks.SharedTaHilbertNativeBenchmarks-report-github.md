```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **678.5 μs** |   **5.38 μs** |   **2.82 μs** |  **1.30** |    **0.01** |  **69.36 KB** |        **8.27** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   674.0 μs |   4.32 μs |   2.57 μs |  1.29 |    0.01 |  21.77 KB |        2.60 |
| NativeSingle      | TaLib(...)Phase [25] | 1000  |   521.6 μs |   4.99 μs |   2.97 μs |  1.00 |    0.01 |   8.39 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 1000  |   743.7 μs |  36.07 μs |  23.86 μs |  1.43 |    0.04 |  30.19 KB |        3.60 |
|                   |                      |       |            |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **7,090.0 μs** |  **39.44 μs** |  **20.63 μs** |  **1.26** |    **0.01** | **632.74 KB** |        **8.02** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 7,035.0 μs |  31.91 μs |  18.99 μs |  1.25 |    0.00 | 162.91 KB |        2.07 |
| NativeSingle      | TaLib(...)Phase [25] | 10000 | 5,641.0 μs |  34.72 μs |  18.16 μs |  1.00 |    0.00 |  78.89 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 10000 | 8,016.7 μs | 514.60 μs | 340.38 μs |  1.42 |    0.06 | 276.86 KB |        3.51 |
