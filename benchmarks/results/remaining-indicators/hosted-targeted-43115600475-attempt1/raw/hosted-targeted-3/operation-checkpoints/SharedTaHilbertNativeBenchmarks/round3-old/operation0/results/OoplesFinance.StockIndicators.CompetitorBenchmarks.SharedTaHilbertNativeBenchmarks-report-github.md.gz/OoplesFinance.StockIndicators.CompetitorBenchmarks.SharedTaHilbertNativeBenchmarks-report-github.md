```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **815.9 μs** |   **6.51 μs** |   **3.41 μs** |  **68.95 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   819.8 μs |   7.43 μs |   4.91 μs |  21.38 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **8,739.9 μs** | **251.17 μs** | **149.46 μs** | **632.44 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 8,430.3 μs |  58.05 μs |  30.36 μs | 162.63 KB |
