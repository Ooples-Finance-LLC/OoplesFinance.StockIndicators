```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)Phase [25]** |   **863.0 μs** |  **42.42 μs** |  **28.06 μs** |  **1.00** |    **0.04** | **110.06 KB** |        **1.00** |
|        |       |                      |            |           |           |       |         |           |             |
| **Ooples** | **10000** | **TaLib(...)Phase [25]** | **8,651.3 μs** | **183.69 μs** | **109.31 μs** |  **1.00** |    **0.02** | **1041.4 KB** |        **1.00** |
