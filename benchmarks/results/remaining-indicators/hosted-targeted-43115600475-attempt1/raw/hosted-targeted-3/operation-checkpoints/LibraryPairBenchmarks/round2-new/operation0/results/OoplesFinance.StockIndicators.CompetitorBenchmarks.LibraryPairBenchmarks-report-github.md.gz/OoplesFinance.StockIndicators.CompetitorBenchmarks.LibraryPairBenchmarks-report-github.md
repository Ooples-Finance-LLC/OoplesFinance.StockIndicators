```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Phase [25]** |   **750.9 μs** |  **35.64 μs** |  **21.21 μs** |  **1.00** |    **0.04** |  **110.48 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Phase [25] |   544.6 μs |  23.77 μs |  14.14 μs |  0.73 |    0.03 |   42.09 KB |        0.38 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)Phase [25]** | **7,533.6 μs** | **435.94 μs** | **259.42 μs** |  **1.00** |    **0.05** | **1041.82 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Phase [25] | 6,139.2 μs | 583.09 μs | 385.68 μs |  0.82 |    0.06 |  332.13 KB |        0.32 |
