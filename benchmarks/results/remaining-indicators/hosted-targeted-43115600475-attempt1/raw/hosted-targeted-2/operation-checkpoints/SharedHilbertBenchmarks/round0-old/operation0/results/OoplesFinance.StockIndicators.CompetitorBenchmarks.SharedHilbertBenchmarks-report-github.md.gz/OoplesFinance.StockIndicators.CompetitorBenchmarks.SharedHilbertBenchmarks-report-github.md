```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mama** | **1000**  |   **339.4 μs** |   **1.17 μs** |   **0.70 μs** |       **-** |  **82.61 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 1000  |   340.1 μs |   6.56 μs |   4.34 μs |  1.9531 |     35 KB |
| **BuilderFull**       | **TaLib.Functions.Mama** | **10000** | **3,420.4 μs** | **125.58 μs** |  **83.06 μs** | **31.2500** | **786.27 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 10000 | 3,393.4 μs | 175.84 μs | 116.30 μs |       - | 316.42 KB |
