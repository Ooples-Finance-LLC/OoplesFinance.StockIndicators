```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mama** | **1000**  |   **336.6 μs** |   **4.72 μs** |   **2.81 μs** |       **-** |  **82.61 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 1000  |   332.0 μs |  11.00 μs |   6.55 μs |  1.9531 |     35 KB |
| **BuilderFull**       | **TaLib.Functions.Mama** | **10000** | **3,717.9 μs** | **491.06 μs** | **324.80 μs** | **31.2500** |  **786.3 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 10000 | 3,143.0 μs |  94.34 μs |  62.40 μs |       - | 316.38 KB |
