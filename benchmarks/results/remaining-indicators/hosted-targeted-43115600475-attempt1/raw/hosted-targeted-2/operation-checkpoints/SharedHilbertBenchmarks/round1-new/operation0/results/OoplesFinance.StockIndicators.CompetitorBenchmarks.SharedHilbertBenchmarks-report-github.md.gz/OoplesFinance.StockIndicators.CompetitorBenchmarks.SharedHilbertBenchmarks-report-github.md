```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mama** | **1000**  |   **301.1 μs** |  **7.28 μs** |  **4.81 μs** |  **3.9063** |       **-** |  **83.03 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 1000  |   298.0 μs |  9.37 μs |  5.58 μs |  1.9531 |       - |  35.43 KB |
| **BuilderFull**       | **TaLib.Functions.Mama** | **10000** | **2,855.3 μs** | **63.37 μs** | **37.71 μs** | **46.8750** | **15.6250** | **786.52 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 10000 | 2,866.5 μs | 90.46 μs | 59.83 μs | 15.6250 |       - | 316.68 KB |
