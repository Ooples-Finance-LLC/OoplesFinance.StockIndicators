```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Mama** | **1000**  |   **267.90 μs** |   **2.346 μs** |  **1.227 μs** |  **3.44** |    **0.04** |        **-** |        **-** |        **-** |  **83.03 KB** |        **5.34** |
| BuilderLatestOnly | TaLib.Functions.Mama | 1000  |   273.55 μs |  17.173 μs |  8.982 μs |  3.51 |    0.12 |   1.9531 |        - |        - |  35.43 KB |        2.28 |
| NativeSingle      | TaLib.Functions.Mama | 1000  |    77.94 μs |   1.470 μs |  0.973 μs |  1.00 |    0.02 |   0.4883 |        - |        - |  15.55 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mama | 1000  |   146.19 μs |   7.706 μs |  5.097 μs |  1.88 |    0.07 |   3.9063 |        - |        - |  54.83 KB |        3.53 |
|                   |                      |       |             |            |           |       |         |          |          |          |           |             |
| **BuilderFull**       | **TaLib.Functions.Mama** | **10000** | **2,673.41 μs** |  **30.144 μs** | **19.938 μs** |  **3.18** |    **0.04** |  **46.8750** |  **15.6250** |        **-** | **786.59 KB** |        **5.02** |
| BuilderLatestOnly | TaLib.Functions.Mama | 10000 | 2,676.64 μs | 106.971 μs | 70.755 μs |  3.18 |    0.09 |  15.6250 |        - |        - |  316.7 KB |        2.02 |
| NativeSingle      | TaLib.Functions.Mama | 10000 |   840.96 μs |  12.630 μs |  8.354 μs |  1.00 |    0.01 |  46.8750 |  46.8750 |  46.8750 | 156.57 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mama | 10000 | 1,058.83 μs |  59.562 μs | 35.444 μs |  1.26 |    0.04 | 132.8125 | 132.8125 | 132.8125 | 548.11 KB |        3.50 |
