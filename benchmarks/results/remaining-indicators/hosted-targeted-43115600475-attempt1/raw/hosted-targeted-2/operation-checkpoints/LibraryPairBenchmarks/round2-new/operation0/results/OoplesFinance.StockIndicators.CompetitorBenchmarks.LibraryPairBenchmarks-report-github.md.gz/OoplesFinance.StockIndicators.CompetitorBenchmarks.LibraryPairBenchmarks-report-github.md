```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Mama** |   **334.37 μs** | **14.390 μs** |  **8.563 μs** |  **1.00** |    **0.03** |  **164.44 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Mama |    93.67 μs |  3.571 μs |  2.362 μs |  0.28 |    0.01 |    70.5 KB |        0.43 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Mama** | **3,185.07 μs** | **29.506 μs** | **17.559 μs** |  **1.00** |    **0.01** | **1588.59 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Mama |   917.40 μs | 13.712 μs |  9.070 μs |  0.29 |    0.00 |  649.31 KB |        0.41 |
