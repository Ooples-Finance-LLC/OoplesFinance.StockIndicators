```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dline [27]** |   **902.0 μs** |  **33.19 μs** |  **21.95 μs** |  **1.00** |    **0.03** | **110.52 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dline [27] |   147.9 μs |  11.23 μs |   6.68 μs |  0.16 |    0.01 |  41.15 KB |        0.37 |
|            |       |                      |            |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)dline [27]** | **8,839.7 μs** | **177.97 μs** | **117.71 μs** |  **1.00** |    **0.02** | **1041.2 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dline [27] | 1,438.0 μs |  20.02 μs |  13.24 μs |  0.16 |    0.00 | 331.52 KB |        0.32 |
