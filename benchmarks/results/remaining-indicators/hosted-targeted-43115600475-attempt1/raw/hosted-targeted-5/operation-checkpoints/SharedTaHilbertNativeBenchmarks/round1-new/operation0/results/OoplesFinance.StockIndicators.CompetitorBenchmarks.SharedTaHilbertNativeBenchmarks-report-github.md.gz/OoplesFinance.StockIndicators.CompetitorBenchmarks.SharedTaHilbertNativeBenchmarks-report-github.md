```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error       | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|------------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dline [27]** | **1000**  |   **877.6 μs** |    **35.91 μs** |  **21.37 μs** |  **69.69 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 1000  |   926.9 μs |   143.14 μs |  94.68 μs |  22.07 KB |
| **BuilderFull**       | **TaLib(...)dline [27]** | **10000** | **9,586.3 μs** | **1,125.21 μs** | **744.26 μs** | **633.21 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 10000 | 9,894.9 μs | 1,188.43 μs | 786.07 μs | 163.57 KB |
