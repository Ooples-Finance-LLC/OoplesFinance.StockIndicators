```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |------------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)dline [27]** | **1000**  |    **995.3 μs** |  **8.91 μs** |  **5.31 μs** |  **69.27 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 1000  |    972.1 μs | 12.45 μs |  7.41 μs |  21.64 KB |
| **BuilderFull**       | **TaLib(...)dline [27]** | **10000** | **10,032.9 μs** | **28.52 μs** | **16.97 μs** | **632.76 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 10000 |  9,990.9 μs | 74.58 μs | 44.38 μs | 163.02 KB |
