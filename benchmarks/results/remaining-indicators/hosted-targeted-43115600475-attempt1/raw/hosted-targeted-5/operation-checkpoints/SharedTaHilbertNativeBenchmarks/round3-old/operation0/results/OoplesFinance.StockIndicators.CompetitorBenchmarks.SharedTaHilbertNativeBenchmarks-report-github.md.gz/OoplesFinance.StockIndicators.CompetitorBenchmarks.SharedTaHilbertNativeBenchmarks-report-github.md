```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |------------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)dline [27]** | **1000**  |    **979.1 μs** |  **8.14 μs** |  **4.84 μs** |  **69.27 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 1000  |    952.6 μs |  2.52 μs |  1.50 μs |  21.64 KB |
| **BuilderFull**       | **TaLib(...)dline [27]** | **10000** |  **9,865.4 μs** | **96.02 μs** | **50.22 μs** | **632.76 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 10000 | 10,038.6 μs | 55.05 μs | 32.76 μs | 162.99 KB |
