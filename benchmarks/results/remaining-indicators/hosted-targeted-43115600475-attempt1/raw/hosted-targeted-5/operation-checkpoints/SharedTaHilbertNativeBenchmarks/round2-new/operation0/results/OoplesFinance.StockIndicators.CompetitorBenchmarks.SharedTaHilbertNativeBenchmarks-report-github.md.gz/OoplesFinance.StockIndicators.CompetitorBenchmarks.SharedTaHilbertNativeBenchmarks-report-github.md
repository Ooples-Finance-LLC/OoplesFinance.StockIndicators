```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Ratio | RatioSD | Gen0    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dline [27]** | **1000**  |   **872.2 μs** | **10.25 μs** |  **6.10 μs** |  **7.05** |    **0.06** |       **-** |  **69.69 KB** |        **8.76** |
| BuilderLatestOnly | TaLib(...)dline [27] | 1000  |   839.7 μs |  7.63 μs |  3.99 μs |  6.79 |    0.04 |       - |  22.06 KB |        2.77 |
| NativeSingle      | TaLib(...)dline [27] | 1000  |   123.7 μs |  1.06 μs |  0.55 μs |  1.00 |    0.01 |       - |   7.95 KB |        1.00 |
| NativeParallel    | TaLib(...)dline [27] | 1000  |   220.2 μs | 36.33 μs | 24.03 μs |  1.78 |    0.19 |  1.9531 |  28.52 KB |        3.59 |
|                   |                      |       |            |          |          |       |         |         |           |             |
| **BuilderFull**       | **TaLib(...)dline [27]** | **10000** | **8,530.9 μs** | **34.60 μs** | **18.09 μs** |  **6.25** |    **0.03** |       **-** | **633.09 KB** |        **8.08** |
| BuilderLatestOnly | TaLib(...)dline [27] | 10000 | 8,704.8 μs | 25.61 μs | 13.39 μs |  6.38 |    0.03 |       - | 163.31 KB |        2.09 |
| NativeSingle      | TaLib(...)dline [27] | 10000 | 1,365.0 μs | 10.95 μs |  6.52 μs |  1.00 |    0.01 |       - |  78.31 KB |        1.00 |
| NativeParallel    | TaLib(...)dline [27] | 10000 | 1,577.2 μs | 43.76 μs | 26.04 μs |  1.16 |    0.02 | 15.6250 | 274.72 KB |        3.51 |
