```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1.107 ms** | **0.0081 ms** | **0.0042 ms** |   **71.6 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1.089 ms | 0.0078 ms | 0.0041 ms |  24.04 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **11.519 ms** | **0.0479 ms** | **0.0285 ms** |    **635 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 11.425 ms | 0.0769 ms | 0.0509 ms | 165.52 KB |
