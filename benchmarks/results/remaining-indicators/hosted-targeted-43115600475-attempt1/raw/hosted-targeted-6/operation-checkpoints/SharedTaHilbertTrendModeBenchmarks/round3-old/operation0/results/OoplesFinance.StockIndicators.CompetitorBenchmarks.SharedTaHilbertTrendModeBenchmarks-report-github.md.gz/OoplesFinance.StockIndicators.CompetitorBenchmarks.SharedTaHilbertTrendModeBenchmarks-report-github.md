```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1.111 ms** | **0.0086 ms** | **0.0045 ms** |  **71.68 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1.101 ms | 0.0069 ms | 0.0041 ms |  24.04 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **11.624 ms** | **0.0645 ms** | **0.0426 ms** | **635.15 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 11.568 ms | 0.2455 ms | 0.1284 ms | 165.26 KB |
