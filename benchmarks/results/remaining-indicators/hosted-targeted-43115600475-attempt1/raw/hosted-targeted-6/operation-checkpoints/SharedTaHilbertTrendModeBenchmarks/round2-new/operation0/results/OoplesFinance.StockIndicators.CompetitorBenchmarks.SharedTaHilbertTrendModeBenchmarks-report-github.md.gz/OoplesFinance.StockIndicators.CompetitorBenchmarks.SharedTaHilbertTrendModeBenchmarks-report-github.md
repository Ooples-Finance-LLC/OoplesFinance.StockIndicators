```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1,065.1 μs** |   **4.58 μs** |   **2.72 μs** |  **2.60** |    **0.01** |   **72.1 KB** |       **15.28** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1,052.9 μs |   7.78 μs |   4.07 μs |  2.57 |    0.01 |  24.45 KB |        5.18 |
| NativeSingle      | TaLib(...)dMode [27] | 1000  |    410.1 μs |   1.40 μs |   0.73 μs |  1.00 |    0.00 |   4.72 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 1000  |    633.6 μs |  28.90 μs |  19.12 μs |  1.54 |    0.04 |   17.4 KB |        3.69 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **10,981.6 μs** |  **77.38 μs** |  **40.47 μs** |  **2.22** |    **0.01** | **635.17 KB** |       **15.87** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 11,013.2 μs |  47.16 μs |  31.20 μs |  2.23 |    0.01 | 165.62 KB |        4.14 |
| NativeSingle      | TaLib(...)dMode [27] | 10000 |  4,939.2 μs |  23.33 μs |  13.88 μs |  1.00 |    0.00 |  40.02 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 10000 |  6,900.9 μs | 417.54 μs | 276.18 μs |  1.40 |    0.05 | 140.94 KB |        3.52 |
