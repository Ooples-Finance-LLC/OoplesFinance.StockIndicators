```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dMode [27]** |  **1,099.1 μs** |  **26.26 μs** |  **15.63 μs** |  **1.00** |    **0.02** |  **113.15 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dMode [27] |    497.8 μs |  29.99 μs |  17.85 μs |  0.45 |    0.02 |    37.2 KB |        0.33 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)dMode [27]** | **11,336.1 μs** | **177.79 μs** | **117.60 μs** |  **1.00** |    **0.01** | **1043.17 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dMode [27] |  5,016.7 μs |  41.53 μs |  24.71 μs |  0.44 |    0.00 |  291.47 KB |        0.28 |
