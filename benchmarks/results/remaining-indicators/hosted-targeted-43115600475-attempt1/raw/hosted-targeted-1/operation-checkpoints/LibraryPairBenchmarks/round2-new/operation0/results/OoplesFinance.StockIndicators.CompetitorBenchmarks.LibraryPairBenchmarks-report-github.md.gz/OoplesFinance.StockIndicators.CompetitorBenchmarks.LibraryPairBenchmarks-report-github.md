```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)hasor [24]** |   **541.8 μs** |  **46.13 μs** |  **30.51 μs** |  **1.00** |    **0.07** |  **164.47 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)hasor [24] |   113.8 μs |   4.47 μs |   2.34 μs |  0.21 |    0.01 |   74.15 KB |        0.45 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)hasor [24]** | **5,091.6 μs** | **225.67 μs** | **134.29 μs** |  **1.00** |    **0.03** | **1596.78 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)hasor [24] | 1,079.6 μs |   7.22 μs |   4.30 μs |  0.21 |    0.01 |  653.95 KB |        0.41 |
