```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)hasor [24]** | **1000**  |   **446.0 μs** |  **19.99 μs** |  **11.90 μs** |  **4.22** |    **0.11** |        **-** |        **-** |        **-** |   **82.8 KB** |        **5.32** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 1000  |   431.5 μs |   2.96 μs |   1.55 μs |  4.08 |    0.03 |        - |        - |        - |  35.25 KB |        2.27 |
| NativeSingle      | TaLib(...)hasor [24] | 1000  |   105.7 μs |   1.03 μs |   0.68 μs |  1.00 |    0.01 |        - |        - |        - |  15.55 KB |        1.00 |
| NativeParallel    | TaLib(...)hasor [24] | 1000  |   192.6 μs |  14.93 μs |   8.89 μs |  1.82 |    0.08 |   3.9063 |        - |        - |  54.84 KB |        3.53 |
|                   |                      |       |            |           |           |       |         |          |          |          |           |             |
| **BuilderFull**       | **TaLib(...)hasor [24]** | **10000** | **4,401.8 μs** | **232.56 μs** | **153.82 μs** |  **3.60** |    **0.12** |  **31.2500** |        **-** |        **-** | **786.53 KB** |        **5.02** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 10000 | 4,239.7 μs |  21.43 μs |  14.17 μs |  3.47 |    0.02 |        - |        - |        - | 316.73 KB |        2.02 |
| NativeSingle      | TaLib(...)hasor [24] | 10000 | 1,221.2 μs |   8.16 μs |   4.27 μs |  1.00 |    0.00 |  46.8750 |  46.8750 |  46.8750 |  156.6 KB |        1.00 |
| NativeParallel    | TaLib(...)hasor [24] | 10000 | 1,518.3 μs |  29.50 μs |  17.55 μs |  1.24 |    0.01 | 125.0000 | 125.0000 | 125.0000 | 548.11 KB |        3.50 |
