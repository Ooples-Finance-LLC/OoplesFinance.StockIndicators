```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)hasor [24]** | **1000**  |   **442.7 μs** | **21.76 μs** | **12.95 μs** |       **-** |  **82.84 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 1000  |   433.6 μs |  9.68 μs |  5.06 μs |       - |  35.25 KB |
| **BuilderFull**       | **TaLib(...)hasor [24]** | **10000** | **4,264.8 μs** | **63.63 μs** | **37.87 μs** | **31.2500** | **786.56 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 10000 | 4,225.4 μs | 28.03 μs | 16.68 μs |       - | 316.72 KB |
