```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)eriod [26]** |   **513.0 μs** | **41.04 μs** | **27.14 μs** |  **1.00** |    **0.07** |  **108.07 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)eriod [26] |   108.2 μs |  1.26 μs |  0.66 μs |  0.21 |    0.01 |   41.34 KB |        0.38 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)eriod [26]** | **4,732.7 μs** | **23.75 μs** | **12.42 μs** |  **1.00** |    **0.00** | **1038.75 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)eriod [26] | 1,082.0 μs | 14.01 μs |  9.27 μs |  0.23 |    0.00 |  331.38 KB |        0.32 |
