```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)eriod [26]** | **1000**  |   **425.9 μs** |  **2.73 μs** |  **1.43 μs** |       **-** |  **66.94 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 1000  |   423.2 μs |  2.41 μs |  1.26 μs |       - |  19.36 KB |
| **BuilderFull**       | **TaLib(...)eriod [26]** | **10000** | **4,185.8 μs** | **29.63 μs** | **17.63 μs** | **31.2500** | **630.03 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 10000 | 4,121.9 μs | 28.45 μs | 16.93 μs |       - | 160.18 KB |
