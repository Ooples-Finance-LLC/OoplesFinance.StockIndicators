```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Ratio | RatioSD | Gen0    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)eriod [26]** | **1000**  |   **423.9 μs** |  **9.45 μs** |  **5.62 μs** |  **3.73** |    **0.05** |       **-** |  **66.94 KB** |        **8.38** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 1000  |   417.9 μs |  3.23 μs |  1.92 μs |  3.67 |    0.02 |       - |  19.36 KB |        2.42 |
| NativeSingle      | TaLib(...)eriod [26] | 1000  |   113.7 μs |  0.50 μs |  0.26 μs |  1.00 |    0.00 |       - |   7.99 KB |        1.00 |
| NativeParallel    | TaLib(...)eriod [26] | 1000  |   193.5 μs | 15.43 μs |  9.18 μs |  1.70 |    0.08 |  1.9531 |  28.36 KB |        3.55 |
|                   |                      |       |            |          |          |       |         |         |           |             |
| **BuilderFull**       | **TaLib(...)eriod [26]** | **10000** | **4,113.0 μs** | **30.74 μs** | **18.29 μs** |  **3.58** |    **0.02** | **31.2500** | **630.04 KB** |        **8.04** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 10000 | 4,064.8 μs | 12.57 μs |  6.57 μs |  3.54 |    0.01 |       - | 160.22 KB |        2.04 |
| NativeSingle      | TaLib(...)eriod [26] | 10000 | 1,149.5 μs |  2.19 μs |  1.15 μs |  1.00 |    0.00 |       - |  78.36 KB |        1.00 |
| NativeParallel    | TaLib(...)eriod [26] | 10000 | 1,271.4 μs | 72.60 μs | 48.02 μs |  1.11 |    0.04 | 15.6250 | 274.51 KB |        3.50 |
