```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)eriod [26]** | **1000**  |   **543.6 μs** | **10.51 μs** |  **6.25 μs** |       **-** |  **66.53 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 1000  |   548.9 μs |  4.98 μs |  3.29 μs |       - |  18.94 KB |
| **BuilderFull**       | **TaLib(...)eriod [26]** | **10000** | **5,363.1 μs** | **42.70 μs** | **28.25 μs** | **31.2500** | **629.58 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 10000 | 5,348.5 μs | 16.59 μs |  9.87 μs |       - | 159.79 KB |
