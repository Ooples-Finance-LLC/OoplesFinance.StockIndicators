```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)dline [22]** | **1,046.7 μs** | **44.53 μs** | **26.50 μs** |  **1.00** |    **0.03** |  **223.38 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)dline [22] |   192.8 μs | 24.85 μs | 16.44 μs |  0.18 |    0.02 |  290.24 KB |        1.30 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)dline [22]** | **9,992.0 μs** | **36.12 μs** | **18.89 μs** |  **1.00** |    **0.00** | **2156.05 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)dline [22] | 1,875.3 μs | 55.37 μs | 36.63 μs |  0.19 |    0.00 |  2812.7 KB |        1.30 |
