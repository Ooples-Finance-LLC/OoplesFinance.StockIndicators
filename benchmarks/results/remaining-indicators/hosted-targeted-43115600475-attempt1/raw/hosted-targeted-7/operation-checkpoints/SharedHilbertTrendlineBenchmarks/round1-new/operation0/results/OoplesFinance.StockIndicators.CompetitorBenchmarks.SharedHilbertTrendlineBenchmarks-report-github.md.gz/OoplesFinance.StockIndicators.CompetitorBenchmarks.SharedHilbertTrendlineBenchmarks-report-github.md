```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  |   **879.7 μs** |  **3.66 μs** |  **1.91 μs** | **101.36 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  |   854.9 μs |  6.42 μs |  4.24 μs |  53.73 KB |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **8,399.6 μs** | **17.57 μs** |  **9.19 μs** | **946.03 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 8,343.4 μs | 23.49 μs | 12.28 μs | 476.23 KB |
