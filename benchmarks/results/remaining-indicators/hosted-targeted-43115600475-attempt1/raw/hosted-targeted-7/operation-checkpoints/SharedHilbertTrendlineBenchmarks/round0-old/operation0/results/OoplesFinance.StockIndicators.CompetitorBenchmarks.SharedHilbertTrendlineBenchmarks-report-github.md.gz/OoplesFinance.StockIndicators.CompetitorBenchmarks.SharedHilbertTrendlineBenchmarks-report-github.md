```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  |   **994.9 μs** |  **7.05 μs** |  **4.20 μs** | **100.94 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  | 1,001.6 μs |  8.43 μs |  5.57 μs |  53.31 KB |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **9,643.8 μs** | **77.67 μs** | **46.22 μs** | **945.68 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 9,652.0 μs | 43.50 μs | 25.89 μs | 475.87 KB |
