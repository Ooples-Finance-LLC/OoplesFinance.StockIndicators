```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  |   **858.0 μs** |   **3.15 μs** |   **1.87 μs** |  **6.51** |    **0.05** |        **-** |        **-** |        **-** |  **101.37 KB** |        **0.49** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  |   855.5 μs |   9.32 μs |   5.55 μs |  6.50 |    0.06 |        - |        - |        - |   53.68 KB |        0.26 |
| NativeSingle      | Skend(...)dline [22] | 1000  |   131.7 μs |   1.84 μs |   1.10 μs |  1.00 |    0.01 |  12.6953 |   2.9297 |        - |  207.71 KB |        1.00 |
| NativeParallel    | Skend(...)dline [22] | 1000  |   245.3 μs |  10.93 μs |   6.50 μs |  1.86 |    0.05 |  33.2031 |   9.7656 |        - |  528.53 KB |        2.54 |
|                   |                      |       |            |           |           |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **8,290.7 μs** | **126.58 μs** |  **66.20 μs** |  **5.43** |    **0.15** |        **-** |        **-** |        **-** |  **945.99 KB** |        **0.46** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 8,254.3 μs |  61.61 μs |  40.75 μs |  5.41 |    0.15 |        - |        - |        - |  476.18 KB |        0.23 |
| NativeSingle      | Skend(...)dline [22] | 10000 | 1,526.6 μs |  74.36 μs |  44.25 μs |  1.00 |    0.04 | 187.5000 | 148.4375 |  85.9375 | 2072.15 KB |        1.00 |
| NativeParallel    | Skend(...)dline [22] | 10000 | 3,453.9 μs | 182.61 μs | 120.79 μs |  2.26 |    0.10 | 421.8750 | 328.1250 | 140.6250 | 5258.93 KB |        2.54 |
