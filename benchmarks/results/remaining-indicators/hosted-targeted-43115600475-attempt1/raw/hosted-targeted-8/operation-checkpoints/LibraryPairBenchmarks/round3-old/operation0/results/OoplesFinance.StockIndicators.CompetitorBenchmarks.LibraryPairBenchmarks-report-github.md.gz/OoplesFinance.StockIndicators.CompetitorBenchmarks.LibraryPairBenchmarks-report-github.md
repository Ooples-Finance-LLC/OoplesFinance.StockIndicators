```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId         | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **QuanTAlib.Mama** |   **403.4 μs** |   **8.47 μs** |   **4.43 μs** |  **1.00** |    **0.01** | **164.02 KB** |        **1.00** |
|        |       |                |            |           |           |       |         |           |             |
| **Ooples** | **10000** | **QuanTAlib.Mama** | **3,914.0 μs** | **201.28 μs** | **119.78 μs** |  **1.00** |    **0.04** | **1588.5 KB** |        **1.00** |
