```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Mama** |   **345.9 μs** | **16.49 μs** |  **9.82 μs** |  **1.00** |    **0.04** |  **164.44 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Mama |   201.4 μs |  7.08 μs |  3.70 μs |  0.58 |    0.02 |   93.47 KB |        0.57 |
|            |       |                |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Mama** | **3,463.1 μs** | **47.03 μs** | **31.11 μs** |  **1.00** |    **0.01** | **1588.59 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Mama | 1,969.1 μs | 29.46 μs | 17.53 μs |  0.57 |    0.01 |  881.53 KB |        0.55 |
