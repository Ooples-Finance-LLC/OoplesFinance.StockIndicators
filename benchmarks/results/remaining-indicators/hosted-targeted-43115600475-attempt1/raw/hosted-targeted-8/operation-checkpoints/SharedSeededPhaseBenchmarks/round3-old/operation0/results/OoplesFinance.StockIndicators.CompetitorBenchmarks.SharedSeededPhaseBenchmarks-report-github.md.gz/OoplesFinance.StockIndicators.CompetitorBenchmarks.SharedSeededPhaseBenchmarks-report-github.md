```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Mama** | **1000**  |   **332.2 μs** |  **10.22 μs** |   **6.08 μs** |       **-** |  **82.61 KB** |
| BuilderLatestOnly | QuanTAlib.Mama | 1000  |   332.8 μs |   7.62 μs |   4.53 μs |  1.9531 |     35 KB |
| **BuilderFull**       | **QuanTAlib.Mama** | **10000** | **3,359.9 μs** | **272.77 μs** | **162.32 μs** | **31.2500** | **786.11 KB** |
| BuilderLatestOnly | QuanTAlib.Mama | 10000 | 3,229.9 μs |  20.09 μs |  10.51 μs |       - | 316.38 KB |
