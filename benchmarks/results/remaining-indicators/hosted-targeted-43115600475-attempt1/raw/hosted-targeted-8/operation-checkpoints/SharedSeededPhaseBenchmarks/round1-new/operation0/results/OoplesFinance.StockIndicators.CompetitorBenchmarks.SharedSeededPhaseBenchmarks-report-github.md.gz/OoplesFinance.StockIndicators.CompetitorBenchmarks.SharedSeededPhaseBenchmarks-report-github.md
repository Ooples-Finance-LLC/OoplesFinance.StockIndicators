```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Mama** | **1000**  |   **277.5 μs** | **10.67 μs** |  **5.58 μs** |       **-** |       **-** |  **83.03 KB** |
| BuilderLatestOnly | QuanTAlib.Mama | 1000  |   282.9 μs | 14.75 μs |  9.76 μs |  1.9531 |       - |  35.43 KB |
| **BuilderFull**       | **QuanTAlib.Mama** | **10000** | **2,650.2 μs** | **78.12 μs** | **46.49 μs** | **46.8750** | **15.6250** | **786.56 KB** |
| BuilderLatestOnly | QuanTAlib.Mama | 10000 | 2,722.7 μs | 96.64 μs | 57.51 μs | 15.6250 |       - | 316.74 KB |
