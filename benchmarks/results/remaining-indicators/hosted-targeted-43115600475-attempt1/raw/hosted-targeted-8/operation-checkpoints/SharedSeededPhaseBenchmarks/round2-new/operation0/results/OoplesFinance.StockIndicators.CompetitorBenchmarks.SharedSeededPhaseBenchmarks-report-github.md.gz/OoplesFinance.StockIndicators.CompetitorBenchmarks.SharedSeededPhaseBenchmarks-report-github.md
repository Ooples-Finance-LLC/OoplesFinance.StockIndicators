```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |-----------:|----------:|----------:|------:|--------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Mama** | **1000**  |   **277.7 μs** |  **19.43 μs** |  **12.85 μs** |  **1.66** |    **0.08** |       **-** |       **-** |       **-** |   **83.03 KB** |        **1.48** |
| BuilderLatestOnly | QuanTAlib.Mama | 1000  |   281.1 μs |   8.52 μs |   5.07 μs |  1.68 |    0.04 |  1.9531 |       - |       - |   35.42 KB |        0.63 |
| NativeSingle      | QuanTAlib.Mama | 1000  |   166.9 μs |   4.15 μs |   2.47 μs |  1.00 |    0.02 |  2.9297 |       - |       - |   56.24 KB |        1.00 |
| NativeParallel    | QuanTAlib.Mama | 1000  |   528.1 μs |  65.13 μs |  43.08 μs |  3.17 |    0.25 |  3.9063 |       - |       - |  119.62 KB |        2.13 |
|                   |                |       |            |           |           |       |         |         |         |         |            |             |
| **BuilderFull**       | **QuanTAlib.Mama** | **10000** | **2,740.3 μs** |  **52.58 μs** |  **31.29 μs** |  **1.54** |    **0.04** | **46.8750** | **15.6250** |       **-** |  **786.56 KB** |        **1.43** |
| BuilderLatestOnly | QuanTAlib.Mama | 10000 | 2,626.6 μs |  85.28 μs |  44.60 μs |  1.48 |    0.04 | 15.6250 |       - |       - |  316.73 KB |        0.58 |
| NativeSingle      | QuanTAlib.Mama | 10000 | 1,779.8 μs |  66.30 μs |  43.85 μs |  1.00 |    0.03 | 46.8750 | 31.2500 | 31.2500 |   548.7 KB |        1.00 |
| NativeParallel    | QuanTAlib.Mama | 10000 | 3,604.0 μs | 219.89 μs | 145.45 μs |  2.03 |    0.09 | 31.2500 |       - |       - | 1139.36 KB |        2.08 |
