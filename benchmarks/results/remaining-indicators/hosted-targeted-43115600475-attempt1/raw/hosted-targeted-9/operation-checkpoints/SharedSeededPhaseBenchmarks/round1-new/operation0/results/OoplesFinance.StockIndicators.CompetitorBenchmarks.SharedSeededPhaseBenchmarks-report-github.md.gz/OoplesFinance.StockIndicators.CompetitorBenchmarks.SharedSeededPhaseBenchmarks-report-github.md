```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetMama** | **1000**  |   **282.8 μs** |  **6.06 μs** |  **4.01 μs** |       **-** |       **-** |     **83 KB** |
| BuilderLatestOnly | Skender.GetMama | 1000  |   279.6 μs |  6.85 μs |  4.08 μs |  1.9531 |       - |  35.42 KB |
| **BuilderFull**       | **Skender.GetMama** | **10000** | **2,860.1 μs** | **82.68 μs** | **54.69 μs** | **46.8750** | **15.6250** | **786.56 KB** |
| BuilderLatestOnly | Skender.GetMama | 10000 | 2,714.7 μs | 29.13 μs | 15.23 μs | 15.6250 |       - | 316.81 KB |
