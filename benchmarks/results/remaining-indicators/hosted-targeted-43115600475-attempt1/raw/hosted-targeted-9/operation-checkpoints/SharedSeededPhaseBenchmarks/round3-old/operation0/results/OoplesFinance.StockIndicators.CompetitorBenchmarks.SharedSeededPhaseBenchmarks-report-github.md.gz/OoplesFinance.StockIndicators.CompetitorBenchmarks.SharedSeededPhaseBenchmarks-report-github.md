```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetMama** | **1000**  |   **338.9 μs** |  **15.63 μs** | **10.34 μs** |       **-** |  **82.61 KB** |
| BuilderLatestOnly | Skender.GetMama | 1000  |   325.2 μs |   2.58 μs |  1.35 μs |       - |  35.01 KB |
| **BuilderFull**       | **Skender.GetMama** | **10000** | **3,272.6 μs** |  **30.11 μs** | **17.92 μs** | **31.2500** | **786.25 KB** |
| BuilderLatestOnly | Skender.GetMama | 10000 | 3,286.0 μs | 147.91 μs | 97.83 μs |       - | 316.43 KB |
