```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetMama** | **1000**  |   **346.1 μs** | **11.93 μs** |  **7.89 μs** |  **3.9063** |  **82.61 KB** |
| BuilderLatestOnly | Skender.GetMama | 1000  |   335.9 μs | 11.82 μs |  7.03 μs |       - |  35.02 KB |
| **BuilderFull**       | **Skender.GetMama** | **10000** | **3,332.8 μs** | **43.30 μs** | **25.77 μs** | **31.2500** | **786.09 KB** |
| BuilderLatestOnly | Skender.GetMama | 10000 | 3,340.6 μs | 27.41 μs | 16.31 μs |       - | 316.33 KB |
