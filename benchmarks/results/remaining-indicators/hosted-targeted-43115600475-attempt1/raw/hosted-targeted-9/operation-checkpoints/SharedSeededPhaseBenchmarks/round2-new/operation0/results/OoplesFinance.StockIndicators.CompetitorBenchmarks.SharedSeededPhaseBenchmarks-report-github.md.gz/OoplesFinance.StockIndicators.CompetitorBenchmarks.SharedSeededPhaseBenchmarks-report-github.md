```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetMama** | **1000**  |   **284.99 μs** |   **1.072 μs** |  **0.561 μs** |  **3.84** |    **0.03** |        **-** |        **-** |        **-** |   **83.03 KB** |        **0.43** |
| BuilderLatestOnly | Skender.GetMama | 1000  |   285.41 μs |   1.861 μs |  1.107 μs |  3.84 |    0.03 |   1.9531 |        - |        - |   35.42 KB |        0.18 |
| NativeSingle      | Skender.GetMama | 1000  |    74.29 μs |   1.077 μs |  0.641 μs |  1.00 |    0.01 |  11.7188 |   2.9297 |        - |  192.06 KB |        1.00 |
| NativeParallel    | Skender.GetMama | 1000  |   160.47 μs |   6.384 μs |  3.339 μs |  2.16 |    0.05 |  31.2500 |   8.7891 |        - |  489.37 KB |        2.55 |
|                   |                 |       |             |            |           |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetMama** | **10000** | **2,920.45 μs** | **137.643 μs** | **81.909 μs** |  **3.39** |    **0.09** |  **46.8750** |  **15.6250** |        **-** |   **786.6 KB** |        **0.41** |
| BuilderLatestOnly | Skender.GetMama | 10000 | 2,887.30 μs |  43.234 μs | 22.612 μs |  3.35 |    0.04 |        - |        - |        - |  316.85 KB |        0.17 |
| NativeSingle      | Skender.GetMama | 10000 |   862.61 μs |  13.155 μs |  7.828 μs |  1.00 |    0.01 | 179.6875 | 140.6250 |  85.9375 |  1915.7 KB |        1.00 |
| NativeParallel    | Skender.GetMama | 10000 | 1,643.29 μs | 112.861 μs | 74.650 μs |  1.91 |    0.08 | 421.8750 | 335.9375 | 156.2500 | 4868.55 KB |        2.54 |
