```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId          | Mean        | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |------------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetMama** |   **506.49 μs** | **14.134 μs** | **9.349 μs** |  **1.00** |    **0.02** |  **164.44 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetMama |    83.67 μs |  2.341 μs | 1.224 μs |  0.17 |    0.00 |  245.63 KB |        1.49 |
|            |       |                 |             |           |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetMama** | **4,959.62 μs** | **10.905 μs** | **7.213 μs** |  **1.00** |    **0.00** | **1590.89 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetMama |   843.78 μs | 13.875 μs | 8.257 μs |  0.17 |    0.00 | 2406.52 KB |        1.51 |
