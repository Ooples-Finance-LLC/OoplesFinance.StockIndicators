$ErrorActionPreference='Stop'
$profileRoot='C:\Users\cheat\StockIndicators-Recovery-20261021\hilbert-mode-published-profile-20261025'
$benchmarkRoot='C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-t3-word-binade-20261024\benchmarks\OoplesFinance.StockIndicators.CompetitorBenchmarks\bin\Release\net10.0'
$assembly=[Reflection.Assembly]::LoadFrom("$benchmarkRoot/OoplesFinance.StockIndicators.CompetitorBenchmarks.dll")
$benchmarkType=$assembly.GetType('OoplesFinance.StockIndicators.CompetitorBenchmarks.LibraryPairBenchmarks',$true)
$benchmark=[Activator]::CreateInstance($benchmarkType)
$benchmark.PairId='TaLib.Functions.HtTrendMode';$benchmark.Bars=10000;$benchmark.Setup()
for($i=0;$i -lt 10;$i++) {$null=$benchmark.Ooples()}
@{pid=$PID;production_sha256=(Get-FileHash "$benchmarkRoot/OoplesFinance.StockIndicators.dll" -Algorithm SHA256).Hash.ToLowerInvariant();benchmark_sha256=(Get-FileHash "$benchmarkRoot/OoplesFinance.StockIndicators.CompetitorBenchmarks.dll" -Algorithm SHA256).Hash.ToLowerInvariant()} | ConvertTo-Json | Set-Content -LiteralPath "$profileRoot/ready.json" -Encoding utf8
$deadline=[DateTime]::UtcNow.AddSeconds(60)
while(!(Test-Path -LiteralPath "$profileRoot/go")) {if([DateTime]::UtcNow -gt $deadline){throw 'Trace did not attach'};Start-Sleep -Milliseconds 100}
for($i=0;$i -lt 500;$i++) {$null=$benchmark.Ooples()}
@{completed=$true;invocations=500;bars=10000;note='Sampled-thread profile using qualified source-matched binaries; not timing qualification.'} | ConvertTo-Json | Set-Content -LiteralPath "$profileRoot/completed.json" -Encoding utf8
