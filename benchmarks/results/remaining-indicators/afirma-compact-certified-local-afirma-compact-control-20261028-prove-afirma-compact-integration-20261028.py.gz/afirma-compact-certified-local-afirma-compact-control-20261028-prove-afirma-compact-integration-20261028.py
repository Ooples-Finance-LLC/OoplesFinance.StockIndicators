from pathlib import Path
import gzip,hashlib,importlib.util,json,subprocess
root=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
repo=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
state=json.loads((root/'zigzag-afirma-combined-20261028/status.json').read_text())
assert state['status']=='checks-passed-review-and-publication-pending'
assert state['unit']['passed']==29 and state['parity']['passed']==28 and state['gpu_passed']==100
assert state['checks']['inventory-tests']=='passed'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==state['input_head']
qualified='e94ddf44139decb7b298d6ef06527e4beb74f5ee'
for source,paths in [(qualified,['src/Indicators/FixedKernelSnapshots.cs','tests/ModelsTests/WindowedSincCompactTests.cs']),('1d964b3bf9a1bc9451838d090ee11dba439d4962',['src/Indicators/ZigZagSnapshot.cs','tests/ModelsTests/ZigZagExactScaleTests.cs'])]:
    subprocess.run(['git','diff','--exit-code',source,'HEAD','--',*paths],cwd=repo,check=True)
for path,digest in state['production_dll_sha256'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
spec=importlib.util.spec_from_file_location('gpu',repo/'scripts/verify-competitor-local-gpu.py');gpu=importlib.util.module_from_spec(spec);spec.loader.exec_module(gpu)
receipt=json.loads((gpu.EVIDENCE/'receipt.json').read_text());raw=gzip.decompress((gpu.EVIDENCE/'gpu.trx.gz').read_bytes())
gpu.verify_evidence(receipt,raw,json.loads(gpu.METHODS.read_text()),gpu.source_fingerprint(repo))
proof={'combined_code_source':state['input_head'],'individual_afirma_qualified_source':qualified,'source_fingerprint_sha256':receipt['source_sha256'],'fresh_combined_tree_checks':{'unit':29,'parity':28,'gpu':100,'inventory':8},'production_dll_sha256':state['production_dll_sha256'],'note':'Fresh combined ZigZag/Afirma correctness evidence. Controlled timing rows retain their individually measured source commits; no individual GPU receipt is relabeled as combined-tree evidence.'}
(repo/'benchmarks/results/remaining-indicators/afirma-compact-integration-source-proof-20261028.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print('Verified fresh combined-tree qualification and preserved measured Afirma implementation')
