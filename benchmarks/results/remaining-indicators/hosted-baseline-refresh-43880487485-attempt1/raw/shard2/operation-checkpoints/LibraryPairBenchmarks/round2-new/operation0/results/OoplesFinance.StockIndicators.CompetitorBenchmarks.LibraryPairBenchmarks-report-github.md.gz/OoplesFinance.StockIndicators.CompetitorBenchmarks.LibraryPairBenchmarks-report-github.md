```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |------------------- |-----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Realized** |   **738.3 μs** | **47.37 μs** | **31.33 μs** |  **1.00** |    **0.06** |  **74.93 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Realized |   128.3 μs |  4.50 μs |  2.68 μs |  0.17 |    0.01 |  72.39 KB |        0.97 |
|            |       |                    |            |          |          |       |         |           |             |
| **Ooples**     | **10000** | **QuanTAlib.Realized** | **3,468.0 μs** | **75.31 μs** | **44.82 μs** |  **1.00** |    **0.02** | **804.59 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Realized | 1,233.0 μs | 38.20 μs | 25.27 μs |  0.36 |    0.01 | 644.01 KB |        0.80 |
