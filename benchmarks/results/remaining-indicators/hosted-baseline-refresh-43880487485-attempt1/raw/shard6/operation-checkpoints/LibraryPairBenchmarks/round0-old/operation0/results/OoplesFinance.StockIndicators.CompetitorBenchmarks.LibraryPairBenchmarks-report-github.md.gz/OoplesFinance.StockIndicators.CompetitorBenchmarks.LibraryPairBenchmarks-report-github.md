```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId          | Mean     | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |---------------- |---------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **QuanTAlib.Slope** | **106.1 μs** | **35.33 μs** | **23.37 μs** |  **1.04** |    **0.29** |  **158.16 KB** |        **1.00** |
|        |       |                 |          |          |          |       |         |            |             |
| **Ooples** | **10000** | **QuanTAlib.Slope** | **785.7 μs** | **57.32 μs** | **34.11 μs** |  **1.00** |    **0.06** | **1545.91 KB** |        **1.00** |
