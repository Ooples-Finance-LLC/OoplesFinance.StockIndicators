```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId          | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Slope** |    **89.95 μs** |  **7.936 μs** |  **4.151 μs** |  **1.00** |    **0.06** |  **158.16 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Slope |   106.89 μs |  3.244 μs |  1.697 μs |  1.19 |    0.05 |  514.91 KB |        3.26 |
|            |       |                 |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Slope** |   **765.86 μs** | **15.323 μs** |  **9.119 μs** |  **1.00** |    **0.02** | **1545.91 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Slope | 1,022.83 μs | 39.335 μs | 20.573 μs |  1.34 |    0.03 | 5119.93 KB |        3.31 |
