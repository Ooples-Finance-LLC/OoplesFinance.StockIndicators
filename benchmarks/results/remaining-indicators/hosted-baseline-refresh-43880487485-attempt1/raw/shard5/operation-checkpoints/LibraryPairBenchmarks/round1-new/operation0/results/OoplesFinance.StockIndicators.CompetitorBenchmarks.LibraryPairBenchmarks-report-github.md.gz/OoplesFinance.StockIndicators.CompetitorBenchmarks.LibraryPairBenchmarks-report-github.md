```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId              | Mean       | Error   | StdDev  | Ratio | Allocated  | Alloc Ratio |
|------- |------ |-------------------- |-----------:|--------:|--------:|------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetElderRay** |   **122.4 μs** | **2.48 μs** | **1.30 μs** |  **1.00** |  **108.12 KB** |        **1.00** |
|        |       |                     |            |         |         |       |            |             |
| **Ooples** | **10000** | **Skender.GetElderRay** | **1,025.5 μs** | **7.53 μs** | **3.94 μs** |  **1.00** | **1056.09 KB** |        **1.00** |
