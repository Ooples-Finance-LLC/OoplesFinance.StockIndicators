```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetElderRay** |   **186.9 μs** | **58.51 μs** | **30.60 μs** |  **1.03** |    **0.26** |  **108.12 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetElderRay |   112.3 μs | 22.65 μs | 13.48 μs |  0.62 |    0.14 |  340.89 KB |        3.15 |
|            |       |                     |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetElderRay** | **1,022.8 μs** | **28.83 μs** | **17.16 μs** |  **1.00** |    **0.02** | **1056.05 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetElderRay | 1,150.8 μs | 48.60 μs | 28.92 μs |  1.13 |    0.03 | 3320.05 KB |        3.14 |
