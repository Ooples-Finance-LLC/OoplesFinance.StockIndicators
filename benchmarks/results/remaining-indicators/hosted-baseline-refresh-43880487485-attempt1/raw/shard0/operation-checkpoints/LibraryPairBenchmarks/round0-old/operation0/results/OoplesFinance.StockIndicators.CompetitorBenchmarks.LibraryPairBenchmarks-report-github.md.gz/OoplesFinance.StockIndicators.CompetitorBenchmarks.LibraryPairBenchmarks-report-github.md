```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId             | Mean      | Error    | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |------------------- |----------:|---------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetAwesome** |  **81.39 μs** | **11.09 μs** |  **6.597 μs** |  **1.01** |    **0.11** |  **102.1 KB** |        **1.00** |
|        |       |                    |           |          |           |       |         |           |             |
| **Ooples** | **10000** | **Skender.GetAwesome** | **447.46 μs** | **24.16 μs** | **14.375 μs** |  **1.00** |    **0.04** | **970.98 KB** |        **1.00** |
