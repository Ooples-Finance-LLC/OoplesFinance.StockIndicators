```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAwesome** |  **80.00 μs** | **13.587 μs** |  **8.085 μs** |  **1.01** |    **0.13** |  **102.13 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAwesome |  75.46 μs |  7.629 μs |  3.990 μs |  0.95 |    0.10 |  171.51 KB |        1.68 |
|            |       |                    |           |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAwesome** | **461.86 μs** | **77.787 μs** | **46.290 μs** |  **1.01** |    **0.13** |  **971.62 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAwesome | 845.73 μs | 38.326 μs | 22.807 μs |  1.85 |    0.16 | 1630.49 KB |        1.68 |
