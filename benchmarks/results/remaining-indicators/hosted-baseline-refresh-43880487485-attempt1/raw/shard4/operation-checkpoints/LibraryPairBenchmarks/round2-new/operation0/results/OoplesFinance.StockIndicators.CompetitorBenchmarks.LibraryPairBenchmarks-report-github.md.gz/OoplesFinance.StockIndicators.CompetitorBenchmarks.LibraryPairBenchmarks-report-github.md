```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetDynamic** | **405.26 μs** | **26.930 μs** | **17.812 μs** |  **1.00** |    **0.06** |   **99.09 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetDynamic |  67.78 μs |  0.984 μs |  0.515 μs |  0.17 |    0.01 |  110.41 KB |        1.11 |
|            |       |                    |           |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetDynamic** | **716.53 μs** | **29.887 μs** | **17.785 μs** |  **1.00** |    **0.03** |  **873.86 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetDynamic | 693.41 μs | 26.215 μs | 17.340 μs |  0.97 |    0.03 | 1071.65 KB |        1.23 |
