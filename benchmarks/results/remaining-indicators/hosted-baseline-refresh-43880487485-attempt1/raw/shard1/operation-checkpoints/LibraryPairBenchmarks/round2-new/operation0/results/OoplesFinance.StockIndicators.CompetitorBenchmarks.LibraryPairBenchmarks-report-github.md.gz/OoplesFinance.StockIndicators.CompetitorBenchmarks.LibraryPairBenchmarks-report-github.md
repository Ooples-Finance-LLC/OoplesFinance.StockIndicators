```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Historical** | **1,240.2 μs** | **37.67 μs** | **22.42 μs** |  **1.00** |    **0.02** |   **74.93 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Historical |   583.3 μs | 27.42 μs | 16.32 μs |  0.47 |    0.01 |  438.98 KB |        5.86 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Historical** | **5,766.2 μs** | **44.64 μs** | **26.57 μs** |  **1.00** |    **0.01** |  **804.59 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Historical | 5,854.2 μs | 78.66 μs | 41.14 μs |  1.02 |    0.01 | 4375.05 KB |        5.44 |
