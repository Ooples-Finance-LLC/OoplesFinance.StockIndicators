```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId           | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |----------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetSlope** |   **118.9 μs** | **36.80 μs** | **24.34 μs** |  **1.04** |    **0.30** |  **158.16 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetSlope |   108.2 μs |  1.51 μs |  0.79 μs |  0.95 |    0.20 |  288.42 KB |        1.82 |
|            |       |                  |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetSlope** |   **903.2 μs** | **37.69 μs** | **22.43 μs** |  **1.00** |    **0.03** | **1545.88 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetSlope | 1,087.9 μs | 24.86 μs | 14.79 μs |  1.21 |    0.03 |  2829.4 KB |        1.83 |
