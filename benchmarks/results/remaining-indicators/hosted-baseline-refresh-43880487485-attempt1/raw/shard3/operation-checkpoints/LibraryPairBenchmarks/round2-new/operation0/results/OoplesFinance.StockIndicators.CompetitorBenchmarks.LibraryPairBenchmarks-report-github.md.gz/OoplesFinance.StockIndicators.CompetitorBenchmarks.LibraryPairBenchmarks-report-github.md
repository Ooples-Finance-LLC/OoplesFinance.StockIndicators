```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Mgdi** |  **87.76 μs** |  **4.009 μs** |  **2.385 μs** |  **1.00** |    **0.04** |  **99.09 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Mgdi |  56.02 μs |  0.418 μs |  0.219 μs |  0.64 |    0.02 |  66.22 KB |        0.67 |
|            |       |                |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **QuanTAlib.Mgdi** | **479.73 μs** | **16.964 μs** | **10.095 μs** |  **1.00** |    **0.03** |  **869.6 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Mgdi | 557.39 μs | 15.330 μs | 10.140 μs |  1.16 |    0.03 | 637.84 KB |        0.73 |
