```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId         | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **QuanTAlib.Mgdi** |  **80.80 μs** |  **5.791 μs** | **3.029 μs** |  **1.00** |    **0.05** |  **99.09 KB** |        **1.00** |
|        |       |                |           |           |          |       |         |           |             |
| **Ooples** | **10000** | **QuanTAlib.Mgdi** | **482.61 μs** | **12.533 μs** | **7.458 μs** |  **1.00** |    **0.02** | **873.53 KB** |        **1.00** |
