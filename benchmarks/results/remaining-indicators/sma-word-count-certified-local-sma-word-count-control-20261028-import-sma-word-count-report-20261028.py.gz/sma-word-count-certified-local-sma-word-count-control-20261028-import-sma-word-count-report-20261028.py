from pathlib import Path
import datetime,hashlib,json,re,sys
name='sma-word-count'
run=f'local-{name}-control-20261028'
live=Path('C:/Users/cheat/Documents/OoplesFinance-Reports/competitor-performance.html')
out=live.parent/(name+'-refresh-'+run)
stage=json.loads((out/'staged.json').read_text()); verified=json.loads((out/'browser-verification.json').read_text())
candidate=out/'candidate.html'
assert verified['comparisons']==verified['displayed_table_comparisons']==verified['exported_comparisons']==802
assert not verified['javascript_errors'] and verified['run_id']==run
assert hashlib.sha256(candidate.read_bytes()).hexdigest()==stage['candidate_sha256']==verified['report_sha256']
assert hashlib.sha256(live.read_bytes()).hexdigest()==stage['before_sha256']
def rows(p):return json.loads(re.search(r'<script[^>]*id="dataset"[^>]*>(.*?)</script>',p.read_text(encoding='utf-8'),re.S)[1])['rows']
before=rows(live);after=rows(candidate)
source=json.loads((out/'measurement.json').read_text(encoding='utf-8'))['source_sha']
pairs={r['pair'] for r in after if r['source_sha']==source}
builder_pairs={r['pair'] for r in stage['builder_rows'] if r['source_sha']==source}
same=0
for a,b in zip(before,after,strict=True):
    assert (a['pair'],a['bars'])==(b['pair'],b['bars'])
    if a['pair'] not in pairs:assert a==b;same+=1
assert same==stage['unchanged_baseline_rows']
def builder(p):return json.loads(re.search(r'<script[^>]*id="current-competitor-data"[^>]*>(.*?)</script>',p.read_text(encoding='utf-8'),re.S)[1])
def index(d):return {(r['pair'],r['bars'],r['mode']):{**r,'run_id':str(receipt['run_id']),'source_sha':receipt['source_sha'],'measurement_url':receipt.get('measurement_url','https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/'+str(receipt['run_id']))} for receipt in d['receipts'] for r in receipt['comparisons']}
a,b=index(builder(live)),index(builder(candidate));assert a.keys()<=b.keys()
assert len(b)-len(a)==stage.get('added_builder_slots',0)
assert sum(a[k]==b[k] for k in a)==len(a)-stage.get('replaced_builder_slots',stage['changed_builder_slots'])
for k in a:
    if k[0] not in builder_pairs:assert a[k]==b[k]
assert list(sorted(b.values(),key=lambda r:(r['pair'],r['bars'],r['mode'])))==list(sorted(stage['builder_rows'],key=lambda r:(r['pair'],r['bars'],r['mode'])))
temporary=live.with_suffix('.certified-update.tmp');assert not temporary.exists()
temporary.write_bytes(candidate.read_bytes());temporary.replace(live)
assert hashlib.sha256(live.read_bytes()).hexdigest()==stage['candidate_sha256']
(out/'imported.json').write_text(json.dumps({**stage,'unchanged_rows':same,'run_id':run,'imported_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'browser_verified':True},indent=2))
print('Updated actual measured rows; verified all802 comparisons and preserved',same,'other rows:',stage['candidate_sha256'])
