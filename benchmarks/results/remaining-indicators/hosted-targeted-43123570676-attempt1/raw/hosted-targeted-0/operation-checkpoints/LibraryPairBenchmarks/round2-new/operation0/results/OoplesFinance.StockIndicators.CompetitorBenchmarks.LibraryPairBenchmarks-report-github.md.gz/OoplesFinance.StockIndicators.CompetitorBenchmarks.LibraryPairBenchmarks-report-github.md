```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean       | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |------------------- |-----------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ad** | **146.370 μs** | **28.7906 μs** | **19.0432 μs** |  **1.01** |    **0.17** |  **72.91 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ad |   5.039 μs |  0.6200 μs |  0.3689 μs |  0.03 |    0.00 |   8.15 KB |        0.11 |
|            |       |                    |            |            |            |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ad** | **921.240 μs** | **53.4778 μs** | **35.3723 μs** |  **1.00** |    **0.05** | **710.93 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ad |  29.278 μs |  5.0173 μs |  2.9857 μs |  0.03 |    0.00 |   84.7 KB |        0.12 |
