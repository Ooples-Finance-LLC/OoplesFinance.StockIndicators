```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |---------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **114.7 μs** |  **1.71 μs** |  **1.02 μs** |  **64.89 KB** |
| BuilderLatestOnly | Ad        | 1000  |   103.8 μs |  0.76 μs |  0.40 μs |  17.28 KB |
| **BuilderFull**       | **Ad**        | **10000** | **1,075.6 μs** | **47.18 μs** | **31.21 μs** | **627.77 KB** |
| BuilderLatestOnly | Ad        | 10000 |   970.0 μs |  6.72 μs |  3.51 μs |  157.9 KB |
