```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean         | Error      | StdDev    | Ratio | RatioSD | Gen0   | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |-------------:|-----------:|----------:|------:|--------:|-------:|-------:|----------:|------------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **115.439 μs** |  **3.7755 μs** | **1.9747 μs** | **43.39** |    **0.73** |      **-** |      **-** |  **64.89 KB** |        **8.24** |
| BuilderLatestOnly | Ad        | 1000  |   105.852 μs |  0.5159 μs | 0.3412 μs | 39.78 |    0.24 |      - |      - |  17.28 KB |        2.19 |
| NativeSingle      | Ad        | 1000  |     2.661 μs |  0.0243 μs | 0.0145 μs |  1.00 |    0.01 | 0.0916 |      - |   7.88 KB |        1.00 |
| NativeParallel    | Ad        | 1000  |    81.437 μs |  5.5315 μs | 3.6587 μs | 30.61 |    1.32 |      - |      - |   8.17 KB |        1.04 |
|                   |           |       |              |            |           |       |         |        |        |           |             |
| **BuilderFull**       | **Ad**        | **10000** | **1,058.725 μs** | **11.0272 μs** | **7.2938 μs** | **49.20** |    **0.39** |      **-** |      **-** | **627.77 KB** |        **8.03** |
| BuilderLatestOnly | Ad        | 10000 |   963.942 μs |  4.5896 μs | 2.4005 μs | 44.79 |    0.22 |      - |      - | 157.96 KB |        2.02 |
| NativeSingle      | Ad        | 10000 |    21.521 μs |  0.1898 μs | 0.0993 μs |  1.00 |    0.01 | 0.8545 | 0.1221 |  78.19 KB |        1.00 |
| NativeParallel    | Ad        | 10000 |   103.846 μs |  6.1848 μs | 4.0908 μs |  4.83 |    0.18 |      - |      - |  78.48 KB |        1.00 |
