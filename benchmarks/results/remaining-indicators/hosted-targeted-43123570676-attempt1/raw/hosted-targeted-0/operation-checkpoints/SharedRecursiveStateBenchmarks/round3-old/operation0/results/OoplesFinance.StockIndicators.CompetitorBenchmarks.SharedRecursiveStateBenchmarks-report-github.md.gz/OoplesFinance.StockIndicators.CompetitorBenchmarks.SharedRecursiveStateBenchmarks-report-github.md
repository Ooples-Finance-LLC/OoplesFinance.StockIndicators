```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error    | StdDev  | Allocated |
|------------------ |---------- |------ |-----------:|---------:|--------:|----------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **146.7 μs** | **14.75 μs** | **7.72 μs** |  **64.92 KB** |
| BuilderLatestOnly | Ad        | 1000  |   105.6 μs |  1.30 μs | 0.86 μs |  17.27 KB |
| **BuilderFull**       | **Ad**        | **10000** | **1,071.2 μs** | **10.59 μs** | **5.54 μs** | **627.76 KB** |
| BuilderLatestOnly | Ad        | 10000 | 1,067.9 μs | 10.29 μs | 6.12 μs | 157.94 KB |
