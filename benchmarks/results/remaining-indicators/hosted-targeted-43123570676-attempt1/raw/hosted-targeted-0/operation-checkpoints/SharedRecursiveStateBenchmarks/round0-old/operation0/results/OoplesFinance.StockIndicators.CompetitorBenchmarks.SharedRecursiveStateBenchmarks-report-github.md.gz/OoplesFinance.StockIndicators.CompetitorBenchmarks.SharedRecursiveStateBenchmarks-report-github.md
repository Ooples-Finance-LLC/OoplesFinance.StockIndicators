```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error   | StdDev  | Allocated |
|------------------ |---------- |------ |-----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **126.3 μs** | **2.28 μs** | **1.19 μs** |  **64.88 KB** |
| BuilderLatestOnly | Ad        | 1000  |   104.2 μs | 0.54 μs | 0.36 μs |  17.27 KB |
| **BuilderFull**       | **Ad**        | **10000** | **1,066.6 μs** | **6.31 μs** | **3.75 μs** | **627.76 KB** |
| BuilderLatestOnly | Ad        | 10000 |   964.2 μs | 9.15 μs | 4.79 μs | 157.95 KB |
