```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error    | StdDev   | Ratio | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|---------:|---------:|------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Mult** | **140.04 μs** | **3.027 μs** | **1.583 μs** |  **1.00** |  **98.26 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Mult |  15.60 μs | 0.951 μs | 0.566 μs |  0.11 |  39.29 KB |        0.40 |
|            |       |                      |           |          |          |       |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Mult** | **290.34 μs** | **4.878 μs** | **2.903 μs** |  **1.00** | **959.47 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Mult | 125.70 μs | 4.972 μs | 2.601 μs |  0.43 | 330.64 KB |        0.34 |
