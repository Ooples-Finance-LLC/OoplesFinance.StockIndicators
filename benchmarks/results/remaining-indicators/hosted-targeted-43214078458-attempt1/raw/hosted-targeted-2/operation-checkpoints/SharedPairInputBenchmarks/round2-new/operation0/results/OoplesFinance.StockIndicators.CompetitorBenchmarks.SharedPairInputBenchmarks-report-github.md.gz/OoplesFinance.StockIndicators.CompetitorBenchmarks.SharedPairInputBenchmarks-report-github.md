```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Mult**      |   **6.607 μs** | **0.1215 μs** | **0.0635 μs** |  **6.43** |    **0.14** |  **3.4180** |  **0.4883** |  **56.82 KB** |        **7.22** |
| BuilderLatestOnly | 1000  | Mult      |   4.392 μs | 0.0597 μs | 0.0355 μs |  4.27 |    0.09 |  0.5493 |       - |   9.21 KB |        1.17 |
| NativeSingle      | 1000  | Mult      |   1.028 μs | 0.0346 μs | 0.0206 μs |  1.00 |    0.03 |  0.4807 |  0.0076 |   7.87 KB |        1.00 |
| NativeParallel    | 1000  | Mult      |  86.340 μs | 0.5398 μs | 0.3212 μs | 84.02 |    1.63 |  0.4883 |       - |   8.14 KB |        1.03 |
|                   |       |           |            |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **10000** | **Mult**      | **123.570 μs** | **2.1632 μs** | **1.1314 μs** | **16.42** |    **0.18** | **33.2031** | **13.6719** | **549.82 KB** |        **7.03** |
| BuilderLatestOnly | 10000 | Mult      | 107.326 μs | 3.5414 μs | 2.3424 μs | 14.26 |    0.31 |  3.9063 |       - |  79.97 KB |        1.02 |
| NativeSingle      | 10000 | Mult      |   7.528 μs | 0.0948 μs | 0.0564 μs |  1.00 |    0.01 |  4.7607 |  0.9155 |  78.18 KB |        1.00 |
| NativeParallel    | 10000 | Mult      |  93.299 μs | 0.7061 μs | 0.4670 μs | 12.39 |    0.11 |  4.3945 |  0.4883 |  78.45 KB |        1.00 |
