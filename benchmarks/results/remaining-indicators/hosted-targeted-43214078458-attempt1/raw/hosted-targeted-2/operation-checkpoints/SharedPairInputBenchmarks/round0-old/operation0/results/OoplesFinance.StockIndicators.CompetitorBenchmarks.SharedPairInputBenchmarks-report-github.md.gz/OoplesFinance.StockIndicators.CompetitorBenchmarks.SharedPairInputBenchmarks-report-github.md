```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Mult**      |   **9.435 μs** | **0.4658 μs** | **0.3081 μs** |  **3.4180** |  **0.4883** |  **56.83 KB** |
| BuilderLatestOnly | 1000  | Mult      |   6.789 μs | 0.3191 μs | 0.1899 μs |  0.5493 |       - |   9.22 KB |
| **BuilderFull**       | **10000** | **Mult**      | **141.601 μs** | **8.9867 μs** | **5.3479 μs** | **33.2031** | **13.6719** | **549.83 KB** |
| BuilderLatestOnly | 10000 | Mult      | 124.869 μs | 3.6297 μs | 2.1600 μs |  3.9063 |       - |  79.98 KB |
