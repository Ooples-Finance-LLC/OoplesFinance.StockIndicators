```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean       | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Div** |  **75.689 μs** | **10.2377 μs** |  **6.0923 μs** |  **1.01** |    **0.10** |  **98.26 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Div |   6.833 μs |  0.5247 μs |  0.3122 μs |  0.09 |    0.01 |  34.41 KB |        0.35 |
|            |       |                     |            |            |            |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Div** | **160.000 μs** | **26.6644 μs** | **15.8676 μs** |  **1.01** |    **0.13** |  **957.5 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Div |  59.388 μs |  0.5730 μs |  0.2997 μs |  0.37 |    0.03 | 326.42 KB |        0.34 |
