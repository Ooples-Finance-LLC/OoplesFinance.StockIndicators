```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------- |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Div**       |  **4.967 μs** | **0.9147 μs** | **0.5443 μs** |  **3.4180** |  **0.4883** |  **56.82 KB** |
| BuilderLatestOnly | 1000  | Div       |  2.351 μs | 0.1798 μs | 0.1070 μs |  0.5493 |       - |   9.21 KB |
| **BuilderFull**       | **10000** | **Div**       | **91.529 μs** | **3.5036 μs** | **2.3174 μs** | **33.2031** | **13.6719** | **549.82 KB** |
| BuilderLatestOnly | 10000 | Div       | 74.323 μs | 2.8302 μs | 1.8720 μs |  4.3945 |  0.4883 |  79.97 KB |
