```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Div**       |   **4.320 μs** | **0.6547 μs** | **0.4330 μs** |  **4.05** |    **0.39** |  **3.4180** |  **0.4883** |  **56.86 KB** |        **7.23** |
| BuilderLatestOnly | 1000  | Div       |   2.184 μs | 0.0804 μs | 0.0479 μs |  2.05 |    0.05 |  0.5493 |  0.0153 |   9.21 KB |        1.17 |
| NativeSingle      | 1000  | Div       |   1.067 μs | 0.0236 μs | 0.0140 μs |  1.00 |    0.02 |  0.4807 |  0.0076 |   7.87 KB |        1.00 |
| NativeParallel    | 1000  | Div       |  65.550 μs | 0.6785 μs | 0.4488 μs | 61.43 |    0.87 |  0.4883 |       - |   8.14 KB |        1.03 |
|                   |       |           |            |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **10000** | **Div**       |  **86.851 μs** | **2.9870 μs** | **1.7775 μs** |  **8.58** |    **0.21** | **33.2031** | **13.6719** | **549.78 KB** |        **7.03** |
| BuilderLatestOnly | 10000 | Div       | 104.484 μs | 2.0211 μs | 1.3368 μs | 10.32 |    0.20 |  4.3945 |  0.4883 |  79.97 KB |        1.02 |
| NativeSingle      | 10000 | Div       |  10.130 μs | 0.3024 μs | 0.1581 μs |  1.00 |    0.02 |  4.7607 |  0.9155 |  78.18 KB |        1.00 |
| NativeParallel    | 10000 | Div       |  98.431 μs | 1.4906 μs | 0.9859 μs |  9.72 |    0.17 |  3.9063 |       - |  78.45 KB |        1.00 |
