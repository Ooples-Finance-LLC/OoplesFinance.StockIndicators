```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-------------:|------------:|------------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Add**       |   **6,262.3 ns** |   **120.73 ns** |    **63.14 ns** |  **6.94** |    **0.12** |  **3.4180** |  **0.4883** |  **56.82 KB** |        **7.22** |
| BuilderLatestOnly | 1000  | Add       |   3,813.2 ns |    83.23 ns |    49.53 ns |  4.23 |    0.08 |  0.5493 |       - |   9.21 KB |        1.17 |
| NativeSingle      | 1000  | Add       |     902.2 ns |    22.80 ns |    13.57 ns |  1.00 |    0.02 |  0.4807 |  0.0076 |   7.87 KB |        1.00 |
| NativeParallel    | 1000  | Add       |  85,706.2 ns | 1,035.41 ns |   684.86 ns | 95.02 |    1.52 |  0.4883 |       - |   8.14 KB |        1.03 |
|                   |       |           |              |             |             |       |         |         |         |           |             |
| **BuilderFull**       | **10000** | **Add**       | **121,486.1 ns** | **4,602.10 ns** | **3,044.00 ns** | **16.28** |    **0.41** | **33.2031** | **13.6719** | **549.82 KB** |        **7.03** |
| BuilderLatestOnly | 10000 | Add       | 101,497.4 ns | 1,497.59 ns |   783.27 ns | 13.61 |    0.15 |  3.9063 |       - |  79.97 KB |        1.02 |
| NativeSingle      | 10000 | Add       |   7,460.7 ns |   115.37 ns |    68.65 ns |  1.00 |    0.01 |  4.7607 |  0.9155 |  78.18 KB |        1.00 |
| NativeParallel    | 10000 | Add       |  89,824.3 ns | 1,151.81 ns |   761.85 ns | 12.04 |    0.14 |  4.3945 |  0.4883 |  78.45 KB |        1.00 |
