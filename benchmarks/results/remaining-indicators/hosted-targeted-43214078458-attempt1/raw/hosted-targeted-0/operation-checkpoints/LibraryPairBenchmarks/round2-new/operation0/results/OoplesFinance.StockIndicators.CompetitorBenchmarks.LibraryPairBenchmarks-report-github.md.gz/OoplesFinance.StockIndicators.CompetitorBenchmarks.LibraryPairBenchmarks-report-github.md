```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Add** |  **92.73 μs** | **19.982 μs** | **11.891 μs** |  **1.01** |    **0.16** |  **98.26 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Add |  14.65 μs |  1.963 μs |  1.298 μs |  0.16 |    0.02 |  40.65 KB |        0.41 |
|            |       |                     |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Add** | **251.64 μs** | **12.320 μs** |  **7.332 μs** |  **1.00** |    **0.04** | **959.47 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Add | 118.35 μs |  6.232 μs |  4.122 μs |  0.47 |    0.02 | 330.97 KB |        0.34 |
