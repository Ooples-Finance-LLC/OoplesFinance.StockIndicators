```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId              | Mean     | Error    | StdDev  | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |-------------------- |---------:|---------:|--------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Add** | **110.0 μs** |  **2.11 μs** | **1.10 μs** |  **1.00** |    **0.01** |  **98.26 KB** |        **1.00** |
|        |       |                     |          |          |         |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Add** | **265.2 μs** | **12.92 μs** | **7.69 μs** |  **1.00** |    **0.04** | **959.47 KB** |        **1.00** |
