```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean      | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Sub** | **249.32 μs** | **3.248 μs** | **1.933 μs** |  **1.00** |    **0.01** |  **98.26 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Sub |  14.40 μs | 2.058 μs | 1.225 μs |  0.06 |    0.00 |  40.32 KB |        0.41 |
|            |       |                     |           |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Sub** | **255.89 μs** | **5.896 μs** | **3.509 μs** |  **1.00** |    **0.02** | **959.47 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Sub | 120.89 μs | 3.666 μs | 2.181 μs |  0.47 |    0.01 | 330.31 KB |        0.34 |
