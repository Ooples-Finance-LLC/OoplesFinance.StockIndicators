```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId              | Mean     | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |-------------------- |---------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Sub** | **118.0 μs** |  **6.09 μs** |  **3.62 μs** |  **1.00** |    **0.04** |  **98.27 KB** |        **1.00** |
|        |       |                     |          |          |          |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Sub** | **282.9 μs** | **19.33 μs** | **11.50 μs** |  **1.00** |    **0.05** | **959.48 KB** |        **1.00** |
