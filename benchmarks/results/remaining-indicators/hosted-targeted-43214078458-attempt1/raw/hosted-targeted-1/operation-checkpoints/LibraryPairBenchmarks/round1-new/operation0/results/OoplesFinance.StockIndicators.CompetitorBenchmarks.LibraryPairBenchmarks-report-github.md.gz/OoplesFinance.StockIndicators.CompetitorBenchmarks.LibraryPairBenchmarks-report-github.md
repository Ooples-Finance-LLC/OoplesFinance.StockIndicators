```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId              | Mean     | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |-------------------- |---------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Sub** | **258.7 μs** | **28.01 μs** | **16.67 μs** |  **1.00** |    **0.08** |  **98.26 KB** |        **1.00** |
|        |       |                     |          |          |          |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Sub** | **261.6 μs** | **19.37 μs** | **11.53 μs** |  **1.00** |    **0.06** | **959.47 KB** |        **1.00** |
