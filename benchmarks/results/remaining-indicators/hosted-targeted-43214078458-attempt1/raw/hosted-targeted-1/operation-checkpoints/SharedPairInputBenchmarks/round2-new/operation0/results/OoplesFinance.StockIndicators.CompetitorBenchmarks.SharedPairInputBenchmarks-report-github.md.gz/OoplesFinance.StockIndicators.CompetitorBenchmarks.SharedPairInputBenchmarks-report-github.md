```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-------------:|------------:|------------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Sub**       |   **6,280.1 ns** |   **156.99 ns** |    **93.42 ns** |  **6.84** |    **0.11** |  **3.4180** |  **0.4883** |  **56.82 KB** |        **7.22** |
| BuilderLatestOnly | 1000  | Sub       |   4,181.5 ns |   107.79 ns |    71.30 ns |  4.56 |    0.08 |  0.5493 |       - |   9.21 KB |        1.17 |
| NativeSingle      | 1000  | Sub       |     917.5 ns |    13.72 ns |     7.17 ns |  1.00 |    0.01 |  0.4807 |  0.0076 |   7.87 KB |        1.00 |
| NativeParallel    | 1000  | Sub       |  85,981.9 ns | 1,165.87 ns |   771.15 ns | 93.71 |    1.06 |  0.4883 |       - |   8.14 KB |        1.03 |
|                   |       |           |              |             |             |       |         |         |         |           |             |
| **BuilderFull**       | **10000** | **Sub**       | **124,316.6 ns** | **3,834.99 ns** | **2,536.61 ns** | **16.60** |    **0.35** | **33.2031** | **13.6719** | **549.82 KB** |        **7.03** |
| BuilderLatestOnly | 10000 | Sub       | 105,934.4 ns | 2,899.46 ns | 1,917.82 ns | 14.15 |    0.27 |  3.9063 |       - |  79.97 KB |        1.02 |
| NativeSingle      | 10000 | Sub       |   7,488.5 ns |   106.34 ns |    63.28 ns |  1.00 |    0.01 |  4.7607 |  0.9155 |  78.18 KB |        1.00 |
| NativeParallel    | 10000 | Sub       |  91,956.8 ns |   872.29 ns |   576.96 ns | 12.28 |    0.12 |  4.3945 |  0.4883 |  78.45 KB |        1.00 |
