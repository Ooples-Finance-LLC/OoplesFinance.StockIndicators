```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon 6973P-C 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **225.0 μs** | **10.97 μs** |  **5.74 μs** |  **73.47 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   209.6 μs |  2.85 μs |  1.70 μs |  25.92 KB |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **2,221.1 μs** | **26.18 μs** | **15.58 μs** | **706.74 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 2,212.8 μs | 89.52 μs | 59.21 μs | 236.97 KB |
