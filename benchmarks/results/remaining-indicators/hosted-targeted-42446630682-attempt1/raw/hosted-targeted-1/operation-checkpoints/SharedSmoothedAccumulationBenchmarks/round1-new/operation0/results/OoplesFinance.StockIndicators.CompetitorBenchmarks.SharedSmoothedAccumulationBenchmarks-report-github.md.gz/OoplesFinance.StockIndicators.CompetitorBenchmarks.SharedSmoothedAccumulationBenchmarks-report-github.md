```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon 6973P-C 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **220.4 μs** |  **3.80 μs** |  **2.26 μs** |  **73.53 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   211.4 μs |  6.10 μs |  4.03 μs |  25.92 KB |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **2,299.2 μs** | **59.60 μs** | **39.43 μs** | **706.75 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 2,178.3 μs | 43.32 μs | 22.66 μs | 236.97 KB |
