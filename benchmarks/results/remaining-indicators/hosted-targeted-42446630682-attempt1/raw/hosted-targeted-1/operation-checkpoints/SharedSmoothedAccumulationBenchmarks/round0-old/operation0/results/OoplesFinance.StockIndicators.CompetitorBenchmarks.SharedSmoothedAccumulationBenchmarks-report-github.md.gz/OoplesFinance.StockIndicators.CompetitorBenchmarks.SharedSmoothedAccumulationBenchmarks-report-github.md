```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon 6973P-C 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **220.7 μs** |   **1.78 μs** |   **1.06 μs** |  **73.56 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   223.1 μs |   7.69 μs |   5.08 μs |  25.91 KB |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **2,291.9 μs** |  **38.76 μs** |  **20.27 μs** | **706.78 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 2,293.8 μs | 164.97 μs | 109.12 μs | 236.85 KB |
