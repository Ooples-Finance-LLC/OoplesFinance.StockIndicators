```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon 6973P-C 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **211.610 μs** |  **1.7228 μs** |  **1.0252 μs** | **64.40** |    **0.94** |      **-** |  **73.51 KB** |        **9.42** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   211.791 μs |  2.6948 μs |  1.7825 μs | 64.45 |    1.03 |      - |  25.92 KB |        3.32 |
| NativeSingle      | TaLib(...)AdOsc [21] | 1000  |     3.287 μs |  0.0817 μs |  0.0486 μs |  1.00 |    0.02 | 0.0916 |    7.8 KB |        1.00 |
| NativeParallel    | TaLib(...)AdOsc [21] | 1000  |    75.934 μs |  5.0814 μs |  3.3610 μs | 23.11 |    1.03 |      - |  27.57 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |        |           |             |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **2,204.331 μs** | **26.9885 μs** | **16.0604 μs** | **70.23** |    **0.71** |      **-** | **706.78 KB** |        **9.05** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 2,152.468 μs | 33.0822 μs | 19.6867 μs | 68.58 |    0.78 |      - | 236.97 KB |        3.03 |
| NativeSingle      | TaLib(...)AdOsc [21] | 10000 |    31.387 μs |  0.4724 μs |  0.2471 μs |  1.00 |    0.01 | 0.7324 |  78.12 KB |        1.00 |
| NativeParallel    | TaLib(...)AdOsc [21] | 10000 |   116.974 μs |  6.5475 μs |  3.4245 μs |  3.73 |    0.11 | 2.9297 | 273.66 KB |        3.50 |
