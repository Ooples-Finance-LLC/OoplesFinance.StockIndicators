```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon 6973P-C 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)AdOsc [21]** |   **364.23 μs** | **21.799 μs** | **12.972 μs** |  **1.00** |    **0.05** |  **209.08 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)AdOsc [21] |    11.29 μs |  0.314 μs |  0.164 μs |  0.03 |    0.00 |   35.57 KB |        0.17 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)AdOsc [21]** | **3,113.17 μs** | **96.611 μs** | **57.492 μs** |  **1.00** |    **0.02** | **2050.54 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)AdOsc [21] |    65.23 μs |  3.799 μs |  2.261 μs |  0.02 |    0.00 |  329.92 KB |        0.16 |
