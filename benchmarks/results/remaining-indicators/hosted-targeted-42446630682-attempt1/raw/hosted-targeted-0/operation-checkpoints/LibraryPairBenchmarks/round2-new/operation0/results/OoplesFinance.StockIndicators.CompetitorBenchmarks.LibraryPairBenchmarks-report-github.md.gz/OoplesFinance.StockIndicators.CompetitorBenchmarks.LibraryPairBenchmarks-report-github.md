```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ad** |  **98.24 μs** |  **8.800 μs** | **5.237 μs** |  **1.00** |    **0.07** |  **140.75 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ad |  24.90 μs |  0.385 μs | 0.229 μs |  0.25 |    0.01 |   14.66 KB |        0.10 |
|            |       |                    |           |           |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ad** | **961.26 μs** | **14.576 μs** | **8.674 μs** |  **1.00** |    **0.01** | **1707.15 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ad |  17.74 μs |  8.557 μs | 5.660 μs |  0.02 |    0.01 |   78.79 KB |        0.05 |
