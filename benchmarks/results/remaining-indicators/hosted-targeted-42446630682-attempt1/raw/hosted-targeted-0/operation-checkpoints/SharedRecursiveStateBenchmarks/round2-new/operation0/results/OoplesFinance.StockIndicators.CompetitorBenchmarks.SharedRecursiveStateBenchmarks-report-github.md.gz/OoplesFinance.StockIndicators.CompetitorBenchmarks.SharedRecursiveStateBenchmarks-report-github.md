```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |---------- |------ |-----------:|-----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **Ad**        | **1000**  |  **77.280 μs** |  **4.2094 μs** | **2.2016 μs** | **58.48** |    **2.04** |  **3.9063** |       **-** |  **64.88 KB** |        **8.24** |
| BuilderLatestOnly | Ad        | 1000  |  73.214 μs |  1.0723 μs | 0.5608 μs | 55.41 |    1.30 |  0.9766 |       - |  17.27 KB |        2.19 |
| NativeSingle      | Ad        | 1000  |   1.322 μs |  0.0474 μs | 0.0313 μs |  1.00 |    0.03 |  0.4807 |  0.0076 |   7.88 KB |        1.00 |
| NativeParallel    | Ad        | 1000  |  66.055 μs |  0.7906 μs | 0.4705 μs | 49.99 |    1.17 |  0.4883 |       - |   8.17 KB |        1.04 |
|                   |           |       |            |            |           |       |         |         |         |           |             |
| **BuilderFull**       | **Ad**        | **10000** | **704.303 μs** | **11.2344 μs** | **6.6854 μs** | **62.24** |    **0.66** | **35.1563** | **11.7188** | **627.74 KB** |        **8.03** |
| BuilderLatestOnly | Ad        | 10000 | 677.845 μs |  5.6818 μs | 2.9717 μs | 59.90 |    0.41 |  7.8125 |       - | 157.91 KB |        2.02 |
| NativeSingle      | Ad        | 10000 |  11.317 μs |  0.1000 μs | 0.0661 μs |  1.00 |    0.01 |  4.7607 |  0.9155 |  78.19 KB |        1.00 |
| NativeParallel    | Ad        | 10000 |  77.982 μs |  3.0477 μs | 2.0159 μs |  6.89 |    0.17 |  4.3945 |  0.4883 |  78.48 KB |        1.00 |
