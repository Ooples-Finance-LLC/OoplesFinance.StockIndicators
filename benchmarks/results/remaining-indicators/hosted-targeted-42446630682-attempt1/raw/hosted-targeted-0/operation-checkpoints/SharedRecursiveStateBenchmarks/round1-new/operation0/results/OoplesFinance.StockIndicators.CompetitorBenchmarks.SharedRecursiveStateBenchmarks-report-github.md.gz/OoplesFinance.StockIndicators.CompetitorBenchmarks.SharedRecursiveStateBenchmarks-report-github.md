```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Ad**        | **1000**  |  **73.84 μs** |  **0.669 μs** |  **0.350 μs** |  **3.9063** |       **-** |  **64.88 KB** |
| BuilderLatestOnly | Ad        | 1000  |  70.91 μs |  1.771 μs |  1.171 μs |  0.9766 |       - |  17.27 KB |
| **BuilderFull**       | **Ad**        | **10000** | **758.23 μs** | **28.079 μs** | **18.573 μs** | **35.1563** | **11.7188** | **627.74 KB** |
| BuilderLatestOnly | Ad        | 10000 | 661.11 μs | 25.114 μs | 16.611 μs |  7.8125 |       - | 157.91 KB |
