```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |---------- |------ |----------:|----------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **Ad**        | **1000**  |  **78.39 μs** |  **1.818 μs** | **1.082 μs** |  **3.9063** |      **-** |  **64.88 KB** |
| BuilderLatestOnly | Ad        | 1000  |  82.53 μs |  1.205 μs | 0.630 μs |  0.9766 |      - |  17.27 KB |
| **BuilderFull**       | **Ad**        | **10000** | **777.05 μs** | **16.635 μs** | **9.899 μs** | **31.2500** | **7.8125** | **627.76 KB** |
| BuilderLatestOnly | Ad        | 10000 | 676.21 μs |  3.662 μs | 1.915 μs |  7.8125 |      - | 157.91 KB |
