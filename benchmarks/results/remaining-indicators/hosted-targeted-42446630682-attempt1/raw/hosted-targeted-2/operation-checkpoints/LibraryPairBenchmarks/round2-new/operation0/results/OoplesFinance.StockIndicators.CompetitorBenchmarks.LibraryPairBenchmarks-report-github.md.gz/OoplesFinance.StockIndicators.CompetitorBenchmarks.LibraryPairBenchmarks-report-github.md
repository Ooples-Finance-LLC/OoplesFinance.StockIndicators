```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)inOsc [21]** |   **511.3 μs** |  **23.04 μs** |  **13.71 μs** |  **1.00** |    **0.04** |  **259.67 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)inOsc [21] |   107.7 μs |   4.29 μs |   2.55 μs |  0.21 |    0.01 |  494.53 KB |        1.90 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)inOsc [21]** | **4,734.6 μs** | **232.29 μs** | **153.65 μs** |  **1.00** |    **0.04** | **2552.38 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)inOsc [21] | 1,107.7 μs |  32.82 μs |  17.16 μs |  0.23 |    0.01 | 4854.23 KB |        1.90 |
