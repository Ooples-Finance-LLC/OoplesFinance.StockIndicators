```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **328.3 μs** |   **6.09 μs** |   **3.19 μs** |       **-** |  **96.99 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   334.0 μs |  13.15 μs |   8.70 μs |  1.9531 |  49.42 KB |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **3,583.8 μs** | **170.79 μs** | **112.96 μs** | **31.2500** | **941.34 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 3,895.3 μs | 713.67 μs | 472.05 μs |       - | 471.52 KB |
