```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **330.98 μs** |   **3.631 μs** |  **2.161 μs** |  **3.75** |    **0.05** |        **-** |        **-** |       **-** |   **97.03 KB** |        **0.26** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   331.20 μs |   1.795 μs |  1.068 μs |  3.75 |    0.04 |   1.9531 |        - |       - |   49.42 KB |        0.13 |
| NativeSingle      | Skend(...)inOsc [21] | 1000  |    88.34 μs |   1.776 μs |  1.057 μs |  1.00 |    0.02 |  22.9492 |   6.8359 |       - |  379.71 KB |        1.00 |
| NativeParallel    | Skend(...)inOsc [21] | 1000  |   214.28 μs |  14.991 μs |  9.916 μs |  2.43 |    0.11 |  58.5938 |  19.5313 |       - |  958.69 KB |        2.52 |
|                   |                      |       |             |            |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **3,336.25 μs** |  **17.414 μs** | **10.363 μs** |  **2.71** |    **0.03** |  **31.2500** |        **-** |       **-** |  **941.35 KB** |        **0.25** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 3,320.81 μs |  51.788 μs | 30.818 μs |  2.70 |    0.04 |        - |        - |       - |  471.54 KB |        0.12 |
| NativeSingle      | Skend(...)inOsc [21] | 10000 | 1,231.84 μs |  23.288 μs | 15.403 μs |  1.00 |    0.02 | 242.1875 | 148.4375 | 46.8750 | 3790.28 KB |        1.00 |
| NativeParallel    | Skend(...)inOsc [21] | 10000 | 2,654.64 μs | 105.269 μs | 62.644 μs |  2.16 |    0.05 | 593.7500 | 515.6250 | 78.1250 | 9555.11 KB |        2.52 |
