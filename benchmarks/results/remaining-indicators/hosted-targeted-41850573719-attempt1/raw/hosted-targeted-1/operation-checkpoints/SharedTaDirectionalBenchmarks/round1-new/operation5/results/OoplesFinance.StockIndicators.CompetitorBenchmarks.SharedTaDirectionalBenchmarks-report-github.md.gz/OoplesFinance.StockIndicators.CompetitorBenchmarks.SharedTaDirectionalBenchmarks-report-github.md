```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |-------------------- |------ |-----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **277.9 μs** |   **5.19 μs** |  **2.71 μs** |  **3.9063** |       **-** |  **65.23 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   262.5 μs |   3.56 μs |  2.12 μs |       - |       - |  17.63 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **2,956.0 μs** | **158.40 μs** | **94.26 μs** | **31.2500** | **15.6250** |  **630.7 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 2,978.2 μs |  99.78 μs | 59.38 μs |       - |       - | 160.97 KB |
