```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **135.004 μs** |  **4.9620 μs** |  **3.2821 μs** | **27.59** |    **0.83** |  **3.9063** |      **-** |  **65.01 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   133.497 μs |  1.5112 μs |  0.7904 μs | 27.28 |    0.54 |  0.9766 |      - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDI [23] | 1000  |     4.895 μs |  0.1470 μs |  0.0972 μs |  1.00 |    0.03 |  0.4578 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 1000  |     7.127 μs |  0.1729 μs |  0.1029 μs |  1.46 |    0.03 |  1.8311 | 0.0610 |  27.24 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **1,278.564 μs** | **54.1457 μs** | **32.2213 μs** | **25.87** |    **0.87** | **31.2500** | **7.8125** | **627.89 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 1,324.225 μs | 26.1849 μs | 17.3197 μs | 26.80 |    0.71 |  7.8125 |      - | 158.05 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDI [23] | 10000 |    49.448 μs |  2.1082 μs |  1.2546 μs |  1.00 |    0.03 |  4.3945 |      - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 10000 |    77.417 μs |  2.9308 μs |  1.9385 μs |  1.57 |    0.05 | 18.0664 | 4.3945 | 273.34 KB |        3.50 |
