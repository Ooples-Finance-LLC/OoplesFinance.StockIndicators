```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |-------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **300.4 μs** |  **12.05 μs** |  **7.17 μs** |       **-** |  **65.22 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   294.6 μs |  12.40 μs |  8.20 μs |       - |  17.61 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **3,219.8 μs** |  **82.48 μs** | **54.55 μs** | **31.2500** |  **630.8 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 3,194.8 μs | 145.03 μs | 75.86 μs |       - | 160.93 KB |
