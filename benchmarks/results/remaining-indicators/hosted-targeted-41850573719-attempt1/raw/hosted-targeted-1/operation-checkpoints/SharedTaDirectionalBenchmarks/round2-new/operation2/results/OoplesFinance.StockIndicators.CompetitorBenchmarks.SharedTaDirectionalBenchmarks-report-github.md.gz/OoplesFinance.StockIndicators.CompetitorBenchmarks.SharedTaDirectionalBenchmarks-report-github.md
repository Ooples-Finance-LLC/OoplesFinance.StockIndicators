```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **138.225 μs** |  **2.0359 μs** |  **1.2115 μs** | **27.89** |    **0.25** |       **-** |      **-** |  **65.05 KB** |        **8.43** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   129.629 μs |  1.6284 μs |  0.8517 μs | 26.16 |    0.18 |  0.9766 |      - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib(...)lusDI [22] | 1000  |     4.956 μs |  0.0313 μs |  0.0164 μs |  1.00 |    0.00 |  0.4578 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 1000  |     7.309 μs |  0.3042 μs |  0.2012 μs |  1.47 |    0.04 |  1.8921 | 0.0610 |  27.24 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **1,265.057 μs** | **54.5247 μs** | **32.4468 μs** | **25.54** |    **0.63** | **31.2500** | **7.8125** | **627.89 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 1,274.856 μs | 11.5360 μs |  6.8649 μs | 25.74 |    0.18 |  7.8125 |      - | 158.06 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDI [22] | 10000 |    49.537 μs |  0.4243 μs |  0.2525 μs |  1.00 |    0.01 |  4.3945 |      - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 10000 |    79.519 μs |  1.3747 μs |  0.8181 μs |  1.61 |    0.02 | 18.0664 | 4.3945 | 273.34 KB |        3.50 |
