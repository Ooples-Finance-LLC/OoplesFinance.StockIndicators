```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  | **106.56 μs** |  **6.760 μs** |  **4.471 μs** |  **3.9063** |      **-** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |  92.87 μs |  2.719 μs |  1.799 μs |  0.9766 |      - |  17.39 KB |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **908.96 μs** | **21.869 μs** | **14.465 μs** | **31.2500** | **7.8125** | **627.91 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 889.43 μs | 16.383 μs |  9.749 μs |  7.8125 |      - | 158.03 KB |
