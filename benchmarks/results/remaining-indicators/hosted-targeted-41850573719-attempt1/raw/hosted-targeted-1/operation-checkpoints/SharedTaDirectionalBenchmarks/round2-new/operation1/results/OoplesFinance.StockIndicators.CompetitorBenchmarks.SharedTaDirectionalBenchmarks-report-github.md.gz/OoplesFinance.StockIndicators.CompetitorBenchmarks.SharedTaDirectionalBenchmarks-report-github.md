```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|-----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |  **73.510 μs** |  **3.0012 μs** | **1.7859 μs** |  **9.06** |    **0.22** |  **3.9063** |       **-** |  **65.01 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |  69.047 μs |  1.2267 μs | 0.7300 μs |  8.51 |    0.11 |  0.9766 |       - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDM [23] | 1000  |   8.111 μs |  0.1178 μs | 0.0701 μs |  1.00 |    0.01 |  0.4272 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 1000  |  10.160 μs |  0.3310 μs | 0.1970 μs |  1.25 |    0.03 |  1.7700 |  0.0610 |  27.23 KB |        3.53 |
|                   |                      |       |            |            |           |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **681.830 μs** |  **9.9397 μs** | **5.9150 μs** |  **8.33** |    **0.10** | **35.1563** | **11.7188** | **627.86 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 666.616 μs | 12.0376 μs | 7.9621 μs |  8.15 |    0.11 |  7.8125 |       - | 158.05 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDM [23] | 10000 |  81.828 μs |  1.1538 μs | 0.6866 μs |  1.00 |    0.01 |  4.3945 |       - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 10000 | 127.743 μs |  7.7861 μs | 4.6334 μs |  1.56 |    0.06 | 17.5781 |  3.9063 | 273.33 KB |        3.50 |
