```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **306.5 μs** |  **4.03 μs** |  **2.40 μs** |       **-** |  **65.22 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   295.8 μs | 10.06 μs |  5.99 μs |       - |  17.61 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **3,300.8 μs** | **27.69 μs** | **14.48 μs** | **31.2500** | **630.81 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 3,218.0 μs | 25.34 μs | 15.08 μs |       - | 160.96 KB |
