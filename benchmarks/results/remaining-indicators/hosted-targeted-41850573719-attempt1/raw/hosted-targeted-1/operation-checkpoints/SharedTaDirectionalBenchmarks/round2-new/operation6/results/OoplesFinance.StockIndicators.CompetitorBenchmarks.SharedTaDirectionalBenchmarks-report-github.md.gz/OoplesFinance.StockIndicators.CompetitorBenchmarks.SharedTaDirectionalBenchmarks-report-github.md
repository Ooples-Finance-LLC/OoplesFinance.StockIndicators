```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **301.18 μs** |  **9.705 μs** |  **5.076 μs** | **27.65** |    **0.54** |       **-** |      **-** |   **66.3 KB** |        **4.42** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   291.57 μs |  7.316 μs |  4.839 μs | 26.76 |    0.52 |       - |      - |   18.7 KB |        1.25 |
| NativeSingle      | TaLib.Functions.Adxr | 1000  |    10.90 μs |  0.193 μs |  0.127 μs |  1.00 |    0.02 |  0.9155 |      - |  14.99 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 1000  |    17.54 μs |  0.685 μs |  0.358 μs |  1.61 |    0.04 |  3.0518 | 0.1221 |  45.43 KB |        3.03 |
|                   |                      |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **3,436.14 μs** | **57.061 μs** | **33.956 μs** | **31.82** |    **0.66** | **31.2500** |      **-** | **631.88 KB** |        **4.06** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 3,133.47 μs | 59.743 μs | 35.552 μs | 29.02 |    0.62 |       - |      - |    162 KB |        1.04 |
| NativeSingle      | TaLib.Functions.Adxr | 10000 |   108.01 μs |  3.560 μs |  2.119 μs |  1.00 |    0.03 |  8.7891 | 0.9766 | 155.62 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 10000 |   164.13 μs | 16.304 μs | 10.784 μs |  1.52 |    0.10 | 30.2734 | 8.7891 | 467.31 KB |        3.00 |
