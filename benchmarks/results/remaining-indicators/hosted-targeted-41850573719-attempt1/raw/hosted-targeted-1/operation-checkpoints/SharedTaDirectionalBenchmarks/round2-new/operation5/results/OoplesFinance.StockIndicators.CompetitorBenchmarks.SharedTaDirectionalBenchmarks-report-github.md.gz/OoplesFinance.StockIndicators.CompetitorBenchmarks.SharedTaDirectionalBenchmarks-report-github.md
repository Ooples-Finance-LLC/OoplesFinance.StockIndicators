```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **265.421 μs** |  **4.5089 μs** |  **2.3582 μs** | **28.98** |    **0.60** |       **-** |       **-** |  **65.23 KB** |        **8.62** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   268.508 μs |  5.8845 μs |  3.8922 μs | 29.32 |    0.69 |       - |       - |  17.63 KB |        2.33 |
| NativeSingle      | TaLib.Functions.Adx | 1000  |     9.161 μs |  0.2776 μs |  0.1836 μs |  1.00 |    0.03 |  0.4272 |       - |   7.57 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 1000  |    14.921 μs |  1.2675 μs |  0.8384 μs |  1.63 |    0.09 |  1.7090 |       - |  26.71 KB |        3.53 |
|                   |                     |       |              |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **2,819.522 μs** | **71.2230 μs** | **47.1096 μs** | **29.69** |    **0.62** | **31.2500** | **15.6250** | **630.74 KB** |        **8.10** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 2,848.903 μs | 76.9988 μs | 50.9299 μs | 30.00 |    0.66 |       - |       - | 160.92 KB |        2.07 |
| NativeSingle      | TaLib.Functions.Adx | 10000 |    94.984 μs |  2.2997 μs |  1.3685 μs |  1.00 |    0.02 |  4.3945 |       - |  77.88 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 10000 |   141.384 μs |  4.9497 μs |  2.9455 μs |  1.49 |    0.04 | 17.5781 |  4.8828 | 272.81 KB |        3.50 |
