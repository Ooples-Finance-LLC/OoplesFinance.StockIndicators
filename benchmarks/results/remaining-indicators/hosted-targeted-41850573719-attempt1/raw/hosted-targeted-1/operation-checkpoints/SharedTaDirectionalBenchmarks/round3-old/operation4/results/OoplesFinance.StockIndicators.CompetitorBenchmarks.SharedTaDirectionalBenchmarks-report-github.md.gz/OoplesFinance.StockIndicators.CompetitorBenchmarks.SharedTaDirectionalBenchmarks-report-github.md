```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **375.7 μs** |  **12.78 μs** |  **6.68 μs** |       **-** |     **65 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   368.8 μs |   8.10 μs |  4.82 μs |       - |  17.39 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **3,739.0 μs** | **118.90 μs** | **78.65 μs** | **31.2500** | **627.99 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 3,811.4 μs |  39.00 μs | 20.40 μs |       - | 158.15 KB |
