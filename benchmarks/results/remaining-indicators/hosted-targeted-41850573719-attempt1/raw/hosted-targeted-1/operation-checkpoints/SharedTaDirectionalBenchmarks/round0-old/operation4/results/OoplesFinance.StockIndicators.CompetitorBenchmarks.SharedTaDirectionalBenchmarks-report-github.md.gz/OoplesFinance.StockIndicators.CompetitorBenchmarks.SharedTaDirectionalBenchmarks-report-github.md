```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **367.4 μs** |   **5.79 μs** |   **3.44 μs** |       **-** |     **65 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   361.4 μs |  12.44 μs |   7.41 μs |       - |  17.39 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **3,812.0 μs** |  **23.05 μs** |  **13.72 μs** | **31.2500** | **628.01 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 3,865.5 μs | 260.65 μs | 136.32 μs |       - | 158.13 KB |
