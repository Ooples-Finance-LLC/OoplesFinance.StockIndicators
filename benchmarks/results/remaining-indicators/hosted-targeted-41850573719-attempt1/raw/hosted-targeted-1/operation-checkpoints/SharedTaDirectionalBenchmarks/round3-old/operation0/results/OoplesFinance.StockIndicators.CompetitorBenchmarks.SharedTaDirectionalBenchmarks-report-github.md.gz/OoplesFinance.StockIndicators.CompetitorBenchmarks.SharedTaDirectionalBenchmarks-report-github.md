```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |  **93.83 μs** | **13.096 μs** |  **6.849 μs** |  **3.9063** |      **-** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |  90.83 μs |  1.189 μs |  0.622 μs |  0.9766 |      - |  17.39 KB |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **922.11 μs** | **28.291 μs** | **16.836 μs** | **31.2500** | **7.8125** | **627.88 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 906.57 μs | 20.509 μs | 12.204 μs |  7.8125 |      - | 158.05 KB |
