```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|-----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |  **71.839 μs** |  **2.8202 μs** | **1.6783 μs** |  **8.58** |    **0.20** |  **3.9063** |       **-** |  **65.01 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |  67.947 μs |  1.4033 μs | 0.8351 μs |  8.12 |    0.12 |  0.9766 |       - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib(...)lusDM [22] | 1000  |   8.373 μs |  0.1189 μs | 0.0787 μs |  1.00 |    0.01 |  0.4272 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 1000  |  10.438 μs |  0.7155 μs | 0.3742 μs |  1.25 |    0.04 |  1.8311 |  0.0610 |  27.23 KB |        3.53 |
|                   |                      |       |            |            |           |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **689.889 μs** |  **7.7776 μs** | **4.6283 μs** |  **8.38** |    **0.06** | **35.1563** | **11.7188** | **627.87 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 669.737 μs | 12.2727 μs | 7.3033 μs |  8.13 |    0.09 |  7.8125 |       - | 158.05 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDM [22] | 10000 |  82.363 μs |  0.5194 μs | 0.2717 μs |  1.00 |    0.00 |  4.3945 |       - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 10000 | 120.680 μs |  2.8067 μs | 1.8565 μs |  1.47 |    0.02 | 17.5781 |  3.9063 | 273.33 KB |        3.50 |
