```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **165.8 μs** |  **2.14 μs** |  **1.28 μs** |  **3.9063** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   161.4 μs |  3.65 μs |  2.17 μs |  0.9766 |  17.38 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **1,642.3 μs** | **36.33 μs** | **21.62 μs** | **31.2500** | **627.91 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 1,622.9 μs | 12.10 μs |  7.20 μs |       - | 158.07 KB |
