```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |------------:|-----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **299.30 μs** |   **5.320 μs** |  **3.166 μs** | **28.23** |    **0.65** |       **-** |      **-** |  **65.01 KB** |        **8.42** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   305.43 μs |  15.944 μs |  9.488 μs | 28.81 |    1.04 |       - |      - |  17.41 KB |        2.26 |
| NativeSingle      | TaLib.Functions.Dx | 1000  |    10.61 μs |   0.356 μs |  0.236 μs |  1.00 |    0.03 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 1000  |    16.32 μs |   1.758 μs |  1.163 μs |  1.54 |    0.11 |  1.8311 |      - |  27.24 KB |        3.53 |
|                   |                    |       |             |            |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **3,197.92 μs** |  **24.217 μs** | **12.666 μs** | **29.33** |    **0.37** | **31.2500** |      **-** | **627.98 KB** |        **8.05** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 3,126.33 μs | 144.796 μs | 86.166 μs | 28.67 |    0.83 |       - |      - | 158.09 KB |        2.03 |
| NativeSingle      | TaLib.Functions.Dx | 10000 |   109.05 μs |   2.115 μs |  1.399 μs |  1.00 |    0.02 |  3.9063 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 10000 |   151.96 μs |   6.513 μs |  4.308 μs |  1.39 |    0.04 | 17.5781 | 3.9063 | 273.34 KB |        3.50 |
