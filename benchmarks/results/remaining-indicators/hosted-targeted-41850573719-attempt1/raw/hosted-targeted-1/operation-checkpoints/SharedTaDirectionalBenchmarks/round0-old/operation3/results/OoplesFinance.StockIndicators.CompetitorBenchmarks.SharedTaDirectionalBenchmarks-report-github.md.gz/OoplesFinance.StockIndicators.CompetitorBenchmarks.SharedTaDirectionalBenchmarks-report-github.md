```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **166.0 μs** |   **1.34 μs** |  **0.80 μs** |  **3.9063** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   169.5 μs |   7.29 μs |  3.81 μs |  0.9766 |  17.38 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **1,610.8 μs** |  **11.50 μs** |  **6.01 μs** | **31.2500** | **627.88 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 1,625.7 μs | 114.53 μs | 68.15 μs |       - | 158.07 KB |
