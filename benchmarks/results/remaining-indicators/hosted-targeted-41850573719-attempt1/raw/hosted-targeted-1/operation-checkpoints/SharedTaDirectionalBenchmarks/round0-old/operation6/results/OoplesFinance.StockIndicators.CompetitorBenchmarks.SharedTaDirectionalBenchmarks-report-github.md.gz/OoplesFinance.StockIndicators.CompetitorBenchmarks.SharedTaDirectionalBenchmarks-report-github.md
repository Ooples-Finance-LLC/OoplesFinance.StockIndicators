```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **326.1 μs** |   **4.77 μs** |  **2.49 μs** |       **-** |  **66.25 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   333.3 μs |   8.08 μs |  5.34 μs |       - |  18.68 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **3,501.1 μs** | **110.32 μs** | **65.65 μs** | **31.2500** | **631.83 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 3,387.2 μs |  90.71 μs | 53.98 μs |       - | 162.02 KB |
