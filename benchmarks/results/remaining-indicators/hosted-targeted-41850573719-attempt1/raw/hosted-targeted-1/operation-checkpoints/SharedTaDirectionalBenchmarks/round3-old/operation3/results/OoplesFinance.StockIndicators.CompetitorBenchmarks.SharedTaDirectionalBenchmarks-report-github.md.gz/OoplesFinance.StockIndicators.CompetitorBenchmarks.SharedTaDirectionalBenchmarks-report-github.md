```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **168.0 μs** |  **5.68 μs** |  **2.97 μs** |       **-** |  **64.96 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   163.9 μs |  2.29 μs |  1.51 μs |  0.9766 |  17.39 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **1,642.3 μs** | **38.22 μs** | **19.99 μs** | **31.2500** | **627.87 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 1,676.2 μs | 57.42 μs | 37.98 μs |       - | 158.08 KB |
