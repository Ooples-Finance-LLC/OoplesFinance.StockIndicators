```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **415.5 μs** | **140.03 μs** | **92.62 μs** |       **-** |  **66.25 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   346.5 μs |  46.84 μs | 30.98 μs |       - |  18.68 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **3,629.8 μs** | **136.18 μs** | **81.04 μs** | **31.2500** | **631.85 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 3,558.8 μs | 102.05 μs | 67.50 μs |       - | 162.06 KB |
