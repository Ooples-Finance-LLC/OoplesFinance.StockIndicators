```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId              | Mean       | Error    | StdDev   | Ratio | Allocated  | Alloc Ratio |
|------- |------ |-------------------- |-----------:|---------:|---------:|------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Adx** |   **628.7 μs** |  **4.52 μs** |  **2.36 μs** |  **1.00** |  **105.89 KB** |        **1.00** |
|        |       |                     |            |          |          |       |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Adx** | **6,102.5 μs** | **84.87 μs** | **50.51 μs** |  **1.00** | **1037.58 KB** |        **1.00** |
