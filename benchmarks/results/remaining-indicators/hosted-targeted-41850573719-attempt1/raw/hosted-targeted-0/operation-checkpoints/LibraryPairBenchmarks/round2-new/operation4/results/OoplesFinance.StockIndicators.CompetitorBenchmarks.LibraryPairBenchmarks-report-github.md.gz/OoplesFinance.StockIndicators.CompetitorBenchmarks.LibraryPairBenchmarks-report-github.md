```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Dx** |   **642.94 μs** | **46.031 μs** | **30.447 μs** |  **1.00** |    **0.06** |  **105.69 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Dx |    23.80 μs |  1.081 μs |  0.715 μs |  0.04 |    0.00 |   38.91 KB |        0.37 |
|            |       |                    |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Dx** | **5,933.75 μs** | **54.049 μs** | **28.269 μs** |  **1.00** |    **0.01** | **1034.07 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Dx |   219.32 μs | 11.502 μs |  6.845 μs |  0.04 |    0.00 |  329.61 KB |        0.32 |
