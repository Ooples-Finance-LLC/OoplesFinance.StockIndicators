```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adx** |   **575.93 μs** | **16.323 μs** |  **9.714 μs** |  **1.00** |    **0.02** |  **105.91 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adx |    25.64 μs |  4.871 μs |  3.222 μs |  0.04 |    0.01 |   38.59 KB |        0.36 |
|            |       |                     |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adx** | **5,484.18 μs** | **36.070 μs** | **21.465 μs** |  **1.00** |    **0.01** | **1036.56 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adx |   235.48 μs | 32.994 μs | 19.634 μs |  0.04 |    0.00 |  330.64 KB |        0.32 |
