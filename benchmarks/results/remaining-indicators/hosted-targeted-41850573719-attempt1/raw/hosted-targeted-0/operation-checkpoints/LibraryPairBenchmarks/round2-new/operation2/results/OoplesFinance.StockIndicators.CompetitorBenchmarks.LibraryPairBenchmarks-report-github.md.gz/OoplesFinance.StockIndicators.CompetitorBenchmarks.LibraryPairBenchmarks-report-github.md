```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDI [22]** |   **305.42 μs** | **35.558 μs** | **23.519 μs** |  **1.01** |    **0.10** |  **105.69 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDI [22] |    19.89 μs |  1.541 μs |  0.917 μs |  0.07 |    0.01 |   40.27 KB |        0.38 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDI [22]** | **2,659.07 μs** | **36.060 μs** | **21.459 μs** |  **1.00** |    **0.01** | **1035.05 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDI [22] |   180.79 μs |  4.849 μs |  2.536 μs |  0.07 |    0.00 |  329.28 KB |        0.32 |
