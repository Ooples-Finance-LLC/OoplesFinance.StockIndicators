```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adxr** |   **630.96 μs** | **23.157 μs** | **13.780 μs** |  **1.00** |    **0.03** |  **106.98 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adxr |    25.84 μs |  1.397 μs |  0.731 μs |  0.04 |    0.00 |   46.16 KB |        0.43 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adxr** | **5,971.83 μs** | **63.234 μs** | **37.630 μs** |  **1.00** |    **0.01** | **1039.27 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adxr |   248.90 μs | 22.707 μs | 13.513 μs |  0.04 |    0.00 |  406.51 KB |        0.39 |
