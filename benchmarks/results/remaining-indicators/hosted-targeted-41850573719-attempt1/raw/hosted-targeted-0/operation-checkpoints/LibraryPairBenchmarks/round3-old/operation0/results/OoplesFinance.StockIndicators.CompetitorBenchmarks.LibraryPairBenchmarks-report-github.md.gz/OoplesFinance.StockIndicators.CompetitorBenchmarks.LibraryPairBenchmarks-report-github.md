```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean       | Error    | StdDev  | Ratio | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |-----------:|---------:|--------:|------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)lusDM [22]** |   **211.6 μs** |  **2.03 μs** | **1.06 μs** |  **1.00** |  **105.67 KB** |        **1.00** |
|        |       |                      |            |          |         |       |            |             |
| **Ooples** | **10000** | **TaLib(...)lusDM [22]** | **1,855.7 μs** | **10.67 μs** | **6.35 μs** |  **1.00** | **1035.41 KB** |        **1.00** |
