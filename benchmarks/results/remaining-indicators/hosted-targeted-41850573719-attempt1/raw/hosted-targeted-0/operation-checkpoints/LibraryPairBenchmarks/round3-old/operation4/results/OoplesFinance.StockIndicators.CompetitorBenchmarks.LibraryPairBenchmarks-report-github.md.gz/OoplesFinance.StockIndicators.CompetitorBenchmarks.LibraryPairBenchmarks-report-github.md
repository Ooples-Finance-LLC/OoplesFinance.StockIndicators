```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId             | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |------------------- |-----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Dx** |   **735.7 μs** | **39.52 μs** | **26.14 μs** |  **1.00** |    **0.05** | **105.63 KB** |        **1.00** |
|        |       |                    |            |          |          |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Dx** | **6,860.6 μs** | **23.50 μs** | **15.54 μs** |  **1.00** |    **0.00** |   **1035 KB** |        **1.00** |
