```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDM [22]** |   **167.57 μs** |  **2.912 μs** |  **1.523 μs** |  **1.00** |    **0.01** | **105.65 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDM [22] |    22.22 μs |  1.414 μs |  0.935 μs |  0.13 |    0.01 |  40.55 KB |        0.38 |
|            |       |                      |             |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)lusDM [22]** | **1,474.22 μs** | **27.741 μs** | **16.508 μs** |  **1.00** |    **0.02** | **1036.7 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDM [22] |   185.04 μs | 15.997 μs | 10.581 μs |  0.13 |    0.01 | 330.91 KB |        0.32 |
