```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)dline [22]** |  **1,115.4 μs** |  **45.56 μs** |  **27.11 μs** |  **1.00** |    **0.03** |  **223.38 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)dline [22] |    191.8 μs |  18.91 μs |  11.25 μs |  0.17 |    0.01 |  290.52 KB |        1.30 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)dline [22]** | **10,982.2 μs** | **221.14 μs** | **131.60 μs** |  **1.00** |    **0.02** | **2156.66 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)dline [22] |  1,891.8 μs |  46.77 μs |  30.93 μs |  0.17 |    0.00 | 2812.98 KB |        1.30 |
