```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  |   **871.1 μs** |  **4.99 μs** |  **2.97 μs** | **101.36 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  |   863.1 μs |  7.07 μs |  4.68 μs |  53.74 KB |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **8,540.8 μs** | **75.37 μs** | **39.42 μs** | **946.04 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 8,384.7 μs | 30.37 μs | 15.88 μs | 476.25 KB |
