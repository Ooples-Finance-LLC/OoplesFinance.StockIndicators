```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error       | StdDev      | Allocated |
|------------------ |--------------------- |------ |-----------:|------------:|------------:|----------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  |   **872.2 μs** |     **5.85 μs** |     **3.48 μs** | **101.36 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  |   831.7 μs |     6.90 μs |     3.61 μs |  53.74 KB |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **8,222.8 μs** |    **36.88 μs** |    **19.29 μs** |  **946.1 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 9,914.9 μs | 3,796.02 μs | 2,510.83 μs |  476.2 KB |
