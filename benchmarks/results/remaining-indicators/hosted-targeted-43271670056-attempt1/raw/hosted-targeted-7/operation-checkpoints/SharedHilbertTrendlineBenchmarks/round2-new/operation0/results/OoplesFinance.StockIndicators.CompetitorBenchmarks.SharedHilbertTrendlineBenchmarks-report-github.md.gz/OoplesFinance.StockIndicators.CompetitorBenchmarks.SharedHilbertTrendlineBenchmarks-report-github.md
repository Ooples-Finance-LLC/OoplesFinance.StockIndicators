```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  |   **926.5 μs** |   **4.13 μs** |  **2.16 μs** |  **7.16** |    **0.09** |        **-** |        **-** |        **-** |  **101.37 KB** |        **0.49** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  |   908.3 μs |   7.13 μs |  3.73 μs |  7.01 |    0.09 |        - |        - |        - |   53.73 KB |        0.26 |
| NativeSingle      | Skend(...)dline [22] | 1000  |   129.5 μs |   2.54 μs |  1.68 μs |  1.00 |    0.02 |  12.6953 |   2.9297 |        - |  207.71 KB |        1.00 |
| NativeParallel    | Skend(...)dline [22] | 1000  |   250.8 μs |   7.87 μs |  4.68 μs |  1.94 |    0.04 |  33.2031 |   9.7656 |        - |  528.53 KB |        2.54 |
|                   |                      |       |            |           |          |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **8,914.3 μs** |  **88.01 μs** | **52.37 μs** |  **5.93** |    **0.17** |        **-** |        **-** |        **-** |  **946.07 KB** |        **0.46** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 8,931.0 μs |  30.64 μs | 20.27 μs |  5.95 |    0.17 |        - |        - |        - |  476.29 KB |        0.23 |
| NativeSingle      | Skend(...)dline [22] | 10000 | 1,503.3 μs |  68.44 μs | 45.27 μs |  1.00 |    0.04 | 187.5000 | 148.4375 |  85.9375 | 2071.78 KB |        1.00 |
| NativeParallel    | Skend(...)dline [22] | 10000 | 2,739.2 μs | 122.01 μs | 72.60 μs |  1.82 |    0.07 | 421.8750 | 328.1250 | 140.6250 | 5258.75 KB |        2.54 |
