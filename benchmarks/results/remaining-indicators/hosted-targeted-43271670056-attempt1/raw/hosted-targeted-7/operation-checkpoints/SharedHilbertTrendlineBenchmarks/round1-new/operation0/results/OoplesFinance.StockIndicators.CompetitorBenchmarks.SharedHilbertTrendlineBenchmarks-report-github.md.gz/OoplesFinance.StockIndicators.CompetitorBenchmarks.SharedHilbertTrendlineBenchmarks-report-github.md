```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  | **1,522.8 μs** | **337.37 μs** | **200.76 μs** | **101.37 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  |   895.3 μs |   8.18 μs |   4.87 μs |  53.73 KB |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **8,816.8 μs** |  **57.73 μs** |  **34.35 μs** | **946.07 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 8,860.2 μs |  71.58 μs |  47.34 μs | 476.23 KB |
