```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |-----------:|------------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)tSine [22]** |   **895.5 μs** |    **29.77 μs** |  **17.72 μs** |  **1.00** |    **0.03** | **166.88 KB** |        **1.00** |
|        |       |                      |            |             |           |       |         |           |             |
| **Ooples** | **10000** | **TaLib(...)tSine [22]** | **9,342.7 μs** | **1,038.83 μs** | **687.12 μs** |  **1.00** |    **0.10** | **1599.2 KB** |        **1.00** |
