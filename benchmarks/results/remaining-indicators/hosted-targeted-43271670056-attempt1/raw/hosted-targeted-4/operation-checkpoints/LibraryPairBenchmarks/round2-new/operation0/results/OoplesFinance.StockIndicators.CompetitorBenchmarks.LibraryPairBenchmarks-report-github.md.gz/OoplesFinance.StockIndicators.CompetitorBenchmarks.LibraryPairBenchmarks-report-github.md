```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tSine [22]** |   **924.3 μs** | **73.17 μs** | **43.54 μs** |  **1.00** |    **0.06** |  **166.88 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tSine [22] |   612.0 μs | 36.28 μs | 24.00 μs |  0.66 |    0.04 |   74.23 KB |        0.44 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)tSine [22]** | **8,769.8 μs** | **72.18 μs** | **37.75 μs** |  **1.00** |    **0.01** | **1598.59 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tSine [22] | 6,159.7 μs | 47.65 μs | 28.36 μs |  0.70 |    0.00 |  653.98 KB |        0.41 |
