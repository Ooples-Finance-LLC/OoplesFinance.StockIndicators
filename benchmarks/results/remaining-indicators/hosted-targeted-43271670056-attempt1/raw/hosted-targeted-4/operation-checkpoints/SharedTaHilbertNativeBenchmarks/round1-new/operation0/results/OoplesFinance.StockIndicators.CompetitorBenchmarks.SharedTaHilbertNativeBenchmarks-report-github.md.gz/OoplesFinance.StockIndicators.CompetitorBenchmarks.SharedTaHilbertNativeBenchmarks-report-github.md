```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **790.2 μs** | **23.89 μs** | **15.80 μs** |  **85.26 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   779.0 μs | 28.86 μs | 19.09 μs |  37.67 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **8,273.3 μs** | **42.34 μs** | **25.20 μs** | **789.33 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 8,157.0 μs | 41.24 μs | 21.57 μs | 319.51 KB |
