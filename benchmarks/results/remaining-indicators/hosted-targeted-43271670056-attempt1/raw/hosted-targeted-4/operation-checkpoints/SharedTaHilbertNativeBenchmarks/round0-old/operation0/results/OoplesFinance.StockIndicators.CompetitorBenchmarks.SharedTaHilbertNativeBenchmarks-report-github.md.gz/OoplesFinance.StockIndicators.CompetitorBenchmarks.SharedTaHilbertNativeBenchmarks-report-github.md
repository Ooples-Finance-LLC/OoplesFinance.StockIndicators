```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **715.8 μs** |  **15.99 μs** |   **9.51 μs** |  **85.25 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   760.5 μs |  18.42 μs |  10.96 μs |  37.67 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **7,362.8 μs** | **186.02 μs** | **110.70 μs** |  **789.3 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 7,195.3 μs |  96.15 μs |  57.22 μs | 319.46 KB |
