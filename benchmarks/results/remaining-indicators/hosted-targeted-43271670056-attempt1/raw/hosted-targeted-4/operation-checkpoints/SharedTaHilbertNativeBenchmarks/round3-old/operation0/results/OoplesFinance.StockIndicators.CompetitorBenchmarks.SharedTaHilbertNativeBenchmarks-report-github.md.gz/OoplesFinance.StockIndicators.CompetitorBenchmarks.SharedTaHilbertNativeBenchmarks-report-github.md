```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **723.5 μs** | **34.24 μs** | **20.38 μs** |  **85.25 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   727.5 μs | 18.16 μs | 12.01 μs |  37.67 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **7,354.4 μs** | **69.77 μs** | **41.52 μs** |  **789.3 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 7,245.1 μs | 97.77 μs | 64.67 μs | 319.53 KB |
