```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **783.8 μs** |   **7.13 μs** |   **3.73 μs** |  **1.33** |    **0.03** |  **85.26 KB** |        **5.42** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   789.4 μs |  53.14 μs |  35.15 μs |  1.34 |    0.07 |  37.69 KB |        2.39 |
| NativeSingle      | TaLib(...)tSine [22] | 1000  |   591.0 μs |  23.34 μs |  15.44 μs |  1.00 |    0.03 |  15.74 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 1000  |   862.2 μs |  27.73 μs |  16.50 μs |  1.46 |    0.04 |  55.99 KB |        3.56 |
|                   |                      |       |            |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **8,359.1 μs** | **125.79 μs** |  **74.86 μs** |  **1.37** |    **0.01** | **789.32 KB** |        **5.03** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 8,270.8 μs | 153.85 μs |  91.55 μs |  1.36 |    0.02 | 319.51 KB |        2.04 |
| NativeSingle      | TaLib(...)tSine [22] | 10000 | 6,090.6 μs |  56.11 μs |  33.39 μs |  1.00 |    0.01 |  156.8 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 10000 | 8,649.2 μs | 976.06 μs | 645.60 μs |  1.42 |    0.10 | 548.75 KB |        3.50 |
