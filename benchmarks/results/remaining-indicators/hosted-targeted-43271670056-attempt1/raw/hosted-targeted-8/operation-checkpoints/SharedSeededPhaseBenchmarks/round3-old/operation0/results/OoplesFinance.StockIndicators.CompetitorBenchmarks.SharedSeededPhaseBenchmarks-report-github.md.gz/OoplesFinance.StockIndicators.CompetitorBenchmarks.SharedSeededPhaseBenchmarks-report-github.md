```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **QuanTAlib.Mama** | **1000**  |   **418.4 μs** |  **10.12 μs** |  **5.29 μs** |  **83.03 KB** |
| BuilderLatestOnly | QuanTAlib.Mama | 1000  |   398.1 μs |   3.21 μs |  1.91 μs |  35.44 KB |
| **BuilderFull**       | **QuanTAlib.Mama** | **10000** | **4,054.1 μs** | **124.45 μs** | **74.06 μs** | **786.73 KB** |
| BuilderLatestOnly | QuanTAlib.Mama | 10000 | 4,011.2 μs |  41.50 μs | 24.69 μs | 316.93 KB |
