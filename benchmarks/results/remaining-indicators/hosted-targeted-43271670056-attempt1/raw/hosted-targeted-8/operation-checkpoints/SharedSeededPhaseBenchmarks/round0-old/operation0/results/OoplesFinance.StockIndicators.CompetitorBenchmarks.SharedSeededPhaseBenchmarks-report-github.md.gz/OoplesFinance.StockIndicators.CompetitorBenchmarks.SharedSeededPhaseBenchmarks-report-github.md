```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **QuanTAlib.Mama** | **1000**  |   **421.9 μs** |  **6.18 μs** |  **3.23 μs** |  **83.03 KB** |
| BuilderLatestOnly | QuanTAlib.Mama | 1000  |   409.9 μs |  4.44 μs |  2.32 μs |  35.44 KB |
| **BuilderFull**       | **QuanTAlib.Mama** | **10000** | **4,090.4 μs** | **21.75 μs** | **11.38 μs** | **786.73 KB** |
| BuilderLatestOnly | QuanTAlib.Mama | 10000 | 4,049.0 μs | 57.05 μs | 29.84 μs | 316.92 KB |
