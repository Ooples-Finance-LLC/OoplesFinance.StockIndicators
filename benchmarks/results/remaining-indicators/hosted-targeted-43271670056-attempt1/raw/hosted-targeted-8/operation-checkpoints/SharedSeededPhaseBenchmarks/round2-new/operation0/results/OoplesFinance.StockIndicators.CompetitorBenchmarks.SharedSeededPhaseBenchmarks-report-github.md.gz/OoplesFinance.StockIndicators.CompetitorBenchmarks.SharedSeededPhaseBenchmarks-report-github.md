```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |-----------:|----------:|----------:|------:|--------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Mama** | **1000**  |   **479.0 μs** |   **5.28 μs** |   **3.14 μs** |  **1.91** |    **0.02** |       **-** |       **-** |       **-** |   **83.03 KB** |        **1.48** |
| BuilderLatestOnly | QuanTAlib.Mama | 1000  |   464.4 μs |   3.72 μs |   1.95 μs |  1.85 |    0.02 |       - |       - |       - |   35.44 KB |        0.63 |
| NativeSingle      | QuanTAlib.Mama | 1000  |   251.5 μs |   3.53 μs |   2.10 μs |  1.00 |    0.01 |       - |       - |       - |   56.25 KB |        1.00 |
| NativeParallel    | QuanTAlib.Mama | 1000  |   951.0 μs |  99.10 μs |  65.55 μs |  3.78 |    0.25 |       - |       - |       - |  119.66 KB |        2.13 |
|                   |                |       |            |           |           |       |         |         |         |         |            |             |
| **BuilderFull**       | **QuanTAlib.Mama** | **10000** | **4,704.4 μs** |  **62.22 μs** |  **32.54 μs** |  **1.78** |    **0.04** |       **-** |       **-** |       **-** |  **786.71 KB** |        **1.43** |
| BuilderLatestOnly | QuanTAlib.Mama | 10000 | 4,593.9 μs |  44.51 μs |  26.49 μs |  1.74 |    0.03 |       - |       - |       - |  316.92 KB |        0.58 |
| NativeSingle      | QuanTAlib.Mama | 10000 | 2,638.5 μs | 103.18 μs |  53.96 μs |  1.00 |    0.03 | 31.2500 | 31.2500 | 31.2500 |  548.85 KB |        1.00 |
| NativeParallel    | QuanTAlib.Mama | 10000 | 6,222.4 μs | 673.72 μs | 445.62 μs |  2.36 |    0.17 |       - |       - |       - | 1139.61 KB |        2.08 |
