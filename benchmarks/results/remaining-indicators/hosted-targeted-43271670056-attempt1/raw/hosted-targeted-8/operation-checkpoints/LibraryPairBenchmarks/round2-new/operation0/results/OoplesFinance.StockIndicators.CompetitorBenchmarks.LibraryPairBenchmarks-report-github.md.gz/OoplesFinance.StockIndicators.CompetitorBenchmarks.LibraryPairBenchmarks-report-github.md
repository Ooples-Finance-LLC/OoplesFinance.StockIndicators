```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Mama** |   **603.8 μs** |  **24.34 μs** | **14.48 μs** |  **1.00** |    **0.03** |  **164.44 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Mama |   312.5 μs |  25.12 μs | 16.61 μs |  0.52 |    0.03 |   98.02 KB |        0.60 |
|            |       |                |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Mama** | **5,747.2 μs** | **137.76 μs** | **81.98 μs** |  **1.00** |    **0.02** | **1596.42 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Mama | 2,910.8 μs |  66.44 μs | 43.95 μs |  0.51 |    0.01 |  889.64 KB |        0.56 |
