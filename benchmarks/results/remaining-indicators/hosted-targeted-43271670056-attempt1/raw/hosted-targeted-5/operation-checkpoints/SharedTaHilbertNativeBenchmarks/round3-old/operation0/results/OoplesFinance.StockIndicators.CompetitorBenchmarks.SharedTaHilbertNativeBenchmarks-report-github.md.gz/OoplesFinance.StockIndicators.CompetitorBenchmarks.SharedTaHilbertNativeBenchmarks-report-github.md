```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)dline [27]** | **1000**  |   **859.1 μs** |  **5.65 μs** |  **3.36 μs** |  **69.69 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 1000  |   838.5 μs |  5.83 μs |  3.47 μs |  22.06 KB |
| **BuilderFull**       | **TaLib(...)dline [27]** | **10000** | **8,679.0 μs** | **68.53 μs** | **40.78 μs** | **633.09 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 10000 | 8,631.6 μs | 54.24 μs | 32.28 μs | 163.28 KB |
