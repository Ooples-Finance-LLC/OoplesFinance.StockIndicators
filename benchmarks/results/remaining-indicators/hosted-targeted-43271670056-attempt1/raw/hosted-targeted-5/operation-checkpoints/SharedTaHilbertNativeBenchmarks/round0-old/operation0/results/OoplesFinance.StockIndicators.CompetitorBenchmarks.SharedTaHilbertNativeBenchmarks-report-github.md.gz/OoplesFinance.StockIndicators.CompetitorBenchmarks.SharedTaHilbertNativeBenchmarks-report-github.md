```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)dline [27]** | **1000**  |   **864.7 μs** |  **5.55 μs** |  **2.90 μs** |  **69.69 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 1000  |   842.7 μs |  5.23 μs |  3.11 μs |  22.06 KB |
| **BuilderFull**       | **TaLib(...)dline [27]** | **10000** | **8,725.0 μs** | **30.74 μs** | **18.29 μs** | **633.08 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 10000 | 8,719.0 μs | 68.38 μs | 40.69 μs | 163.28 KB |
