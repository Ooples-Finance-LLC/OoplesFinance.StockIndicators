```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Ratio | RatioSD | Gen0    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dline [27]** | **1000**  | **1,101.7 μs** | **10.21 μs** |  **6.08 μs** |  **8.90** |    **0.05** |       **-** |   **69.7 KB** |        **8.76** |
| BuilderLatestOnly | TaLib(...)dline [27] | 1000  |   898.0 μs |  9.38 μs |  5.58 μs |  7.26 |    0.04 |       - |  22.06 KB |        2.77 |
| NativeSingle      | TaLib(...)dline [27] | 1000  |   123.7 μs |  0.34 μs |  0.18 μs |  1.00 |    0.00 |       - |   7.95 KB |        1.00 |
| NativeParallel    | TaLib(...)dline [27] | 1000  |   206.8 μs | 26.74 μs | 15.91 μs |  1.67 |    0.12 |  1.9531 |  28.52 KB |        3.59 |
|                   |                      |       |            |          |          |       |         |         |           |             |
| **BuilderFull**       | **TaLib(...)dline [27]** | **10000** | **9,386.0 μs** | **47.97 μs** | **28.55 μs** |  **6.87** |    **0.04** |       **-** | **633.15 KB** |        **8.08** |
| BuilderLatestOnly | TaLib(...)dline [27] | 10000 | 9,370.5 μs | 39.36 μs | 20.59 μs |  6.86 |    0.03 |       - | 163.39 KB |        2.09 |
| NativeSingle      | TaLib(...)dline [27] | 10000 | 1,365.3 μs |  9.78 μs |  6.47 μs |  1.00 |    0.01 |       - |  78.32 KB |        1.00 |
| NativeParallel    | TaLib(...)dline [27] | 10000 | 1,604.8 μs | 52.40 μs | 34.66 μs |  1.18 |    0.02 | 15.6250 | 274.72 KB |        3.51 |
