```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)dline [27]** | **1000**  |   **947.9 μs** |  **5.67 μs** |  **2.96 μs** |   **69.7 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 1000  |   915.1 μs |  6.75 μs |  3.53 μs |  22.06 KB |
| **BuilderFull**       | **TaLib(...)dline [27]** | **10000** | **9,642.6 μs** | **86.19 μs** | **51.29 μs** | **633.21 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 10000 | 9,670.0 μs | 27.79 μs | 14.53 μs | 163.37 KB |
