```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dline [27]** |   **984.5 μs** | **32.16 μs** | **21.27 μs** |  **1.00** |    **0.03** |  **110.52 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dline [27] |   144.7 μs |  0.65 μs |  0.34 μs |  0.15 |    0.00 |   41.48 KB |        0.38 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)dline [27]** | **9,521.1 μs** | **30.68 μs** | **18.26 μs** |  **1.00** |    **0.00** | **1041.58 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dline [27] | 1,438.2 μs | 19.05 μs | 11.34 μs |  0.15 |    0.00 |  331.52 KB |        0.32 |
