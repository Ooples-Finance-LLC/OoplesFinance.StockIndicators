```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId          | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetMama** |  **1,114.7 μs** |  **38.93 μs** |  **23.16 μs** |  **1.00** |    **0.03** |  **164.44 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetMama |    150.6 μs |  13.29 μs |   7.91 μs |  0.14 |    0.01 |  250.22 KB |        1.52 |
|            |       |                 |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetMama** | **11,130.6 μs** | **694.61 μs** | **459.44 μs** |  **1.00** |    **0.06** | **1595.77 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetMama |  1,489.5 μs |  18.67 μs |  11.11 μs |  0.13 |    0.01 | 2412.33 KB |        1.51 |
