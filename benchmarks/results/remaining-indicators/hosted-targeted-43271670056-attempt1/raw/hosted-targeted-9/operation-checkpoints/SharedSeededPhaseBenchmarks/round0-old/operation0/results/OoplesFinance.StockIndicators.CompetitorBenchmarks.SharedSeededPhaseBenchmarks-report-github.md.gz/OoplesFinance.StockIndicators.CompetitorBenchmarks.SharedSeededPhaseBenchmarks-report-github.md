```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetMama** | **1000**  |   **514.3 μs** |  **3.17 μs** |  **1.89 μs** |       **-** |  **83.03 KB** |
| BuilderLatestOnly | Skender.GetMama | 1000  |   511.2 μs |  1.38 μs |  0.82 μs |       - |  35.45 KB |
| **BuilderFull**       | **Skender.GetMama** | **10000** | **5,040.0 μs** | **38.01 μs** | **22.62 μs** | **31.2500** | **786.76 KB** |
| BuilderLatestOnly | Skender.GetMama | 10000 | 4,973.6 μs | 54.23 μs | 35.87 μs |       - | 316.92 KB |
