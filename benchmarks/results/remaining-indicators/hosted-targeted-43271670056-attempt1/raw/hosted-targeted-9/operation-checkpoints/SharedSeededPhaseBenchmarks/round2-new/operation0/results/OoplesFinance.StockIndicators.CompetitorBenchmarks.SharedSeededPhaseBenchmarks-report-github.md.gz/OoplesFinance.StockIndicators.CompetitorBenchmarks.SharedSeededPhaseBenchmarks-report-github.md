```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev   | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |-----------:|----------:|---------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetMama** | **1000**  |   **580.9 μs** |   **2.72 μs** |  **1.42 μs** |  **4.36** |    **0.03** |        **-** |        **-** |        **-** |   **83.08 KB** |        **0.43** |
| BuilderLatestOnly | Skender.GetMama | 1000  |   567.2 μs |   3.99 μs |  2.64 μs |  4.26 |    0.03 |        - |        - |        - |   35.44 KB |        0.18 |
| NativeSingle      | Skender.GetMama | 1000  |   133.2 μs |   1.40 μs |  0.83 μs |  1.00 |    0.01 |  11.7188 |   1.9531 |        - |  192.06 KB |        1.00 |
| NativeParallel    | Skender.GetMama | 1000  |   248.1 μs |  15.08 μs |  9.98 μs |  1.86 |    0.07 |  31.2500 |   9.7656 |        - |  489.38 KB |        2.55 |
|                   |                 |       |            |           |          |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetMama** | **10000** | **5,649.9 μs** | **102.07 μs** | **67.52 μs** |  **3.56** |    **0.08** |  **31.2500** |        **-** |        **-** |  **786.76 KB** |        **0.41** |
| BuilderLatestOnly | Skender.GetMama | 10000 | 5,654.3 μs |  45.71 μs | 23.91 μs |  3.57 |    0.06 |        - |        - |        - |  316.92 KB |        0.17 |
| NativeSingle      | Skender.GetMama | 10000 | 1,586.2 μs |  50.20 μs | 29.87 μs |  1.00 |    0.03 | 179.6875 | 140.6250 |  85.9375 | 1915.93 KB |        1.00 |
| NativeParallel    | Skender.GetMama | 10000 | 2,663.4 μs | 138.26 μs | 82.28 μs |  1.68 |    0.06 | 406.2500 | 312.5000 | 140.6250 | 4868.26 KB |        2.54 |
