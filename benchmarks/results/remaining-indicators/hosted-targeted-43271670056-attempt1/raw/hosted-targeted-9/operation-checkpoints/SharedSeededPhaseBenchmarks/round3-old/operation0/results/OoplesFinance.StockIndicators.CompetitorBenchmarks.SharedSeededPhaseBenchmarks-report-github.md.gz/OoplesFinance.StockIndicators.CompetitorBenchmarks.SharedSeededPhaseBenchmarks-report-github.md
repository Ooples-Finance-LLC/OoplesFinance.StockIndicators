```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetMama** | **1000**  |   **515.4 μs** |   **3.47 μs** |   **2.07 μs** |       **-** |  **83.03 KB** |
| BuilderLatestOnly | Skender.GetMama | 1000  |   510.3 μs |   8.28 μs |   4.93 μs |       - |  35.44 KB |
| **BuilderFull**       | **Skender.GetMama** | **10000** | **5,161.5 μs** | **201.18 μs** | **133.07 μs** | **31.2500** | **786.74 KB** |
| BuilderLatestOnly | Skender.GetMama | 10000 | 5,055.3 μs |  42.21 μs |  22.08 μs |       - | 316.89 KB |
