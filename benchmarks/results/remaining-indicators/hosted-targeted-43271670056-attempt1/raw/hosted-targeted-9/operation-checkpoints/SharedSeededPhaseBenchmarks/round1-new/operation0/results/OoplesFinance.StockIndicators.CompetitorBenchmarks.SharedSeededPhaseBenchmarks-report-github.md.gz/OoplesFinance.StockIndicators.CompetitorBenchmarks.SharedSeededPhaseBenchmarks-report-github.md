```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetMama** | **1000**  |   **575.9 μs** | **21.70 μs** | **12.91 μs** |       **-** |  **83.04 KB** |
| BuilderLatestOnly | Skender.GetMama | 1000  |   618.1 μs | 75.19 μs | 49.73 μs |       - |  35.45 KB |
| **BuilderFull**       | **Skender.GetMama** | **10000** | **5,518.3 μs** | **61.17 μs** | **36.40 μs** | **31.2500** | **786.75 KB** |
| BuilderLatestOnly | Skender.GetMama | 10000 | 5,574.6 μs | 58.60 μs | 34.87 μs |       - | 316.92 KB |
