```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dMode [27]** |  **1,171.8 μs** | **40.86 μs** | **24.32 μs** |  **1.00** |    **0.03** |  **113.12 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dMode [27] |    478.1 μs |  1.31 μs |  0.78 μs |  0.41 |    0.01 |    37.2 KB |        0.33 |
|            |       |                      |             |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)dMode [27]** | **11,840.8 μs** | **53.54 μs** | **31.86 μs** |  **1.00** |    **0.00** | **1042.81 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dMode [27] |  5,003.2 μs | 27.38 μs | 18.11 μs |  0.42 |    0.00 |  290.44 KB |        0.28 |
