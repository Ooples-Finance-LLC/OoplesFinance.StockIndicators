```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1,137.6 μs** |  **24.19 μs** |  **14.39 μs** |  **2.76** |    **0.04** |  **72.11 KB** |       **15.26** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1,079.0 μs |   8.46 μs |   4.42 μs |  2.62 |    0.02 |  24.45 KB |        5.17 |
| NativeSingle      | TaLib(...)dMode [27] | 1000  |    411.6 μs |   4.26 μs |   2.53 μs |  1.00 |    0.01 |   4.73 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 1000  |    629.2 μs |  29.09 μs |  19.24 μs |  1.53 |    0.05 |   17.4 KB |        3.68 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **11,616.8 μs** | **181.05 μs** |  **94.69 μs** |  **2.35** |    **0.02** | **635.79 KB** |       **15.88** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 11,492.9 μs |  38.51 μs |  22.91 μs |  2.33 |    0.01 | 165.54 KB |        4.13 |
| NativeSingle      | TaLib(...)dMode [27] | 10000 |  4,937.5 μs |  16.52 μs |   9.83 μs |  1.00 |    0.00 |  40.04 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 10000 |  6,676.2 μs | 288.89 μs | 171.91 μs |  1.35 |    0.03 |  140.9 KB |        3.52 |
