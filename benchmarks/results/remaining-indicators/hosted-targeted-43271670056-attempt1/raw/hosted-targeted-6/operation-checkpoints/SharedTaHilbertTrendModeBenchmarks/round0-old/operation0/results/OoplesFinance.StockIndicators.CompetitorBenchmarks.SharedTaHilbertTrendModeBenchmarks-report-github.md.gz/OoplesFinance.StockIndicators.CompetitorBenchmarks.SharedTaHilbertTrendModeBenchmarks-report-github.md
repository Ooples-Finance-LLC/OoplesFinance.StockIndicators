```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1.037 ms** | **0.0068 ms** | **0.0035 ms** |  **72.02 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1.047 ms | 0.0066 ms | 0.0034 ms |  24.46 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **10.904 ms** | **0.0232 ms** | **0.0121 ms** |  **635.3 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 11.003 ms | 0.0373 ms | 0.0195 ms | 165.65 KB |
