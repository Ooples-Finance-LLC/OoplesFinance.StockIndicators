```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1.051 ms** | **0.0048 ms** | **0.0029 ms** |   **72.1 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1.032 ms | 0.0034 ms | 0.0018 ms |  24.46 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **10.773 ms** | **0.0691 ms** | **0.0411 ms** | **635.33 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 10.821 ms | 0.0470 ms | 0.0246 ms | 165.59 KB |
