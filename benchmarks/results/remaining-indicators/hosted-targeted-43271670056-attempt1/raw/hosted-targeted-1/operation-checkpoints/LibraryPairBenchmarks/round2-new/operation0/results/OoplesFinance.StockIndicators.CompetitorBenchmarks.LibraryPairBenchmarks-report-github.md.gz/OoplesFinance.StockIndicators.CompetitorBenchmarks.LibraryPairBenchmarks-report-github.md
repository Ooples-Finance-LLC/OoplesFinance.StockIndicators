```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)hasor [24]** |   **614.2 μs** |  **40.65 μs** |  **24.19 μs** |  **1.00** |    **0.05** | **164.47 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)hasor [24] |   112.2 μs |   5.02 μs |   3.32 μs |  0.18 |    0.01 |  73.87 KB |        0.45 |
|            |       |                      |            |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)hasor [24]** | **6,341.3 μs** | **694.74 μs** | **413.43 μs** |  **1.00** |    **0.09** | **1596.5 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)hasor [24] | 1,105.5 μs |  42.99 μs |  22.49 μs |  0.17 |    0.01 | 654.23 KB |        0.41 |
