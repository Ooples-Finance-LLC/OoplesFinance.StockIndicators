```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)hasor [24]** | **1000**  |   **477.2 μs** |   **2.47 μs** |   **1.29 μs** |       **-** |  **82.84 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 1000  |   474.9 μs |   5.44 μs |   2.84 μs |       - |  35.25 KB |
| **BuilderFull**       | **TaLib(...)hasor [24]** | **10000** | **4,683.5 μs** |  **28.99 μs** |  **17.25 μs** | **31.2500** | **786.54 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 10000 | 4,787.7 μs | 158.23 μs | 104.66 μs |       - | 316.73 KB |
