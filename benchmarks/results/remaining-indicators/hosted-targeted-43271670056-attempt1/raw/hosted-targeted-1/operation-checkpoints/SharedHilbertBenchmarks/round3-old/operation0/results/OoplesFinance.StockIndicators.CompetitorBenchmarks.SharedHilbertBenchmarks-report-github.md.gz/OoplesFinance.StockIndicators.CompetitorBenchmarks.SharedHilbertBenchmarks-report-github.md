```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)hasor [24]** | **1000**  |   **439.6 μs** |  **3.63 μs** |  **2.16 μs** |       **-** |  **82.84 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 1000  |   433.0 μs |  2.57 μs |  1.70 μs |       - |  35.25 KB |
| **BuilderFull**       | **TaLib(...)hasor [24]** | **10000** | **4,323.7 μs** | **35.91 μs** | **21.37 μs** | **31.2500** | **786.57 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 10000 | 4,232.7 μs | 25.02 μs | 14.89 μs |       - | 316.71 KB |
