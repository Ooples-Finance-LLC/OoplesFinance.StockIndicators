```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)hasor [24]** | **1000**  |   **486.2 μs** |  **6.33 μs** |  **3.77 μs** |  **4.61** |    **0.04** |        **-** |        **-** |        **-** |  **82.84 KB** |        **5.33** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 1000  |   479.6 μs |  2.49 μs |  1.48 μs |  4.55 |    0.02 |        - |        - |        - |  35.25 KB |        2.27 |
| NativeSingle      | TaLib(...)hasor [24] | 1000  |   105.4 μs |  0.46 μs |  0.27 μs |  1.00 |    0.00 |        - |        - |        - |  15.55 KB |        1.00 |
| NativeParallel    | TaLib(...)hasor [24] | 1000  |   202.0 μs | 19.00 μs | 12.57 μs |  1.92 |    0.11 |   3.9063 |        - |        - |  54.84 KB |        3.53 |
|                   |                      |       |            |          |          |       |         |          |          |          |           |             |
| **BuilderFull**       | **TaLib(...)hasor [24]** | **10000** | **4,811.4 μs** | **28.25 μs** | **16.81 μs** |  **4.17** |    **0.04** |  **31.2500** |        **-** |        **-** | **786.53 KB** |        **5.02** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 10000 | 4,721.6 μs | 25.16 μs | 16.64 μs |  4.09 |    0.04 |        - |        - |        - | 316.73 KB |        2.02 |
| NativeSingle      | TaLib(...)hasor [24] | 10000 | 1,153.8 μs | 17.84 μs | 11.80 μs |  1.00 |    0.01 |  46.8750 |  46.8750 |  46.8750 |  156.6 KB |        1.00 |
| NativeParallel    | TaLib(...)hasor [24] | 10000 | 1,510.5 μs | 35.65 μs | 23.58 μs |  1.31 |    0.02 | 125.0000 | 125.0000 | 125.0000 | 548.11 KB |        3.50 |
