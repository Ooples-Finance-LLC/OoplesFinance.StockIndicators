```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mama** | **1000**  |   **406.6 μs** |  **3.21 μs** |  **1.91 μs** |  **83.03 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 1000  |   396.3 μs |  3.03 μs |  1.80 μs |  35.44 KB |
| **BuilderFull**       | **TaLib.Functions.Mama** | **10000** | **4,010.1 μs** | **31.22 μs** | **16.33 μs** | **786.73 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 10000 | 3,931.6 μs | 58.13 μs | 34.59 μs | 316.92 KB |
