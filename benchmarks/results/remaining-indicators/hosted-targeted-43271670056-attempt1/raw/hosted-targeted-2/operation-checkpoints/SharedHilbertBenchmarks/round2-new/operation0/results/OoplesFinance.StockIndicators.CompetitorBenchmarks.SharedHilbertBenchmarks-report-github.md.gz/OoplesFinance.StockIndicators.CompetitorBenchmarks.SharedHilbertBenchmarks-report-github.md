```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Mama** | **1000**  |   **407.33 μs** |   **2.699 μs** |  **1.412 μs** |  **4.61** |    **0.03** |        **-** |        **-** |        **-** |  **83.03 KB** |        **5.34** |
| BuilderLatestOnly | TaLib.Functions.Mama | 1000  |   408.88 μs |  10.740 μs |  6.391 μs |  4.62 |    0.08 |        - |        - |        - |  35.44 KB |        2.28 |
| NativeSingle      | TaLib.Functions.Mama | 1000  |    88.43 μs |   1.044 μs |  0.621 μs |  1.00 |    0.01 |        - |        - |        - |  15.55 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mama | 1000  |   165.76 μs |  16.007 μs | 10.588 μs |  1.87 |    0.11 |        - |        - |        - |  54.83 KB |        3.53 |
|                   |                      |       |             |            |           |       |         |          |          |          |           |             |
| **BuilderFull**       | **TaLib.Functions.Mama** | **10000** | **4,130.16 μs** | **134.045 μs** | **79.768 μs** |  **4.31** |    **0.08** |        **-** |        **-** |        **-** | **786.72 KB** |        **5.02** |
| BuilderLatestOnly | TaLib.Functions.Mama | 10000 | 3,965.36 μs |  48.149 μs | 31.848 μs |  4.14 |    0.03 |        - |        - |        - | 316.91 KB |        2.02 |
| NativeSingle      | TaLib.Functions.Mama | 10000 |   958.68 μs |   2.529 μs |  1.505 μs |  1.00 |    0.00 |  46.8750 |  46.8750 |  46.8750 | 156.59 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mama | 10000 | 1,297.89 μs |  47.723 μs | 31.566 μs |  1.35 |    0.03 | 132.8125 | 132.8125 | 132.8125 | 548.11 KB |        3.50 |
