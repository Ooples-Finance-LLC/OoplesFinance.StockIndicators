```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mama** | **1000**  |   **347.2 μs** |  **3.75 μs** |  **2.23 μs** |  **83.03 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 1000  |   339.8 μs |  0.51 μs |  0.27 μs |  35.43 KB |
| **BuilderFull**       | **TaLib.Functions.Mama** | **10000** | **3,471.3 μs** | **71.99 μs** | **42.84 μs** |  **786.7 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 10000 | 3,492.2 μs | 84.36 μs | 44.12 μs | 316.92 KB |
