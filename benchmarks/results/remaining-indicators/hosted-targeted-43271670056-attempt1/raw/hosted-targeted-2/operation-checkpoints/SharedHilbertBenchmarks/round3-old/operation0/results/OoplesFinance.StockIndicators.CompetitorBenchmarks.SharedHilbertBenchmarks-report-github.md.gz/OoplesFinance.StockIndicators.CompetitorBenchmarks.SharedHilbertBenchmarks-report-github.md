```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mama** | **1000**  |   **349.0 μs** |  **2.12 μs** |  **1.11 μs** |  **83.03 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 1000  |   346.5 μs | 13.58 μs |  8.99 μs |  35.43 KB |
| **BuilderFull**       | **TaLib.Functions.Mama** | **10000** | **3,528.3 μs** | **45.50 μs** | **23.80 μs** | **786.73 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 10000 | 3,417.1 μs | 46.40 μs | 27.61 μs |  316.9 KB |
