```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Mama** |   **526.3 μs** |  **22.69 μs** |  **13.50 μs** |  **1.00** |    **0.03** |  **164.44 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Mama |   111.1 μs |   3.17 μs |   1.88 μs |  0.21 |    0.01 |   73.78 KB |        0.45 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Mama** | **5,106.2 μs** | **635.59 μs** | **332.43 μs** |  **1.00** |    **0.08** | **1596.47 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Mama | 1,040.0 μs |  43.79 μs |  22.90 μs |  0.20 |    0.01 |  654.19 KB |        0.41 |
