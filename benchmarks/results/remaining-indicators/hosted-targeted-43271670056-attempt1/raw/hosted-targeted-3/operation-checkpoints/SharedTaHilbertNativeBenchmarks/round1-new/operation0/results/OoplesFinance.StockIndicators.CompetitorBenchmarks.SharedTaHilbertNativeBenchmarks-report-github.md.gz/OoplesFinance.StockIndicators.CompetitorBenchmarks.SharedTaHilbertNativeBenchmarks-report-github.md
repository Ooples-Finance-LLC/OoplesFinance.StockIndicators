```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **753.7 μs** |  **7.93 μs** |  **4.72 μs** |  **69.37 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   760.7 μs | 29.06 μs | 19.22 μs |  21.77 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **7,861.9 μs** | **68.43 μs** | **40.72 μs** | **632.83 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 7,845.8 μs | 54.29 μs | 32.31 μs | 163.05 KB |
