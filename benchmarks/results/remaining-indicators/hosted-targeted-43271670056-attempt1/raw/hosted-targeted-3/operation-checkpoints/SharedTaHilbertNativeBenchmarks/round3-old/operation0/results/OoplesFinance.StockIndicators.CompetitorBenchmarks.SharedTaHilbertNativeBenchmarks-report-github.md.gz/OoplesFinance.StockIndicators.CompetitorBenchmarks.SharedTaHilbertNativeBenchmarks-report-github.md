```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **686.1 μs** |  **5.31 μs** |  **3.16 μs** |  **69.36 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   677.2 μs |  9.49 μs |  6.27 μs |  21.77 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **7,115.7 μs** | **87.40 μs** | **52.01 μs** | **632.73 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 7,061.0 μs | 43.25 μs | 28.61 μs | 162.84 KB |
