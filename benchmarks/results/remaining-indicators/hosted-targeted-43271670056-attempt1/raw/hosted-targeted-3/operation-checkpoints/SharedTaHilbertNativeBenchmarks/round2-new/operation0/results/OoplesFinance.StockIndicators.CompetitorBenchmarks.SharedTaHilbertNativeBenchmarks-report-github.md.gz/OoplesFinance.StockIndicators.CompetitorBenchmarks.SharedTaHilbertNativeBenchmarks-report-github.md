```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **768.4 μs** |  **10.42 μs** |   **5.45 μs** |  **1.48** |    **0.01** |  **69.41 KB** |        **8.28** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   755.2 μs |   6.68 μs |   4.42 μs |  1.45 |    0.01 |  21.77 KB |        2.60 |
| NativeSingle      | TaLib(...)Phase [25] | 1000  |   519.8 μs |   4.72 μs |   2.47 μs |  1.00 |    0.01 |   8.38 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 1000  |   747.8 μs |  17.64 μs |   9.23 μs |  1.44 |    0.02 |  30.19 KB |        3.60 |
|                   |                      |       |            |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **7,842.6 μs** | **131.69 μs** |  **68.88 μs** |  **1.28** |    **0.11** | **632.83 KB** |        **7.99** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 7,818.2 μs |  37.79 μs |  22.49 μs |  1.28 |    0.11 | 162.99 KB |        2.06 |
| NativeSingle      | TaLib(...)Phase [25] | 10000 | 6,158.8 μs | 908.23 μs | 600.74 μs |  1.01 |    0.13 |  79.19 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 10000 | 7,910.9 μs | 773.83 μs | 460.49 μs |  1.29 |    0.13 | 276.91 KB |        3.50 |
