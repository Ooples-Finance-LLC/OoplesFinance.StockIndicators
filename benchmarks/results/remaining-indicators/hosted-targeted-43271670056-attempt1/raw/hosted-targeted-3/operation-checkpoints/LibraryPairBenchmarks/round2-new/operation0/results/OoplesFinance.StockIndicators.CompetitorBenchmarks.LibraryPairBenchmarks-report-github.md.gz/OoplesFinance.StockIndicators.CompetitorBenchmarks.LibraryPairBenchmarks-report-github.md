```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Phase [25]** |   **791.0 μs** | **26.17 μs** | **15.57 μs** |  **1.00** |    **0.03** |  **110.48 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Phase [25] |   546.8 μs | 23.90 μs | 15.81 μs |  0.69 |    0.02 |   41.43 KB |        0.37 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)Phase [25]** | **7,981.2 μs** | **26.68 μs** | **15.88 μs** |  **1.00** |    **0.00** | **1041.54 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Phase [25] | 5,699.4 μs | 24.06 μs | 15.92 μs |  0.71 |    0.00 |   331.8 KB |        0.32 |
