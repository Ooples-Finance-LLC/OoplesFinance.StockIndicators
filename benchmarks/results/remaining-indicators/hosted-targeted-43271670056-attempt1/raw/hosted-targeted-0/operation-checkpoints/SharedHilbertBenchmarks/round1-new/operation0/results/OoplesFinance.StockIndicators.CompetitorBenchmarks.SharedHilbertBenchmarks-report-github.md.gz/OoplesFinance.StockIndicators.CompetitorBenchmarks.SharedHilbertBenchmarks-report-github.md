```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)eriod [26]** | **1000**  |   **586.0 μs** |  **80.11 μs** |  **41.90 μs** |       **-** |  **66.96 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 1000  |   569.8 μs |  75.95 μs |  45.20 μs |       - |  19.39 KB |
| **BuilderFull**       | **TaLib(...)eriod [26]** | **10000** | **4,708.5 μs** | **173.11 μs** | **103.02 μs** | **31.2500** | **630.02 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 10000 | 4,736.9 μs | 265.86 μs | 175.85 μs |       - | 160.17 KB |
