```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Ratio | RatioSD | Gen0    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)eriod [26]** | **1000**  |   **478.5 μs** |  **7.49 μs** |  **3.92 μs** |  **4.20** |    **0.04** |       **-** |  **66.95 KB** |        **8.38** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 1000  |   471.0 μs | 12.17 μs |  7.24 μs |  4.14 |    0.06 |       - |  19.36 KB |        2.42 |
| NativeSingle      | TaLib(...)eriod [26] | 1000  |   113.9 μs |  1.04 μs |  0.62 μs |  1.00 |    0.01 |       - |   7.99 KB |        1.00 |
| NativeParallel    | TaLib(...)eriod [26] | 1000  |   198.5 μs | 20.20 μs | 13.36 μs |  1.74 |    0.11 |  1.9531 |  28.37 KB |        3.55 |
|                   |                      |       |            |          |          |       |         |         |           |             |
| **BuilderFull**       | **TaLib(...)eriod [26]** | **10000** | **4,663.9 μs** | **32.69 μs** | **17.10 μs** |  **4.04** |    **0.02** | **31.2500** | **630.03 KB** |        **8.04** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 10000 | 4,612.2 μs | 50.74 μs | 30.19 μs |  4.00 |    0.03 |       - | 160.21 KB |        2.04 |
| NativeSingle      | TaLib(...)eriod [26] | 10000 | 1,153.9 μs |  8.68 μs |  4.54 μs |  1.00 |    0.01 |       - |  78.36 KB |        1.00 |
| NativeParallel    | TaLib(...)eriod [26] | 10000 | 1,283.6 μs | 75.27 μs | 49.79 μs |  1.11 |    0.04 | 15.6250 | 274.51 KB |        3.50 |
