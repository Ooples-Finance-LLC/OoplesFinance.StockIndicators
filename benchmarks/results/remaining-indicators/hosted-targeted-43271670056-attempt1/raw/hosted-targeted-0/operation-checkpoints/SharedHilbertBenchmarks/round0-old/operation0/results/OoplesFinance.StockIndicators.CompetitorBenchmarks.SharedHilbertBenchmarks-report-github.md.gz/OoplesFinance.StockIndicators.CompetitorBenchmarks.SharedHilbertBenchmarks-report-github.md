```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)eriod [26]** | **1000**  |   **442.9 μs** | **25.57 μs** | **13.37 μs** |       **-** |  **66.95 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 1000  |   424.0 μs |  1.97 μs |  1.03 μs |       - |  19.36 KB |
| **BuilderFull**       | **TaLib(...)eriod [26]** | **10000** | **4,177.0 μs** | **30.95 μs** | **16.19 μs** | **31.2500** | **630.01 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 10000 | 4,116.5 μs | 18.47 μs | 10.99 μs |       - |  160.2 KB |
