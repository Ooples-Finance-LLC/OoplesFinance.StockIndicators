import argparse,gzip,importlib.util,json,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('repo',type=Path);p.add_argument('tooling',type=Path);p.add_argument('out',type=Path);a=p.parse_args()
state=json.loads((a.out/'status.json').read_text());assert state['status']=='gpu-complete-awaiting-ci-finalization'
origin=state['build_origin'];run=origin['run_id']
actual=json.loads(subprocess.check_output(['gh','run','view',run,'--repo','Ooples-Finance-LLC/OoplesFinance.StockIndicators','--json','status,conclusion,headSha']))
assert actual==dict(status='completed',conclusion='success',headSha=origin['workflow_head'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=a.repo,text=True).strip()==state['source']
helper=a.tooling/'scripts/build-candidate-correctness.py';spec=importlib.util.spec_from_file_location('ci_inputs',helper);ci=importlib.util.module_from_spec(spec);spec.loader.exec_module(ci)
assert helper.read_bytes().replace(b'\r\n',b'\n')==subprocess.check_output(['git','show',origin['workflow_head']+':scripts/build-candidate-correctness.py'],cwd=a.repo)
manifest=json.loads((a.out/'ci-manifest.json').read_text());assert manifest['run_id']==run and manifest['source']==state['source'] and manifest['workflow_head']==origin['workflow_head']
assert all(ci.digest(a.repo/name)==sha for name,sha in manifest['runtime_files'].items())
gpu=ci.gpu_module(a.repo);fingerprint=gpu.source_fingerprint(a.repo)
receipt=json.loads((gpu.EVIDENCE/'receipt.json').read_text());trx=gzip.decompress((gpu.EVIDENCE/'gpu.trx.gz').read_bytes())
gpu.verify_evidence(receipt,trx,json.loads(gpu.METHODS.read_text()),fingerprint)
assert receipt['build_origin']==origin and receipt['passed_cases']==100
sys.path.insert(0,str(a.repo/'scripts'));from hosted_timing.pipeline import verify_trx
for name in ('unit','parity'):
 checks=verify_trx(a.out/name/(name+'.trx'),manifest['classes'][name]);assert checks==state[name]==manifest['checks'][name]
(a.out/'final-workflow-state.json').write_bytes((json.dumps(actual,indent=2)+'\n').encode())
state['status']='correctness-complete';state['workflow_finalization_note']='Successful immutable producer job used for actual GPU verification while aggregate run finalized; final workflow success now independently confirmed, all runtime hashes/source/TRX/GPU evidence reverified without duplicate GPU execution.'
(a.out/'status.json').write_bytes((json.dumps(state,indent=2)+'\n').encode());print(state['status'],state['unit']['passed'],state['parity']['passed'],'GPU100')
