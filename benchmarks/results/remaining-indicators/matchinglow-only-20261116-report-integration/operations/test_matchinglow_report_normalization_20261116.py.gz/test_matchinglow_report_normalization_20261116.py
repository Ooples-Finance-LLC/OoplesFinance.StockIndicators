"""Small pure normalization/preservation fixtures; no browser, source build or main calls."""
import copy
import importlib.util
import json
from pathlib import Path
import unittest

spec=importlib.util.spec_from_file_location('matchinglow_stage',Path(__file__).with_name('stage-matchinglow-report-20261116.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
RUN='44123456789'


def dataset():
    rows=[]
    for pair in sorted(m.PAIRS):
        for bars in (1000,10000):
            row=dict(pair=pair,bars=bars,source_sha=m.SOURCE,measurement_run_id=RUN,
                measurement_run_url='https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/'+RUN,
                ooples_mean_ns=17.25,competitor_mean_ns=23.5,raw={'Ooples':{'samples':[17,17.5],'host':{'cpu':'unchanged'}}},
                production_optimization=False,production_assembly_sha256='old-core',canonical_gpu_source_sha='old-source',
                canonical_gpu_receipt_sha256='old-gpu',measurement_kind='harness-baseline-refresh',baseline_refresh_reason='old',
                harness_changed=False,same_binary_verdict='inconclusive',native_round_classifications=['loss']*4,
                native_consensus='loss',native_control_round=2,native_control_count=1)
            rows.append(row)
    rows.extend(dict(pair='Unchanged.'+str(i),bars=1000,source_sha='old',value=i) for i in range(796))
    return dict(rows=rows,evidence={'harnessBaselineRefreshes':[{'run_id':'old-history','pairs':['TaLib.Candles.SeparatingLines']}]})


def document(data,builders):
    return ''.join('<script id="'+name+'" type="application/json">'+json.dumps(value)+'</script>' for name,value in (
        ('dataset',data),('current-competitor-data',builders),('archived-baseline-dataset',{'historical':'unchanged'})))


def fixture():
    staged=dataset();before=copy.deepcopy(staged)
    for row in before['rows'][:6]:row.update(source_sha='old',measurement_run_id='old')
    target=[dict(pair=pair,bars=bars,mode=mode,native={'NativeSingle':{'mean_ns':2},'NativeParallel':{'mean_ns':3}},ooples={'mean_ns':1})
        for pair,bars in sorted(m.KEYS) for mode in ('BuilderFull','BuilderLatestOnly')]
    outside=[dict(pair='Other.'+str(i),bars=1000,mode='BuilderFull',native={'NativeSingle':{},'NativeParallel':{}},ooples={'mean_ns':i}) for i in range(1532)]
    old=dict(receipts=[dict(source_sha='old',run_id='old',comparisons=target+outside)])
    new=dict(receipts=[dict(source_sha=m.SOURCE,run_id=RUN,comparisons=copy.deepcopy(target)),dict(source_sha='old',run_id='old',comparisons=copy.deepcopy(outside))])
    return document(before,old),document(m.normalize_dataset(staged,RUN),new)


class MatchingLowNormalizationTests(unittest.TestCase):
    def test_normalizes_only_six_rows_and_preserves_numeric_raw_and_history(self):
        source=dataset();unchanged=copy.deepcopy(source);result=m.normalize_dataset(source,RUN)
        self.assertEqual(unchanged,source)
        self.assertEqual(source['evidence'],result['evidence'])
        self.assertEqual(source['rows'][6:],result['rows'][6:])
        for old,new in zip(source['rows'][:6],result['rows'][:6],strict=True):
            self.assertEqual(old['raw'],new['raw']);self.assertEqual(old['ooples_mean_ns'],new['ooples_mean_ns'])
            self.assertEqual(m.CORE,new['production_assembly_sha256']);self.assertEqual(m.GPU,new['canonical_gpu_receipt_sha256'])
            self.assertFalse((m.OBSOLETE-set(m.FRESH))&new.keys())
            self.assertEqual(new['pair']=='TaLib.Candles.MatchingLow',new['production_optimization'])

    def test_rejects_missing_duplicate_or_wrong_run_target_rows(self):
        for kind in ('missing','duplicate','run'):
            with self.subTest(kind=kind):
                data=dataset()
                if kind=='missing':del data['rows'][0]
                elif kind=='duplicate':data['rows'].append(copy.deepcopy(data['rows'][0]))
                else:data['rows'][0]['measurement_run_id']='wrong'
                with self.assertRaises(AssertionError):m.normalize_dataset(data,RUN)

    def test_accepts_exact_six_and_twelve_change_boundary(self):
        before,after=fixture()
        self.assertEqual(dict(changed_baseline_rows=6,unchanged_baseline_rows=796,changed_builder_comparisons=12,unchanged_builder_comparisons=1532),m.validate_preservation(before,after,RUN))
        local={'input_provenance_sha256':'verified-input','native_crossover_samples':{0:{'Ooples':{'mean_ns':17.25}}}}
        serialized=json.loads(json.dumps(local))
        self.assertEqual(serialized,m.verify_collected_result(local,serialized,copy.deepcopy(serialized),'verified-input'))
        changed=copy.deepcopy(serialized)
        changed['native_crossover_samples']['0']['Ooples']['mean_ns']=17.5
        with self.assertRaises(AssertionError):m.verify_collected_result(local,changed,changed,'verified-input')
        with self.assertRaises(AssertionError):m.verify_collected_result(local,serialized,serialized,'different-input')

    def test_rejects_outside_baseline_or_builder_change_and_stale_core(self):
        before,after=fixture()
        for kind in ('baseline','builder','core'):
            with self.subTest(kind=kind):
                data=m.embedded(after,'dataset');builders=m.embedded(after,'current-competitor-data')
                if kind=='baseline':data['rows'][6]['value']=-1
                elif kind=='builder':builders['receipts'][1]['comparisons'][0]['ooples']['mean_ns']=-1
                else:data['rows'][0]['production_assembly_sha256']='old-core'
                with self.assertRaises(AssertionError):m.validate_preservation(before,document(data,builders),RUN)


if __name__=='__main__':unittest.main()
