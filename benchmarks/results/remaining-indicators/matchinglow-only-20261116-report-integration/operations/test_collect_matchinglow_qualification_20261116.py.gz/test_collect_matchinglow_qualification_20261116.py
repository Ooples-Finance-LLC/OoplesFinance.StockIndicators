"""Tiny synthetic-only collector defenses; no remote access or production runtime."""
import importlib.util
import io
import tempfile
import unittest
import zipfile
from pathlib import Path
spec=importlib.util.spec_from_file_location('collector',Path(__file__).with_name('collect-matchinglow-qualification-20261116.py'))
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)

class CollectorTests(unittest.TestCase):
    def test_member_paths_and_aliases(self):
        for names in [('a/../b',),('C:/bad',),('a\\b',),('CON.txt',),('file','FILE')]:
            with self.subTest(names=names):
                stream=io.BytesIO()
                with zipfile.ZipFile(stream,'w') as p:
                    for name in names:
                        item=zipfile.ZipInfo('placeholder');item.filename=name
                        p.writestr(item,b'x')
                with zipfile.ZipFile(stream) as p,self.assertRaises(AssertionError):c.members(p)
    def test_preflight_source_and_assembly_evidence(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);stream=io.BytesIO()
            names=['matchinglow-inputs/consumer-preflight/jit/bounded-windows-source.cs',
                'matchinglow-inputs/consumer-preflight/jit/adjudicated-bodies/FillBoundedWindow.asm',
                'matchinglow-inputs/consumer-preflight/source-change.patch']
            with zipfile.ZipFile(stream,'w') as p:
                for name in names:p.writestr(name,b'proof')
            original=c.reserve
            try:
                c.reserve=lambda *args:None
                with zipfile.ZipFile(stream) as p:
                    rows=c.extract_text(p,c.members(p),set(names),root)
                self.assertEqual(len(rows),3)
            finally:c.reserve=original
    def test_fresh_links_preserve_original_and_reject_overwrite(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);source=root/'source';target=root/'target';source.write_bytes(b'exact')
            sha=c.digest(source);self.assertEqual(c.link_verified(source,target,sha),'hardlink')
            self.assertEqual(target.read_bytes(),b'exact')
            with self.assertRaises(AssertionError):c.link_verified(source,target,sha)
            self.assertEqual(c.digest(source),sha)
    def test_rejected_summary_retained(self):
        result=dict(case_count=90,decision_count=18,accepted=False,native_crossover_gate_passed=False,
            production_integrated=False,report_imported=False)
        self.assertEqual(c.check_summary(result,dict(result)),result)
        with self.assertRaises(AssertionError):c.check_summary(result,dict(result,accepted=True))
        with self.assertRaises(AssertionError):c.check_summary(dict(result,accepted=True),dict(result,accepted=True))
    def test_round_keys_use_exact_json_representation(self):
        result=dict(case_count=90,decision_count=18,accepted=False,native_crossover_gate_passed=False,
            production_integrated=False,report_imported=False,native_crossover_samples={0:{'mean_ns':123.5}})
        hosted=dict(result,native_crossover_samples={'0':{'mean_ns':123.5}})
        self.assertEqual(c.check_summary(result,hosted),hosted)
        with self.assertRaises(AssertionError):
            c.check_summary(result,dict(hosted,native_crossover_samples={'0':{'mean_ns':123.6}}))
    def test_archived_snapshots_exact_and_wrong_core(self):
        import hashlib
        h=lambda raw:hashlib.sha256(raw).hexdigest()
        core='OoplesFinance.StockIndicators.dll'
        common={core:h(b'common-core'),'dependency.dll':h(b'dependency')}
        proof=dict(common_manifest=common,production_sha256=dict(old=h(b'old-core'),successor=h(b'new-core')))
        by_sha={sha:None for sha in [*common.values(),*proof['production_sha256'].values()]}
        for corruption in (False,True):
            stream=io.BytesIO()
            with zipfile.ZipFile(stream,'w') as p:
                for label in ('old','new'):
                    prefix='matchinglow-qualification/evidence/shard0-runtime-'+label+'/'
                    p.writestr(prefix+'dependency.dll',b'dependency')
                    raw=(label+'-core').encode()
                    p.writestr(prefix+core,b'WRONG' if corruption and label=='new' else raw)
            with zipfile.ZipFile(stream) as p:
                if corruption:
                    with self.assertRaises(AssertionError):c.archived_snapshots(p,c.members(p),proof,by_sha)
                else:
                    result=c.archived_snapshots(p,c.members(p),proof,by_sha)
                    self.assertEqual(set(result),{'old','new'})
                    self.assertEqual(result['new']['files'][core],h(b'new-core'))
    def test_runtime_bytes_checked_before_materialization(self):
        import json
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);base=root/'base';candidate=root/'candidate';base.mkdir();candidate.mkdir()
            (base/'common').mkdir();(base/'production').mkdir()
            harness='OoplesFinance.StockIndicators.CompetitorBenchmarks.dll'
            core='OoplesFinance.StockIndicators.dll'
            names=[harness,core]+['dependency'+str(i)+'.dll' for i in range(92)]
            for name in names:(base/'common'/name).write_bytes(b'valid')
            h=c.digest(base/'common'/harness)
            for name in ('old','successor'):(base/'production'/(name+'.dll')).write_bytes(b'valid')
            proof=dict(common_manifest={name:h for name in names},production_sha256=dict(old=h,successor=h))
            c.write(base/'provenance.json',proof)
            cpu=dict(source=c.SOURCE,run_id='43984038209',workflow_head=c.CPU_PRODUCER,runtime_files={})
            archive=root/'input.zip';out=root/'out'
            with zipfile.ZipFile(archive,'w') as p:
                p.writestr('matchinglow-inputs/provenance.json',json.dumps(proof))
                p.writestr('matchinglow-qualification/summary.json','{}')
                for name in names:
                    p.writestr('matchinglow-inputs/common/'+name,b'CORRUPTED' if name==harness else b'valid')
                    for label in ('old','new'):
                        p.writestr('matchinglow-qualification/evidence/shard0-runtime-'+label+'/'+name,b'valid')
                for name in ('old','successor'):p.writestr('matchinglow-inputs/production/'+name+'.dll',b'valid')
                p.writestr('matchinglow-inputs/baseline-authentication/common/'+harness,b'valid')
                p.writestr('matchinglow-inputs/candidate-authentication/blobs/'+h,b'valid')
            with self.assertRaises(AssertionError):c.reconstruct(archive,out,base,candidate,cpu)
            self.assertFalse(out.exists())

if __name__=='__main__':unittest.main()
