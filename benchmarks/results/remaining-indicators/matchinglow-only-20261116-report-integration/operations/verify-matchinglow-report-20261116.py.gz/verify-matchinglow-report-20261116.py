"""Verify normalized MatchingLow report using the pinned complete browser/CSV checks."""
import argparse
import ast
import csv
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import re

OPS=Path(r'C:\Users\cheat\source\stock-indicators-operations')
BROWSER_HELPER=OPS/'verify-current-baseline-ten-report-20261116.py'
BROWSER_HELPER_SHA='eb07c2fb1023fc870fe46fd565a407dedd2e9dc25950770cd79e3073847acc87'


def load_stage():
    path=OPS/'stage-matchinglow-report-20261116.py'
    spec=importlib.util.spec_from_file_location('matchinglow_stage',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args();out=args.out.resolve();m=load_stage()
    normalization=m.read(out/'normalization-receipt.json');stage=m.read(out/'staged.json');measurement=m.read(out/'measurement.json')
    run=str(normalization['run_id']);report=out/'candidate.html'
    assert run==m.RUN and normalization['tooling_head']==m.TOOLING and normalization['plan_sha256']==m.PLAN_SHA
    assert normalization['stage_wrapper_sha256']==m.digest(OPS/'stage-matchinglow-report-20261116.py')
    assert m.digest(report)==normalization['candidate_sha256']==stage['candidate_sha256']
    assert m.digest(out/'before.html')==normalization['before_sha256']==stage['before_sha256']==m.BEFORE_SHA
    assert measurement['source_sha']==normalization['source']==m.SOURCE and str(measurement['run_id'])==run
    assert not (out/'browser-verification.json').exists(), 'Fresh browser verification required'
    document=report.read_text(encoding='utf-8');before=(out/'before.html').read_text(encoding='utf-8')
    preservation=m.validate_preservation(before,document,run)
    data=m.embedded(document,'dataset');summary=[]
    for library in sorted({r['library'] for r in data['rows']}):
        for bars in (1000,10000):
            rows=[r for r in data['rows'] if r['library']==library and r['bars']==bars]
            lower=sum(r['competitor_over_ooples']>1 for r in rows);higher=sum(r['competitor_over_ooples']<1 for r in rows)
            summary.append(dict(library=library,bars=bars,comparisons=len(rows),lower=lower,higher=higher,equal=len(rows)-lower-higher))
    assert m.digest(BROWSER_HELPER)==BROWSER_HELPER_SHA
    tree=ast.parse(BROWSER_HELPER.read_text(encoding='utf-8'))
    blocks=[node for node in tree.body if isinstance(node,ast.With) and len(node.items)==1
        and isinstance(node.items[0].context_expr,ast.Call) and isinstance(node.items[0].context_expr.func,ast.Name)
        and node.items[0].context_expr.func.id=='sync_playwright']
    assert len(blocks)==1, 'Pinned browser helper shape changed'
    from playwright.sync_api import sync_playwright
    context=dict(sync_playwright=sync_playwright,Path=Path,csv=csv,io=io,re=re,json=json,
        report=report,out=out,document=document,data=data,summary=summary,pairs=m.PAIRS,
        new_source=m.SOURCE,EXPECTED_RUN=run,expected_run=run)
    # Execute the exact already-reviewed full browser block, never its baseline-only setup.
    module=ast.Module(body=blocks,type_ignores=[]);ast.fix_missing_locations(module)
    exec(compile(module,str(BROWSER_HELPER),'exec'),context)
    exported=context['exported'];index={(r['pair'],int(r['bars'])):r for r in exported}
    assert len(index)==len(exported)==802
    for key in m.KEYS:
        row=index[key];actual=m.index_rows(data['rows'])[key]
        for name,value in m.FRESH.items():assert row[name]==str(value),(key,name,row[name],value)
        assert row['qualification_role']==actual['qualification_role']
        assert row['production_optimization'].lower()==str(actual['production_optimization']).lower()
        for name in m.OBSOLETE-set(m.FRESH):assert not row.get(name),(key,name,row.get(name))
        assert row['source_sha']==m.SOURCE and row['measurement_run_id']==run
    assert m.digest(report)==normalization['candidate_sha256'], 'Browser must not mutate report'
    screenshots={name:m.digest(out/name) for name in ('refreshed-baseline.png','updated-pair-details.png')}
    receipt=dict(kind='matchinglow-qualified-source-report-browser-verification',source=m.SOURCE,run_id=run,
        report_sha256=m.digest(report),comparisons=802,displayed_table_comparisons=len(context['table_keys']),
        exported_comparisons=len(exported),builder_comparisons=1544,**preservation,
        javascript_errors=context['errors'],hosted_provenance_verified=True,fresh_qualified_metadata_verified=True,
        updated_baseline_keys=sorted(m.KEYS),summary=summary,screenshots=screenshots,
        reused_browser_helper_sha256=BROWSER_HELPER_SHA,normalization_receipt_sha256=m.digest(out/'normalization-receipt.json'),
        verifier_sha256=m.digest(Path(__file__)),screenshot_review_pending=True,report_imported=False)
    m.write(out/'browser-verification.json',receipt)
    print(json.dumps(receipt))


if __name__=='__main__':main()
