"""Package the imported MatchingLow report/evidence; never import, commit or push."""
import argparse
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess

OPS=Path(r'C:\Users\cheat\source\stock-indicators-operations')
BACKUP=Path(r'Z:\StockIndicators-Archives\active-operations\matchinglow-only-20261116')
REPORT_OUT=OPS/'active-performance-evidence/matchinglow-report-publication-20261116'
COLLECTION=OPS/'active-performance-evidence/hosted-runs/43992359476'
RUN='43992359476'
TOOLING='fab5e0179feee36f3e0d9205dd0323d1b1e9c2f7'
SOURCE='a1f0028c601e1c6e7be5eabfe0d5da5cfe1f0758'
QUALIFIED='a921574e878c82392a6ce26122f5f2adaa2f430e'
REPORT='9dc3d9b721dfaed8f114b6cc5d680d71b726598331236f9a51e0b541d4f81e11'
NAME='matchinglow-only-20261116'


def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def atomic(path,raw):
    path.parent.mkdir(parents=True,exist_ok=True);temporary=path.with_name(path.name+'.package.tmp')
    assert not temporary.exists()
    with temporary.open('xb') as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
    os.replace(temporary,path)
def save(path,value):atomic(path,(json.dumps(value,indent=2)+'\n').encode())


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--check-only',action='store_true');args=parser.parse_args()
    state=read(OPS/'continuation-latest-20261028.json');q=state['performance_continuation_20261103'][NAME]
    assert q['qualification_run']==RUN and q['tooling']==TOOLING and q['source']==SOURCE and q['qualified_source']==QUALIFIED
    publisher=Path(state['publishing_checkout']).resolve()
    git=lambda *argv:subprocess.check_output(['git',*argv],cwd=publisher,text=True).strip()
    assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
    assert not git('diff',SOURCE,'HEAD','--','src','tests')
    gpu_paths=['benchmarks/results/shared-rollout/local-gpu-contracts/receipt.json','benchmarks/results/shared-rollout/local-gpu-contracts/gpu.trx.gz']
    assert not git('diff',QUALIFIED,'HEAD','--',*gpu_paths)
    spec=importlib.util.spec_from_file_location('matchinglow_stage',OPS/'stage-matchinglow-report-20261116.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    report=REPORT_OUT
    imported,browser,staged,normal,visual=[read(report/name) for name in ('imported.json','browser-verification.json','staged.json','normalization-receipt.json','parent-visual-review.json')]
    assert str(imported['run_id'])==str(browser['run_id'])==str(normal['run_id'])==RUN
    assert imported['candidate_sha256']==staged['candidate_sha256']==normal['candidate_sha256']==browser['report_sha256']==visual['candidate_sha256']==REPORT
    assert digest(report/'candidate.html')==digest(Path(r'C:\Users\cheat\Documents\OoplesFinance-Reports\competitor-performance.html'))==REPORT
    assert visual['visual_review_passed'] and all(digest(report/name)==sha for name,sha in visual['screenshots'].items())
    assert browser['fresh_qualified_metadata_verified'] and browser['hosted_provenance_verified'] and not browser['javascript_errors']
    assert browser['comparisons']==browser['displayed_table_comparisons']==browser['exported_comparisons']==802
    assert browser['builder_comparisons']==1544 and browser['unchanged_builder_comparisons']==1532
    before=(report/'before.html').read_text(encoding='utf-8');after=(report/'candidate.html').read_text(encoding='utf-8')
    assert m.validate_preservation(before,after,RUN)==dict(changed_baseline_rows=6,unchanged_baseline_rows=796,changed_builder_comparisons=12,unchanged_builder_comparisons=1532)
    assert (imported['changed_baseline_rows'],imported['unchanged_rows'],imported['replaced_builder_slots'],imported['added_builder_slots'])==(6,796,12,0)
    summary=read(COLLECTION/'independently-collected.json');collector=read(COLLECTION/'collection-receipt.json')
    assert summary['accepted'] and summary['native_crossover_gate_passed'] and (summary['case_count'],summary['decision_count'])==(90,18)
    assert summary['verdicts'].get('slower',0)==0 and summary['verdicts'].get('faster',0)>=1
    assert collector['status']=='verified' and collector['local_hosted_collection_equal'] and collector['protected_baseline_unchanged'] and collector['protected_candidate_unchanged']
    assert collector['run_id']==RUN and collector['tooling_head']==TOOLING and collector['accepted'] and collector['native_crossover_gate_passed']
    assert normal['verified_result_sha256']==digest(COLLECTION/'independently-collected.json')
    assert collector['collector_sha256']==digest(OPS/'collect-matchinglow-qualification-20261116.py')
    review=read(OPS/'matchinglow-report-normalization-review-receipt-20261116.json')
    assert review['verification']['passed']==4 and review['verification']['failed']==0
    assert all(digest(OPS/name)==sha for name,sha in review['files'].items())
    assert normal['stage_wrapper_sha256']==digest(OPS/'stage-matchinglow-report-20261116.py') and browser['verifier_sha256']==digest(OPS/'verify-matchinglow-report-20261116.py')
    correctness=BACKUP/'correctness';gpu=read(correctness/'actual-local-gpu-receipt.json');jit=read(BACKUP/'jit-v2/jit-adjudication.json')
    assert gpu['passed_cases']==100 and gpu['source_sha256']==m.FINGERPRINT and digest(correctness/'actual-local-gpu-receipt.json')==m.GPU
    assert jit['source']==SOURCE and jit['production_sha256']==m.CORE and jit['jit_gate_passed'] and jit['parent_reviewed'] and jit['independent_peer_reviewed']
    existing=publisher/'benchmarks/results/remaining-indicators'/('hosted-targeted-'+RUN+'-attempt1')
    decision=read(existing/'decision.json');assert decision['run_id']==RUN and decision['accepted'] and decision['native_crossover_gate_passed']
    assert read(existing/'verified-summary.json')==summary
    destination=publisher/'benchmarks/results/remaining-indicators'/(NAME+'-report-integration');assert not destination.exists()
    names=('before.html','candidate.html','measurement.json','normalization-receipt.json','staged.json','browser-verification.json','imported.json','parent-visual-review.json','refreshed-baseline.png','updated-pair-details.png')
    blobs={name:report/name for name in names}
    if (report/'browser.log').exists():blobs['browser.log']=report/'browser.log'
    for name in ('stage-matchinglow-report-20261116.py','verify-matchinglow-report-20261116.py','test_matchinglow_report_normalization_20261116.py','matchinglow-report-normalization-review-receipt-20261116.json','collect-matchinglow-qualification-20261116.py','test_collect_matchinglow_qualification_20261116.py',Path(__file__).name):blobs['operations/'+name]=OPS/name
    for name in ('collection-receipt.json','independently-collected.json'):blobs['collection/'+name]=COLLECTION/name
    for name in ('status.json','ci-manifest.json','actual-local-gpu-receipt.json'):blobs['proofs/correctness/'+name]=correctness/name
    for name in ('jit-adjudication.json','jit-proof.json'):blobs['proofs/jit/'+name]=BACKUP/'jit-v2'/name
    assert all(path.is_file() and path.suffix.lower() not in ('.dll','.exe','.pdb','.zip') for path in blobs.values())
    rows=m.embedded(after,'dataset')['rows'];wins={str(size):sum(r['bars']==size and r['competitor_over_ooples']>1 for r in rows) for size in (1000,10000)}
    assert wins=={'1000':196,'10000':238}
    raw_bytes=sum(path.stat().st_size for path in blobs.values());budget=2*raw_bytes+128*1024**2;free=shutil.disk_usage(publisher).free
    assert free>budget,('Insufficient bounded package space',free,budget)
    if args.check_only:
        print(json.dumps(dict(check_only=True,destination=str(destination),files=len(blobs),report_sha256=REPORT,report_wins=wins,required_free_bytes=budget)));return
    destination.mkdir();atomic(destination/'.gitattributes',b'* -text\n');manifest={}
    for name,path in sorted(blobs.items()):
        raw=path.read_bytes();target=destination/(name+'.gz');atomic(target,gzip.compress(raw,mtime=0))
        assert gzip.decompress(target.read_bytes())==raw
        manifest[name]=dict(sha256=hashlib.sha256(raw).hexdigest(),archive=target.relative_to(publisher).as_posix())
    save(destination/'manifest.json',manifest)
    references={key:value for key,value in decision['archives'].items() if key.startswith('prepared/consumer-preflight/') or key in ('prepared/evidence/successor-original-gpu-receipt.json','prepared/evidence/successor-original-gpu-gpu.trx.gz')}
    save(destination/'proof-references.json',dict(qualification_archive=existing.relative_to(publisher).as_posix(),archived_source_bound_proofs=references,gpu_source=SOURCE,gpu_receipt_sha256=m.GPU,jit_original_parser_preserved=True,jit_gate_accepted_by_separate_adjudication=True))
    packaging=dict(status='qualified-source-report-integration-packaged',run_id=RUN,tooling_head=TOOLING,source=SOURCE,qualified_source=QUALIFIED,report_sha256=REPORT,imported_json_sha256=digest(report/'imported.json'),browser_receipt_sha256=digest(report/'browser-verification.json'),changed_baseline_rows=6,unchanged_baseline_rows=796,replaced_builder_comparisons=12,unchanged_builder_comparisons=1532,report_point_wins=wins,mixed_historical_point_gaps_10000=163,full_current_gap_count_established=False,qualified_matchinglow_native_crossover=True,qualified_source_closures=1,published_source_optimization_credit=0,overall_goal_complete=False,package_source_raw_bytes=raw_bytes,required_free_bytes=budget,available_free_bytes_at_start=free,committed=False,pushed=False)
    save(destination/'packaging.json',packaging)
    decision.update(production_integrated=True,report_imported=True,report_sha256=REPORT,report_archive=destination.relative_to(publisher).as_posix());save(existing/'decision.json',decision)
    latest=read(OPS/'continuation-latest-20261028.json');own=latest['performance_continuation_20261103'][NAME]
    assert own['qualification_run']==RUN and own['source']==SOURCE
    own.update(accepted=True,report_imported=True,report_sha256=REPORT,report_out=str(report),report_archive=str(destination),report_wins=wins,mixed_historical_point_gaps_10000=163,full_current_gap_count_established=False,source_optimization_credit=0,status='Accepted MatchingLow source/report evidence packaged; parent commit/publication pending')
    checkpoint_raw=(json.dumps(latest,indent=2)+'\n').encode()
    atomic(BACKUP/'continuation-latest-20261028.json',checkpoint_raw);atomic(OPS/'continuation-latest-20261028.json',checkpoint_raw)
    save(BACKUP/'matchinglow-report-packaging-20261116.json',packaging)
    print(json.dumps(packaging))


if __name__=='__main__':main()
