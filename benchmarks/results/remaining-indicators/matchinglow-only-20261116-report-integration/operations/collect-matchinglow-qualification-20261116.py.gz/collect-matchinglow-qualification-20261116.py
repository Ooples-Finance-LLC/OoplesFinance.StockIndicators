"""Collect the pinned MatchingLow qualification; preserve accepted and rejected evidence."""
import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import zipfile

OPS = Path(r'C:\Users\cheat\source\stock-indicators-operations')
BASELINE = OPS/'active-performance-evidence/hosted-runs/43880487485/inputs'
ARCHIVES = Path(r'Z:\StockIndicators-Archives\hosted-runs-20261116')
NETWORK_OUTPUTS = Path(r'Z:\StockIndicators-Archives\active-performance-evidence\hosted-runs')
REMOTE = 'Ooples-Finance-LLC/OoplesFinance.StockIndicators'
PLAN = 'benchmarks/plans/hosted-matchinglow-only-grid-20261116.json'
APPROVED_RUN = '43992359476'
APPROVED_HEAD = 'fab5e0179feee36f3e0d9205dd0323d1b1e9c2f7'
PLAN_SHA = 'a60bd3a6efce56b1d56e168e34ebb40d88e7b17b2c980a20fcf50166801819c0'
CANDIDATE = Path(r'C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-matchinglow-only-20261116')
CPU_MANIFEST = Path(r'Z:\StockIndicators-Archives\active-operations\matchinglow-only-20261116\correctness\ci-manifest.json')
SOURCE = 'a1f0028c601e1c6e7be5eabfe0d5da5cfe1f0758'
QUALIFIED_HEAD = 'a921574e878c82392a6ce26122f5f2adaa2f430e'
CPU_MANIFEST_SHA = 'f2541e7d0621187f35160c9fcd94627f7fc70169bd185a5a6bc73cae594c1508'
CPU_PRODUCER = '2a1737f30e5e1164189d0209b39ea46bf38c1239'
TEXT = {'.json', '.log', '.txt', '.csv', '.md', '.html', '.xml', '.trx', '.gz', '.py', '.ps1', '.cs', '.asm', '.patch'}
RESERVED = {'CON', 'PRN', 'AUX', 'NUL', 'CONIN$', 'CONOUT$',
    *(f'COM{i}' for i in range(1, 10)), *(f'LPT{i}' for i in range(1, 10)),
    *(p+n for p in ('COM', 'LPT') for n in ('\u00b9', '\u00b2', '\u00b3'))}


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, data):
    path=Path(path); temporary=path.with_name(path.name+'.new')
    with temporary.open('xb') as stream:
        stream.write((json.dumps(data,indent=2,allow_nan=False)+'\n').encode());stream.flush();os.fsync(stream.fileno())
    temporary.replace(path)


def members(package):
    result, aliases = {}, set()
    for info in package.infolist():
        assert info.orig_filename == info.filename, 'ZIP member spelling was normalized'
        name = info.filename.rstrip('/')
        parts = PurePosixPath(name)
        assert name and not parts.is_absolute() and '\\' not in name and '\0' not in name
        assert all(p not in ('', '.', '..') and p.rstrip(' .') == p
            and not any(c in p for c in ':<>"|?*') and p.split('.')[0].rstrip(' ').upper() not in RESERVED
            for p in name.split('/')), name
        assert not stat.S_ISLNK(info.external_attr >> 16), 'ZIP symlink'
        if info.is_dir():
            continue
        assert name.casefold() not in aliases, 'Duplicate/case-aliased ZIP member'
        aliases.add(name.casefold()); result[name] = info
    return result


def target(folder, name):
    path = (folder/name).resolve()
    assert path.is_relative_to(folder.resolve()) and path != folder.resolve()
    return path


def manifest(folder):
    return {p.relative_to(folder).as_posix(): digest(p) for p in folder.rglob('*') if p.is_file()}


def runtime_files(proof):
    return {'common/'+p: sha for p, sha in proof['common_manifest'].items()} | {
        'production/'+label+'.dll': sha for label, sha in proof['production_sha256'].items()}


def protected_snapshot(baseline):
    return {section+'/'+name: sha for section in ('common', 'production')
            for name, sha in manifest(baseline/section).items()}


def reserve(path, added_bytes=0):
    existing = path
    while not existing.exists():
        assert existing.parent != existing, 'Output drive/root unavailable'
        existing = existing.parent
    assert shutil.disk_usage(existing).free > 2*1024**3 + added_bytes, 'Below output-drive evidence reserve'


def same_volume(source, destination):
    return source.resolve().drive.casefold() == destination.resolve().drive.casefold()


def link_verified(source, destination, sha):
    assert source.is_file() and digest(source)==sha
    assert same_volume(source,destination), 'Runtime must be fresh C hardlinks'
    assert not destination.exists(), 'Never overwrite a runtime target'
    destination.parent.mkdir(parents=True,exist_ok=True)
    os.link(source,destination)
    assert digest(destination)==sha
    return 'hardlink'


def extract_text(package, entries, names, folder):
    records = []
    for name in sorted(names):
        assert Path(name).suffix.lower() in TEXT, 'Unexpected non-text/evidence member: '+name
        path = target(folder, name)
        assert not path.exists()
        path.parent.mkdir(parents=True, exist_ok=True)
        reserve(folder, entries[name].file_size)
        with package.open(entries[name]) as source, path.open('xb') as out:
            shutil.copyfileobj(source, out, 1024*1024)
        records.append(dict(path=name, sha256=digest(path), bytes=path.stat().st_size))
    return records



def checked_sources(baseline, candidate, cpu):
    original=json.loads((baseline/'provenance.json').read_text())
    baseline_before=protected_snapshot(baseline)
    assert baseline_before==runtime_files(original)
    assert cpu['source']==SOURCE and cpu['run_id']=='43984038209'
    assert cpu['workflow_head']==CPU_PRODUCER
    by_sha={}
    for name,sha in baseline_before.items():by_sha.setdefault(sha,baseline/name)
    candidate_before={}
    for name,sha in cpu['runtime_files'].items():
        path=target(candidate,name)
        assert digest(path)==sha, 'Installed candidate runtime changed: '+name
        candidate_before[name]=sha;by_sha.setdefault(sha,path)
    return original,baseline_before,candidate_before,by_sha


def archived_snapshots(package,entries,proof,by_sha):
    snapshots={}
    for label,production_label in [('old','old'),('new','successor')]:
        prefix='matchinglow-qualification/evidence/shard0-runtime-'+label+'/'
        expected=dict(proof['common_manifest'])
        expected['OoplesFinance.StockIndicators.dll']=proof['production_sha256'][production_label]
        actual={n[len(prefix):] for n in entries if n.startswith(prefix)}
        assert actual==set(expected), 'Unexpected/missing archived runtime snapshot: '+label
        for name,sha in expected.items():
            assert sha in by_sha and re.fullmatch('[a-f0-9]{64}',sha)
            with package.open(entries[prefix+name]) as stream:
                assert hashlib.file_digest(stream,'sha256').hexdigest()==sha,prefix+name
        snapshots[label]=dict(prefix=prefix,files=expected,retention='Authenticated full bytes retained in raw ZIP only; not materialized')
    return snapshots


def reconstruct(archive,out,baseline,candidate,cpu):
    original,before,candidate_before,by_sha=checked_sources(baseline,candidate,cpu)
    with zipfile.ZipFile(archive) as package:
        entries=members(package)
        assert 'matchinglow-inputs/provenance.json' in entries
        assert 'matchinglow-qualification/summary.json' in entries
        assert all(n.startswith(('matchinglow-inputs/','matchinglow-qualification/evidence/shard0/',
            'matchinglow-qualification/evidence/shard0-runtime-old/',
            'matchinglow-qualification/evidence/shard0-runtime-new/'))
            or n=='matchinglow-qualification/summary.json' for n in entries)
        proof=json.loads(package.read(entries['matchinglow-inputs/provenance.json']))
        assert len(proof['common_manifest'])==94
        snapshots=archived_snapshots(package,entries,proof,by_sha)
        snapshot_names={row['prefix']+n for row in snapshots.values() for n in row['files']}
        expected={'matchinglow-inputs/'+n:sha for n,sha in runtime_files(proof).items()}
        expected['matchinglow-inputs/baseline-authentication/common/OoplesFinance.StockIndicators.CompetitorBenchmarks.dll']=original['common_manifest']['OoplesFinance.StockIndicators.CompetitorBenchmarks.dll']
        for n in entries:
            if n.startswith('matchinglow-inputs/candidate-authentication/blobs/'):
                sha=n.rsplit('/',1)[1];assert re.fullmatch('[a-f0-9]{64}',sha)
                expected[n]=sha
        assert any('/candidate-authentication/blobs/' in n for n in expected)
        # Authenticate ALL archived runtime/blob bytes before creating any destination.
        for name,sha in expected.items():
            assert name in entries and re.fullmatch('[a-f0-9]{64}',sha)
            with package.open(entries[name]) as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==sha,name
            assert sha in by_sha, 'No verified local source for '+name
        assert not out.exists();out.mkdir(parents=True)
        records=extract_text(package,entries,set(entries)-set(expected)-snapshot_names,out)
        for name,sha in expected.items():link_verified(by_sha[sha],target(out,name),sha)
        assert all(digest(out/name)==sha for name,sha in expected.items())
    assert protected_snapshot(baseline)==before
    assert all(digest(candidate/name)==sha for name,sha in candidate_before.items())
    return before,candidate_before,records,snapshots


def verify_tooling(repo):
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==APPROVED_HEAD
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
    raw=subprocess.check_output(['git','show',APPROVED_HEAD+':'+PLAN],cwd=repo)
    assert (repo/PLAN).read_bytes()==raw and digest(repo/PLAN)==PLAN_SHA


def check_summary(result,hosted):
    # Compare the exact JSON representation written by the frozen CI producer.
    result=json.loads(json.dumps(result,allow_nan=False))
    assert result==hosted, 'Independent collection differs from hosted summary'
    assert (result['case_count'],result['decision_count'])==(90,18)
    assert type(result['accepted']) is bool and type(result['native_crossover_gate_passed']) is bool
    assert not result['accepted'] or result['native_crossover_gate_passed']
    assert result['production_integrated'] is False and result['report_imported'] is False
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args();repo=args.repo.resolve();out=args.out.resolve()
    assert out!=OPS.resolve() and out.is_relative_to(OPS.resolve())
    assert not out.exists() and not out.is_relative_to(BASELINE.resolve())
    assert not repo.is_relative_to(out) and not CANDIDATE.resolve().is_relative_to(out)
    verify_tooling(repo)
    plan=json.loads((repo/PLAN).read_text());assert (plan['cases'],plan['decisions'])==(90,18)
    def api(path):return json.loads(subprocess.check_output(['gh','api','repos/'+REMOTE+path]))
    run=api('/actions/runs/'+APPROVED_RUN)
    assert run['id']==int(APPROVED_RUN) and run['head_sha']==APPROVED_HEAD
    assert (run['status'],run['conclusion'])==('completed','success')
    artifacts=[];page=1
    while True:
        response=api(f'/actions/runs/{APPROVED_RUN}/artifacts?per_page=100&page={page}')
        artifacts+=response['artifacts']
        if len(artifacts)>=response['total_count']:break
        assert response['artifacts'];page+=1
    matches=[a for a in artifacts if a['name']=='matchinglow-grid-qualification' and not a['expired']]
    assert len(matches)==1;item=matches[0]
    assert ARCHIVES.is_dir()
    archive_root=(ARCHIVES/APPROVED_RUN).resolve();assert archive_root.is_relative_to(ARCHIVES.resolve())
    archive_root.mkdir(parents=True,exist_ok=True)
    archive=archive_root/f"matchinglow-grid-qualification-attempt{run['run_attempt']}-artifact{item['id']}.zip"
    sidecar=archive.with_suffix('.receipt.json')
    if archive.exists():
        receipt=json.loads(sidecar.read_text())
        assert receipt['run_id']==APPROVED_RUN and receipt['artifact']['id']==item['id']
        assert receipt['archive_sha256']==digest(archive)
    else:
        temporary=archive.with_suffix('.zip.download')
        with temporary.open('xb') as stream:
            subprocess.run(['gh','api',f"repos/{REMOTE}/actions/artifacts/{item['id']}/zip"],stdout=stream,check=True)
            stream.flush();os.fsync(stream.fileno())
        temporary.replace(archive)
    sha=digest(archive)
    if item.get('digest'):assert item['digest']=='sha256:'+sha
    receipt=dict(run_id=APPROVED_RUN,run_attempt=run['run_attempt'],tooling_head=APPROVED_HEAD,
        plan_sha256=PLAN_SHA,artifact=item,archive=str(archive),archive_sha256=sha)
    write(sidecar,receipt)
    reserve(out)
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=CANDIDATE,text=True).strip()==QUALIFIED_HEAD
    assert not subprocess.check_output(['git','diff','--name-only',SOURCE,QUALIFIED_HEAD,'--','src','tests',
        'benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks',
        'benchmarks/OoplesFinance.StockIndicators.CompetitorTests'],cwd=CANDIDATE)
    assert digest(CPU_MANIFEST)==CPU_MANIFEST_SHA
    cpu=json.loads(CPU_MANIFEST.read_text())
    before,candidate_before,selected,snapshots=reconstruct(archive,out,BASELINE,CANDIDATE,cpu)
    os.environ['HOSTED_TIMING_PLAN']=str(repo/PLAN);sys.path.insert(0,str(repo/'scripts'))
    p=importlib.import_module('hosted_timing.pipeline')
    q=importlib.import_module('hosted_timing.matchinglow_grid_qualification')
    assert p.REPO.resolve()==repo and p.PLAN.resolve()==(repo/PLAN).resolve()
    q.validate_scope(p.read(p.PLAN))
    inputs=out/'matchinglow-inputs';evidence=out/'matchinglow-qualification/evidence'
    proof=p.verify_inputs(inputs)
    assert proof['run_id']==APPROVED_RUN and proof['workflow_head']==APPROVED_HEAD and proof['plan_sha256']==PLAN_SHA
    result=check_summary(q.collect(evidence,inputs),p.read(out/'matchinglow-qualification/summary.json'))
    assert protected_snapshot(BASELINE)==before
    assert all(digest(CANDIDATE/name)==sha for name,sha in candidate_before.items())
    verify_tooling(repo)
    write(out/'independently-collected.json',result)
    write(out/'collection-receipt.json',dict(status='verified',run_id=APPROVED_RUN,tooling_head=APPROVED_HEAD,
        plan_sha256=PLAN_SHA,collector_sha256=digest(Path(__file__)),artifact=receipt,selected_files=selected,
        local_hosted_collection_equal=True,protected_baseline_unchanged=True,protected_candidate_unchanged=True,
        runtime_materialization='Fresh verified C hardlinks; every archived runtime byte hashed first',
        archived_runtime_snapshots=snapshots,
        cases=90,decisions=18,accepted=result['accepted'],native_crossover_gate_passed=result['native_crossover_gate_passed'],
        report_imported=False,source_imported=False,policy_changed=False))
    print(json.dumps(dict(run=APPROVED_RUN,cases=90,decisions=18,accepted=result['accepted'],
        native_crossover_gate_passed=result['native_crossover_gate_passed'])),flush=True)


if __name__=='__main__':main()
