"""Stage accepted MatchingLow qualification and normalize only its six report rows."""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

OPS=Path(r'C:\Users\cheat\source\stock-indicators-operations')
BASE='0005efc1d9e09ec1d008414323290050c142fc3b'
RUN='43992359476'
TOOLING='fab5e0179feee36f3e0d9205dd0323d1b1e9c2f7'
PLAN_SHA='a60bd3a6efce56b1d56e168e34ebb40d88e7b17b2c980a20fcf50166801819c0'
SOURCE='a1f0028c601e1c6e7be5eabfe0d5da5cfe1f0758'
HARNESS='9a45372530e49718b01b6524f9a0db993514e1e8'
CORE='4d571648599e567bb6df0cda1f823d79e95712241078c2ab1721cf7409c10173'
BENCH='48229494a1ff1e4e59bddd5a018cbd590cae24523d52dd2f3effdd20bd802723'
GPU='c41d3565f89350caceb25992e978ebbfb3c4f49f8bbad369f7c93d1794fd3bf2'
FINGERPRINT='b78614b84af822560e8b9ddfca5391c30576f4f38950fef4ee3ca8b1fed20007'
BEFORE_SHA='7b3ad6b8829afa29d2d9b86143b088bf66cc3b28a6411d318d821bd049d6d67b'
PAIRS={'TaLib.Candles.MatchingLow','TaLib.Candles.SeparatingLines','TaLib.Candles.StickSandwich'}
KEYS={(pair,bars) for pair in PAIRS for bars in (1000,10000)}
OBSOLETE={'measurement_kind','baseline_refresh_reason','harness_changed','same_binary_verdict',
    'native_round_classifications','native_consensus','native_control_round','native_control_count',
    'canonical_gpu_source_sha','canonical_gpu_receipt_sha256','production_assembly_sha256'}
FRESH=dict(measurement_kind='qualified-source-verification',production_assembly_sha256=CORE,
    canonical_gpu_source_sha=SOURCE,canonical_gpu_receipt_sha256=GPU,
    benchmark_source_sha=HARNESS,benchmark_assembly_sha256=BENCH)
TOUCHED=OBSOLETE|set(FRESH)|{'qualification_role','production_optimization'}


def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def atomic(path,raw):
    temporary=path.with_suffix(path.suffix+'.tmp');assert not temporary.exists()
    temporary.write_bytes(raw);os.replace(temporary,path)
def write(path,value):atomic(path,(json.dumps(value,indent=2)+'\n').encode())
def embedded(document,name):
    return json.loads(re.search(r'<script[^>]*id="'+name+r'"[^>]*>(.*?)</script>',document,re.S)[1])
def index_rows(rows):
    result={(r['pair'],r['bars']):r for r in rows};assert len(result)==len(rows)
    return result

def verify_collected_result(result,independent,hosted,input_sha):
    # JSON round labels are strings; normalize only the in-memory local result.
    canonical=json.loads(json.dumps(result,allow_nan=False))
    assert canonical==independent==hosted
    assert canonical['input_provenance_sha256']==input_sha
    return canonical

def normalize_dataset(dataset,run):
    result=copy.deepcopy(dataset);index=index_rows(result['rows'])
    assert KEYS <= index.keys()
    for key in KEYS:
        row=index[key];original=copy.deepcopy(row)
        assert row['source_sha']==SOURCE and str(row['measurement_run_id'])==str(run)
        assert row['measurement_run_url']=='https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/'+str(run)
        for name in OBSOLETE:row.pop(name,None)
        row.update(FRESH)
        target=key[0]=='TaLib.Candles.MatchingLow'
        row.update(qualification_role='optimization-target' if target else 'unchanged-consumer-sentinel',production_optimization=target)
        assert {k:v for k,v in row.items() if k not in TOUCHED}=={k:v for k,v in original.items() if k not in TOUCHED}
    return result

def builder_index(block):
    result={}
    for receipt in block['receipts']:
        metadata={k:v for k,v in receipt.items() if k!='comparisons'}
        for row in receipt['comparisons']:
            key=row['pair'],row['bars'],row['mode'];assert key not in result
            result[key]={**metadata,**row}
    return result

def validate_preservation(before,after,run):
    old=index_rows(embedded(before,'dataset')['rows']);new=index_rows(embedded(after,'dataset')['rows'])
    assert len(old)==len(new)==802 and old.keys()==new.keys()
    assert {key for key in old if old[key]!=new[key]}==KEYS
    for key in KEYS:
        row=new[key]
        assert row['source_sha']==SOURCE and str(row['measurement_run_id'])==str(run)
        assert all(row.get(k)==v for k,v in FRESH.items())
        assert not (OBSOLETE-set(FRESH)) & row.keys()
        target=key[0]=='TaLib.Candles.MatchingLow'
        assert row['production_optimization'] is target
        assert row['qualification_role']==('optimization-target' if target else 'unchanged-consumer-sentinel')
    old_builder=builder_index(embedded(before,'current-competitor-data'));new_builder=builder_index(embedded(after,'current-competitor-data'))
    builder_keys={(pair,bars,mode) for pair,bars in KEYS for mode in ('BuilderFull','BuilderLatestOnly')}
    assert len(old_builder)==len(new_builder)==1544 and old_builder.keys()==new_builder.keys()
    assert {key for key in old_builder if old_builder[key]!=new_builder[key]}==builder_keys
    for key in builder_keys:
        row=new_builder[key];assert row['source_sha']==SOURCE and str(row['run_id'])==str(run)
        assert set(row['native'])=={'NativeSingle','NativeParallel'}
    assert embedded(before,'dataset')['evidence'].get('harnessBaselineRefreshes')==embedded(after,'dataset')['evidence'].get('harnessBaselineRefreshes')
    assert embedded(before,'archived-baseline-dataset')==embedded(after,'archived-baseline-dataset')
    return dict(changed_baseline_rows=6,unchanged_baseline_rows=796,changed_builder_comparisons=12,unchanged_builder_comparisons=1532)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('tooling','raw','inputs','publisher','out','result','hosted-result'):parser.add_argument('--'+name,type=Path,required=True)
    for name in ('tooling-head','plan-sha','run'):parser.add_argument('--'+name,required=True)
    args=parser.parse_args();q=read(OPS/'continuation-latest-20261028.json')['performance_continuation_20261103']['matchinglow-only-20261116']
    assert args.run==RUN==q['qualification_run'] and args.tooling_head==TOOLING==q['tooling'] and args.plan_sha==PLAN_SHA==q['plan_sha256']
    assert re.fullmatch('[a-f0-9]{40}',args.tooling_head) and re.fullmatch('[a-f0-9]{64}',args.plan_sha) and args.run.isdigit()
    tooling=args.tooling.resolve();out=args.out.resolve();publisher=args.publisher.resolve()
    def git(repo,*parts):return subprocess.check_output(['git',*parts],cwd=repo,text=True).strip()
    assert git(tooling,'rev-parse','HEAD')==args.tooling_head and not git(tooling,'status','--porcelain')
    plan=tooling/q['plan'];assert digest(plan)==args.plan_sha
    assert plan.read_bytes()==subprocess.check_output(['git','show',args.tooling_head+':'+q['plan']],cwd=tooling)
    live=Path(r'C:\Users\cheat\Documents\OoplesFinance-Reports\competitor-performance.html')
    assert digest(live)==BEFORE_SHA and not out.exists()
    assert any(out.is_relative_to(root.resolve()) and out!=root.resolve() for root in (OPS,Path(r'Z:\StockIndicators-Archives\active-operations')))
    assert not git(publisher,'status','--porcelain')
    assert not git(publisher,'diff',SOURCE,'HEAD','--','src','tests')
    os.environ['HOSTED_TIMING_PLAN']=str(plan);sys.path.insert(0,str(tooling/'scripts'))
    from hosted_timing import pipeline as p,matchinglow_grid_qualification as qualification
    from hosted_timing.report import stage
    assert p.REPO.resolve()==tooling and p.PLAN.resolve()==plan.resolve()
    proof=p.verify_inputs(args.inputs.resolve());result=qualification.collect(args.raw.resolve())
    result=verify_collected_result(result,read(args.result),read(args.hosted_result),digest(args.inputs/'provenance.json'))
    assert result['accepted'] and result['native_crossover_gate_passed']
    assert (result['case_count'],result['decision_count'])==(90,18)
    assert result['verdicts'].get('slower',0)==0 and result['verdicts'].get('faster',0)>=1
    assert result['sources']=={'old':BASE,'new':SOURCE}
    assert str(proof['run_id'])==args.run and proof['workflow_head']==args.tooling_head and proof['plan_sha256']==args.plan_sha
    assert proof['production_sha256']['successor']==CORE and proof['common_manifest']['OoplesFinance.StockIndicators.CompetitorBenchmarks.dll']==BENCH
    assert proof['source_authentication']['candidate']['gpu_receipt_sha256']==GPU
    gpu=args.inputs/'evidence/successor-original-gpu-receipt.json';assert digest(gpu)==GPU
    gpu_receipt=read(gpu);assert gpu_receipt['source_sha256']==FINGERPRINT and gpu_receipt['passed_cases']==100 and gpu_receipt['build_origin']['source']==SOURCE
    candidate=stage(live,args.raw.resolve(),publisher,out,phase='targeted',inputs=args.inputs.resolve())
    document=candidate.read_text(encoding='utf-8');before=(out/'before.html').read_text(encoding='utf-8')
    unnormalized=embedded(document,'dataset');normalized=normalize_dataset(unnormalized,args.run)
    document,count=re.subn(r'(<script[^>]*id="dataset"[^>]*>).*?(</script>)',lambda m:m[1]+json.dumps(normalized,ensure_ascii=True).replace('<','\\u003c')+m[2],document,flags=re.S);assert count==1
    counts=validate_preservation(before,document,args.run)
    # A fresh output path ensures no pre-normalization browser receipt/screenshots can be reused.
    assert not (out/'browser-verification.json').exists()
    atomic(candidate,document.encode())
    staged=read(out/'staged.json')
    assert (staged['changed_baseline_rows'],staged['unchanged_baseline_rows'],staged['changed_builder_slots'],staged['replaced_builder_slots'],staged['added_builder_slots'])==(6,796,12,12,0)
    staged['candidate_sha256']=digest(candidate);write(out/'staged.json',staged)
    write(out/'normalization-receipt.json',dict(kind='matchinglow-qualified-row-normalization',run_id=args.run,source=SOURCE,
        candidate_sha256=digest(candidate),before_sha256=BEFORE_SHA,tooling_head=args.tooling_head,plan_sha256=args.plan_sha,
        verified_result_sha256=digest(args.result),hosted_result_sha256=digest(args.hosted_result),
        input_provenance_sha256=digest(args.inputs/'provenance.json'),gpu_receipt_sha256=GPU,production_sha256=CORE,
        fresh_fields=FRESH,removed_obsolete_fields=sorted(OBSOLETE-set(FRESH)),updated_keys=sorted(KEYS),
        stage_wrapper_sha256=digest(Path(__file__)),numeric_raw_run_fields_preserved=True,historic_refresh_records_preserved=True,
        **counts,browser_verification_pending=True,screenshot_review_pending=True,report_imported=False))
    assert digest(live)==BEFORE_SHA
    print(json.dumps(dict(candidate=str(candidate),candidate_sha256=digest(candidate),**counts,report_imported=False)))


if __name__=='__main__':main()
