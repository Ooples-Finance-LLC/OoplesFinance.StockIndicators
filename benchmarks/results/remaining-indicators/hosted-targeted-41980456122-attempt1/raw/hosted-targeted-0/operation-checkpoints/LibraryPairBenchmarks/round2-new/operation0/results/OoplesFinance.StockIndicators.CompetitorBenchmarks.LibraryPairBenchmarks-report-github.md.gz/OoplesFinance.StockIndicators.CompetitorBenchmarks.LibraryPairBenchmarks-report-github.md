```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)dline [22]** |   **948.8 μs** | **30.78 μs** | **18.31 μs** |  **1.00** |    **0.03** |  **222.91 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)dline [22] |   149.7 μs |  0.88 μs |  0.46 μs |  0.16 |    0.00 |  288.27 KB |        1.29 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)dline [22]** | **8,945.1 μs** | **27.37 μs** | **16.29 μs** |  **1.00** |    **0.00** | **2152.96 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)dline [22] | 1,497.1 μs | 26.56 μs | 13.89 μs |  0.17 |    0.00 | 2812.05 KB |        1.31 |
