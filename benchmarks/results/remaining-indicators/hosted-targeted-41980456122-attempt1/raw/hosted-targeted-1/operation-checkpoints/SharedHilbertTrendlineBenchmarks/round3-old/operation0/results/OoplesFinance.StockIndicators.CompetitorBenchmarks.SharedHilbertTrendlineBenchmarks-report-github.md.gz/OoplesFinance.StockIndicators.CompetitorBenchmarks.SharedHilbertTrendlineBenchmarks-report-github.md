```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  | **1,006.8 μs** | **25.89 μs** | **15.41 μs** |  **100.9 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  |   980.0 μs |  5.51 μs |  2.88 μs |  53.27 KB |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **9,677.7 μs** | **82.82 μs** | **43.32 μs** | **945.63 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 9,643.7 μs | 61.29 μs | 32.06 μs | 475.82 KB |
