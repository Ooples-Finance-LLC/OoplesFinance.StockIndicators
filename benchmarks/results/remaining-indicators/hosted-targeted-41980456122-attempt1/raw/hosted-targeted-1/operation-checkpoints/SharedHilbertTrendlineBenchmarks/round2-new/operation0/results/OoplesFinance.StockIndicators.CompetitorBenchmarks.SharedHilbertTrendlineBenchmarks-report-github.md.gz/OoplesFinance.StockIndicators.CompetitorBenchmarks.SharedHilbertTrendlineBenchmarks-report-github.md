```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  |   **980.9 μs** |  **59.92 μs** | **31.34 μs** |  **7.43** |    **0.23** |        **-** |        **-** |        **-** |   **100.9 KB** |        **0.49** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  |   959.3 μs |   9.76 μs |  5.81 μs |  7.26 |    0.06 |        - |        - |        - |   53.26 KB |        0.26 |
| NativeSingle      | Skend(...)dline [22] | 1000  |   132.1 μs |   1.43 μs |  0.75 μs |  1.00 |    0.01 |  12.6953 |   2.9297 |        - |  207.71 KB |        1.00 |
| NativeParallel    | Skend(...)dline [22] | 1000  |   203.0 μs |  18.59 μs | 12.29 μs |  1.54 |    0.09 |  33.2031 |  11.7188 |        - |  528.53 KB |        2.54 |
|                   |                      |       |            |           |          |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **9,369.3 μs** |  **40.72 μs** | **21.29 μs** |  **6.21** |    **0.13** |        **-** |        **-** |        **-** |  **945.57 KB** |        **0.46** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 9,515.4 μs |  94.49 μs | 56.23 μs |  6.30 |    0.14 |        - |        - |        - |  475.79 KB |        0.23 |
| NativeSingle      | Skend(...)dline [22] | 10000 | 1,510.3 μs |  51.33 μs | 33.95 μs |  1.00 |    0.03 | 179.6875 | 148.4375 |  78.1250 |  2071.7 KB |        1.00 |
| NativeParallel    | Skend(...)dline [22] | 10000 | 2,525.9 μs | 148.63 μs | 98.31 μs |  1.67 |    0.07 | 421.8750 | 328.1250 | 140.6250 | 5258.49 KB |        2.54 |
