```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------- |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Atan**      |  **9.644 μs** | **0.8930 μs** | **0.5314 μs** |  **3.4180** |  **0.4883** |  **56.77 KB** |
| BuilderLatestOnly | 1000  | Atan      |  6.951 μs | 0.1193 μs | 0.0624 μs |  0.5493 |       - |   9.16 KB |
| **BuilderFull**       | **10000** | **Atan**      | **80.075 μs** | **1.1692 μs** | **0.6958 μs** | **33.2031** | **13.6719** | **549.32 KB** |
| BuilderLatestOnly | 10000 | Atan      | 60.315 μs | 1.4029 μs | 0.7337 μs |  4.3945 |  0.4883 |  79.48 KB |
