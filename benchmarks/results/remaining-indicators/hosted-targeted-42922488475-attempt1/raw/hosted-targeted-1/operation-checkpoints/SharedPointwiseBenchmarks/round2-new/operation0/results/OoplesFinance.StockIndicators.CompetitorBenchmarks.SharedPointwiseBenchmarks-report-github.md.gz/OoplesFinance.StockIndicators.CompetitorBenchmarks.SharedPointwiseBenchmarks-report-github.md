```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Atan**      |   **9.206 μs** | **0.2099 μs** | **0.1249 μs** |  **1.58** |    **0.04** |  **3.4180** |  **0.4883** |  **56.77 KB** |        **7.22** |
| BuilderLatestOnly | 1000  | Atan      |   6.972 μs | 0.0907 μs | 0.0600 μs |  1.19 |    0.03 |  0.5493 |       - |   9.16 KB |        1.16 |
| NativeSingle      | 1000  | Atan      |   5.844 μs | 0.2209 μs | 0.1461 μs |  1.00 |    0.03 |  0.4578 |       - |   7.87 KB |        1.00 |
| NativeParallel    | 1000  | Atan      |  82.470 μs | 0.8314 μs | 0.5499 μs | 14.12 |    0.35 |  0.4883 |       - |   8.14 KB |        1.03 |
|                   |       |           |            |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **10000** | **Atan**      |  **80.466 μs** | **1.1411 μs** | **0.6791 μs** |  **1.42** |    **0.02** | **33.2031** | **13.6719** | **549.31 KB** |        **7.03** |
| BuilderLatestOnly | 10000 | Atan      |  60.213 μs | 0.3131 μs | 0.1863 μs |  1.06 |    0.01 |  4.3945 |  0.4883 |  79.48 KB |        1.02 |
| NativeSingle      | 10000 | Atan      |  56.681 μs | 0.9139 μs | 0.5439 μs |  1.00 |    0.01 |  4.3945 |  0.4883 |  78.18 KB |        1.00 |
| NativeParallel    | 10000 | Atan      | 105.764 μs | 5.7854 μs | 3.8267 μs |  1.87 |    0.07 |  3.9063 |       - |  78.45 KB |        1.00 |
