```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Atan** |  **34.16 μs** |  **1.185 μs** |  **0.620 μs** |  **1.00** |    **0.02** |  **97.86 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Atan |  14.51 μs |  0.296 μs |  0.176 μs |  0.42 |    0.01 |  40.27 KB |        0.41 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Atan** | **224.08 μs** | **21.298 μs** | **12.674 μs** |  **1.00** |    **0.08** | **959.18 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Atan | 127.89 μs |  3.631 μs |  1.899 μs |  0.57 |    0.03 | 329.66 KB |        0.34 |
