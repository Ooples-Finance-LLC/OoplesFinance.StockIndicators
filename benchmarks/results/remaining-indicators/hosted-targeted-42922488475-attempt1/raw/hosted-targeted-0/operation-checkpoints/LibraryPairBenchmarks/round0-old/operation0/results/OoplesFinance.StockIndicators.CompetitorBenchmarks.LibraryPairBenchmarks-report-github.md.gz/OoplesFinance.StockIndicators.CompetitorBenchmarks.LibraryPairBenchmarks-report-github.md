```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Acos** |  **47.30 μs** |  **4.853 μs** |  **2.888 μs** |  **1.00** |    **0.08** |  **97.86 KB** |        **1.00** |
|        |       |                      |           |           |           |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Acos** | **262.13 μs** | **17.349 μs** | **10.324 μs** |  **1.00** |    **0.05** | **959.51 KB** |        **1.00** |
