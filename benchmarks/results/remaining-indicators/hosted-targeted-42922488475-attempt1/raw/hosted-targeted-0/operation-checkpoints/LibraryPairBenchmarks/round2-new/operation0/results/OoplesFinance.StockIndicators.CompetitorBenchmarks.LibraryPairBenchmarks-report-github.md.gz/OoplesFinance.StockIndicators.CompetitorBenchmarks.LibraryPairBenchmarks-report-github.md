```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Acos** |  **48.59 μs** |  **3.654 μs** |  **1.911 μs** |  **1.00** |    **0.05** |  **97.86 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Acos |  20.92 μs |  0.694 μs |  0.459 μs |  0.43 |    0.02 |  40.93 KB |        0.42 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Acos** | **278.10 μs** | **22.843 μs** | **15.110 μs** |  **1.00** |    **0.07** | **959.51 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Acos | 163.43 μs |  6.947 μs |  4.134 μs |  0.59 |    0.03 | 331.02 KB |        0.34 |
