```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean      | Error    | StdDev   | Gen0   | Gen1   | Allocated |
|------------------ |------ |---------- |----------:|---------:|---------:|-------:|-------:|----------:|
| **BuilderFull**       | **1000**  | **Acos**      |  **13.67 μs** | **0.213 μs** | **0.112 μs** | **0.4883** |      **-** |  **56.77 KB** |
| BuilderLatestOnly | 1000  | Acos      |  11.06 μs | 0.291 μs | 0.193 μs | 0.0610 |      - |   9.16 KB |
| **BuilderFull**       | **10000** | **Acos**      | **168.82 μs** | **5.222 μs** | **3.108 μs** | **5.8594** | **4.8828** | **549.73 KB** |
| BuilderLatestOnly | 10000 | Acos      | 149.12 μs | 5.658 μs | 3.742 μs | 0.9766 |      - |  79.92 KB |
