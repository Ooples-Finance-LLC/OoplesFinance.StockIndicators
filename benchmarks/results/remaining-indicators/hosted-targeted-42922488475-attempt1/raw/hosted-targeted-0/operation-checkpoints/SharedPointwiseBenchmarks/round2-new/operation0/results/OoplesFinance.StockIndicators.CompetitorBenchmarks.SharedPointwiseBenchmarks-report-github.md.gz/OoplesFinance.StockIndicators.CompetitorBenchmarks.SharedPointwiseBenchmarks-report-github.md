```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0   | Gen1   | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-----------:|----------:|----------:|------:|--------:|-------:|-------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Acos**      |  **13.405 μs** | **0.2662 μs** | **0.1584 μs** |  **1.08** |    **0.01** | **0.4883** |      **-** |  **56.77 KB** |        **7.21** |
| BuilderLatestOnly | 1000  | Acos      |   9.501 μs | 0.1335 μs | 0.0883 μs |  0.76 |    0.01 | 0.0610 |      - |   9.16 KB |        1.16 |
| NativeSingle      | 1000  | Acos      |  12.469 μs | 0.1765 μs | 0.1050 μs |  1.00 |    0.01 |      - |      - |   7.87 KB |        1.00 |
| NativeParallel    | 1000  | Acos      |  85.344 μs | 5.2753 μs | 3.4893 μs |  6.84 |    0.27 |      - |      - |   8.14 KB |        1.03 |
|                   |       |           |            |           |           |       |         |        |        |           |             |
| **BuilderFull**       | **10000** | **Acos**      | **162.789 μs** | **3.4919 μs** | **2.3097 μs** |  **1.33** |    **0.02** | **5.8594** | **1.9531** |  **549.3 KB** |        **7.03** |
| BuilderLatestOnly | 10000 | Acos      | 134.554 μs | 4.6309 μs | 3.0630 μs |  1.10 |    0.02 |      - |      - |  79.48 KB |        1.02 |
| NativeSingle      | 10000 | Acos      | 122.591 μs | 1.3248 μs | 0.7884 μs |  1.00 |    0.01 |      - |      - |  78.19 KB |        1.00 |
| NativeParallel    | 10000 | Acos      | 143.208 μs | 1.9522 μs | 1.1618 μs |  1.17 |    0.01 |      - |      - |  78.45 KB |        1.00 |
