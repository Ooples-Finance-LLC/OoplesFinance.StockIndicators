from pathlib import Path
import hashlib,json,re,sys
from playwright.sync_api import sync_playwright
run=sys.argv[1];assert re.fullmatch(r'[A-Za-z0-9-]+',run);out=Path('C:/Users/cheat/Documents/OoplesFinance-Reports')/('cpu-builder-refresh-'+run);stage=json.loads((out/'staged.json').read_text());candidate=out/'candidate.html'
def data(path,name):return json.loads(re.search(r'<script[^>]*id="'+name+r'"[^>]*>(.*?)</script>',path.read_text(encoding='utf-8'),re.S)[1])
for name in ['dataset','archived-baseline-dataset']:assert data(out/'before.html',name)==data(candidate,name)
status=data(candidate,'rollout-status-data');assert status['measurement_totals']=={**stage['verdicts'],'expected':1604,'measured':stage['builder_comparisons'],'pending':1604-stage['builder_comparisons']}
builder=data(candidate,'current-competitor-data');before=data(out/'before.html','current-competitor-data');assert builder['receipts'][:len(before['receipts'])]==before['receipts'] and len(builder['receipts'])>len(before['receipts']) and builder['verdicts']==stage['verdicts']
with sync_playwright() as p:
 b=p.chromium.launch(channel='msedge',headless=True);page=b.new_page(viewport={'width':1600,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto(candidate.as_uri())
 assert page.locator('#builder-current-results tbody tr').count()==stage['builder_comparisons']
 for r in stage['rows']:
  row=page.locator(f'#builder-current-results tr[data-builder-pair="{r["pair"]}"][data-bars="{r["bars"]}"][data-mode="{r["mode"]}"]')
  cells=row.locator('td').all_inner_texts();assert cells[0]==r['pair'] and cells[1]==f'{r["bars"]:,}'
  assert cells[3:6]==[f'{r["ooples"]["mean_ns"]/1e6:.6f}',f'{r["native"]["NativeSingle"]["mean_ns"]/1e6:.6f}',f'{r["native"]["NativeParallel"]["mean_ns"]/1e6:.6f}']
  assert cells[6]=={'faster':'Faster than both','slower':'Slower than at least one','inconclusive':'Inconclusive'}[r['verdict']]
  assert row.locator('a').get_attribute('href')==r.get('measurement_url','https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/'+r['run_id'])
 assert f"{stage['builder_comparisons']} / 1604" in page.locator('#rollout-status').inner_text() and f"{1604-stage['builder_comparisons']} pending" in page.locator('#current-competitors').inner_text()
 page.evaluate("window.scrollTo(0,document.querySelector('#current-competitors').offsetTop)");page.screenshot(path=str(out/'builder-results.png'));assert not errors;b.close()
(out/'builder-verification.json').write_text(json.dumps({'run_id':run,'builder_comparisons':stage['builder_comparisons'],'new_builder_comparisons':stage['new_builder_comparisons'],'unchanged_baseline_comparisons':802,'report_sha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'javascript_errors':errors,'status_totals':status['measurement_totals']},indent=2))
print('Verified every displayed builder row and provenance; baseline802 and prior builder records unchanged',stage['builder_comparisons'])
