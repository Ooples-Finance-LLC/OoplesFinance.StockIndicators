```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0      | Gen1     | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)bands [24]** | **1000**  |  **1.897 ms** | **0.0212 ms** | **0.0126 ms** |  **187.5000** |  **31.2500** |   **3.11 MB** |
| BuilderLatestOnly | TaLib(...)bands [24] | 1000  |  1.882 ms | 0.0373 ms | 0.0222 ms |  187.5000 |  31.2500 |   3.07 MB |
| **BuilderFull**       | **TaLib(...)bands [24]** | **10000** | **11.934 ms** | **0.5117 ms** | **0.2676 ms** | **1888.8889** | **888.8889** |  **31.34 MB** |
| BuilderLatestOnly | TaLib(...)bands [24] | 10000 | 12.039 ms | 0.3292 ms | 0.2177 ms | 1888.8889 | 888.8889 |  30.88 MB |
