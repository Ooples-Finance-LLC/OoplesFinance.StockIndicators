```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)bands [24]** | **1000**  |   **535.8 μs** |   **2.41 μs** |   **1.26 μs** |       **-** |  **99.55 KB** |
| BuilderLatestOnly | TaLib(...)bands [24] | 1000  |   505.3 μs |  14.23 μs |   9.41 μs |       - |  51.88 KB |
| **BuilderFull**       | **TaLib(...)bands [24]** | **10000** | **2,988.7 μs** | **193.31 μs** | **127.86 μs** | **31.2500** | **953.26 KB** |
| BuilderLatestOnly | TaLib(...)bands [24] | 10000 | 2,983.7 μs | 207.48 μs | 137.24 μs | 15.6250 | 483.39 KB |
