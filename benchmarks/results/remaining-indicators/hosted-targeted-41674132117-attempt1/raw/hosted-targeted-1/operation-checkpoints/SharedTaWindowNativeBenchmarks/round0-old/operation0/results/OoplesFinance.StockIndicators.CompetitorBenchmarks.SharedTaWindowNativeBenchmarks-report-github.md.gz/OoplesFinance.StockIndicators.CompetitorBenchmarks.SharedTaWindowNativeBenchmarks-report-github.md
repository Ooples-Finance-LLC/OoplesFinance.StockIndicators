```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0      | Gen1     | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)bands [24]** | **1000**  |  **1.845 ms** | **0.0453 ms** | **0.0270 ms** |  **187.5000** |  **31.2500** |   **3.11 MB** |
| BuilderLatestOnly | TaLib(...)bands [24] | 1000  |  1.815 ms | 0.0159 ms | 0.0095 ms |  187.5000 |  31.2500 |   3.07 MB |
| **BuilderFull**       | **TaLib(...)bands [24]** | **10000** | **11.592 ms** | **0.5184 ms** | **0.3429 ms** | **1888.8889** | **888.8889** |  **31.34 MB** |
| BuilderLatestOnly | TaLib(...)bands [24] | 10000 | 12.063 ms | 0.7238 ms | 0.4788 ms | 1888.8889 | 888.8889 |  30.88 MB |
