```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)bands [24]** | **1000**  |   **545.899 μs** |   **8.5639 μs** |   **5.0963 μs** | **69.34** |    **1.25** |       **-** |       **-** |   **99.54 KB** |        **2.55** |
| BuilderLatestOnly | TaLib(...)bands [24] | 1000  |   514.196 μs |   4.2353 μs |   2.5204 μs | 65.32 |    1.07 |       - |       - |   51.88 KB |        1.33 |
| NativeSingle      | TaLib(...)bands [24] | 1000  |     7.874 μs |   0.2155 μs |   0.1282 μs |  1.00 |    0.02 |  2.3804 |  0.1831 |   39.09 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [24] | 1000  |    15.789 μs |   0.6188 μs |   0.4093 μs |  2.01 |    0.06 |  8.0566 |  1.2207 |  122.26 KB |        3.13 |
|                   |                      |       |              |             |             |       |         |         |         |            |             |
| **BuilderFull**       | **TaLib(...)bands [24]** | **10000** | **2,958.057 μs** |  **42.5862 μs** |  **22.2734 μs** | **38.24** |    **0.67** | **31.2500** |       **-** |  **953.19 KB** |        **2.44** |
| BuilderLatestOnly | TaLib(...)bands [24] | 10000 | 3,014.880 μs | 177.3029 μs | 117.2749 μs | 38.98 |    1.58 | 15.6250 |       - |  483.37 KB |        1.24 |
| NativeSingle      | TaLib(...)bands [24] | 10000 |    77.366 μs |   1.9839 μs |   1.3122 μs |  1.00 |    0.02 | 23.4375 |  7.8125 |  390.65 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [24] | 10000 |   141.697 μs |   7.6653 μs |   5.0701 μs |  1.83 |    0.07 | 76.1719 | 34.1797 | 1212.11 KB |        3.10 |
