```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error        | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-------------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)bands [24]** |   **753.85 μs** |    **33.377 μs** |  **22.076 μs** |  **1.00** |    **0.04** |  **221.38 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)bands [24] |    22.24 μs |     0.445 μs |   0.233 μs |  0.03 |    0.00 |  122.17 KB |        0.55 |
|            |       |                      |             |              |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)bands [24]** | **5,016.43 μs** | **1,373.546 μs** | **908.516 μs** |  **1.03** |    **0.25** | **2158.01 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)bands [24] |   185.00 μs |     6.320 μs |   3.761 μs |  0.04 |    0.01 | 1132.91 KB |        0.52 |
