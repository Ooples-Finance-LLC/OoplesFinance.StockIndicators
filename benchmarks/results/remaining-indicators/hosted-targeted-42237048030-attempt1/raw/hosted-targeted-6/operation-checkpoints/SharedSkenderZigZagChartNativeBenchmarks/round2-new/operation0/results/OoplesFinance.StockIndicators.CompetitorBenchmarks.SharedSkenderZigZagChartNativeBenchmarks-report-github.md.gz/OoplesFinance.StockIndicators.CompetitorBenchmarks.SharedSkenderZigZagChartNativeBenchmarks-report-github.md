```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method       | Count | Operation         | Mean       | Error    | StdDev   | Ratio | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------- |------ |------------------ |-----------:|---------:|---------:|------:|---------:|---------:|---------:|-----------:|------------:|
| **Snapshot**     | **1000**  | **Skender.GetZigZag** |   **120.1 μs** |  **2.73 μs** |  **1.43 μs** |  **0.49** |   **5.8594** |        **-** |        **-** |  **149.64 KB** |        **0.61** |
| NativeSingle | 1000  | Skender.GetZigZag |   243.0 μs |  1.89 μs |  1.12 μs |  1.00 |   7.8125 |        - |        - |  244.29 KB |        1.00 |
|              |       |                   |            |          |          |       |          |          |          |            |             |
| **Snapshot**     | **10000** | **Skender.GetZigZag** | **1,673.2 μs** | **66.58 μs** | **39.62 μs** |  **0.58** | **203.1250** | **187.5000** | **187.5000** | **1495.15 KB** |        **0.64** |
| NativeSingle | 10000 | Skender.GetZigZag | 2,860.7 μs | 20.35 μs | 12.11 μs |  1.00 |  93.7500 |  46.8750 |        - | 2323.26 KB |        1.00 |
