```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method   | Count | Operation         | Mean       | Error     | StdDev    | Gen0     | Gen1     | Gen2     | Allocated  |
|--------- |------ |------------------ |-----------:|----------:|----------:|---------:|---------:|---------:|-----------:|
| **Snapshot** | **1000**  | **Skender.GetZigZag** |   **266.2 μs** |   **6.15 μs** |   **3.66 μs** |  **11.7188** |        **-** |        **-** |  **372.64 KB** |
| **Snapshot** | **10000** | **Skender.GetZigZag** | **4,201.7 μs** | **322.64 μs** | **213.40 μs** | **281.2500** | **218.7500** | **187.5000** | **3788.66 KB** |
