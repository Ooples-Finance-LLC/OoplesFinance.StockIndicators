```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method   | Count | Operation         | Mean       | Error     | StdDev    | Gen0     | Gen1     | Gen2     | Allocated  |
|--------- |------ |------------------ |-----------:|----------:|----------:|---------:|---------:|---------:|-----------:|
| **Snapshot** | **1000**  | **Skender.GetZigZag** |   **128.5 μs** |   **2.39 μs** |   **1.58 μs** |   **5.8594** |        **-** |        **-** |  **149.64 KB** |
| **Snapshot** | **10000** | **Skender.GetZigZag** | **1,835.8 μs** | **241.90 μs** | **160.00 μs** | **203.1250** | **187.5000** | **187.5000** | **1495.05 KB** |
