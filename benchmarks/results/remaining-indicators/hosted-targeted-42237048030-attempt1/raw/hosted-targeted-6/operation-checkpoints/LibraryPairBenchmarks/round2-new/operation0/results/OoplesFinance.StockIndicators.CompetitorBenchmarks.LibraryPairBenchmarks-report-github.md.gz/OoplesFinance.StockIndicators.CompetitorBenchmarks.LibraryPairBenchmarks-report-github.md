```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId            | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------ |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetZigZag** |   **281.8 μs** | **91.12 μs** | **60.27 μs** |  **1.04** |    **0.29** |  **256.95 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetZigZag |   363.9 μs | 60.24 μs | 35.85 μs |  1.34 |    0.28 |   429.1 KB |        1.67 |
|            |       |                   |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetZigZag** | **1,989.5 μs** | **47.81 μs** | **25.01 μs** |  **1.00** |    **0.02** | **2557.01 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetZigZag | 3,425.1 μs | 79.10 μs | 47.07 μs |  1.72 |    0.03 |  4090.7 KB |        1.60 |
