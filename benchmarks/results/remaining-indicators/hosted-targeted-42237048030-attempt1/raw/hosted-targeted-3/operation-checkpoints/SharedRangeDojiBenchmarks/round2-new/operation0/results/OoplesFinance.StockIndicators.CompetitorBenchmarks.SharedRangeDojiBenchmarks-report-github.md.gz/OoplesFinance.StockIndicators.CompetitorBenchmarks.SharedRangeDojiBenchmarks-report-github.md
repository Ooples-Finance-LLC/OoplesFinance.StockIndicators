```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)eDoji [28]** | **1000**  |  **44.88 μs** |  **0.322 μs** |  **0.169 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)eDoji [28] | 1000  |  38.68 μs |  5.343 μs |  3.534 μs |  0.86 |    0.08 |  0.4883 |       - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib(...)eDoji [28] | 1000  |  45.81 μs |  0.356 μs |  0.212 μs |  1.02 |    0.01 |  3.4180 |  0.4883 |  57.24 KB |       14.42 |
| BuilderLatestOnly | TaLib(...)eDoji [28] | 1000  |  44.00 μs |  0.538 μs |  0.320 μs |  0.98 |    0.01 |  0.4883 |       - |   9.38 KB |        2.36 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)eDoji [28]** | **10000** | **453.48 μs** |  **6.846 μs** |  **3.580 μs** |  **1.00** |    **0.01** |       **-** |       **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)eDoji [28] | 10000 | 310.99 μs | 42.897 μs | 28.373 μs |  0.69 |    0.06 |  5.8594 |       - |   78.7 KB |        2.01 |
| BuilderFull       | TaLib(...)eDoji [28] | 10000 | 409.09 μs |  3.923 μs |  2.052 μs |  0.90 |    0.01 | 31.2500 | 11.7188 |  549.8 KB |       14.04 |
| BuilderLatestOnly | TaLib(...)eDoji [28] | 10000 | 390.68 μs |  5.062 μs |  3.012 μs |  0.86 |    0.01 |  3.9063 |       - |  79.73 KB |        2.04 |
