```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)eDoji [28]** | **1000**  |  **52.89 μs** | **0.577 μs** | **0.343 μs** |  **1.9531** |       **-** |  **57.26 KB** |
| BuilderLatestOnly | TaLib(...)eDoji [28] | 1000  |  49.29 μs | 0.340 μs | 0.203 μs |  0.4883 |       - |   9.38 KB |
| **BuilderFull**       | **TaLib(...)eDoji [28]** | **10000** | **489.06 μs** | **2.006 μs** | **1.194 μs** | **31.2500** | **11.7188** | **549.82 KB** |
| BuilderLatestOnly | TaLib(...)eDoji [28] | 10000 | 455.51 μs | 1.265 μs | 0.661 μs |  3.9063 |       - |  79.71 KB |
