```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)eDoji [28]** |  **61.19 μs** |  **0.573 μs** |  **0.300 μs** |  **1.00** |    **0.01** |  **65.33 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)eDoji [28] |  53.70 μs | 11.135 μs |  7.365 μs |  0.88 |    0.11 |  19.58 KB |        0.30 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)eDoji [28]** | **465.91 μs** | **24.731 μs** | **14.717 μs** |  **1.00** |    **0.04** | **628.16 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)eDoji [28] | 440.78 μs | 20.868 μs | 13.803 μs |  0.95 |    0.04 | 117.55 KB |        0.19 |
