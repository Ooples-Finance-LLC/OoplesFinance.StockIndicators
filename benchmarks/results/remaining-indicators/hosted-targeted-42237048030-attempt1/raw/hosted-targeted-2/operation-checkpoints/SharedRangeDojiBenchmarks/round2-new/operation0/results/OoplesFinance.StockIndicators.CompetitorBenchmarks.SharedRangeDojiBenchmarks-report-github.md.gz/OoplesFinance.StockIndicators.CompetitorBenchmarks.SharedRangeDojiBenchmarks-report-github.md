```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)yDoji [27]** | **1000**  |  **44.69 μs** |  **0.208 μs** |  **0.124 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)yDoji [27] | 1000  |  37.73 μs |  4.459 μs |  2.950 μs |  0.84 |    0.06 |  0.4883 |       - |    8.4 KB |        2.12 |
| BuilderFull       | TaLib(...)yDoji [27] | 1000  |  52.62 μs |  0.722 μs |  0.378 μs |  1.18 |    0.01 |  3.4180 |  0.4883 |  57.27 KB |       14.43 |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 1000  |  45.49 μs |  0.201 μs |  0.105 μs |  1.02 |    0.00 |  0.4883 |       - |   9.38 KB |        2.36 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)yDoji [27]** | **10000** | **440.72 μs** |  **2.956 μs** |  **1.546 μs** |  **1.00** |    **0.00** |       **-** |       **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)yDoji [27] | 10000 | 322.63 μs | 49.674 μs | 32.856 μs |  0.73 |    0.07 |  5.8594 |       - |  78.72 KB |        2.01 |
| BuilderFull       | TaLib(...)yDoji [27] | 10000 | 449.19 μs |  4.167 μs |  2.179 μs |  1.02 |    0.01 | 31.2500 | 11.7188 | 549.83 KB |       14.04 |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 10000 | 424.08 μs |  3.186 μs |  1.666 μs |  0.96 |    0.00 |  3.9063 |       - |  79.73 KB |        2.04 |
