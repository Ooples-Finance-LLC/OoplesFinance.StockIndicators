```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)yDoji [27]** | **1000**  |  **47.48 μs** | **0.541 μs** | **0.322 μs** |  **1.9531** |       **-** |  **57.27 KB** |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 1000  |  46.61 μs | 1.193 μs | 0.789 μs |  0.4883 |       - |   9.38 KB |
| **BuilderFull**       | **TaLib(...)yDoji [27]** | **10000** | **436.69 μs** | **2.180 μs** | **1.140 μs** | **31.2500** | **11.7188** | **549.82 KB** |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 10000 | 415.01 μs | 0.766 μs | 0.401 μs |  3.9063 |       - |  79.72 KB |
