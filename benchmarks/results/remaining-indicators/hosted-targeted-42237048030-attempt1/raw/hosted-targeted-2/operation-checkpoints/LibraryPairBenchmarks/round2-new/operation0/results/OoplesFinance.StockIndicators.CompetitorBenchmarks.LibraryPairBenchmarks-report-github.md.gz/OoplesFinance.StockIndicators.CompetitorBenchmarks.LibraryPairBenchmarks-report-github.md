```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)yDoji [27]** |  **85.27 μs** |  **1.549 μs** |  **0.922 μs** |  **1.00** |    **0.01** |  **65.37 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)yDoji [27] |  47.06 μs |  7.343 μs |  4.370 μs |  0.55 |    0.05 |   19.3 KB |        0.30 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)yDoji [27]** | **469.53 μs** | **12.866 μs** |  **7.656 μs** |  **1.00** |    **0.02** | **632.38 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)yDoji [27] | 431.32 μs | 18.435 μs | 12.194 μs |  0.92 |    0.03 | 122.09 KB |        0.19 |
