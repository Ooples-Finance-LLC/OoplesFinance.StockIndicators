```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |-----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib.Candles.Doji** | **1000**  |  **22.719 μs** | **0.3194 μs** | **0.1671 μs** |  **1.00** |    **0.01** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Doji | 1000  |   9.731 μs | 1.4732 μs | 0.8767 μs |  0.43 |    0.04 |  0.4883 |       - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib.Candles.Doji | 1000  |  25.653 μs | 0.8919 μs | 0.5308 μs |  1.13 |    0.02 |  3.4180 |  0.4883 |  57.23 KB |       14.42 |
| BuilderLatestOnly | TaLib.Candles.Doji | 1000  |  24.541 μs | 0.5469 μs | 0.3254 μs |  1.08 |    0.02 |  0.4883 |       - |   9.38 KB |        2.36 |
|                   |                    |       |            |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib.Candles.Doji** | **10000** | **138.777 μs** | **0.9668 μs** | **0.5056 μs** |  **1.00** |    **0.00** |  **1.9531** |       **-** |  **39.13 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Doji | 10000 | 108.952 μs | 5.4975 μs | 3.2715 μs |  0.79 |    0.02 |  5.8594 |       - |  78.69 KB |        2.01 |
| BuilderFull       | TaLib.Candles.Doji | 10000 | 231.711 μs | 1.0120 μs | 0.6022 μs |  1.67 |    0.01 | 33.2031 | 11.7188 | 549.77 KB |       14.05 |
| BuilderLatestOnly | TaLib.Candles.Doji | 10000 | 223.141 μs | 1.3303 μs | 0.6958 μs |  1.61 |    0.01 |  3.9063 |       - |  79.71 KB |        2.04 |
