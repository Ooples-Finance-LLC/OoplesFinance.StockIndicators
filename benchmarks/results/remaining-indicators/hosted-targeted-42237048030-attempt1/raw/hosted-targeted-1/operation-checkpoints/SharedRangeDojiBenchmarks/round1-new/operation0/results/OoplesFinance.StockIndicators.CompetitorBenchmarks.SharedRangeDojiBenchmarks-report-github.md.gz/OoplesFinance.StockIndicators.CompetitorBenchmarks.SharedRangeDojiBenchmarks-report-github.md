```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------------- |------ |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Candles.Doji** | **1000**  |  **32.29 μs** |  **5.028 μs** | **2.992 μs** |  **2.9297** |       **-** |  **57.24 KB** |
| BuilderLatestOnly | TaLib.Candles.Doji | 1000  |  24.69 μs |  0.912 μs | 0.543 μs |  0.4883 |       - |   9.38 KB |
| **BuilderFull**       | **TaLib.Candles.Doji** | **10000** | **233.85 μs** | **13.490 μs** | **7.055 μs** | **33.2031** | **11.7188** | **549.77 KB** |
| BuilderLatestOnly | TaLib.Candles.Doji | 10000 | 223.83 μs |  4.599 μs | 2.737 μs |  3.9063 |       - |   79.7 KB |
