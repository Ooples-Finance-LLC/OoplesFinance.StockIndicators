```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Candles.Doji** | **1000**  |  **27.63 μs** | **1.411 μs** | **0.738 μs** |  **2.9297** |       **-** |  **57.26 KB** |
| BuilderLatestOnly | TaLib.Candles.Doji | 1000  |  25.94 μs | 1.073 μs | 0.710 μs |  0.4883 |       - |   9.38 KB |
| **BuilderFull**       | **TaLib.Candles.Doji** | **10000** | **239.13 μs** | **1.722 μs** | **0.901 μs** | **33.2031** | **11.7188** |  **549.8 KB** |
| BuilderLatestOnly | TaLib.Candles.Doji | 10000 | 242.37 μs | 1.595 μs | 0.834 μs |  3.9063 |       - |   79.7 KB |
