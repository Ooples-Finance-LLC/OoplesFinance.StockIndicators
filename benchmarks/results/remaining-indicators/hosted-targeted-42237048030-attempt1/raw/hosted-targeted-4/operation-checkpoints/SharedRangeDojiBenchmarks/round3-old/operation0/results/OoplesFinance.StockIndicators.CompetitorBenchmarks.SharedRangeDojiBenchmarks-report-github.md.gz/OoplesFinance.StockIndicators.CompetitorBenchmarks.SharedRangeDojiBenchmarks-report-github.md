```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)dDoji [28]** | **1000**  |  **64.19 μs** | **0.384 μs** | **0.229 μs** |       **-** |       **-** |   **57.3 KB** |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 1000  |  48.60 μs | 0.429 μs | 0.224 μs |  0.4883 |       - |   9.38 KB |
| **BuilderFull**       | **TaLib(...)dDoji [28]** | **10000** | **472.65 μs** | **3.746 μs** | **1.959 μs** | **31.2500** | **11.7188** | **549.82 KB** |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 10000 | 451.98 μs | 3.567 μs | 1.866 μs |  3.9063 |       - |  79.71 KB |
