```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)dDoji [28]** | **1000**  |  **47.75 μs** |  **0.777 μs** |  **0.462 μs** |  **1.00** |    **0.01** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)dDoji [28] | 1000  |  40.07 μs |  6.770 μs |  3.541 μs |  0.84 |    0.07 |  0.4883 |       - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib(...)dDoji [28] | 1000  |  50.36 μs |  0.299 μs |  0.157 μs |  1.05 |    0.01 |  3.4180 |  0.4883 |  57.27 KB |       14.43 |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 1000  |  48.69 μs |  0.150 μs |  0.078 μs |  1.02 |    0.01 |  0.4883 |       - |   9.39 KB |        2.37 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)dDoji [28]** | **10000** | **473.33 μs** |  **3.066 μs** |  **1.825 μs** |  **1.00** |    **0.01** |       **-** |       **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib(...)dDoji [28] | 10000 | 373.80 μs | 63.939 μs | 42.292 μs |  0.79 |    0.09 |  3.9063 |       - |  78.71 KB |        2.01 |
| BuilderFull       | TaLib(...)dDoji [28] | 10000 | 537.95 μs |  4.363 μs |  2.282 μs |  1.14 |    0.01 | 31.2500 | 11.7188 | 549.82 KB |       14.05 |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 10000 | 429.90 μs |  3.486 μs |  1.823 μs |  0.91 |    0.00 |  3.9063 |       - |  79.73 KB |        2.04 |
