```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dDoji [28]** |  **84.95 μs** |  **1.481 μs** |  **0.775 μs** |  **1.00** |    **0.01** |  **65.37 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dDoji [28] |  59.27 μs |  3.233 μs |  1.691 μs |  0.70 |    0.02 |  18.92 KB |        0.29 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)dDoji [28]** | **469.94 μs** |  **8.552 μs** |  **4.473 μs** |  **1.00** |    **0.01** | **631.72 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dDoji [28] | 484.14 μs | 25.998 μs | 17.196 μs |  1.03 |    0.04 | 124.06 KB |        0.20 |
