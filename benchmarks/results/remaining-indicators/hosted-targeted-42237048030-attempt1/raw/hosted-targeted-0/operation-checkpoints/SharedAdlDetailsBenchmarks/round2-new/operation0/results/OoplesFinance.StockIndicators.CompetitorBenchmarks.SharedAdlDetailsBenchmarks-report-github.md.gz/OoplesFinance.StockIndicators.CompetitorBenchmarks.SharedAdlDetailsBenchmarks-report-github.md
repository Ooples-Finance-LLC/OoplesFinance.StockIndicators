```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |    **38.22 μs** |   **0.531 μs** |  **0.351 μs** |  **0.51** |    **0.01** |   **4.8828** |   **0.9766** |   **88.31 KB** |        **0.50** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |    34.70 μs |   0.179 μs |  0.094 μs |  0.46 |    0.00 |   2.4414 |   0.2441 |    40.7 KB |        0.23 |
| NativeSingle      | Skender.GetAdl | 1000  |    75.12 μs |   0.914 μs |  0.604 μs |  1.00 |    0.01 |  10.7422 |   2.4414 |  176.21 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 1000  |   139.98 μs |  11.104 μs |  6.608 μs |  1.86 |    0.08 |  28.3203 |   8.7891 |   449.4 KB |        2.55 |
|                   |                |       |             |            |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetAdl** | **10000** |   **364.01 μs** |   **3.386 μs** |  **1.771 μs** |  **0.42** |    **0.00** |  **50.7813** |  **17.5781** |  **862.12 KB** |        **0.49** |
| BuilderLatestOnly | Skender.GetAdl | 10000 |   338.61 μs |   4.062 μs |  2.125 μs |  0.39 |    0.00 |  23.4375 |   9.7656 |  392.29 KB |        0.22 |
| NativeSingle      | Skender.GetAdl | 10000 |   862.30 μs |  12.449 μs |  7.408 μs |  1.00 |    0.01 | 101.5625 |  62.5000 |  1758.3 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 10000 | 1,457.65 μs | 105.488 μs | 69.774 μs |  1.69 |    0.08 | 273.4375 | 195.3125 | 4474.84 KB |        2.54 |
