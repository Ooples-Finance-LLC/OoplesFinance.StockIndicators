```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAdl** |   **209.67 μs** |  **4.043 μs** |  **2.406 μs** |  **1.00** |    **0.02** |  **159.04 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAdl |    91.72 μs | 11.571 μs |  6.886 μs |  0.44 |    0.03 |  273.38 KB |        1.72 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAdl** | **1,733.51 μs** | **31.332 μs** | **16.387 μs** |  **1.00** |    **0.01** | **1511.76 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAdl |   969.33 μs | 66.730 μs | 39.710 μs |  0.56 |    0.02 | 2656.48 KB |        1.76 |
