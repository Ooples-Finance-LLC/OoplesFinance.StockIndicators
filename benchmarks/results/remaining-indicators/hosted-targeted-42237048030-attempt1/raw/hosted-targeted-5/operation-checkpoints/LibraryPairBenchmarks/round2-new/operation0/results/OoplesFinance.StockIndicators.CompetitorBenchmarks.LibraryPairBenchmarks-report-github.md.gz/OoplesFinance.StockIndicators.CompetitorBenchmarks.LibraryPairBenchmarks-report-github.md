```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)iLine [24]** | **100.91 μs** |  **0.795 μs** |  **0.416 μs** |  **1.00** |    **0.01** |  **65.37 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)iLine [24] |  72.03 μs | 12.123 μs |  7.214 μs |  0.71 |    0.07 |   19.3 KB |        0.30 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)iLine [24]** | **574.38 μs** | **32.736 μs** | **19.481 μs** |  **1.00** |    **0.05** | **634.02 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)iLine [24] | 669.85 μs |  8.447 μs |  4.418 μs |  1.17 |    0.04 | 123.73 KB |        0.20 |
