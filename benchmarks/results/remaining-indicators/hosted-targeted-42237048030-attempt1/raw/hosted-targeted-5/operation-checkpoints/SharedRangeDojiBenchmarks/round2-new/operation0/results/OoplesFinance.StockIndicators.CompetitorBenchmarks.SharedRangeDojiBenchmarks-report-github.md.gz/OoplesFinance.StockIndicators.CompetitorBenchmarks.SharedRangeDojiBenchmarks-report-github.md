```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)iLine [24]** | **1000**  |  **91.26 μs** |  **0.165 μs** |  **0.098 μs** |  **1.00** |    **0.00** |       **-** |      **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)iLine [24] | 1000  |  54.45 μs |  5.602 μs |  3.705 μs |  0.60 |    0.04 |  0.4883 |      - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib(...)iLine [24] | 1000  |  69.39 μs |  0.719 μs |  0.428 μs |  0.76 |    0.00 |  3.4180 | 0.4883 |  57.27 KB |       14.43 |
| BuilderLatestOnly | TaLib(...)iLine [24] | 1000  |  63.12 μs |  0.126 μs |  0.066 μs |  0.69 |    0.00 |  0.4883 |      - |   9.39 KB |        2.37 |
|                   |                      |       |           |           |           |       |         |         |        |           |             |
| **NativeSingle**      | **TaLib(...)iLine [24]** | **10000** | **701.21 μs** |  **4.646 μs** |  **3.073 μs** |  **1.00** |    **0.01** |       **-** |      **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)iLine [24] | 10000 | 467.15 μs | 75.113 μs | 49.682 μs |  0.67 |    0.07 |  3.9063 |      - |  78.72 KB |        2.01 |
| BuilderFull       | TaLib(...)iLine [24] | 10000 | 701.14 μs |  1.981 μs |  1.036 μs |  1.00 |    0.00 | 31.2500 | 7.8125 | 549.87 KB |       14.04 |
| BuilderLatestOnly | TaLib(...)iLine [24] | 10000 | 585.62 μs |  3.156 μs |  2.088 μs |  0.84 |    0.00 |  3.9063 |      - |  79.73 KB |        2.04 |
