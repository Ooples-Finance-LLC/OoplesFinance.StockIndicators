```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)iLine [24]** | **1000**  |  **75.16 μs** | **0.285 μs** | **0.169 μs** |       **-** |       **-** |  **57.26 KB** |
| BuilderLatestOnly | TaLib(...)iLine [24] | 1000  |  73.01 μs | 0.571 μs | 0.340 μs |  0.4883 |       - |   9.38 KB |
| **BuilderFull**       | **TaLib(...)iLine [24]** | **10000** | **712.60 μs** | **5.605 μs** | **3.335 μs** | **31.2500** | **11.7188** | **549.83 KB** |
| BuilderLatestOnly | TaLib(...)iLine [24] | 10000 | 687.84 μs | 1.889 μs | 0.988 μs |  3.9063 |       - |  79.72 KB |
