"""Archive the immutable rejected qualification only; never publish candidate source."""
import gzip,hashlib,json,os,shutil,subprocess,sys,tempfile
from pathlib import Path

RUN='44245783811'
BASE='f36781297872d2c496e59dd4edff9e702815dc97'
FROZEN='ab5370a6a0706c8b4390418a618eab36ebd99c48'
OLD='9e914007c3438d9f251f3fab9ef321d49c22de83'
NEW='d1933adf1c979bc19a5fab3f2bb2b26946386386'
REPO=Path(r'C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-seven-candle-word-qualification-20261118')
PUBLISHER=Path(r'C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-rejected-seven-candle-evidence-publisher-20261118')
OPS=Path(r'C:\Users\cheat\source\stock-indicators-operations')
EVIDENCE=Path('Z:/StockIndicators-Archives/active-performance-evidence')/('seven-candle-word-qualification-'+RUN)
PREP=OPS/'seven-candle-word-qualification-20261118'/('hosted-inputs-'+RUN)
RAW=EVIDENCE/'raw/evidence'
PLAN=REPO/'benchmarks/plans/hosted-seven-candle-word-qualification-20261118.json'
SUMMARY_SHA='113e95e49d48325ae3499fa1bb8a80fe5019b994fdb87da8ea5509ce1dd50048'

def git(repo,*args):return subprocess.check_output(['git',*args],cwd=repo)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def encoded(data):return (json.dumps(data,indent=2)+'\n').encode()
def read(path):return json.loads(path.read_bytes())

assert git(REPO,'rev-parse','HEAD').decode().strip()==FROZEN and not git(REPO,'status','--porcelain')
assert git(PUBLISHER,'rev-parse','HEAD').decode().strip()==BASE and not git(PUBLISHER,'status','--porcelain')
assert sha(PLAN.read_bytes())=='8c230c36187f4f25b34fb3408b3d7df514b4983c8a937204a913fc984b555031'
assert sha((EVIDENCE/'authenticated-summary.json').read_bytes())==SUMMARY_SHA
assert (EVIDENCE/'authenticated-summary.json').read_bytes()==(EVIDENCE/'uploaded-summary.json').read_bytes()
review=read(EVIDENCE/'root-review.json')
assert review['status']=='parent-independent-frozen-rejection-authenticated' and review['summary_sha256']==SUMMARY_SHA
assert review['accepted'] is False and review['accepted_closure_credit']==0 and review['proposed_criterion_amendment_approved'] is False
proposal=read(EVIDENCE/'original-native-policy-counterfactual-proposal.json')
assert proposal['approved'] is False and proposal['accepted_closure_credit']==0 and proposal['source_publication_authorized'] is False
assert proposal['original_rejected_summary_sha256']==SUMMARY_SHA
assert shutil.disk_usage(OPS).free>=128*1024*1024
scratch=OPS/'seven-candle-word-qualification-20261118'/('verification-temp-'+RUN)
assert scratch.is_dir();os.environ.update(TEMP=str(scratch),TMP=str(scratch),HOSTED_TIMING_PLAN=str(PLAN));tempfile.tempdir=str(scratch)
sys.path.insert(0,str(REPO/'scripts'))
from hosted_timing import seven_candle_qualification as q
from hosted_timing import archive as frozen_archive

q.roi.verify_source_boundary()
fingerprint=q.roi.common.source_fingerprint(BASE)
assert fingerprint==q.roi.common.source_fingerprint(OLD)=='79ccf727c22cb156a0cb75cdd0f764da037603d7b74c8cd9cb075da2c6498815'
assert git(PUBLISHER,'rev-parse',BASE+':src')==git(PUBLISHER,'rev-parse',OLD+':src')
module_path='scripts/hosted_timing/archive.py'
module_blob=git(REPO,'show',FROZEN+':'+module_path);module_working=(REPO/module_path).read_bytes()
assert module_working.replace(b'\r\n',b'\n')==module_blob
destination=frozen_archive.archive(RAW,PREP,PUBLISHER,'targeted')
assert sha((destination/'verified-summary.json').read_bytes())==SUMMARY_SHA
decision_path=destination/'decision.json';decision=read(decision_path)
assert decision['status']=='rejected-or-inconclusive' and decision['accepted'] is False
assert decision['source_gate_accepted'] is True and decision['native_progress_gate_passed'] is False
assert (decision['case_count'],decision['decision_count'])==(198,42) and decision['new_closure_credit_pairs']==[]
source_patch=git(PUBLISHER,'diff','--binary',OLD,NEW,'--','src','tests')
assert gzip.decompress((destination/'candidate-source.patch.gz').read_bytes())==source_patch
source_identity=dict(status='archive-only-live-source-unchanged',publisher_base=BASE,measured_old=OLD,measured_candidate=NEW,
    live_source_fingerprint=fingerprint,live_src_tree=git(PUBLISHER,'rev-parse',BASE+':src').decode().strip(),
    source_patch_sha256=sha(source_patch),source_patch_gzip_only=True,candidate_source_applied=False,
    gpu_evidence_cherry_picked=False,accepted_closure_credit=0,criterion_amendment_approved=False,
    original_rejected_summary_sha256=SUMMARY_SHA)
zip_proof=dict(run_id=RUN,head=FROZEN,artifact_id=14403491049,
    artifact_zip_sha256='640db4731d1f8bc91bb3eb86a12edd5f415cea14d7ec66455d731de19afcc46f',
    zip_files_verified=1376,runtime_zip_payload_files_verified=200,all_files_accounted_for=True,
    runtime_zip_hashes_match_declared_manifests=True,new_runtime_payload_bytes=0,
    preserved_external_zip=str(EVIDENCE/'artifact.zip'),bulk_zip_or_runtime_archived_in_git=False,
    proof_sources=['review/materialization-manifest.json','review/collection-receipt.json','review/root-review.json'])
extra={}
for name in ('root-review.json','run-api.json','artifact-api.json','materialization-manifest.json','collection-receipt.json',
             'authenticated-summary.json','original-native-policy-counterfactual-proposal.json'):
    extra['review/'+name]=(EVIDENCE/name).read_bytes()
extra.update({'review/zip-proof.json':encoded(zip_proof),'review/rejected-source-identity-proof.json':encoded(source_identity),
    'review/frozen-archive-code-proof.json':encoded(dict(commit=FROZEN,path=module_path,git_blob_sha256=sha(module_blob),
        executed_working_copy_sha256=sha(module_working),only_possible_byte_difference='CRLF checkout conversion',normalized_git_identity_verified=True)),
    'review/collector.py':(OPS/'collect-seven-candle-word-qualification-44245783811.py').read_bytes(),
    'review/archive-preparation.py':Path(__file__).read_bytes(),
    'review/roi-root-review.json':(EVIDENCE.parent/'candle-isolated-roi-44242770814/root-review.json').read_bytes(),
    'review/qualification-authorization.json':(EVIDENCE.parent/'candle-isolated-roi-44242770814/root-qualification-authorization.json').read_bytes()})
for relative,raw in sorted(extra.items()):
    assert relative not in decision['archives']
    target=destination/(relative+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(raw,mtime=0))
    assert gzip.decompress(target.read_bytes())==raw
    decision['archives'][relative]=dict(sha256=sha(raw),archive=target.relative_to(PUBLISHER).as_posix())
decision.update(root_authentication_passed=True,criterion_amendment_approved=False,closure_ledger_new_rows=0,
    accepted_closure_credit=0,counterfactual_proposal_is_not_acceptance=True)
decision_path.write_bytes(encoded(decision))
for relative,binding in decision['archives'].items():
    path=PUBLISHER/binding['archive'];assert path.resolve().is_relative_to(destination.resolve())
    packed=path.read_bytes();assert packed[4:8]==b'\0'*4 and sha(gzip.decompress(packed))==binding['sha256']
assert set(path.relative_to(destination).as_posix() for path in destination.rglob('*') if path.is_file())==set(
    (relative+'.gz') for relative in decision['archives'])|{'decision.json','verified-summary.json','.gitattributes'}
assert all(path.suffix=='.gz' or path.name in ('decision.json','verified-summary.json','.gitattributes') for path in destination.rglob('*') if path.is_file())
assert not git(PUBLISHER,'diff','--name-only',BASE,'--','src','tests','.github','scripts','benchmarks/results/remaining-indicators/hosted-targeted-44229597200-attempt1')
assert q.roi.common.source_fingerprint(BASE)==fingerprint
proof=dict(status='original-rejected-archive-prepared-for-root-review',publisher=str(PUBLISHER),base=BASE,
    destination=str(destination),run_id=RUN,workflow_head=FROZEN,gzip_entries=len(decision['archives']),
    total_files=len(decision['archives'])+3,decision_sha256=sha(decision_path.read_bytes()),summary_sha256=SUMMARY_SHA,
    live_source_fingerprint=fingerprint,source_patch_sha256=sha(source_patch),source_gate=True,native_gate=False,
    accepted=False,closure_credit=0,criterion_amendment_approved=False,production_integrated=False,pushed=False)
path=OPS/'rejected-seven-candle-archive-44245783811-proof.json';assert not path.exists();path.write_bytes(encoded(proof))
print(json.dumps(proof,indent=2))
