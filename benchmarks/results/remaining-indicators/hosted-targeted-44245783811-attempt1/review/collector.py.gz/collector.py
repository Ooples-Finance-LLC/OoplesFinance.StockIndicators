"""Authenticate one explicit completed run: bulk on Z, verified existing runtimes on C."""
import hashlib,json,os,shutil,stat,subprocess,sys,tempfile,traceback,zipfile
from pathlib import Path,PurePosixPath

RUN,HEAD=sys.argv[1:]
assert RUN=='44245783811' and HEAD=='ab5370a6a0706c8b4390418a618eab36ebd99c48'
REMOTE='Ooples-Finance-LLC/OoplesFinance.StockIndicators'
REPO=Path(r'C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-seven-candle-word-qualification-20261118')
OPS=Path(r'C:\Users\cheat\source\stock-indicators-operations\seven-candle-word-qualification-20261118')
OUT=Path('Z:/StockIndicators-Archives/active-performance-evidence')/('seven-candle-word-qualification-'+RUN)
PREP=OPS/('hosted-inputs-'+RUN)
RAW=OUT/'raw'/'evidence'
BASELINE=Path(r'C:\Users\cheat\source\stock-indicators-operations\pr266-master-reconcile-20261117\authenticated-input-44217513798')
CANDIDATE=Path(r'C:\Users\cheat\source\stock-indicators-operations\candle-word-dispatch-correctness-20261118\authenticated-input-44239677318')
PLAN=REPO/'benchmarks/plans/hosted-seven-candle-word-qualification-20261118.json'
PLAN_SHA='8c230c36187f4f25b34fb3408b3d7df514b4983c8a937204a913fc984b555031'

def gh(*args):return subprocess.check_output(['gh',*args],cwd=REPO)
def api(path):return json.loads(gh('api','repos/'+REMOTE+'/'+path))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def write(path,data):path.write_bytes((json.dumps(data,indent=2)+'\n').encode())
def verifier_bound():
    assert digest(PLAN)==PLAN_SHA
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==HEAD
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=REPO)

verifier_bound()
state=api('actions/runs/'+RUN)
assert str(state['id'])==RUN and state['head_sha']==HEAD and state['event']=='push' and state['run_attempt']==1
assert state['head_branch']=='perf/seven-candle-word-qualification-20261118'
assert state['path']=='.github/workflows/seven-candle-word-qualification.yml'
assert state['status']=='completed','Collector requires actual completion'
assert state['conclusion']=='success','Failed workflow cannot authorize qualification acceptance'
jobs=api('actions/runs/'+RUN+'/jobs')['jobs'];assert len(jobs)==1 and jobs[0]['name']=='qualify'
assert not OUT.exists() and not PREP.exists(),'Fresh single-run outputs only; preserve failures, no automatic reruns'
items=api('actions/runs/'+RUN+'/artifacts')['artifacts']
items=[item for item in items if item['name']=='seven-candle-word-qualification' and not item['expired']]
assert len(items)==1;artifact=items[0]
assert str(artifact['workflow_run']['id'])==RUN and artifact['workflow_run']['head_sha']==HEAD
assert artifact['digest'].startswith('sha256:')
OUT.mkdir(parents=True);write(OUT/'run-api.json',state);write(OUT/'artifact-api.json',artifact)
partial=OUT/'artifact.zip.partial'
with partial.open('xb') as stream:
    subprocess.run(['gh','api',f"repos/{REMOTE}/actions/artifacts/{artifact['id']}/zip"],cwd=REPO,stdout=stream,check=True)
    stream.flush();os.fsync(stream.fileno())
assert digest(partial)==artifact['digest'][7:]
partial.rename(OUT/'artifact.zip')

try:
    os.environ['HOSTED_TIMING_PLAN']=str(PLAN);sys.path.insert(0,str(REPO/'scripts'))
    from hosted_timing import seven_candle_qualification as q
    with zipfile.ZipFile(OUT/'artifact.zip') as package:
        entries=[entry for entry in package.infolist() if not entry.is_dir()]
        files={entry.filename:entry for entry in entries}
        assert len(files)==len(entries)==len({name.casefold() for name in files})
        for name,entry in files.items():
            rel=PurePosixPath(name)
            assert not rel.is_absolute() and '..' not in rel.parts and ':' not in name and '\\' not in name
            assert all(part not in ('.','..') and not part.endswith(('.',' ')) for part in rel.parts)
            assert not stat.S_ISLNK(entry.external_attr>>16)
        prep_prefix='seven-candle-inputs/'
        raw_prefix='seven-candle-qualification/evidence/'
        prepared={name[len(prep_prefix):]:entry for name,entry in files.items() if name.startswith(prep_prefix)}
        raw={name[len(raw_prefix):]:entry for name,entry in files.items() if name.startswith(raw_prefix+'shard0/')}
        hosted_name='seven-candle-qualification/summary.json'
        assert prepared and raw and hosted_name in files
        proof=json.loads(package.read(prep_prefix+'provenance.json'))
        assert str(proof['run_id'])==RUN and str(proof['run_attempt'])=='1' and proof['workflow_head']==HEAD
        assert proof['plan_sha256']==PLAN_SHA and proof['sources']==q.p.read(PLAN)['sources']
        shard=json.loads(package.read(raw_prefix+'shard0/provenance.json'))
        assert shard['input_provenance_sha256']==sha(package.read(prep_prefix+'provenance.json'))
        runtime_files={};classified={prep_prefix+name for name in prepared}|{raw_prefix+name for name in raw}|{hosted_name}
        for arm in ('old','new'):
            prefix=raw_prefix+'shard0-runtime-'+arm+'/'
            actual={name[len(prefix):]:entry for name,entry in files.items() if name.startswith(prefix)}
            declared=shard['binary_manifest'][arm];assert set(actual)==set(declared)
            for relative,entry in actual.items():
                expected=declared[relative];assert sha(package.read(entry))==expected
                runtime_files[entry.filename]=expected;classified.add(entry.filename)
        assert classified==set(files),'Every uploaded file must have an authenticated role'
        cache={}
        for folder in (BASELINE/'blobs',CANDIDATE/'blobs'):
            assert folder.is_dir()
            paths=[path for path in folder.rglob('*') if path.is_file()];assert len(paths)==312
            for path in paths:
                assert len(path.name)==64 and all(c in '0123456789abcdef' for c in path.name)
                cache.setdefault(path.name,path)
        def payload(relative):return relative.startswith(('common/','production/')) or '/blobs/' in relative
        metadata_bytes=sum(entry.file_size for relative,entry in prepared.items() if not payload(relative))
        OPS.mkdir(parents=True,exist_ok=True)
        assert shutil.disk_usage(OPS).free>=metadata_bytes+128*1024*1024,'C metadata plus 128MiB verification budget required'
        scratch=OPS/('verification-temp-'+RUN);assert not scratch.exists();scratch.mkdir()
        os.environ.update(TEMP=str(scratch),TMP=str(scratch));tempfile.tempdir=str(scratch)
        PREP.mkdir();RAW.mkdir(parents=True);links=0;verified_cache=set();prepared_manifest={};raw_manifest={}
        for relative,entry in prepared.items():
            target=PREP.joinpath(*PurePosixPath(relative).parts);assert target.resolve().is_relative_to(PREP.resolve())
            target.parent.mkdir(parents=True,exist_ok=True);data=package.read(entry);expected=sha(data)
            if payload(relative):
                assert expected in cache,'No new runtime payload may be installed: '+relative
                if expected not in verified_cache:
                    assert digest(cache[expected])==expected;verified_cache.add(expected)
                os.link(cache[expected],target);links+=1
            else:target.write_bytes(data)
            assert digest(target)==expected;prepared_manifest[relative]=expected
        for relative,entry in raw.items():
            target=RAW.joinpath(*PurePosixPath(relative).parts);assert target.resolve().is_relative_to(RAW.resolve())
            assert target.suffix.lower() not in ('.dll','.exe','.pdb'),'No runtime extraction to Z'
            target.parent.mkdir(parents=True,exist_ok=True);data=package.read(entry);target.write_bytes(data)
            raw_manifest[relative]=sha(data)
        hosted_raw=package.read(hosted_name);(OUT/'uploaded-summary.json').write_bytes(hosted_raw);hosted=json.loads(hosted_raw)
        write(OUT/'materialization-manifest.json',dict(prepared=prepared_manifest,raw=raw_manifest,runtime_zip_payloads=runtime_files,uploaded_summary_sha256=sha(hosted_raw)))
        assert len(prepared_manifest)+len(raw_manifest)+len(runtime_files)+1==len(files)
        verifier_bound();result=q.collect(RAW,inputs=PREP);verifier_bound()
        assert json.loads(json.dumps(result,allow_nan=False))==hosted
        assert (result['case_count'],result['decision_count'])==(198,42)
        assert result['input_provenance_sha256']==q.p.digest(PREP/'provenance.json')
        assert result['accepted']==(result['source_gate_accepted'] and result['native_progress_gate_passed'])
        assert result['existing_two_crows_recounted'] is False
        assert result['new_closure_credit_pairs']==(q.REQUIRED if result['accepted'] else [])
        q.p.write(OUT/'authenticated-summary.json',result)
        receipt=dict(status='complete-single-run-independently-authenticated',run_id=RUN,run_attempt=1,head=HEAD,
            artifact_id=artifact['id'],artifact_zip_sha256=artifact['digest'][7:],zip_files_verified=len(files),
            prepared=str(PREP),raw=str(RAW),runtime_hardlinks=links,new_runtime_payload_bytes=0,
            runtime_zip_payload_files_verified=len(runtime_files),verification_temp=str(scratch),
            plan_sha256=PLAN_SHA,prepared_provenance_sha256=q.p.digest(PREP/'provenance.json'),
            fixture_inventory_sha256=q.p.digest(PREP/'fixture-method-inventory.json'),
            summary_sha256=q.p.digest(OUT/'authenticated-summary.json'),hosted_summary_equal_independent=True,
            cases=result['case_count'],decisions=result['decision_count'],verdicts=result['verdicts'],
            source_gate_accepted=result['source_gate_accepted'],native_progress_gate_passed=result['native_progress_gate_passed'],
            native_progress_gate=result['native_progress_gate'],accepted_by_collector=result['accepted'],
            candidate_closure_credit_pairs=result['new_closure_credit_pairs'],root_authentication_pending=True,
            closure_ledger_new_rows=0,source_integrated=False,new_measurements=0)
        q.p.write(OUT/'collection-receipt.json',receipt);print(json.dumps(receipt,indent=2))
except BaseException as error:
    write(OUT/'collection-failure.json',dict(run_id=RUN,head=HEAD,error=str(error),traceback=traceback.format_exc(),
        source_zip_preserved=True,automatic_retry_allowed=False,qualification_claimed=False))
    raise
