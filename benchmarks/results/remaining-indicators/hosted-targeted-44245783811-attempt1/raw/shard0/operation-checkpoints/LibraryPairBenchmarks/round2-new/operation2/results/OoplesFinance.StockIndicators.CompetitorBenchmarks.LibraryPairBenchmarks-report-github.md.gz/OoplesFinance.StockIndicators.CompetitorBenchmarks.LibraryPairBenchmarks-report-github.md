```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Crows [31]** |  **40.26 μs** |  **1.414 μs** | **0.841 μs** |  **1.00** |    **0.03** |  **65.13 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Crows [31] |  42.72 μs |  0.953 μs | 0.567 μs |  1.06 |    0.02 |  17.28 KB |        0.27 |
|            |       |                      |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Crows [31]** |  **87.20 μs** |  **3.222 μs** | **1.685 μs** |  **1.00** |    **0.03** | **637.23 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Crows [31] | 423.31 μs | 12.046 μs | 7.968 μs |  4.86 |    0.12 | 122.47 KB |        0.19 |
