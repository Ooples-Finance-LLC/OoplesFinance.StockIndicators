```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)River [30]** |  **76.40 μs** | **2.814 μs** | **1.472 μs** |  **1.00** |    **0.03** |  **68.66 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)River [30] |  45.69 μs | 0.985 μs | 0.515 μs |  0.60 |    0.01 |     17 KB |        0.25 |
|            |       |                      |           |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)River [30]** | **128.78 μs** | **3.799 μs** | **1.987 μs** |  **1.00** |    **0.02** | **638.67 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)River [30] | 452.71 μs | 4.242 μs | 2.525 μs |  3.52 |    0.05 | 122.14 KB |        0.19 |
