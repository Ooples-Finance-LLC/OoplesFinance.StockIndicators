```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)ottom [26]** | **309.16 μs** | **32.742 μs** | **19.484 μs** |  **1.00** |    **0.08** |  **68.77 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)ottom [26] |  22.07 μs |  0.490 μs |  0.292 μs |  0.07 |    0.00 |  19.91 KB |        0.29 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)ottom [26]** | **261.12 μs** | **14.155 μs** |  **8.424 μs** |  **1.00** |    **0.04** | **639.07 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)ottom [26] | 198.72 μs |  1.246 μs |  0.741 μs |  0.76 |    0.02 | 121.44 KB |        0.19 |
