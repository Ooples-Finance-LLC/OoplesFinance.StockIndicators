```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Crows [22]** |  **40.54 μs** | **1.881 μs** | **1.119 μs** |  **1.00** |    **0.04** |  **65.13 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Crows [22] |  27.96 μs | 0.662 μs | 0.346 μs |  0.69 |    0.02 |  17.28 KB |        0.27 |
|            |       |                      |           |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Crows [22]** |  **93.55 μs** | **0.670 μs** | **0.351 μs** |  **1.00** |    **0.00** | **639.28 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Crows [22] | 265.34 μs | 1.459 μs | 0.763 μs |  2.84 |    0.01 | 124.06 KB |        0.19 |
