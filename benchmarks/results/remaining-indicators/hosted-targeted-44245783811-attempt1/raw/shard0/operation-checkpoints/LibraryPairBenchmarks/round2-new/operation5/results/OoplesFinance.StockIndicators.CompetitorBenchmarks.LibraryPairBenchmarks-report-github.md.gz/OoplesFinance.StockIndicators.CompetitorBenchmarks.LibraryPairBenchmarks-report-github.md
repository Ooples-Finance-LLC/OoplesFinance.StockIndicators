```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)allow [35]** | **212.61 μs** | **15.307 μs** | **9.109 μs** |  **1.00** |    **0.06** |  **68.77 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)allow [35] |  47.11 μs |  0.505 μs | 0.264 μs |  0.22 |    0.01 |  17.33 KB |        0.25 |
|            |       |                      |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)allow [35]** | **272.23 μs** | **11.825 μs** | **7.037 μs** |  **1.00** |    **0.03** | **639.07 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)allow [35] | 477.94 μs | 12.735 μs | 7.578 μs |  1.76 |    0.05 | 125.38 KB |        0.20 |
