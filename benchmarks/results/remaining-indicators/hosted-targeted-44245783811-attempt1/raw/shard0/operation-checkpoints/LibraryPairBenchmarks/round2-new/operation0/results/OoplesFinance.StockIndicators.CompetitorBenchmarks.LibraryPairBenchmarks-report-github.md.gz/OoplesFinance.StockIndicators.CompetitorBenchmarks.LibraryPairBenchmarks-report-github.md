```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nside [25]** |  **65.08 μs** | **13.208 μs** | **7.860 μs** |  **1.01** |    **0.16** |  **68.66 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nside [25] |  56.68 μs | 12.700 μs | 8.400 μs |  0.88 |    0.16 |  17.94 KB |        0.26 |
|            |       |                      |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)nside [25]** | **158.77 μs** |  **9.404 μs** | **5.596 μs** |  **1.00** |    **0.05** | **635.47 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nside [25] | 503.88 μs |  4.310 μs | 2.254 μs |  3.18 |    0.10 | 122.75 KB |        0.19 |
