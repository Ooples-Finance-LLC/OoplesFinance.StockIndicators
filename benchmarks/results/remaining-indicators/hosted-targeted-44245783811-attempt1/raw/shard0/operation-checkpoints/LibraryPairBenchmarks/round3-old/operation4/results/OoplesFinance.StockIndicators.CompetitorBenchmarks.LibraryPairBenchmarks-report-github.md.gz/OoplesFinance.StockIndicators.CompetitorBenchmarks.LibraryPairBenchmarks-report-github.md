```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean     | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |---------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)kaway [23]** | **429.7 μs** |  **20.24 μs** | **10.59 μs** |  **1.00** |    **0.03** |  **68.77 KB** |        **1.00** |
|        |       |                      |          |           |          |       |         |           |             |
| **Ooples** | **10000** | **TaLib(...)kaway [23]** | **475.6 μs** | **156.45 μs** | **93.10 μs** |  **1.03** |    **0.25** | **638.73 KB** |        **1.00** |
