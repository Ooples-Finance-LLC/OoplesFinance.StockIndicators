```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)kaway [23]** | **338.01 μs** | **79.724 μs** | **52.733 μs** |  **1.02** |    **0.21** |  **68.77 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)kaway [23] |  35.96 μs |  1.032 μs |  0.540 μs |  0.11 |    0.02 |  16.95 KB |        0.25 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)kaway [23]** |  **93.73 μs** | **15.683 μs** |  **9.333 μs** |  **1.01** |    **0.13** | **637.29 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)kaway [23] | 352.62 μs |  9.592 μs |  5.708 μs |  3.79 |    0.32 | 121.77 KB |        0.19 |
