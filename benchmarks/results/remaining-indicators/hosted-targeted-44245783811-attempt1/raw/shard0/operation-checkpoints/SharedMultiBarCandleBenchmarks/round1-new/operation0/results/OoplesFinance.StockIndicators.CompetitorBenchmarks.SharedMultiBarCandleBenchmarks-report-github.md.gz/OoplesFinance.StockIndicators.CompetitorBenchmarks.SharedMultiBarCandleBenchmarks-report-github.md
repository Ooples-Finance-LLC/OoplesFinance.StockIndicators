```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation            | Mean     | Error   | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |------ |--------------------- |---------:|--------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **TaLib(...)kaway [23]** | **119.5 μs** | **7.54 μs** | **4.99 μs** |  **3.9063** |       **-** |  **64.47 KB** |
| BuilderLatestOnly | 1000  | TaLib(...)kaway [23] | 114.7 μs | 2.37 μs | 1.41 μs |  0.9766 |       - |  16.59 KB |
| **BuilderFull**       | **10000** | **TaLib(...)kaway [23]** | **129.9 μs** | **1.59 μs** | **0.83 μs** | **33.2031** | **10.7422** | **551.55 KB** |
| BuilderLatestOnly | 10000 | TaLib(...)kaway [23] | 115.9 μs | 2.13 μs | 1.11 μs |  4.8828 |  0.9766 |  81.45 KB |
