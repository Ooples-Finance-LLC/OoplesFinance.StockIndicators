```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation            | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------ |--------------------- |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **TaLib(...)kaway [23]** | **118.4 μs** |  **5.03 μs** |  **2.63 μs** |  **3.9063** |       **-** |  **64.47 KB** |
| BuilderLatestOnly | 1000  | TaLib(...)kaway [23] | 113.3 μs |  1.66 μs |  0.87 μs |  0.9766 |       - |  16.59 KB |
| **BuilderFull**       | **10000** | **TaLib(...)kaway [23]** | **499.1 μs** | **45.07 μs** | **29.81 μs** | **31.2500** | **11.7188** | **557.04 KB** |
| BuilderLatestOnly | 10000 | TaLib(...)kaway [23] | 457.7 μs | 22.09 μs | 13.14 μs |  3.9063 |       - |  86.93 KB |
