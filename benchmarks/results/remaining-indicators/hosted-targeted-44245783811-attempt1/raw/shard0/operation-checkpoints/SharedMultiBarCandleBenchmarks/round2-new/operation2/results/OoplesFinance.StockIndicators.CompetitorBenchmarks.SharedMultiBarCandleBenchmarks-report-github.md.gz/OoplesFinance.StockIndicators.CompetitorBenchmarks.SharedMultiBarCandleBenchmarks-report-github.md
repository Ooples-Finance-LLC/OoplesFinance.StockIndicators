```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation            | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------ |--------------------- |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **TaLib(...)ottom [26]** | **103.9 μs** |  **2.04 μs** |  **1.07 μs** |  **3.9063** |       **-** |  **64.47 KB** |
| BuilderLatestOnly | 1000  | TaLib(...)ottom [26] | 104.2 μs |  6.26 μs |  4.14 μs |  0.9766 |       - |  16.59 KB |
| **BuilderFull**       | **10000** | **TaLib(...)ottom [26]** | **355.1 μs** | **55.06 μs** | **36.42 μs** | **31.2500** | **11.7188** | **557.04 KB** |
| BuilderLatestOnly | 10000 | TaLib(...)ottom [26] | 317.1 μs | 26.01 μs | 17.21 μs |  3.9063 |       - |  86.92 KB |
