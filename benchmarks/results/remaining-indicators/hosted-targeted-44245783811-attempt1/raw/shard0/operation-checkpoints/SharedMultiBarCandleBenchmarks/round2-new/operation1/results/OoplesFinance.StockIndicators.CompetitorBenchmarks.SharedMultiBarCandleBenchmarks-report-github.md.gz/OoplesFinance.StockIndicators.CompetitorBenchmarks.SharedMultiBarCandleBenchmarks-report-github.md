```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation            | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------ |--------------------- |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **TaLib(...)allow [35]** | **106.56 μs** | **12.367 μs** |  **7.359 μs** |  **3.9063** |       **-** |  **64.43 KB** |
| BuilderLatestOnly | 1000  | TaLib(...)allow [35] |  99.96 μs |  2.050 μs |  1.072 μs |  0.9766 |       - |  16.59 KB |
| **BuilderFull**       | **10000** | **TaLib(...)allow [35]** | **326.24 μs** |  **5.714 μs** |  **2.989 μs** | **31.2500** | **11.7188** |    **557 KB** |
| BuilderLatestOnly | 10000 | TaLib(...)allow [35] | 319.30 μs | 25.013 μs | 16.545 μs |  3.9063 |       - |  86.92 KB |
