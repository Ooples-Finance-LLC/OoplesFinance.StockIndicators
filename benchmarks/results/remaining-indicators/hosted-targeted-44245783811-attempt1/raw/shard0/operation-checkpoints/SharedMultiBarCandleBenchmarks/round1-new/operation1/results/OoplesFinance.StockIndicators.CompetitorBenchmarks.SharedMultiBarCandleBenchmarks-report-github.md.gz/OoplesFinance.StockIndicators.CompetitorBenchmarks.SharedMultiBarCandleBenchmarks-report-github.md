```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation            | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------ |--------------------- |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **TaLib(...)allow [35]** | **106.0 μs** |  **8.13 μs** |  **4.84 μs** |  **3.9063** |       **-** |  **64.44 KB** |
| BuilderLatestOnly | 1000  | TaLib(...)allow [35] | 101.3 μs |  4.03 μs |  2.67 μs |  0.9766 |       - |  16.59 KB |
| **BuilderFull**       | **10000** | **TaLib(...)allow [35]** | **338.3 μs** | **15.72 μs** |  **8.22 μs** | **31.2500** | **11.7188** | **557.01 KB** |
| BuilderLatestOnly | 10000 | TaLib(...)allow [35] | 313.7 μs | 26.82 μs | 17.74 μs |  3.9063 |       - |  86.92 KB |
