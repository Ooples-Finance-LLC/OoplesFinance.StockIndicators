```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nside [25]** | **1000**  | **134.4 μs** | **24.16 μs** | **15.98 μs** |  **3.9063** |       **-** |  **64.25 KB** |
| BuilderLatestOnly | TaLib(...)nside [25] | 1000  | 111.0 μs |  2.85 μs |  1.49 μs |  0.9766 |       - |  16.38 KB |
| **BuilderFull**       | **TaLib(...)nside [25]** | **10000** | **421.3 μs** |  **9.64 μs** |  **5.04 μs** | **31.2500** | **11.7188** | **556.82 KB** |
| BuilderLatestOnly | TaLib(...)nside [25] | 10000 | 437.2 μs | 39.80 μs | 26.33 μs |  3.9063 |       - |  86.71 KB |
