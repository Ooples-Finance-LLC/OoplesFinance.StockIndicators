```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)River [30]** | **1000**  |  **88.82 μs** |  **2.710 μs** |  **1.612 μs** |  **2.9297** |       **-** |  **62.49 KB** |
| BuilderLatestOnly | TaLib(...)River [30] | 1000  |  85.06 μs |  1.334 μs |  0.794 μs |  0.4883 |       - |  14.61 KB |
| **BuilderFull**       | **TaLib(...)River [30]** | **10000** | **214.63 μs** |  **3.343 μs** |  **1.749 μs** | **33.2031** | **13.6719** |  **556.8 KB** |
| BuilderLatestOnly | TaLib(...)River [30] | 10000 | 204.54 μs | 16.438 μs | 10.873 μs |  3.9063 |       - |   86.7 KB |
