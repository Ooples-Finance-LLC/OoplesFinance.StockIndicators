```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error   | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |---------:|--------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nside [25]** | **1000**  | **112.1 μs** | **3.08 μs** | **1.61 μs** |  **3.9063** |       **-** |  **64.25 KB** |
| BuilderLatestOnly | TaLib(...)nside [25] | 1000  | 115.5 μs | 4.32 μs | 2.86 μs |  0.9766 |       - |  16.38 KB |
| **BuilderFull**       | **TaLib(...)nside [25]** | **10000** | **431.2 μs** | **5.92 μs** | **3.09 μs** | **31.2500** | **11.7188** | **556.82 KB** |
| BuilderLatestOnly | TaLib(...)nside [25] | 10000 | 421.2 μs | 6.26 μs | 3.27 μs |  3.9063 |       - |  86.71 KB |
