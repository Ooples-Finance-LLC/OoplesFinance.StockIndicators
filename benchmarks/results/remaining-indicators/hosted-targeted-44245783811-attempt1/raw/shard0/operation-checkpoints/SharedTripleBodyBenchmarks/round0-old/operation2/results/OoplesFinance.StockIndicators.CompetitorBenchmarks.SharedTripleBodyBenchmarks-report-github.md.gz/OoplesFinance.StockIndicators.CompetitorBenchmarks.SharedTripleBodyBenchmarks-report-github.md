```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)Crows [31]** | **1000**  |  **89.63 μs** |  **2.221 μs** | **1.322 μs** |  **2.9297** |       **-** |  **62.49 KB** |
| BuilderLatestOnly | TaLib(...)Crows [31] | 1000  |  87.22 μs |  3.540 μs | 2.341 μs |  0.4883 |       - |  14.61 KB |
| **BuilderFull**       | **TaLib(...)Crows [31]** | **10000** | **200.63 μs** | **12.255 μs** | **7.292 μs** | **33.2031** | **13.6719** |  **556.8 KB** |
| BuilderLatestOnly | TaLib(...)Crows [31] | 10000 | 189.01 μs | 10.984 μs | 7.265 μs |  4.8828 |  0.9766 |  86.69 KB |
