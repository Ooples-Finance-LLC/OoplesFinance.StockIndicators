```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)nside [25]** | **1000**  |  **38.01 μs** |  **0.943 μs** |  **0.493 μs** |  **1.00** |    **0.02** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)nside [25] | 1000  |  94.94 μs |  0.666 μs |  0.348 μs |  2.50 |    0.03 |       - |       - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib(...)nside [25] | 1000  | 114.62 μs |  1.049 μs |  0.549 μs |  3.02 |    0.04 |  3.9063 |       - |  64.26 KB |       16.19 |
| BuilderLatestOnly | TaLib(...)nside [25] | 1000  | 113.40 μs |  4.593 μs |  3.038 μs |  2.98 |    0.08 |  0.9766 |       - |  16.38 KB |        4.13 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)nside [25]** | **10000** | **380.47 μs** |  **2.418 μs** |  **1.265 μs** |  **1.00** |    **0.00** |       **-** |       **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)nside [25] | 10000 | 293.27 μs | 25.733 μs | 17.021 μs |  0.77 |    0.04 |  5.8594 |       - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib(...)nside [25] | 10000 | 426.83 μs | 10.389 μs |  5.434 μs |  1.12 |    0.01 | 31.2500 | 11.7188 | 556.82 KB |       14.22 |
| BuilderLatestOnly | TaLib(...)nside [25] | 10000 | 429.29 μs | 29.088 μs | 19.240 μs |  1.13 |    0.05 |  3.9063 |       - |  86.71 KB |        2.21 |
