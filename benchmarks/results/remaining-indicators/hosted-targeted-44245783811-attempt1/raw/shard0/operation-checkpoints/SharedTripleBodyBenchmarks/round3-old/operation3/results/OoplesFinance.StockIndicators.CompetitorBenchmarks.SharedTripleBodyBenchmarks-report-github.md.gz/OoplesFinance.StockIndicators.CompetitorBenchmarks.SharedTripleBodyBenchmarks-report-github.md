```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)River [30]** | **1000**  |  **89.15 μs** |  **2.903 μs** | **1.920 μs** |  **2.9297** |       **-** |  **62.49 KB** |
| BuilderLatestOnly | TaLib(...)River [30] | 1000  |  85.65 μs |  2.010 μs | 1.196 μs |  0.4883 |       - |  14.61 KB |
| **BuilderFull**       | **TaLib(...)River [30]** | **10000** | **221.80 μs** |  **3.762 μs** | **1.967 μs** | **33.2031** | **13.6719** |  **556.8 KB** |
| BuilderLatestOnly | TaLib(...)River [30] | 10000 | 207.21 μs | 14.767 μs | 9.767 μs |  3.9063 |       - |   86.7 KB |
