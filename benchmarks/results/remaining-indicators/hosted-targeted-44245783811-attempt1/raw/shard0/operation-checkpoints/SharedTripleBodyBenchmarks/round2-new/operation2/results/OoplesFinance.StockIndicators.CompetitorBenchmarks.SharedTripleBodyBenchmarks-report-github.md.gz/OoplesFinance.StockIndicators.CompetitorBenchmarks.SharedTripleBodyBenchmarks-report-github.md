```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)Crows [31]** | **1000**  |  **49.56 μs** |  **0.294 μs** |  **0.175 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)Crows [31] | 1000  |  92.81 μs |  0.717 μs |  0.375 μs |  1.87 |    0.01 |       - |       - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib(...)Crows [31] | 1000  |  89.57 μs |  3.812 μs |  2.522 μs |  1.81 |    0.05 |  2.9297 |       - |  62.49 KB |       15.75 |
| BuilderLatestOnly | TaLib(...)Crows [31] | 1000  |  86.11 μs |  2.102 μs |  1.251 μs |  1.74 |    0.02 |       - |       - |  14.61 KB |        3.68 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)Crows [31]** | **10000** | **362.04 μs** |  **9.311 μs** |  **6.158 μs** |  **1.00** |    **0.02** |  **1.9531** |       **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib(...)Crows [31] | 10000 | 272.23 μs | 16.908 μs | 11.183 μs |  0.75 |    0.03 |  5.8594 |       - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib(...)Crows [31] | 10000 | 206.77 μs | 17.935 μs | 11.863 μs |  0.57 |    0.03 | 33.2031 | 13.6719 |  556.8 KB |       14.23 |
| BuilderLatestOnly | TaLib(...)Crows [31] | 10000 | 189.59 μs |  8.124 μs |  5.373 μs |  0.52 |    0.02 |  4.8828 |  0.9766 |  86.69 KB |        2.22 |
