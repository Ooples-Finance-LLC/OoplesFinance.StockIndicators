```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)River [30]** | **1000**  |  **36.59 μs** |  **0.092 μs** |  **0.048 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)River [30] | 1000  |  94.04 μs |  0.901 μs |  0.471 μs |  2.57 |    0.01 |       - |       - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib(...)River [30] | 1000  |  88.73 μs |  2.609 μs |  1.726 μs |  2.43 |    0.05 |  2.9297 |       - |  62.49 KB |       15.75 |
| BuilderLatestOnly | TaLib(...)River [30] | 1000  |  85.28 μs |  1.924 μs |  1.273 μs |  2.33 |    0.03 |  0.4883 |       - |  14.61 KB |        3.68 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)River [30]** | **10000** | **378.60 μs** | **13.239 μs** |  **8.756 μs** |  **1.00** |    **0.03** |  **1.9531** |       **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib(...)River [30] | 10000 | 277.66 μs | 16.297 μs | 10.779 μs |  0.73 |    0.03 |  5.8594 |       - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib(...)River [30] | 10000 | 214.01 μs |  3.225 μs |  1.687 μs |  0.57 |    0.01 | 33.2031 | 13.6719 |  556.8 KB |       14.23 |
| BuilderLatestOnly | TaLib(...)River [30] | 10000 | 201.84 μs | 10.436 μs |  6.210 μs |  0.53 |    0.02 |  3.9063 |       - |   86.7 KB |        2.22 |
