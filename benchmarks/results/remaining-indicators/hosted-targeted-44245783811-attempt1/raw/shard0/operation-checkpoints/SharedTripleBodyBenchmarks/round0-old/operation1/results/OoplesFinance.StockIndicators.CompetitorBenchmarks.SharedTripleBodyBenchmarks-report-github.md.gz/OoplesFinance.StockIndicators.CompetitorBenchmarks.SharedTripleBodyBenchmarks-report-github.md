```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)Crows [22]** | **1000**  |  **92.43 μs** | **5.518 μs** | **3.284 μs** |  **2.9297** |       **-** |  **62.45 KB** |
| BuilderLatestOnly | TaLib(...)Crows [22] | 1000  |  87.89 μs | 1.587 μs | 1.049 μs |  0.4883 |       - |  14.61 KB |
| **BuilderFull**       | **TaLib(...)Crows [22]** | **10000** | **187.96 μs** | **3.369 μs** | **1.762 μs** | **33.2031** | **13.6719** | **556.76 KB** |
| BuilderLatestOnly | TaLib(...)Crows [22] | 10000 | 170.13 μs | 5.284 μs | 3.495 μs |  4.8828 |  0.9766 |  86.69 KB |
