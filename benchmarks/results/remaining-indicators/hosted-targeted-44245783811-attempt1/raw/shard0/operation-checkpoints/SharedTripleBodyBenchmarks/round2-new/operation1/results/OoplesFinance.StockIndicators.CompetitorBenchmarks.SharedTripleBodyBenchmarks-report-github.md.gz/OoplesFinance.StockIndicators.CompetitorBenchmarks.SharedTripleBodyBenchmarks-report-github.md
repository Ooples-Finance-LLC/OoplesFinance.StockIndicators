```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev   | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|---------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)Crows [22]** | **1000**  |  **18.81 μs** |  **0.064 μs** | **0.038 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)Crows [22] | 1000  |  86.75 μs |  1.950 μs | 1.290 μs |  4.61 |    0.07 |  0.4883 |       - |    8.4 KB |        2.12 |
| BuilderFull       | TaLib(...)Crows [22] | 1000  |  90.35 μs |  2.286 μs | 1.512 μs |  4.80 |    0.08 |  2.9297 |       - |  62.49 KB |       15.75 |
| BuilderLatestOnly | TaLib(...)Crows [22] | 1000  |  87.79 μs |  1.485 μs | 0.982 μs |  4.67 |    0.05 |  0.4883 |       - |  14.61 KB |        3.68 |
|                   |                      |       |           |           |          |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)Crows [22]** | **10000** | **203.60 μs** |  **0.683 μs** | **0.407 μs** |  **1.00** |    **0.00** |  **1.9531** |       **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib(...)Crows [22] | 10000 | 179.41 μs |  9.497 μs | 5.651 μs |  0.88 |    0.03 |  5.8594 |       - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib(...)Crows [22] | 10000 | 185.45 μs | 10.982 μs | 7.264 μs |  0.91 |    0.03 | 33.2031 | 13.6719 | 556.79 KB |       14.23 |
| BuilderLatestOnly | TaLib(...)Crows [22] | 10000 | 170.24 μs | 11.520 μs | 7.619 μs |  0.84 |    0.04 |  4.8828 |  0.9766 |  86.69 KB |        2.21 |
