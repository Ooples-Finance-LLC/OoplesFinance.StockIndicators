```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error      | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |---------------- |------ |----------:|-----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **ThreeBlackCrows** | **1000**  |  **71.06 μs** |  **19.310 μs** | **12.773 μs** |  **3.9063** |      **-** |  **65.66 KB** |
| BuilderLatestOnly | ThreeBlackCrows | 1000  |  42.74 μs |   4.656 μs |  2.435 μs |  0.9766 |      - |  17.78 KB |
| **BuilderFull**       | **ThreeBlackCrows** | **10000** | **365.98 μs** |  **35.475 μs** | **21.110 μs** | **33.2031** | **9.7656** | **558.21 KB** |
| BuilderLatestOnly | ThreeBlackCrows | 10000 | 399.89 μs | 101.033 μs | 66.827 μs |  3.9063 |      - |  88.11 KB |
