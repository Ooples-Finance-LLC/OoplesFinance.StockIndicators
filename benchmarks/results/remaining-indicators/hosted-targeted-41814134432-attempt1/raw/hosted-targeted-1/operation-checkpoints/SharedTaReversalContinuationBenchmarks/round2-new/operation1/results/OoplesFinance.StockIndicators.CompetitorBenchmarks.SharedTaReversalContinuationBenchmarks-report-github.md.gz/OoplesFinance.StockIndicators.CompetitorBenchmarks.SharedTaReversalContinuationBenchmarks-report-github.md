```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **IdenticalThreeCrows** | **1000**  | **102.84 μs** | **19.983 μs** | **13.217 μs** |  **1.04** |    **0.13** |  **3.9063** |       **-** |  **68.14 KB** |       **17.16** |
| BuilderLatestOnly | IdenticalThreeCrows | 1000  |  71.70 μs |  4.931 μs |  3.262 μs |  0.73 |    0.04 |  0.9766 |       - |  20.21 KB |        5.09 |
| NativeSingle      | IdenticalThreeCrows | 1000  |  98.53 μs |  4.257 μs |  2.816 μs |  1.00 |    0.04 |       - |       - |   3.97 KB |        1.00 |
| NativeParallel    | IdenticalThreeCrows | 1000  |  82.43 μs |  7.316 μs |  4.839 μs |  0.84 |    0.05 |  0.4883 |       - |   8.39 KB |        2.11 |
|                   |                     |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **IdenticalThreeCrows** | **10000** | **460.55 μs** | **52.360 μs** | **31.159 μs** |  **0.47** |    **0.03** | **31.2500** | **11.7188** | **560.66 KB** |       **14.31** |
| BuilderLatestOnly | IdenticalThreeCrows | 10000 | 423.97 μs | 52.766 μs | 31.400 μs |  0.44 |    0.03 |  3.9063 |       - |  90.56 KB |        2.31 |
| NativeSingle      | IdenticalThreeCrows | 10000 | 974.10 μs | 21.338 μs | 11.160 μs |  1.00 |    0.02 |       - |       - |  39.17 KB |        1.00 |
| NativeParallel    | IdenticalThreeCrows | 10000 | 624.60 μs | 97.820 μs | 64.702 μs |  0.64 |    0.06 |  3.9063 |       - |  78.73 KB |        2.01 |
