```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |-------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **IdenticalThreeCrows** | **1000**  | **103.95 μs** | **16.104 μs** | **10.652 μs** |  **3.9063** |       **-** |  **68.14 KB** |
| BuilderLatestOnly | IdenticalThreeCrows | 1000  |  76.47 μs |  3.140 μs |  1.869 μs |  0.9766 |       - |  20.21 KB |
| **BuilderFull**       | **IdenticalThreeCrows** | **10000** | **465.62 μs** | **24.914 μs** | **13.030 μs** | **31.2500** | **11.7188** | **560.65 KB** |
| BuilderLatestOnly | IdenticalThreeCrows | 10000 | 482.41 μs | 47.550 μs | 28.296 μs |  3.9063 |       - |  90.56 KB |
