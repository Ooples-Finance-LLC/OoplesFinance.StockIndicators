```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |---------------- |------ |----------:|----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **ThreeBlackCrows** | **1000**  |  **60.65 μs** | **14.325 μs** |  **9.475 μs** |  **3.9063** |      **-** |  **65.66 KB** |
| BuilderLatestOnly | ThreeBlackCrows | 1000  |  33.62 μs |  4.367 μs |  2.888 μs |  0.9766 |      - |  17.78 KB |
| **BuilderFull**       | **ThreeBlackCrows** | **10000** | **306.05 μs** | **46.086 μs** | **30.483 μs** | **33.2031** | **9.7656** | **558.21 KB** |
| BuilderLatestOnly | ThreeBlackCrows | 10000 | 303.92 μs | 47.532 μs | 31.439 μs |  3.9063 |      - |   88.1 KB |
