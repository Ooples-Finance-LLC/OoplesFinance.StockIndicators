```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error      | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |---------------- |------ |----------:|-----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **ThreeBlackCrows** | **1000**  |  **62.96 μs** |   **6.358 μs** |  **4.206 μs** |  **3.9063** |      **-** |  **65.66 KB** |
| BuilderLatestOnly | ThreeBlackCrows | 1000  |  46.83 μs |   4.922 μs |  3.256 μs |  0.9766 |      - |  17.78 KB |
| **BuilderFull**       | **ThreeBlackCrows** | **10000** | **409.26 μs** | **105.147 μs** | **69.548 μs** | **31.2500** | **7.8125** | **558.22 KB** |
| BuilderLatestOnly | ThreeBlackCrows | 10000 | 379.23 μs |  28.062 μs | 18.561 μs |  3.9063 |      - |   88.1 KB |
