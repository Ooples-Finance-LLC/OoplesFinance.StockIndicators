```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |-----------:|---------:|---------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **ThreeWhiteSoldiers** | **1000**  |   **123.4 μs** | **10.21 μs** |  **5.34 μs** |  **0.83** |    **0.03** |  **3.9063** |       **-** |  **73.64 KB** |       **18.53** |
| BuilderLatestOnly | ThreeWhiteSoldiers | 1000  |   110.2 μs |  4.07 μs |  2.69 μs |  0.74 |    0.02 |  0.9766 |       - |  25.76 KB |        6.48 |
| NativeSingle      | ThreeWhiteSoldiers | 1000  |   148.8 μs |  1.56 μs |  0.93 μs |  1.00 |    0.01 |       - |       - |   3.97 KB |        1.00 |
| NativeParallel    | ThreeWhiteSoldiers | 1000  |   124.0 μs |  8.53 μs |  5.07 μs |  0.83 |    0.03 |       - |       - |    8.4 KB |        2.11 |
|                   |                    |       |            |          |          |       |         |         |         |           |             |
| **BuilderFull**       | **ThreeWhiteSoldiers** | **10000** |   **730.5 μs** | **56.55 μs** | **37.40 μs** |  **0.47** |    **0.03** | **31.2500** | **11.7188** |  **566.2 KB** |       **14.45** |
| BuilderLatestOnly | ThreeWhiteSoldiers | 10000 |   680.6 μs | 56.04 μs | 33.35 μs |  0.44 |    0.02 |  3.9063 |       - |  96.09 KB |        2.45 |
| NativeSingle      | ThreeWhiteSoldiers | 10000 | 1,560.5 μs | 70.34 μs | 46.53 μs |  1.00 |    0.04 |       - |       - |  39.18 KB |        1.00 |
| NativeParallel    | ThreeWhiteSoldiers | 10000 |   790.4 μs | 13.60 μs |  7.12 μs |  0.51 |    0.01 |       - |       - |  78.76 KB |        2.01 |
