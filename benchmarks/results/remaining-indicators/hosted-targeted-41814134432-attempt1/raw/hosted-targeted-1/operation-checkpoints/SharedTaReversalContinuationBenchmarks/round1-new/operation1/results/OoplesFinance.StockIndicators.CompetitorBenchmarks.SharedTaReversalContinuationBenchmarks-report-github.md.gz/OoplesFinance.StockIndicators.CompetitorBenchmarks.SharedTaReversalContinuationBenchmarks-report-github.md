```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |-------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **IdenticalThreeCrows** | **1000**  |  **89.22 μs** | **15.778 μs** | **10.436 μs** |  **3.9063** |       **-** |  **68.14 KB** |
| BuilderLatestOnly | IdenticalThreeCrows | 1000  |  63.07 μs |  4.606 μs |  2.741 μs |  0.9766 |       - |  20.22 KB |
| **BuilderFull**       | **IdenticalThreeCrows** | **10000** | **446.55 μs** | **81.607 μs** | **53.978 μs** | **31.2500** | **11.7188** | **560.66 KB** |
| BuilderLatestOnly | IdenticalThreeCrows | 10000 | 440.20 μs | 36.524 μs | 21.735 μs |  3.9063 |       - |  90.55 KB |
