```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean     | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------------- |------ |---------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **ThreeWhiteSoldiers** | **1000**  | **119.4 μs** |   **5.63 μs** |  **3.35 μs** |  **3.9063** |       **-** |  **73.64 KB** |
| BuilderLatestOnly | ThreeWhiteSoldiers | 1000  | 112.4 μs |   2.06 μs |  1.23 μs |  0.9766 |       - |  25.76 KB |
| **BuilderFull**       | **ThreeWhiteSoldiers** | **10000** | **741.7 μs** |  **75.77 μs** | **45.09 μs** | **31.2500** | **15.6250** |  **566.2 KB** |
| BuilderLatestOnly | ThreeWhiteSoldiers | 10000 | 727.0 μs | 100.80 μs | 66.67 μs |  3.9063 |       - |   96.1 KB |
