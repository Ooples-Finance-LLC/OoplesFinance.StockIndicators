```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **ThreeBlackCrows** | **1000**  |  **45.10 μs** |  **8.140 μs** |  **5.384 μs** |  **0.77** |    **0.09** |  **3.9063** |      **-** |  **65.66 KB** |       **16.53** |
| BuilderLatestOnly | ThreeBlackCrows | 1000  |  35.71 μs |  4.197 μs |  2.776 μs |  0.61 |    0.05 |  0.9766 |      - |  17.78 KB |        4.47 |
| NativeSingle      | ThreeBlackCrows | 1000  |  58.92 μs |  0.284 μs |  0.149 μs |  1.00 |    0.00 |       - |      - |   3.97 KB |        1.00 |
| NativeParallel    | ThreeBlackCrows | 1000  |  49.84 μs |  6.743 μs |  4.460 μs |  0.85 |    0.07 |  0.4883 |      - |   8.42 KB |        2.12 |
|                   |                 |       |           |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **ThreeBlackCrows** | **10000** | **307.00 μs** | **31.540 μs** | **20.862 μs** |  **0.51** |    **0.03** | **33.2031** | **9.7656** | **558.21 KB** |       **14.26** |
| BuilderLatestOnly | ThreeBlackCrows | 10000 | 297.59 μs | 27.180 μs | 16.174 μs |  0.50 |    0.03 |  3.9063 |      - |   88.1 KB |        2.25 |
| NativeSingle      | ThreeBlackCrows | 10000 | 599.75 μs | 13.429 μs |  7.991 μs |  1.00 |    0.02 |       - |      - |  39.15 KB |        1.00 |
| NativeParallel    | ThreeBlackCrows | 10000 | 403.23 μs | 57.697 μs | 38.163 μs |  0.67 |    0.06 |  3.9063 |      - |  78.76 KB |        2.01 |
