```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)diers [32]** | **292.44 μs** | **25.003 μs** | **16.538 μs** |  **1.00** |    **0.08** |  **73.36 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)diers [32] |  88.06 μs |  0.638 μs |  0.334 μs |  0.30 |    0.02 |  16.63 KB |        0.23 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)diers [32]** | **400.17 μs** | **10.981 μs** |  **6.535 μs** |  **1.00** |    **0.02** | **642.96 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)diers [32] | 892.52 μs | 16.666 μs | 11.024 μs |  2.23 |    0.04 | 121.77 KB |        0.19 |
