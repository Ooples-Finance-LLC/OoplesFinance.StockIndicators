```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Crows [33]** |  **44.80 μs** |  **1.526 μs** | **0.798 μs** |  **1.00** |    **0.02** |  **70.59 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Crows [33] |  59.60 μs |  0.514 μs | 0.340 μs |  1.33 |    0.02 |  15.97 KB |        0.23 |
|            |       |                      |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Crows [33]** | **271.50 μs** | **16.101 μs** | **9.581 μs** |  **1.00** |    **0.05** | **639.23 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Crows [33] | 589.48 μs | 13.957 μs | 9.232 μs |  2.17 |    0.08 | 121.77 KB |        0.19 |
