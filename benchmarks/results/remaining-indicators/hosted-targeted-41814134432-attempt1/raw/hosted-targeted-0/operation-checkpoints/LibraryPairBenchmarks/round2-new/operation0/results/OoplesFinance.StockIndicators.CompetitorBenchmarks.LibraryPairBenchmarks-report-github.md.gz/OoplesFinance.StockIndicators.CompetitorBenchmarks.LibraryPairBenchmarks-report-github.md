```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Crows [29]** | **204.23 μs** |  **25.021 μs** |  **14.889 μs** |  **1.00** |    **0.09** |  **69.37 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Crows [29] |  38.91 μs |   0.427 μs |   0.223 μs |  0.19 |    0.01 |  15.73 KB |        0.23 |
|            |       |                      |           |            |            |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Crows [29]** | **321.80 μs** | **192.457 μs** | **127.299 μs** |  **1.16** |    **0.66** |    **639 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Crows [29] | 372.55 μs |  15.184 μs |  10.043 μs |  1.34 |    0.53 | 122.42 KB |        0.19 |
