```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean     | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |---------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)Crows [33]** | **244.2 μs** | **79.23 μs** | **52.40 μs** |  **1.04** |    **0.28** |  **70.59 KB** |        **1.00** |
|        |       |                      |          |          |          |       |         |           |             |
| **Ooples** | **10000** | **TaLib(...)Crows [33]** | **366.5 μs** | **82.83 μs** | **49.29 μs** |  **1.02** |    **0.20** | **640.88 KB** |        **1.00** |
