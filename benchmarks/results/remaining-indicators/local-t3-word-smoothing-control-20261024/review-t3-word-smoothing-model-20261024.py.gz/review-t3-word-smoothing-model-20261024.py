from fractions import Fraction
from pathlib import Path
import json,random,struct
root=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
mask=(1<<52)-1
bits=lambda x:struct.unpack('>Q',struct.pack('>d',x))[0]
value=lambda x:struct.unpack('>d',struct.pack('>Q',x))[0]
rng=random.Random(309248);cases=[]
for exponent in [1,2,500,1023,1500,2045,2046]:
 for period in [1,2,3,20,1023,2047]:
  for a in [0,1,mask-1,mask]:
   for b in [0,1,mask-1,mask]:cases.append((exponent,a,b,period))
  for i in range(100):cases.append((exponent,rng.randrange(1<<52),rng.randrange(1<<52),period))
for i in range(10000):cases.append((rng.randrange(1,2047),rng.randrange(1<<52),rng.randrange(1<<52),rng.randrange(1,2048)))
corrections=ties=0
for exponent,ma,mb,period in cases:
 a=(1<<52)|ma;b=(1<<52)|mb;d=period+1;n=a*(d-2)+2*b
 assert 0<=n<1<<64
 reciprocal=(1<<64)//d
 q=(n*reciprocal)>>64
 assert n//d-q in [0,1]
 rem=n-q*d;assert 0<=rem<2*d
 if rem>=d:q+=1;rem-=d;corrections+=1
 assert (q,rem)==divmod(n,d)
 if rem==d-rem:ties+=1
 if rem>d-rem or rem==d-rem and q&1:q+=1
 assert 1<<52<=q<1<<53
 actual=value((exponent<<52)|(q&mask))
 x=value((exponent<<52)|ma);y=value((exponent<<52)|mb)
 expected=float((Fraction.from_float(x)*(period-1)+2*Fraction.from_float(y))/(period+1))
 assert bits(actual)==bits(expected),(exponent,ma,mb,period,actual,expected)
assert corrections>0 and ties>0
receipt={'cases':len(cases),'one_step_division_corrections':corrections,'midpoint_cases':ties,'all_binary64_outputs_match_exact_fractions':True,'note':'Design model only: exact same-positive-normal-exponent smoothing with period <=2047 and cached floor(2^64/d). No C# implementation or performance qualification implied.'}
(root/'t3-word-smoothing-model-review-20261024.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(receipt))
