```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |---------------- |------ |-----------:|----------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **MorningDojiStar** | **1000**  |   **158.3 μs** |   **7.73 μs** |  **5.11 μs** |       **-** |      **-** |  **61.33 KB** |
| BuilderLatestOnly | MorningDojiStar | 1000  |   149.3 μs |   1.74 μs |  0.91 μs |       - |      - |  13.46 KB |
| **BuilderFull**       | **MorningDojiStar** | **10000** |   **874.4 μs** | **149.52 μs** | **98.90 μs** | **31.2500** | **7.8125** | **568.03 KB** |
| BuilderLatestOnly | MorningDojiStar | 10000 | 1,300.2 μs |  63.27 μs | 37.65 μs |       - |      - |  97.92 KB |
