```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0       | Gen1      | Allocated    | Alloc Ratio |
|------------------ |---------------- |------ |-------------:|------------:|------------:|------:|--------:|-----------:|----------:|-------------:|------------:|
| **BuilderFull**       | **MorningDojiStar** | **1000**  |     **165.6 μs** |     **4.76 μs** |     **2.83 μs** |  **0.02** |    **0.00** |          **-** |         **-** |     **61.41 KB** |       **0.002** |
| BuilderLatestOnly | MorningDojiStar | 1000  |     155.4 μs |     1.30 μs |     0.68 μs |  0.01 |    0.00 |          - |         - |     13.46 KB |       0.001 |
| NativeSingle      | MorningDojiStar | 1000  |  10,650.6 μs |   474.89 μs |   314.11 μs |  1.00 |    0.04 |  1571.4286 |  142.8571 |  26351.54 KB |       1.000 |
| NativeParallel    | MorningDojiStar | 1000  |   6,667.0 μs |   161.29 μs |    84.36 μs |  0.63 |    0.02 |  1600.0000 |  266.6667 |   26360.4 KB |       1.000 |
|                   |                 |       |              |             |             |       |         |            |           |              |             |
| **BuilderFull**       | **MorningDojiStar** | **10000** |     **865.5 μs** |   **136.56 μs** |    **90.33 μs** | **0.008** |    **0.00** |    **31.2500** |    **7.8125** |    **568.03 KB** |       **0.002** |
| BuilderLatestOnly | MorningDojiStar | 10000 |     846.8 μs |   125.19 μs |    74.50 μs | 0.008 |    0.00 |          - |         - |     97.92 KB |       0.000 |
| NativeSingle      | MorningDojiStar | 10000 | 104,971.5 μs | 2,149.28 μs | 1,421.61 μs | 1.000 |    0.02 | 16250.0000 | 1500.0000 | 267013.67 KB |       1.000 |
| NativeParallel    | MorningDojiStar | 10000 |  64,691.8 μs | 2,069.16 μs | 1,231.33 μs | 0.616 |    0.01 | 16750.0000 | 3250.0000 |  267079.8 KB |       1.000 |
