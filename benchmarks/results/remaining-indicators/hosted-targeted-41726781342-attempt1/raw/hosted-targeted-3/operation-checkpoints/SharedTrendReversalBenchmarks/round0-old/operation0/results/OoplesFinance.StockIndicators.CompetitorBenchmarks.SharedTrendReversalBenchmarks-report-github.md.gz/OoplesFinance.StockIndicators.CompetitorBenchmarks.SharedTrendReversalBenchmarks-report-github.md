```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |-----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **MorningDojiStar** | **1000**  |   **345.8 μs** |   **2.71 μs** |  **1.61 μs** |       **-** |       **-** |  **61.52 KB** |
| BuilderLatestOnly | MorningDojiStar | 1000  |   257.7 μs |   1.15 μs |  0.69 μs |       - |       - |  13.53 KB |
| **BuilderFull**       | **MorningDojiStar** | **10000** | **1,318.4 μs** |  **47.00 μs** | **24.58 μs** | **31.2500** | **15.6250** | **568.35 KB** |
| BuilderLatestOnly | MorningDojiStar | 10000 | 1,340.2 μs | 100.45 μs | 66.44 μs |       - |       - |  98.17 KB |
