```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)iStar [33]** |   **200.7 μs** |   **7.78 μs** |   **4.07 μs** |  **1.00** |    **0.03** |    **69.8 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)iStar [33] |   875.0 μs |  36.31 μs |  24.02 μs |  4.36 |    0.14 |   932.4 KB |       13.36 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Trady(...)iStar [33]** |   **924.5 μs** |  **43.84 μs** |  **22.93 μs** |  **1.00** |    **0.03** |  **646.63 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)iStar [33] | 6,427.2 μs | 226.74 μs | 149.97 μs |  6.96 |    0.22 | 9064.73 KB |       14.02 |
