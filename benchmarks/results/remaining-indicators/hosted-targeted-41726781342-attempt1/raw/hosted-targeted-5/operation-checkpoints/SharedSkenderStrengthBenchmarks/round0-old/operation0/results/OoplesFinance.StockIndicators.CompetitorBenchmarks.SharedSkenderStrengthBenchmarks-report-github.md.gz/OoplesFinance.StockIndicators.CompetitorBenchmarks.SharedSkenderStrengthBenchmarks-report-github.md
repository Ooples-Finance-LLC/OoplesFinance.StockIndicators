```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Allocated  |
|------------------ |--------------- |------ |----------:|----------:|----------:|-----------:|
| **BuilderFull**       | **Skender.GetAdx** | **1000**  |  **1.319 ms** | **0.0747 ms** | **0.0494 ms** |  **113.73 KB** |
| BuilderLatestOnly | Skender.GetAdx | 1000  |  1.182 ms | 0.0114 ms | 0.0068 ms |   66.15 KB |
| **BuilderFull**       | **Skender.GetAdx** | **10000** | **12.236 ms** | **0.0393 ms** | **0.0206 ms** | **1099.04 KB** |
| BuilderLatestOnly | Skender.GetAdx | 10000 | 12.074 ms | 0.0659 ms | 0.0392 ms |  629.56 KB |
