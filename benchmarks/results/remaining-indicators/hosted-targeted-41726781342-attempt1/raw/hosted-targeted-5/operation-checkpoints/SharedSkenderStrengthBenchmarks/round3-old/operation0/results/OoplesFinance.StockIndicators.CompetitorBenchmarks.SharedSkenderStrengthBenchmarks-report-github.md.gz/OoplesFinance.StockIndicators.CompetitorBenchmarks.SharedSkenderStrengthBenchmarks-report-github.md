```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Allocated  |
|------------------ |--------------- |------ |----------:|----------:|----------:|-----------:|
| **BuilderFull**       | **Skender.GetAdx** | **1000**  |  **1.207 ms** | **0.0133 ms** | **0.0070 ms** |  **113.84 KB** |
| BuilderLatestOnly | Skender.GetAdx | 1000  |  1.231 ms | 0.0103 ms | 0.0054 ms |   66.17 KB |
| **BuilderFull**       | **Skender.GetAdx** | **10000** | **12.782 ms** | **0.0526 ms** | **0.0275 ms** | **1099.16 KB** |
| BuilderLatestOnly | Skender.GetAdx | 10000 | 12.242 ms | 0.0319 ms | 0.0167 ms |  629.56 KB |
