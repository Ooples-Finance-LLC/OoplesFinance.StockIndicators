```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean         | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |-------------:|-----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAdx** | **1000**  |  **1,129.58 μs** |  **13.910 μs** |  **7.275 μs** | **20.80** |    **0.74** |        **-** |        **-** |  **113.84 KB** |        **0.57** |
| BuilderLatestOnly | Skender.GetAdx | 1000  |  1,094.80 μs |   6.925 μs |  4.121 μs | 20.16 |    0.71 |        - |        - |   66.16 KB |        0.33 |
| NativeSingle      | Skender.GetAdx | 1000  |     54.38 μs |   3.060 μs |  2.024 μs |  1.00 |    0.05 |  12.2070 |   2.9297 |  199.67 KB |        1.00 |
| NativeParallel    | Skender.GetAdx | 1000  |     99.72 μs |   4.281 μs |  2.239 μs |  1.84 |    0.08 |  32.2266 |  12.6953 |  507.82 KB |        2.54 |
|                   |                |       |              |            |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetAdx** | **10000** | **11,181.96 μs** | **100.516 μs** | **66.485 μs** | **16.55** |    **0.22** |        **-** |        **-** | **1099.19 KB** |        **0.55** |
| BuilderLatestOnly | Skender.GetAdx | 10000 | 11,128.91 μs |  28.782 μs | 15.053 μs | 16.47 |    0.20 |        - |        - |  629.53 KB |        0.32 |
| NativeSingle      | Skender.GetAdx | 10000 |    675.61 μs |  14.625 μs |  8.703 μs |  1.00 |    0.02 | 121.0938 |  70.3125 | 1992.67 KB |        1.00 |
| NativeParallel    | Skender.GetAdx | 10000 |  1,218.25 μs |  65.163 μs | 43.101 μs |  1.80 |    0.06 | 312.5000 | 257.8125 |  5060.6 KB |        2.54 |
