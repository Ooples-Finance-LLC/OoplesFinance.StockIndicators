```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean         | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAdx** |  **1,160.21 μs** | **22.151 μs** | **14.652 μs** |  **1.00** |    **0.02** |  **316.88 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAdx |     79.08 μs |  7.695 μs |  4.025 μs |  0.07 |    0.00 |  338.13 KB |        1.07 |
|            |       |                |              |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAdx** | **11,700.27 μs** | **48.533 μs** | **25.383 μs** |  **1.00** |    **0.00** | **3108.88 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAdx |    774.18 μs | 35.088 μs | 20.881 μs |  0.07 |    0.00 | 3301.35 KB |        1.06 |
