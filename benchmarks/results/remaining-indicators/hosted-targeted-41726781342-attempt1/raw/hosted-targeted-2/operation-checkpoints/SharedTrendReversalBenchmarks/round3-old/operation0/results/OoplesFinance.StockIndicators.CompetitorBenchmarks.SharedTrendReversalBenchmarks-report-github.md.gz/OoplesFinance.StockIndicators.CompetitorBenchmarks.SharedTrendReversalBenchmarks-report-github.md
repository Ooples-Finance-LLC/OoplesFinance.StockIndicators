```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error     | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |----------------- |------ |-----------:|----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **MoringinDojiStar** | **1000**  |   **348.3 μs** |   **3.44 μs** |   **1.80 μs** |       **-** |      **-** |  **61.41 KB** |
| BuilderLatestOnly | MoringinDojiStar | 1000  |   251.5 μs |   1.00 μs |   0.53 μs |       - |      - |  13.51 KB |
| **BuilderFull**       | **MoringinDojiStar** | **10000** | **1,359.3 μs** | **122.00 μs** |  **80.69 μs** | **31.2500** | **7.8125** | **568.27 KB** |
| BuilderLatestOnly | MoringinDojiStar | 10000 | 1,356.1 μs | 171.14 μs | 113.20 μs |       - |      - |  98.16 KB |
