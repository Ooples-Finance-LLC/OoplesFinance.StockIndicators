```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |----------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **MoringinDojiStar** | **1000**  |   **348.0 μs** |  **0.98 μs** |  **0.51 μs** |       **-** |       **-** |   **61.6 KB** |
| BuilderLatestOnly | MoringinDojiStar | 1000  |   258.7 μs |  1.38 μs |  0.82 μs |       - |       - |  13.53 KB |
| **BuilderFull**       | **MoringinDojiStar** | **10000** | **1,357.4 μs** | **22.06 μs** | **11.54 μs** | **31.2500** | **15.6250** | **568.34 KB** |
| BuilderLatestOnly | MoringinDojiStar | 10000 | 1,305.5 μs | 54.25 μs | 28.37 μs |       - |       - |  98.23 KB |
