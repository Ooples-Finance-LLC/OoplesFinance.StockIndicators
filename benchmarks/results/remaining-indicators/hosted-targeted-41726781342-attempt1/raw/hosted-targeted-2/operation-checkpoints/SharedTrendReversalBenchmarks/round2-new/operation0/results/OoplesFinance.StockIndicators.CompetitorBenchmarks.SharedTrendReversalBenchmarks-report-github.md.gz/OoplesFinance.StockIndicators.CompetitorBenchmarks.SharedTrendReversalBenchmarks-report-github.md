```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0       | Gen1      | Allocated    | Alloc Ratio |
|------------------ |----------------- |------ |-------------:|------------:|------------:|------:|--------:|-----------:|----------:|-------------:|------------:|
| **BuilderFull**       | **MoringinDojiStar** | **1000**  |     **148.4 μs** |     **3.52 μs** |     **2.10 μs** |  **0.01** |    **0.00** |          **-** |         **-** |      **61.3 KB** |       **0.002** |
| BuilderLatestOnly | MoringinDojiStar | 1000  |     153.1 μs |     1.21 μs |     0.80 μs |  0.01 |    0.00 |          - |         - |     13.45 KB |       0.001 |
| NativeSingle      | MoringinDojiStar | 1000  |  10,442.8 μs |   328.93 μs |   195.74 μs |  1.00 |    0.02 |  1600.0000 |  100.0000 |  26324.04 KB |       1.000 |
| NativeParallel    | MoringinDojiStar | 1000  |   6,683.2 μs |   251.89 μs |   166.61 μs |  0.64 |    0.02 |  1600.0000 |  266.6667 |   26335.5 KB |       1.000 |
|                   |                  |       |              |             |             |       |         |            |           |              |             |
| **BuilderFull**       | **MoringinDojiStar** | **10000** |     **830.9 μs** |    **98.69 μs** |    **58.73 μs** | **0.008** |    **0.00** |    **31.2500** |    **7.8125** |    **567.99 KB** |       **0.002** |
| BuilderLatestOnly | MoringinDojiStar | 10000 |     841.8 μs |    80.72 μs |    53.39 μs | 0.008 |    0.00 |          - |         - |     97.91 KB |       0.000 |
| NativeSingle      | MoringinDojiStar | 10000 | 104,996.0 μs | 1,106.51 μs |   578.73 μs | 1.000 |    0.01 | 16250.0000 | 1500.0000 | 266747.58 KB |       1.000 |
| NativeParallel    | MoringinDojiStar | 10000 |  65,257.8 μs | 1,684.95 μs | 1,114.49 μs | 0.622 |    0.01 | 16750.0000 | 3500.0000 | 266840.45 KB |       1.000 |
