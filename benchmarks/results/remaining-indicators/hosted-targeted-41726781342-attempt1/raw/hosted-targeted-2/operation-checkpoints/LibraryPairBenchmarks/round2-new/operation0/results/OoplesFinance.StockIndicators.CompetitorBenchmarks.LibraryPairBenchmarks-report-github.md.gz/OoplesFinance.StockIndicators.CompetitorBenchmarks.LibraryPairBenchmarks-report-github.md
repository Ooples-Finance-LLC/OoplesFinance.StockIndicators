```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)iStar [34]** |   **202.6 μs** |  **3.89 μs** |  **2.04 μs** |  **1.00** |    **0.01** |    **69.8 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)iStar [34] |   339.1 μs | 23.70 μs | 14.10 μs |  1.67 |    0.07 |  680.77 KB |        9.75 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Trady(...)iStar [34]** |   **933.4 μs** | **35.44 μs** | **18.53 μs** |  **1.00** |    **0.03** |  **645.31 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)iStar [34] | 3,583.5 μs | 60.62 μs | 40.10 μs |  3.84 |    0.08 | 6581.23 KB |       10.20 |
