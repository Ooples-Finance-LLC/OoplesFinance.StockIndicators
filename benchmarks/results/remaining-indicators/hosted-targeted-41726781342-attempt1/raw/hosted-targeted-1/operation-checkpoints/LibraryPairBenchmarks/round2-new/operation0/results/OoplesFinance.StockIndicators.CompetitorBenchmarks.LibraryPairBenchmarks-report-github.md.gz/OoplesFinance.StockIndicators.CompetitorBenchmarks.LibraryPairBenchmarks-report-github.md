```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon 6973P-C 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)gStar [29]** |   **242.3 μs** |  **20.68 μs** | **13.68 μs** |  **1.00** |    **0.08** |   **71.68 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)gStar [29] |   683.7 μs |  41.04 μs | 27.15 μs |  2.83 |    0.19 |  901.76 KB |       12.58 |
|            |       |                      |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **Trady(...)gStar [29]** |   **996.8 μs** |  **49.39 μs** | **25.83 μs** |  **1.00** |    **0.03** |  **650.39 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)gStar [29] | 4,489.2 μs | 108.33 μs | 64.47 μs |  4.51 |    0.13 | 8752.13 KB |       13.46 |
