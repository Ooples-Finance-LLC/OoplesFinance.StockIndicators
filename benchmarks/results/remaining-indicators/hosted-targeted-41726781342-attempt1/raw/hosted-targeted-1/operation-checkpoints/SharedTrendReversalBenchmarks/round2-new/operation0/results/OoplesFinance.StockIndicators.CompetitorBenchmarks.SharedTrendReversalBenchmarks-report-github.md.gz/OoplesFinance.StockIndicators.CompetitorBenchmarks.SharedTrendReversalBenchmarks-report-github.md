```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon 6973P-C 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Allocated    | Alloc Ratio |
|------------------ |------------ |------ |-------------:|------------:|------------:|------:|--------:|----------:|----------:|-------------:|------------:|
| **BuilderFull**       | **EveningStar** | **1000**  |     **111.9 μs** |     **9.66 μs** |     **6.39 μs** | **0.006** |    **0.00** |         **-** |         **-** |     **63.21 KB** |       **0.001** |
| BuilderLatestOnly | EveningStar | 1000  |     136.7 μs |     3.66 μs |     2.42 μs | 0.007 |    0.00 |         - |         - |     15.34 KB |       0.000 |
| NativeSingle      | EveningStar | 1000  |  19,832.0 μs |   343.11 μs |   226.94 μs | 1.000 |    0.02 |  500.0000 |         - |  50316.94 KB |       1.000 |
| NativeParallel    | EveningStar | 1000  |  12,349.5 μs |   479.97 μs |   317.47 μs | 0.623 |    0.02 |  555.5556 |  111.1111 |  50331.25 KB |       1.000 |
|                   |             |       |              |             |             |       |         |           |           |              |             |
| **BuilderFull**       | **EveningStar** | **10000** |     **668.7 μs** |    **69.35 μs** |    **45.87 μs** | **0.003** |    **0.00** |    **3.9063** |         **-** |     **575.5 KB** |       **0.001** |
| BuilderLatestOnly | EveningStar | 10000 |     589.5 μs |    52.38 μs |    31.17 μs | 0.003 |    0.00 |         - |         - |     105.4 KB |       0.000 |
| NativeSingle      | EveningStar | 10000 | 202,637.2 μs | 3,149.08 μs | 2,082.92 μs | 1.000 |    0.01 | 6000.0000 |  750.0000 | 510236.42 KB |       1.000 |
| NativeParallel    | EveningStar | 10000 | 123,987.2 μs | 6,127.59 μs | 4,053.02 μs | 0.612 |    0.02 | 6250.0000 | 1750.0000 |    510417 KB |       1.000 |
