```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon 6973P-C 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |------------ |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **EveningStar** | **1000**  |   **196.7 μs** |  **10.57 μs** |  **6.29 μs** |  **63.31 KB** |
| BuilderLatestOnly | EveningStar | 1000  |   193.1 μs |   8.76 μs |  4.58 μs |  15.44 KB |
| **BuilderFull**       | **EveningStar** | **10000** | **1,291.5 μs** | **101.40 μs** | **60.34 μs** | **575.91 KB** |
| BuilderLatestOnly | EveningStar | 10000 | 1,091.6 μs |  64.77 μs | 33.87 μs | 105.75 KB |
