```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon 6973P-C 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |------------ |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **EveningStar** | **1000**  |   **208.0 μs** |   **5.05 μs** |   **2.64 μs** |  **63.31 KB** |
| BuilderLatestOnly | EveningStar | 1000  |   203.9 μs |   7.33 μs |   4.36 μs |  15.44 KB |
| **BuilderFull**       | **EveningStar** | **10000** | **1,306.4 μs** | **175.13 μs** | **115.83 μs** | **575.92 KB** |
| BuilderLatestOnly | EveningStar | 10000 | 1,106.1 μs |  15.88 μs |   8.31 μs | 105.83 KB |
