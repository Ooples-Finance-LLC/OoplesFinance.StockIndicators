```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon 6973P-C 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean      | Error      | StdDev    | Gen0   | Allocated |
|------------------ |------------ |------ |----------:|-----------:|----------:|-------:|----------:|
| **BuilderFull**       | **EveningStar** | **1000**  | **101.67 μs** |   **3.234 μs** |  **1.925 μs** |      **-** |  **63.21 KB** |
| BuilderLatestOnly | EveningStar | 1000  |  90.26 μs |   3.036 μs |  2.008 μs |      - |  15.33 KB |
| **BuilderFull**       | **EveningStar** | **10000** | **843.95 μs** | **109.794 μs** | **72.622 μs** | **3.9063** |  **575.5 KB** |
| BuilderLatestOnly | EveningStar | 10000 | 534.90 μs |  49.885 μs | 29.686 μs |      - |  105.4 KB |
