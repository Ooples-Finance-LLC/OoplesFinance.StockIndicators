```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)iStar [33]** |   **242.7 μs** | **16.35 μs** |  **9.73 μs** |  **1.00** |    **0.05** |    **69.8 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)iStar [33] |   896.6 μs | 41.39 μs | 27.38 μs |  3.70 |    0.18 |  962.28 KB |       13.79 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Trady(...)iStar [33]** |   **966.4 μs** | **35.42 μs** | **18.52 μs** |  **1.00** |    **0.03** |  **646.63 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)iStar [33] | 6,270.3 μs | 67.78 μs | 40.33 μs |  6.49 |    0.12 | 9377.13 KB |       14.50 |
