```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean     | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |---------------- |------ |---------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **EveningDojiStar** | **1000**  | **166.7 μs** | **11.98 μs** |  **7.13 μs** |       **-** |      **-** |  **61.45 KB** |
| BuilderLatestOnly | EveningDojiStar | 1000  | 133.0 μs |  2.50 μs |  1.66 μs |       - |      - |  13.45 KB |
| **BuilderFull**       | **EveningDojiStar** | **10000** | **748.1 μs** | **22.29 μs** | **11.66 μs** | **31.2500** | **7.8125** | **568.03 KB** |
| BuilderLatestOnly | EveningDojiStar | 10000 | 790.4 μs | 79.50 μs | 52.58 μs |  3.9063 |      - |  97.86 KB |
