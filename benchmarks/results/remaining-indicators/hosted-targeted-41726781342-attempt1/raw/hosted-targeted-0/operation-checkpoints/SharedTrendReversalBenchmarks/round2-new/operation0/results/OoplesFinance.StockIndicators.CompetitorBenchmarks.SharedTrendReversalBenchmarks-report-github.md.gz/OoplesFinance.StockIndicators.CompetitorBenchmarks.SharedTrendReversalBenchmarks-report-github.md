```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean         | Error       | StdDev      | Ratio | Gen0       | Gen1      | Allocated    | Alloc Ratio |
|------------------ |---------------- |------ |-------------:|------------:|------------:|------:|-----------:|----------:|-------------:|------------:|
| **BuilderFull**       | **EveningDojiStar** | **1000**  |     **145.3 μs** |     **1.48 μs** |     **0.88 μs** |  **0.01** |          **-** |         **-** |     **61.37 KB** |       **0.002** |
| BuilderLatestOnly | EveningDojiStar | 1000  |     155.1 μs |     1.30 μs |     0.77 μs |  0.01 |          - |         - |     13.46 KB |       0.001 |
| NativeSingle      | EveningDojiStar | 1000  |  11,814.1 μs |   126.73 μs |    75.42 μs |  1.00 |  1555.5556 |  111.1111 |  26447.71 KB |       1.000 |
| NativeParallel    | EveningDojiStar | 1000  |   7,460.4 μs |   207.23 μs |   108.39 μs |  0.63 |  1615.3846 |  307.6923 |   26456.6 KB |       1.000 |
|                   |                 |       |              |             |             |       |            |           |              |             |
| **BuilderFull**       | **EveningDojiStar** | **10000** |     **744.7 μs** |   **110.34 μs** |    **65.66 μs** | **0.006** |    **31.2500** |    **7.8125** |    **567.99 KB** |       **0.002** |
| BuilderLatestOnly | EveningDojiStar | 10000 |     759.6 μs |   111.20 μs |    73.55 μs | 0.006 |     3.9063 |         - |     97.88 KB |       0.000 |
| NativeSingle      | EveningDojiStar | 10000 | 117,911.4 μs |   710.68 μs |   371.70 μs | 1.000 | 16250.0000 | 1500.0000 | 267325.87 KB |       1.000 |
| NativeParallel    | EveningDojiStar | 10000 |  74,969.6 μs | 2,136.74 μs | 1,413.32 μs | 0.636 | 16750.0000 | 3250.0000 | 267396.48 KB |       1.000 |
