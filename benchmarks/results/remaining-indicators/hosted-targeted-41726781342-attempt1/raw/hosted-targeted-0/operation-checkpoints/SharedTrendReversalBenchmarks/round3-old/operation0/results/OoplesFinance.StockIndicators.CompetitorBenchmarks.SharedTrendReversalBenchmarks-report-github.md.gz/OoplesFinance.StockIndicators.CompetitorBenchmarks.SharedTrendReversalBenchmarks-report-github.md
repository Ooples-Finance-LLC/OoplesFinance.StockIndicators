```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **EveningDojiStar** | **1000**  |   **364.6 μs** |   **3.30 μs** |   **1.96 μs** |       **-** |       **-** |   **61.6 KB** |
| BuilderLatestOnly | EveningDojiStar | 1000  |   246.9 μs |   2.14 μs |   1.12 μs |       - |       - |  13.53 KB |
| **BuilderFull**       | **EveningDojiStar** | **10000** | **1,483.8 μs** | **241.84 μs** | **159.96 μs** | **31.2500** | **15.6250** | **568.35 KB** |
| BuilderLatestOnly | EveningDojiStar | 10000 | 1,356.5 μs | 189.57 μs | 125.39 μs |       - |       - |  98.16 KB |
