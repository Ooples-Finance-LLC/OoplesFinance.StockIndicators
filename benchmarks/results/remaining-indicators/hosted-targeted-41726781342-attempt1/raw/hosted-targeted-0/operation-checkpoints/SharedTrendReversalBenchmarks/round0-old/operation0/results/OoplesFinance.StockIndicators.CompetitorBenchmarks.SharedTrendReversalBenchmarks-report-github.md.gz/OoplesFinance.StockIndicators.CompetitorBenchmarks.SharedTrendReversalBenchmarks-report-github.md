```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **EveningDojiStar** | **1000**  |   **361.8 μs** |   **2.42 μs** |   **1.44 μs** |       **-** |       **-** |  **61.48 KB** |
| BuilderLatestOnly | EveningDojiStar | 1000  |   249.9 μs |   1.57 μs |   0.93 μs |       - |       - |  13.53 KB |
| **BuilderFull**       | **EveningDojiStar** | **10000** | **1,313.5 μs** |  **45.41 μs** |  **23.75 μs** | **31.2500** | **15.6250** | **568.36 KB** |
| BuilderLatestOnly | EveningDojiStar | 10000 | 1,348.2 μs | 175.54 μs | 116.11 μs |       - |       - |  98.16 KB |
