```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean       | Error    | StdDev   | Median     | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |-----------:|---------:|---------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **Trady(...)gStar [29]** |   **711.4 μs** | **450.0 μs** | **297.6 μs** |   **538.8 μs** |  **1.16** |    **0.63** |  **71.77 KB** |        **1.00** |
|        |       |                      |            |          |          |            |       |         |           |             |
| **Ooples** | **10000** | **Trady(...)gStar [29]** | **2,714.9 μs** | **873.2 μs** | **577.6 μs** | **2,802.5 μs** |  **1.04** |    **0.30** | **649.27 KB** |        **1.00** |
