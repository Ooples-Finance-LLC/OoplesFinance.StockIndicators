```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)gStar [29]** |   **292.8 μs** |  **11.26 μs** |   **5.89 μs** |  **1.00** |    **0.03** |   **71.68 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)gStar [29] | 1,198.8 μs |  84.32 μs |  55.77 μs |  4.10 |    0.20 |  901.43 KB |       12.58 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Trady(...)gStar [29]** | **1,311.8 μs** |  **48.04 μs** |  **28.59 μs** |  **1.00** |    **0.03** |  **650.39 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)gStar [29] | 7,578.4 μs | 418.56 μs | 276.85 μs |  5.78 |    0.23 | 8752.84 KB |       13.46 |
