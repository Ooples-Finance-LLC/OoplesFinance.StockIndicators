```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean     | Error     | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |------------ |------ |---------:|----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **MorningStar** | **1000**  | **150.2 μs** |  **19.81 μs** |  **11.79 μs** |       **-** |      **-** |  **63.22 KB** |
| BuilderLatestOnly | MorningStar | 1000  | 116.9 μs |   1.64 μs |   0.86 μs |       - |      - |  15.34 KB |
| **BuilderFull**       | **MorningStar** | **10000** | **883.3 μs** | **185.45 μs** | **122.67 μs** | **23.4375** | **7.8125** | **575.51 KB** |
| BuilderLatestOnly | MorningStar | 10000 | 850.1 μs | 131.79 μs |  87.17 μs |       - |      - | 105.45 KB |
