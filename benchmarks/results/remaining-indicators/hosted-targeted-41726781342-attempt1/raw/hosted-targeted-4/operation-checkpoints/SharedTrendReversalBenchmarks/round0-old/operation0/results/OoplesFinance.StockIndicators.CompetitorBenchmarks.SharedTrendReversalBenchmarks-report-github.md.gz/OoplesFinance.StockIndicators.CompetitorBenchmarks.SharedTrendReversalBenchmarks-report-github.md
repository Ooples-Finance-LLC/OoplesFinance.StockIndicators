```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |------------ |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **MorningStar** | **1000**  |   **264.8 μs** | **40.81 μs** | **26.99 μs** |       **-** |  **63.31 KB** |
| BuilderLatestOnly | MorningStar | 1000  |   232.0 μs |  4.09 μs |  2.44 μs |       - |  15.44 KB |
| **BuilderFull**       | **MorningStar** | **10000** | **1,407.9 μs** | **95.41 μs** | **49.90 μs** | **15.6250** | **576.01 KB** |
| BuilderLatestOnly | MorningStar | 10000 | 1,543.2 μs | 50.89 μs | 26.61 μs |       - | 105.91 KB |
