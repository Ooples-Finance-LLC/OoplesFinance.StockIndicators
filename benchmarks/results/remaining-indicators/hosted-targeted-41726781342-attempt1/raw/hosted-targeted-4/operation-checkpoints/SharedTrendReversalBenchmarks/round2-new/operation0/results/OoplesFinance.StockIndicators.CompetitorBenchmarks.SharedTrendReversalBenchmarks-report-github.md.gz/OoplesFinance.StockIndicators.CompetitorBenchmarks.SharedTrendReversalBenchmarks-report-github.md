```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0       | Gen1      | Allocated    | Alloc Ratio |
|------------------ |------------ |------ |-------------:|------------:|------------:|------:|--------:|-----------:|----------:|-------------:|------------:|
| **BuilderFull**       | **MorningStar** | **1000**  |     **142.0 μs** |     **8.18 μs** |     **4.28 μs** | **0.007** |    **0.00** |          **-** |         **-** |      **63.3 KB** |       **0.001** |
| BuilderLatestOnly | MorningStar | 1000  |     116.9 μs |     0.93 μs |     0.49 μs | 0.006 |    0.00 |          - |         - |     15.34 KB |       0.000 |
| NativeSingle      | MorningStar | 1000  |  20,389.5 μs |   194.38 μs |   115.67 μs | 1.000 |    0.01 |  2000.0000 |         - |  50072.68 KB |       1.000 |
| NativeParallel    | MorningStar | 1000  |  15,094.6 μs |   563.55 μs |   372.75 μs | 0.740 |    0.02 |  2000.0000 |  285.7143 |   50091.2 KB |       1.000 |
|                   |             |       |              |             |             |       |         |            |           |              |             |
| **BuilderFull**       | **MorningStar** | **10000** |     **878.2 μs** |   **155.35 μs** |   **102.76 μs** | **0.004** |    **0.00** |    **23.4375** |    **7.8125** |    **575.55 KB** |       **0.001** |
| BuilderLatestOnly | MorningStar | 10000 |     978.8 μs |   158.22 μs |   104.65 μs | 0.005 |    0.00 |          - |         - |    105.45 KB |       0.000 |
| NativeSingle      | MorningStar | 10000 | 210,136.7 μs | 3,517.13 μs | 2,326.36 μs | 1.000 |    0.01 | 20750.0000 | 2000.0000 | 510415.82 KB |       1.000 |
| NativeParallel    | MorningStar | 10000 | 147,596.7 μs | 2,069.05 μs | 1,368.55 μs | 0.702 |    0.01 | 21250.0000 | 4250.0000 | 510659.07 KB |       1.000 |
