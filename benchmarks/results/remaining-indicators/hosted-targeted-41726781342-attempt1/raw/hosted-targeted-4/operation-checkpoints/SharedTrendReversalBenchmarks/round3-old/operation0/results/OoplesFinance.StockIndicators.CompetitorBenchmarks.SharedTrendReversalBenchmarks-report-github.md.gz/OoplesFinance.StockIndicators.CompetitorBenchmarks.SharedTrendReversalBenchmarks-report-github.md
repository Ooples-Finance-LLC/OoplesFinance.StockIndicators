```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |------------ |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **MorningStar** | **1000**  |   **328.1 μs** |  **54.42 μs** |  **28.46 μs** |       **-** |  **63.32 KB** |
| BuilderLatestOnly | MorningStar | 1000  |   237.0 μs |   2.28 μs |   1.50 μs |       - |  15.44 KB |
| **BuilderFull**       | **MorningStar** | **10000** | **1,488.9 μs** | **291.53 μs** | **173.48 μs** | **15.6250** | **576.01 KB** |
| BuilderLatestOnly | MorningStar | 10000 | 1,659.7 μs | 198.70 μs | 131.42 μs |       - | 105.82 KB |
