```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method   | Count | Operation        | Mean       | Error     | StdDev   | Median     | Gen0    | Allocated  |
|--------- |------ |----------------- |-----------:|----------:|---------:|-----------:|--------:|-----------:|
| **Snapshot** | **1000**  | **Skender.GetRenko** |   **253.2 μs** | **143.81 μs** | **95.12 μs** |   **184.6 μs** |  **7.8125** |   **147.8 KB** |
| **Snapshot** | **10000** | **Skender.GetRenko** | **1,773.8 μs** |  **23.77 μs** | **14.15 μs** | **1,773.2 μs** | **78.1250** | **1476.18 KB** |
