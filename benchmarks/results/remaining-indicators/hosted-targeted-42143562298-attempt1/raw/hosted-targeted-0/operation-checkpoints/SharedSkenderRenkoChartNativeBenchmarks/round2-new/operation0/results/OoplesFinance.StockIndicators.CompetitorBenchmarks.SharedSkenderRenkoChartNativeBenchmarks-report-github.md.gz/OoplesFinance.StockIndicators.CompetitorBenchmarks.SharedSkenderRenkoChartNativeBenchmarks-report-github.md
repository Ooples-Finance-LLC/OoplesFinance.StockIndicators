```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method         | Count | Operation        | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|--------------- |------ |----------------- |------------:|----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **Snapshot**       | **1000**  | **Skender.GetRenko** |   **144.57 μs** |  **1.592 μs** |  **0.833 μs** |  **1.81** |    **0.02** |  **3.9063** |       **-** |  **102.49 KB** |        **1.99** |
| NativeSingle   | 1000  | Skender.GetRenko |    79.68 μs |  1.259 μs |  0.833 μs |  1.00 |    0.01 |  2.9297 |       - |    51.4 KB |        1.00 |
| NativeParallel | 1000  | Skender.GetRenko |   141.10 μs | 10.735 μs |  7.101 μs |  1.77 |    0.09 |  8.7891 |  0.9766 |  130.01 KB |        2.53 |
|                |       |                  |             |           |           |       |         |         |         |            |             |
| **Snapshot**       | **10000** | **Skender.GetRenko** | **1,466.62 μs** | **10.628 μs** |  **6.324 μs** |  **1.47** |    **0.03** | **54.6875** |       **-** | **1015.18 KB** |        **1.98** |
| NativeSingle   | 10000 | Skender.GetRenko |   999.34 μs | 36.487 μs | 24.134 μs |  1.00 |    0.03 | 31.2500 |  7.8125 |  513.34 KB |        1.00 |
| NativeParallel | 10000 | Skender.GetRenko | 1,343.55 μs | 83.818 μs | 55.440 μs |  1.35 |    0.06 | 78.1250 | 31.2500 | 1309.58 KB |        2.55 |
