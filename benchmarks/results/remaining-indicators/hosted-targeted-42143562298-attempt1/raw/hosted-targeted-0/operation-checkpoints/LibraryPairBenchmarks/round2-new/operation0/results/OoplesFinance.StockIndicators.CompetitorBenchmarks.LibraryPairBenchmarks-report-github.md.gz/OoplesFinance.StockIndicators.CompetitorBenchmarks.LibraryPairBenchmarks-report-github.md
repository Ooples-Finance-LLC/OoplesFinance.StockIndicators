```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId           | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |----------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetRenko** |   **214.5 μs** | **16.28 μs** |  **9.69 μs** |  **1.00** |    **0.06** |  **114.34 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetRenko |   114.2 μs |  2.86 μs |  1.70 μs |  0.53 |    0.02 |   82.47 KB |        0.72 |
|            |       |                  |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetRenko** | **1,465.5 μs** | **26.85 μs** | **14.04 μs** |  **1.00** |    **0.01** | **1117.56 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetRenko | 1,106.5 μs | 38.82 μs | 23.10 μs |  0.76 |    0.02 |  731.42 KB |        0.65 |
