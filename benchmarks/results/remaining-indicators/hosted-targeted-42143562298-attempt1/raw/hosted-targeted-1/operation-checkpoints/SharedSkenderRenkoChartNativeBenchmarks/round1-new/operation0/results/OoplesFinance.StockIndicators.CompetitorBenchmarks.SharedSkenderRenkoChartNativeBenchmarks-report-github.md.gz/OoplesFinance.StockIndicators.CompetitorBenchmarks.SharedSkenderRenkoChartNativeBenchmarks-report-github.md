```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method   | Count | Operation           | Mean       | Error    | StdDev   | Gen0    | Allocated |
|--------- |------ |-------------------- |-----------:|---------:|---------:|--------:|----------:|
| **Snapshot** | **1000**  | **Skender.GetRenkoAtr** |   **294.9 μs** | **58.70 μs** | **38.82 μs** |       **-** |  **86.52 KB** |
| **Snapshot** | **10000** | **Skender.GetRenkoAtr** | **1,913.7 μs** | **13.27 μs** |  **6.94 μs** | **46.8750** | **857.59 KB** |
