```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method         | Count | Operation           | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|--------------- |------ |-------------------- |-----------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **Snapshot**       | **1000**  | **Skender.GetRenkoAtr** |   **331.5 μs** | **232.98 μs** | **154.10 μs** |  **2.90** |    **1.29** |        **-** |       **-** |   **86.43 KB** |        **0.41** |
| NativeSingle   | 1000  | Skender.GetRenkoAtr |   114.4 μs |   2.21 μs |   1.16 μs |  1.00 |    0.01 |  12.6953 |  2.9297 |  208.67 KB |        1.00 |
| NativeParallel | 1000  | Skender.GetRenkoAtr |   147.9 μs |   5.13 μs |   2.68 μs |  1.29 |    0.03 |  15.6250 |  1.9531 |  270.48 KB |        1.30 |
|                |       |                     |            |           |           |       |         |          |         |            |             |
| **Snapshot**       | **10000** | **Skender.GetRenkoAtr** | **1,908.5 μs** |   **9.03 μs** |   **5.38 μs** |  **1.42** |    **0.01** |  **46.8750** |       **-** |  **857.59 KB** |        **0.41** |
| NativeSingle   | 10000 | Skender.GetRenkoAtr | 1,348.3 μs |  12.93 μs |   8.55 μs |  1.00 |    0.01 | 125.0000 | 62.5000 |  2078.5 KB |        1.00 |
| NativeParallel | 10000 | Skender.GetRenkoAtr | 1,610.2 μs |  43.08 μs |  22.53 μs |  1.19 |    0.02 | 156.2500 | 78.1250 | 2686.34 KB |        1.29 |
