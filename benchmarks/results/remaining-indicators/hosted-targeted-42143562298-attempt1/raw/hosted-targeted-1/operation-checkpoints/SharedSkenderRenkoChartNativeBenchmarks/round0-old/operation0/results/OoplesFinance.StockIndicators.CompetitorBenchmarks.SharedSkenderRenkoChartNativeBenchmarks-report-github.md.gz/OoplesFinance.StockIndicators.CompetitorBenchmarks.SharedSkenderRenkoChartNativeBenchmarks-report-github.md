```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method   | Count | Operation           | Mean       | Error    | StdDev   | Gen0    | Allocated |
|--------- |------ |-------------------- |-----------:|---------:|---------:|--------:|----------:|
| **Snapshot** | **1000**  | **Skender.GetRenkoAtr** |   **192.7 μs** |  **1.83 μs** |  **1.09 μs** |       **-** |  **99.87 KB** |
| **Snapshot** | **10000** | **Skender.GetRenkoAtr** | **1,992.6 μs** | **76.56 μs** | **50.64 μs** | **46.8750** | **990.07 KB** |
