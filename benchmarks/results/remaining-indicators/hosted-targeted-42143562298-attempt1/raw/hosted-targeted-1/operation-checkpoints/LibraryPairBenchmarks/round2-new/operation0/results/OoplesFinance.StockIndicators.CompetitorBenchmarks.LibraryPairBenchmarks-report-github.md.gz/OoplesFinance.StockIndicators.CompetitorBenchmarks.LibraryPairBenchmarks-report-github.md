```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean       | Error    | StdDev   | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|---------:|---------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetRenkoAtr** |   **192.4 μs** |  **2.04 μs** |  **1.21 μs** |  **1.00** |   **91.88 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetRenkoAtr |   126.2 μs |  0.99 μs |  0.52 μs |  0.66 |  222.48 KB |        2.42 |
|            |       |                     |            |          |          |       |            |             |
| **Ooples**     | **10000** | **Skender.GetRenkoAtr** | **1,883.7 μs** | **16.61 μs** |  **9.88 μs** |  **1.00** |  **889.67 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetRenkoAtr | 1,290.7 μs | 27.50 μs | 16.37 μs |  0.69 | 2144.88 KB |        2.41 |
