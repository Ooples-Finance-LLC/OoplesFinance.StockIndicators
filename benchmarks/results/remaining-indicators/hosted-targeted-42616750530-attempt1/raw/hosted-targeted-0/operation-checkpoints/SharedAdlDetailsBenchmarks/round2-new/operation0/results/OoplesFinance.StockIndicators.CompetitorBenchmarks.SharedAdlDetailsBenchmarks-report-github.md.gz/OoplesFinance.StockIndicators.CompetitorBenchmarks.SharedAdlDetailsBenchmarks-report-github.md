```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated | Alloc Ratio |
|------------------ |--------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|----------:|------------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |    **34.97 μs** |  **0.410 μs** |  **0.244 μs** |  **0.45** |    **0.00** |   **4.8828** |   **0.9766** |  **88.31 KB** |        **0.50** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |    31.62 μs |  0.565 μs |  0.296 μs |  0.41 |    0.00 |   2.4414 |   0.2441 |   40.7 KB |        0.23 |
| NativeSingle      | Skender.GetAdl | 1000  |    77.17 μs |  1.048 μs |  0.548 μs |  1.00 |    0.01 |  10.7422 |   2.4414 | 176.21 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 1000  |   193.81 μs |  7.982 μs |  5.279 μs |  2.51 |    0.07 |  28.3203 |   8.7891 |  449.4 KB |        2.55 |
|                   |                |       |             |           |           |       |         |          |          |           |             |
| **BuilderFull**       | **Skender.GetAdl** | **10000** |   **332.33 μs** |  **4.232 μs** |  **2.519 μs** |  **0.38** |    **0.01** |  **50.7813** |  **17.5781** | **862.12 KB** |        **0.49** |
| BuilderLatestOnly | Skender.GetAdl | 10000 |   303.12 μs |  4.269 μs |  2.541 μs |  0.35 |    0.00 |  23.4375 |   9.7656 | 392.29 KB |        0.22 |
| NativeSingle      | Skender.GetAdl | 10000 |   877.98 μs | 17.629 μs | 10.491 μs |  1.00 |    0.02 | 101.5625 |  54.6875 | 1758.3 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 10000 | 1,810.01 μs | 55.563 μs | 36.752 μs |  2.06 |    0.05 | 265.6250 | 187.5000 | 4474.9 KB |        2.55 |
