using System.Numerics;
using System.Reflection;
using System.Runtime.Loader;
using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Configs;
using BenchmarkDotNet.Jobs;
using BenchmarkDotNet.Running;
using BenchmarkDotNet.Toolchains.InProcess.Emit;

if (args.Length < 1) throw new ArgumentException("Production DLL path required.");
CoreTarget.Path = System.IO.Path.GetFullPath(args[0]);
var directory = System.IO.Path.GetDirectoryName(CoreTarget.Path)!;
AssemblyLoadContext.Default.Resolving += (_, name) =>
{
    var dependency = System.IO.Path.Combine(directory, name.Name + ".dll");
    return File.Exists(dependency) ? AssemblyLoadContext.Default.LoadFromAssemblyPath(dependency) : null;
};
if (args.Skip(1).Contains("--verify-only"))
{
    foreach (int count in new[] { 1000, 10000 })
    foreach (int period in new[] { 1, 20, 79 })
    {
        var fixture = new FibonacciCoreBenchmarks { Count = count, Period = period };
        fixture.Setup();
        if (!double.IsFinite(fixture.Calculate())) throw new ArithmeticException("Invalid benchmark result.");
    }
    Console.WriteLine("Verified all six direct-core fixtures against independent exact tap sums.");
}
else BenchmarkSwitcher.FromTypes([typeof(FibonacciCoreBenchmarks)]).Run(args.Skip(1).ToArray());

internal static class CoreTarget { internal static string Path = ""; }
public sealed class CoreTimingConfig : ManualConfig
{
    public CoreTimingConfig() => AddJob(Job.ShortRun
        .WithToolchain(new InProcessEmitToolchain(TimeSpan.FromMinutes(10), true))
        .WithUnrollFactor(1).WithWarmupCount(10).WithIterationCount(10)
        .WithMinIterationTime(Perfolizer.Horology.TimeInterval.FromMilliseconds(100)));
}
[MemoryDiagnoser, Config(typeof(CoreTimingConfig))]
public class FibonacciCoreBenchmarks
{
    [Params(1000, 10000)] public int Count { get; set; }
    [Params(1, 20, 79)] public int Period { get; set; }
    private delegate void Compute(ReadOnlySpan<double> input, Span<double> output, int length);
    private Compute _compute = null!;
    private double[] _input = null!, _output = null!;
    [GlobalSetup]
    public void Setup()
    {
        var assembly = Assembly.LoadFrom(CoreTarget.Path);
        var type = assembly.GetType("OoplesFinance.StockIndicators.Core.MovingAverageCore", throwOnError: true)!;
        var method = type.GetMethod("FibonacciWeightedMovingAverage", BindingFlags.Static | BindingFlags.NonPublic)!;
        _compute = method.CreateDelegate<Compute>();
        _input = Enumerable.Range(0, Count).Select(i => 100 + (i * 13 % 101) / 8d).ToArray();
        _output = new double[Count];
        var weights = new BigInteger[Period];
        BigInteger newest = 1, previous = 0;
        for (int i = 1; i < Period; i++) (newest, previous) = (newest + previous, newest);
        BigInteger denominator = (2 * newest + previous - 1) * 8;
        for (int i = 0; i < Period; i++)
        {
            weights[i] = newest;
            (newest, previous) = (previous, newest - previous);
        }
        _compute(_input, _output, Period);
        for (int i = 0; i < Count; i++)
        {
            BigInteger sum = 0;
            for (int lag = 0; lag < Period && lag <= i; lag++)
                sum += (long)(_input[i - lag] * 8) * weights[lag];
            double expected = ExactPositiveRatio(sum, denominator);
            if (BitConverter.DoubleToInt64Bits(expected) != BitConverter.DoubleToInt64Bits(_output[i]))
                throw new ArithmeticException($"Core output differs at count={Count}, period={Period}, bar={i}.");
        }
    }
    [Benchmark] public double Calculate()
    {
        _compute(_input, _output, Period);
        return _output[^1];
    }
    // Full tap sums are independent of the rolling production recurrence.
    // These bounded positive fixtures have normal finite ratios.
    private static double ExactPositiveRatio(BigInteger numerator, BigInteger denominator)
    {
        if (numerator.Sign <= 0 || denominator.Sign <= 0) throw new ArithmeticException("Fixture ratio must be positive.");
        int power = checked((int)(numerator.GetBitLength() - denominator.GetBitLength()));
        if (power >= 0 ? numerator < (denominator << power) : (numerator << -power) < denominator) power--;
        int shift = 52 - power;
        if (shift >= 0) numerator <<= shift; else denominator <<= -shift;
        var quotient = BigInteger.DivRem(numerator, denominator, out var remainder);
        int tie = (2 * remainder).CompareTo(denominator);
        if (tie > 0 || tie == 0 && !quotient.IsEven) quotient++;
        return Math.ScaleB((double)quotient, power - 52);
    }
}
