from pathlib import Path
import hashlib,json,math,re,subprocess
ROOT=Path('C:/Users/cheat/StockIndicators-Recovery-20261021');OUT=ROOT/'local-fib-core-rolling-control-20261023'
state=json.loads((OUT/'status.json').read_text());proof=json.loads((OUT/'provenance.json').read_text());manifests=json.loads((OUT/'binary-manifest.json').read_text())
assert state['status']=='raw-measurements-complete-independent-verification-pending' and state['order']==['old','new','new','old'] and len(state['rounds'])==4
for arm,folder in proof['folders'].items():
 p=Path(folder);assert {f.relative_to(p).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file()}==manifests[arm]
host=ROOT/'fibonacci-core-runner';assert {n:hashlib.sha256((host/n).read_bytes()).hexdigest() for n in proof['host_sources']}==proof['host_sources']
q=proof['qualification'];assert q['unit']['passed']==57 and q['parity']['passed']==12 and q['gpu_passed']==100
assert manifests['new']['OoplesFinance.StockIndicators.dll'] in q['production_dll_sha256'].values()
assert manifests['old']['OoplesFinance.StockIndicators.dll'] in proof['old_qualification']['production_dll_sha256'].values()
repo=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-fib-core-rolling-20261023')
paths=['src','tests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','benchmarks/OoplesFinance.StockIndicators.CompetitorTests','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json']
assert not subprocess.check_output(['git','diff',q['input_head'],proof['new_source'],'--',*paths],cwd=repo)
assert set(subprocess.check_output(['git','diff','--name-only',proof['old_source'],proof['new_source'],'--',*paths],cwd=repo,text=True).splitlines())=={'src/Helpers/FibonacciWindowMean.cs','tests/ValidationTests/FibonacciWindowRecurrenceTests.cs'}
rounds={}
for record in state['rounds']:
 i=record['index'];assert record['arm']==state['order'][i] and i not in rounds
 assert len(record['quiet_cpu_samples'])==3 and max(record['quiet_cpu_samples'])<=15
 path=Path(record['report']);assert path.is_relative_to(OUT);raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()==record['sha256']
 cases={}
 for c in json.loads(raw)['Benchmarks']:
  assert c['Method']=='Calculate';name=c['FullName'];key=int(re.search(r'Count: (\d+)',name)[1]),int(re.search(r'Period: (\d+)',name)[1]);assert key not in cases
  stats=c['Statistics'];values=stats['OriginalValues'];ci=stats['ConfidenceInterval']
  assert stats['N']==len(values)>=7 and all(math.isfinite(v) and v>0 for v in values)
  assert math.isclose(sum(values)/len(values),stats['Mean'],rel_tol=1e-12)
  assert math.isfinite(ci['Lower']) and math.isfinite(ci['Upper']) and ci['Lower']<=stats['Mean']<=ci['Upper']
  cases[key]=dict(count=key[0],period=key[1],mean_ns=stats['Mean'],lower_ns=ci['Lower'],upper_ns=ci['Upper'],samples=stats['N'],allocated_bytes=c['Memory']['BytesAllocatedPerOperation'])
 assert cases.keys()=={(n,p) for n in [1000,10000] for p in [1,20,79]}
 sections=re.split(r'^// Benchmark: ',(OUT/f'round{i}-{record['arm']}.log').read_text(encoding='utf-8-sig'),flags=re.M)[1:];assert len(sections)==6
 for section in sections:
  assert 'WarmupCount=10' in section.splitlines()[0] and 'IterationCount=10' in section.splitlines()[0]
  assert len(re.findall(r'^WorkloadWarmup\s+\d+:',section,re.M))==10 and len(re.findall(r'^WorkloadActual\s+\d+:',section,re.M))==10
 rounds[i]=cases
decisions=[]
for key in sorted(rounds[0]):
 old=[rounds[i][key] for i in [0,3]];new=[rounds[i][key] for i in [1,2]]
 verdict='faster' if max(r['upper_ns'] for r in new)<min(r['lower_ns'] for r in old) else 'slower' if min(r['lower_ns'] for r in new)>max(r['upper_ns'] for r in old) else 'inconclusive'
 row=dict(count=key[0],period=key[1],old_means_ms=[r['mean_ns']/1e6 for r in old],new_means_ms=[r['mean_ns']/1e6 for r in new],verdict=verdict);decisions.append(row);print(json.dumps(row))
summary=dict(all_24_cases_verified=True,scope=proof['scope'],sources={'old':proof['old_source'],'new':proof['new_source']},decisions=decisions,final_candidate_round=2,final_candidate_rows=list(rounds[2].values()))
(OUT/'verified-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
