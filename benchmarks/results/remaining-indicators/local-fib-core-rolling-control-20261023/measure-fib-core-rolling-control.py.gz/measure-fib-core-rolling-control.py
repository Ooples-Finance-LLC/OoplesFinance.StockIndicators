from pathlib import Path
import datetime,hashlib,json,os,psutil,subprocess
ROOT=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
BASE=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC')
OLD=BASE/'si-t3-compact-division-20261023';NEW=BASE/'si-fib-core-rolling-20261023'
HOST=ROOT/'fibonacci-core-runner';OUT=ROOT/'local-fib-core-rolling-control-20261023'
REL=Path('benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks/bin/Release/net10.0')
DLL='OoplesFinance.StockIndicators.dll'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def manifest(p):return {f.relative_to(p).as_posix():digest(f) for f in p.rglob('*') if f.is_file()}
def head(p):return subprocess.check_output(['git','rev-parse','HEAD'],cwd=p,text=True).strip()
q=json.loads((ROOT/'fib-core-rolling/status.json').read_text());oldq=json.loads((ROOT/'t3-compact-division/status.json').read_text())
assert q['status']==oldq['status']=='checks-passed-review-and-publication-pending'
assert q['unit']['passed']==57 and q['parity']['passed']==12 and q['gpu_passed']==100
assert oldq['unit']['passed']==33 and oldq['parity']['passed']==26 and oldq['gpu_passed']==100
paths=['src','tests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','benchmarks/OoplesFinance.StockIndicators.CompetitorTests','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json']
for repo,qual in [(OLD,oldq),(NEW,q)]:
 assert not subprocess.check_output(['git','diff',qual['input_head'],'HEAD','--',*paths],cwd=repo)
 assert not subprocess.check_output(['git','diff','HEAD','--',*paths],cwd=repo)
 assert digest(repo/REL/DLL) in qual['production_dll_sha256'].values()
changed=subprocess.check_output(['git','diff','--name-only',head(OLD),head(NEW),'--',*paths],cwd=NEW,text=True).splitlines()
assert set(changed)=={'src/Helpers/FibonacciWindowMean.cs','tests/ValidationTests/FibonacciWindowRecurrenceTests.cs'}
assert not OUT.exists();OUT.mkdir()
folders={'old':OLD/REL,'new':NEW/REL,'host':HOST/'bin/Release/net10.0'}
manifests={a:manifest(p) for a,p in folders.items()}
source_manifest={n:digest(HOST/n) for n in ['Program.cs','FibonacciCoreRunner.csproj']}
(OUT/'binary-manifest.json').write_text(json.dumps(manifests,indent=2),encoding='utf-8')
proof=dict(old_source=head(OLD),new_source=head(NEW),qualification=q,old_qualification=oldq,folders={a:str(p) for a,p in folders.items()},host_sources=source_manifest,changed_inputs=changed,scope='Direct fixed-normalization Fibonacci Core span API; no competitor comparison or available-prefix facade claim.',policy='Identical standalone in-process host, exact-tap setup checks, ten warmups and ten measured iterations,100ms minimum iteration, ABBA old/new/new/old.')
(OUT/'provenance.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
state={'status':'starting','order':['old','new','new','old'],'rounds':[]}
def save():
 state['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(OUT/'status.json').write_text(json.dumps(state,indent=2),encoding='utf-8')
env=os.environ.copy();env['TEMP']=env['TMP']=str(ROOT/'temp')
for index,arm in enumerate(state['order']):
 state.update(status='waiting-quiet-window',round=index,arm=arm);save();samples=[]
 while len(samples)<3:
  builds=[p.pid for p in psutil.process_iter(['name','cmdline']) if (p.info['name'] or '').lower()=='dotnet.exe' and 'build' in (p.info['cmdline'] or [])]
  cpu=psutil.cpu_percent(interval=5)
  samples=samples+[cpu] if not builds and cpu<=15 else []
 folder=OUT/f'round{index}-{arm}';state['status']='measuring';save()
 with folder.with_suffix('.log').open('wb') as log:
  subprocess.run(['dotnet',str(folders['host']/'FibonacciCoreRunner.dll'),str(folders[arm]/DLL),'--filter','*FibonacciCoreBenchmarks*','--warmupCount','10','--iterationCount','10','--exporters','json','--artifacts',str(folder)],cwd=HOST,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=1800)
 reports=list((folder/'results').glob('*-report-full-compressed.json'));assert len(reports)==1
 report=json.loads(reports[0].read_bytes());assert len(report['Benchmarks'])==6 and all(c.get('Statistics') and c['Statistics']['N']>=7 for c in report['Benchmarks'])
 state['rounds'].append(dict(index=index,arm=arm,quiet_cpu_samples=samples,report=str(reports[0]),sha256=digest(reports[0]),cases=6));save()
assert all(manifest(folders[a])==manifests[a] for a in folders)
assert {n:digest(HOST/n) for n in source_manifest}==source_manifest
state['status']='raw-measurements-complete-independent-verification-pending';save();print(state['status'],flush=True)
