```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Allocated  |
|------------------ |--------------- |------ |----------:|----------:|----------:|-----------:|
| **BuilderFull**       | **Skender.GetAdx** | **1000**  |  **2.130 ms** | **0.0184 ms** | **0.0110 ms** |  **113.86 KB** |
| BuilderLatestOnly | Skender.GetAdx | 1000  |  1.300 ms | 0.0104 ms | 0.0062 ms |   66.18 KB |
| **BuilderFull**       | **Skender.GetAdx** | **10000** | **13.033 ms** | **0.0539 ms** | **0.0282 ms** | **1099.37 KB** |
| BuilderLatestOnly | Skender.GetAdx | 10000 | 13.339 ms | 0.5338 ms | 0.3177 ms |  629.64 KB |
