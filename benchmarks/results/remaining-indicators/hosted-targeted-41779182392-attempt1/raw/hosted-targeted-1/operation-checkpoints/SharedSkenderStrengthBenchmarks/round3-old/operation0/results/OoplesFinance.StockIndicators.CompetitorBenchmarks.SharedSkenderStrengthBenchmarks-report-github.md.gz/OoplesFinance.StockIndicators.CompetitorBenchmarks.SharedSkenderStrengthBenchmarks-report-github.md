```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Allocated  |
|------------------ |--------------- |------ |----------:|----------:|----------:|-----------:|
| **BuilderFull**       | **Skender.GetAdx** | **1000**  |  **2.532 ms** | **1.7027 ms** | **1.1262 ms** |  **113.86 KB** |
| BuilderLatestOnly | Skender.GetAdx | 1000  |  1.284 ms | 0.0099 ms | 0.0059 ms |   66.18 KB |
| **BuilderFull**       | **Skender.GetAdx** | **10000** | **13.076 ms** | **0.0619 ms** | **0.0324 ms** | **1099.49 KB** |
| BuilderLatestOnly | Skender.GetAdx | 10000 | 13.101 ms | 0.0426 ms | 0.0223 ms |  629.59 KB |
