```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean         | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |-------------:|----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAdx** | **1000**  |  **1,074.13 μs** |  **9.743 μs** |  **5.798 μs** | **13.80** |    **0.36** |        **-** |        **-** |  **113.83 KB** |        **0.57** |
| BuilderLatestOnly | Skender.GetAdx | 1000  |  1,024.23 μs |  2.755 μs |  1.639 μs | 13.16 |    0.34 |        - |        - |   66.18 KB |        0.33 |
| NativeSingle      | Skender.GetAdx | 1000  |     77.87 μs |  3.210 μs |  2.123 μs |  1.00 |    0.04 |  12.2070 |   2.9297 |  199.68 KB |        1.00 |
| NativeParallel    | Skender.GetAdx | 1000  |    137.87 μs | 10.043 μs |  6.643 μs |  1.77 |    0.09 |  32.2266 |  10.7422 |  507.82 KB |        2.54 |
|                   |                |       |              |           |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetAdx** | **10000** | **10,292.75 μs** | **51.711 μs** | **30.773 μs** | **12.00** |    **0.06** |        **-** |        **-** | **1099.25 KB** |        **0.55** |
| BuilderLatestOnly | Skender.GetAdx | 10000 | 10,445.08 μs | 27.421 μs | 14.342 μs | 12.18 |    0.06 |        - |        - |  629.46 KB |        0.32 |
| NativeSingle      | Skender.GetAdx | 10000 |    857.84 μs |  7.840 μs |  4.101 μs |  1.00 |    0.01 | 117.1875 |  70.3125 |  1992.7 KB |        1.00 |
| NativeParallel    | Skender.GetAdx | 10000 |  1,469.87 μs | 80.743 μs | 53.406 μs |  1.71 |    0.06 | 312.5000 | 257.8125 | 5060.61 KB |        2.54 |
