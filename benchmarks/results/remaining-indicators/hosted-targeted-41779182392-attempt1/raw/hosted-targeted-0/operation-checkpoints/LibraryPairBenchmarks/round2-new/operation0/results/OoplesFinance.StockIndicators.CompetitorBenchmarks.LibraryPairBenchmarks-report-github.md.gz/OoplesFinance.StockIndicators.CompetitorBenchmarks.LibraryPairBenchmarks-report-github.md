```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error       | StdDev       | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|------------:|-------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAdx** |   **716.12 μs** |    **12.51 μs** |     **7.443 μs** |  **1.00** |    **0.01** |  **316.88 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAdx |    57.15 μs |    13.40 μs |     8.863 μs |  0.08 |    0.01 |  335.22 KB |        1.06 |
|            |       |                |             |             |              |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAdx** | **8,036.29 μs** | **1,538.04 μs** | **1,017.317 μs** |  **1.01** |    **0.17** |  **3111.5 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAdx |   559.17 μs |    12.55 μs |     6.562 μs |  0.07 |    0.01 | 3296.76 KB |        1.06 |
