```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean       | Error    | StdDev  | Ratio | Allocated | Alloc Ratio |
|------- |------ |--------------------- |-----------:|---------:|--------:|------:|----------:|------------:|
| **Ooples** | **1000**  | **Trady(...)gStar [29]** |   **426.6 μs** |  **3.49 μs** | **1.83 μs** |  **1.00** |  **71.77 KB** |        **1.00** |
|        |       |                      |            |          |         |       |           |             |
| **Ooples** | **10000** | **Trady(...)gStar [29]** | **1,992.7 μs** | **11.54 μs** | **6.04 μs** |  **1.00** | **650.25 KB** |        **1.00** |
