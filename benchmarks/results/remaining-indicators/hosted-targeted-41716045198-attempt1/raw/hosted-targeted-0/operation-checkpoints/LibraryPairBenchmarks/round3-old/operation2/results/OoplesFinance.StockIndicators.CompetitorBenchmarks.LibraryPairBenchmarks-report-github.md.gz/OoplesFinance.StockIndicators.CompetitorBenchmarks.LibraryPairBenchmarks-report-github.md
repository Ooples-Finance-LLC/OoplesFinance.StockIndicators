```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **Trady(...)iStar [34]** |   **307.3 μs** | **16.81 μs** | **11.12 μs** |  **1.00** |    **0.05** |  **69.86 KB** |        **1.00** |
|        |       |                      |            |          |          |       |         |           |             |
| **Ooples** | **10000** | **Trady(...)iStar [34]** | **1,411.6 μs** | **33.97 μs** | **17.76 μs** |  **1.00** |    **0.02** | **645.77 KB** |        **1.00** |
