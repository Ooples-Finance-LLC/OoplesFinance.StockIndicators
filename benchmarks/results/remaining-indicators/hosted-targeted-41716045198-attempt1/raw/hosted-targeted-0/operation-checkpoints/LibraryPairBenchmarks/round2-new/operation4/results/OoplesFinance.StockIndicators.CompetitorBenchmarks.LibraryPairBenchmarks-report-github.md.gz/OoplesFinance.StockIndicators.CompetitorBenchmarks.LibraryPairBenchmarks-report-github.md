```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)gStar [29]** |   **263.2 μs** |  **10.48 μs** |   **6.24 μs** |  **1.00** |    **0.03** |   **71.68 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)gStar [29] |   861.2 μs |  40.73 μs |  26.94 μs |  3.27 |    0.12 |  901.12 KB |       12.57 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Trady(...)gStar [29]** | **1,291.7 μs** | **131.19 μs** |  **86.77 μs** |  **1.00** |    **0.09** |  **650.39 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)gStar [29] | 7,030.9 μs | 424.96 μs | 281.08 μs |  5.47 |    0.41 | 8751.49 KB |       13.46 |
