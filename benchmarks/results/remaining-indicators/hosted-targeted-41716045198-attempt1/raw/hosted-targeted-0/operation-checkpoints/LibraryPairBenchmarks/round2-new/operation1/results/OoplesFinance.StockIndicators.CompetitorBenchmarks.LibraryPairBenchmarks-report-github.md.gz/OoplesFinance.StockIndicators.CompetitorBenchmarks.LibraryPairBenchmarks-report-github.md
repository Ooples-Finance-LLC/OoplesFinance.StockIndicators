```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)gStar [29]** |   **271.8 μs** |  **17.48 μs** |  **11.56 μs** |  **1.00** |    **0.06** |   **71.68 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)gStar [29] |   883.3 μs |  39.10 μs |  23.27 μs |  3.26 |    0.15 |  901.43 KB |       12.58 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Trady(...)gStar [29]** | **1,209.7 μs** |  **76.61 μs** |  **45.59 μs** |  **1.00** |    **0.05** |  **650.39 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)gStar [29] | 6,765.9 μs | 285.77 μs | 189.02 μs |  5.60 |    0.24 | 8752.46 KB |       13.46 |
