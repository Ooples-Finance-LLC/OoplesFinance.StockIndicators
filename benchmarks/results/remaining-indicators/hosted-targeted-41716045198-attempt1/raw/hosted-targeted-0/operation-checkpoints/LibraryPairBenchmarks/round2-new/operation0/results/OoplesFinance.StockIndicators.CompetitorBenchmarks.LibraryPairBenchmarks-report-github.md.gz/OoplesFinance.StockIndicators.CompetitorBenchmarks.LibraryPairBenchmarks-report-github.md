```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)iStar [33]** |   **200.0 μs** |   **3.71 μs** |   **1.94 μs** |  **1.00** |    **0.01** |   **69.8 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)iStar [33] |   934.2 μs |  49.13 μs |  32.49 μs |  4.67 |    0.16 | 963.64 KB |       13.81 |
|            |       |                      |            |           |           |       |         |           |             |
| **Ooples**     | **10000** | **Trady(...)iStar [33]** |   **970.4 μs** | **135.22 μs** |  **80.47 μs** |  **1.01** |    **0.11** | **646.63 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)iStar [33] | 6,963.4 μs | 338.14 μs | 201.22 μs |  7.22 |    0.58 | 9377.5 KB |       14.50 |
