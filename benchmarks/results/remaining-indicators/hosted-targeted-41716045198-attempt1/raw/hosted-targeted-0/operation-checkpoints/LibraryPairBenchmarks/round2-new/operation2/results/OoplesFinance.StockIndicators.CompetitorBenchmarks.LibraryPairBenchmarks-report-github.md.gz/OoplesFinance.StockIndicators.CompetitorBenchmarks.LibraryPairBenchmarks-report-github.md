```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)iStar [34]** |   **204.6 μs** |  **10.68 μs** |   **5.59 μs** |  **1.00** |    **0.04** |    **69.8 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)iStar [34] |   368.0 μs |   7.65 μs |   4.00 μs |  1.80 |    0.05 |  680.06 KB |        9.74 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Trady(...)iStar [34]** | **1,012.0 μs** | **159.24 μs** | **105.33 μs** |  **1.01** |    **0.14** |  **645.31 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)iStar [34] | 3,912.8 μs |  55.75 μs |  33.18 μs |  3.90 |    0.36 | 6581.23 KB |       10.20 |
