```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |---------------- |------ |-----------:|----------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **EveningDojiStar** | **1000**  |   **346.1 μs** |   **1.14 μs** |  **0.68 μs** |       **-** |      **-** |  **61.52 KB** |
| BuilderLatestOnly | EveningDojiStar | 1000  |   270.0 μs |   1.36 μs |  0.81 μs |       - |      - |  13.53 KB |
| **BuilderFull**       | **EveningDojiStar** | **10000** | **1,376.0 μs** | **135.29 μs** | **89.49 μs** | **31.2500** | **7.8125** | **568.28 KB** |
| BuilderLatestOnly | EveningDojiStar | 10000 | 1,302.4 μs | 118.57 μs | 78.43 μs |       - |      - |  98.17 KB |
