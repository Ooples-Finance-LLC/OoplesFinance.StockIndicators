```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0       | Gen1      | Allocated    | Alloc Ratio |
|------------------ |---------------- |------ |-------------:|------------:|------------:|------:|--------:|-----------:|----------:|-------------:|------------:|
| **BuilderFull**       | **MorningDojiStar** | **1000**  |     **154.4 μs** |     **4.18 μs** |     **2.49 μs** |  **0.01** |    **0.00** |          **-** |         **-** |     **61.41 KB** |       **0.002** |
| BuilderLatestOnly | MorningDojiStar | 1000  |     149.3 μs |     1.33 μs |     0.79 μs |  0.01 |    0.00 |          - |         - |     13.46 KB |       0.001 |
| NativeSingle      | MorningDojiStar | 1000  |  10,567.7 μs |   222.54 μs |   116.39 μs |  1.00 |    0.01 |  1555.5556 |  111.1111 |  26324.24 KB |       1.000 |
| NativeParallel    | MorningDojiStar | 1000  |   6,631.5 μs |   173.87 μs |   115.00 μs |  0.63 |    0.01 |  1642.8571 |  285.7143 |     26332 KB |       1.000 |
|                   |                 |       |              |             |             |       |         |            |           |              |             |
| **BuilderFull**       | **MorningDojiStar** | **10000** |     **832.6 μs** |    **69.14 μs** |    **36.16 μs** | **0.008** |    **0.00** |    **31.2500** |    **7.8125** |    **568.03 KB** |       **0.002** |
| BuilderLatestOnly | MorningDojiStar | 10000 |     796.1 μs |    17.31 μs |     9.05 μs | 0.008 |    0.00 |          - |         - |     97.92 KB |       0.000 |
| NativeSingle      | MorningDojiStar | 10000 | 104,716.5 μs | 2,451.73 μs | 1,621.67 μs | 1.000 |    0.02 | 16250.0000 | 1500.0000 | 266747.82 KB |       1.000 |
| NativeParallel    | MorningDojiStar | 10000 |  65,349.3 μs | 1,928.67 μs | 1,275.70 μs | 0.624 |    0.01 | 16750.0000 | 3000.0000 | 266825.42 KB |       1.000 |
