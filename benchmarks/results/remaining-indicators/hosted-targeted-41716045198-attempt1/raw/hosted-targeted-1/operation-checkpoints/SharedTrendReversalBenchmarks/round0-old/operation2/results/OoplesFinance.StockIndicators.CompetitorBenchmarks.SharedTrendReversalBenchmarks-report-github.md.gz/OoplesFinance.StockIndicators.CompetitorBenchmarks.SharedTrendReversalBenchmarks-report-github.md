```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |----------------- |------ |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **MoringinDojiStar** | **1000**  |   **360.3 μs** |  **24.91 μs** |  **13.03 μs** |       **-** |       **-** |  **61.52 KB** |
| BuilderLatestOnly | MoringinDojiStar | 1000  |   262.8 μs |   5.67 μs |   3.37 μs |       - |       - |  13.53 KB |
| **BuilderFull**       | **MoringinDojiStar** | **10000** | **1,368.1 μs** | **168.73 μs** | **111.61 μs** | **31.2500** | **15.6250** | **568.34 KB** |
| BuilderLatestOnly | MoringinDojiStar | 10000 | 1,319.7 μs | 114.44 μs |  75.69 μs |       - |       - |  98.16 KB |
