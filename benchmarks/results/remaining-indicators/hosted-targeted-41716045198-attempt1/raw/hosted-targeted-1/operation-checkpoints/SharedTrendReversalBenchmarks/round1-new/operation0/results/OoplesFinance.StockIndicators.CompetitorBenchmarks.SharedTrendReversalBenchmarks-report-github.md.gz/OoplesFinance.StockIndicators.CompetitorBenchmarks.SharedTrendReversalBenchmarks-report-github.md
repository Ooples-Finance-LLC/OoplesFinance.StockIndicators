```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean     | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |---------------- |------ |---------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **EveningDojiStar** | **1000**  | **157.7 μs** |  **4.24 μs** |  **2.22 μs** |       **-** |      **-** |  **61.41 KB** |
| BuilderLatestOnly | EveningDojiStar | 1000  | 150.1 μs |  1.88 μs |  0.98 μs |       - |      - |  13.46 KB |
| **BuilderFull**       | **EveningDojiStar** | **10000** | **820.0 μs** | **20.71 μs** | **10.83 μs** | **31.2500** | **7.8125** | **568.03 KB** |
| BuilderLatestOnly | EveningDojiStar | 10000 | 806.9 μs | 88.82 μs | 52.86 μs |       - |      - |  97.92 KB |
