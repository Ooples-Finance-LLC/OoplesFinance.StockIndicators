```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0       | Gen1      | Allocated    | Alloc Ratio |
|------------------ |------------ |------ |-------------:|------------:|------------:|------:|--------:|-----------:|----------:|-------------:|------------:|
| **BuilderFull**       | **MorningStar** | **1000**  |     **152.8 μs** |     **2.91 μs** |     **1.73 μs** | **0.008** |    **0.00** |          **-** |         **-** |      **63.3 KB** |       **0.001** |
| BuilderLatestOnly | MorningStar | 1000  |     148.1 μs |     1.73 μs |     0.90 μs | 0.007 |    0.00 |          - |         - |     15.34 KB |       0.000 |
| NativeSingle      | MorningStar | 1000  |  20,159.4 μs | 1,041.59 μs |   688.95 μs | 1.001 |    0.05 |  3000.0000 |  250.0000 |  50072.86 KB |       1.000 |
| NativeParallel    | MorningStar | 1000  |  12,930.4 μs |   474.72 μs |   314.00 μs | 0.642 |    0.03 |  3125.0000 |  500.0000 |  50083.84 KB |       1.000 |
|                   |             |       |              |             |             |       |         |            |           |              |             |
| **BuilderFull**       | **MorningStar** | **10000** |     **819.3 μs** |    **72.88 μs** |    **43.37 μs** | **0.004** |    **0.00** |    **31.2500** |    **7.8125** |    **575.56 KB** |       **0.001** |
| BuilderLatestOnly | MorningStar | 10000 |   1,081.0 μs |   244.16 μs |   161.50 μs | 0.005 |    0.00 |     3.9063 |         - |    105.41 KB |       0.000 |
| NativeSingle      | MorningStar | 10000 | 206,551.9 μs | 2,754.21 μs | 1,821.74 μs | 1.000 |    0.01 | 31000.0000 | 2750.0000 | 510415.82 KB |       1.000 |
| NativeParallel    | MorningStar | 10000 | 127,095.4 μs | 4,402.15 μs | 2,911.75 μs | 0.615 |    0.01 | 32000.0000 | 6000.0000 | 510577.09 KB |       1.000 |
