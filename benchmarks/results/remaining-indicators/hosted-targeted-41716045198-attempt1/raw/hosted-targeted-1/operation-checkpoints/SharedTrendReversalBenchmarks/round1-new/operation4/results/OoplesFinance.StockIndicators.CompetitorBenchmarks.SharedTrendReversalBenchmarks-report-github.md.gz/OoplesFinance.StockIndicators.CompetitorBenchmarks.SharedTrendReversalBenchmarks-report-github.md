```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean     | Error     | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |------------ |------ |---------:|----------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **MorningStar** | **1000**  | **155.9 μs** |   **5.43 μs** |  **2.84 μs** |       **-** |      **-** |   **63.3 KB** |
| BuilderLatestOnly | MorningStar | 1000  | 146.6 μs |   2.20 μs |  1.15 μs |       - |      - |  15.34 KB |
| **BuilderFull**       | **MorningStar** | **10000** | **831.8 μs** |  **97.42 μs** | **64.44 μs** | **31.2500** | **7.8125** | **575.56 KB** |
| BuilderLatestOnly | MorningStar | 10000 | 795.4 μs | 107.79 μs | 71.29 μs |       - |      - | 105.44 KB |
