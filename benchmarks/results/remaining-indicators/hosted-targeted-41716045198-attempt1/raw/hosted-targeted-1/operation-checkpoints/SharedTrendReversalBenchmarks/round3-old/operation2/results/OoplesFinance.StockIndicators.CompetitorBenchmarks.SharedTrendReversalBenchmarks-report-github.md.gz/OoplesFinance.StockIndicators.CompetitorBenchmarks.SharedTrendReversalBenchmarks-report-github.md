```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error     | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |----------------- |------ |-----------:|----------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **MoringinDojiStar** | **1000**  |   **345.6 μs** |   **0.92 μs** |  **0.48 μs** |       **-** |      **-** |   **61.6 KB** |
| BuilderLatestOnly | MoringinDojiStar | 1000  |   261.0 μs |   2.11 μs |  1.26 μs |       - |      - |  13.53 KB |
| **BuilderFull**       | **MoringinDojiStar** | **10000** | **1,347.1 μs** | **122.17 μs** | **80.81 μs** | **31.2500** | **7.8125** | **568.27 KB** |
| BuilderLatestOnly | MoringinDojiStar | 10000 | 1,342.5 μs | 127.09 μs | 84.06 μs |       - |      - |  98.16 KB |
