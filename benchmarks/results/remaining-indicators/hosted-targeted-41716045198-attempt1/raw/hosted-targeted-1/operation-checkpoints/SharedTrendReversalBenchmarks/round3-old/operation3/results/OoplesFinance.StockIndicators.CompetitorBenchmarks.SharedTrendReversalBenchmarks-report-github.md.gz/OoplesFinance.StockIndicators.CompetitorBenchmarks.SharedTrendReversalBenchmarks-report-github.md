```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |-----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **MorningDojiStar** | **1000**  |   **350.9 μs** |   **3.34 μs** |  **1.99 μs** |       **-** |       **-** |   **61.6 KB** |
| BuilderLatestOnly | MorningDojiStar | 1000  |   257.9 μs |   2.54 μs |  1.33 μs |       - |       - |  13.53 KB |
| **BuilderFull**       | **MorningDojiStar** | **10000** | **1,340.0 μs** |  **49.20 μs** | **25.73 μs** | **31.2500** | **15.6250** | **568.36 KB** |
| BuilderLatestOnly | MorningDojiStar | 10000 | 1,370.2 μs | 135.57 μs | 89.67 μs |       - |       - |  98.17 KB |
