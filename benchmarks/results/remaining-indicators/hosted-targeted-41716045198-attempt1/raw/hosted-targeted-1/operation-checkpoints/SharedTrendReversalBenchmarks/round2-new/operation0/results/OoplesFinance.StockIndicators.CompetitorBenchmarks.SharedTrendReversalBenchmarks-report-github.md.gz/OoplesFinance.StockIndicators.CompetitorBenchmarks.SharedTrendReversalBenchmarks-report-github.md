```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0       | Gen1      | Allocated    | Alloc Ratio |
|------------------ |---------------- |------ |-------------:|------------:|------------:|------:|--------:|-----------:|----------:|-------------:|------------:|
| **BuilderFull**       | **EveningDojiStar** | **1000**  |     **160.8 μs** |     **3.81 μs** |     **1.99 μs** |  **0.01** |    **0.00** |          **-** |         **-** |     **61.45 KB** |       **0.002** |
| BuilderLatestOnly | EveningDojiStar | 1000  |     151.0 μs |     1.87 μs |     1.11 μs |  0.01 |    0.00 |          - |         - |     13.46 KB |       0.001 |
| NativeSingle      | EveningDojiStar | 1000  |  12,933.9 μs |   186.31 μs |   110.87 μs |  1.00 |    0.01 |  1500.0000 |         - |  26475.27 KB |       1.000 |
| NativeParallel    | EveningDojiStar | 1000  |   8,002.5 μs |   338.70 μs |   224.03 μs |  0.62 |    0.02 |  1615.3846 |  307.6923 |  26481.85 KB |       1.000 |
|                   |                 |       |              |             |             |       |         |            |           |              |             |
| **BuilderFull**       | **EveningDojiStar** | **10000** |     **879.3 μs** |   **175.07 μs** |   **115.80 μs** | **0.007** |    **0.00** |    **31.2500** |    **7.8125** |    **568.02 KB** |       **0.002** |
| BuilderLatestOnly | EveningDojiStar | 10000 |     844.7 μs |   139.69 μs |    92.40 μs | 0.006 |    0.00 |          - |         - |     97.92 KB |       0.000 |
| NativeSingle      | EveningDojiStar | 10000 | 131,086.9 μs | 2,113.08 μs | 1,397.67 μs | 1.000 |    0.01 | 16250.0000 | 1500.0000 | 267591.16 KB |       1.000 |
| NativeParallel    | EveningDojiStar | 10000 |  79,379.8 μs | 2,753.48 μs | 1,821.26 μs | 0.606 |    0.01 | 16750.0000 | 3250.0000 | 267642.72 KB |       1.000 |
