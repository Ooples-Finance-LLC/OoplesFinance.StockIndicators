```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean     | Error     | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |---------------- |------ |---------:|----------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **MorningDojiStar** | **1000**  | **150.3 μs** |   **3.20 μs** |  **1.90 μs** |       **-** |      **-** |  **61.33 KB** |
| BuilderLatestOnly | MorningDojiStar | 1000  | 150.2 μs |   1.59 μs |  0.95 μs |       - |      - |  13.46 KB |
| **BuilderFull**       | **MorningDojiStar** | **10000** | **849.3 μs** | **123.94 μs** | **73.75 μs** | **31.2500** | **7.8125** | **568.03 KB** |
| BuilderLatestOnly | MorningDojiStar | 10000 | 805.7 μs |  35.02 μs | 18.32 μs |       - |      - |  97.92 KB |
