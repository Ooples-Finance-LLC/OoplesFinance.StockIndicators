```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0       | Gen1      | Allocated    | Alloc Ratio |
|------------------ |----------------- |------ |-------------:|------------:|------------:|------:|--------:|-----------:|----------:|-------------:|------------:|
| **BuilderFull**       | **MoringinDojiStar** | **1000**  |     **164.4 μs** |     **8.57 μs** |     **5.10 μs** |  **0.02** |    **0.00** |          **-** |         **-** |     **61.41 KB** |       **0.002** |
| BuilderLatestOnly | MoringinDojiStar | 1000  |     151.1 μs |     1.48 μs |     0.77 μs |  0.01 |    0.00 |          - |         - |     13.45 KB |       0.001 |
| NativeSingle      | MoringinDojiStar | 1000  |  10,545.2 μs |   187.49 μs |   124.01 μs |  1.00 |    0.02 |  1500.0000 |  125.0000 |  26324.21 KB |       1.000 |
| NativeParallel    | MoringinDojiStar | 1000  |   6,989.6 μs |   385.63 μs |   255.07 μs |  0.66 |    0.02 |  1600.0000 |  266.6667 |  26332.22 KB |       1.000 |
|                   |                  |       |              |             |             |       |         |            |           |              |             |
| **BuilderFull**       | **MoringinDojiStar** | **10000** |     **872.2 μs** |   **106.51 μs** |    **70.45 μs** | **0.008** |    **0.00** |    **31.2500** |    **7.8125** |    **568.02 KB** |       **0.002** |
| BuilderLatestOnly | MoringinDojiStar | 10000 |     895.7 μs |   169.88 μs |   112.37 μs | 0.008 |    0.00 |          - |         - |     97.91 KB |       0.000 |
| NativeSingle      | MoringinDojiStar | 10000 | 107,648.5 μs | 1,910.30 μs | 1,263.54 μs | 1.000 |    0.02 | 16250.0000 | 1500.0000 |  266747.5 KB |       1.000 |
| NativeParallel    | MoringinDojiStar | 10000 |  65,748.3 μs | 1,577.47 μs |   938.73 μs | 0.611 |    0.01 | 16750.0000 | 3250.0000 | 266811.38 KB |       1.000 |
