```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0       | Gen1      | Allocated    | Alloc Ratio |
|------------------ |------------ |------ |-------------:|------------:|------------:|------:|--------:|-----------:|----------:|-------------:|------------:|
| **BuilderFull**       | **EveningStar** | **1000**  |     **152.7 μs** |     **4.59 μs** |     **2.40 μs** | **0.007** |    **0.00** |          **-** |         **-** |     **63.26 KB** |       **0.001** |
| BuilderLatestOnly | EveningStar | 1000  |     141.3 μs |     5.08 μs |     3.36 μs | 0.006 |    0.00 |          - |         - |     15.34 KB |       0.000 |
| NativeSingle      | EveningStar | 1000  |  23,066.8 μs |   549.93 μs |   363.74 μs | 1.000 |    0.02 |  3000.0000 |  250.0000 |  50316.87 KB |       1.000 |
| NativeParallel    | EveningStar | 1000  |  14,848.2 μs |   594.07 μs |   353.52 μs | 0.644 |    0.02 |  3142.8571 |  571.4286 |   50331.4 KB |       1.000 |
|                   |             |       |              |             |             |       |         |            |           |              |             |
| **BuilderFull**       | **EveningStar** | **10000** |     **893.5 μs** |   **126.31 μs** |    **83.55 μs** | **0.004** |    **0.00** |    **31.2500** |    **7.8125** |    **575.56 KB** |       **0.001** |
| BuilderLatestOnly | EveningStar | 10000 |     803.5 μs |    71.96 μs |    42.82 μs | 0.003 |    0.00 |          - |         - |    105.45 KB |       0.000 |
| NativeSingle      | EveningStar | 10000 | 238,931.3 μs | 3,747.40 μs | 2,478.67 μs | 1.000 |    0.01 | 31000.0000 | 2750.0000 | 510236.34 KB |       1.000 |
| NativeParallel    | EveningStar | 10000 | 145,693.7 μs | 2,200.78 μs | 1,455.68 μs | 0.610 |    0.01 | 32000.0000 | 6000.0000 |  510392.8 KB |       1.000 |
