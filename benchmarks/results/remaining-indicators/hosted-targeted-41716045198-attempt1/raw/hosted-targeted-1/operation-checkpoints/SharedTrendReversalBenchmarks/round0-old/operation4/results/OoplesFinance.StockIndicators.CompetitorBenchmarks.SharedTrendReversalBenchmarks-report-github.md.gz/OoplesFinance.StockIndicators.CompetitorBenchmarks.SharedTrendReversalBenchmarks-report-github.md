```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |------------ |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **MorningStar** | **1000**  |   **375.6 μs** |   **5.62 μs** |   **3.35 μs** |       **-** |  **63.36 KB** |
| BuilderLatestOnly | MorningStar | 1000  |   291.8 μs |   2.48 μs |   1.47 μs |       - |  15.44 KB |
| **BuilderFull**       | **MorningStar** | **10000** | **1,566.9 μs** | **200.75 μs** | **132.78 μs** | **31.2500** | **576.02 KB** |
| BuilderLatestOnly | MorningStar | 10000 | 1,752.4 μs | 163.37 μs |  97.22 μs |       - | 105.91 KB |
