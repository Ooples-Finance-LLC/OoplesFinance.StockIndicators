```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetTsi** | **1000**  |   **339.5 μs** |   **8.80 μs** |   **5.82 μs** |  **3.9063** |  **81.02 KB** |
| BuilderLatestOnly | Skender.GetTsi | 1000  |   332.7 μs |   5.89 μs |   3.51 μs |  1.9531 |  33.42 KB |
| **BuilderFull**       | **Skender.GetTsi** | **10000** | **3,777.9 μs** |  **54.91 μs** |  **32.68 μs** | **31.2500** | **784.67 KB** |
| BuilderLatestOnly | Skender.GetTsi | 10000 | 3,827.8 μs | 159.52 μs | 105.51 μs |       - | 314.82 KB |
