```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetTsi** | **1000**  |   **319.33 μs** |   **3.218 μs** |   **1.915 μs** | **17.54** |    **0.23** |        **-** |        **-** |        **-** |   **81.07 KB** |        **0.53** |
| BuilderLatestOnly | Skender.GetTsi | 1000  |   313.34 μs |   7.676 μs |   4.568 μs | 17.21 |    0.32 |   1.9531 |        - |        - |   33.42 KB |        0.22 |
| NativeSingle      | Skender.GetTsi | 1000  |    18.21 μs |   0.348 μs |   0.230 μs |  1.00 |    0.02 |   9.2773 |   1.9531 |        - |  152.88 KB |        1.00 |
| NativeParallel    | Skender.GetTsi | 1000  |    96.54 μs |   4.523 μs |   2.992 μs |  5.30 |    0.17 |  25.3906 |   5.8594 |        - |  391.01 KB |        2.56 |
|                   |                |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetTsi** | **10000** | **3,618.85 μs** |  **47.881 μs** |  **25.043 μs** | **10.31** |    **0.31** |  **31.2500** |        **-** |        **-** |  **784.66 KB** |        **0.51** |
| BuilderLatestOnly | Skender.GetTsi | 10000 | 3,641.30 μs | 119.832 μs |  71.310 μs | 10.38 |    0.36 |        - |        - |        - |  314.83 KB |        0.21 |
| NativeSingle      | Skender.GetTsi | 10000 |   351.25 μs |  16.268 μs |  10.760 μs |  1.00 |    0.04 |  99.6094 |  99.6094 |  99.6094 | 1524.75 KB |        1.00 |
| NativeParallel    | Skender.GetTsi | 10000 | 1,446.39 μs | 302.664 μs | 200.194 μs |  4.12 |    0.56 | 359.3750 | 304.6875 | 156.2500 | 3891.92 KB |        2.55 |
