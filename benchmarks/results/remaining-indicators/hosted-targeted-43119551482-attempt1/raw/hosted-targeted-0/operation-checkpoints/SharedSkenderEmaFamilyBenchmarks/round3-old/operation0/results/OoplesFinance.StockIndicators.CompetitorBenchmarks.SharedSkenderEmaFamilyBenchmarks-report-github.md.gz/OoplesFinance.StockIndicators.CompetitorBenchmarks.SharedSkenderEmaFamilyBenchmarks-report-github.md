```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetTsi** | **1000**  |   **349.1 μs** | **11.40 μs** |  **6.79 μs** |  **3.9063** |  **80.99 KB** |
| BuilderLatestOnly | Skender.GetTsi | 1000  |   340.5 μs |  6.01 μs |  3.57 μs |  1.9531 |  33.42 KB |
| **BuilderFull**       | **Skender.GetTsi** | **10000** | **3,818.3 μs** | **47.59 μs** | **28.32 μs** | **31.2500** |  **784.6 KB** |
| BuilderLatestOnly | Skender.GetTsi | 10000 | 3,812.4 μs | 27.45 μs | 18.15 μs |       - | 314.79 KB |
