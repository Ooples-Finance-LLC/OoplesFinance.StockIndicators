```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetTsi** |   **395.76 μs** | **10.929 μs** |  **6.504 μs** |  **1.00** |    **0.02** |  **162.47 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetTsi |    31.99 μs |  1.766 μs |  0.923 μs |  0.08 |    0.00 |  203.55 KB |        1.25 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetTsi** | **3,864.26 μs** | **44.587 μs** | **26.533 μs** |  **1.00** |    **0.01** | **1593.14 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetTsi |   328.40 μs |  3.761 μs |  2.238 μs |  0.08 |    0.00 | 2017.01 KB |        1.27 |
