```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDI [22]** |   **198.25 μs** |  **1.934 μs** |  **1.151 μs** |  **1.00** |  **105.64 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDI [22] |    15.06 μs |  0.722 μs |  0.378 μs |  0.08 |   38.59 KB |        0.37 |
|            |       |                      |             |           |           |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDI [22]** | **1,783.90 μs** | **20.518 μs** | **12.210 μs** |  **1.00** | **1033.74 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDI [22] |   137.19 μs |  1.959 μs |  1.025 μs |  0.08 |  329.61 KB |        0.32 |
