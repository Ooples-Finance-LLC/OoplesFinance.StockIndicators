```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **139.0 μs** |  **3.96 μs** |  **2.36 μs** |  **3.9063** |  **65.01 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   140.2 μs |  4.50 μs |  2.68 μs |  0.9766 |  17.41 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **1,677.2 μs** | **12.60 μs** |  **7.50 μs** | **31.2500** | **627.95 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 1,681.4 μs | 17.82 μs | 10.60 μs |       - | 158.09 KB |
