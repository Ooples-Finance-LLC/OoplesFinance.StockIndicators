```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **132.418 μs** |  **1.7811 μs** | **0.9316 μs** | **20.68** |    **0.21** |  **3.9063** |      **-** |  **64.97 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   129.733 μs |  3.7177 μs | 2.2124 μs | 20.26 |    0.36 |  0.9766 |      - |  17.36 KB |        2.25 |
| NativeSingle      | TaLib(...)lusDI [22] | 1000  |     6.402 μs |  0.0803 μs | 0.0531 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 1000  |    83.368 μs |  0.8077 μs | 0.4807 μs | 13.02 |    0.12 |  1.9531 |      - |  27.25 KB |        3.53 |
|                   |                      |       |              |            |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **1,623.454 μs** |  **6.1022 μs** | **3.1915 μs** | **26.73** |    **0.09** | **31.2500** |      **-** | **627.91 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 1,607.776 μs | 14.8697 μs | 7.7771 μs | 26.47 |    0.14 |       - |      - | 158.08 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDI [22] | 10000 |    60.743 μs |  0.3463 μs | 0.1811 μs |  1.00 |    0.00 |  4.3945 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 10000 |   149.662 μs |  3.5396 μs | 2.1064 μs |  2.46 |    0.03 | 17.5781 | 3.9063 | 273.34 KB |        3.50 |
