```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **132.5 μs** |  **2.06 μs** |  **1.08 μs** |  **3.9063** |  **64.97 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   128.5 μs |  1.04 μs |  0.62 μs |  0.9766 |  17.36 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **1,625.0 μs** | **18.94 μs** |  **9.90 μs** | **31.2500** |  **627.9 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 1,610.2 μs | 20.89 μs | 10.93 μs |       - |  158.1 KB |
