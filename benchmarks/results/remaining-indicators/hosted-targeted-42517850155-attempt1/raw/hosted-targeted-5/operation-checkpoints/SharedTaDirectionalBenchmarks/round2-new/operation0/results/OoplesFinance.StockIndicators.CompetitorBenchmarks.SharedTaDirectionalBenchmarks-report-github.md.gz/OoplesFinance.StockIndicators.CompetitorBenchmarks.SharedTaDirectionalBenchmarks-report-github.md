```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **410.02 μs** |  **3.197 μs** |  **1.672 μs** | **27.08** |    **0.14** |       **-** |      **-** |  **65.19 KB** |        **8.61** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   405.84 μs |  4.019 μs |  2.658 μs | 26.80 |    0.19 |       - |      - |   17.6 KB |        2.32 |
| NativeSingle      | TaLib.Functions.Adx | 1000  |    15.14 μs |  0.079 μs |  0.052 μs |  1.00 |    0.00 |  0.3662 |      - |   7.57 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 1000  |   103.82 μs |  4.071 μs |  2.693 μs |  6.86 |    0.17 |  0.9766 |      - |  26.72 KB |        3.53 |
|                   |                     |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **4,241.18 μs** | **16.814 μs** | **10.006 μs** | **28.10** |    **0.15** | **31.2500** |      **-** | **630.88 KB** |        **8.10** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 4,189.69 μs | 20.351 μs | 10.644 μs | 27.76 |    0.15 |       - |      - | 161.06 KB |        2.07 |
| NativeSingle      | TaLib.Functions.Adx | 10000 |   150.94 μs |  1.270 μs |  0.756 μs |  1.00 |    0.01 |  3.9063 |      - |  77.89 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 10000 |   275.84 μs | 14.573 μs |  9.639 μs |  1.83 |    0.06 | 17.5781 | 3.9063 | 272.82 KB |        3.50 |
