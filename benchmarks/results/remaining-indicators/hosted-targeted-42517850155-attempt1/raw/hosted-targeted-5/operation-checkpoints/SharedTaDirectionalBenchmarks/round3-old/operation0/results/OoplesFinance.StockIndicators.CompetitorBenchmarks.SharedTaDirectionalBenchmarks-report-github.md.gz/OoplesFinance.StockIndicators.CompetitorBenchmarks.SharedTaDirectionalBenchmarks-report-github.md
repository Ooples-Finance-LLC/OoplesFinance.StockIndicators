```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev  | Gen0    | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **416.0 μs** |  **3.34 μs** | **1.75 μs** |       **-** |  **65.21 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   411.6 μs |  6.66 μs | 3.48 μs |       - |  17.65 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **4,306.3 μs** | **16.78 μs** | **9.98 μs** | **31.2500** | **630.89 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 4,248.8 μs | 15.42 μs | 8.07 μs |       - | 161.09 KB |
