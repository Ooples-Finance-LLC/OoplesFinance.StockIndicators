```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **396.7 μs** |  **2.26 μs** |  **1.18 μs** |       **-** |  **65.15 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   395.8 μs |  5.22 μs |  3.11 μs |       - |   17.6 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **4,179.5 μs** | **16.39 μs** |  **9.75 μs** | **31.2500** | **630.84 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 4,148.2 μs | 22.86 μs | 11.96 μs |       - | 161.05 KB |
