```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adx** |   **474.11 μs** | **41.115 μs** | **27.195 μs** |  **1.00** |    **0.08** |  **105.82 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adx |    23.48 μs |  1.118 μs |  0.585 μs |  0.05 |    0.00 |   40.55 KB |        0.38 |
|            |       |                     |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adx** | **4,386.73 μs** | **97.726 μs** | **58.155 μs** |  **1.00** |    **0.02** | **1039.43 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adx |   220.47 μs |  6.580 μs |  3.442 μs |  0.05 |    0.00 |  330.59 KB |        0.32 |
