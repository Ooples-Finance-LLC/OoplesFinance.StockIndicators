```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDM [23]** |   **160.94 μs** |  **8.719 μs** |  **5.189 μs** |  **1.00** |    **0.04** |  **105.61 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDM [23] |    19.51 μs |  1.230 μs |  0.732 μs |  0.12 |    0.01 |   33.42 KB |        0.32 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDM [23]** | **1,282.52 μs** | **20.156 μs** | **11.994 μs** |  **1.00** |    **0.01** | **1033.38 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDM [23] |   159.92 μs |  3.549 μs |  2.112 μs |  0.12 |    0.00 |  328.95 KB |        0.32 |
