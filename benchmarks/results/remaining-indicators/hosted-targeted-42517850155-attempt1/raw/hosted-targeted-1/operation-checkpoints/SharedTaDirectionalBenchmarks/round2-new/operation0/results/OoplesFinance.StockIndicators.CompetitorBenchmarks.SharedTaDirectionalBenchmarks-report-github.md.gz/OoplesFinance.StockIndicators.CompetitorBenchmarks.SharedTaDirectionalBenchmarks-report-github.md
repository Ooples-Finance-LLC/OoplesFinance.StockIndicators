```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **114.13 μs** |  **1.787 μs** |  **0.935 μs** | **11.32** |    **0.11** |      **-** |  **64.96 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   112.51 μs |  1.901 μs |  1.131 μs | 11.16 |    0.13 |      - |  17.36 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDM [23] | 1000  |    10.08 μs |  0.101 μs |  0.067 μs |  1.00 |    0.01 | 0.0610 |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 1000  |    72.13 μs |  4.845 μs |  3.205 μs |  7.16 |    0.31 |      - |  27.23 KB |        3.53 |
|                   |                      |       |             |           |           |       |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,135.81 μs** | **43.444 μs** | **28.735 μs** | **11.56** |    **0.29** |      **-** | **627.85 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 1,074.89 μs | 43.861 μs | 29.011 μs | 10.94 |    0.29 |      - | 158.04 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDM [23] | 10000 |    98.27 μs |  1.252 μs |  0.655 μs |  1.00 |    0.01 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 10000 |   188.70 μs | 12.489 μs |  8.261 μs |  1.92 |    0.08 | 2.9297 | 273.33 KB |        3.50 |
