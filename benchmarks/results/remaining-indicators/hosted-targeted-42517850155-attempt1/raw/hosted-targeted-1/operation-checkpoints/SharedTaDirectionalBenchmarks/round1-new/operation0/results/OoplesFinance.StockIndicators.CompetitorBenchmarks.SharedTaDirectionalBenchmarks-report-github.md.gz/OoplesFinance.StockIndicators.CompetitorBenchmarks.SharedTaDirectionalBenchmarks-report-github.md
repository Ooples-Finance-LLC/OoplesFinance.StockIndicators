```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev  | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **110.4 μs** |  **1.95 μs** | **1.16 μs** |  **64.96 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   103.5 μs |  2.36 μs | 1.56 μs |  17.36 KB |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,035.0 μs** | **12.52 μs** | **8.28 μs** | **627.79 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 |   988.0 μs | 16.19 μs | 8.47 μs | 158.04 KB |
