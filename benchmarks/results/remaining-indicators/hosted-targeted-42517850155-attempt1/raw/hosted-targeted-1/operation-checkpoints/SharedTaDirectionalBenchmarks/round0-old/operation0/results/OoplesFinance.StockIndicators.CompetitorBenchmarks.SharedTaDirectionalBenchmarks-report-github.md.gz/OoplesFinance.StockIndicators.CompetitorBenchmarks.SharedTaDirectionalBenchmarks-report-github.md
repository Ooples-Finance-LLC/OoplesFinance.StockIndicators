```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **126.5 μs** |  **1.80 μs** |  **1.07 μs** |  **65.05 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   109.8 μs |  2.49 μs |  1.30 μs |   17.4 KB |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,122.8 μs** | **46.49 μs** | **27.67 μs** |  **627.9 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 1,061.2 μs | 49.34 μs | 32.63 μs | 158.08 KB |
