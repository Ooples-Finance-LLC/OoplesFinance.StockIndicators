```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDI [23]** |   **220.64 μs** | **18.231 μs** | **10.849 μs** |  **1.00** |    **0.06** | **105.68 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDI [23] |    13.54 μs |  1.012 μs |  0.602 μs |  0.06 |    0.00 |  39.57 KB |        0.37 |
|            |       |                      |             |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)nusDI [23]** | **1,870.01 μs** | **15.292 μs** |  **7.998 μs** |  **1.00** |    **0.01** | **1033.7 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDI [23] |   122.76 μs | 12.772 μs |  8.448 μs |  0.07 |    0.00 | 330.92 KB |        0.32 |
