```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **132.377 μs** | **1.6274 μs** | **0.9685 μs** | **21.75** |    **0.19** |  **3.9063** |      **-** |  **64.97 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   131.623 μs | 4.1526 μs | 2.7467 μs | 21.63 |    0.44 |       - |      - |  17.37 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDI [23] | 1000  |     6.086 μs | 0.0481 μs | 0.0318 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 1000  |    82.561 μs | 1.2410 μs | 0.7385 μs | 13.57 |    0.13 |  1.4648 |      - |  27.25 KB |        3.53 |
|                   |                      |       |              |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **1,661.542 μs** | **4.0614 μs** | **2.1242 μs** | **28.05** |    **0.05** | **31.2500** |      **-** | **627.92 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 1,655.347 μs | 5.3578 μs | 2.8022 μs | 27.94 |    0.06 |       - |      - | 158.07 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDI [23] | 10000 |    59.238 μs | 0.1715 μs | 0.0897 μs |  1.00 |    0.00 |  4.3945 |      - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 10000 |   144.874 μs | 6.0462 μs | 3.9992 μs |  2.45 |    0.06 | 17.5781 | 3.9063 | 273.34 KB |        3.50 |
