```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **145.1 μs** |  **9.30 μs** |  **5.53 μs** |  **3.9063** |  **65.01 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   139.1 μs |  2.80 μs |  1.67 μs |  0.9766 |  17.41 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **1,720.9 μs** | **17.48 μs** | **10.40 μs** | **31.2500** | **627.94 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 1,691.7 μs | 12.36 μs |  7.36 μs |       - |  158.1 KB |
