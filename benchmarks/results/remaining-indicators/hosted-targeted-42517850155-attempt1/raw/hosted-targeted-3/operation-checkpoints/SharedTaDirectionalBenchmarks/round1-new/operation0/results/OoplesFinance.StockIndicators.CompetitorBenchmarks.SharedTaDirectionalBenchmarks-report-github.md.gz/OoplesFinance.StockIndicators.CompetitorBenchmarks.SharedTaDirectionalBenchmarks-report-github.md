```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error   | StdDev  | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **137.0 μs** | **4.21 μs** | **2.51 μs** |  **3.9063** |  **64.97 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   132.2 μs | 1.35 μs | 0.70 μs |  0.9766 |  17.36 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **1,674.0 μs** | **6.10 μs** | **3.19 μs** | **31.2500** | **627.94 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 1,655.4 μs | 4.96 μs | 2.59 μs |       - | 158.04 KB |
