```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **450.0 μs** |  **3.76 μs** |  **1.97 μs** |       **-** |  **66.31 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   446.7 μs |  5.47 μs |  3.62 μs |       - |  18.72 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **4,685.7 μs** | **18.72 μs** | **11.14 μs** | **31.2500** | **632.01 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 4,632.5 μs | 17.26 μs | 10.27 μs |       - | 161.93 KB |
