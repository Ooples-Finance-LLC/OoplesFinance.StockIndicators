```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **432.22 μs** |  **6.293 μs** |  **3.291 μs** | **25.47** |    **0.89** |       **-** |      **-** |  **66.26 KB** |        **4.42** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   428.55 μs |  2.114 μs |  1.105 μs | 25.25 |    0.87 |       - |      - |  18.67 KB |        1.25 |
| NativeSingle      | TaLib.Functions.Adxr | 1000  |    16.99 μs |  0.955 μs |  0.632 μs |  1.00 |    0.05 |  0.8545 |      - |  14.99 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 1000  |   105.86 μs |  4.217 μs |  2.509 μs |  6.24 |    0.26 |  2.9297 |      - |  45.44 KB |        3.03 |
|                   |                      |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **4,513.15 μs** | **26.747 μs** | **13.989 μs** | **26.85** |    **0.19** | **31.2500** |      **-** | **631.96 KB** |        **4.06** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 4,455.53 μs | 16.922 μs | 11.193 μs | 26.50 |    0.18 |       - |      - | 162.12 KB |        1.04 |
| NativeSingle      | TaLib.Functions.Adxr | 10000 |   168.12 μs |  1.727 μs |  1.142 μs |  1.00 |    0.01 |  8.7891 | 0.9766 | 155.63 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 10000 |   311.08 μs | 14.770 μs |  8.789 μs |  1.85 |    0.05 | 29.2969 | 7.8125 | 467.32 KB |        3.00 |
