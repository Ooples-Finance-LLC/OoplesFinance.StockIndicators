```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **461.6 μs** |  **2.40 μs** |  **1.26 μs** |       **-** |  **66.31 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   457.1 μs |  2.28 μs |  1.19 μs |       - |  18.72 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **4,990.4 μs** | **21.00 μs** | **12.49 μs** | **31.2500** | **631.97 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 4,772.4 μs | 40.81 μs | 26.99 μs |       - | 162.17 KB |
