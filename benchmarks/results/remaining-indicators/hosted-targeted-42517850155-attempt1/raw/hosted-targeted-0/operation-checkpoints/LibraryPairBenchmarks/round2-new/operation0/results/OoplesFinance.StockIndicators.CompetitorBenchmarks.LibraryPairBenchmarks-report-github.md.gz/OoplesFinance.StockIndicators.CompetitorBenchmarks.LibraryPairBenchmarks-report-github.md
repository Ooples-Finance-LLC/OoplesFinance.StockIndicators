```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDM [22]** | **127.76 μs** | **14.076 μs** | **9.310 μs** |  **1.00** |    **0.10** |  **105.68 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDM [22] |  28.33 μs |  2.017 μs | 1.200 μs |  0.22 |    0.02 |   39.94 KB |        0.38 |
|            |       |                      |           |           |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDM [22]** | **748.77 μs** |  **6.719 μs** | **3.514 μs** |  **1.00** |    **0.01** | **1029.48 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDM [22] |  98.71 μs |  3.297 μs | 1.962 μs |  0.13 |    0.00 |  324.07 KB |        0.31 |
