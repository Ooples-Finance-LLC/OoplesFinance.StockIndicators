```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |  **63.22 μs** |  **1.557 μs** |  **0.927 μs** |  **3.9063** |       **-** |  **65.01 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |  60.65 μs |  0.453 μs |  0.237 μs |  0.9766 |       - |   17.4 KB |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **632.30 μs** | **23.091 μs** | **15.273 μs** | **35.1563** | **11.7188** | **627.88 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 600.93 μs |  2.671 μs |  1.397 μs |  7.8125 |       - | 158.04 KB |
