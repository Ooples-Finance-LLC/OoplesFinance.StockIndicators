```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |  **66.28 μs** |  **1.188 μs** |  **0.707 μs** |  **3.9063** |  **0.4883** |  **65.01 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |  65.02 μs |  2.986 μs |  1.975 μs |  0.9766 |       - |   17.4 KB |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **650.20 μs** | **29.026 μs** | **19.199 μs** | **35.1563** | **11.7188** | **627.86 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 617.26 μs |  8.122 μs |  4.248 μs |  7.8125 |       - | 158.06 KB |
