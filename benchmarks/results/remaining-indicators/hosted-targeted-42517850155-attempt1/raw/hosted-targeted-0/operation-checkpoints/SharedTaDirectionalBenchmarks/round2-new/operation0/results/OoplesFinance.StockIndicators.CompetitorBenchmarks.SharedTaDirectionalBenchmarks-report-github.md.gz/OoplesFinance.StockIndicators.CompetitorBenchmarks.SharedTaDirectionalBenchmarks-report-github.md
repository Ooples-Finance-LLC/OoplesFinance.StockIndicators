```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |  **64.161 μs** |  **1.7138 μs** |  **1.0199 μs** |  **8.61** |    **0.13** |  **3.9063** |       **-** |  **64.96 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |  62.852 μs |  2.9387 μs |  1.9438 μs |  8.44 |    0.25 |  0.9766 |       - |  17.35 KB |        2.25 |
| NativeSingle      | TaLib(...)lusDM [22] | 1000  |   7.450 μs |  0.0188 μs |  0.0098 μs |  1.00 |    0.00 |  0.4272 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 1000  |  98.772 μs |  1.9699 μs |  1.3030 μs | 13.26 |    0.17 |  1.9531 |       - |  27.23 KB |        3.53 |
|                   |                      |       |            |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **621.106 μs** | **10.3405 μs** |  **6.1535 μs** |  **8.14** |    **0.22** | **35.1563** | **11.7188** | **627.83 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 622.552 μs | 22.2559 μs | 14.7209 μs |  8.16 |    0.27 |  7.8125 |       - |    158 KB |        2.02 |
| NativeSingle      | TaLib(...)lusDM [22] | 10000 |  76.340 μs |  3.0772 μs |  2.0354 μs |  1.00 |    0.04 |  4.3945 |       - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 10000 | 174.224 μs |  4.8871 μs |  2.9082 μs |  2.28 |    0.07 | 17.5781 |  2.9297 | 273.33 KB |        3.50 |
