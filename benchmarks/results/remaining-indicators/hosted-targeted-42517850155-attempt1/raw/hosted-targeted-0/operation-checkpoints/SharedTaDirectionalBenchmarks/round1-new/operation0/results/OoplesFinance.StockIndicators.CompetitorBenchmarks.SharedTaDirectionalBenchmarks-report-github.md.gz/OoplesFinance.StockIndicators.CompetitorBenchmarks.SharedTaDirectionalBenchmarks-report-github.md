```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |  **63.73 μs** |  **0.978 μs** | **0.582 μs** |  **3.9063** |       **-** |  **64.93 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |  61.50 μs |  0.376 μs | 0.197 μs |  0.9766 |       - |  17.36 KB |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **628.51 μs** | **11.705 μs** | **6.122 μs** | **35.1563** | **11.7188** | **627.79 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 609.35 μs |  4.726 μs | 2.472 μs |  7.8125 |       - |    158 KB |
