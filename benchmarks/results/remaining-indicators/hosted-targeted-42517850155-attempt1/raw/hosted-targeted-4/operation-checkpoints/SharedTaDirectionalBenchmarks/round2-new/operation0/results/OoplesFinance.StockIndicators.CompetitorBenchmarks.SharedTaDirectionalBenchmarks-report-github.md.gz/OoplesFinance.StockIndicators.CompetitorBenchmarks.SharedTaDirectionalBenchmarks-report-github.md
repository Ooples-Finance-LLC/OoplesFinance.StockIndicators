```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **436.88 μs** |  **4.350 μs** |  **2.275 μs** | **28.96** |    **0.19** |       **-** |      **-** |  **64.97 KB** |        **8.42** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   430.65 μs |  3.670 μs |  1.919 μs | 28.55 |    0.17 |       - |      - |  17.38 KB |        2.25 |
| NativeSingle      | TaLib.Functions.Dx | 1000  |    15.09 μs |  0.132 μs |  0.069 μs |  1.00 |    0.01 |  0.3662 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 1000  |   104.04 μs |  3.736 μs |  2.471 μs |  6.90 |    0.16 |  0.9766 |      - |  27.25 KB |        3.53 |
|                   |                    |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **4,538.39 μs** | **40.680 μs** | **24.208 μs** | **29.76** |    **0.21** | **31.2500** |      **-** | **628.06 KB** |        **8.05** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 4,470.93 μs | 29.975 μs | 17.838 μs | 29.32 |    0.19 |       - |      - | 158.23 KB |        2.03 |
| NativeSingle      | TaLib.Functions.Dx | 10000 |   152.48 μs |  1.384 μs |  0.824 μs |  1.00 |    0.01 |  3.9063 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 10000 |   262.69 μs |  9.950 μs |  5.921 μs |  1.72 |    0.04 | 17.5781 | 3.9063 | 273.35 KB |        3.50 |
