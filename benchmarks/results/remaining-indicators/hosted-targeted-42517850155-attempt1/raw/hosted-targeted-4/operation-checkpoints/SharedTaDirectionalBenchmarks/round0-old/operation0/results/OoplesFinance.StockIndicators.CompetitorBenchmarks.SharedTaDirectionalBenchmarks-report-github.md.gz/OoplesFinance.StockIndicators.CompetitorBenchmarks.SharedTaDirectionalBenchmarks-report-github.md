```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **451.8 μs** |  **6.15 μs** |  **3.66 μs** |       **-** |  **65.02 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   446.3 μs |  3.87 μs |  2.56 μs |       - |  17.43 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **4,670.3 μs** | **33.83 μs** | **20.13 μs** | **31.2500** | **628.11 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 4,631.0 μs | 29.41 μs | 15.38 μs |       - | 158.26 KB |
