```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **431.7 μs** |  **7.32 μs** |  **3.83 μs** |       **-** |  **64.94 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   423.9 μs |  5.89 μs |  3.51 μs |       - |  17.38 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **4,513.5 μs** | **54.32 μs** | **32.32 μs** | **31.2500** | **628.02 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 4,418.2 μs | 77.70 μs | 51.40 μs |       - | 158.23 KB |
