```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Dx** |   **498.62 μs** | **23.900 μs** | **14.222 μs** |  **1.00** |    **0.04** |  **105.64 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Dx |    21.46 μs |  0.489 μs |  0.256 μs |  0.04 |    0.00 |   40.23 KB |        0.38 |
|            |       |                    |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Dx** | **4,692.50 μs** | **39.940 μs** | **23.768 μs** |  **1.00** |    **0.01** | **1036.32 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Dx |   212.67 μs | 12.258 μs |  8.108 μs |  0.05 |    0.00 |  330.92 KB |        0.32 |
