```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error        | StdDev       | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|-------------:|-------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetPvo** |   **732.34 μs** |    **44.217 μs** |    **29.247 μs** |  **1.00** |    **0.05** |  **290.12 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetPvo |    83.15 μs |     3.377 μs |     1.766 μs |  0.11 |    0.00 |  375.59 KB |        1.29 |
|            |       |                |             |              |              |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetPvo** | **8,436.43 μs** | **2,142.059 μs** | **1,416.840 μs** |  **1.02** |    **0.23** | **2856.22 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetPvo |   888.57 μs |    69.556 μs |    46.007 μs |  0.11 |    0.02 |  3870.7 KB |        1.36 |
