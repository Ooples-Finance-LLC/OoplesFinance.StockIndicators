```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId          | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetMacd** |   **691.06 μs** | **48.167 μs** | **28.664 μs** |  **1.00** |    **0.05** |  **331.71 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetMacd |    95.62 μs |  1.949 μs |  1.019 μs |  0.14 |    0.01 |  456.36 KB |        1.38 |
|            |       |                 |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetMacd** | **6,401.27 μs** | **58.968 μs** | **39.004 μs** |  **1.00** |    **0.01** | **3266.63 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetMacd | 1,006.60 μs | 45.464 μs | 27.055 μs |  0.16 |    0.00 | 4672.18 KB |        1.43 |
