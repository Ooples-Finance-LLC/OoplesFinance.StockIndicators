```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)gence [50]** |    **650.4 μs** |    **35.32 μs** |    **21.02 μs** |  **1.00** |    **0.04** |         **-** |         **-** |         **-** |   **290.06 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)gence [50] |  2,212.7 μs |    16.98 μs |     8.88 μs |  3.41 |    0.10 |         - |         - |         - |  3521.46 KB |       12.14 |
|            |       |                      |             |             |             |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)gence [50]** |  **6,162.9 μs** |    **19.26 μs** |    **11.46 μs** |  **1.00** |    **0.00** |         **-** |         **-** |         **-** |  **2856.49 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)gence [50] | 23,969.0 μs | 2,469.60 μs | 1,633.49 μs |  3.89 |    0.25 | 2000.0000 | 1000.0000 | 1000.0000 | 34697.52 KB |       12.15 |
