```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)ogram [59]** |    **643.9 μs** |    **24.34 μs** |  **16.10 μs** |  **1.00** |    **0.03** |         **-** |         **-** |         **-** |   **240.71 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)ogram [59] |  2,458.5 μs |    64.56 μs |  42.70 μs |  3.82 |    0.11 |         - |         - |         - |  3699.02 KB |       15.37 |
|            |       |                      |             |             |           |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)ogram [59]** |  **6,100.1 μs** |    **82.56 μs** |  **43.18 μs** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |  **2368.06 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)ogram [59] | 28,250.9 μs | 1,230.30 μs | 732.13 μs |  4.63 |    0.12 | 2000.0000 | 1000.0000 | 1000.0000 | 36356.04 KB |       15.35 |
