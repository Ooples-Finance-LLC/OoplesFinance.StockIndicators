```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev  | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |   **421.1 μs** |  **2.12 μs** | **1.11 μs** |       **-** | **104.99 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |   413.0 μs |  2.80 μs | 1.66 μs |       - |  57.38 KB |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** | **4,160.2 μs** | **13.81 μs** | **8.22 μs** | **31.2500** | **1019.4 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 | 4,167.4 μs | 14.20 μs | 8.45 μs | 31.2500 | 549.74 KB |
