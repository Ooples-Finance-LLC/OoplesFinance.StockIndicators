```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |   **420.1 μs** |  **1.12 μs** |  **0.67 μs** |       **-** |     **105 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |   415.7 μs |  2.04 μs |  1.06 μs |       - |    57.4 KB |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** | **4,174.7 μs** | **34.25 μs** | **17.91 μs** | **31.2500** | **1019.67 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 | 4,200.0 μs | 26.15 μs | 13.68 μs | 31.2500 |  549.78 KB |
