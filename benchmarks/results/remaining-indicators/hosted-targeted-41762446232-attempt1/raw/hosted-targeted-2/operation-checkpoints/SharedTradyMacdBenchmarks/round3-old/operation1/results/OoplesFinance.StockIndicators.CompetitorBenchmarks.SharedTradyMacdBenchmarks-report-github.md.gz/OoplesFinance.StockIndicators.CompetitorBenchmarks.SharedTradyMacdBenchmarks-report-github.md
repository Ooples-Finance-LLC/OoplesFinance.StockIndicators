```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev  | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |   **396.4 μs** |  **2.30 μs** | **1.37 μs** |       **-** |  **73.63 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |   394.2 μs |  2.06 μs | 1.08 μs |       - |  26.04 KB |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** | **3,983.7 μs** | **16.65 μs** | **8.71 μs** | **31.2500** | **707.05 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 | 4,019.8 μs | 15.29 μs | 8.00 μs |       - | 237.12 KB |
