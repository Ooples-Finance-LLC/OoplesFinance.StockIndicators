```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |    **410.9 μs** |     **3.24 μs** |     **1.93 μs** |  **0.24** |    **0.00** |         **-** |         **-** |         **-** |      **105 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |    406.4 μs |     2.29 μs |     1.20 μs |  0.24 |    0.00 |         - |         - |         - |    57.39 KB |        0.02 |
| NativeSingle      | Movin(...)gence [34] | 1000  |  1,692.8 μs |    25.38 μs |    16.79 μs |  1.00 |    0.01 |  203.1250 |  140.6250 |   46.8750 |  3232.03 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 1000  |  1,448.2 μs |    30.39 μs |    18.08 μs |  0.86 |    0.01 |  359.3750 |  171.8750 |         - |  5670.87 KB |        1.75 |
|                   |                      |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** |  **4,128.5 μs** |     **9.31 μs** |     **4.87 μs** |  **0.23** |    **0.01** |   **31.2500** |         **-** |         **-** |  **1019.57 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 |  4,242.8 μs |    10.70 μs |     5.60 μs |  0.24 |    0.01 |   31.2500 |         - |         - |   549.81 KB |        0.02 |
| NativeSingle      | Movin(...)gence [34] | 10000 | 17,988.7 μs |   716.57 μs |   426.42 μs |  1.00 |    0.03 | 2166.6667 | 1500.0000 | 1166.6667 |  31913.4 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 10000 | 19,561.6 μs | 2,052.35 μs | 1,357.51 μs |  1.09 |    0.08 | 3200.0000 | 2200.0000 | 1400.0000 | 56070.42 KB |        1.76 |
