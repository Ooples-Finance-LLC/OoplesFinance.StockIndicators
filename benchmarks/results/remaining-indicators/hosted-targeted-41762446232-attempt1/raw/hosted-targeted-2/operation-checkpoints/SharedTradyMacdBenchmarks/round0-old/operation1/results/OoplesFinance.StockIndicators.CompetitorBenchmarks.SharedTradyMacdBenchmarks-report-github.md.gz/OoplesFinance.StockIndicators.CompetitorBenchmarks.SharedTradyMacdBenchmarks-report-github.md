```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |   **395.5 μs** |  **1.22 μs** |  **0.73 μs** |       **-** |  **73.63 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |   388.9 μs |  2.11 μs |  1.26 μs |       - |  26.04 KB |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** | **4,092.2 μs** |  **5.66 μs** |  **2.96 μs** | **31.2500** | **706.99 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 | 4,016.5 μs | 27.91 μs | 16.61 μs |       - | 237.12 KB |
