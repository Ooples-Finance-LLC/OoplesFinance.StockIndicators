```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |    **396.3 μs** |     **1.78 μs** |     **1.06 μs** |  **0.23** |    **0.00** |         **-** |         **-** |         **-** |    **73.65 KB** |       **0.022** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |    390.9 μs |     3.34 μs |     1.99 μs |  0.22 |    0.00 |         - |         - |         - |    26.06 KB |       0.008 |
| NativeSingle      | Movin(...)ogram [43] | 1000  |  1,755.7 μs |    51.55 μs |    34.10 μs |  1.00 |    0.03 |  203.1250 |  109.3750 |   46.8750 |  3389.08 KB |       1.000 |
| NativeParallel    | Movin(...)ogram [43] | 1000  |  1,482.7 μs |    42.11 μs |    25.06 μs |  0.84 |    0.02 |  359.3750 |  171.8750 |         - |  5597.46 KB |       1.652 |
|                   |                      |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** |  **4,009.1 μs** |    **19.05 μs** |     **9.96 μs** |  **0.22** |    **0.00** |   **31.2500** |         **-** |         **-** |      **707 KB** |       **0.021** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 |  3,966.2 μs |    29.94 μs |    17.82 μs |  0.22 |    0.00 |         - |         - |         - |   237.19 KB |       0.007 |
| NativeSingle      | Movin(...)ogram [43] | 10000 | 18,308.3 μs |   671.10 μs |   399.36 μs |  1.00 |    0.03 | 2000.0000 | 1400.0000 | 1000.0000 | 33357.88 KB |       1.000 |
| NativeParallel    | Movin(...)ogram [43] | 10000 | 19,469.9 μs | 1,767.52 μs | 1,169.10 μs |  1.06 |    0.06 | 3000.0000 | 2000.0000 | 1166.6667 |  55281.8 KB |       1.657 |
