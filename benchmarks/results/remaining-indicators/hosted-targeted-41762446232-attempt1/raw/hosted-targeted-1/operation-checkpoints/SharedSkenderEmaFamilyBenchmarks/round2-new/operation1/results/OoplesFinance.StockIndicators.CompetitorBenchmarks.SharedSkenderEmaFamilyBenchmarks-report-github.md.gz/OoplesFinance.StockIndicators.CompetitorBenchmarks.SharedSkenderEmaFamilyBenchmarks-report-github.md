```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **616.98 μs** |   **6.683 μs** |   **3.495 μs** |  **8.19** |    **0.40** |        **-** |        **-** |        **-** |  **105.08 KB** |        **0.37** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   624.75 μs |  14.684 μs |   8.738 μs |  8.29 |    0.42 |        - |        - |        - |   57.45 KB |        0.20 |
| NativeSingle      | Skender.GetPvo | 1000  |    75.54 μs |   6.025 μs |   3.985 μs |  1.00 |    0.07 |  17.0898 |   3.4180 |        - |  285.61 KB |        1.00 |
| NativeParallel    | Skender.GetPvo | 1000  |   168.82 μs |  10.332 μs |   6.834 μs |  2.24 |    0.14 |  45.8984 |  15.6250 |        - |  729.53 KB |        2.55 |
|                   |                |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **6,201.38 μs** | **218.375 μs** | **144.442 μs** |  **5.37** |    **0.15** |        **-** |        **-** |        **-** | **1019.94 KB** |        **0.33** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 6,140.70 μs |  98.209 μs |  58.442 μs |  5.31 |    0.10 |  31.2500 |        - |        - |  549.85 KB |        0.18 |
| NativeSingle      | Skender.GetPvo | 10000 | 1,155.89 μs |  30.987 μs |  20.496 μs |  1.00 |    0.02 | 164.0625 | 164.0625 | 164.0625 | 3052.21 KB |        1.00 |
| NativeParallel    | Skender.GetPvo | 10000 | 3,425.51 μs | 600.842 μs | 397.420 μs |  2.96 |    0.33 | 625.0000 | 500.0000 | 250.0000 | 7581.56 KB |        2.48 |
