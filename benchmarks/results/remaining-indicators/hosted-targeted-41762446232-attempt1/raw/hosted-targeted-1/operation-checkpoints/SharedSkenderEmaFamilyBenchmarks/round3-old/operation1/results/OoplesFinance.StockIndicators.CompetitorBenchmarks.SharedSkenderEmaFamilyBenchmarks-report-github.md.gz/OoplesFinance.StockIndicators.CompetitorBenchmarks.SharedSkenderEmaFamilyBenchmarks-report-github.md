```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **681.4 μs** |  **5.20 μs** |  **3.09 μs** | **105.05 KB** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   673.3 μs |  7.45 μs |  4.93 μs |  57.39 KB |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **6,668.4 μs** | **22.70 μs** | **11.87 μs** | **1019.9 KB** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 6,796.1 μs | 80.70 μs | 53.38 μs | 550.11 KB |
