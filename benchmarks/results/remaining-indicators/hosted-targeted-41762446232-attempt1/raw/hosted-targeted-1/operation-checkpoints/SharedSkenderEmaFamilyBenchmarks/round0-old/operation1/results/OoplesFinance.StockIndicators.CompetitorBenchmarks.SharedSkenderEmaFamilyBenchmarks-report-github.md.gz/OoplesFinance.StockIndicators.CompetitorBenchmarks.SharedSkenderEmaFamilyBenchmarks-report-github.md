```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated  |
|------------------ |--------------- |------ |-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **705.5 μs** | **24.56 μs** | **14.61 μs** |  **105.05 KB** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   681.1 μs |  4.70 μs |  2.80 μs |   57.39 KB |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **6,783.4 μs** | **33.41 μs** | **17.48 μs** | **1019.88 KB** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 6,881.5 μs | 51.16 μs | 30.44 μs |  550.09 KB |
