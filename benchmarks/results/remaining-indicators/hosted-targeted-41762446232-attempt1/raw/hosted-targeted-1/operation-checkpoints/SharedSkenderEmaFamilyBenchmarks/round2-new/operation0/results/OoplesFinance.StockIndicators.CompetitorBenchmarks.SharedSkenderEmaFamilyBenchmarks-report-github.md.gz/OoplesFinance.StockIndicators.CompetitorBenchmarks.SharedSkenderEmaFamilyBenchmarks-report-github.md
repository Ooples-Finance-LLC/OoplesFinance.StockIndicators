```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **550.58 μs** |   **2.662 μs** |   **1.392 μs** |  **9.41** |    **0.09** |        **-** |        **-** |        **-** |  **128.55 KB** |        **0.40** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   537.83 μs |   3.567 μs |   1.866 μs |  9.19 |    0.09 |   3.9063 |        - |        - |   80.92 KB |        0.25 |
| NativeSingle      | Skender.GetMacd | 1000  |    58.52 μs |   0.978 μs |   0.582 μs |  1.00 |    0.01 |  19.5313 |   6.3477 |        - |  324.53 KB |        1.00 |
| NativeParallel    | Skender.GetMacd | 1000  |   120.63 μs |   3.330 μs |   1.742 μs |  2.06 |    0.03 |  53.7109 |  20.5078 |        - |  826.63 KB |        2.55 |
|                   |                 |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **5,441.89 μs** |  **18.103 μs** |  **10.773 μs** |  **4.52** |    **0.11** |  **62.5000** |        **-** |        **-** | **1254.13 KB** |        **0.36** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 5,538.16 μs |  65.830 μs |  39.174 μs |  4.60 |    0.12 |  31.2500 |        - |        - |  784.28 KB |        0.23 |
| NativeSingle      | Skender.GetMacd | 10000 | 1,205.96 μs |  48.059 μs |  31.788 μs |  1.00 |    0.04 | 218.7500 | 218.7500 | 218.7500 | 3443.12 KB |        1.00 |
| NativeParallel    | Skender.GetMacd | 10000 | 4,236.54 μs | 922.300 μs | 610.044 μs |  3.52 |    0.49 | 750.0000 | 625.0000 | 312.5000 | 8556.44 KB |        2.49 |
