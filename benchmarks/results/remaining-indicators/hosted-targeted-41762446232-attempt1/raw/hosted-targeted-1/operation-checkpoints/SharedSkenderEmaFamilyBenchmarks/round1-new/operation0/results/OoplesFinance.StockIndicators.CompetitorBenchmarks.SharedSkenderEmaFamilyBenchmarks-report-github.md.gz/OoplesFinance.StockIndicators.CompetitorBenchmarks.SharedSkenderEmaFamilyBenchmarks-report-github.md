```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **555.6 μs** |  **8.74 μs** |  **5.20 μs** |       **-** |  **128.55 KB** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   552.1 μs |  5.06 μs |  3.35 μs |  3.9063 |   80.92 KB |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **5,452.4 μs** | **27.00 μs** | **16.07 μs** | **62.5000** | **1254.12 KB** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 5,522.9 μs | 21.33 μs | 12.69 μs | 31.2500 |  784.28 KB |
