```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Candles.OnNeck** | **317.82 μs** |  **2.696 μs** |  **1.410 μs** |  **1.00** |    **0.01** |   **64.8 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Candles.OnNeck |  50.54 μs |  3.160 μs |  2.090 μs |  0.16 |    0.01 |  16.02 KB |        0.25 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Candles.OnNeck** | **208.90 μs** | **10.987 μs** |  **6.538 μs** |  **1.00** |    **0.04** | **635.75 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Candles.OnNeck | 435.71 μs | 20.460 μs | 10.701 μs |  2.09 |    0.08 | 122.75 KB |        0.19 |
