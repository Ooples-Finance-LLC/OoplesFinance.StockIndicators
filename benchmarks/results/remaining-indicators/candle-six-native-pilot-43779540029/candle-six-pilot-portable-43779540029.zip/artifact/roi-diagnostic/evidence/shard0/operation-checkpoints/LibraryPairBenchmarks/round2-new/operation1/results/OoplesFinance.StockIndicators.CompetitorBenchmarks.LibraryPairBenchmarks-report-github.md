```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dwich [27]** |  **51.06 μs** |  **1.486 μs** | **0.777 μs** |  **1.00** |    **0.02** |   **64.8 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dwich [27] |  24.48 μs |  7.563 μs | 5.002 μs |  0.48 |    0.09 |     17 KB |        0.26 |
|            |       |                      |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)dwich [27]** | **203.24 μs** | **11.833 μs** | **6.189 μs** |  **1.00** |    **0.04** | **635.75 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dwich [27] | 204.51 μs |  1.286 μs | 0.673 μs |  1.01 |    0.03 | 123.45 KB |        0.19 |
