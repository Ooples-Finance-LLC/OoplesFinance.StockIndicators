```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)trike [29]** |  **61.00 μs** |  **0.708 μs** |  **0.370 μs** |  **1.00** |    **0.01** |   **64.8 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)trike [29] |  42.20 μs |  0.354 μs |  0.185 μs |  0.69 |    0.00 |  18.27 KB |        0.28 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)trike [29]** | **248.57 μs** |  **3.519 μs** |  **1.841 μs** |  **1.00** |    **0.01** | **635.42 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)trike [29] | 404.54 μs | 17.180 μs | 11.363 μs |  1.63 |    0.05 | 120.88 KB |        0.19 |
