```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Candles.InNeck** | **143.21 μs** |  **0.899 μs** |  **0.470 μs** |  **1.00** |    **0.00** |   **64.8 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Candles.InNeck |  59.13 μs | 13.301 μs |  8.798 μs |  0.41 |    0.06 |  15.97 KB |        0.25 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Candles.InNeck** | **206.58 μs** | **10.209 μs** |  **6.075 μs** |  **1.00** |    **0.04** | **635.47 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Candles.InNeck | 482.65 μs | 74.438 μs | 49.236 μs |  2.34 |    0.24 | 121.77 KB |        0.19 |
