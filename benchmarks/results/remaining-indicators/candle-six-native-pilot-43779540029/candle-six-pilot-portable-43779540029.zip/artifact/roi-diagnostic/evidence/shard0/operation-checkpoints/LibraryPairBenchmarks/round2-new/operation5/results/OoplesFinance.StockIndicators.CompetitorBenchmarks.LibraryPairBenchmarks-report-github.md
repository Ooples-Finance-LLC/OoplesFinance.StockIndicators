```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error    | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|---------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)sting [23]** |  **61.52 μs** | **17.72 μs** | **11.718 μs** |  **1.03** |    **0.25** |   **64.8 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)sting [23] |  70.11 μs | 15.19 μs | 10.046 μs |  1.17 |    0.25 |  19.63 KB |        0.30 |
|            |       |                      |           |          |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)sting [23]** | **303.14 μs** | **27.24 μs** | **16.210 μs** |  **1.00** |    **0.07** | **635.47 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)sting [23] | 556.30 μs | 16.43 μs |  9.775 μs |  1.84 |    0.10 | 125.38 KB |        0.20 |
