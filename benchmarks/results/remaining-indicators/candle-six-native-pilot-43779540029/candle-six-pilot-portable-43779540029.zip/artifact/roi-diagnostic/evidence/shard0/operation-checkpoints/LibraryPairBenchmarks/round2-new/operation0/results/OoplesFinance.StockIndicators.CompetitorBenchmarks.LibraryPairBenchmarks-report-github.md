```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)ngLow [25]** |  **50.83 μs** |  **1.539 μs** | **0.805 μs** |  **1.00** |    **0.02** |   **64.8 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)ngLow [25] |  28.66 μs | 10.084 μs | 6.670 μs |  0.56 |    0.13 |     17 KB |        0.26 |
|            |       |                      |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)ngLow [25]** | **211.16 μs** | **14.941 μs** | **8.891 μs** |  **1.00** |    **0.06** | **635.14 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)ngLow [25] | 233.39 μs | 12.265 μs | 8.113 μs |  1.11 |    0.06 | 123.08 KB |        0.19 |
