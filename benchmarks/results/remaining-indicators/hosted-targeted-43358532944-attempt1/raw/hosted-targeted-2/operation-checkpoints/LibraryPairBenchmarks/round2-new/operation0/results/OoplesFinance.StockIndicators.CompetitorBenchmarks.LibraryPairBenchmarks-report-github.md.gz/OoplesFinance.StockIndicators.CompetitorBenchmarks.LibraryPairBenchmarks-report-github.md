```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Tanh** | **206.64 μs** | **10.606 μs** | **6.311 μs** |  **1.00** |    **0.04** |  **97.92 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Tanh |  22.95 μs |  1.133 μs | 0.593 μs |  0.11 |    0.00 |  39.29 KB |        0.40 |
|            |       |                      |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Tanh** | **252.60 μs** | **12.008 μs** | **6.281 μs** |  **1.00** |    **0.03** |  **958.9 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Tanh | 198.96 μs |  2.780 μs | 1.454 μs |  0.79 |    0.02 | 328.02 KB |        0.34 |
