```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Tanh**      |   **8.731 μs** | **0.0478 μs** | **0.0284 μs** |  **1.55** |    **0.04** |  **3.4180** |  **0.4883** |  **56.77 KB** |        **7.22** |
| BuilderLatestOnly | 1000  | Tanh      |   6.524 μs | 0.0409 μs | 0.0214 μs |  1.16 |    0.03 |  0.5493 |       - |   9.16 KB |        1.16 |
| NativeSingle      | 1000  | Tanh      |   5.623 μs | 0.2474 μs | 0.1637 μs |  1.00 |    0.04 |  0.4578 |       - |   7.87 KB |        1.00 |
| NativeParallel    | 1000  | Tanh      |  78.542 μs | 1.0969 μs | 0.7255 μs | 13.98 |    0.40 |  0.4883 |       - |   8.14 KB |        1.03 |
|                   |       |           |            |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **10000** | **Tanh**      |  **76.738 μs** | **0.7679 μs** | **0.4569 μs** |  **1.39** |    **0.02** | **33.2031** | **13.6719** | **549.31 KB** |        **7.03** |
| BuilderLatestOnly | 10000 | Tanh      |  57.404 μs | 0.4053 μs | 0.2412 μs |  1.04 |    0.02 |  4.3945 |  0.4883 |  79.48 KB |        1.02 |
| NativeSingle      | 10000 | Tanh      |  55.030 μs | 1.5948 μs | 0.9490 μs |  1.00 |    0.02 |  4.3945 |  0.4883 |  78.18 KB |        1.00 |
| NativeParallel    | 10000 | Tanh      | 103.891 μs | 2.6098 μs | 1.5531 μs |  1.89 |    0.04 |  3.9063 |       - |  78.45 KB |        1.00 |
