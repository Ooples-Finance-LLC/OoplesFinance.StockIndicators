```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean      | Error    | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |----------:|---------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Sinh** |  **65.57 μs** | **16.54 μs** |  **9.841 μs** |  **1.02** |    **0.21** |  **97.86 KB** |        **1.00** |
|        |       |                      |           |          |           |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Sinh** | **274.43 μs** | **47.82 μs** | **31.629 μs** |  **1.01** |    **0.15** | **958.52 KB** |        **1.00** |
