```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean      | Error     | StdDev    | Gen0   | Gen1   | Allocated |
|------------------ |------ |---------- |----------:|----------:|----------:|-------:|-------:|----------:|
| **BuilderFull**       | **1000**  | **Sinh**      |  **14.91 μs** |  **0.131 μs** |  **0.069 μs** | **0.4883** |      **-** |  **56.77 KB** |
| BuilderLatestOnly | 1000  | Sinh      |  11.64 μs |  0.961 μs |  0.572 μs |      - |      - |   9.16 KB |
| **BuilderFull**       | **10000** | **Sinh**      | **174.67 μs** | **35.910 μs** | **23.752 μs** | **5.8594** | **3.9063** | **549.74 KB** |
| BuilderLatestOnly | 10000 | Sinh      | 133.64 μs |  4.938 μs |  2.939 μs | 0.9766 |      - |  79.92 KB |
