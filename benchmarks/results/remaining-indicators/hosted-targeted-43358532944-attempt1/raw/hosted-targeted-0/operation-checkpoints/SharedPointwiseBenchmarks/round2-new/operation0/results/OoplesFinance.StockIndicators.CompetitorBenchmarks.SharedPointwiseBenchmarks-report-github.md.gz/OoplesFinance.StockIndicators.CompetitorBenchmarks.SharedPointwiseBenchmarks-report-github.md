```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0   | Gen1   | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-----------:|----------:|----------:|------:|--------:|-------:|-------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Sinh**      |  **15.148 μs** | **0.1889 μs** | **0.1124 μs** |  **1.58** |    **0.02** | **0.4883** |      **-** |  **56.77 KB** |        **7.21** |
| BuilderLatestOnly | 1000  | Sinh      |  11.039 μs | 0.1592 μs | 0.0947 μs |  1.15 |    0.01 | 0.0610 |      - |   9.16 KB |        1.16 |
| NativeSingle      | 1000  | Sinh      |   9.577 μs | 0.1273 μs | 0.0666 μs |  1.00 |    0.01 | 0.0610 |      - |   7.87 KB |        1.00 |
| NativeParallel    | 1000  | Sinh      |  62.493 μs | 3.7848 μs | 2.5034 μs |  6.53 |    0.25 |      - |      - |   8.14 KB |        1.03 |
|                   |       |           |            |           |           |       |         |        |        |           |             |
| **BuilderFull**       | **10000** | **Sinh**      | **126.025 μs** | **1.0654 μs** | **0.5572 μs** |  **1.37** |    **0.01** | **5.8594** | **1.9531** | **549.29 KB** |        **7.03** |
| BuilderLatestOnly | 10000 | Sinh      |  95.373 μs | 0.6162 μs | 0.4076 μs |  1.04 |    0.01 |      - |      - |  79.48 KB |        1.02 |
| NativeSingle      | 10000 | Sinh      |  92.147 μs | 0.7357 μs | 0.4866 μs |  1.00 |    0.01 |      - |      - |  78.19 KB |        1.00 |
| NativeParallel    | 10000 | Sinh      | 102.377 μs | 1.2701 μs | 0.6643 μs |  1.11 |    0.01 |      - |      - |  78.45 KB |        1.00 |
