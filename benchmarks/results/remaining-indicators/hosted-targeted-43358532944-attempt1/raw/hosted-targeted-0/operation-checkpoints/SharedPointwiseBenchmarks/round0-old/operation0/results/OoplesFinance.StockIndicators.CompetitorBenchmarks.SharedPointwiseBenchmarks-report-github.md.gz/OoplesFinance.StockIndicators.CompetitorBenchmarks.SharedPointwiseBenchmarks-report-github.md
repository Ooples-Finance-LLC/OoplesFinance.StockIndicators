```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean      | Error    | StdDev   | Gen0   | Gen1   | Allocated |
|------------------ |------ |---------- |----------:|---------:|---------:|-------:|-------:|----------:|
| **BuilderFull**       | **1000**  | **Sinh**      |  **14.92 μs** | **0.177 μs** | **0.105 μs** | **0.4883** |      **-** |  **56.77 KB** |
| BuilderLatestOnly | 1000  | Sinh      |  11.58 μs | 0.580 μs | 0.345 μs |      - |      - |   9.16 KB |
| **BuilderFull**       | **10000** | **Sinh**      | **124.84 μs** | **4.892 μs** | **2.559 μs** | **5.8594** | **4.8828** | **549.73 KB** |
| BuilderLatestOnly | 10000 | Sinh      | 107.28 μs | 2.584 μs | 1.351 μs | 0.9766 |      - |  79.92 KB |
