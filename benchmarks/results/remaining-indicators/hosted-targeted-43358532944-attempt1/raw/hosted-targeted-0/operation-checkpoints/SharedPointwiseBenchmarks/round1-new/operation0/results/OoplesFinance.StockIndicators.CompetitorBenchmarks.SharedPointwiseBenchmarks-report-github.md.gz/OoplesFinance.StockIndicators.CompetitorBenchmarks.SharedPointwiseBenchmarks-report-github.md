```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean      | Error    | StdDev   | Gen0   | Gen1   | Allocated |
|------------------ |------ |---------- |----------:|---------:|---------:|-------:|-------:|----------:|
| **BuilderFull**       | **1000**  | **Sinh**      |  **15.35 μs** | **0.601 μs** | **0.397 μs** | **0.4883** |      **-** |  **56.77 KB** |
| BuilderLatestOnly | 1000  | Sinh      |  11.74 μs | 0.156 μs | 0.093 μs |      - |      - |   9.16 KB |
| **BuilderFull**       | **10000** | **Sinh**      | **126.73 μs** | **1.117 μs** | **0.739 μs** | **5.8594** | **1.9531** | **549.29 KB** |
| BuilderLatestOnly | 10000 | Sinh      | 102.58 μs | 1.265 μs | 0.837 μs |      - |      - |  79.48 KB |
