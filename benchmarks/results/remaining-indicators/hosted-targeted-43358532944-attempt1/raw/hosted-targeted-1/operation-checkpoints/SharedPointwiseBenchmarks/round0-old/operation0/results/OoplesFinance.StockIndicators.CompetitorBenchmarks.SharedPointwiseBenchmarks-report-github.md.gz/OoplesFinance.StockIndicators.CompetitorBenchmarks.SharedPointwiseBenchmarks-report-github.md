```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------- |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Cosh**      |  **12.70 μs** | **0.596 μs** | **0.394 μs** |  **2.9297** |       **-** |  **56.77 KB** |
| BuilderLatestOnly | 1000  | Cosh      |  10.29 μs | 0.229 μs | 0.120 μs |  0.5493 |       - |   9.16 KB |
| **BuilderFull**       | **10000** | **Cosh**      | **139.36 μs** | **8.818 μs** | **5.832 μs** | **33.2031** | **13.6719** | **549.76 KB** |
| BuilderLatestOnly | 10000 | Cosh      | 124.75 μs | 9.306 μs | 6.155 μs |  3.9063 |       - |  79.92 KB |
