```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Cosh**      |  **12.567 μs** | **0.6148 μs** | **0.4067 μs** |  **1.69** |    **0.05** |  **3.4180** |  **0.4883** |  **56.77 KB** |        **7.22** |
| BuilderLatestOnly | 1000  | Cosh      |  10.034 μs | 0.0710 μs | 0.0423 μs |  1.35 |    0.01 |  0.5493 |       - |   9.16 KB |        1.16 |
| NativeSingle      | 1000  | Cosh      |   7.450 μs | 0.1178 μs | 0.0779 μs |  1.00 |    0.01 |  0.4272 |       - |   7.87 KB |        1.00 |
| NativeParallel    | 1000  | Cosh      |  79.289 μs | 0.5775 μs | 0.3021 μs | 10.64 |    0.11 |  0.4883 |       - |   8.14 KB |        1.03 |
|                   |       |           |            |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **10000** | **Cosh**      | **110.305 μs** | **1.6980 μs** | **1.0105 μs** |  **1.55** |    **0.01** | **33.2031** | **13.6719** | **549.32 KB** |        **7.03** |
| BuilderLatestOnly | 10000 | Cosh      |  88.661 μs | 0.2666 μs | 0.1395 μs |  1.25 |    0.00 |  4.3945 |  0.4883 |  79.48 KB |        1.02 |
| NativeSingle      | 10000 | Cosh      |  70.971 μs | 0.3005 μs | 0.1572 μs |  1.00 |    0.00 |  4.3945 |  0.4883 |  78.18 KB |        1.00 |
| NativeParallel    | 10000 | Cosh      | 112.911 μs | 1.7660 μs | 0.9236 μs |  1.59 |    0.01 |  3.9063 |       - |  78.45 KB |        1.00 |
