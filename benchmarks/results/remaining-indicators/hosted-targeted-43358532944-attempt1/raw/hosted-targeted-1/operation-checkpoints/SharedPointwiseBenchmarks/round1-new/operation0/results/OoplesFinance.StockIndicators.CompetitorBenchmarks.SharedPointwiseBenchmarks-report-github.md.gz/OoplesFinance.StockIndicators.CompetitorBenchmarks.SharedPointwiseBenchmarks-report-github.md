```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------- |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Cosh**      |  **12.89 μs** | **0.368 μs** | **0.219 μs** |  **3.4180** |  **0.4883** |  **56.77 KB** |
| BuilderLatestOnly | 1000  | Cosh      |  10.31 μs | 0.223 μs | 0.117 μs |  0.4883 |       - |   9.16 KB |
| **BuilderFull**       | **10000** | **Cosh**      | **111.30 μs** | **2.434 μs** | **1.449 μs** | **33.2031** | **13.6719** | **549.32 KB** |
| BuilderLatestOnly | 10000 | Cosh      |  88.94 μs | 0.287 μs | 0.171 μs |  4.3945 |  0.4883 |  79.47 KB |
