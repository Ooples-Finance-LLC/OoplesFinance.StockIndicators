```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Cosh** | **205.23 μs** | **11.507 μs** |  **6.848 μs** |  **1.00** |    **0.04** |  **97.92 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Cosh |  18.00 μs |  1.127 μs |  0.671 μs |  0.09 |    0.00 |  39.01 KB |        0.40 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Cosh** | **277.42 μs** | **61.117 μs** | **36.370 μs** |  **1.02** |    **0.18** | **959.18 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Cosh | 151.72 μs |  0.889 μs |  0.465 μs |  0.56 |    0.07 | 328.34 KB |        0.34 |
