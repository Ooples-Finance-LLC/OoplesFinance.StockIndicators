```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1,296.8 μs** | **305.02 μs** | **201.75 μs** |  **3.15** |    **0.47** |   **72.1 KB** |       **15.26** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1,083.3 μs |   9.94 μs |   5.92 μs |  2.63 |    0.02 |  24.49 KB |        5.18 |
| NativeSingle      | TaLib(...)dMode [27] | 1000  |    411.6 μs |   3.32 μs |   1.97 μs |  1.00 |    0.01 |   4.72 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 1000  |    611.0 μs |  25.44 μs |  16.83 μs |  1.48 |    0.04 |   17.4 KB |        3.68 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **11,232.8 μs** |  **71.49 μs** |  **42.54 μs** |  **2.28** |    **0.01** | **635.24 KB** |       **15.88** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 11,319.9 μs |  21.45 μs |  11.22 μs |  2.30 |    0.00 | 165.94 KB |        4.15 |
| NativeSingle      | TaLib(...)dMode [27] | 10000 |  4,928.0 μs |  16.49 μs |   8.62 μs |  1.00 |    0.00 |  40.01 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 10000 |  6,913.6 μs | 447.51 μs | 296.00 μs |  1.40 |    0.06 |  140.9 KB |        3.52 |
