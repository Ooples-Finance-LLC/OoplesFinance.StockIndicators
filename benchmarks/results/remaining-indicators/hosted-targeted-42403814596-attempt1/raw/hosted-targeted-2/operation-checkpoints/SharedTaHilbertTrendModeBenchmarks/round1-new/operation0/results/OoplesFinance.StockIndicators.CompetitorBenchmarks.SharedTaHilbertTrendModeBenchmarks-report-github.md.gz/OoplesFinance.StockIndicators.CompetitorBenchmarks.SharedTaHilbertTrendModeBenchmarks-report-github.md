```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1.132 ms** | **0.0075 ms** | **0.0045 ms** |  **72.13 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1.103 ms | 0.0084 ms | 0.0044 ms |  24.48 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **11.605 ms** | **0.0759 ms** | **0.0451 ms** | **635.49 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 11.655 ms | 0.0230 ms | 0.0120 ms | 165.79 KB |
