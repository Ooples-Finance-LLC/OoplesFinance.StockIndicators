```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1.145 ms** | **0.0289 ms** | **0.0172 ms** |  **71.68 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1.122 ms | 0.0058 ms | 0.0031 ms |  24.04 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **11.646 ms** | **0.0530 ms** | **0.0315 ms** | **635.08 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 11.666 ms | 0.0509 ms | 0.0266 ms | 164.68 KB |
