```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **1.129 ms** | **0.0243 ms** | **0.0127 ms** |  **71.68 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1.119 ms | 0.0065 ms | 0.0039 ms |  24.03 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **11.550 ms** | **0.0345 ms** | **0.0206 ms** | **635.11 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 11.684 ms | 0.0235 ms | 0.0123 ms | 165.26 KB |
