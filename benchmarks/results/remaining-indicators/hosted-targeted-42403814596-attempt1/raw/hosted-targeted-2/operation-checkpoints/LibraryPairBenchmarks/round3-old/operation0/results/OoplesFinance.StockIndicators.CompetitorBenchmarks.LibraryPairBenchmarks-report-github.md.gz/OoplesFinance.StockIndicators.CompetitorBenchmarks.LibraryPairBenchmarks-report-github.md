```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)dMode [27]** |  **1.178 ms** | **0.0279 ms** | **0.0184 ms** |  **1.00** |    **0.02** |  **112.73 KB** |        **1.00** |
|        |       |                      |           |           |           |       |         |            |             |
| **Ooples** | **10000** | **TaLib(...)dMode [27]** | **11.922 ms** | **0.1215 ms** | **0.0723 ms** |  **1.00** |    **0.01** | **1041.11 KB** |        **1.00** |
