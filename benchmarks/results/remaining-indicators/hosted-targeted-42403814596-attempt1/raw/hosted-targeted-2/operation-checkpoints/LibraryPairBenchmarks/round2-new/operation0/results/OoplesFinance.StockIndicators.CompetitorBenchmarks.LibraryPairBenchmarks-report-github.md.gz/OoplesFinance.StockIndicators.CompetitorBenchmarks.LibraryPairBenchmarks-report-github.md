```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dMode [27]** |  **1,214.3 μs** |  **71.46 μs** | **47.27 μs** |  **1.00** |    **0.05** |  **113.18 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dMode [27] |    586.5 μs | 113.79 μs | 75.26 μs |  0.48 |    0.06 |   38.18 KB |        0.34 |
|            |       |                      |             |           |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)dMode [27]** | **11,766.4 μs** |  **57.06 μs** | **33.96 μs** |  **1.00** |    **0.00** | **1041.56 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dMode [27] |  4,999.5 μs |  24.22 μs | 16.02 μs |  0.42 |    0.00 |  292.45 KB |        0.28 |
