```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|------------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **897.6 μs** |   **176.00 μs** | **116.41 μs** |  **1.72** |    **0.21** |   **69.4 KB** |        **8.27** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   803.8 μs |     4.67 μs |   2.78 μs |  1.54 |    0.01 |  21.84 KB |        2.60 |
| NativeSingle      | TaLib(...)Phase [25] | 1000  |   521.8 μs |     7.70 μs |   4.58 μs |  1.00 |    0.01 |   8.39 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 1000  |   752.4 μs |    46.05 μs |  27.40 μs |  1.44 |    0.05 |  30.19 KB |        3.60 |
|                   |                      |       |            |             |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **8,405.5 μs** |   **117.77 μs** |  **61.59 μs** |  **1.49** |    **0.01** | **632.87 KB** |        **8.02** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 8,327.3 μs |    23.85 μs |  12.47 μs |  1.48 |    0.00 | 163.08 KB |        2.07 |
| NativeSingle      | TaLib(...)Phase [25] | 10000 | 5,643.5 μs |    23.77 μs |  14.14 μs |  1.00 |    0.00 |   78.9 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 10000 | 8,692.6 μs | 1,390.29 μs | 919.59 μs |  1.54 |    0.16 | 277.11 KB |        3.51 |
