```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **805.0 μs** |  **22.31 μs** | **13.28 μs** |  **68.95 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   800.8 μs |  12.02 μs |  7.15 μs |  21.38 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **8,330.1 μs** | **110.15 μs** | **72.86 μs** | **632.44 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 8,307.3 μs | 144.86 μs | 86.20 μs | 162.55 KB |
