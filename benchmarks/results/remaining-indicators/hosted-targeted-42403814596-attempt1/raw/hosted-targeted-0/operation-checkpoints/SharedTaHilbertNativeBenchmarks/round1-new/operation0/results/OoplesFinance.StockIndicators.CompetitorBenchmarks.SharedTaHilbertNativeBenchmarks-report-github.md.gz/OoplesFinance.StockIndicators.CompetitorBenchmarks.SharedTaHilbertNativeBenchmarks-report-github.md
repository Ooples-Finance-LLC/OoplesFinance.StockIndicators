```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **821.1 μs** |  **7.77 μs** |  **4.06 μs** |   **69.4 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   811.6 μs |  5.88 μs |  3.50 μs |  21.78 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **8,462.3 μs** | **78.79 μs** | **46.89 μs** | **632.89 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 8,438.2 μs | 28.12 μs | 14.71 μs | 163.08 KB |
