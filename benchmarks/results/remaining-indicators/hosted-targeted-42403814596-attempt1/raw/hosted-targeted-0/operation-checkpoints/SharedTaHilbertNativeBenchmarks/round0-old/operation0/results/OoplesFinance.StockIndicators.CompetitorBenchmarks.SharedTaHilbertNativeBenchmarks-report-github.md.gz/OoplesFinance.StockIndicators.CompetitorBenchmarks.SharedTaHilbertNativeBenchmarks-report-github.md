```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |   **802.8 μs** |  **18.62 μs** |   **9.74 μs** |  **68.91 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |   800.1 μs |  19.07 μs |  12.61 μs |  21.39 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **8,274.5 μs** |  **88.00 μs** |  **52.37 μs** | **632.37 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 8,679.5 μs | 901.61 μs | 596.36 μs | 162.62 KB |
