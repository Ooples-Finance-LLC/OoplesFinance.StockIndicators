```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Phase [25]** |   **872.5 μs** | **39.59 μs** | **20.71 μs** |  **1.00** |    **0.03** |  **110.48 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Phase [25] |   546.8 μs | 26.27 μs | 15.63 μs |  0.63 |    0.02 |   41.43 KB |        0.38 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)Phase [25]** | **8,578.4 μs** | **32.00 μs** | **19.04 μs** |  **1.00** |    **0.00** | **1041.81 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Phase [25] | 5,706.5 μs | 41.08 μs | 27.17 μs |  0.67 |    0.00 |   329.5 KB |        0.32 |
