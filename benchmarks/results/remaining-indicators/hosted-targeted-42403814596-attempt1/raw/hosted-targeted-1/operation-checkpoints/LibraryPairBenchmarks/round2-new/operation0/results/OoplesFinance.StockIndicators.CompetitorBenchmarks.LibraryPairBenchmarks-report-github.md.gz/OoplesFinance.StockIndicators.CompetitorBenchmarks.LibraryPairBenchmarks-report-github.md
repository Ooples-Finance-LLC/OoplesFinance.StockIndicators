```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tSine [22]** |   **908.8 μs** |  **28.73 μs** | **19.00 μs** |  **1.00** |    **0.03** |  **166.88 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tSine [22] |   581.9 μs |  34.55 μs | 22.85 μs |  0.64 |    0.03 |   74.28 KB |        0.45 |
|            |       |                      |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)tSine [22]** | **9,112.7 μs** | **105.82 μs** | **62.97 μs** |  **1.00** |    **0.01** | **1598.91 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tSine [22] | 5,987.3 μs |  98.63 μs | 65.24 μs |  0.66 |    0.01 |  653.05 KB |        0.41 |
