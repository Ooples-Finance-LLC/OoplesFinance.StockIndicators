```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **839.7 μs** |  **6.18 μs** |  **3.23 μs** |  **85.29 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   835.2 μs |  7.68 μs |  4.57 μs |  37.73 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **8,696.3 μs** | **59.88 μs** | **31.32 μs** | **789.38 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 8,678.8 μs | 56.42 μs | 33.58 μs | 319.62 KB |
