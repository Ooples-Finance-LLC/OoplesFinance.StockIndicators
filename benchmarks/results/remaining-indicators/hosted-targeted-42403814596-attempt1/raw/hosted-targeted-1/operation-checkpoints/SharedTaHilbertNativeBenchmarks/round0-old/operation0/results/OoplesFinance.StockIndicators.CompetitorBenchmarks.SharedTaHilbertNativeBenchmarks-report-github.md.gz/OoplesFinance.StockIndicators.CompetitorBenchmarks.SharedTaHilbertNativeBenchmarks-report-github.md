```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **839.3 μs** |   **4.45 μs** |   **2.65 μs** |  **84.84 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   832.7 μs |   8.06 μs |   4.80 μs |  37.28 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **8,641.6 μs** |  **88.53 μs** |  **52.68 μs** | **788.95 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 8,907.0 μs | 489.28 μs | 323.63 μs | 319.17 KB |
