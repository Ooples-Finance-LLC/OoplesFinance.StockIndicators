```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **835.9 μs** |  **4.44 μs** |  **2.64 μs** |   **84.8 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   832.3 μs |  4.99 μs |  2.97 μs |  37.27 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **8,685.2 μs** | **47.56 μs** | **24.88 μs** |    **789 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 8,593.4 μs | 66.12 μs | 39.34 μs | 319.17 KB |
