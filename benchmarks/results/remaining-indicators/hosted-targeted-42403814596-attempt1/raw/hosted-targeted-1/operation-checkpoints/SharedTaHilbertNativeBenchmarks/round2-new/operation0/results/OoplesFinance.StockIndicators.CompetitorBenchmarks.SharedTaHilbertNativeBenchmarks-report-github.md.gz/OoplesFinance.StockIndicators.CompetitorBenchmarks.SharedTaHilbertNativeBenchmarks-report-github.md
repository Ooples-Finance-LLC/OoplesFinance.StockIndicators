```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error       | StdDev      | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|------------:|------------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |   **840.3 μs** |    **22.91 μs** |    **11.98 μs** |  **1.55** |    **0.02** |  **85.29 KB** |        **5.42** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |   835.2 μs |     7.12 μs |     3.72 μs |  1.54 |    0.01 |  37.73 KB |        2.40 |
| NativeSingle      | TaLib(...)tSine [22] | 1000  |   543.7 μs |     3.89 μs |     2.03 μs |  1.00 |    0.00 |  15.74 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 1000  |   803.2 μs |    53.26 μs |    35.23 μs |  1.48 |    0.06 |  55.99 KB |        3.56 |
|                   |                      |       |            |             |             |       |         |           |             |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **8,773.1 μs** |    **37.61 μs** |    **22.38 μs** |  **1.49** |    **0.01** | **789.41 KB** |        **5.04** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 8,646.7 μs |    61.29 μs |    40.54 μs |  1.47 |    0.01 |  319.6 KB |        2.04 |
| NativeSingle      | TaLib(...)tSine [22] | 10000 | 5,891.5 μs |    56.07 μs |    29.33 μs |  1.00 |    0.01 | 156.57 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 10000 | 9,237.7 μs | 1,750.04 μs | 1,157.55 μs |  1.57 |    0.19 | 548.99 KB |        3.51 |
