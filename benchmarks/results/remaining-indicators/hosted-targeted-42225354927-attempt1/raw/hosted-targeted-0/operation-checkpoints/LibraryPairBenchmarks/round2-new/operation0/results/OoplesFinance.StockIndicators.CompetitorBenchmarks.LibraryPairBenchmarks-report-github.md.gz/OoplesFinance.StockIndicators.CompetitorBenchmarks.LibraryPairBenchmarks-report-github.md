```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Candles.Doji** | **112.80 μs** | **26.171 μs** | **17.310 μs** |  **1.02** |    **0.21** |  **65.37 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Candles.Doji |  31.21 μs |  0.782 μs |  0.517 μs |  0.28 |    0.04 |  19.58 KB |        0.30 |
|            |       |                    |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Candles.Doji** | **539.82 μs** | **32.946 μs** | **19.606 μs** |  **1.00** |    **0.05** | **635.66 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Candles.Doji | 305.57 μs | 22.508 μs | 14.888 μs |  0.57 |    0.03 | 124.06 KB |        0.20 |
