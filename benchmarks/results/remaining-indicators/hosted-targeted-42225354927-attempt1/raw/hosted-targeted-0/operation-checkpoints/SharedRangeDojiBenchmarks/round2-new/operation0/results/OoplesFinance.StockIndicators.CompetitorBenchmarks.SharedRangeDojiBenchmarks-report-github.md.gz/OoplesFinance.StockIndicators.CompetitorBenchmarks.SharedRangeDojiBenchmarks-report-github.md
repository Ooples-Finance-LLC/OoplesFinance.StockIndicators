```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib.Candles.Doji** | **1000**  |  **26.25 μs** |  **0.162 μs** |  **0.085 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Doji | 1000  |  19.91 μs |  4.568 μs |  3.021 μs |  0.76 |    0.11 |  0.4883 |       - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib.Candles.Doji | 1000  |  50.39 μs |  0.351 μs |  0.209 μs |  1.92 |    0.01 |  3.4180 |  0.4883 |  57.27 KB |       14.43 |
| BuilderLatestOnly | TaLib.Candles.Doji | 1000  |  49.21 μs |  4.166 μs |  2.756 μs |  1.87 |    0.10 |  0.4883 |       - |   9.39 KB |        2.37 |
|                   |                    |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib.Candles.Doji** | **10000** | **264.11 μs** |  **2.590 μs** |  **1.354 μs** |  **1.00** |    **0.01** |  **1.9531** |       **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Doji | 10000 | 186.67 μs | 25.593 μs | 16.928 μs |  0.71 |    0.06 |  5.8594 |       - |   78.7 KB |        2.01 |
| BuilderFull       | TaLib.Candles.Doji | 10000 | 453.10 μs |  4.636 μs |  2.425 μs |  1.72 |    0.01 | 31.2500 | 11.7188 | 549.83 KB |       14.05 |
| BuilderLatestOnly | TaLib.Candles.Doji | 10000 | 417.67 μs |  5.862 μs |  3.066 μs |  1.58 |    0.01 |  3.9063 |       - |  79.73 KB |        2.04 |
