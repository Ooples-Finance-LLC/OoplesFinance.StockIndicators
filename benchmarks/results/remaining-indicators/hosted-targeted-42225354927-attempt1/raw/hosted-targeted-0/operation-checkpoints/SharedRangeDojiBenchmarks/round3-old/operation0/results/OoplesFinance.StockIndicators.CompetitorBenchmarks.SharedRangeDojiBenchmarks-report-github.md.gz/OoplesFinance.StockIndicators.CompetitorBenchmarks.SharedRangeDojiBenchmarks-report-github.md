```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Candles.Doji** | **1000**  |  **68.30 μs** | **0.637 μs** | **0.379 μs** |       **-** |       **-** |   **57.3 KB** |
| BuilderLatestOnly | TaLib.Candles.Doji | 1000  |  45.54 μs | 0.228 μs | 0.119 μs |  0.4883 |       - |   9.38 KB |
| **BuilderFull**       | **TaLib.Candles.Doji** | **10000** | **486.88 μs** | **2.056 μs** | **1.223 μs** | **31.2500** | **11.7188** | **549.83 KB** |
| BuilderLatestOnly | TaLib.Candles.Doji | 10000 | 419.65 μs | 1.950 μs | 1.020 μs |  3.9063 |       - |  79.72 KB |
