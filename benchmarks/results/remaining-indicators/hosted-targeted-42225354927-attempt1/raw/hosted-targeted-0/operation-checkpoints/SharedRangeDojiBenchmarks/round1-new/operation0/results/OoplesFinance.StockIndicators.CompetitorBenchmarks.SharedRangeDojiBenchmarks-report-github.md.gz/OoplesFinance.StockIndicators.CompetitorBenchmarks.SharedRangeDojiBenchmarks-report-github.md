```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------------- |------ |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Candles.Doji** | **1000**  |  **49.63 μs** |  **0.770 μs** | **0.459 μs** |  **1.9531** |       **-** |  **57.27 KB** |
| BuilderLatestOnly | TaLib.Candles.Doji | 1000  |  43.50 μs |  0.227 μs | 0.119 μs |  0.4883 |       - |   9.39 KB |
| **BuilderFull**       | **TaLib.Candles.Doji** | **10000** | **447.25 μs** | **10.999 μs** | **6.546 μs** | **31.2500** | **11.7188** | **549.83 KB** |
| BuilderLatestOnly | TaLib.Candles.Doji | 10000 | 397.26 μs |  7.969 μs | 4.168 μs |  3.9063 |       - |  79.73 KB |
