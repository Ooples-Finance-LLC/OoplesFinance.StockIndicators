```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)yDoji [27]** | **1000**  |  **49.58 μs** |  **3.634 μs** |  **1.901 μs** |      **-** |  **57.27 KB** |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 1000  |  50.36 μs |  2.790 μs |  1.845 μs |      - |   9.39 KB |
| **BuilderFull**       | **TaLib(...)yDoji [27]** | **10000** | **506.59 μs** | **38.838 μs** | **23.112 μs** | **3.9063** | **549.81 KB** |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 10000 | 470.79 μs | 32.703 μs | 21.631 μs |      - |  79.73 KB |
