```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|-------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)yDoji [27]** | **1000**  |  **40.63 μs** |  **0.951 μs** |  **0.629 μs** |  **1.00** |    **0.02** |      **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)yDoji [27] | 1000  |  35.16 μs |  5.820 μs |  3.850 μs |  0.87 |    0.09 |      - |    8.4 KB |        2.12 |
| BuilderFull       | TaLib(...)yDoji [27] | 1000  |  56.82 μs |  2.369 μs |  1.567 μs |  1.40 |    0.04 | 0.4883 |  57.27 KB |       14.43 |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 1000  |  52.99 μs |  1.639 μs |  1.084 μs |  1.30 |    0.03 |      - |   9.39 KB |        2.37 |
|                   |                      |       |           |           |           |       |         |        |           |             |
| **NativeSingle**      | **TaLib(...)yDoji [27]** | **10000** | **397.49 μs** | **10.340 μs** |  **6.153 μs** |  **1.00** |    **0.02** |      **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)yDoji [27] | 10000 | 263.78 μs | 36.541 μs | 21.745 μs |  0.66 |    0.05 |      - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib(...)yDoji [27] | 10000 | 526.42 μs | 15.411 μs | 10.194 μs |  1.32 |    0.03 | 3.9063 | 549.82 KB |       14.04 |
| BuilderLatestOnly | TaLib(...)yDoji [27] | 10000 | 499.62 μs | 14.636 μs |  8.709 μs |  1.26 |    0.03 |      - |  79.73 KB |        2.04 |
