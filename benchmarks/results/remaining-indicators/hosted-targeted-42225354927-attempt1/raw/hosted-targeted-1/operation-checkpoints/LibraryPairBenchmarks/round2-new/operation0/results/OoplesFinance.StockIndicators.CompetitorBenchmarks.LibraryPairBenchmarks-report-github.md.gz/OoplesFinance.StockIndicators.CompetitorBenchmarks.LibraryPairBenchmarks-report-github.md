```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)yDoji [27]** | **101.23 μs** |  **3.354 μs** |  **1.996 μs** |  **1.00** |    **0.03** |  **65.37 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)yDoji [27] |  63.58 μs |  8.930 μs |  5.907 μs |  0.63 |    0.06 |  19.91 KB |        0.30 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)yDoji [27]** | **533.59 μs** | **37.911 μs** | **22.560 μs** |  **1.00** |    **0.06** | **633.41 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)yDoji [27] | 390.87 μs | 49.920 μs | 29.706 μs |  0.73 |    0.06 | 125.38 KB |        0.20 |
