```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)iLine [24]** | **104.44 μs** |  **1.309 μs** |  **0.684 μs** |  **1.00** |    **0.01** |  **65.37 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)iLine [24] |  74.76 μs | 18.691 μs | 12.363 μs |  0.72 |    0.11 |  19.02 KB |        0.29 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)iLine [24]** | **574.32 μs** | **33.005 μs** | **19.641 μs** |  **1.00** |    **0.05** | **634.39 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)iLine [24] | 695.01 μs | 15.052 μs |  8.957 μs |  1.21 |    0.04 | 124.39 KB |        0.20 |
