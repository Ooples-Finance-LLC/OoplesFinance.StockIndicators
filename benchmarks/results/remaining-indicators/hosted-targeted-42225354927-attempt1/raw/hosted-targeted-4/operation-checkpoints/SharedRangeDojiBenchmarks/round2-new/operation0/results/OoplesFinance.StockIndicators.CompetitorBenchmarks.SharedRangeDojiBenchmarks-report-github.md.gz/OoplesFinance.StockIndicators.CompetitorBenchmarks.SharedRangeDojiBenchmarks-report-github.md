```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|-----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)iLine [24]** | **1000**  |  **71.63 μs** |   **0.441 μs** |  **0.262 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)iLine [24] | 1000  |  57.77 μs |   8.476 μs |  5.606 μs |  0.81 |    0.07 |  0.4883 |       - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib(...)iLine [24] | 1000  |  73.78 μs |   0.646 μs |  0.338 μs |  1.03 |    0.01 |  3.4180 |  0.4883 |  57.27 KB |       14.43 |
| BuilderLatestOnly | TaLib(...)iLine [24] | 1000  |  64.53 μs |   0.453 μs |  0.237 μs |  0.90 |    0.00 |  0.4883 |       - |   9.39 KB |        2.37 |
|                   |                      |       |           |            |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)iLine [24]** | **10000** | **697.78 μs** |   **2.048 μs** |  **1.071 μs** |  **1.00** |    **0.00** |       **-** |       **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)iLine [24] | 10000 | 458.96 μs | 107.819 μs | 71.315 μs |  0.66 |    0.10 |  3.9063 |       - |   78.7 KB |        2.01 |
| BuilderFull       | TaLib(...)iLine [24] | 10000 | 639.52 μs |   2.984 μs |  1.776 μs |  0.92 |    0.00 | 31.2500 | 11.7188 | 549.83 KB |       14.04 |
| BuilderLatestOnly | TaLib(...)iLine [24] | 10000 | 588.62 μs |   2.246 μs |  1.175 μs |  0.84 |    0.00 |  3.9063 |       - |  79.73 KB |        2.04 |
