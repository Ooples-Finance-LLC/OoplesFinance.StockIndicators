```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)iLine [24]** | **1000**  |  **84.81 μs** |  **5.611 μs** |  **3.339 μs** |       **-** |       **-** |  **57.31 KB** |
| BuilderLatestOnly | TaLib(...)iLine [24] | 1000  |  64.89 μs |  2.853 μs |  1.698 μs |  0.4883 |       - |   9.39 KB |
| **BuilderFull**       | **TaLib(...)iLine [24]** | **10000** | **696.01 μs** | **69.406 μs** | **45.908 μs** | **31.2500** | **11.7188** | **549.83 KB** |
| BuilderLatestOnly | TaLib(...)iLine [24] | 10000 | 648.70 μs | 72.085 μs | 47.680 μs |  3.9063 |       - |  79.73 KB |
