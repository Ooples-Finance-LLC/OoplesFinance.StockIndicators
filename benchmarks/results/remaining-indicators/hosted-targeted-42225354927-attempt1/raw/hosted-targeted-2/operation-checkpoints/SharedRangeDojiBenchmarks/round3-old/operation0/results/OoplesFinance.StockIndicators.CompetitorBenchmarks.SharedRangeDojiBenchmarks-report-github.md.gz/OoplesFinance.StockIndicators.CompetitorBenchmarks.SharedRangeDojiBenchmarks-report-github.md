```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)eDoji [28]** | **1000**  |  **52.39 μs** | **1.729 μs** | **0.904 μs** |       **-** |       **-** |  **57.26 KB** |
| BuilderLatestOnly | TaLib(...)eDoji [28] | 1000  |  49.80 μs | 0.987 μs | 0.587 μs |  0.4883 |       - |   9.38 KB |
| **BuilderFull**       | **TaLib(...)eDoji [28]** | **10000** | **488.05 μs** | **4.608 μs** | **2.742 μs** | **31.2500** | **11.7188** | **549.82 KB** |
| BuilderLatestOnly | TaLib(...)eDoji [28] | 10000 | 455.46 μs | 1.961 μs | 1.026 μs |  3.9063 |       - |  79.71 KB |
