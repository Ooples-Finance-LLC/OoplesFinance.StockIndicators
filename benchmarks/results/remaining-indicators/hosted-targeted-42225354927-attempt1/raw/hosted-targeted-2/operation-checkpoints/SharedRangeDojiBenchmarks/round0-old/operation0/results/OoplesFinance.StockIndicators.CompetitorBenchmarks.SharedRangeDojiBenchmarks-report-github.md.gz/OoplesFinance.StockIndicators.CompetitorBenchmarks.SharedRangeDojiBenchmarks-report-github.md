```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)eDoji [28]** | **1000**  |  **66.18 μs** | **0.325 μs** | **0.170 μs** |       **-** |       **-** |   **57.3 KB** |
| BuilderLatestOnly | TaLib(...)eDoji [28] | 1000  |  49.66 μs | 0.812 μs | 0.425 μs |  0.4883 |       - |   9.38 KB |
| **BuilderFull**       | **TaLib(...)eDoji [28]** | **10000** | **488.30 μs** | **9.083 μs** | **4.751 μs** | **31.2500** | **11.7188** | **549.81 KB** |
| BuilderLatestOnly | TaLib(...)eDoji [28] | 10000 | 467.16 μs | 9.975 μs | 5.936 μs |  3.9063 |       - |  79.71 KB |
