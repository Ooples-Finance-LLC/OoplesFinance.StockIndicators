```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)eDoji [28]** | **1000**  |  **45.10 μs** |  **0.128 μs** |  **0.076 μs** |  **1.00** |    **0.00** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)eDoji [28] | 1000  |  37.71 μs |  5.088 μs |  3.366 μs |  0.84 |    0.07 |  0.4883 |       - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib(...)eDoji [28] | 1000  |  46.25 μs |  1.300 μs |  0.860 μs |  1.03 |    0.02 |  3.4180 |  0.4883 |  57.27 KB |       14.43 |
| BuilderLatestOnly | TaLib(...)eDoji [28] | 1000  |  44.41 μs |  1.075 μs |  0.711 μs |  0.98 |    0.02 |  0.4883 |       - |   9.38 KB |        2.36 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)eDoji [28]** | **10000** | **468.38 μs** | **29.069 μs** | **19.227 μs** |  **1.00** |    **0.06** |       **-** |       **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib(...)eDoji [28] | 10000 | 324.08 μs | 58.754 μs | 38.862 μs |  0.69 |    0.08 |  5.8594 |       - |   78.7 KB |        2.01 |
| BuilderFull       | TaLib(...)eDoji [28] | 10000 | 421.46 μs | 10.417 μs |  6.199 μs |  0.90 |    0.04 | 31.2500 | 11.7188 | 549.82 KB |       14.05 |
| BuilderLatestOnly | TaLib(...)eDoji [28] | 10000 | 400.69 μs |  5.037 μs |  2.997 μs |  0.86 |    0.03 |  3.9063 |       - |  79.73 KB |        2.04 |
