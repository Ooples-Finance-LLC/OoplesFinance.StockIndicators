```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)eDoji [28]** |  **91.23 μs** |  **4.319 μs** |  **2.857 μs** |  **1.00** |    **0.04** |  **65.37 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)eDoji [28] |  45.16 μs |  1.239 μs |  0.648 μs |  0.50 |    0.02 |  16.63 KB |        0.25 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)eDoji [28]** | **475.04 μs** | **25.068 μs** | **14.917 μs** |  **1.00** |    **0.04** | **630.13 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)eDoji [28] | 439.24 μs | 20.429 μs | 12.157 μs |  0.93 |    0.04 | 122.09 KB |        0.19 |
