```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)dDoji [28]** | **1000**  |  **59.60 μs** |  **0.674 μs** |  **0.446 μs** |  **1.00** |    **0.01** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)dDoji [28] | 1000  |  53.37 μs |  8.466 μs |  5.600 μs |  0.90 |    0.09 |  0.4883 |       - |   8.38 KB |        2.11 |
| BuilderFull       | TaLib(...)dDoji [28] | 1000  |  65.68 μs |  1.376 μs |  0.819 μs |  1.10 |    0.02 |  3.4180 |  0.4883 |  57.27 KB |       14.43 |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 1000  |  60.57 μs |  0.380 μs |  0.251 μs |  1.02 |    0.01 |  0.4883 |       - |   9.39 KB |        2.37 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib(...)dDoji [28]** | **10000** | **601.42 μs** |  **4.703 μs** |  **2.799 μs** |  **1.00** |    **0.01** |       **-** |       **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)dDoji [28] | 10000 | 407.51 μs | 63.833 μs | 42.221 μs |  0.68 |    0.07 |  5.8594 |       - |   78.7 KB |        2.01 |
| BuilderFull       | TaLib(...)dDoji [28] | 10000 | 597.60 μs |  4.326 μs |  2.263 μs |  0.99 |    0.01 | 31.2500 | 11.7188 | 549.83 KB |       14.04 |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 10000 | 560.01 μs |  2.966 μs |  1.765 μs |  0.93 |    0.00 |  3.9063 |       - |  79.73 KB |        2.04 |
