```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)dDoji [28]** | **1000**  |  **90.25 μs** | **0.573 μs** | **0.299 μs** |       **-** |       **-** |  **57.26 KB** |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 1000  |  66.30 μs | 0.933 μs | 0.488 μs |  0.4883 |       - |   9.38 KB |
| **BuilderFull**       | **TaLib(...)dDoji [28]** | **10000** | **654.14 μs** | **4.787 μs** | **2.504 μs** | **31.2500** | **11.7188** | **549.82 KB** |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 10000 | 613.43 μs | 4.278 μs | 2.546 μs |  3.9063 |       - |  79.72 KB |
