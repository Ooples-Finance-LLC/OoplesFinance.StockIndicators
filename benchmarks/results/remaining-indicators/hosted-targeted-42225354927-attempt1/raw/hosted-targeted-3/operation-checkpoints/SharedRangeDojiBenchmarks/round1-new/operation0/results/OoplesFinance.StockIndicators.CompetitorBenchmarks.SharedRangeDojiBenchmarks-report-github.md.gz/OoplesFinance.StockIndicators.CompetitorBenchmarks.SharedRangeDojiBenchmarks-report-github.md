```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)dDoji [28]** | **1000**  |  **83.78 μs** | **0.910 μs** | **0.476 μs** |       **-** |       **-** |  **57.31 KB** |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 1000  |  59.35 μs | 0.614 μs | 0.365 μs |  0.4883 |       - |   9.39 KB |
| **BuilderFull**       | **TaLib(...)dDoji [28]** | **10000** | **585.48 μs** | **1.904 μs** | **1.133 μs** | **31.2500** | **11.7188** | **549.83 KB** |
| BuilderLatestOnly | TaLib(...)dDoji [28] | 10000 | 544.70 μs | 4.773 μs | 2.840 μs |  3.9063 |       - |  79.73 KB |
