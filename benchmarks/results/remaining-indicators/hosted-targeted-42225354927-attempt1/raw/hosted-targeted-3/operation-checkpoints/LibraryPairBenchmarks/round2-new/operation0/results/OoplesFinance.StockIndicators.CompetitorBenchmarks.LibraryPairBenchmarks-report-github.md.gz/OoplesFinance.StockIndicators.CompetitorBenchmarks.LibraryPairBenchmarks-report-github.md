```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dDoji [28]** | **112.13 μs** |  **17.896 μs** |  **10.650 μs** |  **1.01** |    **0.12** |  **65.37 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dDoji [28] |  84.33 μs |  17.457 μs |  11.547 μs |  0.76 |    0.12 |  19.91 KB |        0.30 |
|            |       |                      |           |            |            |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)dDoji [28]** | **570.60 μs** |   **4.717 μs** |   **2.467 μs** |  **1.00** |    **0.01** | **635.98 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dDoji [28] | 907.00 μs | 254.595 μs | 168.399 μs |  1.59 |    0.28 | 125.38 KB |        0.20 |
