```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **1000**  |   **351.8 μs** |   **3.34 μs** |   **1.75 μs** |       **-** |  **57.78 KB** |
| BuilderLatestOnly | 1000  |   343.5 μs |   2.92 μs |   1.74 μs |       - |   9.84 KB |
| **BuilderFull**       | **10000** | **3,755.7 μs** | **448.45 μs** | **296.62 μs** | **31.2500** | **550.51 KB** |
| BuilderLatestOnly | 10000 | 3,419.9 μs |  54.84 μs |  28.68 μs |       - |   80.4 KB |
