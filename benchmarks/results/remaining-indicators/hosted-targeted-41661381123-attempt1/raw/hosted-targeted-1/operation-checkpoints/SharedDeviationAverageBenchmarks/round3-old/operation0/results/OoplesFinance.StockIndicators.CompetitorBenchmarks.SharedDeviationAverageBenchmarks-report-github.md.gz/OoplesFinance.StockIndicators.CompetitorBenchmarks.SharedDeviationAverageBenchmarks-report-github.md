```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **1000**  |   **501.6 μs** |  **4.65 μs** |  **3.08 μs** |       **-** |  **57.71 KB** |
| BuilderLatestOnly | 1000  |   497.2 μs |  3.49 μs |  2.07 μs |       - |   9.85 KB |
| **BuilderFull**       | **10000** | **4,984.0 μs** | **51.75 μs** | **34.23 μs** | **31.2500** | **550.47 KB** |
| BuilderLatestOnly | 10000 | 5,227.5 μs | 32.99 μs | 17.25 μs |       - |  80.37 KB |
