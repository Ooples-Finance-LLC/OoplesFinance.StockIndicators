```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **1000**  |   **524.9 μs** |  **14.82 μs** |   **8.82 μs** |       **-** |  **57.67 KB** |
| BuilderLatestOnly | 1000  |   516.9 μs |   3.05 μs |   1.81 μs |       - |   9.84 KB |
| **BuilderFull**       | **10000** | **5,192.4 μs** | **196.00 μs** | **129.64 μs** | **31.2500** | **550.44 KB** |
| BuilderLatestOnly | 10000 | 5,051.0 μs |  24.55 μs |  12.84 μs |       - |   80.3 KB |
