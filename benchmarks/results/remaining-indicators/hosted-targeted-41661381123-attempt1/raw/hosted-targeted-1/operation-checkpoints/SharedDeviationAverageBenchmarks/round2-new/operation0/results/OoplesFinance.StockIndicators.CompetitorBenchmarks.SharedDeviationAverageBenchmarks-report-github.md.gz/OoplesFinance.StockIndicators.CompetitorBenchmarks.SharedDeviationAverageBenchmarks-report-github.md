```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |------ |------------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **1000**  |   **356.62 μs** |  **2.808 μs** |  **1.671 μs** |  **5.78** |    **0.13** |        **-** |       **-** |   **57.78 KB** |        **0.27** |
| BuilderLatestOnly | 1000  |   347.25 μs |  3.936 μs |  2.342 μs |  5.62 |    0.13 |        - |       - |    9.85 KB |        0.05 |
| NativeSingle      | 1000  |    61.77 μs |  2.378 μs |  1.415 μs |  1.00 |    0.03 |  12.6953 |       - |  214.78 KB |        1.00 |
| NativeParallel    | 1000  |   113.83 μs |  4.973 μs |  3.289 μs |  1.84 |    0.06 |  31.2500 |  0.9766 |  520.93 KB |        2.43 |
|                   |       |             |           |           |       |         |          |         |            |             |
| **BuilderFull**       | **10000** | **3,475.59 μs** |  **8.088 μs** |  **4.230 μs** |  **5.63** |    **0.10** |  **31.2500** |       **-** |  **550.49 KB** |        **0.25** |
| BuilderLatestOnly | 10000 | 3,355.83 μs |  7.598 μs |  4.521 μs |  5.43 |    0.10 |        - |       - |   80.33 KB |        0.04 |
| NativeSingle      | 10000 |   617.90 μs | 17.538 μs | 11.600 μs |  1.00 |    0.03 | 132.8125 | 23.4375 |    2173 KB |        1.00 |
| NativeParallel    | 10000 |   982.10 μs | 69.901 μs | 46.235 μs |  1.59 |    0.08 | 320.3125 | 62.5000 | 5311.21 KB |        2.44 |
