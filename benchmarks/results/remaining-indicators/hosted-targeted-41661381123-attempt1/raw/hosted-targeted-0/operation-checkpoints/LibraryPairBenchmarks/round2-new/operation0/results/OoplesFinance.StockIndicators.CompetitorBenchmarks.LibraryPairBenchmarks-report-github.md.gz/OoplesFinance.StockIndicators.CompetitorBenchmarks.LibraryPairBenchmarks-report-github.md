```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Dsma** |   **940.3 μs** | **421.23 μs** | **278.62 μs** |  **1.07** |    **0.41** |  **512.61 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Dsma |   153.6 μs |  20.29 μs |  13.42 μs |  0.18 |    0.05 |  222.68 KB |        0.43 |
|            |       |                |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Dsma** | **9,065.3 μs** | **568.34 μs** | **338.21 μs** |  **1.00** |    **0.05** | **8105.13 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Dsma | 1,226.0 μs |  18.74 μs |   9.80 μs |  0.14 |    0.00 | 2180.93 KB |        0.27 |
