```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error      | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|-----------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Historical** |   **859.1 μs** |   **100.5 μs** |    **52.55 μs** |  **1.00** |    **0.08** |  **106.81 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Historical |   681.9 μs |   199.1 μs |   131.72 μs |  0.80 |    0.15 |   439.3 KB |        4.11 |
|            |       |                      |            |            |             |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Historical** | **9,849.9 μs** | **1,948.5 μs** | **1,288.78 μs** |  **1.01** |    **0.17** | **1038.15 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Historical | 6,384.2 μs |   722.4 μs |   377.85 μs |  0.66 |    0.08 | 4375.38 KB |        4.21 |
