```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **QuanTAlib.Historical** | **1000**  |  **3.975 ms** | **0.0831 ms** | **0.0550 ms** |  **66.07 KB** |
| BuilderLatestOnly | QuanTAlib.Historical | 1000  |  1.511 ms | 0.0077 ms | 0.0046 ms |  18.32 KB |
| **BuilderFull**       | **QuanTAlib.Historical** | **10000** | **15.248 ms** | **0.0494 ms** | **0.0258 ms** | **629.72 KB** |
| BuilderLatestOnly | QuanTAlib.Historical | 10000 | 15.188 ms | 0.0644 ms | 0.0337 ms | 160.52 KB |
