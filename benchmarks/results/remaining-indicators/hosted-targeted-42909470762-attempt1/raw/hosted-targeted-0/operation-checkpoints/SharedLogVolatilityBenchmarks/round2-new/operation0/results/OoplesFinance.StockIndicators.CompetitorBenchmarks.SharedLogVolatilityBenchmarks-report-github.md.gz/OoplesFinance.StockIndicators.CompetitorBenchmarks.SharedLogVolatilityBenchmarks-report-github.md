```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error       | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|------------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Historical** | **1000**  | **2,039.0 μs** | **1,344.22 μs** | **889.12 μs** |  **4.14** |    **1.72** |        **-** |       **-** |   **65.97 KB** |        **0.16** |
| BuilderLatestOnly | QuanTAlib.Historical | 1000  |   868.9 μs |     5.27 μs |   2.75 μs |  1.77 |    0.02 |        - |       - |   18.32 KB |        0.04 |
| NativeSingle      | QuanTAlib.Historical | 1000  |   492.0 μs |     9.06 μs |   5.99 μs |  1.00 |    0.02 |  23.4375 |       - |  414.08 KB |        1.00 |
| NativeParallel    | QuanTAlib.Historical | 1000  |   357.8 μs |    23.26 μs |  15.39 μs |  0.73 |    0.03 |  25.3906 |       - |  418.64 KB |        1.01 |
|                   |                      |       |            |             |           |       |         |          |         |            |             |
| **BuilderFull**       | **QuanTAlib.Historical** | **10000** | **8,837.4 μs** |    **59.58 μs** |  **35.45 μs** |  **1.81** |    **0.03** |        **-** |       **-** |  **629.38 KB** |        **0.15** |
| BuilderLatestOnly | QuanTAlib.Historical | 10000 | 8,668.1 μs |    21.33 μs |  11.16 μs |  1.78 |    0.02 |        - |       - |  159.56 KB |        0.04 |
| NativeSingle      | QuanTAlib.Historical | 10000 | 4,878.0 μs |   106.49 μs |  70.44 μs |  1.00 |    0.02 | 250.0000 | 31.2500 | 4200.62 KB |        1.00 |
| NativeParallel    | QuanTAlib.Historical | 10000 | 2,839.3 μs |   111.40 μs |  58.26 μs |  0.58 |    0.01 | 250.0000 | 31.2500 | 4205.56 KB |        1.00 |
