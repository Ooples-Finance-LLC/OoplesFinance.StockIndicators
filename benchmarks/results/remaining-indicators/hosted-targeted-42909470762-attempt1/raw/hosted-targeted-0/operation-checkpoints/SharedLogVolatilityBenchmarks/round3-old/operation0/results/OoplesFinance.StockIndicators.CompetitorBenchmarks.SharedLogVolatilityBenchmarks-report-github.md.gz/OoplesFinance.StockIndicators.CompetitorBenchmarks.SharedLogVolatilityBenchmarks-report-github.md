```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **QuanTAlib.Historical** | **1000**  |  **3.036 ms** | **0.0343 ms** | **0.0204 ms** |  **66.07 KB** |
| BuilderLatestOnly | QuanTAlib.Historical | 1000  |  1.496 ms | 0.0107 ms | 0.0064 ms |  18.38 KB |
| **BuilderFull**       | **QuanTAlib.Historical** | **10000** | **15.195 ms** | **0.0853 ms** | **0.0564 ms** | **629.86 KB** |
| BuilderLatestOnly | QuanTAlib.Historical | 10000 | 14.970 ms | 0.2048 ms | 0.1219 ms | 160.09 KB |
