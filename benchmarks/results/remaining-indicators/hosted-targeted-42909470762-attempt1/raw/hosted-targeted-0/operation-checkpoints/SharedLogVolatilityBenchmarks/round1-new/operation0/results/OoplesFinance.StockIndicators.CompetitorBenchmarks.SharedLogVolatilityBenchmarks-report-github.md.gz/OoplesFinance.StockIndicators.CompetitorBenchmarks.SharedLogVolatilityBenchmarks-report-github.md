```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **QuanTAlib.Historical** | **1000**  |   **889.1 μs** |  **4.99 μs** |  **2.97 μs** |  **65.97 KB** |
| BuilderLatestOnly | QuanTAlib.Historical | 1000  |   866.5 μs |  3.35 μs |  1.99 μs |  18.32 KB |
| **BuilderFull**       | **QuanTAlib.Historical** | **10000** | **8,738.2 μs** | **84.35 μs** | **44.12 μs** |  **629.4 KB** |
| BuilderLatestOnly | QuanTAlib.Historical | 10000 | 8,709.7 μs | 24.22 μs | 14.42 μs | 159.56 KB |
