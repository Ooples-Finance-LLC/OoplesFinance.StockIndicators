```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **QuanTAlib.Realized** | **1000**  |   **635.3 μs** |  **1.93 μs** |  **1.01 μs** |  **65.96 KB** |
| BuilderLatestOnly | QuanTAlib.Realized | 1000  |   613.7 μs |  2.26 μs |  1.18 μs |  18.29 KB |
| **BuilderFull**       | **QuanTAlib.Realized** | **10000** | **6,288.9 μs** | **40.60 μs** | **24.16 μs** | **629.18 KB** |
| BuilderLatestOnly | QuanTAlib.Realized | 10000 | 6,160.6 μs | 22.14 μs | 13.17 μs | 159.15 KB |
