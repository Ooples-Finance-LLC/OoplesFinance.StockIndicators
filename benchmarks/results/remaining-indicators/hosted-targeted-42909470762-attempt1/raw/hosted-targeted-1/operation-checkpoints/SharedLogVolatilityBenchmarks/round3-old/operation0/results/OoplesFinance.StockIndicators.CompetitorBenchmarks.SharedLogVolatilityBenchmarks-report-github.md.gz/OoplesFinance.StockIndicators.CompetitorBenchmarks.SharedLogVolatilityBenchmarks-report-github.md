```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **QuanTAlib.Realized** | **1000**  |  **3.132 ms** | **0.0805 ms** | **0.0533 ms** |  **66.03 KB** |
| BuilderLatestOnly | QuanTAlib.Realized | 1000  |  1.240 ms | 0.0053 ms | 0.0028 ms |  18.32 KB |
| **BuilderFull**       | **QuanTAlib.Realized** | **10000** | **12.587 ms** | **0.0601 ms** | **0.0314 ms** | **629.71 KB** |
| BuilderLatestOnly | QuanTAlib.Realized | 10000 | 12.339 ms | 0.0562 ms | 0.0334 ms | 159.82 KB |
