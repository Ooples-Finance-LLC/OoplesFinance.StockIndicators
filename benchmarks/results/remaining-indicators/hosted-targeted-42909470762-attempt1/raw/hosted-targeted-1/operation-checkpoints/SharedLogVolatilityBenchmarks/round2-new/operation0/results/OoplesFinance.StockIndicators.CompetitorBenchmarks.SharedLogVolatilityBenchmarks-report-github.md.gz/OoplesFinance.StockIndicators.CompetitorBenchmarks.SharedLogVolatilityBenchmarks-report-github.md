```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated  | Alloc Ratio |
|------------------ |------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Realized** | **1000**  | **1,107.75 μs** |  **5.367 μs** |  **3.194 μs** | **14.09** |    **0.19** |       **-** |      **-** |   **65.96 KB** |        **1.39** |
| BuilderLatestOnly | QuanTAlib.Realized | 1000  |   611.43 μs | 15.221 μs |  9.058 μs |  7.78 |    0.15 |       - |      - |   18.29 KB |        0.39 |
| NativeSingle      | QuanTAlib.Realized | 1000  |    78.64 μs |  1.815 μs |  1.080 μs |  1.00 |    0.02 |  2.4414 |      - |   47.47 KB |        1.00 |
| NativeParallel    | QuanTAlib.Realized | 1000  |   170.77 μs | 12.841 μs |  8.494 μs |  2.17 |    0.11 |  5.8594 |      - |  107.95 KB |        2.27 |
|                   |                    |       |             |           |           |       |         |         |        |            |             |
| **BuilderFull**       | **QuanTAlib.Realized** | **10000** | **6,056.81 μs** | **29.634 μs** | **17.635 μs** |  **7.72** |    **0.06** | **31.2500** |      **-** |  **628.96 KB** |        **1.34** |
| BuilderLatestOnly | QuanTAlib.Realized | 10000 | 5,904.46 μs | 32.063 μs | 19.080 μs |  7.52 |    0.06 |       - |      - |  159.13 KB |        0.34 |
| NativeSingle      | QuanTAlib.Realized | 10000 |   784.89 μs |  8.811 μs |  5.828 μs |  1.00 |    0.01 | 23.4375 |      - |   469.4 KB |        1.00 |
| NativeParallel    | QuanTAlib.Realized | 10000 | 1,251.44 μs | 39.975 μs | 26.441 μs |  1.59 |    0.03 | 62.5000 | 7.8125 | 1057.23 KB |        2.25 |
