```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Realized** |   **553.1 μs** | **25.11 μs** | **14.94 μs** |  **1.00** |    **0.04** |  **106.81 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Realized |   126.4 μs |  0.35 μs |  0.18 μs |  0.23 |    0.01 |   72.44 KB |        0.68 |
|            |       |                    |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Realized** | **5,378.0 μs** | **50.80 μs** | **26.57 μs** |  **1.00** |    **0.01** | **1037.49 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Realized | 1,251.6 μs | 30.82 μs | 18.34 μs |  0.23 |    0.00 |  643.73 KB |        0.62 |
