```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDM [22]** |   **131.94 μs** | **10.439 μs** |  **6.905 μs** |  **1.00** |    **0.07** |  **105.64 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDM [22] |    11.39 μs |  2.576 μs |  1.704 μs |  0.09 |    0.01 |   36.33 KB |        0.34 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDM [22]** | **1,046.04 μs** | **17.635 μs** | **11.665 μs** |  **1.00** |    **0.02** | **1029.15 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDM [22] |   104.74 μs |  1.475 μs |  0.878 μs |  0.10 |    0.00 |  324.07 KB |        0.31 |
