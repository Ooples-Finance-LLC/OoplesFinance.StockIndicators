```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|-----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |  **94.748 μs** |  **5.0549 μs** | **3.3435 μs** | **11.68** |    **0.40** |  **3.9063** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |  90.222 μs |  0.8404 μs | 0.4396 μs | 11.12 |    0.09 |  0.9766 |      - |  17.39 KB |        2.25 |
| NativeSingle      | TaLib(...)lusDM [22] | 1000  |   8.113 μs |  0.0829 μs | 0.0548 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 1000  |  10.465 μs |  0.3359 μs | 0.2222 μs |  1.29 |    0.03 |  1.8311 |      - |  27.23 KB |        3.53 |
|                   |                      |       |            |            |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **911.410 μs** | **15.5641 μs** | **8.1403 μs** | **11.22** |    **0.13** | **31.2500** | **7.8125** | **627.86 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 874.842 μs |  8.7581 μs | 5.2118 μs | 10.77 |    0.11 |  7.8125 |      - | 158.04 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDM [22] | 10000 |  81.217 μs |  1.2364 μs | 0.7357 μs |  1.00 |    0.01 |  4.3945 |      - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 10000 | 124.125 μs |  9.7215 μs | 6.4302 μs |  1.53 |    0.08 | 17.5781 | 3.9063 | 273.33 KB |        3.50 |
