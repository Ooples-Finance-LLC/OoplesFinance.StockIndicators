```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **239.8 μs** |  **4.77 μs** |  **2.49 μs** |  **5.8594** |       **-** |  **97.02 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   232.1 μs | 10.49 μs |  6.94 μs |  1.9531 |       - |  49.42 KB |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **2,388.7 μs** | **69.40 μs** | **45.90 μs** | **46.8750** | **15.6250** | **941.13 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 2,414.7 μs | 62.39 μs | 37.13 μs | 15.6250 |       - |  471.3 KB |
