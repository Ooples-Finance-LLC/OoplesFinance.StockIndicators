```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **175.48 μs** |   **2.271 μs** |  **1.351 μs** |  **3.84** |    **0.09** |        **-** |        **-** |       **-** |   **97.02 KB** |        **0.26** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   165.21 μs |   3.142 μs |  1.644 μs |  3.61 |    0.09 |   1.9531 |        - |       - |   49.42 KB |        0.13 |
| NativeSingle      | Skend(...)inOsc [21] | 1000  |    45.75 μs |   1.846 μs |  1.098 μs |  1.00 |    0.03 |  23.1934 |   7.3242 |       - |   379.7 KB |        1.00 |
| NativeParallel    | Skend(...)inOsc [21] | 1000  |    89.24 μs |   6.451 μs |  4.267 μs |  1.95 |    0.10 |  60.5469 |  22.4609 |       - |  958.67 KB |        2.52 |
|                   |                      |       |             |            |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **1,710.22 μs** |  **59.751 μs** | **39.522 μs** |  **2.51** |    **0.08** |  **46.8750** |  **15.6250** |       **-** |  **941.19 KB** |        **0.25** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 1,701.48 μs |  67.164 μs | 39.968 μs |  2.50 |    0.08 |  15.6250 |        - |       - |  471.37 KB |        0.12 |
| NativeSingle      | Skend(...)inOsc [21] | 10000 |   682.30 μs |  26.859 μs | 17.766 μs |  1.00 |    0.04 | 246.0938 | 148.4375 | 46.8750 | 3790.24 KB |        1.00 |
| NativeParallel    | Skend(...)inOsc [21] | 10000 | 1,512.46 μs | 113.449 μs | 67.512 μs |  2.22 |    0.11 | 609.3750 | 531.2500 | 78.1250 | 9555.13 KB |        2.52 |
