```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)inOsc [21]** |   **269.58 μs** | **24.914 μs** | **14.826 μs** |  **1.00** |    **0.07** |  **259.67 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)inOsc [21] |    57.84 μs |  3.106 μs |  1.625 μs |  0.22 |    0.01 |   488.3 KB |        1.88 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)inOsc [21]** | **2,477.08 μs** | **34.652 μs** | **22.920 μs** |  **1.00** |    **0.01** | **2545.16 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)inOsc [21] |   567.31 μs | 32.770 μs | 19.501 μs |  0.23 |    0.01 | 4846.36 KB |        1.90 |
