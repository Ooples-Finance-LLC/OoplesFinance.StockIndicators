```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **693.8 μs** |   **6.66 μs** |  **3.96 μs** |     **65 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   689.4 μs |  23.21 μs | 13.81 μs |  17.41 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **7,057.6 μs** | **104.82 μs** | **69.33 μs** | **628.36 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 6,993.2 μs |  39.27 μs | 25.97 μs | 158.55 KB |
