```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **652.86 μs** |  **5.796 μs** |  **3.032 μs** | **41.88** |    **0.23** |       **-** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   650.44 μs |  9.129 μs |  5.432 μs | 41.72 |    0.36 |       - |      - |  17.41 KB |        2.26 |
| NativeSingle      | TaLib.Functions.Dx | 1000  |    15.59 μs |  0.105 μs |  0.055 μs |  1.00 |    0.00 |  0.3662 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 1000  |    26.44 μs |  1.254 μs |  0.829 μs |  1.70 |    0.05 |  1.7090 |      - |  27.24 KB |        3.53 |
|                   |                    |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **6,548.47 μs** | **73.923 μs** | **48.896 μs** | **41.44** |    **0.35** |       **-** |      **-** | **628.35 KB** |        **8.05** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 6,538.05 μs | 41.956 μs | 21.944 μs | 41.38 |    0.23 |       - |      - | 158.54 KB |        2.03 |
| NativeSingle      | TaLib.Functions.Dx | 10000 |   158.01 μs |  1.126 μs |  0.744 μs |  1.00 |    0.01 |  3.9063 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 10000 |   232.01 μs | 16.708 μs |  9.942 μs |  1.47 |    0.06 | 17.5781 | 3.9063 | 273.35 KB |        3.50 |
