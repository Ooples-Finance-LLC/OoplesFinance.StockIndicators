```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **702.5 μs** | **18.29 μs** | **10.88 μs** |     **65 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   697.7 μs | 14.97 μs |  9.90 μs |  17.42 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **7,173.6 μs** | **95.14 μs** | **56.62 μs** | **628.41 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 7,058.2 μs | 37.71 μs | 24.94 μs | 158.59 KB |
