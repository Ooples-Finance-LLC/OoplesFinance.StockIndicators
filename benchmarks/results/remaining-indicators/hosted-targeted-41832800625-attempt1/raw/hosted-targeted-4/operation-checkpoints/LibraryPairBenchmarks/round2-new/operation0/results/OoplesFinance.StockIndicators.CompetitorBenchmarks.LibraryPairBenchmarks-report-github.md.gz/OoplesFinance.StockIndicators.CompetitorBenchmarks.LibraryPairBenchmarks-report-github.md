```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean        | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |------------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Dx** |   **698.24 μs** |  **35.733 μs** |  **23.635 μs** |  **1.00** |    **0.05** |  **105.67 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Dx |    22.20 μs |   2.040 μs |   1.349 μs |  0.03 |    0.00 |   40.88 KB |        0.39 |
|            |       |                    |             |            |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Dx** | **6,756.19 μs** | **247.182 μs** | **147.094 μs** |  **1.00** |    **0.03** | **1036.73 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Dx |   206.80 μs |   5.498 μs |   2.876 μs |  0.03 |    0.00 |  330.92 KB |        0.32 |
