```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDI [23]** |   **314.45 μs** | **26.545 μs** | **17.558 μs** |  **1.00** |    **0.07** |  **105.67 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDI [23] |    14.97 μs |  1.241 μs |  0.821 μs |  0.05 |    0.00 |   40.27 KB |        0.38 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDI [23]** | **3,018.27 μs** | **57.064 μs** | **33.958 μs** |  **1.00** |    **0.02** | **1035.04 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDI [23] |   128.83 μs |  5.413 μs |  3.221 μs |  0.04 |    0.00 |  330.59 KB |        0.32 |
