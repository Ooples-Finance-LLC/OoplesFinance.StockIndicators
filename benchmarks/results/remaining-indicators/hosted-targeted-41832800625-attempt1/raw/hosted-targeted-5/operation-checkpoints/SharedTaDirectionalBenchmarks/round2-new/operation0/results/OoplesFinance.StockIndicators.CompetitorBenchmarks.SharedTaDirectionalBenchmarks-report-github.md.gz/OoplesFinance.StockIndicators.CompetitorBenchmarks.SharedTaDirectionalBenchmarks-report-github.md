```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **253.556 μs** | **13.0162 μs** |  **7.7457 μs** | **34.35** |    **1.15** |       **-** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   248.023 μs |  4.9889 μs |  2.9688 μs | 33.60 |    0.69 |       - |      - |  17.39 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDI [23] | 1000  |     7.384 μs |  0.2011 μs |  0.1330 μs |  1.00 |    0.02 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 1000  |    12.125 μs |  0.7745 μs |  0.4609 μs |  1.64 |    0.07 |  1.8311 |      - |  27.24 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **2,825.798 μs** | **60.6358 μs** | **36.0834 μs** | **40.87** |    **0.62** | **31.2500** |      **-** | **627.95 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,729.242 μs | 60.7302 μs | 36.1396 μs | 39.48 |    0.62 |       - |      - | 158.12 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDI [23] | 10000 |    69.139 μs |  1.1408 μs |  0.6789 μs |  1.00 |    0.01 |  4.3945 |      - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 10000 |   125.463 μs |  3.4245 μs |  2.2651 μs |  1.81 |    0.04 | 18.5547 | 3.9063 | 273.34 KB |        3.50 |
