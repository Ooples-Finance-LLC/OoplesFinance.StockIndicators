```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **250.2 μs** |  **6.42 μs** |  **3.82 μs** |       **-** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   244.7 μs |  4.69 μs |  2.79 μs |       - |  17.39 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **2,803.0 μs** | **81.30 μs** | **53.78 μs** | **31.2500** | **627.89 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,790.0 μs | 63.09 μs | 37.54 μs |       - | 158.13 KB |
