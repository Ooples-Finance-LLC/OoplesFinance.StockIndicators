```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **251.5 μs** |   **7.85 μs** |   **4.67 μs** |       **-** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   256.9 μs |  12.78 μs |   8.45 μs |       - |   17.4 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **3,041.3 μs** | **166.19 μs** | **109.92 μs** | **31.2500** | **627.97 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,873.7 μs | 186.11 μs | 123.10 μs |       - | 158.13 KB |
