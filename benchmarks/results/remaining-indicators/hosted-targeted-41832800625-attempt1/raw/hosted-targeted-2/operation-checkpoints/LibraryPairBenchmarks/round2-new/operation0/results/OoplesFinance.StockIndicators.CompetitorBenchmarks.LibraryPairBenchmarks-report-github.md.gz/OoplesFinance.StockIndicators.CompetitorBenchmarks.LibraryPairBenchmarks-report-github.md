```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adx** |   **635.63 μs** | **25.242 μs** | **15.021 μs** |  **1.00** |    **0.03** | **105.89 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adx |    23.21 μs |  1.167 μs |  0.610 μs |  0.04 |    0.00 |  40.55 KB |        0.38 |
|            |       |                     |             |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adx** | **6,040.32 μs** | **42.024 μs** | **25.008 μs** |  **1.00** |    **0.01** | **1039.5 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adx |   216.44 μs |  4.732 μs |  2.475 μs |  0.04 |    0.00 | 330.92 KB |        0.32 |
