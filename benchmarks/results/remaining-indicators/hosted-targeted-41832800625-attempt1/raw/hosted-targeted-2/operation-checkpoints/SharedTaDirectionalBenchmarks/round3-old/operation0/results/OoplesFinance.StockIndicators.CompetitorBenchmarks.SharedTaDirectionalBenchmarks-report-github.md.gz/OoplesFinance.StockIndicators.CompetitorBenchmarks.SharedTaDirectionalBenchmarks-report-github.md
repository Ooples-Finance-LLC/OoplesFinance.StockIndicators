```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **629.4 μs** |  **2.59 μs** |  **1.36 μs** |  **65.65 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   627.0 μs | 10.52 μs |  6.26 μs |  18.06 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **6,332.5 μs** | **21.86 μs** | **13.01 μs** | **637.85 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 6,302.4 μs | 25.49 μs | 13.33 μs | 168.04 KB |
