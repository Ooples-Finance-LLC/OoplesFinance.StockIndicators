```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |-------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **596.7 μs** |  **25.85 μs** |  **17.10 μs** |       **-** |  **65.22 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   562.3 μs |   5.29 μs |   2.77 μs |       - |  17.63 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **5,803.6 μs** | **157.48 μs** | **104.16 μs** | **31.2500** |  **630.9 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 5,849.5 μs | 235.33 μs | 155.65 μs |       - | 161.08 KB |
