```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|-----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **573.16 μs** |  **19.730 μs** | **10.319 μs** | **38.25** |    **0.66** |       **-** |      **-** |  **65.22 KB** |        **8.61** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   561.81 μs |   6.670 μs |  3.488 μs | 37.50 |    0.24 |       - |      - |  17.63 KB |        2.33 |
| NativeSingle      | TaLib.Functions.Adx | 1000  |    14.98 μs |   0.072 μs |  0.043 μs |  1.00 |    0.00 |  0.3662 |      - |   7.57 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 1000  |    28.56 μs |   2.109 μs |  1.395 μs |  1.91 |    0.09 |  1.7090 |      - |  26.71 KB |        3.53 |
|                   |                     |       |             |            |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **5,850.01 μs** | **125.779 μs** | **74.849 μs** | **38.60** |    **0.59** | **31.2500** |      **-** | **630.92 KB** |        **8.10** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 5,752.28 μs |  39.283 μs | 23.377 μs | 37.96 |    0.39 |       - |      - | 161.09 KB |        2.07 |
| NativeSingle      | TaLib.Functions.Adx | 10000 |   151.56 μs |   2.965 μs |  1.551 μs |  1.00 |    0.01 |  3.9063 |      - |  77.89 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 10000 |   228.58 μs |  31.068 μs | 20.550 μs |  1.51 |    0.13 | 17.5781 | 3.9063 | 272.82 KB |        3.50 |
