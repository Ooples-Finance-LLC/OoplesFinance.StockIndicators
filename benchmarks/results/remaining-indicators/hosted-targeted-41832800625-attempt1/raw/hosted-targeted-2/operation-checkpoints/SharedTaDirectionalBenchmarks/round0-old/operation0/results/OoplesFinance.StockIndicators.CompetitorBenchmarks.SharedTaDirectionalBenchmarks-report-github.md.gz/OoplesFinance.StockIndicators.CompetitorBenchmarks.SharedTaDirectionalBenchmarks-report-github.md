```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **626.1 μs** |  **6.17 μs** |  **3.67 μs** |  **65.65 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   619.2 μs |  7.20 μs |  3.77 μs |  18.06 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **6,352.1 μs** | **28.91 μs** | **17.20 μs** | **637.87 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 6,298.4 μs | 47.59 μs | 24.89 μs | 167.99 KB |
