```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adxr** |   **671.83 μs** | **26.506 μs** | **17.532 μs** |  **1.00** |    **0.04** | **106.96 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adxr |    24.54 μs |  1.379 μs |  0.821 μs |  0.04 |    0.00 |  48.45 KB |        0.45 |
|            |       |                      |             |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adxr** | **6,340.14 μs** | **52.403 μs** | **27.408 μs** |  **1.00** |    **0.01** | **1040.9 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adxr |   244.21 μs | 22.500 μs | 14.883 μs |  0.04 |    0.00 |  408.8 KB |        0.39 |
