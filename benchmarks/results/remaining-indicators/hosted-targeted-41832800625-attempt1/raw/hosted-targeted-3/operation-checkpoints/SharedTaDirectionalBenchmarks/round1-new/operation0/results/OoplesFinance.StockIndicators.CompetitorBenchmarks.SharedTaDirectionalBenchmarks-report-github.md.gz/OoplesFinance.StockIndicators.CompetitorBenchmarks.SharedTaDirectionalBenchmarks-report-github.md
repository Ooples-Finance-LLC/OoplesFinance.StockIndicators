```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **609.2 μs** |   **5.16 μs** |   **2.70 μs** |  **66.25 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   610.9 μs |  14.26 μs |   8.49 μs |   18.7 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **6,277.7 μs** | **105.24 μs** |  **55.04 μs** | **632.18 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 6,404.5 μs | 310.55 μs | 184.80 μs | 162.58 KB |
