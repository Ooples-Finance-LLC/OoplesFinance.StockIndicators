```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **600.85 μs** |  **9.655 μs** |  **5.746 μs** | **36.02** |    **0.38** |       **-** |      **-** |  **66.29 KB** |        **4.42** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   600.32 μs |  6.374 μs |  3.793 μs | 35.99 |    0.29 |       - |      - |   18.7 KB |        1.25 |
| NativeSingle      | TaLib.Functions.Adxr | 1000  |    16.68 μs |  0.178 μs |  0.093 μs |  1.00 |    0.01 |  0.8545 |      - |  14.99 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 1000  |    30.11 μs |  1.228 μs |  0.731 μs |  1.80 |    0.04 |  3.1738 |      - |  45.43 KB |        3.03 |
|                   |                      |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **6,010.25 μs** | **31.519 μs** | **16.485 μs** | **35.14** |    **0.86** | **31.2500** |      **-** | **631.99 KB** |        **4.06** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 5,964.08 μs | 58.356 μs | 38.599 μs | 34.87 |    0.87 |       - |      - | 162.16 KB |        1.04 |
| NativeSingle      | TaLib.Functions.Adxr | 10000 |   171.13 μs |  6.729 μs |  4.451 μs |  1.00 |    0.03 |  8.7891 | 0.9766 | 155.63 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 10000 |   257.11 μs |  5.241 μs |  2.741 μs |  1.50 |    0.04 | 29.2969 | 7.8125 | 467.32 KB |        3.00 |
