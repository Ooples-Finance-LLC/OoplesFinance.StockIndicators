```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **636.3 μs** |  **4.29 μs** |  **2.56 μs** |  **66.68 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   629.6 μs |  4.13 μs |  2.73 μs |  19.13 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **6,656.9 μs** | **26.55 μs** | **13.89 μs** | **638.88 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 6,448.5 μs | 35.17 μs | 20.93 μs | 169.13 KB |
