```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **645.8 μs** |  **5.20 μs** |  **3.09 μs** |  **66.72 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   634.4 μs |  6.69 μs |  3.50 μs |  19.13 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **6,596.3 μs** | **51.82 μs** | **30.84 μs** | **638.96 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 6,604.7 μs | 16.53 μs |  8.65 μs | 169.15 KB |
