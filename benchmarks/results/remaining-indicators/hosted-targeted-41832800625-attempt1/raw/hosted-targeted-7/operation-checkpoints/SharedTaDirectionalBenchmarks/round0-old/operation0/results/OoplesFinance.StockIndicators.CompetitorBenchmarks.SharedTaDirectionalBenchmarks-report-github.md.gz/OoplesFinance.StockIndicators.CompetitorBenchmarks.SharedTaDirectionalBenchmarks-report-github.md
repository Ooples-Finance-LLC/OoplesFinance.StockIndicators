```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **292.2 μs** |  **2.86 μs** |  **1.70 μs** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   285.5 μs |  5.16 μs |  2.70 μs |   17.4 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **3,020.2 μs** | **14.33 μs** |  **8.53 μs** | **628.08 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,943.2 μs | 51.00 μs | 33.73 μs | 158.14 KB |
