```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **266.143 μs** |  **4.4840 μs** |  **2.3452 μs** | **35.09** |    **0.37** |       **-** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   256.573 μs |  4.1062 μs |  2.4436 μs | 33.83 |    0.38 |       - |      - |  17.38 KB |        2.25 |
| NativeSingle      | TaLib(...)lusDI [22] | 1000  |     7.584 μs |  0.0873 μs |  0.0520 μs |  1.00 |    0.01 |  0.3052 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 1000  |    14.220 μs |  1.1490 μs |  0.6837 μs |  1.88 |    0.09 |  1.2207 |      - |  27.24 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **2,713.771 μs** | **23.0200 μs** | **12.0399 μs** | **30.89** |    **0.23** | **15.6250** |      **-** | **627.96 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,616.214 μs | 48.1535 μs | 25.1852 μs | 29.78 |    0.33 |       - |      - | 158.14 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDI [22] | 10000 |    87.864 μs |  1.1034 μs |  0.5771 μs |  1.00 |    0.01 |  2.9297 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 10000 |   171.361 μs | 12.5071 μs |  8.2727 μs |  1.95 |    0.09 | 11.7188 | 2.9297 | 273.34 KB |        3.50 |
