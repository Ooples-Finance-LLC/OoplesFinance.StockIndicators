```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **265.3 μs** |  **3.65 μs** |  **2.17 μs** |       **-** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   256.0 μs |  2.41 μs |  1.60 μs |       - |   17.4 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **2,706.7 μs** | **30.63 μs** | **20.26 μs** | **15.6250** | **627.96 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,622.7 μs | 81.67 μs | 48.60 μs |       - | 158.12 KB |
