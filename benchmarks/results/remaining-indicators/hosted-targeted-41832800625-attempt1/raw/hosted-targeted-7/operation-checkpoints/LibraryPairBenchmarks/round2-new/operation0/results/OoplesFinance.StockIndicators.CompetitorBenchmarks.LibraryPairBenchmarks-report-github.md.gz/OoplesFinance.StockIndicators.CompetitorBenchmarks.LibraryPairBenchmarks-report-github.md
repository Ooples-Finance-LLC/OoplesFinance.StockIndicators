```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDI [22]** |   **413.76 μs** | **69.190 μs** | **41.174 μs** |  **1.01** |    **0.13** |  **105.67 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDI [22] |    22.36 μs |  3.319 μs |  1.736 μs |  0.05 |    0.01 |   32.73 KB |        0.31 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDI [22]** | **3,173.82 μs** | **49.988 μs** | **29.747 μs** |  **1.00** |    **0.01** | **1037.01 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDI [22] |   183.26 μs | 10.379 μs |  5.428 μs |  0.06 |    0.00 |  330.92 KB |        0.32 |
