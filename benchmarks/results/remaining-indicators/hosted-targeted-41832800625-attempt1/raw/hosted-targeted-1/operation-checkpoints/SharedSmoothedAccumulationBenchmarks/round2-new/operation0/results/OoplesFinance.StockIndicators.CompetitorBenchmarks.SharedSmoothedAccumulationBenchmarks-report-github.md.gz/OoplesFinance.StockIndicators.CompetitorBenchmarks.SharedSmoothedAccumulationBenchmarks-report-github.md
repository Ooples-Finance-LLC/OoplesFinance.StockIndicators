```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio  | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|-------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **322.764 μs** |  **2.2927 μs** |  **1.3643 μs** | **104.51** |    **1.39** |       **-** |      **-** |  **73.52 KB** |        **9.42** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   329.383 μs |  1.5881 μs |  0.8306 μs | 106.66 |    1.38 |       - |      - |  25.92 KB |        3.32 |
| NativeSingle      | TaLib(...)AdOsc [21] | 1000  |     3.089 μs |  0.0704 μs |  0.0419 μs |   1.00 |    0.02 |  0.4578 |      - |    7.8 KB |        1.00 |
| NativeParallel    | TaLib(...)AdOsc [21] | 1000  |     7.668 μs |  0.1862 μs |  0.1108 μs |   2.48 |    0.05 |  1.8921 | 0.0610 |  27.56 KB |        3.53 |
|                   |                      |       |              |            |            |        |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **3,274.864 μs** | **18.9227 μs** |  **9.8969 μs** | **110.67** |    **1.19** | **31.2500** |      **-** | **706.93 KB** |        **9.05** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 3,237.877 μs | 80.4584 μs | 53.2182 μs | 109.42 |    2.06 |       - |      - |  237.1 KB |        3.04 |
| NativeSingle      | TaLib(...)AdOsc [21] | 10000 |    29.593 μs |  0.6256 μs |  0.3272 μs |   1.00 |    0.01 |  4.6387 |      - |  78.12 KB |        1.00 |
| NativeParallel    | TaLib(...)AdOsc [21] | 10000 |    68.382 μs |  6.3901 μs |  4.2267 μs |   2.31 |    0.14 | 18.0664 | 4.3945 | 273.66 KB |        3.50 |
