```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **481.8 μs** |  **2.87 μs** |  **1.90 μs** |       **-** |  **73.57 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   465.1 μs |  2.00 μs |  1.05 μs |       - |  25.93 KB |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **4,744.7 μs** | **34.38 μs** | **20.46 μs** | **31.2500** | **706.93 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 4,721.7 μs | 16.40 μs |  8.57 μs |       - | 237.09 KB |
