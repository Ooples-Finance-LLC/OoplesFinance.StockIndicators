```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **466.7 μs** |  **3.73 μs** |  **2.22 μs** |       **-** |  **73.54 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   463.5 μs |  3.15 μs |  2.09 μs |       - |  25.93 KB |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **4,598.2 μs** | **18.66 μs** |  **9.76 μs** | **31.2500** |  **706.9 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 4,647.8 μs | 39.42 μs | 26.07 μs |       - |  237.1 KB |
