```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean         | Error       | StdDev      | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |-------------:|------------:|------------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)AdOsc [21]** |   **473.780 μs** |  **17.7713 μs** |  **11.7546 μs** |  **1.00** |    **0.03** | **209.08 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)AdOsc [21] |     8.988 μs |   0.9279 μs |   0.4853 μs |  0.02 |    0.00 |   37.3 KB |        0.18 |
|            |       |                      |              |             |             |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)AdOsc [21]** | **4,451.600 μs** | **260.2373 μs** | **172.1309 μs** |  **1.00** |    **0.05** | **2054.2 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)AdOsc [21] |    63.575 μs |   5.5506 μs |   2.9031 μs |  0.01 |    0.00 | 330.86 KB |        0.16 |
