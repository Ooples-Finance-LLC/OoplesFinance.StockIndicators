```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **135.350 μs** |  **4.9754 μs** |  **2.6022 μs** | **14.65** |    **0.35** |  **3.9063** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   116.455 μs |  0.6457 μs |  0.3377 μs | 12.61 |    0.21 |  0.9766 |      - |  17.39 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDM [23] | 1000  |     9.239 μs |  0.2384 μs |  0.1577 μs |  1.00 |    0.02 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 1000  |    12.544 μs |  0.9814 μs |  0.6491 μs |  1.36 |    0.07 |  1.8311 |      - |  27.23 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,289.812 μs** | **10.3404 μs** |  **6.1534 μs** | **14.01** |    **0.09** | **31.2500** | **7.8125** | **627.89 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 1,314.796 μs | 39.5231 μs | 26.1421 μs | 14.29 |    0.28 |  7.8125 |      - | 158.07 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDM [23] | 10000 |    92.033 μs |  0.6250 μs |  0.4134 μs |  1.00 |    0.01 |  4.3945 |      - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 10000 |   135.659 μs |  4.7072 μs |  3.1135 μs |  1.47 |    0.03 | 17.5781 | 4.8828 | 273.33 KB |        3.50 |
