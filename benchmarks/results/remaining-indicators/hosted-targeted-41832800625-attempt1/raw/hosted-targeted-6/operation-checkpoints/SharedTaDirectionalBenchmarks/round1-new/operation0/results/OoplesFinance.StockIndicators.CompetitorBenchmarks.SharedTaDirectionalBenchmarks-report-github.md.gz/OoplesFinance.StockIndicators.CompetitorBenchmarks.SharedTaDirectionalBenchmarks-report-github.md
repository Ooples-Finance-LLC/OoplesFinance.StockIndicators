```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error   | StdDev  | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |-----------:|--------:|--------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **121.7 μs** | **1.42 μs** | **0.74 μs** |  **3.9063** |      **-** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   119.5 μs | 0.95 μs | 0.56 μs |  0.9766 |      - |  17.39 KB |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,269.9 μs** | **3.84 μs** | **2.54 μs** | **31.2500** | **7.8125** | **627.88 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 1,242.4 μs | 3.34 μs | 1.99 μs |  7.8125 |      - | 158.06 KB |
