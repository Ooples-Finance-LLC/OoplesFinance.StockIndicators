```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDM [23]** |   **198.64 μs** | **27.944 μs** | **18.483 μs** |  **1.01** |    **0.12** |  **105.67 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDM [23] |    15.89 μs |  1.382 μs |  0.723 μs |  0.08 |    0.01 |   40.59 KB |        0.38 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDM [23]** | **1,453.82 μs** | **10.887 μs** |  **6.478 μs** |  **1.00** |    **0.01** | **1037.01 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDM [23] |   146.21 μs | 17.672 μs | 11.689 μs |  0.10 |    0.01 |  328.01 KB |        0.32 |
