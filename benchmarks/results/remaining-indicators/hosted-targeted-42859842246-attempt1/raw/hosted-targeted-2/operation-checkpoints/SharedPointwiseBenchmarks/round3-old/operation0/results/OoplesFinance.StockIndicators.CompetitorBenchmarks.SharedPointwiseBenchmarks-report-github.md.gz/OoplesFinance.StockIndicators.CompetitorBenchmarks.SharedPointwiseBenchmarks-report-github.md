```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Sin**       |  **10.594 μs** | **0.2064 μs** | **0.1228 μs** |  **3.4180** |  **0.4883** |  **56.77 KB** |
| BuilderLatestOnly | 1000  | Sin       |   7.590 μs | 0.0877 μs | 0.0522 μs |  0.5493 |       - |   9.16 KB |
| **BuilderFull**       | **10000** | **Sin**       | **142.795 μs** | **8.8146 μs** | **5.8303 μs** | **33.2031** | **13.6719** | **549.76 KB** |
| BuilderLatestOnly | 10000 | Sin       | 124.953 μs | 2.2333 μs | 1.1680 μs |  3.9063 |       - |  79.92 KB |
