```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Sin**       |  **10.102 μs** | **0.4267 μs** | **0.2822 μs** |  **1.70** |    **0.05** |  **3.4180** |  **0.4883** |  **56.77 KB** |        **7.22** |
| BuilderLatestOnly | 1000  | Sin       |   7.454 μs | 0.2219 μs | 0.1320 μs |  1.25 |    0.03 |  0.5493 |       - |   9.16 KB |        1.16 |
| NativeSingle      | 1000  | Sin       |   5.954 μs | 0.1286 μs | 0.0765 μs |  1.00 |    0.02 |  0.4578 |       - |   7.87 KB |        1.00 |
| NativeParallel    | 1000  | Sin       |  88.682 μs | 1.1853 μs | 0.7840 μs | 14.90 |    0.22 |  0.4883 |       - |   8.14 KB |        1.03 |
|                   |       |           |            |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **10000** | **Sin**       |  **91.144 μs** | **3.4640 μs** | **2.2912 μs** |  **1.52** |    **0.04** | **33.2031** | **13.6719** | **549.32 KB** |        **7.03** |
| BuilderLatestOnly | 10000 | Sin       |  65.599 μs | 0.9746 μs | 0.5800 μs |  1.10 |    0.01 |  4.3945 |  0.4883 |  79.48 KB |        1.02 |
| NativeSingle      | 10000 | Sin       |  59.824 μs | 0.8747 μs | 0.5786 μs |  1.00 |    0.01 |  4.3945 |  0.4883 |  78.18 KB |        1.00 |
| NativeParallel    | 10000 | Sin       | 119.783 μs | 3.1433 μs | 1.8705 μs |  2.00 |    0.03 |  3.9063 |       - |  78.45 KB |        1.00 |
