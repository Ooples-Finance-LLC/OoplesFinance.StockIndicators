```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Sin** | **139.94 μs** | **20.643 μs** | **12.284 μs** |  **1.01** |    **0.11** |  **97.92 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Sin |  27.44 μs |  0.947 μs |  0.496 μs |  0.20 |    0.02 |  40.32 KB |        0.41 |
|            |       |                     |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Sin** | **326.23 μs** | **19.363 μs** | **11.522 μs** |  **1.00** |    **0.05** | **958.85 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Sin | 268.35 μs | 20.401 μs | 13.494 μs |  0.82 |    0.05 | 330.36 KB |        0.34 |
