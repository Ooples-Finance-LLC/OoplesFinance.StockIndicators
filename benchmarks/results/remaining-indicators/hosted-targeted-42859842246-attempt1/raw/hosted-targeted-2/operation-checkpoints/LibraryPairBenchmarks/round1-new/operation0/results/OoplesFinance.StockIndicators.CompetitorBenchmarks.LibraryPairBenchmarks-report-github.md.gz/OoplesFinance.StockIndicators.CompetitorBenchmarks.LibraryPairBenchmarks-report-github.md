```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId              | Mean     | Error    | StdDev  | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |-------------------- |---------:|---------:|--------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Sin** | **255.4 μs** |  **4.31 μs** | **2.25 μs** |  **1.00** |    **0.01** |  **97.92 KB** |        **1.00** |
|        |       |                     |          |          |         |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Sin** | **308.4 μs** | **16.05 μs** | **9.55 μs** |  **1.00** |    **0.04** | **958.85 KB** |        **1.00** |
