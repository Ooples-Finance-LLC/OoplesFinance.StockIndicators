```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Log10**     |  **13.136 μs** | **0.4743 μs** | **0.2822 μs** |  **1.86** |    **0.04** |  **3.4180** |  **0.4883** |  **56.77 KB** |        **7.22** |
| BuilderLatestOnly | 1000  | Log10     |   9.589 μs | 0.1524 μs | 0.0797 μs |  1.36 |    0.01 |  0.5493 |       - |   9.16 KB |        1.16 |
| NativeSingle      | 1000  | Log10     |   7.072 μs | 0.0783 μs | 0.0518 μs |  1.00 |    0.01 |  0.4272 |       - |   7.87 KB |        1.00 |
| NativeParallel    | 1000  | Log10     |  90.318 μs | 1.6021 μs | 1.0597 μs | 12.77 |    0.17 |  0.4883 |       - |   8.14 KB |        1.03 |
|                   |       |           |            |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **10000** | **Log10**     | **112.697 μs** | **1.2980 μs** | **0.7724 μs** |  **1.64** |    **0.03** | **33.2031** | **13.6719** | **549.32 KB** |        **7.03** |
| BuilderLatestOnly | 10000 | Log10     |  84.733 μs | 0.5703 μs | 0.2983 μs |  1.23 |    0.02 |  4.3945 |  0.4883 |  79.48 KB |        1.02 |
| NativeSingle      | 10000 | Log10     |  68.689 μs | 2.3427 μs | 1.3941 μs |  1.00 |    0.03 |  4.3945 |  0.4883 |  78.18 KB |        1.00 |
| NativeParallel    | 10000 | Log10     | 127.817 μs | 7.4671 μs | 4.9390 μs |  1.86 |    0.08 |  3.9063 |       - |  78.45 KB |        1.00 |
