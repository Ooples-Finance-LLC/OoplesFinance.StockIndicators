```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Log10**     |  **12.934 μs** | **0.6310 μs** | **0.3755 μs** |  **3.4180** |  **0.4883** |  **56.77 KB** |
| BuilderLatestOnly | 1000  | Log10     |   9.943 μs | 0.1229 μs | 0.0643 μs |  0.5493 |       - |   9.16 KB |
| **BuilderFull**       | **10000** | **Log10**     | **113.109 μs** | **2.0105 μs** | **1.3298 μs** | **33.2031** | **13.6719** | **549.31 KB** |
| BuilderLatestOnly | 10000 | Log10     |  85.880 μs | 0.7851 μs | 0.4672 μs |  3.9063 |       - |  79.48 KB |
