```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Log10**     |  **13.015 μs** | **1.1174 μs** | **0.5844 μs** |  **3.4180** |  **0.4883** |  **56.77 KB** |
| BuilderLatestOnly | 1000  | Log10     |   9.775 μs | 0.0999 μs | 0.0594 μs |  0.5493 |       - |   9.16 KB |
| **BuilderFull**       | **10000** | **Log10**     | **114.647 μs** | **4.8968 μs** | **3.2389 μs** | **33.2031** | **13.6719** | **549.32 KB** |
| BuilderLatestOnly | 10000 | Log10     |  86.218 μs | 0.9322 μs | 0.5548 μs |  3.9063 |       - |  79.48 KB |
