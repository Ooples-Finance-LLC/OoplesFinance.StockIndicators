```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Log10**     |  **13.102 μs** | **0.3557 μs** | **0.1861 μs** |  **3.4180** |  **0.4883** |  **56.77 KB** |
| BuilderLatestOnly | 1000  | Log10     |   9.637 μs | 0.0983 μs | 0.0514 μs |  0.5493 |       - |   9.16 KB |
| **BuilderFull**       | **10000** | **Log10**     | **113.099 μs** | **1.9258 μs** | **1.0073 μs** | **33.2031** | **13.6719** | **549.32 KB** |
| BuilderLatestOnly | 10000 | Log10     |  84.887 μs | 0.8637 μs | 0.5713 μs |  4.3945 |  0.4883 |  79.48 KB |
