```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Log10 [21]** | **270.80 μs** | **38.647 μs** | **25.563 μs** |  **1.01** |    **0.12** |  **97.92 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Log10 [21] |  21.01 μs |  0.564 μs |  0.295 μs |  0.08 |    0.01 |  40.32 KB |        0.41 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Log10 [21]** | **298.08 μs** | **26.392 μs** | **15.705 μs** |  **1.00** |    **0.07** | **959.51 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Log10 [21] | 193.72 μs | 16.402 μs | 10.849 μs |  0.65 |    0.05 | 331.02 KB |        0.34 |
