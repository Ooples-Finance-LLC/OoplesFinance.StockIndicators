```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ln** | **134.78 μs** | **12.050 μs** | **7.171 μs** |  **1.00** |    **0.07** |  **97.92 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ln |  10.14 μs |  1.197 μs | 0.713 μs |  0.08 |    0.01 |  36.34 KB |        0.37 |
|            |       |                    |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ln** | **162.36 μs** |  **5.517 μs** | **3.283 μs** |  **1.00** |    **0.03** | **959.51 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ln |  91.30 μs | 14.447 μs | 9.556 μs |  0.56 |    0.06 | 328.02 KB |        0.34 |
