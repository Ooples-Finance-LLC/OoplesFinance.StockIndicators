```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Ln**        |   **7.217 μs** | **0.3375 μs** | **0.2232 μs** |  **1.85** |    **0.08** |  **3.4180** |  **0.4883** |  **56.77 KB** |        **7.22** |
| BuilderLatestOnly | 1000  | Ln        |   5.286 μs | 0.2943 μs | 0.1946 μs |  1.36 |    0.06 |  0.5493 |       - |   9.16 KB |        1.16 |
| NativeSingle      | 1000  | Ln        |   3.902 μs | 0.1878 μs | 0.1242 μs |  1.00 |    0.04 |  0.4578 |       - |   7.87 KB |        1.00 |
| NativeParallel    | 1000  | Ln        |  92.897 μs | 1.8143 μs | 1.0797 μs | 23.83 |    0.78 |  0.4883 |       - |   8.14 KB |        1.03 |
|                   |       |           |            |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **10000** | **Ln**        |  **61.007 μs** | **1.5680 μs** | **1.0371 μs** |  **1.70** |    **0.06** | **33.2031** | **13.6719** | **549.31 KB** |        **7.03** |
| BuilderLatestOnly | 10000 | Ln        |  44.920 μs | 2.5109 μs | 1.4942 μs |  1.25 |    0.05 |  4.6387 |  0.7324 |  79.47 KB |        1.02 |
| NativeSingle      | 10000 | Ln        |  35.919 μs | 1.7234 μs | 1.1399 μs |  1.00 |    0.04 |  4.6387 |  0.7324 |  78.18 KB |        1.00 |
| NativeParallel    | 10000 | Ln        | 112.266 μs | 4.5374 μs | 3.0012 μs |  3.13 |    0.12 |  3.9063 |       - |  78.45 KB |        1.00 |
