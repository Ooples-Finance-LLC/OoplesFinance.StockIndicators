```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------- |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Ln**        |  **6.691 μs** | **0.3881 μs** | **0.2567 μs** |  **3.4180** |  **0.4883** |  **56.77 KB** |
| BuilderLatestOnly | 1000  | Ln        |  5.254 μs | 0.3632 μs | 0.2402 μs |  0.5493 |       - |   9.16 KB |
| **BuilderFull**       | **10000** | **Ln**        | **59.185 μs** | **2.0599 μs** | **1.3625 μs** | **33.2031** | **13.6719** | **549.31 KB** |
| BuilderLatestOnly | 10000 | Ln        | 44.428 μs | 1.4056 μs | 0.9297 μs |  4.6387 |  0.7324 |  79.47 KB |
