```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Cos**       |  **11.019 μs** | **0.5072 μs** | **0.2653 μs** |  **3.4180** |  **0.4883** |  **56.77 KB** |
| BuilderLatestOnly | 1000  | Cos       |   7.920 μs | 0.2182 μs | 0.1141 μs |  0.5493 |       - |   9.16 KB |
| **BuilderFull**       | **10000** | **Cos**       | **146.568 μs** | **7.0528 μs** | **4.6650 μs** | **33.2031** | **13.6719** | **549.76 KB** |
| BuilderLatestOnly | 10000 | Cos       | 128.250 μs | 4.8345 μs | 2.8770 μs |  3.9063 |       - |  79.92 KB |
