```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------- |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Cos**       | **10.724 μs** | **0.5015 μs** | **0.3317 μs** |  **3.4180** |  **0.4883** |  **56.74 KB** |
| BuilderLatestOnly | 1000  | Cos       |  7.681 μs | 0.1110 μs | 0.0661 μs |  0.5493 |       - |   9.16 KB |
| **BuilderFull**       | **10000** | **Cos**       | **96.483 μs** | **1.0015 μs** | **0.6624 μs** | **33.2031** | **13.6719** | **549.29 KB** |
| BuilderLatestOnly | 10000 | Cos       | 70.746 μs | 1.2409 μs | 0.6490 μs |  4.3945 |  0.4883 |  79.48 KB |
