```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Cos**       |  **10.878 μs** | **0.6229 μs** | **0.3707 μs** |  **1.68** |    **0.06** |  **3.4180** |  **0.4883** |  **56.77 KB** |        **7.22** |
| BuilderLatestOnly | 1000  | Cos       |   7.606 μs | 0.1392 μs | 0.0921 μs |  1.18 |    0.02 |  0.5493 |       - |   9.16 KB |        1.16 |
| NativeSingle      | 1000  | Cos       |   6.459 μs | 0.2114 μs | 0.1106 μs |  1.00 |    0.02 |  0.4272 |       - |   7.87 KB |        1.00 |
| NativeParallel    | 1000  | Cos       |  89.551 μs | 1.2445 μs | 0.8232 μs | 13.87 |    0.25 |  0.4883 |       - |   8.14 KB |        1.03 |
|                   |       |           |            |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **10000** | **Cos**       |  **96.408 μs** | **1.4239 μs** | **0.7447 μs** |  **1.48** |    **0.03** | **33.2031** | **13.6719** | **549.31 KB** |        **7.03** |
| BuilderLatestOnly | 10000 | Cos       |  70.816 μs | 1.9259 μs | 1.1461 μs |  1.08 |    0.03 |  4.3945 |  0.4883 |  79.48 KB |        1.02 |
| NativeSingle      | 10000 | Cos       |  65.343 μs | 1.9675 μs | 1.3013 μs |  1.00 |    0.03 |  4.3945 |  0.4883 |  78.18 KB |        1.00 |
| NativeParallel    | 10000 | Cos       | 121.741 μs | 2.0581 μs | 1.0764 μs |  1.86 |    0.04 |  3.9063 |       - |  78.45 KB |        1.00 |
