```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Cos** | **134.67 μs** | **35.601 μs** | **21.186 μs** |  **1.02** |    **0.20** |  **97.92 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Cos |  27.46 μs |  1.266 μs |  0.754 μs |  0.21 |    0.03 |  40.65 KB |        0.42 |
|            |       |                     |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Cos** | **320.88 μs** | **15.380 μs** |  **9.152 μs** |  **1.00** |    **0.04** | **959.18 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Cos | 252.21 μs | 22.103 μs | 14.620 μs |  0.79 |    0.05 | 330.97 KB |        0.35 |
