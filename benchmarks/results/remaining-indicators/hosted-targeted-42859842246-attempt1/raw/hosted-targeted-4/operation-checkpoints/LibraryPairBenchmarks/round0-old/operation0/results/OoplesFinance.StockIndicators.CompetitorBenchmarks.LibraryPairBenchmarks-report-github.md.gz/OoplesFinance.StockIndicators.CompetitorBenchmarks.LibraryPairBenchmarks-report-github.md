```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId              | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |-------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Tan** |  **61.99 μs** |  **9.609 μs** |  **5.718 μs** |  **1.01** |    **0.13** |  **97.86 KB** |        **1.00** |
|        |       |                     |           |           |           |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Tan** | **337.31 μs** | **45.230 μs** | **26.916 μs** |  **1.01** |    **0.10** | **959.18 KB** |        **1.00** |
