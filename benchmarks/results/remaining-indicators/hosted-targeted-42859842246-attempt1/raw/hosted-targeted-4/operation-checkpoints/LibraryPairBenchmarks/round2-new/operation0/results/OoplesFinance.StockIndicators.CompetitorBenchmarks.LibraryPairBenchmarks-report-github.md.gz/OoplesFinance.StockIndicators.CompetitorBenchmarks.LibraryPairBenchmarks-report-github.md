```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Tan** | **128.65 μs** | **15.525 μs** |  **8.120 μs** |  **1.00** |    **0.08** |   **97.9 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Tan |  29.63 μs |  0.656 μs |  0.391 μs |  0.23 |    0.01 |   40.6 KB |        0.41 |
|            |       |                     |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Tan** | **347.20 μs** | **25.251 μs** | **15.027 μs** |  **1.00** |    **0.06** | **959.18 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Tan | 285.02 μs | 15.279 μs |  9.092 μs |  0.82 |    0.04 | 330.97 KB |        0.35 |
