```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------- |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Tan**       |  **13.35 μs** | **0.632 μs** | **0.376 μs** |  **3.4180** |  **0.4883** |  **56.77 KB** |
| BuilderLatestOnly | 1000  | Tan       |  10.26 μs | 0.086 μs | 0.045 μs |  0.5493 |       - |   9.16 KB |
| **BuilderFull**       | **10000** | **Tan**       | **156.12 μs** | **6.144 μs** | **4.064 μs** | **33.2031** | **13.6719** | **549.76 KB** |
| BuilderLatestOnly | 10000 | Tan       | 138.10 μs | 7.261 μs | 4.803 μs |  3.9063 |       - |  79.92 KB |
