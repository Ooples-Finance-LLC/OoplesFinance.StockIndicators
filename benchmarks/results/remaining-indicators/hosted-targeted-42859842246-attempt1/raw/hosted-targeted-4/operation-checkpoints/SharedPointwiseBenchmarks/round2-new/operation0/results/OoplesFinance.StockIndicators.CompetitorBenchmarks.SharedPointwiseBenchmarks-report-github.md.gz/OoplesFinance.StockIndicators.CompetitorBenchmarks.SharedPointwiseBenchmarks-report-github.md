```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Tan**       |  **12.878 μs** | **0.1688 μs** | **0.1004 μs** |  **1.65** |    **0.01** |  **3.4180** |  **0.4883** |  **56.77 KB** |        **7.22** |
| BuilderLatestOnly | 1000  | Tan       |  10.011 μs | 0.1023 μs | 0.0535 μs |  1.28 |    0.01 |  0.5493 |       - |   9.16 KB |        1.16 |
| NativeSingle      | 1000  | Tan       |   7.822 μs | 0.0542 μs | 0.0323 μs |  1.00 |    0.01 |  0.3662 |       - |   7.87 KB |        1.00 |
| NativeParallel    | 1000  | Tan       |  89.446 μs | 1.9999 μs | 1.3228 μs | 11.43 |    0.17 |  0.4883 |       - |   8.14 KB |        1.03 |
|                   |       |           |            |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **10000** | **Tan**       | **126.152 μs** | **0.9347 μs** | **0.4889 μs** |  **1.51** |    **0.02** | **33.2031** | **13.6719** | **549.32 KB** |        **7.03** |
| BuilderLatestOnly | 10000 | Tan       |  99.595 μs | 1.5148 μs | 1.0019 μs |  1.19 |    0.02 |  3.9063 |       - |  79.48 KB |        1.02 |
| NativeSingle      | 10000 | Tan       |  83.775 μs | 1.9506 μs | 1.2902 μs |  1.00 |    0.02 |  3.9063 |       - |  78.19 KB |        1.00 |
| NativeParallel    | 10000 | Tan       | 126.104 μs | 2.1491 μs | 1.1240 μs |  1.51 |    0.03 |  3.9063 |       - |  78.45 KB |        1.00 |
