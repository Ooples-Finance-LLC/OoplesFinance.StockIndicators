```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error   | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|--------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **245.3 μs** | **2.40 μs** | **1.43 μs** |       **-** |       **-** |  **89.21 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   254.2 μs | 4.70 μs | 3.11 μs |  1.9531 |       - |  41.59 KB |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **2,788.2 μs** | **5.32 μs** | **3.17 μs** | **46.8750** | **15.6250** | **863.08 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 2,795.3 μs | 5.26 μs | 2.75 μs | 15.6250 |       - | 393.29 KB |
