```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **235.7 μs** |  **2.25 μs** |  **1.34 μs** |       **-** |       **-** |   **89.2 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   244.4 μs |  2.32 μs |  1.53 μs |  1.9531 |       - |   41.6 KB |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **2,665.5 μs** | **25.73 μs** | **15.31 μs** | **46.8750** | **15.6250** | **863.12 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 2,831.4 μs | 30.62 μs | 20.25 μs | 15.6250 |       - | 393.26 KB |
