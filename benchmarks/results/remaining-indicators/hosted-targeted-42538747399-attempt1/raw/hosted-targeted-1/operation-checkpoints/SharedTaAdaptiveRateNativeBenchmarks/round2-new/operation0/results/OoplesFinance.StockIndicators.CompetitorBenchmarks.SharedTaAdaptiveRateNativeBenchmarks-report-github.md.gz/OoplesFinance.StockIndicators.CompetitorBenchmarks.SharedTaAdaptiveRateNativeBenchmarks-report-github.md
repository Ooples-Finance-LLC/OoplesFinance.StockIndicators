```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **174.513 μs** |  **3.1088 μs** |  **1.6259 μs** | **19.36** |    **0.19** |       **-** |       **-** |  **89.09 KB** |        **5.75** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   184.459 μs | 27.8089 μs | 18.3938 μs | 20.46 |    1.95 |  1.9531 |       - |  41.44 KB |        2.68 |
| NativeSingle      | TaLib.Functions.Trix | 1000  |     9.014 μs |  0.0768 μs |  0.0402 μs |  1.00 |    0.01 |  0.9155 |       - |  15.48 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Trix | 1000  |    86.579 μs |  1.9190 μs |  1.2693 μs |  9.60 |    0.14 |  3.4180 |       - |  47.61 KB |        3.07 |
|                   |                      |       |              |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **2,035.701 μs** |  **8.4951 μs** |  **5.0553 μs** | **21.88** |    **0.12** | **46.8750** | **15.6250** | **862.91 KB** |        **5.53** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 2,070.586 μs | 21.5414 μs | 12.8189 μs | 22.26 |    0.17 | 15.6250 |       - | 393.11 KB |        2.52 |
| NativeSingle      | TaLib.Functions.Trix | 10000 |    93.036 μs |  0.7515 μs |  0.4971 μs |  1.00 |    0.01 |  9.2773 |  1.4648 | 156.11 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Trix | 10000 |   187.083 μs |  6.6308 μs |  3.9459 μs |  2.01 |    0.04 | 30.2734 |  9.7656 | 469.48 KB |        3.01 |
