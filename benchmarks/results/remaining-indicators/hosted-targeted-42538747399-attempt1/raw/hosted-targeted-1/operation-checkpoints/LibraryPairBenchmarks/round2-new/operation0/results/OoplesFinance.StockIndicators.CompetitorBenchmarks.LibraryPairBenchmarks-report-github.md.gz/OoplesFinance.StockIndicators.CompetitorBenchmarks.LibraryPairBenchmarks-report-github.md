```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Trix** |   **257.70 μs** | **26.201 μs** | **15.592 μs** |  **1.00** |    **0.08** | **192.81 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Trix |    12.91 μs |  0.820 μs |  0.429 μs |  0.05 |    0.00 |  47.76 KB |        0.25 |
|            |       |                      |             |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Trix** | **2,509.78 μs** | **13.453 μs** |  **8.006 μs** |  **1.00** |    **0.00** | **1893.7 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Trix |   113.76 μs |  4.229 μs |  2.212 μs |  0.05 |    0.00 | 408.81 KB |        0.22 |
