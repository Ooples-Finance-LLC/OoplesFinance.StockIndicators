```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId          | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetTrix** |   **326.48 μs** | **24.082 μs** | **15.929 μs** |  **1.00** |    **0.06** |  **210.91 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetTrix |    60.08 μs |  1.036 μs |  0.542 μs |  0.18 |    0.01 |  204.02 KB |        0.97 |
|            |       |                 |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetTrix** | **3,092.73 μs** | **21.787 μs** | **12.965 μs** |  **1.00** |    **0.01** | **2073.89 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetTrix |   607.61 μs | 12.242 μs |  6.403 μs |  0.20 |    0.00 |    1953 KB |        0.94 |
