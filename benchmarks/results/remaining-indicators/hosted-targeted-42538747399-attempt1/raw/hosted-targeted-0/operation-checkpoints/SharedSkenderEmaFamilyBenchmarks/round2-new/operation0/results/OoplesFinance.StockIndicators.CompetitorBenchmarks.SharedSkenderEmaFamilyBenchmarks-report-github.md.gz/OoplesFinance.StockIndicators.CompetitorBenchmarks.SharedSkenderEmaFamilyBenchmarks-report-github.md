```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **223.15 μs** |   **4.019 μs** |   **2.102 μs** |  **7.27** |    **0.07** |        **-** |        **-** |        **-** |   **89.09 KB** |        **0.73** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   217.64 μs |   1.470 μs |   0.875 μs |  7.09 |    0.04 |   1.9531 |        - |        - |   41.45 KB |        0.34 |
| NativeSingle      | Skender.GetTrix | 1000  |    30.70 μs |   0.252 μs |   0.150 μs |  1.00 |    0.01 |   7.3242 |   1.7090 |        - |  121.49 KB |        1.00 |
| NativeParallel    | Skender.GetTrix | 1000  |   131.68 μs |   5.187 μs |   3.431 μs |  4.29 |    0.11 |  20.5078 |   5.8594 |        - |  312.32 KB |        2.57 |
|                   |                 |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **2,324.60 μs** |  **21.102 μs** |  **12.558 μs** |  **4.52** |    **0.03** |  **46.8750** |  **15.6250** |        **-** |  **862.96 KB** |        **0.71** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 2,255.41 μs |  15.606 μs |   9.287 μs |  4.38 |    0.03 |  15.6250 |        - |        - |  393.13 KB |        0.32 |
| NativeSingle      | Skender.GetTrix | 10000 |   514.77 μs |   4.352 μs |   2.276 μs |  1.00 |    0.01 |  97.6563 |  97.6563 |  97.6563 | 1212.12 KB |        1.00 |
| NativeParallel    | Skender.GetTrix | 10000 | 1,712.46 μs | 304.098 μs | 201.142 μs |  3.33 |    0.37 | 296.8750 | 234.3750 | 156.2500 | 3108.91 KB |        2.56 |
