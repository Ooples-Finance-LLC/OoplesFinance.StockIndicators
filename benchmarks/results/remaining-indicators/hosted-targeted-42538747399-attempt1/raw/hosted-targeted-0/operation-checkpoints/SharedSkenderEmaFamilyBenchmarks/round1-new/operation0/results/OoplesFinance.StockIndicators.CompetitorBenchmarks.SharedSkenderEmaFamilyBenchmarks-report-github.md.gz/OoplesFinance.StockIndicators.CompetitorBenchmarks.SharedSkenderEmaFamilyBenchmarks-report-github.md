```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **233.7 μs** |  **0.92 μs** |  **0.48 μs** |       **-** |       **-** |  **89.09 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   232.7 μs |  0.95 μs |  0.56 μs |  1.9531 |       - |  41.45 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **2,497.4 μs** | **21.17 μs** | **12.60 μs** | **46.8750** | **15.6250** | **862.96 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 2,378.1 μs | 10.27 μs |  6.11 μs | 15.6250 |       - | 393.13 KB |
