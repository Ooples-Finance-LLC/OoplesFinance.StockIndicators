```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Log10**     |   **6.517 μs** | **0.1114 μs** | **0.0583 μs** |  **1.69** |    **0.02** |  **3.4180** |  **0.4883** |  **56.74 KB** |        **7.21** |
| BuilderLatestOnly | 1000  | Log10     |   5.167 μs | 0.0748 μs | 0.0445 μs |  1.34 |    0.02 |  0.5493 |       - |   9.16 KB |        1.16 |
| NativeSingle      | 1000  | Log10     |   3.853 μs | 0.0631 μs | 0.0417 μs |  1.00 |    0.01 |  0.4578 |       - |   7.87 KB |        1.00 |
| NativeParallel    | 1000  | Log10     |  94.589 μs | 1.9069 μs | 1.2613 μs | 24.55 |    0.40 |  0.4883 |       - |   8.14 KB |        1.03 |
|                   |       |           |            |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **10000** | **Log10**     |  **61.645 μs** | **1.8275 μs** | **1.2088 μs** |  **1.70** |    **0.04** | **33.2031** | **13.6719** | **549.28 KB** |        **7.03** |
| BuilderLatestOnly | 10000 | Log10     |  45.344 μs | 2.5686 μs | 1.6990 μs |  1.25 |    0.05 |  4.6387 |  0.7324 |  79.47 KB |        1.02 |
| NativeSingle      | 10000 | Log10     |  36.295 μs | 1.1573 μs | 0.6053 μs |  1.00 |    0.02 |  4.6387 |  0.7324 |  78.18 KB |        1.00 |
| NativeParallel    | 10000 | Log10     | 111.667 μs | 3.8371 μs | 2.5380 μs |  3.08 |    0.08 |  3.9063 |       - |  78.45 KB |        1.00 |
