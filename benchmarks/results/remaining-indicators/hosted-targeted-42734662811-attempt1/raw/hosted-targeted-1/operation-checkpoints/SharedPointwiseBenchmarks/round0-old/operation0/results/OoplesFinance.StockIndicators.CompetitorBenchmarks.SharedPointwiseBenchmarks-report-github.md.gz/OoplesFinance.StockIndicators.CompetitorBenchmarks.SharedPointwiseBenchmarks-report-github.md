```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Log10**     |   **6.960 μs** | **0.3426 μs** | **0.1792 μs** |  **3.4180** |  **0.4883** |  **56.73 KB** |
| BuilderLatestOnly | 1000  | Log10     |   5.382 μs | 0.2282 μs | 0.1358 μs |  0.5493 |       - |   9.16 KB |
| **BuilderFull**       | **10000** | **Log10**     | **103.367 μs** | **5.7304 μs** | **3.7903 μs** | **33.2031** | **13.6719** | **549.72 KB** |
| BuilderLatestOnly | 10000 | Log10     |  91.078 μs | 3.8404 μs | 2.5402 μs |  4.3945 |  0.4883 |  79.91 KB |
