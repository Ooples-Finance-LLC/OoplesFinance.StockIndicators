```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Log10 [21]** |  **70.662 μs** | **1.5995 μs** | **0.8366 μs** |  **1.00** |    **0.02** |  **97.92 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Log10 [21] |   9.706 μs | 0.3476 μs | 0.2068 μs |  0.14 |    0.00 |  35.07 KB |        0.36 |
|            |       |                      |            |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Log10 [21]** | **182.062 μs** | **3.4641 μs** | **1.8118 μs** |  **1.00** |    **0.01** | **953.63 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Log10 [21] |  85.638 μs | 0.6127 μs | 0.3204 μs |  0.47 |    0.00 | 324.83 KB |        0.34 |
