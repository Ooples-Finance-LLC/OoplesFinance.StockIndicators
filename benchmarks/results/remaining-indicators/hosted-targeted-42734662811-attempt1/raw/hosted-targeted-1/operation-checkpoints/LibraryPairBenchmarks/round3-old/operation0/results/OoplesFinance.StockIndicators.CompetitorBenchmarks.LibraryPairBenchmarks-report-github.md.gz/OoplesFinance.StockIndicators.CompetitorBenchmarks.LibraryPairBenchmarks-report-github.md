```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean     | Error    | StdDev  | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |---------:|---------:|--------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)Log10 [21]** | **146.7 μs** | **14.71 μs** | **9.73 μs** |  **1.00** |    **0.09** |  **97.92 KB** |        **1.00** |
|        |       |                      |          |          |         |       |         |           |             |
| **Ooples** | **10000** | **TaLib(...)Log10 [21]** | **158.2 μs** |  **8.09 μs** | **4.81 μs** |  **1.00** |    **0.04** | **959.23 KB** |        **1.00** |
