```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId             | Mean     | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |------------------- |---------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Ln** | **213.5 μs** | **25.38 μs** | **16.79 μs** |  **1.01** |    **0.10** |  **97.92 KB** |        **1.00** |
|        |       |                    |          |          |          |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Ln** | **215.7 μs** | **11.73 μs** |  **6.98 μs** |  **1.00** |    **0.04** | **959.48 KB** |        **1.00** |
