```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |------------------- |----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ln** | **205.68 μs** | **12.870 μs** | **7.659 μs** |  **1.00** |    **0.05** |  **97.92 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ln |  19.51 μs |  3.683 μs | 1.926 μs |  0.09 |    0.01 |  40.98 KB |        0.42 |
|            |       |                    |           |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ln** | **247.07 μs** | **11.718 μs** | **6.973 μs** |  **1.00** |    **0.04** |  **957.2 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ln | 148.55 μs | 13.073 μs | 6.837 μs |  0.60 |    0.03 | 331.02 KB |        0.35 |
