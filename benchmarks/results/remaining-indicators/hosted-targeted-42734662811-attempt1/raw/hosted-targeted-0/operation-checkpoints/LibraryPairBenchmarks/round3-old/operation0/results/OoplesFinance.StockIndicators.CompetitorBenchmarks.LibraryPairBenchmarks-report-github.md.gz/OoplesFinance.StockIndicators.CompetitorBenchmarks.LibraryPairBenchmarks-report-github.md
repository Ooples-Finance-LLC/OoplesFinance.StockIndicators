```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId             | Mean     | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |------------------- |---------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Ln** | **204.6 μs** | **24.81 μs** | **16.41 μs** |  **1.01** |    **0.10** |  **97.92 KB** |        **1.00** |
|        |       |                    |          |          |          |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Ln** | **221.1 μs** | **38.54 μs** | **22.93 μs** |  **1.01** |    **0.13** | **959.51 KB** |        **1.00** |
