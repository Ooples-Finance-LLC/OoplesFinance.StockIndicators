```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Ln**        |   **9.597 μs** | **0.1687 μs** | **0.0882 μs** |  **1.83** |    **0.02** |  **3.4180** |  **0.4883** |  **56.77 KB** |        **7.22** |
| BuilderLatestOnly | 1000  | Ln        |   7.159 μs | 0.0878 μs | 0.0522 μs |  1.36 |    0.01 |  0.5493 |       - |   9.16 KB |        1.16 |
| NativeSingle      | 1000  | Ln        |   5.253 μs | 0.0351 μs | 0.0209 μs |  1.00 |    0.01 |  0.4578 |       - |   7.87 KB |        1.00 |
| NativeParallel    | 1000  | Ln        |  78.331 μs | 0.8152 μs | 0.5392 μs | 14.91 |    0.11 |  0.4883 |       - |   8.14 KB |        1.03 |
|                   |       |           |            |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **10000** | **Ln**        |  **83.313 μs** | **0.5049 μs** | **0.2641 μs** |  **1.64** |    **0.01** | **33.2031** | **13.6719** | **549.32 KB** |        **7.03** |
| BuilderLatestOnly | 10000 | Ln        |  63.606 μs | 0.2981 μs | 0.1972 μs |  1.25 |    0.00 |  4.3945 |  0.4883 |  79.48 KB |        1.02 |
| NativeSingle      | 10000 | Ln        |  50.739 μs | 0.1648 μs | 0.0981 μs |  1.00 |    0.00 |  4.3945 |  0.4883 |  78.18 KB |        1.00 |
| NativeParallel    | 10000 | Ln        | 101.448 μs | 1.4579 μs | 0.7625 μs |  2.00 |    0.01 |  3.9063 |       - |  78.45 KB |        1.00 |
