```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------- |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Ln**        |  **9.776 μs** | **0.1739 μs** | **0.1035 μs** |  **3.4180** |  **0.4883** |  **56.77 KB** |
| BuilderLatestOnly | 1000  | Ln        |  7.177 μs | 0.0618 μs | 0.0368 μs |  0.5493 |       - |   9.16 KB |
| **BuilderFull**       | **10000** | **Ln**        | **84.798 μs** | **2.9957 μs** | **1.7827 μs** | **33.2031** | **13.6719** | **549.31 KB** |
| BuilderLatestOnly | 10000 | Ln        | 63.431 μs | 0.5073 μs | 0.3019 μs |  4.3945 |  0.4883 |  79.48 KB |
