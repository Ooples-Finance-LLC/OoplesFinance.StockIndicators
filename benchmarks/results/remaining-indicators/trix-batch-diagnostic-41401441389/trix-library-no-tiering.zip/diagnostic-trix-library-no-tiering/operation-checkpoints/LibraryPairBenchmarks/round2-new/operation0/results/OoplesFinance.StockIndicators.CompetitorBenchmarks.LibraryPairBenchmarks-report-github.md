```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon 6973P-C 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Trix** |   **466.1 μs** |  **28.92 μs** | **17.21 μs** |  **1.00** |    **0.05** |  **193.01 KB** |        **1.00** |
|        |       |                      |            |           |          |       |         |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Trix** | **4,454.2 μs** | **128.34 μs** | **84.89 μs** |  **1.00** |    **0.03** | **1897.45 KB** |        **1.00** |
