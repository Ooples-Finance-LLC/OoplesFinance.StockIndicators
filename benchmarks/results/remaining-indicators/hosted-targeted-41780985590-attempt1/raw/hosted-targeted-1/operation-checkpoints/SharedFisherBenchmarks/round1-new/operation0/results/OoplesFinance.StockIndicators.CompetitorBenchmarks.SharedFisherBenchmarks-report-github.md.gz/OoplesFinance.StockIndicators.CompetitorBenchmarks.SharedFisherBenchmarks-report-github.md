```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)sform [26]** | **1000**  |   **119.1 μs** |  **1.15 μs** | **0.68 μs** |  **3.9063** |       **-** |  **81.26 KB** |
| BuilderLatestOnly | Skend(...)sform [26] | 1000  |   116.2 μs |  1.40 μs | 0.73 μs |  1.9531 |       - |   33.7 KB |
| **BuilderFull**       | **Skend(...)sform [26]** | **10000** | **1,127.3 μs** | **13.39 μs** | **7.97 μs** | **46.8750** | **23.4375** |  **784.8 KB** |
| BuilderLatestOnly | Skend(...)sform [26] | 10000 | 1,085.0 μs |  5.92 μs | 3.52 μs | 15.6250 |  7.8125 | 315.01 KB |
