```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)sform [26]** | **1000**  |   **124.4 μs** |   **0.62 μs** |  **0.37 μs** |  **1.21** |    **0.01** |        **-** |        **-** |        **-** |   **81.34 KB** |        **0.67** |
| BuilderLatestOnly | Skend(...)sform [26] | 1000  |   116.3 μs |   0.96 μs |  0.63 μs |  1.13 |    0.01 |   1.9531 |        - |        - |    33.7 KB |        0.28 |
| NativeSingle      | Skend(...)sform [26] | 1000  |   103.2 μs |   0.59 μs |  0.39 μs |  1.00 |    0.01 |   6.8359 |   0.9766 |        - |  121.54 KB |        1.00 |
| NativeParallel    | Skend(...)sform [26] | 1000  |   156.9 μs |  11.91 μs |  7.88 μs |  1.52 |    0.07 |  19.5313 |   5.8594 |        - |  312.72 KB |        2.57 |
|                   |                      |       |            |           |          |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skend(...)sform [26]** | **10000** | **1,144.5 μs** |  **14.82 μs** |  **7.75 μs** |  **0.99** |    **0.02** |  **46.8750** |  **23.4375** |        **-** |  **784.85 KB** |        **0.65** |
| BuilderLatestOnly | Skend(...)sform [26] | 10000 | 1,106.1 μs |   9.19 μs |  5.47 μs |  0.95 |    0.02 |  15.6250 |   7.8125 |        - |  315.02 KB |        0.26 |
| NativeSingle      | Skend(...)sform [26] | 10000 | 1,162.0 μs |  31.81 μs | 18.93 μs |  1.00 |    0.02 | 140.6250 | 109.3750 |  85.9375 | 1212.14 KB |        1.00 |
| NativeParallel    | Skend(...)sform [26] | 10000 | 1,823.7 μs | 130.94 μs | 86.61 μs |  1.57 |    0.07 | 296.8750 | 234.3750 | 140.6250 | 3109.35 KB |        2.57 |
