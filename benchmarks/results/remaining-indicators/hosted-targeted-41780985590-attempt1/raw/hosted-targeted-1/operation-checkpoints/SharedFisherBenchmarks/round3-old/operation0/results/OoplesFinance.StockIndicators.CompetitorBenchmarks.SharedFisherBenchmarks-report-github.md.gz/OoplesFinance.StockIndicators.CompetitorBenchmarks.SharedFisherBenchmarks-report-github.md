```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)sform [26]** | **1000**  |   **176.4 μs** |  **1.35 μs** |  **0.80 μs** |  **3.9063** |       **-** |  **81.26 KB** |
| BuilderLatestOnly | Skend(...)sform [26] | 1000  |   173.1 μs |  4.62 μs |  3.05 μs |  1.9531 |       - |   33.7 KB |
| **BuilderFull**       | **Skend(...)sform [26]** | **10000** | **1,664.7 μs** |  **6.11 μs** |  **4.04 μs** | **46.8750** | **15.6250** | **784.87 KB** |
| BuilderLatestOnly | Skend(...)sform [26] | 10000 | 1,644.0 μs | 27.59 μs | 16.42 μs | 15.6250 |       - | 315.08 KB |
