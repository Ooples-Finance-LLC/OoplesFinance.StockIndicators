```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev   | Gen0     | Gen1     | Allocated  |
|------------------ |--------------------- |------ |------------:|----------:|---------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skend(...)lysis [22]** | **1000**  |   **157.79 μs** |  **2.013 μs** | **1.053 μs** |  **15.6250** |        **-** |  **160.51 KB** |
| BuilderLatestOnly | Skend(...)lysis [22] | 1000  |   152.56 μs |  2.177 μs | 1.295 μs |  13.6719 |   1.9531 |   112.9 KB |
| **BuilderFull**       | **Skend(...)lysis [22]** | **10000** | **1,521.95 μs** | **14.629 μs** | **9.676 μs** | **156.2500** | **101.5625** | **1288.96 KB** |
| BuilderLatestOnly | Skend(...)lysis [22] | 10000 | 1,481.75 μs | 11.540 μs | 7.633 μs |  93.7500 |  54.6875 |  819.11 KB |
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **1000**  |    **56.25 μs** |  **0.876 μs** | **0.521 μs** |  **10.7422** |   **1.4648** |   **89.32 KB** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 1000  |    50.82 μs |  2.036 μs | 1.347 μs |   5.3711 |        - |   41.44 KB |
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **10000** |   **477.55 μs** |  **3.402 μs** | **2.025 μs** |  **70.3125** |  **35.1563** |  **581.91 KB** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 10000 |   446.69 μs |  3.160 μs | 2.090 μs |  11.7188 |        - |  111.78 KB |
