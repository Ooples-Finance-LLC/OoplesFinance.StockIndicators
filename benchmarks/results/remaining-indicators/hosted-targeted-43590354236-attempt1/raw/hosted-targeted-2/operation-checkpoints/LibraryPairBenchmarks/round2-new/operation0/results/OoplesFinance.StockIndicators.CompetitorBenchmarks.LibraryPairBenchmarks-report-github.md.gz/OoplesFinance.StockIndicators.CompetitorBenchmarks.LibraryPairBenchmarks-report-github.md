```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)iStar [29]** | **103.52 μs** |  **28.810 μs** |  **17.145 μs** |  **1.02** |    **0.22** |  **73.12 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)iStar [29] |  62.83 μs |   0.681 μs |   0.406 μs |  0.62 |    0.09 |  19.63 KB |        0.27 |
|            |       |                      |           |            |            |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)iStar [29]** | **476.69 μs** | **197.480 μs** | **130.621 μs** |  **1.07** |    **0.41** | **661.69 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)iStar [29] | 636.82 μs |  32.996 μs |  19.635 μs |  1.43 |    0.38 | 125.09 KB |        0.19 |
