```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **MorningDojiStar** | **1000**  | **121.6 μs** |  **9.05 μs** |  **5.99 μs** |  **3.9063** |       **-** |  **71.74 KB** |
| BuilderLatestOnly | MorningDojiStar | 1000  | 113.4 μs |  1.57 μs |  0.82 μs |  0.9766 |       - |  23.86 KB |
| **BuilderFull**       | **MorningDojiStar** | **10000** | **506.7 μs** | **44.94 μs** | **29.72 μs** | **35.1563** | **11.7188** | **583.52 KB** |
| BuilderLatestOnly | MorningDojiStar | 10000 | 475.6 μs | 46.76 μs | 30.93 μs |  3.9063 |       - | 113.42 KB |
