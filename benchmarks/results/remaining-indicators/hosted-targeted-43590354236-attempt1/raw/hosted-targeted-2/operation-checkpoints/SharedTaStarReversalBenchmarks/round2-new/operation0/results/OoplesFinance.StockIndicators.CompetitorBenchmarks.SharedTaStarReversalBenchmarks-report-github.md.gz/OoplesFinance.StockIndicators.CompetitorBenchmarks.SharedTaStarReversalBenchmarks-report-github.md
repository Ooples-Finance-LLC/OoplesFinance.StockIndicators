```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |---------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **MorningDojiStar** | **1000**  | **118.89 μs** | **19.273 μs** | **12.748 μs** |  **2.33** |    **0.24** |  **3.9063** |       **-** |  **71.74 KB** |       **18.06** |
| BuilderLatestOnly | MorningDojiStar | 1000  | 107.23 μs |  1.303 μs |  0.682 μs |  2.10 |    0.01 |  0.9766 |       - |  23.86 KB |        6.01 |
| NativeSingle      | MorningDojiStar | 1000  |  51.06 μs |  0.148 μs |  0.078 μs |  1.00 |    0.00 |       - |       - |   3.97 KB |        1.00 |
| NativeParallel    | MorningDojiStar | 1000  | 103.83 μs |  6.570 μs |  4.346 μs |  2.03 |    0.08 |       - |       - |    8.4 KB |        2.11 |
|                   |                 |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **MorningDojiStar** | **10000** | **382.49 μs** | **19.751 μs** | **10.330 μs** |  **0.70** |    **0.03** | **35.1563** | **11.7188** | **583.52 KB** |       **14.90** |
| BuilderLatestOnly | MorningDojiStar | 10000 | 412.84 μs | 24.819 μs | 14.769 μs |  0.75 |    0.04 |  3.9063 |       - | 113.42 KB |        2.90 |
| NativeSingle      | MorningDojiStar | 10000 | 548.25 μs | 29.593 μs | 19.574 μs |  1.00 |    0.05 |       - |       - |  39.16 KB |        1.00 |
| NativeParallel    | MorningDojiStar | 10000 | 369.54 μs | 22.845 μs | 15.111 μs |  0.67 |    0.03 |  5.8594 |       - |   78.7 KB |        2.01 |
