```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **MorningDojiStar** | **1000**  | **128.2 μs** | **22.14 μs** | **14.64 μs** |  **3.9063** |       **-** |  **71.74 KB** |
| BuilderLatestOnly | MorningDojiStar | 1000  | 105.2 μs |  1.81 μs |  0.94 μs |  0.9766 |       - |  23.86 KB |
| **BuilderFull**       | **MorningDojiStar** | **10000** | **398.0 μs** | **20.12 μs** | **13.31 μs** | **35.1563** | **13.6719** | **583.51 KB** |
| BuilderLatestOnly | MorningDojiStar | 10000 | 392.0 μs | 22.24 μs | 14.71 μs |  5.8594 |       - |  113.4 KB |
