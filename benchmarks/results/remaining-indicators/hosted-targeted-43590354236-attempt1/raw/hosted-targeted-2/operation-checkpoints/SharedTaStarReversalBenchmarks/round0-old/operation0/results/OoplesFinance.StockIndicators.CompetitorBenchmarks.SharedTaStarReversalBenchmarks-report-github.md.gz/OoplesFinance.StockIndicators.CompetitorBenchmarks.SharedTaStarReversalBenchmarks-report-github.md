```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean     | Error    | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |---------:|---------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **MorningDojiStar** | **1000**  | **126.1 μs** | **12.11 μs** | **8.01 μs** |  **3.9063** |       **-** |  **71.71 KB** |
| BuilderLatestOnly | MorningDojiStar | 1000  | 115.9 μs |  3.57 μs | 1.87 μs |  0.9766 |       - |  23.86 KB |
| **BuilderFull**       | **MorningDojiStar** | **10000** | **481.7 μs** | **12.43 μs** | **6.50 μs** | **35.1563** | **11.7188** | **583.49 KB** |
| BuilderLatestOnly | MorningDojiStar | 10000 | 456.6 μs |  9.87 μs | 5.16 μs |  3.9063 |       - | 113.42 KB |
