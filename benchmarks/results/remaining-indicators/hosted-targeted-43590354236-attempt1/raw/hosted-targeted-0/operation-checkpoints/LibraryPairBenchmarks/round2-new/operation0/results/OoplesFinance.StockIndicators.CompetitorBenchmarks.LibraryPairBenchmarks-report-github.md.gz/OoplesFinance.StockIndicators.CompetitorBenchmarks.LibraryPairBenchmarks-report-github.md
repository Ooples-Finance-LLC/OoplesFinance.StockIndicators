```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)gStar [25]** | **218.84 μs** | **17.662 μs** | **11.683 μs** |  **1.00** |    **0.07** |  **73.63 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)gStar [25] |  63.24 μs |  1.076 μs |  0.563 μs |  0.29 |    0.01 |  16.67 KB |        0.23 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)gStar [25]** | **291.88 μs** | **11.640 μs** |  **6.088 μs** |  **1.00** |    **0.03** |  **688.3 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)gStar [25] | 611.77 μs | 22.578 μs | 14.934 μs |  2.10 |    0.06 | 123.45 KB |        0.18 |
