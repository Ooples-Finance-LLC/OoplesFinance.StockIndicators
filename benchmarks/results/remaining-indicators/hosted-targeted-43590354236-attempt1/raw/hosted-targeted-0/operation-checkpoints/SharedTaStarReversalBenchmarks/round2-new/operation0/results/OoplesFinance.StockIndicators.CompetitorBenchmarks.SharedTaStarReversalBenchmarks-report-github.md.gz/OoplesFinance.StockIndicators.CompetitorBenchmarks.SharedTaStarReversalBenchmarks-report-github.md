```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------ |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **MorningStar** | **1000**  | **103.10 μs** |  **4.637 μs** |  **2.759 μs** |  **1.88** |    **0.05** |  **3.9063** |       **-** |  **69.48 KB** |       **17.50** |
| BuilderLatestOnly | MorningStar | 1000  |  99.03 μs |  1.269 μs |  0.664 μs |  1.81 |    0.01 |  0.9766 |       - |   21.6 KB |        5.44 |
| NativeSingle      | MorningStar | 1000  |  54.81 μs |  0.138 μs |  0.072 μs |  1.00 |    0.00 |       - |       - |   3.97 KB |        1.00 |
| NativeParallel    | MorningStar | 1000  | 100.79 μs |  1.547 μs |  0.809 μs |  1.84 |    0.01 |       - |       - |    8.4 KB |        2.12 |
|                   |             |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **MorningStar** | **10000** | **340.79 μs** |  **6.418 μs** |  **3.357 μs** |  **0.65** |    **0.02** | **35.1563** | **15.6250** | **607.04 KB** |       **15.51** |
| BuilderLatestOnly | MorningStar | 10000 | 334.89 μs | 24.345 μs | 16.103 μs |  0.64 |    0.04 |  7.8125 |       - | 136.93 KB |        3.50 |
| NativeSingle      | MorningStar | 10000 | 524.23 μs | 29.670 μs | 19.625 μs |  1.00 |    0.05 |       - |       - |  39.15 KB |        1.00 |
| NativeParallel    | MorningStar | 10000 | 356.71 μs | 22.724 μs | 15.031 μs |  0.68 |    0.04 |  5.8594 |       - |  78.72 KB |        2.01 |
