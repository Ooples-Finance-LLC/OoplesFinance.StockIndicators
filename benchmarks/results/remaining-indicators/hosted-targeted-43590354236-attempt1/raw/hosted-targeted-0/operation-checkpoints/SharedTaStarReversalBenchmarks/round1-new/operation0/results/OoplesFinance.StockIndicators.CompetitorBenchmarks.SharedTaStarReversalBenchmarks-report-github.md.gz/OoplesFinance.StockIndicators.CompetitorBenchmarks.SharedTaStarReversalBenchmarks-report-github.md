```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------ |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **MorningStar** | **1000**  | **103.1 μs** |  **4.97 μs** |  **2.96 μs** |  **3.9063** |       **-** |  **69.48 KB** |
| BuilderLatestOnly | MorningStar | 1000  | 101.3 μs |  3.86 μs |  2.55 μs |  0.9766 |       - |   21.6 KB |
| **BuilderFull**       | **MorningStar** | **10000** | **356.1 μs** | **18.68 μs** | **11.11 μs** | **35.1563** | **15.6250** | **607.05 KB** |
| BuilderLatestOnly | MorningStar | 10000 | 342.9 μs | 34.50 μs | 22.82 μs |  7.8125 |       - | 136.93 KB |
