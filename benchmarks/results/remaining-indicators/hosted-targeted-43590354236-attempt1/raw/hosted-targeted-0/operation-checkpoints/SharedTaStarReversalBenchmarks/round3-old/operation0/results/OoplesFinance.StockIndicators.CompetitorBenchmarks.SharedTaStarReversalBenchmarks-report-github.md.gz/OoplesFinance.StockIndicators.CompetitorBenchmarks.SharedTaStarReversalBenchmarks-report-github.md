```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------ |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **MorningStar** | **1000**  | **107.9 μs** |  **7.64 μs** |  **5.05 μs** |  **3.9063** |       **-** |  **69.48 KB** |
| BuilderLatestOnly | MorningStar | 1000  | 102.0 μs |  1.78 μs |  0.93 μs |  0.9766 |       - |   21.6 KB |
| **BuilderFull**       | **MorningStar** | **10000** | **379.8 μs** |  **8.66 μs** |  **4.53 μs** | **35.1563** | **15.6250** | **607.05 KB** |
| BuilderLatestOnly | MorningStar | 10000 | 369.2 μs | 21.21 μs | 14.03 μs |  7.8125 |       - | 136.93 KB |
