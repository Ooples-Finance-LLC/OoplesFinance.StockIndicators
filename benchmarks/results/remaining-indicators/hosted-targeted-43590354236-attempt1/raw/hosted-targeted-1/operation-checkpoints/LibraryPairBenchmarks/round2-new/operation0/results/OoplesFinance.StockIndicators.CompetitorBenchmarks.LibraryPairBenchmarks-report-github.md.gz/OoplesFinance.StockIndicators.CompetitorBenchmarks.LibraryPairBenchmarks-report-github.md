```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error      | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|-----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)gStar [25]** |  **38.26 μs** |   **4.644 μs** |  **2.429 μs** |  **1.00** |    **0.08** |  **73.63 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)gStar [25] |  42.10 μs |   0.403 μs |  0.240 μs |  1.10 |    0.06 |  12.08 KB |        0.16 |
|            |       |                      |           |            |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)gStar [25]** | **297.99 μs** | **117.437 μs** | **77.677 μs** |  **1.07** |    **0.39** | **680.29 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)gStar [25] | 410.32 μs |   1.893 μs |  1.127 μs |  1.47 |    0.38 | 118.91 KB |        0.17 |
