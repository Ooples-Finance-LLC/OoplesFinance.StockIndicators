```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------ |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **EveningStar** | **1000**  | **117.4 μs** |  **3.66 μs** |  **2.42 μs** |  **3.9063** |       **-** |  **69.45 KB** |
| BuilderLatestOnly | EveningStar | 1000  | 115.9 μs |  3.66 μs |  2.42 μs |  0.9766 |       - |   21.6 KB |
| **BuilderFull**       | **EveningStar** | **10000** | **324.8 μs** | **19.90 μs** | **13.16 μs** | **35.1563** | **13.6719** | **602.31 KB** |
| BuilderLatestOnly | EveningStar | 10000 | 321.2 μs | 10.76 μs |  6.40 μs |  7.8125 |       - | 132.24 KB |
