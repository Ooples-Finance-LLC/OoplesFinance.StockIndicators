```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean     | Error    | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |------------ |------ |---------:|---------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **EveningStar** | **1000**  | **118.5 μs** |  **5.59 μs** | **3.70 μs** |  **3.9063** |       **-** |  **69.45 KB** |
| BuilderLatestOnly | EveningStar | 1000  | 112.6 μs |  2.33 μs | 1.54 μs |  0.9766 |       - |   21.6 KB |
| **BuilderFull**       | **EveningStar** | **10000** | **320.1 μs** | **14.03 μs** | **9.28 μs** | **35.1563** | **13.6719** | **602.31 KB** |
| BuilderLatestOnly | EveningStar | 10000 | 315.0 μs | 17.46 μs | 9.13 μs |  7.8125 |       - | 132.24 KB |
