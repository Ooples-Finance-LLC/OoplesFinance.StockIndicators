```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean      | Error     | StdDev    | Median    | Gen0    | Gen1    | Allocated |
|------------------ |------------ |------ |----------:|----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **EveningStar** | **1000**  | **121.86 μs** | **73.765 μs** | **48.791 μs** |  **97.04 μs** |  **3.9063** |       **-** |  **69.45 KB** |
| BuilderLatestOnly | EveningStar | 1000  |  85.27 μs |  1.464 μs |  0.766 μs |  85.35 μs |  0.9766 |       - |   21.6 KB |
| **BuilderFull**       | **EveningStar** | **10000** | **275.14 μs** | **14.782 μs** |  **9.777 μs** | **276.87 μs** | **35.1563** | **13.6719** | **602.31 KB** |
| BuilderLatestOnly | EveningStar | 10000 | 258.24 μs |  4.219 μs |  2.511 μs | 257.22 μs |  7.8125 |       - | 132.24 KB |
