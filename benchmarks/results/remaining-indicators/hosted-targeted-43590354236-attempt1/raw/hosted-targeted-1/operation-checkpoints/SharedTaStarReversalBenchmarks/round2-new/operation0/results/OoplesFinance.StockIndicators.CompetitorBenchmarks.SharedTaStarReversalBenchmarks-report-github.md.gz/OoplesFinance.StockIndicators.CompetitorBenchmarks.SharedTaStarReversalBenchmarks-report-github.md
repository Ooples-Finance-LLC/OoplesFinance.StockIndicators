```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean      | Error     | StdDev   | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------ |------ |----------:|----------:|---------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **EveningStar** | **1000**  | **111.03 μs** |  **3.900 μs** | **2.580 μs** |  **3.61** |    **0.08** |  **3.9063** |       **-** |  **69.48 KB** |       **17.50** |
| BuilderLatestOnly | EveningStar | 1000  | 108.62 μs |  2.594 μs | 1.543 μs |  3.53 |    0.05 |  0.9766 |       - |   21.6 KB |        5.44 |
| NativeSingle      | EveningStar | 1000  |  30.75 μs |  0.273 μs | 0.143 μs |  1.00 |    0.01 |       - |       - |   3.97 KB |        1.00 |
| NativeParallel    | EveningStar | 1000  | 105.64 μs |  0.712 μs | 0.373 μs |  3.44 |    0.02 |       - |       - |    8.4 KB |        2.12 |
|                   |             |       |           |           |          |       |         |         |         |           |             |
| **BuilderFull**       | **EveningStar** | **10000** | **290.70 μs** | **10.425 μs** | **6.204 μs** |  **0.76** |    **0.02** | **35.1563** | **13.6719** | **602.34 KB** |       **15.40** |
| BuilderLatestOnly | EveningStar | 10000 | 276.09 μs |  7.385 μs | 3.862 μs |  0.72 |    0.02 |  7.8125 |       - | 132.24 KB |        3.38 |
| NativeSingle      | EveningStar | 10000 | 382.50 μs | 12.328 μs | 8.154 μs |  1.00 |    0.03 |  1.9531 |       - |  39.13 KB |        1.00 |
| NativeParallel    | EveningStar | 10000 | 283.97 μs |  9.891 μs | 5.886 μs |  0.74 |    0.02 |  5.8594 |       - |  78.72 KB |        2.01 |
