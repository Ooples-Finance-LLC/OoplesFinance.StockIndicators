```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean     | Error     | StdDev    | Median   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |---------:|----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)iStar [29]** | **286.1 μs** |   **4.85 μs** |   **2.54 μs** | **286.0 μs** |  **1.00** |    **0.01** |  **72.65 KB** |        **1.00** |
|        |       |                      |          |           |           |          |       |         |           |             |
| **Ooples** | **10000** | **TaLib(...)iStar [29]** | **427.9 μs** | **238.88 μs** | **158.00 μs** | **335.2 μs** |  **1.10** |    **0.49** | **662.81 KB** |        **1.00** |
