```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error    | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|---------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)iStar [29]** | **114.10 μs** | **38.80 μs** | **25.663 μs** |  **1.04** |    **0.30** |  **72.65 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)iStar [29] |  75.88 μs | 16.58 μs |  9.866 μs |  0.69 |    0.16 |  19.91 KB |        0.27 |
|            |       |                      |           |          |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)iStar [29]** | **560.31 μs** | **32.90 μs** | **19.576 μs** |  **1.00** |    **0.05** | **663.14 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)iStar [29] | 622.41 μs | 16.09 μs | 10.643 μs |  1.11 |    0.04 | 125.38 KB |        0.19 |
