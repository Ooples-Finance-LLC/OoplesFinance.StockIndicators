```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |---------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **EveningDojiStar** | **1000**  | **121.69 μs** | **19.136 μs** | **12.657 μs** |  **2.42** |    **0.24** |  **3.9063** |       **-** |  **71.23 KB** |       **17.93** |
| BuilderLatestOnly | EveningDojiStar | 1000  | 105.45 μs |  1.520 μs |  0.795 μs |  2.10 |    0.02 |  0.9766 |       - |  23.39 KB |        5.89 |
| NativeSingle      | EveningDojiStar | 1000  |  50.28 μs |  0.588 μs |  0.350 μs |  1.00 |    0.01 |       - |       - |   3.97 KB |        1.00 |
| NativeParallel    | EveningDojiStar | 1000  | 102.80 μs |  4.495 μs |  2.973 μs |  2.04 |    0.06 |       - |       - |    8.4 KB |        2.11 |
|                   |                 |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **EveningDojiStar** | **10000** | **399.30 μs** | **22.472 μs** | **14.864 μs** |  **0.77** |    **0.03** | **35.1563** | **13.6719** | **583.94 KB** |       **14.92** |
| BuilderLatestOnly | EveningDojiStar | 10000 | 386.27 μs |  6.182 μs |  3.233 μs |  0.75 |    0.02 |  3.9063 |       - | 113.89 KB |        2.91 |
| NativeSingle      | EveningDojiStar | 10000 | 517.71 μs | 17.708 μs | 10.538 μs |  1.00 |    0.03 |       - |       - |  39.15 KB |        1.00 |
| NativeParallel    | EveningDojiStar | 10000 | 357.32 μs | 19.144 μs | 12.663 μs |  0.69 |    0.03 |  5.8594 |       - |  78.72 KB |        2.01 |
