```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **EveningDojiStar** | **1000**  | **126.7 μs** | **18.53 μs** | **12.26 μs** |  **3.9063** |       **-** |  **71.27 KB** |
| BuilderLatestOnly | EveningDojiStar | 1000  | 114.7 μs |  5.68 μs |  3.38 μs |  0.9766 |       - |  23.39 KB |
| **BuilderFull**       | **EveningDojiStar** | **10000** | **494.9 μs** | **44.68 μs** | **29.56 μs** | **35.1563** | **11.7188** | **583.99 KB** |
| BuilderLatestOnly | EveningDojiStar | 10000 | 454.7 μs |  8.40 μs |  4.40 μs |  3.9063 |       - | 113.89 KB |
