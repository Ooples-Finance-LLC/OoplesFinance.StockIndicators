```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation     | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |-------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **AbandonedBaby** | **1000**  | **130.1 μs** |  **8.12 μs** |  **4.25 μs** |  **3.9063** |       **-** |  **70.33 KB** |
| BuilderLatestOnly | AbandonedBaby | 1000  | 127.5 μs |  8.57 μs |  5.67 μs |  0.9766 |       - |  22.45 KB |
| **BuilderFull**       | **AbandonedBaby** | **10000** | **470.3 μs** | **14.10 μs** |  **7.38 μs** | **31.2500** | **11.7188** |  **562.9 KB** |
| BuilderLatestOnly | AbandonedBaby | 10000 | 507.9 μs | 42.19 μs | 27.90 μs |  3.9063 |       - |  92.79 KB |
