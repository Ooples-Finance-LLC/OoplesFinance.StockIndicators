```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation     | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |-------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **AbandonedBaby** | **1000**  | **127.08 μs** |  **3.023 μs** |  **1.581 μs** |  **1.93** |    **0.03** |  **3.9063** |       **-** |  **70.33 KB** |       **17.70** |
| BuilderLatestOnly | AbandonedBaby | 1000  | 126.73 μs |  7.742 μs |  5.121 μs |  1.92 |    0.07 |  0.9766 |       - |  22.45 KB |        5.65 |
| NativeSingle      | AbandonedBaby | 1000  |  65.92 μs |  0.635 μs |  0.420 μs |  1.00 |    0.01 |       - |       - |   3.97 KB |        1.00 |
| NativeParallel    | AbandonedBaby | 1000  | 127.00 μs |  6.414 μs |  4.243 μs |  1.93 |    0.06 |       - |       - |    8.4 KB |        2.11 |
|                   |               |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **AbandonedBaby** | **10000** | **492.01 μs** | **22.654 μs** | **13.481 μs** |  **0.67** |    **0.02** | **31.2500** | **11.7188** |  **562.9 KB** |       **14.38** |
| BuilderLatestOnly | AbandonedBaby | 10000 | 483.19 μs | 48.203 μs | 31.883 μs |  0.66 |    0.04 |  3.9063 |       - |  92.79 KB |        2.37 |
| NativeSingle      | AbandonedBaby | 10000 | 731.68 μs |  3.397 μs |  2.247 μs |  1.00 |    0.00 |       - |       - |  39.16 KB |        1.00 |
| NativeParallel    | AbandonedBaby | 10000 | 486.09 μs | 64.696 μs | 42.792 μs |  0.66 |    0.06 |  3.9063 |       - |  78.73 KB |        2.01 |
