```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean     | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |---------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dBaby [27]** | **392.4 μs** | **22.28 μs** | **14.74 μs** |  **1.00** |    **0.05** |  **71.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dBaby [27] | 117.5 μs | 34.40 μs | 22.75 μs |  0.30 |    0.06 |  19.58 KB |        0.27 |
|            |       |                      |          |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)dBaby [27]** | **405.7 μs** | **11.95 μs** |  **7.11 μs** |  **1.00** |    **0.02** | **642.33 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dBaby [27] | 765.5 μs | 27.84 μs | 18.41 μs |  1.89 |    0.05 | 125.09 KB |        0.19 |
