```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26220.9739)
AMD Ryzen 9 3950X 3.70GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Historical** | **1000**  |  **2,921.1 μs** |   **404.75 μs** |   **267.71 μs** |  **4.88** |    **1.00** |        **-** |        **-** |   **66.03 KB** |        **0.16** |
| BuilderLatestOnly | QuanTAlib.Historical | 1000  |  2,642.2 μs |   240.74 μs |   125.91 μs |  4.41 |    0.84 |        - |        - |   18.41 KB |        0.04 |
| NativeSingle      | QuanTAlib.Historical | 1000  |    623.8 μs |   220.69 μs |   145.97 μs |  1.04 |    0.30 |  46.8750 |        - |  414.09 KB |        1.00 |
| NativeParallel    | QuanTAlib.Historical | 1000  |    131.0 μs |    20.64 μs |    10.80 μs |  0.22 |    0.04 |  52.7344 |   1.9531 |  424.26 KB |        1.02 |
|                   |                      |       |             |             |             |       |         |          |          |            |             |
| **BuilderFull**       | **QuanTAlib.Historical** | **10000** | **29,589.2 μs** | **1,921.03 μs** | **1,270.64 μs** |  **5.88** |    **0.26** |        **-** |        **-** |  **631.06 KB** |        **0.15** |
| BuilderLatestOnly | QuanTAlib.Historical | 10000 | 26,869.8 μs | 2,033.37 μs | 1,344.95 μs |  5.34 |    0.27 |        - |        - |  161.25 KB |        0.04 |
| NativeSingle      | QuanTAlib.Historical | 10000 |  5,038.0 μs |   189.75 μs |    99.24 μs |  1.00 |    0.03 | 500.0000 |  71.4286 | 4201.01 KB |        1.00 |
| NativeParallel    | QuanTAlib.Historical | 10000 |  1,134.0 μs |    20.26 μs |    13.40 μs |  0.23 |    0.00 | 523.4375 | 101.5625 | 4211.01 KB |        1.00 |
|                   |                      |       |             |             |             |       |         |          |          |            |             |
| **BuilderFull**       | **QuanTAlib.Realized**   | **1000**  |  **2,416.0 μs** |   **134.10 μs** |    **88.70 μs** | **19.89** |    **0.77** |        **-** |        **-** |   **66.01 KB** |        **1.39** |
| BuilderLatestOnly | QuanTAlib.Realized   | 1000  |  2,424.9 μs |   144.73 μs |    95.73 μs | 19.97 |    0.82 |        - |        - |   18.41 KB |        0.39 |
| NativeSingle      | QuanTAlib.Realized   | 1000  |    121.5 μs |     3.23 μs |     2.14 μs |  1.00 |    0.02 |   5.3711 |        - |   47.47 KB |        1.00 |
| NativeParallel    | QuanTAlib.Realized   | 1000  |    113.1 μs |     2.62 μs |     1.74 μs |  0.93 |    0.02 |  22.4609 |        - |  188.36 KB |        3.97 |
|                   |                      |       |             |             |             |       |         |          |          |            |             |
| **BuilderFull**       | **QuanTAlib.Realized**   | **10000** | **25,532.8 μs** | **2,412.47 μs** | **1,595.70 μs** | **26.77** |    **1.86** |        **-** |        **-** |  **630.99 KB** |        **1.34** |
| BuilderLatestOnly | QuanTAlib.Realized   | 10000 | 27,397.3 μs |   703.04 μs |   418.37 μs | 28.73 |    1.11 |        - |        - |  160.77 KB |        0.34 |
| NativeSingle      | QuanTAlib.Realized   | 10000 |    954.9 μs |    61.91 μs |    36.84 μs |  1.00 |    0.05 |  54.6875 |   7.8125 |  469.41 KB |        1.00 |
| NativeParallel    | QuanTAlib.Realized   | 10000 |  1,042.6 μs |    15.14 μs |     9.01 μs |  1.09 |    0.04 | 218.7500 |  39.0625 | 1840.76 KB |        3.92 |
