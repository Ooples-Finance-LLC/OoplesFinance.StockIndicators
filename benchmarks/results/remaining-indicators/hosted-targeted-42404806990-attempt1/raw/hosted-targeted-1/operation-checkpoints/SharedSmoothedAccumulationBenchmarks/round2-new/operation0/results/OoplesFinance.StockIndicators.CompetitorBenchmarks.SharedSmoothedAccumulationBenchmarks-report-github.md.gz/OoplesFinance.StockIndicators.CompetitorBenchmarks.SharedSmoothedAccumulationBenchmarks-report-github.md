```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio  | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|-------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **325.224 μs** |  **2.5252 μs** |  **1.5027 μs** |  **99.39** |    **4.83** |       **-** |      **-** |  **73.52 KB** |        **9.42** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   323.252 μs |  4.1754 μs |  2.4847 μs |  98.79 |    4.84 |       - |      - |  25.92 KB |        3.32 |
| NativeSingle      | TaLib(...)AdOsc [21] | 1000  |     3.280 μs |  0.2652 μs |  0.1754 μs |   1.00 |    0.07 |  0.4578 |      - |    7.8 KB |        1.00 |
| NativeParallel    | TaLib(...)AdOsc [21] | 1000  |    91.500 μs |  2.2234 μs |  1.4706 μs |  27.96 |    1.42 |  1.4648 |      - |  27.57 KB |        3.53 |
|                   |                      |       |              |            |            |        |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **3,242.569 μs** | **37.4321 μs** | **22.2752 μs** | **101.76** |    **3.01** | **31.2500** |      **-** | **706.92 KB** |        **9.05** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 3,251.926 μs | 98.5690 μs | 58.6568 μs | 102.05 |    3.42 |       - |      - |  237.1 KB |        3.04 |
| NativeSingle      | TaLib(...)AdOsc [21] | 10000 |    31.891 μs |  1.4668 μs |  0.9702 μs |   1.00 |    0.04 |  4.6387 |      - |  78.12 KB |        1.00 |
| NativeParallel    | TaLib(...)AdOsc [21] | 10000 |   135.675 μs |  7.3175 μs |  4.8401 μs |   4.26 |    0.19 | 17.5781 | 3.9063 | 273.66 KB |        3.50 |
