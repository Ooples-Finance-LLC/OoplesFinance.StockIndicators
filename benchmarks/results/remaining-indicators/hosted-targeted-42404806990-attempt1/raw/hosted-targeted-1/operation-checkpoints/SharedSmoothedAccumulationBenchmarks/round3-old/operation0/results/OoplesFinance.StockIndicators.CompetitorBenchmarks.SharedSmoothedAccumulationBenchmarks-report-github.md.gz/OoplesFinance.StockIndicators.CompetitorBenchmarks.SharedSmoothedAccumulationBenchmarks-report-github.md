```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **321.7 μs** |  **3.65 μs** |  **2.17 μs** |       **-** |  **73.52 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   319.5 μs |  3.20 μs |  1.67 μs |       - |  25.92 KB |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **3,251.2 μs** | **14.42 μs** |  **7.54 μs** | **31.2500** | **706.93 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 3,190.1 μs | 28.21 μs | 16.79 μs |       - | 237.08 KB |
