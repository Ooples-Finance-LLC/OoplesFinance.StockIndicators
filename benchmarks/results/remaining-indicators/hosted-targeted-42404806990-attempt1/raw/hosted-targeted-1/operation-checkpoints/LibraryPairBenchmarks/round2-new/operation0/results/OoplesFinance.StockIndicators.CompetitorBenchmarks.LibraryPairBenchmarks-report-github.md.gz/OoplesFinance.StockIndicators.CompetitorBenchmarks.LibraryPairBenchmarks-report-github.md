```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)AdOsc [21]** |   **482.84 μs** | **23.212 μs** | **13.813 μs** |  **1.00** |    **0.04** |  **209.08 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)AdOsc [21] |    10.78 μs |  0.543 μs |  0.323 μs |  0.02 |    0.00 |   39.23 KB |        0.19 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)AdOsc [21]** | **4,459.92 μs** | **51.911 μs** | **30.892 μs** |  **1.00** |    **0.01** | **2054.15 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)AdOsc [21] |    72.26 μs | 14.632 μs |  9.678 μs |  0.02 |    0.00 |  330.86 KB |        0.16 |
