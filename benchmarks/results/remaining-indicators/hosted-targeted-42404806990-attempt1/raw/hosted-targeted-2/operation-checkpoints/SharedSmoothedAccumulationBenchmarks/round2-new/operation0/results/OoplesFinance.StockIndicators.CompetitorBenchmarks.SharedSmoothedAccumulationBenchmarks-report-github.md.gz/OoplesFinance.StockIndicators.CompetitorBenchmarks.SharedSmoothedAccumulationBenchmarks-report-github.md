```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **322.91 μs** |   **2.722 μs** |   **1.620 μs** |  **3.44** |    **0.05** |        **-** |        **-** |       **-** |   **96.99 KB** |        **0.26** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   365.43 μs |  49.428 μs |  32.693 μs |  3.89 |    0.34 |   1.9531 |        - |       - |   49.42 KB |        0.13 |
| NativeSingle      | Skend(...)inOsc [21] | 1000  |    93.92 μs |   2.167 μs |   1.289 μs |  1.00 |    0.02 |  22.9492 |   6.8359 |       - |  379.71 KB |        1.00 |
| NativeParallel    | Skend(...)inOsc [21] | 1000  |   217.17 μs |   9.862 μs |   5.869 μs |  2.31 |    0.07 |  58.5938 |  19.5313 |       - |  958.69 KB |        2.52 |
|                   |                      |       |             |            |            |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **3,291.14 μs** |  **48.810 μs** |  **29.046 μs** |  **2.53** |    **0.03** |  **31.2500** |        **-** |       **-** |  **941.34 KB** |        **0.25** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 3,218.41 μs |  30.777 μs |  18.315 μs |  2.48 |    0.02 |        - |        - |       - |  471.54 KB |        0.12 |
| NativeSingle      | Skend(...)inOsc [21] | 10000 | 1,300.11 μs |  15.222 μs |   9.058 μs |  1.00 |    0.01 | 242.1875 | 148.4375 | 46.8750 | 3790.29 KB |        1.00 |
| NativeParallel    | Skend(...)inOsc [21] | 10000 | 2,913.74 μs | 186.492 μs | 123.353 μs |  2.24 |    0.09 | 593.7500 | 515.6250 | 78.1250 | 9555.11 KB |        2.52 |
