```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **331.2 μs** |  **4.60 μs** |  **2.74 μs** |       **-** |  **97.03 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   324.2 μs |  1.10 μs |  0.57 μs |       - |  49.44 KB |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **3,346.9 μs** | **31.96 μs** | **19.02 μs** | **31.2500** | **941.37 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 3,368.2 μs | 28.89 μs | 19.11 μs |       - | 471.55 KB |
