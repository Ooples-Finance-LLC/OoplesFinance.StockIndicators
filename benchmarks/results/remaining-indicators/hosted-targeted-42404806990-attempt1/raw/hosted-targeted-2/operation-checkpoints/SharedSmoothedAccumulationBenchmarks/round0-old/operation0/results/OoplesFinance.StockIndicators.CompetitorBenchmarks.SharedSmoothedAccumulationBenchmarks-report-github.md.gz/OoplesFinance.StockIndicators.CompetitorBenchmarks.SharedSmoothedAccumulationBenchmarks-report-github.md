```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error       | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|------------:|----------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **328.9 μs** |     **4.44 μs** |   **2.64 μs** |       **-** |  **97.03 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   335.6 μs |     2.92 μs |   1.74 μs |  1.9531 |  49.42 KB |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **3,339.6 μs** |    **41.86 μs** |  **21.89 μs** | **31.2500** | **941.36 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 4,052.0 μs | 1,076.25 μs | 711.87 μs |       - | 471.54 KB |
