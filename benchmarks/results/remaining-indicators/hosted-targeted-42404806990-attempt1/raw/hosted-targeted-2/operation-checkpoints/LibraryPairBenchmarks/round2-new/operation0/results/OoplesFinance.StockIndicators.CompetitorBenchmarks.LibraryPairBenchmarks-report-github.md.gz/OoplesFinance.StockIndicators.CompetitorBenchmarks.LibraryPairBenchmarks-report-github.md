```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)inOsc [21]** |   **502.4 μs** | **29.97 μs** | **19.82 μs** |  **1.00** |    **0.05** |  **259.67 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)inOsc [21] |   113.0 μs | 23.49 μs | 12.29 μs |  0.23 |    0.02 |  494.81 KB |        1.91 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)inOsc [21]** | **4,494.9 μs** | **59.35 μs** | **35.32 μs** |  **1.00** |    **0.01** | **2552.66 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)inOsc [21] | 1,136.4 μs | 67.48 μs | 40.16 μs |  0.25 |    0.01 | 4854.19 KB |        1.90 |
