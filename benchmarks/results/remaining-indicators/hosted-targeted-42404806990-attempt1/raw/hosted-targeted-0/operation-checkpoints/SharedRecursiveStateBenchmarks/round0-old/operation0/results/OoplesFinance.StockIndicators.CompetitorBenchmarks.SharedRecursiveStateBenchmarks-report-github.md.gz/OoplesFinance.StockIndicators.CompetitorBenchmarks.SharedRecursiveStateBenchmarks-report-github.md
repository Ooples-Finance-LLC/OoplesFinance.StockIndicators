```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |---------- |------ |----------:|----------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **Ad**        | **1000**  |  **78.55 μs** |  **2.156 μs** | **1.283 μs** |  **3.9063** |      **-** |  **64.88 KB** |
| BuilderLatestOnly | Ad        | 1000  |  75.86 μs |  1.587 μs | 0.944 μs |  0.9766 |      - |  17.27 KB |
| **BuilderFull**       | **Ad**        | **10000** | **720.54 μs** | **16.647 μs** | **9.906 μs** | **31.2500** | **7.8125** | **627.74 KB** |
| BuilderLatestOnly | Ad        | 10000 | 702.10 μs | 10.060 μs | 6.654 μs |  7.8125 |      - | 157.91 KB |
