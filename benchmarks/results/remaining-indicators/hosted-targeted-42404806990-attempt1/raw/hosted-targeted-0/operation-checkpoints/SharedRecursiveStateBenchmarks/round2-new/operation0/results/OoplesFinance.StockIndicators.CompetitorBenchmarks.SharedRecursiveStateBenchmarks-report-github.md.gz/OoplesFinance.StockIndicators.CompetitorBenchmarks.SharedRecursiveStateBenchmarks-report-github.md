```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |---------- |------ |-----------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **Ad**        | **1000**  |  **72.974 μs** |  **1.8310 μs** |  **0.9577 μs** | **49.01** |    **0.71** |  **3.9063** |       **-** |  **64.88 KB** |        **8.24** |
| BuilderLatestOnly | Ad        | 1000  |  68.976 μs |  2.2146 μs |  1.4648 μs | 46.33 |    1.00 |  0.9766 |       - |  17.27 KB |        2.19 |
| NativeSingle      | Ad        | 1000  |   1.489 μs |  0.0226 μs |  0.0118 μs |  1.00 |    0.01 |  0.4807 |  0.0076 |   7.88 KB |        1.00 |
| NativeParallel    | Ad        | 1000  |  66.898 μs |  0.5286 μs |  0.3496 μs | 44.93 |    0.40 |  0.4883 |       - |   8.17 KB |        1.04 |
|                   |           |       |            |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **Ad**        | **10000** | **651.934 μs** | **20.2280 μs** | **12.0374 μs** | **47.22** |    **2.62** | **35.1563** | **11.7188** | **627.73 KB** |        **8.03** |
| BuilderLatestOnly | Ad        | 10000 | 621.902 μs |  6.2389 μs |  3.2630 μs | 45.05 |    2.39 |  7.8125 |       - | 157.91 KB |        2.02 |
| NativeSingle      | Ad        | 10000 |  13.845 μs |  1.3380 μs |  0.7962 μs |  1.00 |    0.08 |  4.7607 |  0.8545 |  78.19 KB |        1.00 |
| NativeParallel    | Ad        | 10000 |  82.478 μs |  3.0178 μs |  1.7958 μs |  5.97 |    0.34 |  4.3945 |  0.4883 |  78.48 KB |        1.00 |
