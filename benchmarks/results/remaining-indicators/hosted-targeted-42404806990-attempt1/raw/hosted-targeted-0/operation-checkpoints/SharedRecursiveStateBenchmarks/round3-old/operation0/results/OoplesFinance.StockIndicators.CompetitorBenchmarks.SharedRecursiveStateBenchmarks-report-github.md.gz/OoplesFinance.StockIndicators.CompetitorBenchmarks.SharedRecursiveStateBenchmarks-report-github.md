```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Ad**        | **1000**  |  **74.21 μs** |  **1.246 μs** | **0.741 μs** |  **3.9063** |       **-** |  **64.88 KB** |
| BuilderLatestOnly | Ad        | 1000  |  72.07 μs |  2.735 μs | 1.627 μs |  0.9766 |       - |  17.27 KB |
| **BuilderFull**       | **Ad**        | **10000** | **698.46 μs** | **13.736 μs** | **9.086 μs** | **35.1563** | **11.7188** | **627.74 KB** |
| BuilderLatestOnly | Ad        | 10000 | 672.28 μs | 10.699 μs | 5.596 μs |  7.8125 |       - | 157.92 KB |
