```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |---------- |------ |----------:|----------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **Ad**        | **1000**  |  **74.90 μs** |  **8.452 μs** | **5.029 μs** |  **3.9063** |      **-** |  **64.88 KB** |
| BuilderLatestOnly | Ad        | 1000  |  68.32 μs |  1.970 μs | 1.303 μs |  0.9766 |      - |  17.27 KB |
| **BuilderFull**       | **Ad**        | **10000** | **659.86 μs** | **11.879 μs** | **7.069 μs** | **31.2500** | **7.8125** | **627.76 KB** |
| BuilderLatestOnly | Ad        | 10000 | 629.31 μs |  7.783 μs | 4.071 μs |  7.8125 |      - | 157.92 KB |
