```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean         | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-------------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ad** |   **106.500 μs** | **22.0660 μs** | **14.5953 μs** |  **1.02** |    **0.18** |  **140.75 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ad |     3.390 μs |  0.8683 μs |  0.5744 μs |  0.03 |    0.01 |    8.15 KB |        0.06 |
|            |       |                    |              |            |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ad** | **1,024.856 μs** | **18.8246 μs** | **11.2022 μs** |  **1.00** |    **0.01** | **1707.14 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ad |    19.220 μs |  9.5711 μs |  6.3307 μs |  0.02 |    0.01 |   83.99 KB |        0.05 |
