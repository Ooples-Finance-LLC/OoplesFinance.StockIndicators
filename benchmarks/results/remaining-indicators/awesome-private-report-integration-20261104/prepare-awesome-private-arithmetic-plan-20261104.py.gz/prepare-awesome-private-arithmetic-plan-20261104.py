"""Freeze the private Awesome trial only after fresh CPU and actual GPU checks."""
import argparse, copy, datetime, hashlib, json, subprocess, sys
from pathlib import Path

parser = argparse.ArgumentParser()
for name in ('baseline', 'reference_run', 'reference_source'):
    parser.add_argument(name)
a = parser.parse_args()
r = Path.cwd()
out = Path(__file__).parent / 'awesome-private-arithmetic-20261104'
status = json.loads((out / 'status.json').read_text())
assert status['status'] == 'correctness-complete'
candidate = Path(status['repo'])
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=candidate, text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=candidate)
subprocess.run(['git', 'diff', '--exit-code', status['source'], source, '--', 'src', 'tests'], cwd=candidate, check=True)
assert status['unit']['classes'] == {'AverageOscillatorSharedExecutionTests': 11, 'AverageDirectDifferenceTests': 3, 'AwesomeArithmeticCertificateTests': 6}
assert set(status['parity']['classes']) == {'AwesomeComparisonTests', 'SharedAverageOscillatorBenchmarkTests', 'SharedSkenderFiniteWindowBenchmarkTests'}
gpu = json.loads((candidate / 'benchmarks/results/shared-rollout/local-gpu-contracts/receipt.json').read_text())
assert gpu['passed_cases'] == 100
p = json.loads((r / 'benchmarks/plans/hosted-pvo-volume-dispatch-20261103.json').read_text())
receipt = f'benchmarks/results/remaining-indicators/hosted-targeted-{a.reference_run}-attempt1/decision.json'
raw = subprocess.check_output(['git', 'show', a.baseline + ':' + receipt], cwd=r)
decision = json.loads(raw)
assert decision['accepted'] and decision['production_integrated'] and decision['report_imported']
baseline_totals = (decision['case_count'], decision['decision_count'])
assert baseline_totals == (180,36)
targeted = r / 'scripts/hosted_timing/targeted.py'
registration = """
SCOPES['awesome-private-arithmetic'] = dict(
    fixtures={'SharedSkenderFiniteWindowBenchmarks': {'Skender.GetAwesome':'Skender.GetAwesome'}},
    implicit_fixtures=set(),
    paths={'src/Indicators/AwesomeWithDetails.cs', 'tests/ModelsTests/AwesomeArithmeticCertificateTests.cs'},
    totals=(30,6), baseline_phase='targeted', baseline_totals=BASELINE_TOTALS)


""".replace('BASELINE_TOTALS', repr(baseline_totals))
s = targeted.read_text()
assert "SCOPES['awesome-private-arithmetic']" not in s
assert s.count('def expected_totals(plan):') == 1
targeted.write_text(s.replace('def expected_totals(plan):', registration + 'def expected_totals(plan):'), newline='\n')
sys.path.insert(0, str(r / 'scripts'))
from hosted_timing.targeted import verify_reference
p['sources'].update(published=a.baseline, old=a.baseline, successor=source)
p['gpu_sources'].update(old=a.baseline, successor=source)
p['cpu_test_classes'] = dict(old=['AverageOscillatorSharedExecutionTests', 'AverageDirectDifferenceTests'], successor=['AverageOscillatorSharedExecutionTests', 'AverageDirectDifferenceTests', 'AwesomeArithmeticCertificateTests'])
p['targeted_reference'] = dict(scope='awesome-private-arithmetic', run_id=a.reference_run, decision=receipt,
    sha256=hashlib.sha256(raw).hexdigest(), qualified_source=a.reference_source)
p['affected_pairs'] = ['Skender.GetAwesome']
p['targeted_shards'] = copy.deepcopy(p['targeted_shards'][:2])
for index, shard in enumerate(p['targeted_shards']):
    task = shard['tasks'][0]
    task.update(fixture='LibraryPairBenchmarks' if index == 0 else 'SharedSkenderFiniteWindowBenchmarks',
        implicit_pair=False, operations=[dict(raw='Skender.GetAwesome', pair='Skender.GetAwesome')],
        cases=10 if index == 0 else 20, decisions=2 if index == 0 else 4)
    shard.update(index=index, tasks=[task], cases=task['cases'], decisions=task['decisions'])
p['matrix'].update(shards=2, max_parallel=2)
p['cases'], p['decisions'] = 30,6
p['source_correctness'] = dict(unit=status['unit']['passed'], comparator=status['parity']['passed'],
    actual_local_gpu=100, source_sha256=gpu['source_sha256'], cpu_build_run=status['build_origin']['run_id'],
    cpu_build_workflow_head=status['build_origin']['workflow_head'])
p['scope'] = 'Private Awesome midpoint and normalized-percentage certificate using exact halves and guarded signed FMA residuals; rolling means, stage rounding and original exact fallback unchanged.'
p['call_graph'] = ['AwesomeWithDetails.State changes only private midpoint and normalized100*oscillator/price publication. Skender.GetAwesome and canonical SharedSkenderFiniteWindowBenchmarks cover batch and all four builder arms. Rolling MeanWindow and separately rounded fast/slow means and oscillator are unchanged. Malformed quote priority, shared helpers and legacy arithmetic are preserved.']
p['limits'] = ['Exactly two source/test paths; fresh complete 30-case / 6-decision qualification.',
    'At least one faster and zero slower; no pooling; existing SDK/runtime/warmup/iteration/CPU/build/hash/source gates retained.']
p['created_utc'] = p['frozen_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
verify_reference(p)
path = r / 'benchmarks/plans/hosted-awesome-private-arithmetic-20261104.json'
assert not path.exists()
path.write_text(json.dumps(p, indent=2)+'\n', newline='\n')
w = r / '.github/workflows/cpu-kernel-performance.yml'
s = w.read_text()
needle = 'benchmarks/plans/hosted-combined-private-inputs-20261104.json]'
assert s.count(needle) == 1
w.write_text(s.replace(needle, needle[:-1]+', '+path.relative_to(r).as_posix()+']'), newline='\n')
attributes = r / '.gitattributes'
attributes.write_text(attributes.read_text()+path.relative_to(r).as_posix()+' text eol=lf\n', newline='\n')
test = (r / 'scripts/test_hosted_envelope_band_certificate.py').read_text()
test = test.replace('exact-envelope', 'exact Awesome').replace('EnvelopeBandCertificateTests', 'AwesomePrivateArithmeticPlanTests').replace('hosted-envelope-band-certificate-20261103', 'hosted-awesome-private-arithmetic-20261104')
(r / 'scripts/test_hosted_awesome_private_arithmetic.py').write_text(test, newline='\n')
print(source, hashlib.sha256(path.read_bytes()).hexdigest())
