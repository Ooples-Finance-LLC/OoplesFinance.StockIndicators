```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |    **28.98 μs** |  **0.542 μs** |  **0.358 μs** |  **0.50** |    **0.01** |   **5.3711** |   **0.9766** |   **88.31 KB** |        **0.50** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |    26.03 μs |  0.580 μs |  0.345 μs |  0.44 |    0.01 |   2.4414 |   0.2441 |    40.7 KB |        0.23 |
| NativeSingle      | Skender.GetAdl | 1000  |    58.54 μs |  1.557 μs |  0.815 μs |  1.00 |    0.02 |  10.7422 |   2.4414 |  176.21 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 1000  |   154.60 μs | 13.634 μs |  9.018 μs |  2.64 |    0.15 |  28.3203 |   8.7891 |   449.4 KB |        2.55 |
|                   |                |       |             |           |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetAdl** | **10000** |   **269.90 μs** |  **4.508 μs** |  **2.683 μs** |  **0.41** |    **0.01** |  **50.7813** |  **17.5781** |  **862.12 KB** |        **0.49** |
| BuilderLatestOnly | Skender.GetAdl | 10000 |   245.54 μs |  2.705 μs |  1.609 μs |  0.37 |    0.01 |  23.4375 |   9.7656 |  392.29 KB |        0.22 |
| NativeSingle      | Skender.GetAdl | 10000 |   662.57 μs | 17.595 μs | 11.638 μs |  1.00 |    0.02 | 105.4688 |  66.4063 | 1758.26 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 10000 | 1,418.04 μs | 45.068 μs | 29.809 μs |  2.14 |    0.06 | 273.4375 | 195.3125 | 4474.84 KB |        2.55 |
