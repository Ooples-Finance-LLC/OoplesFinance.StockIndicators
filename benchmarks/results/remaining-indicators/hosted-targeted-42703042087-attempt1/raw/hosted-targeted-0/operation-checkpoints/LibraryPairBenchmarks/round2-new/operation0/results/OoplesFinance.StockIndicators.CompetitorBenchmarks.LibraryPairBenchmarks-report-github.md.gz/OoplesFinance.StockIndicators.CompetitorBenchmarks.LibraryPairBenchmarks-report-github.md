```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean      | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAdl** | **194.32 μs** | **17.04 μs** | **10.14 μs** |  **1.00** |    **0.07** |  **159.04 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAdl |  88.49 μs | 17.43 μs | 10.37 μs |  0.46 |    0.06 |   273.7 KB |        1.72 |
|            |       |                |           |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAdl** | **949.07 μs** | **44.11 μs** | **26.25 μs** |  **1.00** |    **0.04** | **1507.77 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAdl | 695.86 μs | 37.27 μs | 24.65 μs |  0.73 |    0.03 |  2653.2 KB |        1.76 |
