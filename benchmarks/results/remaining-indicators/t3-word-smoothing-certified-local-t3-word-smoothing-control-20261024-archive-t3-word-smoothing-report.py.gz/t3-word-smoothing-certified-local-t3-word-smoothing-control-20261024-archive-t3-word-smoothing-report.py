from pathlib import Path
import gzip,hashlib,json,re,sys
kind='t3-word-smoothing'
run=f'local-{kind}-control-20261024'
ROOT=Path('C:/Users/cheat/StockIndicators-Recovery-20261021');REPO=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
OUT=REPO/'benchmarks/results/remaining-indicators';REPORT=Path('C:/Users/cheat/Documents/OoplesFinance-Reports')/(kind+'-refresh-'+run)
receipt=json.loads((REPORT/'imported.json').read_text(encoding='utf-8'))
assert hashlib.sha256((REPORT.parent/'competitor-performance.html').read_bytes()).hexdigest()==receipt['candidate_sha256']
archives={}
for name in ['imported.json','browser-verification.json','staged.json','measurement.json']:
 raw=(REPORT/name).read_bytes();target=OUT/(kind+'-certified-'+run+'-'+name+'.gz');target.write_bytes(gzip.compress(raw,mtime=0));archives[name]={'sha256':hashlib.sha256(raw).hexdigest(),'archive':target.relative_to(REPO).as_posix()}
for name in ['stage-t3-word-smoothing-report.py','verify-approved-certified-report.py','import-t3-word-smoothing-report.py','archive-t3-word-smoothing-control.py','prove-t3-word-smoothing-integration.py','archive-t3-word-smoothing-report.py']:
 raw=(ROOT/name).read_bytes();target=OUT/(kind+'-certified-'+run+'-'+name+'.gz');target.write_bytes(gzip.compress(raw,mtime=0));archives[name]={'sha256':hashlib.sha256(raw).hexdigest(),'archive':target.relative_to(REPO).as_posix()}
summary={k:v for k,v in receipt.items() if k not in ['rows','builder_rows']};summary['archives']=archives
(OUT/(kind+'-certified-'+run+'-report-import.json')).write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Archived complete compressed import and verification, plus exact executed scripts:',run)
