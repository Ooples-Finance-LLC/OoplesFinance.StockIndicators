from pathlib import Path
import hashlib,json,math,re,subprocess
root=Path('C:/Users/cheat/StockIndicators-Recovery-20261021');out=root/'compensated-factored-control-39736180246'
run=json.loads(subprocess.check_output(['gh','run','view','39736180246','--repo','Ooples-Finance-LLC/OoplesFinance.StockIndicators','--json','status,conclusion,headSha']))
assert run=={'status':'completed','conclusion':'success','headSha':'abd90dada05db6a9eb5cb134f9b6c5cf55d48a6d'}
d=json.loads((out/'comparison.json').read_text());assert d['complete'] and d['run_id']=='39736180246' and d['workflow_sha']==run['headSha']
assert d['order']==['old','new','new','old'] and len(d['rounds'])==4
sources={'old':'29a41d8b7956a05812a5950631f07b84bcb04ee0','new':'58bf6abd1a52c48575cefd8a8ef7ac45194d284d'}
manifest=json.loads((out/'binary-manifest.json').read_text());assert manifest['old'].keys()==manifest['new'].keys()
assert [p for p in manifest['old'] if manifest['old'][p]!=manifest['new'][p]]==['OoplesFinance.StockIndicators.dll']
proof=json.loads((out/'provenance.json').read_text());assert proof['new_source']==sources['new'] and proof['old_source']==sources['old']
rows=[]
for index,round in enumerate(d['rounds']):
 assert round['order']==index and round['version']==d['order'][index] and round['source_sha']==sources[round['version']]
 path=out/Path(round['report_file']).relative_to('control');raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()==round['report_sha256']
 report=json.loads(raw);cases={}
 for case in report['Benchmarks']:
  name=case['FullName'];assert 'SharedNativeEmaBenchmarks.' in name
  key=re.search(r'Operation: "([^"]+)"',name)[1],int(re.search(r'Count: (\d+)',name)[1]),case['Method'];assert key not in cases
  stats=case['Statistics'];values=stats['OriginalValues'];ci=stats['ConfidenceInterval'];assert len(values)==stats['N']>=7
  assert all(math.isfinite(v) and v>0 for v in values) and math.isclose(sum(values)/len(values),stats['Mean'],rel_tol=1e-12)
  cases[key]={'pair':key[0],'bars':key[1],'method':key[2],'mean_ns':stats['Mean'],'lower_ns':ci['Lower'],'upper_ns':ci['Upper'],'samples':stats['N'],'allocated_bytes':case['Memory']['BytesAllocatedPerOperation']}
 assert cases.keys()=={(p,n,m) for p in ['QuanTAlib.Dema','QuanTAlib.Tema'] for n in [1000,10000] for m in ['BuilderFull','BuilderLatestOnly','NativeSingle','NativeParallel']}
 assert len(round['rows'])==16 and all(cases[r['pair'],r['bars'],r['method']]==r for r in round['rows'])
 rows.append(cases)
decisions=[]
for key in sorted(rows[0]):
 if not key[2].startswith('Builder'):continue
 old=[rows[i][key] for i in [0,3]];new=[rows[i][key] for i in [1,2]]
 verdict='faster' if max(r['upper_ns'] for r in new)<min(r['lower_ns'] for r in old) else 'slower' if min(r['lower_ns'] for r in new)>max(r['upper_ns'] for r in old) else 'inconclusive'
 record={'pair':key[0],'bars':key[1],'mode':key[2],'old_means_ms':[r['mean_ns']/1e6 for r in old],'new_means_ms':[r['mean_ns']/1e6 for r in new],'verdict':verdict}
 decisions.append(record);print(json.dumps(record))
(out/'verified-summary.json').write_text(json.dumps({'run':run,'sources':sources,'all_64_cases_verified':True,'decisions':decisions,'note':'Both candidate intervals compared against both old controls. Inconclusive is not a speedup.'},indent=2),encoding='utf-8')
