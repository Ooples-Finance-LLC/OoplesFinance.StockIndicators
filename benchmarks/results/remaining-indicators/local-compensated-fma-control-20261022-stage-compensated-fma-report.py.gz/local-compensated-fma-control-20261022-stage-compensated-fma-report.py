from pathlib import Path
import copy,datetime,hashlib,html,json,re,subprocess
ROOT=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
REPO=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
RUN='local-compensated-fma-control-20261022'
RAW=ROOT/RUN
LIVE=Path('C:/Users/cheat/Documents/OoplesFinance-Reports/competitor-performance.html')
OUT=LIVE.parent/('tema-refresh-'+RUN)
summary=json.loads((RAW/'verified-summary.json').read_text(encoding='utf-8'))
assert summary['all_96_cases_verified'] and not any(r['verdict']=='slower' for r in summary['decisions'])
SOURCE=summary['sources']['new'];PAIRS={'QuanTAlib.Dema','QuanTAlib.Tema'}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
archive='benchmarks/results/remaining-indicators/'+RUN+'/decision.json'
subprocess.run(['git','cat-file','-e',head+':'+archive],cwd=REPO,check=True)
url='https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/blob/'+head+'/'+archive
original=LIVE.read_bytes();s=original.decode('utf-8')
def embedded(name):return json.loads(re.search(r'<script[^>]*id="'+name+r'"[^>]*>(.*?)</script>',s,re.S)[1])
def replace(name,value):
 global s
 s,n=re.subn(r'(<script[^>]*id="'+name+r'"[^>]*>).*?(</script>)',lambda m:m[1]+json.dumps(value,ensure_ascii=True).replace('<','\\u003c')+m[2],s,flags=re.S);assert n==1
data=embedded('dataset');before=copy.deepcopy(data);builder=embedded('current-competitor-data');status=embedded('rollout-status-data');oldcounts=status['measurement_totals'].copy();oldsource=next(r['source_sha'] for r in data['rows'] if r['pair']=='QuanTAlib.Tema')
state=json.loads((RAW/'status.json').read_text(encoding='utf-8'))
record=next(r for r in state['rounds'] if r['index']==2 and r['fixture']=='LibraryPairBenchmarks')
raw=Path(record['report']).read_bytes();assert hashlib.sha256(raw).hexdigest()==record['sha256'];report=json.loads(raw)
for row in data['rows']:
 if row['pair'] not in PAIRS:continue
 for method,arm in [('Ooples','ooples'),('Competitor','competitor')]:
  cases=[c for c in report['Benchmarks'] if c['Method']==method and f'Bars: {row["bars"]},' in c['FullName'] and f'PairId: "{row["pair"]}"' in c['FullName']];assert len(cases)==1
  c=cases[0];stats=c['Statistics'];row.update({arm+'_mean_ns':stats['Mean'],arm+'_stddev_ns':stats['StandardDeviation'],arm+'_samples':stats['N'],arm+'_allocated_bytes':c['Memory']['BytesAllocatedPerOperation']})
  row['raw'][method]={'samples':stats['OriginalValues'],'host':report['HostEnvironmentInfo'],'report':str(Path(record['report']).relative_to(RAW)),'confidence_interval':stats['ConfidenceInterval']}
 row.update(competitor_over_ooples=row['competitor_mean_ns']/row['ooples_mean_ns'],source_sha=SOURCE,measurement_run_url=url)
data['evidence']['rowOverrides']=[r for r in data['evidence']['rowOverrides'] if r['pair'] not in PAIRS]
for pair in sorted(PAIRS):data['evidence']['rowOverrides'].append({'pair':pair,'sourceSha':SOURCE,'runUrl':url,'reportSha256':record['sha256'],'round':2,'selection':'Chronologically final candidate round of local Windows actual LibraryPair measurements; builder timing is separate.','measurementLocation':'Local Windows'})
assert sum(a==b for a,b in zip(before['rows'],data['rows'],strict=True))==798
replace('dataset',data)
cases={(r['pair'],r['bars'],r['method']):r for r in summary['final_candidate_rows']['SharedNativeEmaBenchmarks']}
def stats(r):return {k:r[k] for k in ['mean_ns','lower_ns','upper_ns','samples','allocated_bytes']}
comparisons=[]
for pair in sorted(PAIRS):
 for bars in [1000,10000]:
  native={m:stats(cases[pair,bars,m]) for m in ['NativeSingle','NativeParallel']}
  for mode in ['BuilderFull','BuilderLatestOnly']:
   ours=stats(cases[pair,bars,mode]);verdict='faster' if ours['upper_ns']<min(n['lower_ns'] for n in native.values()) else 'slower' if ours['lower_ns']>min(n['upper_ns'] for n in native.values()) else 'inconclusive'
   comparisons.append({'pair':pair,'bars':bars,'mode':mode,'ooples':ours,'native':native,'fastest_native':min(native,key=lambda m:native[m]['mean_ns']),'verdict':verdict})
replaced=0
for receipt in builder['receipts']:
 keep=[c for c in receipt['comparisons'] if c['pair'] not in PAIRS];replaced+=len(receipt['comparisons'])-len(keep);receipt['comparisons']=keep
assert replaced==8
builder['receipts']=[r for r in builder['receipts'] if r['comparisons']]
record=next(r for r in state['rounds'] if r['index']==2 and r['fixture']=='SharedNativeEmaBenchmarks')
builder['receipts'].append({'fixture':'SharedNativeEmaBenchmarks','source_sha':SOURCE,'run_id':RUN,'measurement_url':url,'measurement_location':'Local Windows','round':2,'report_file':str(Path(record['report']).relative_to(RAW)),'report_sha256':record['sha256'],'selection':'Chronologically final candidate round, not fastest.','complete':True,'comparisons':comparisons})
rows=[{**c,'run_id':str(r['run_id']),'source_sha':r['source_sha'],'measurement_url':r.get('measurement_url','https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/'+str(r['run_id']))} for r in builder['receipts'] for c in r['comparisons']]
assert len(rows)==builder['full_comparisons'] and len({(r['pair'],r['bars'],r['mode']) for r in rows})==len(rows)
counts={v:sum(r['verdict']==v for r in rows) for v in ['faster','slower','inconclusive']};builder['verdicts']=counts;builder['status'].update(commit=SOURCE,updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());replace('current-competitor-data',builder)
oldhead=status['published_head'];status.update(published_head=head,inventory_commit=head,row_overrides=data['evidence']['rowOverrides'],inventory_sha256=hashlib.sha256((REPO/'benchmarks/results/remaining-indicators/inventory.json').read_bytes()).hexdigest());status['measurement_totals'].update(counts);status['builder_measurement_sources'].append({'source_sha':SOURCE,'run_url':url,'comparisons':8,'replaces_pairs':sorted(PAIRS),'round':2,'measurement_location':'Local Windows'});replace('rollout-status-data',status)
base=data['evidence']['baseSourceSha'];sma=data['evidence']['rowOverrides'][0]['sourceSha']
s=re.sub(r'Measured builds: [^<]*?\.',lambda _:f'Measured builds: {base[:8]} (796 comparisons), {sma[:8]} (two SMA comparisons), {SOURCE[:8]} (four DEMA/TEMA comparisons).',s)
oldwins=sum(r['competitor_over_ooples']>1 for r in before['rows'] if r['bars']==10000);wins=sum(r['competitor_over_ooples']>1 for r in data['rows'] if r['bars']==10000)
s=s.replace(f'{oldwins} / 401 APIs at 10,000 bars',f'{wins} / 401 APIs at 10,000 bars').replace('published <code>'+oldhead[:8]+'</code>','published <code>'+head[:8]+'</code>')
for prefix in ['Builder-mode timing: ',': ']:
 old=prefix+f"{oldcounts['faster']} faster, {oldcounts['slower']} slower, {oldcounts['inconclusive']} inconclusive, "+('and ' if prefix.startswith('Builder') else '')+f"{oldcounts['pending']} pending."
 new=prefix+f"{counts['faster']} faster, {counts['slower']} slower, {counts['inconclusive']} inconclusive, "+('and ' if prefix.startswith('Builder') else '')+f"{oldcounts['pending']} pending."
 s=s.replace(old,new)
body=[]
for r in sorted(rows,key=lambda r:(r['pair'],r['bars'],r['mode'])):
 values=[r['pair'],f"{r['bars']:,}",'Full history' if r['mode']=='BuilderFull' else 'Latest only',f"{r['ooples']['mean_ns']/1e6:.6f}",f"{r['native']['NativeSingle']['mean_ns']/1e6:.6f}",f"{r['native']['NativeParallel']['mean_ns']/1e6:.6f}",{'faster':'Faster than both','slower':'Slower than at least one','inconclusive':'Inconclusive'}[r['verdict']]]
 body.append('<tr data-builder-pair="'+html.escape(r['pair'],quote=True)+'" data-bars="'+str(r['bars'])+'" data-mode="'+r['mode']+'">'+''.join('<td>'+html.escape(x)+'</td>' for x in values)+'<td><a href="'+html.escape(r['measurement_url'],quote=True)+'">'+r['run_id']+'</a></td></tr>')
s,n=re.subn(r'(<table id="builder-current-results">.*?<tbody>).*?(</tbody>)',lambda m:m[1]+''.join(body)+m[2],s,flags=re.S);assert n==1
s=s.replace('DEMA/TEMA use qualified source '+oldsource+' and the final candidate round of control 39738942544.','DEMA/TEMA use qualified source '+SOURCE+' and the final candidate round of local Windows control '+RUN+'.')
s=s.replace('DEMA/TEMA rows use qualified source '+oldsource+' and final candidate round 2 of control39738942544.','DEMA/TEMA rows use qualified source '+SOURCE+' and final candidate round 2 of local Windows control '+RUN+'.')
source_html=f'<p>796 comparisons: <code>{base}</code>, full run 39719116665. Two SMA comparisons: <code>{sma}</code>, final candidate round of 39727929133. Four DEMA/TEMA comparisons: <code>{SOURCE}</code>, <a href="{url}">local Windows actual LibraryPair measurements, final candidate round</a>. Per-row details and CSV contain each measurement source and evidence link.</p>'
s,n=re.subn(r"\$\('source'\)\.innerHTML=[^\r\n]*;",lambda _:"$('source').innerHTML="+json.dumps(source_html)+';',s,count=1,flags=re.M);assert n==1
OUT.mkdir(exist_ok=True);assert not (OUT/'before.html').exists() or (OUT/'before.html').read_bytes()==original
(OUT/'before.html').write_bytes(original);(OUT/'candidate.html').write_text(s,encoding='utf-8')
(OUT/'measurement.json').write_text(json.dumps({'source_sha':SOURCE,'run_id':RUN,'measurement_url':url}),encoding='utf-8')
(OUT/'staged.json').write_text(json.dumps({'before_sha256':hashlib.sha256(original).hexdigest(),'candidate_sha256':hashlib.sha256((OUT/'candidate.html').read_bytes()).hexdigest(),'changed_baseline_rows':4,'unchanged_baseline_rows':798,'changed_builder_slots':8,'builder_rows':rows,'verdicts':counts},indent=2),encoding='utf-8')
print('Staged4 baseline rows and8 builder slots',counts)
