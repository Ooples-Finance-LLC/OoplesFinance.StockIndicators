```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Mama** | **1000**  |   **446.79 μs** |  **4.941 μs** |  **2.941 μs** |  **4.68** |    **0.03** |        **-** |        **-** |        **-** |  **82.61 KB** |        **5.31** |
| BuilderLatestOnly | TaLib.Functions.Mama | 1000  |   429.17 μs |  4.490 μs |  2.970 μs |  4.50 |    0.03 |        - |        - |        - |  35.02 KB |        2.25 |
| NativeSingle      | TaLib.Functions.Mama | 1000  |    95.44 μs |  0.579 μs |  0.383 μs |  1.00 |    0.01 |   0.4883 |        - |        - |  15.55 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mama | 1000  |   136.35 μs |  4.670 μs |  3.089 μs |  1.43 |    0.03 |   3.9063 |        - |        - |  54.83 KB |        3.53 |
|                   |                      |       |             |           |           |       |         |          |          |          |           |             |
| **BuilderFull**       | **TaLib.Functions.Mama** | **10000** | **4,233.27 μs** | **52.862 μs** | **27.648 μs** |  **4.09** |    **0.03** |  **31.2500** |        **-** |        **-** | **786.27 KB** |        **5.02** |
| BuilderLatestOnly | TaLib.Functions.Mama | 10000 | 4,163.22 μs | 11.910 μs |  6.229 μs |  4.02 |    0.02 |        - |        - |        - | 316.45 KB |        2.02 |
| NativeSingle      | TaLib.Functions.Mama | 10000 | 1,034.88 μs |  7.592 μs |  5.022 μs |  1.00 |    0.01 |  46.8750 |  46.8750 |  46.8750 | 156.58 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mama | 10000 | 1,396.03 μs | 24.177 μs | 15.991 μs |  1.35 |    0.02 | 132.8125 | 132.8125 | 132.8125 | 548.11 KB |        3.50 |
