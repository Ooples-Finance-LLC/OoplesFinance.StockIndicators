```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)hasor [24]** | **1000**  |   **378.1 μs** |  **4.55 μs** |  **2.71 μs** |       **-** |  **82.42 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 1000  |   385.7 μs | 15.24 μs | 10.08 μs |       - |  34.83 KB |
| **BuilderFull**       | **TaLib(...)hasor [24]** | **10000** | **3,993.2 μs** | **62.36 μs** | **32.62 μs** | **31.2500** | **786.06 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 10000 | 3,691.0 μs | 64.63 μs | 33.80 μs |       - | 316.27 KB |
