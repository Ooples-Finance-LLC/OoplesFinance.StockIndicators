```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mama** | **1000**  | **1,184.3 μs** |   **9.68 μs** |  **5.06 μs** |  **82.72 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 1000  |   996.6 μs |  13.35 μs |  6.98 μs |  35.03 KB |
| **BuilderFull**       | **TaLib.Functions.Mama** | **10000** | **9,919.0 μs** | **121.11 μs** | **63.34 μs** | **786.68 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 10000 | 9,946.8 μs |  68.18 μs | 35.66 μs | 316.75 KB |
