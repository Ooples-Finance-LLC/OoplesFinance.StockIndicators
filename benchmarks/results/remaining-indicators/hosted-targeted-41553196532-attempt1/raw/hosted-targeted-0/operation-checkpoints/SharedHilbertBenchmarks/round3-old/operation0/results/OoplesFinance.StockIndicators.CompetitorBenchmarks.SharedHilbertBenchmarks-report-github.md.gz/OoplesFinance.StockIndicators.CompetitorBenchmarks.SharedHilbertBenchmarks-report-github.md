```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)eriod [26]** | **1000**  |   **958.0 μs** | **16.22 μs** |  **8.48 μs** |  **66.63 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 1000  |   927.0 μs | 12.46 μs |  6.52 μs |  18.96 KB |
| **BuilderFull**       | **TaLib(...)eriod [26]** | **10000** | **9,134.2 μs** | **40.17 μs** | **23.91 μs** | **629.79 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 10000 | 9,249.4 μs | 47.63 μs | 24.91 μs | 160.03 KB |
