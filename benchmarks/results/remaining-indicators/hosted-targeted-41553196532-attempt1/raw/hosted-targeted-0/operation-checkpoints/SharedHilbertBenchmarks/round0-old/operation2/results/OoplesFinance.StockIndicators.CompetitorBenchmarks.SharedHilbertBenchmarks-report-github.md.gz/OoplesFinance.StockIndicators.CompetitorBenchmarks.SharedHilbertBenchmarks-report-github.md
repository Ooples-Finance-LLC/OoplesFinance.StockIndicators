```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |---------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mama** | **1000**  | **1.130 ms** | **0.0258 ms** | **0.0171 ms** |  **82.72 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 1000  | 1.015 ms | 0.0092 ms | 0.0055 ms |  35.04 KB |
| **BuilderFull**       | **TaLib.Functions.Mama** | **10000** | **9.933 ms** | **0.1963 ms** | **0.1168 ms** | **786.62 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 10000 | 9.900 ms | 0.2980 ms | 0.1774 ms | 316.68 KB |
