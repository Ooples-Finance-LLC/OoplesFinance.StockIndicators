```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)hasor [24]** | **1000**  |   **984.9 μs** |  **20.26 μs** |  **12.06 μs** |  **82.53 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 1000  |   937.7 μs |  11.20 μs |   5.86 μs |  34.85 KB |
| **BuilderFull**       | **TaLib(...)hasor [24]** | **10000** | **9,247.5 μs** | **203.88 μs** | **121.33 μs** | **786.36 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 10000 | 9,204.6 μs |  82.09 μs |  48.85 μs | 316.58 KB |
