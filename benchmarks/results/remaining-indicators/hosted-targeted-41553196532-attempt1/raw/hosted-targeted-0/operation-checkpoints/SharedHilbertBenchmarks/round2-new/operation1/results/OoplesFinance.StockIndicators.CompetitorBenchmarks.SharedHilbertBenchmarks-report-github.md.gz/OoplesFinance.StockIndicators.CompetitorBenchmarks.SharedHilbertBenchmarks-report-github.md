```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)hasor [24]** | **1000**  |   **388.32 μs** | **23.362 μs** | **13.903 μs** |  **4.13** |    **0.15** |        **-** |        **-** |        **-** |  **82.42 KB** |        **5.30** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 1000  |   385.11 μs | 10.238 μs |  6.092 μs |  4.10 |    0.07 |   1.9531 |        - |        - |  34.81 KB |        2.24 |
| NativeSingle      | TaLib(...)hasor [24] | 1000  |    93.94 μs |  1.449 μs |  0.958 μs |  1.00 |    0.01 |   0.4883 |        - |        - |  15.55 KB |        1.00 |
| NativeParallel    | TaLib(...)hasor [24] | 1000  |   134.05 μs |  6.832 μs |  4.519 μs |  1.43 |    0.05 |   3.9063 |        - |        - |  54.83 KB |        3.53 |
|                   |                      |       |             |           |           |       |         |          |          |          |           |             |
| **BuilderFull**       | **TaLib(...)hasor [24]** | **10000** | **3,773.95 μs** | **68.935 μs** | **41.022 μs** |  **3.75** |    **0.04** |  **31.2500** |        **-** |        **-** | **786.06 KB** |        **5.02** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 10000 | 3,701.91 μs | 37.154 μs | 24.575 μs |  3.68 |    0.02 |        - |        - |        - | 316.29 KB |        2.02 |
| NativeSingle      | TaLib(...)hasor [24] | 10000 | 1,006.34 μs |  3.235 μs |  1.925 μs |  1.00 |    0.00 |  46.8750 |  46.8750 |  46.8750 | 156.57 KB |        1.00 |
| NativeParallel    | TaLib(...)hasor [24] | 10000 | 1,345.86 μs | 37.442 μs | 22.281 μs |  1.34 |    0.02 | 132.8125 | 132.8125 | 132.8125 | 548.11 KB |        3.50 |
