```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |---------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)hasor [24]** | **1000**  | **1.114 ms** | **0.0122 ms** | **0.0064 ms** |  **82.53 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 1000  | 1.168 ms | 0.0114 ms | 0.0059 ms |  34.84 KB |
| **BuilderFull**       | **TaLib(...)hasor [24]** | **10000** | **9.325 ms** | **0.2307 ms** | **0.1373 ms** |  **786.6 KB** |
| BuilderLatestOnly | TaLib(...)hasor [24] | 10000 | 9.210 ms | 0.1152 ms | 0.0686 ms | 316.58 KB |
