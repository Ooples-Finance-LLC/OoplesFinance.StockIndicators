```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)eriod [26]** | **1000**  |   **385.02 μs** | **27.353 μs** | **18.093 μs** |  **3.92** |    **0.18** |       **-** |  **66.53 KB** |        **8.33** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 1000  |   382.49 μs |  8.003 μs |  5.294 μs |  3.90 |    0.07 |       - |  18.92 KB |        2.37 |
| NativeSingle      | TaLib(...)eriod [26] | 1000  |    98.14 μs |  2.084 μs |  1.379 μs |  1.00 |    0.02 |       - |   7.99 KB |        1.00 |
| NativeParallel    | TaLib(...)eriod [26] | 1000  |   131.05 μs |  2.734 μs |  1.430 μs |  1.34 |    0.02 |  1.9531 |  28.36 KB |        3.55 |
|                   |                      |       |             |           |           |       |         |         |           |             |
| **BuilderFull**       | **TaLib(...)eriod [26]** | **10000** | **3,742.32 μs** | **89.271 μs** | **53.124 μs** |  **3.83** |    **0.06** | **31.2500** | **629.56 KB** |        **8.04** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 10000 | 3,766.29 μs | 37.972 μs | 19.860 μs |  3.85 |    0.04 |       - | 159.73 KB |        2.04 |
| NativeSingle      | TaLib(...)eriod [26] | 10000 |   978.43 μs | 13.169 μs |  8.710 μs |  1.00 |    0.01 |       - |  78.33 KB |        1.00 |
| NativeParallel    | TaLib(...)eriod [26] | 10000 | 1,189.30 μs | 21.699 μs | 14.353 μs |  1.22 |    0.02 | 15.6250 |  274.5 KB |        3.50 |
