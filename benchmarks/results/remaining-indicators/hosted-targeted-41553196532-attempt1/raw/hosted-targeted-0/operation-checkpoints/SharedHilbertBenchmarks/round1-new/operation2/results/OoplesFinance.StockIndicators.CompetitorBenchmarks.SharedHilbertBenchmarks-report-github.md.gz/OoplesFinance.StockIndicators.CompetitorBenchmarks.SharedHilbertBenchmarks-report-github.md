```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mama** | **1000**  |   **460.2 μs** |  **16.73 μs** | **11.07 μs** |       **-** |  **82.61 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 1000  |   440.3 μs |   7.87 μs |  5.20 μs |       - |  35.02 KB |
| **BuilderFull**       | **TaLib.Functions.Mama** | **10000** | **4,422.6 μs** | **146.26 μs** | **96.74 μs** | **31.2500** | **786.28 KB** |
| BuilderLatestOnly | TaLib.Functions.Mama | 10000 | 4,249.8 μs |  82.64 μs | 49.18 μs |       - | 316.43 KB |
