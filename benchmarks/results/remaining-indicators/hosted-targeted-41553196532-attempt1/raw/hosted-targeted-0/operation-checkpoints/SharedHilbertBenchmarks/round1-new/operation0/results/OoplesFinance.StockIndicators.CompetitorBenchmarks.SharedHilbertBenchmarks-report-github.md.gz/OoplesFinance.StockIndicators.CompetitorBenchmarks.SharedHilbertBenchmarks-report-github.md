```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)eriod [26]** | **1000**  |   **390.4 μs** | **27.35 μs** | **16.27 μs** |       **-** |  **66.53 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 1000  |   373.0 μs |  6.75 μs |  4.01 μs |       - |  18.92 KB |
| **BuilderFull**       | **TaLib(...)eriod [26]** | **10000** | **3,646.6 μs** | **57.59 μs** | **34.27 μs** | **31.2500** |  **629.6 KB** |
| BuilderLatestOnly | TaLib(...)eriod [26] | 10000 | 3,683.1 μs | 57.01 μs | 33.92 μs |       - |  159.7 KB |
