```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId          | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetMama** |   **903.8 μs** | **38.32 μs** | **25.34 μs** |  **1.00** |    **0.04** |  **164.02 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetMama |   115.5 μs |  0.95 μs |  0.57 μs |  0.13 |    0.00 |  248.91 KB |        1.52 |
|            |       |                 |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetMama** | **8,678.8 μs** | **19.59 μs** | **10.25 μs** |  **1.00** |    **0.00** | **1593.38 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetMama | 1,155.9 μs | 28.55 μs | 18.89 μs |  0.13 |    0.00 | 2410.36 KB |        1.51 |
