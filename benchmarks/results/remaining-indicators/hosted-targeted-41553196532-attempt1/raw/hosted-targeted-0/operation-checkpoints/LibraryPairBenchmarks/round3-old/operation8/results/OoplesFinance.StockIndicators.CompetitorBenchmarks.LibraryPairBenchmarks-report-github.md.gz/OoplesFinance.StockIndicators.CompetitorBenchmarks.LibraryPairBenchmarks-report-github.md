```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)dline [27]** |  **1.618 ms** | **0.0307 ms** | **0.0183 ms** |  **1.00** |    **0.02** |  **110.05 KB** |        **1.00** |
|        |       |                      |           |           |           |       |         |            |             |
| **Ooples** | **10000** | **TaLib(...)dline [27]** | **16.175 ms** | **0.0842 ms** | **0.0440 ms** |  **1.00** |    **0.00** | **1038.44 KB** |        **1.00** |
