```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)dline [22]** | **1,002.4 μs** |  **61.50 μs** | **36.60 μs** |  **1.00** |    **0.05** |  **222.91 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)dline [22] |   154.8 μs |   7.67 μs |  4.56 μs |  0.15 |    0.01 |  288.23 KB |        1.29 |
|            |       |                      |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)dline [22]** | **9,225.8 μs** | **106.52 μs** | **63.39 μs** |  **1.00** |    **0.01** | **2152.91 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)dline [22] | 1,556.7 μs |  49.83 μs | 32.96 μs |  0.17 |    0.00 |  2812.7 KB |        1.31 |
