```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dMode [27]** |  **1,550.6 μs** |  **83.25 μs** |  **55.06 μs** |  **1.00** |    **0.05** |  **112.68 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dMode [27] |    490.1 μs |  19.43 μs |  12.85 μs |  0.32 |    0.01 |   33.59 KB |        0.30 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)dMode [27]** | **15,178.6 μs** | **235.86 μs** | **123.36 μs** |  **1.00** |    **0.01** | **1042.38 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dMode [27] |  5,156.5 μs | 187.45 μs | 123.99 μs |  0.34 |    0.01 |  286.59 KB |        0.27 |
