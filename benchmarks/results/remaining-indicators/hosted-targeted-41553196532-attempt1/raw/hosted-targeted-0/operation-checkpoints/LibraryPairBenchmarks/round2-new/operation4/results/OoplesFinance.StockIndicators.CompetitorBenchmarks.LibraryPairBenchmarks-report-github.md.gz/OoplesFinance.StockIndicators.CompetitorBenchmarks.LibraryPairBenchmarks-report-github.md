```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Phase [25]** |   **933.6 μs** |  **26.47 μs** |  **15.75 μs** |  **1.00** |    **0.02** |  **110.06 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Phase [25] |   427.6 μs |  10.90 μs |   7.21 μs |  0.46 |    0.01 |   39.51 KB |        0.36 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)Phase [25]** | **9,480.5 μs** | **263.86 μs** | **174.53 μs** |  **1.00** |    **0.02** | **1038.45 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Phase [25] | 4,617.7 μs | 288.35 μs | 190.73 μs |  0.49 |    0.02 |  328.89 KB |        0.32 |
