```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)hasor [24]** |   **531.53 μs** | **44.438 μs** | **29.393 μs** |  **1.00** |    **0.07** |  **164.05 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)hasor [24] |    97.55 μs |  1.553 μs |  0.812 μs |  0.18 |    0.01 |    71.2 KB |        0.43 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)hasor [24]** | **4,858.50 μs** | **90.898 μs** | **54.092 μs** |  **1.00** |    **0.01** | **1592.14 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)hasor [24] |   966.41 μs | 17.110 μs | 10.182 μs |  0.20 |    0.00 |   652.3 KB |        0.41 |
