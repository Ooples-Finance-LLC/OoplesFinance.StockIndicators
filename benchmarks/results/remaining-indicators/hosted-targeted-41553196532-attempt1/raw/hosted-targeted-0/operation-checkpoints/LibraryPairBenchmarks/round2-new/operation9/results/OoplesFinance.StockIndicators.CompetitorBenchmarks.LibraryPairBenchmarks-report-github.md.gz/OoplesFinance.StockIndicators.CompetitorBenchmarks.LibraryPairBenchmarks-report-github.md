```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Mama** |   **591.7 μs** |  **20.42 μs** | **12.15 μs** |  **1.00** |    **0.03** | **164.02 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Mama |   118.2 μs |   3.03 μs |  1.80 μs |  0.20 |    0.00 |  73.13 KB |        0.45 |
|            |       |                      |            |           |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Mama** | **5,428.9 μs** | **141.72 μs** | **74.12 μs** |  **1.00** |    **0.02** | **1593.7 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Mama | 1,110.2 μs |  11.84 μs |  7.83 μs |  0.20 |    0.00 | 652.22 KB |        0.41 |
