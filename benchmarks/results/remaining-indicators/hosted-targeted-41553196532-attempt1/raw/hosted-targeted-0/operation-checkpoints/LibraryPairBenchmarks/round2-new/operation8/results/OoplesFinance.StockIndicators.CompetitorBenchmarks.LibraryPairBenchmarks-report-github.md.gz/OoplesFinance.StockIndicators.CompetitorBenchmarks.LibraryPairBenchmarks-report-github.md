```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dline [27]** |   **950.9 μs** |  **64.84 μs** |  **38.58 μs** |  **1.00** |    **0.05** |  **110.05 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dline [27] |   125.1 μs |   1.10 μs |   0.66 μs |  0.13 |    0.00 |   36.55 KB |        0.33 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)dline [27]** | **8,923.6 μs** | **351.64 μs** | **232.59 μs** |  **1.00** |    **0.04** | **1039.09 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dline [27] | 1,209.2 μs |  13.94 μs |   9.22 μs |  0.14 |    0.00 |  331.19 KB |        0.32 |
