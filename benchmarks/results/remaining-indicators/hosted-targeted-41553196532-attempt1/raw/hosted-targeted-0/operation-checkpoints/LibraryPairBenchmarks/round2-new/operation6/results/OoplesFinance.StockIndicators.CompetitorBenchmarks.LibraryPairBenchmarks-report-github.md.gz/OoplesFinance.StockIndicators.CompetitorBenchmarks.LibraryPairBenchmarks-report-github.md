```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tSine [22]** |   **966.6 μs** |  **22.69 μs** | **13.50 μs** |  **1.00** |    **0.02** |  **166.46 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tSine [22] |   466.9 μs |  17.54 μs | 11.60 μs |  0.48 |    0.01 |   73.91 KB |        0.44 |
|            |       |                      |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)tSine [22]** | **9,529.4 μs** |  **56.68 μs** | **33.73 μs** |  **1.00** |    **0.00** | **1594.51 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tSine [22] | 4,681.8 μs | 100.52 μs | 66.49 μs |  0.49 |    0.01 |  651.08 KB |        0.41 |
