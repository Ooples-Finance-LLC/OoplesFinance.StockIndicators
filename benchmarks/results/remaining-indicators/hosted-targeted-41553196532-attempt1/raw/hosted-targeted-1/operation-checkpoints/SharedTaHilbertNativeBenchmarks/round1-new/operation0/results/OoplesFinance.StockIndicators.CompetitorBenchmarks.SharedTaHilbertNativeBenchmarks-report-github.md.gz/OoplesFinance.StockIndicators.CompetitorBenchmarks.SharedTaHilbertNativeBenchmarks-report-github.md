```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **4.277 ms** | **1.4507 ms** | **0.8633 ms** |  **69.13 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1.110 ms | 0.0212 ms | 0.0126 ms |  21.39 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **11.770 ms** | **0.2734 ms** | **0.1627 ms** | **632.63 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 11.612 ms | 0.2752 ms | 0.1439 ms | 162.63 KB |
