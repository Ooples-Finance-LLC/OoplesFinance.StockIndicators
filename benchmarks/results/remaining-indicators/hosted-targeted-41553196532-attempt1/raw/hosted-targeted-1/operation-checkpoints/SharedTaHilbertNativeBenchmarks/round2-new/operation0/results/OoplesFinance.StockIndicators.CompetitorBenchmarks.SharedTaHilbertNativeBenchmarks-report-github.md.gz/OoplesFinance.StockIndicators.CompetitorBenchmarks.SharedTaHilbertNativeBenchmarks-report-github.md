```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **3,532.6 μs** | **1,466.42 μs** | **969.95 μs** |  **6.84** |    **1.79** |  **69.13 KB** |        **8.24** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1,117.5 μs |    13.35 μs |   8.83 μs |  2.16 |    0.02 |  21.39 KB |        2.55 |
| NativeSingle      | TaLib(...)Phase [25] | 1000  |    516.8 μs |     1.93 μs |   1.15 μs |  1.00 |    0.00 |   8.39 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 1000  |    697.7 μs |    48.78 μs |  32.26 μs |  1.35 |    0.06 |  30.19 KB |        3.60 |
|                   |                      |       |             |             |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **11,759.2 μs** |   **250.90 μs** | **131.22 μs** |  **2.12** |    **0.03** |  **632.7 KB** |        **8.02** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 11,661.5 μs |   125.85 μs |  74.89 μs |  2.11 |    0.02 | 162.85 KB |        2.06 |
| NativeSingle      | TaLib(...)Phase [25] | 10000 |  5,534.1 μs |    72.06 μs |  37.69 μs |  1.00 |    0.01 |  78.91 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 10000 |  6,953.5 μs |   186.44 μs |  97.51 μs |  1.26 |    0.02 | 276.82 KB |        3.51 |
