```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **2.519 ms** | **0.0488 ms** | **0.0323 ms** |  **85.02 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1.757 ms | 0.0630 ms | 0.0375 ms |  37.34 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **18.467 ms** | **0.1306 ms** | **0.0683 ms** | **789.33 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 18.447 ms | 0.2251 ms | 0.1339 ms | 319.66 KB |
