```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dline [27]** | **1000**  |    **991.6 μs** |  **15.72 μs** |   **9.35 μs** |  **9.40** |    **0.11** |  **69.22 KB** |        **8.70** |
| BuilderLatestOnly | TaLib(...)dline [27] | 1000  |    965.6 μs |  12.87 μs |   7.66 μs |  9.16 |    0.10 |  21.55 KB |        2.71 |
| NativeSingle      | TaLib(...)dline [27] | 1000  |    105.5 μs |   1.22 μs |   0.81 μs |  1.00 |    0.01 |   7.95 KB |        1.00 |
| NativeParallel    | TaLib(...)dline [27] | 1000  |    158.4 μs |  11.44 μs |   7.57 μs |  1.50 |    0.07 |  28.52 KB |        3.59 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)dline [27]** | **10000** | **10,192.1 μs** | **138.65 μs** |  **82.51 μs** |  **8.27** |    **0.11** | **632.62 KB** |        **8.08** |
| BuilderLatestOnly | TaLib(...)dline [27] | 10000 | 10,022.3 μs | 209.43 μs | 124.63 μs |  8.13 |    0.13 | 162.88 KB |        2.08 |
| NativeSingle      | TaLib(...)dline [27] | 10000 |  1,233.2 μs |  20.22 μs |  13.37 μs |  1.00 |    0.01 |  78.31 KB |        1.00 |
| NativeParallel    | TaLib(...)dline [27] | 10000 |  1,627.9 μs |  93.18 μs |  55.45 μs |  1.32 |    0.04 | 274.72 KB |        3.51 |
