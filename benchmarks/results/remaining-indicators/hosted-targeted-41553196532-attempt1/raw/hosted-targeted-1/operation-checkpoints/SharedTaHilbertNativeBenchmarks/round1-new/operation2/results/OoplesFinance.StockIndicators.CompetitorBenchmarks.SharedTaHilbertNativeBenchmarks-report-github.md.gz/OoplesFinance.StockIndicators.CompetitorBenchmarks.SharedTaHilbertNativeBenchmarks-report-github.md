```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev   | Allocated |
|------------------ |--------------------- |------ |------------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)dline [27]** | **1000**  |  **1,036.2 μs** |  **95.70 μs** | **63.30 μs** |  **69.15 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 1000  |    987.5 μs |  18.30 μs | 10.89 μs |   21.6 KB |
| **BuilderFull**       | **TaLib(...)dline [27]** | **10000** | **10,377.8 μs** | **153.04 μs** | **80.04 μs** | **632.82 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 10000 | 10,320.9 μs |  81.03 μs | 42.38 μs | 162.97 KB |
