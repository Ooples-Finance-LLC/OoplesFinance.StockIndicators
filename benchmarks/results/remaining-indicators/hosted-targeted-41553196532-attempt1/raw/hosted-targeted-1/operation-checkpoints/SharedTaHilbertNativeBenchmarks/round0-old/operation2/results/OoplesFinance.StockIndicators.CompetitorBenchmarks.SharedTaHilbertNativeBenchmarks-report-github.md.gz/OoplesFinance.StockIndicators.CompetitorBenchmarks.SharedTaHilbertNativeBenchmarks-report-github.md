```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dline [27]** | **1000**  |  **2.218 ms** | **0.0733 ms** | **0.0485 ms** |  **69.29 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 1000  |  1.740 ms | 0.0451 ms | 0.0268 ms |  21.66 KB |
| **BuilderFull**       | **TaLib(...)dline [27]** | **10000** | **18.046 ms** | **0.3706 ms** | **0.2205 ms** | **633.33 KB** |
| BuilderLatestOnly | TaLib(...)dline [27] | 10000 | 17.927 ms | 0.1209 ms | 0.0719 ms | 163.51 KB |
