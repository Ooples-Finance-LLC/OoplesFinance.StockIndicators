```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **4.759 ms** | **1.0943 ms** | **0.7238 ms** |  **85.02 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1.763 ms | 0.0173 ms | 0.0103 ms |  37.34 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **18.686 ms** | **0.2300 ms** | **0.1369 ms** | **789.47 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 18.711 ms | 0.6595 ms | 0.4362 ms | 319.61 KB |
