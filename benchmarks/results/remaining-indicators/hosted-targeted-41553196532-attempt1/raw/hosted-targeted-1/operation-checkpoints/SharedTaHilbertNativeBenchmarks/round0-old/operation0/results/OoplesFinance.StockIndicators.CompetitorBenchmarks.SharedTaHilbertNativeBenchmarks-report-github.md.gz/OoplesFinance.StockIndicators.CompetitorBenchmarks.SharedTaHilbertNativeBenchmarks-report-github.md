```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **3.004 ms** | **0.0659 ms** | **0.0436 ms** |  **69.13 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1.763 ms | 0.0302 ms | 0.0200 ms |  21.44 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **18.407 ms** | **0.2929 ms** | **0.1937 ms** | **632.79 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 18.512 ms | 0.1568 ms | 0.0933 ms | 163.25 KB |
