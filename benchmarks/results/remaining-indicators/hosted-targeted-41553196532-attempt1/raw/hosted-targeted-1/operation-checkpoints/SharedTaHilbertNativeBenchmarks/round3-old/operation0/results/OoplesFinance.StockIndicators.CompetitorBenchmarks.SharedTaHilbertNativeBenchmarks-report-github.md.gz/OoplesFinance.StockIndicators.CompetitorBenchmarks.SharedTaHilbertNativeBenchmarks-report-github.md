```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **4.909 ms** | **4.0557 ms** | **2.6826 ms** |  **69.13 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1.783 ms | 0.0166 ms | 0.0087 ms |  21.44 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **18.827 ms** | **0.3555 ms** | **0.2115 ms** | **633.11 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 18.612 ms | 0.2269 ms | 0.1187 ms | 163.15 KB |
