```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **1,555.8 μs** |  **58.60 μs** |  **34.87 μs** |  **2.89** |    **0.07** |  **85.02 KB** |        **5.40** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1,076.9 μs |  16.92 μs |  10.07 μs |  2.00 |    0.02 |  37.28 KB |        2.37 |
| NativeSingle      | TaLib(...)tSine [22] | 1000  |    538.8 μs |   6.69 μs |   4.42 μs |  1.00 |    0.01 |  15.74 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 1000  |    753.3 μs |  55.33 μs |  36.60 μs |  1.40 |    0.07 |  55.96 KB |        3.56 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **11,758.5 μs** | **177.28 μs** | **117.26 μs** |  **2.00** |    **0.03** | **789.21 KB** |        **5.04** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 11,591.0 μs | 159.28 μs |  83.31 μs |  1.97 |    0.03 | 319.37 KB |        2.04 |
| NativeSingle      | TaLib(...)tSine [22] | 10000 |  5,876.6 μs | 116.61 μs |  69.39 μs |  1.00 |    0.02 | 156.56 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 10000 |  7,442.0 μs | 254.14 μs | 151.24 μs |  1.27 |    0.03 | 548.77 KB |        3.51 |
