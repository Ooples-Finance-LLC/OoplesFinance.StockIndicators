```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  |   **899.9 μs** |  **19.76 μs** |  **11.76 μs** |  **6.83** |    **0.15** |        **-** |        **-** |        **-** |  **100.89 KB** |        **0.49** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  |   893.4 μs |  29.85 μs |  17.77 μs |  6.78 |    0.17 |        - |        - |        - |   53.27 KB |        0.26 |
| NativeSingle      | Skend(...)dline [22] | 1000  |   131.9 μs |   3.71 μs |   2.45 μs |  1.00 |    0.02 |   1.9531 |        - |        - |  207.71 KB |        1.00 |
| NativeParallel    | Skend(...)dline [22] | 1000  |   192.4 μs |   5.87 μs |   3.07 μs |  1.46 |    0.03 |   5.8594 |        - |        - |  528.53 KB |        2.54 |
|                   |                      |       |            |           |           |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **8,912.1 μs** |  **94.27 μs** |  **56.10 μs** |  **5.49** |    **0.30** |        **-** |        **-** |        **-** |   **945.6 KB** |        **0.46** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 8,846.4 μs |  74.97 μs |  44.61 μs |  5.45 |    0.30 |        - |        - |        - |  475.76 KB |        0.23 |
| NativeSingle      | Skend(...)dline [22] | 10000 | 1,627.8 μs | 138.94 μs |  91.90 μs |  1.00 |    0.08 |  78.1250 |  62.5000 |  62.5000 | 2071.59 KB |        1.00 |
| NativeParallel    | Skend(...)dline [22] | 10000 | 2,530.7 μs | 204.29 μs | 135.13 μs |  1.56 |    0.12 | 187.5000 | 171.8750 | 140.6250 | 5258.69 KB |        2.54 |
