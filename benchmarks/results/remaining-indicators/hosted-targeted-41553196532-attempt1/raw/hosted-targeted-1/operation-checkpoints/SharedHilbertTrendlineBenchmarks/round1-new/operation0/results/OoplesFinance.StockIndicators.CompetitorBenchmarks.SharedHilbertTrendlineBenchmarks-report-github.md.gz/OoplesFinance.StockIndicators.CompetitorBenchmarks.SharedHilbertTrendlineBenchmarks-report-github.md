```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  |   **906.0 μs** |  **35.03 μs** |  **20.84 μs** | **100.89 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  |   874.7 μs |  11.10 μs |   7.34 μs |  53.26 KB |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **8,771.9 μs** | **189.60 μs** | **112.83 μs** |  **945.6 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 8,694.5 μs | 148.20 μs |  88.19 μs | 475.78 KB |
