```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Skend(...)dline [22]** | **1000**  |  **2.038 ms** | **0.0457 ms** | **0.0272 ms** | **100.96 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 1000  |  1.425 ms | 0.0457 ms | 0.0302 ms |  53.26 KB |
| **BuilderFull**       | **Skend(...)dline [22]** | **10000** | **13.665 ms** | **0.2163 ms** | **0.1287 ms** | **946.06 KB** |
| BuilderLatestOnly | Skend(...)dline [22] | 10000 | 13.501 ms | 0.1658 ms | 0.1097 ms | 476.14 KB |
