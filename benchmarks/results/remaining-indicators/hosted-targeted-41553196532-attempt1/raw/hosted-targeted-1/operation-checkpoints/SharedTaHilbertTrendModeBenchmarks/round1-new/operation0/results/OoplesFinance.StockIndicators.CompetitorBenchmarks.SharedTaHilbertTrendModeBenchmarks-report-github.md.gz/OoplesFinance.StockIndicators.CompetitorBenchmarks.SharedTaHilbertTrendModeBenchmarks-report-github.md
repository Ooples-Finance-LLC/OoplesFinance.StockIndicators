```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **6.433 ms** | **5.6249 ms** | **3.7205 ms** |  **71.75 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1.674 ms | 0.0189 ms | 0.0113 ms |  24.07 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **17.797 ms** | **0.2095 ms** | **0.1096 ms** | **635.57 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 17.681 ms | 0.2100 ms | 0.1250 ms | 165.65 KB |
