```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **2.442 ms** | **0.0406 ms** | **0.0242 ms** |  **71.75 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  2.421 ms | 0.0494 ms | 0.0259 ms |  24.06 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **25.515 ms** | **0.1808 ms** | **0.1076 ms** | **636.49 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 25.332 ms | 0.2340 ms | 0.1224 ms | 165.93 KB |
