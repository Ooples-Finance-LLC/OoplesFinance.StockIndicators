```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **2.752 ms** | **0.0798 ms** | **0.0475 ms** |  **71.75 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  2.438 ms | 0.0229 ms | 0.0136 ms |  24.05 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **25.733 ms** | **0.7988 ms** | **0.4754 ms** | **636.42 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 25.260 ms | 0.3383 ms | 0.1770 ms | 166.52 KB |
