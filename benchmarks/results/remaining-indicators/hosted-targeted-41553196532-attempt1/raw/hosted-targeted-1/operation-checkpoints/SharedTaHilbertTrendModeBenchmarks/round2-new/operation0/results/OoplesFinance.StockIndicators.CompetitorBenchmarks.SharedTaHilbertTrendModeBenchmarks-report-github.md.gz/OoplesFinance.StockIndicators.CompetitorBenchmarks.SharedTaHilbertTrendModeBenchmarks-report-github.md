```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Median      | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **4,785.8 μs** | **5,067.43 μs** | **3,351.79 μs** |  **2,865.8 μs** |  **8.27** |    **5.52** |  **71.75 KB** |       **15.17** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  1,679.0 μs |    29.16 μs |    17.35 μs |  1,675.3 μs |  2.90 |    0.03 |  24.07 KB |        5.09 |
| NativeSingle      | TaLib(...)dMode [27] | 1000  |    579.0 μs |     6.59 μs |     3.92 μs |    579.8 μs |  1.00 |    0.01 |   4.73 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 1000  |    789.9 μs |    49.16 μs |    32.51 μs |    774.9 μs |  1.36 |    0.05 |   17.4 KB |        3.68 |
|                   |                      |       |             |             |             |             |       |         |           |             |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **17,825.8 μs** |   **459.89 μs** |   **304.19 μs** | **17,735.7 μs** |  **2.83** |    **0.05** | **635.41 KB** |       **15.75** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 17,702.7 μs |   236.41 μs |   123.65 μs | 17,670.5 μs |  2.81 |    0.02 | 165.97 KB |        4.12 |
| NativeSingle      | TaLib(...)dMode [27] | 10000 |  6,289.9 μs |    49.88 μs |    29.68 μs |  6,306.7 μs |  1.00 |    0.01 |  40.33 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 10000 |  8,102.3 μs |   540.95 μs |   282.93 μs |  7,976.2 μs |  1.29 |    0.04 | 141.02 KB |        3.50 |
