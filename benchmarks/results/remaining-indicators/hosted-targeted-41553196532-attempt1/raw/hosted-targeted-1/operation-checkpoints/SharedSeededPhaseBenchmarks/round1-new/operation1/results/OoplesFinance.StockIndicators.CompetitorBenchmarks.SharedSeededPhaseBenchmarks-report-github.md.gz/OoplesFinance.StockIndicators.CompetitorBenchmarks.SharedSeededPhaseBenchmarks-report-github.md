```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetMama** | **1000**  |   **604.6 μs** | **12.67 μs** |  **8.38 μs** |  **82.61 KB** |
| BuilderLatestOnly | Skender.GetMama | 1000  |   599.3 μs |  4.30 μs |  2.56 μs |  35.02 KB |
| **BuilderFull**       | **Skender.GetMama** | **10000** | **6,005.0 μs** | **46.36 μs** | **24.25 μs** | **786.31 KB** |
| BuilderLatestOnly | Skender.GetMama | 10000 | 5,952.6 μs | 75.40 μs | 39.44 μs |  316.5 KB |
