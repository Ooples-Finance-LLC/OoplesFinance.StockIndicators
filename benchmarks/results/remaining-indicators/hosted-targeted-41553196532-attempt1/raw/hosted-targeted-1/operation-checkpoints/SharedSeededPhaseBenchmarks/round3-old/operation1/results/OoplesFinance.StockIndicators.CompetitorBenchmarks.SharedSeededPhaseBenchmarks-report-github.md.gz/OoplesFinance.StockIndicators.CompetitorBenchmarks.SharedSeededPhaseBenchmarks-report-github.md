```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |---------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Skender.GetMama** | **1000**  |  **1.628 ms** | **0.0309 ms** | **0.0204 ms** |  **82.73 KB** |
| BuilderLatestOnly | Skender.GetMama | 1000  |  1.197 ms | 0.0107 ms | 0.0056 ms |  35.06 KB |
| **BuilderFull**       | **Skender.GetMama** | **10000** | **11.459 ms** | **0.2130 ms** | **0.1114 ms** | **786.93 KB** |
| BuilderLatestOnly | Skender.GetMama | 10000 | 11.239 ms | 0.1709 ms | 0.1017 ms | 317.15 KB |
