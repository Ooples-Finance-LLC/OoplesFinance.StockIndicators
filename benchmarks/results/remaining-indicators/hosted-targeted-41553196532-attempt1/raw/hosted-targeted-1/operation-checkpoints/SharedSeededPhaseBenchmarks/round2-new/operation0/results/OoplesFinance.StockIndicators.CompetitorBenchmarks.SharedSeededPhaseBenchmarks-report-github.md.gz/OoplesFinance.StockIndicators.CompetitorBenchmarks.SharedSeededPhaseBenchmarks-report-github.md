```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |-----------:|----------:|----------:|------:|--------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Mama** | **1000**  |   **615.8 μs** |  **10.53 μs** |   **5.51 μs** |  **2.50** |    **0.03** |       **-** |       **-** |       **-** |   **82.61 KB** |        **1.47** |
| BuilderLatestOnly | QuanTAlib.Mama | 1000  |   599.1 μs |   4.66 μs |   2.77 μs |  2.44 |    0.02 |       - |       - |       - |      35 KB |        0.62 |
| NativeSingle      | QuanTAlib.Mama | 1000  |   245.8 μs |   3.64 μs |   2.16 μs |  1.00 |    0.01 |       - |       - |       - |   56.25 KB |        1.00 |
| NativeParallel    | QuanTAlib.Mama | 1000  |   364.2 μs |  12.04 μs |   6.30 μs |  1.48 |    0.03 |       - |       - |       - |  119.62 KB |        2.13 |
|                   |                |       |            |           |           |       |         |         |         |         |            |             |
| **BuilderFull**       | **QuanTAlib.Mama** | **10000** | **5,984.4 μs** | **151.34 μs** | **100.10 μs** |  **2.37** |    **0.05** |       **-** |       **-** |       **-** |  **786.62 KB** |        **1.43** |
| BuilderLatestOnly | QuanTAlib.Mama | 10000 | 5,910.5 μs |  88.65 μs |  46.37 μs |  2.34 |    0.04 |       - |       - |       - |   316.5 KB |        0.58 |
| NativeSingle      | QuanTAlib.Mama | 10000 | 2,524.7 μs |  58.60 μs |  34.87 μs |  1.00 |    0.02 | 31.2500 | 31.2500 | 31.2500 |   548.8 KB |        1.00 |
| NativeParallel    | QuanTAlib.Mama | 10000 | 3,593.4 μs | 185.50 μs |  97.02 μs |  1.42 |    0.04 |       - |       - |       - | 1139.37 KB |        2.08 |
