```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |---------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **Skender.GetMama** | **1000**  |  **1.580 ms** | **0.0618 ms** | **0.0409 ms** |  **82.73 KB** |
| BuilderLatestOnly | Skender.GetMama | 1000  |  1.218 ms | 0.0362 ms | 0.0239 ms |  35.06 KB |
| **BuilderFull**       | **Skender.GetMama** | **10000** | **11.550 ms** | **0.1610 ms** | **0.0842 ms** | **786.96 KB** |
| BuilderLatestOnly | Skender.GetMama | 10000 | 11.352 ms | 0.1027 ms | 0.0537 ms | 317.27 KB |
