```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |-----------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetMama** | **1000**  |   **618.8 μs** |   **7.43 μs** |   **4.42 μs** |  **4.73** |    **0.10** |        **-** |        **-** |        **-** |   **82.61 KB** |        **0.43** |
| BuilderLatestOnly | Skender.GetMama | 1000  |   620.0 μs |  17.53 μs |  11.60 μs |  4.74 |    0.13 |        - |        - |        - |   35.02 KB |        0.18 |
| NativeSingle      | Skender.GetMama | 1000  |   130.8 μs |   4.22 μs |   2.79 μs |  1.00 |    0.03 |   1.9531 |        - |        - |  192.06 KB |        1.00 |
| NativeParallel    | Skender.GetMama | 1000  |   196.6 μs |  12.14 μs |   7.22 μs |  1.50 |    0.06 |   5.8594 |        - |        - |  489.37 KB |        2.55 |
|                   |                 |       |            |           |           |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetMama** | **10000** | **6,080.1 μs** |  **95.55 μs** |  **49.98 μs** |  **4.04** |    **0.11** |        **-** |        **-** |        **-** |  **786.58 KB** |        **0.41** |
| BuilderLatestOnly | Skender.GetMama | 10000 | 6,055.7 μs | 124.34 μs |  73.99 μs |  4.02 |    0.11 |        - |        - |        - |  316.51 KB |        0.17 |
| NativeSingle      | Skender.GetMama | 10000 | 1,507.3 μs |  69.64 μs |  41.44 μs |  1.00 |    0.04 |  78.1250 |  62.5000 |  62.5000 | 1915.68 KB |        1.00 |
| NativeParallel    | Skender.GetMama | 10000 | 2,421.6 μs | 159.73 μs | 105.65 μs |  1.61 |    0.08 | 187.5000 | 171.8750 | 140.6250 | 4867.54 KB |        2.54 |
