```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **QuanTAlib.Mama** | **1000**  |  **1.298 ms** | **0.0366 ms** | **0.0218 ms** |  **82.73 KB** |
| BuilderLatestOnly | QuanTAlib.Mama | 1000  |  1.154 ms | 0.0102 ms | 0.0061 ms |  35.06 KB |
| **BuilderFull**       | **QuanTAlib.Mama** | **10000** | **11.347 ms** | **0.2148 ms** | **0.1278 ms** | **786.92 KB** |
| BuilderLatestOnly | QuanTAlib.Mama | 10000 | 11.339 ms | 0.1607 ms | 0.0956 ms | 317.04 KB |
