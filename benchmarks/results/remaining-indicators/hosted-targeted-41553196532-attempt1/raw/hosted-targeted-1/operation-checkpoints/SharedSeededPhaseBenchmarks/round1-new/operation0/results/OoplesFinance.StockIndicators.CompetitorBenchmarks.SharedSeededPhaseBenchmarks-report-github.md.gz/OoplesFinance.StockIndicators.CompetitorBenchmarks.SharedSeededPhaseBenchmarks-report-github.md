```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **QuanTAlib.Mama** | **1000**  |   **593.5 μs** |   **5.84 μs** |  **3.05 μs** |  **82.61 KB** |
| BuilderLatestOnly | QuanTAlib.Mama | 1000  |   586.3 μs |   8.44 μs |  4.41 μs |  35.02 KB |
| **BuilderFull**       | **QuanTAlib.Mama** | **10000** | **5,986.3 μs** | **107.50 μs** | **71.11 μs** | **786.31 KB** |
| BuilderLatestOnly | QuanTAlib.Mama | 10000 | 5,833.6 μs |  42.46 μs | 25.27 μs |  316.5 KB |
