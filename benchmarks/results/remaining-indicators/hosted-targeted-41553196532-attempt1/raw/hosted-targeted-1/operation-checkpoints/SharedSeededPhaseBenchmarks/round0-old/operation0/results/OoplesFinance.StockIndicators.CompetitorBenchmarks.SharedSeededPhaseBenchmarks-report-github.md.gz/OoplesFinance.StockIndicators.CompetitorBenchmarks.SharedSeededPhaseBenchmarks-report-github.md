```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **QuanTAlib.Mama** | **1000**  |  **1.283 ms** | **0.0317 ms** | **0.0209 ms** |  **82.73 KB** |
| BuilderLatestOnly | QuanTAlib.Mama | 1000  |  1.159 ms | 0.0270 ms | 0.0161 ms |  35.06 KB |
| **BuilderFull**       | **QuanTAlib.Mama** | **10000** | **11.291 ms** | **0.0915 ms** | **0.0479 ms** |    **787 KB** |
| BuilderLatestOnly | QuanTAlib.Mama | 10000 | 11.386 ms | 0.1039 ms | 0.0618 ms | 317.18 KB |
