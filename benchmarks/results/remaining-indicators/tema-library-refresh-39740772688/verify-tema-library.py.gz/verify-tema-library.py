from pathlib import Path
import hashlib,json,math,re,subprocess
root=Path('C:/Users/cheat/StockIndicators-Recovery-20261021');out=root/'tema-library-refresh-39740772688'
run=json.loads(subprocess.check_output(['gh','run','view','39740772688','--repo','Ooples-Finance-LLC/OoplesFinance.StockIndicators','--json','status,conclusion,headSha']))
assert run=={'status':'completed','conclusion':'success','headSha':'c3c27205554c5477f8d00ddd4f28595543f4bc9f'}
d=json.loads((out/'comparison.json').read_text());assert d['complete'] and d['run_id']=='39740772688' and d['workflow_sha']==run['headSha']
assert d['order']==['new'] and len(d['rounds'])==1
sources={'old':'29a41d8b7956a05812a5950631f07b84bcb04ee0','new':'0e62018ed67b73a18cd94c6320af6d0612a78af7'}
manifest=json.loads((out/'binary-manifest.json').read_text());assert manifest['old'].keys()==manifest['new'].keys()
assert [p for p in manifest['old'] if manifest['old'][p]!=manifest['new'][p]]==['OoplesFinance.StockIndicators.dll']
proof=json.loads((out/'provenance.json').read_text());assert proof['new_source']==sources['new'] and proof['old_source']==sources['old']
rows=[]
for index,round in enumerate(d['rounds']):
 assert round['order']==index and round['version']==d['order'][index] and round['source_sha']==sources[round['version']]
 path=out/Path(round['report_file']).relative_to('control');raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()==round['report_sha256']
 report=json.loads(raw);cases={}
 for case in report['Benchmarks']:
  name=case['FullName'];assert 'LibraryPairBenchmarks.' in name
  key=re.search(r'PairId: "([^"]+)"',name)[1],int(re.search(r'Bars: (\d+)',name)[1]),case['Method'];assert key not in cases
  stats=case['Statistics'];values=stats['OriginalValues'];ci=stats['ConfidenceInterval'];assert len(values)==stats['N']>=7
  assert all(math.isfinite(v) and v>0 for v in values) and math.isclose(sum(values)/len(values),stats['Mean'],rel_tol=1e-12)
  cases[key]={'pair':key[0],'bars':key[1],'method':key[2],'mean_ns':stats['Mean'],'lower_ns':ci['Lower'],'upper_ns':ci['Upper'],'samples':stats['N'],'allocated_bytes':case['Memory']['BytesAllocatedPerOperation']}
 assert cases.keys()=={(p,n,m) for p in ['QuanTAlib.Dema','QuanTAlib.Tema'] for n in [1000,10000] for m in ['Ooples','Competitor']}
 assert len(round['rows'])==8 and all(cases[r['pair'],r['bars'],r['method']]==r for r in round['rows'])
 rows.append(cases)
(out/'verified-summary.json').write_text(json.dumps({'run':run,'sources':sources,'all_8_cases_verified':True,'rows':d['rounds'][0]['rows']},indent=2),encoding='utf-8')
print('Verified all eight actual LibraryPair baseline arms')
