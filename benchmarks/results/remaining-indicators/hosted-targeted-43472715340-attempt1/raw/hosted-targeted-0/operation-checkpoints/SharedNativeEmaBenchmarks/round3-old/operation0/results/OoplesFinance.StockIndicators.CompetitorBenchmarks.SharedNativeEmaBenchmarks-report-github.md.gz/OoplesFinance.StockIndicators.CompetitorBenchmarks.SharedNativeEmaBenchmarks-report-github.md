```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Qema** | **1000**  |   **426.2 μs** |  **7.17 μs** | **3.75 μs** | **15.6250** |       **-** | **356.29 KB** |
| BuilderLatestOnly | QuanTAlib.Qema | 1000  |   421.6 μs |  6.40 μs | 3.35 μs | 15.6250 |       - | 308.43 KB |
| **BuilderFull**       | **QuanTAlib.Qema** | **10000** | **1,764.3 μs** | **10.52 μs** | **6.26 μs** | **46.8750** | **15.6250** | **848.94 KB** |
| BuilderLatestOnly | QuanTAlib.Qema | 10000 | 1,755.5 μs | 15.01 μs | 9.93 μs | 15.6250 |       - | 378.75 KB |
