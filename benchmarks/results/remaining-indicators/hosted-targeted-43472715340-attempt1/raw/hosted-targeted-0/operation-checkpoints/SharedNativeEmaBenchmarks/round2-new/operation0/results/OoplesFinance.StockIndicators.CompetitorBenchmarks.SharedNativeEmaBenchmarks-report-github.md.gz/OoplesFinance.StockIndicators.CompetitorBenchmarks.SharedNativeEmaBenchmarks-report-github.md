```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev   | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |-----------:|----------:|---------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Qema** | **1000**  |   **428.8 μs** |   **7.43 μs** |  **4.42 μs** |  **3.39** |    **0.08** |  **15.6250** |       **-** |  **356.29 KB** |        **1.74** |
| BuilderLatestOnly | QuanTAlib.Qema | 1000  |   425.5 μs |   6.29 μs |  3.74 μs |  3.36 |    0.08 |  15.6250 |       - |  308.43 KB |        1.50 |
| NativeSingle      | QuanTAlib.Qema | 1000  |   126.6 μs |   4.45 μs |  2.95 μs |  1.00 |    0.03 |  11.7188 |       - |  205.19 KB |        1.00 |
| NativeParallel    | QuanTAlib.Qema | 1000  |   411.7 μs |  31.06 μs | 20.54 μs |  3.25 |    0.17 |  29.2969 |       - |  504.46 KB |        2.46 |
|                   |                |       |            |           |          |       |         |          |         |            |             |
| **BuilderFull**       | **QuanTAlib.Qema** | **10000** | **1,685.3 μs** |   **9.27 μs** |  **6.13 μs** |  **1.39** |    **0.01** |  **46.8750** | **15.6250** |  **848.94 KB** |        **0.42** |
| BuilderLatestOnly | QuanTAlib.Qema | 10000 | 1,726.2 μs |  13.36 μs |  7.95 μs |  1.43 |    0.02 |  15.6250 |       - |  378.83 KB |        0.19 |
| NativeSingle      | QuanTAlib.Qema | 10000 | 1,209.9 μs |  18.53 μs | 12.26 μs |  1.00 |    0.01 | 117.1875 | 23.4375 | 2033.37 KB |        1.00 |
| NativeParallel    | QuanTAlib.Qema | 10000 | 2,303.6 μs | 111.77 μs | 73.93 μs |  1.90 |    0.06 | 296.8750 | 46.8750 | 4969.41 KB |        2.44 |
