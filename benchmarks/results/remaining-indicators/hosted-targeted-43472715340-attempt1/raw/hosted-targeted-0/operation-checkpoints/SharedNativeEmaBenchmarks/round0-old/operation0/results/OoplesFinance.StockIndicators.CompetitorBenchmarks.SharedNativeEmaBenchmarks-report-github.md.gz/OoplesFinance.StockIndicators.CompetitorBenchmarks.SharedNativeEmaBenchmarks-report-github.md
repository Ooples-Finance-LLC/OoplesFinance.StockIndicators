```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error   | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |-----------:|--------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Qema** | **1000**  |   **435.0 μs** | **7.74 μs** | **4.61 μs** | **15.6250** |       **-** | **356.29 KB** |
| BuilderLatestOnly | QuanTAlib.Qema | 1000  |   428.5 μs | 4.50 μs | 2.68 μs | 15.6250 |       - | 308.43 KB |
| **BuilderFull**       | **QuanTAlib.Qema** | **10000** | **1,683.1 μs** | **6.52 μs** | **3.41 μs** | **46.8750** | **15.6250** | **848.95 KB** |
| BuilderLatestOnly | QuanTAlib.Qema | 10000 | 1,693.0 μs | 8.14 μs | 4.26 μs | 15.6250 |       - | 378.84 KB |
