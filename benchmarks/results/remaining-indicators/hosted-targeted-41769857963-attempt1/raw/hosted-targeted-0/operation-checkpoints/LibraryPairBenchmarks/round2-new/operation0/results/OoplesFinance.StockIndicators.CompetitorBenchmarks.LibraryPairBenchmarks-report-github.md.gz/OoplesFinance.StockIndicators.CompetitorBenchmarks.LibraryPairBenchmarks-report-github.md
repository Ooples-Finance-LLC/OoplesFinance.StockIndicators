```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)lopes [22]** |   **153.4 μs** |  **9.25 μs** |  **5.51 μs** |  **1.00** |    **0.05** |   **188.8 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)lopes [22] |   104.3 μs |  1.98 μs |  1.18 μs |  0.68 |    0.02 |  286.83 KB |        1.52 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)lopes [22]** | **1,093.6 μs** | **40.49 μs** | **24.09 μs** |  **1.00** |    **0.03** |  **1840.8 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)lopes [22] | 1,206.1 μs | 44.28 μs | 29.29 μs |  1.10 |    0.03 | 2774.13 KB |        1.51 |
