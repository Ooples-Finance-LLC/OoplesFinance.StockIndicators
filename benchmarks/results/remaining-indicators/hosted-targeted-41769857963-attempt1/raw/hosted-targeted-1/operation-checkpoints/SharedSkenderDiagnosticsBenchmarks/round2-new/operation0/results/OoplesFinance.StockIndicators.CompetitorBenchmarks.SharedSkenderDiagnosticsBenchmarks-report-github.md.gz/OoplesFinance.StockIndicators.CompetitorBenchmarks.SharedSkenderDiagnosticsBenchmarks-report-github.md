```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)lopes [22]** | **1000**  |   **236.64 μs** | **157.634 μs** | **104.265 μs** |  **3.33** |    **1.40** |   **3.9063** |        **-** |        **-** |   **83.62 KB** |        **0.39** |
| BuilderLatestOnly | Skend(...)lopes [22] | 1000  |    68.64 μs |   1.650 μs |   0.982 μs |  0.97 |    0.02 |   1.9531 |        - |        - |   35.97 KB |        0.17 |
| NativeSingle      | Skend(...)lopes [22] | 1000  |    71.07 μs |   1.422 μs |   0.744 μs |  1.00 |    0.01 |  12.6953 |   1.9531 |        - |  211.88 KB |        1.00 |
| NativeParallel    | Skend(...)lopes [22] | 1000  |    51.94 μs |   5.522 μs |   3.652 μs |  0.73 |    0.05 |  15.1367 |   3.4180 |        - |  234.75 KB |        1.11 |
|                   |                      |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skend(...)lopes [22]** | **10000** |   **535.68 μs** |  **78.486 μs** |  **51.914 μs** |  **0.26** |    **0.04** |  **46.8750** |  **19.5313** |        **-** |  **787.11 KB** |        **0.37** |
| BuilderLatestOnly | Skend(...)lopes [22] | 10000 |   476.08 μs |  44.837 μs |  29.657 μs |  0.23 |    0.03 |  15.6250 |   3.9063 |        - |  317.26 KB |        0.15 |
| NativeSingle      | Skend(...)lopes [22] | 10000 | 2,068.55 μs | 342.342 μs | 226.438 μs |  1.01 |    0.15 | 234.3750 | 218.7500 | 156.2500 | 2111.84 KB |        1.00 |
| NativeParallel    | Skend(...)lopes [22] | 10000 |   506.31 μs |  14.427 μs |   7.546 μs |  0.25 |    0.03 | 140.6250 |  66.4063 |        - | 2203.53 KB |        1.04 |
