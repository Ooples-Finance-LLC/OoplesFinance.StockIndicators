```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)lopes [22]** | **1000**  |  **88.42 μs** | **30.050 μs** | **19.876 μs** |  **3.9063** |       **-** |  **83.58 KB** |
| BuilderLatestOnly | Skend(...)lopes [22] | 1000  |  70.32 μs |  4.865 μs |  3.218 μs |  1.9531 |       - |  35.97 KB |
| **BuilderFull**       | **Skend(...)lopes [22]** | **10000** | **495.20 μs** | **55.387 μs** | **32.960 μs** | **46.8750** | **19.5313** | **787.11 KB** |
| BuilderLatestOnly | Skend(...)lopes [22] | 10000 | 477.68 μs | 85.614 μs | 56.628 μs | 15.6250 |  3.9063 | 317.26 KB |
