```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Beta** |   **248.71 μs** | **24.130 μs** | **15.960 μs** |  **1.00** |    **0.08** |  **106.25 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Beta |    10.88 μs |  0.602 μs |  0.315 μs |  0.04 |    0.00 |   40.48 KB |        0.38 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Beta** | **2,276.42 μs** | **17.341 μs** | **10.319 μs** |  **1.00** |    **0.01** | **1035.62 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Beta |    85.92 μs |  0.660 μs |  0.345 μs |  0.04 |    0.00 |  330.52 KB |        0.32 |
