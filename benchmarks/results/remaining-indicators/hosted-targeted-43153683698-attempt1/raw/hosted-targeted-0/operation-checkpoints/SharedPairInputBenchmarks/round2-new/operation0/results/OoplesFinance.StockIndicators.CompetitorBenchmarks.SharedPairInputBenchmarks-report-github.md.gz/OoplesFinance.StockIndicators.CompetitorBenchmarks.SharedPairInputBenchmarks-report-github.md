```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **180.384 μs** |  **1.3251 μs** |  **0.7885 μs** | **26.69** |    **0.14** |       **-** |      **-** |  **64.91 KB** |        **8.42** |
| BuilderLatestOnly | 1000  | Beta      |   177.743 μs |  0.7567 μs |  0.4503 μs | 26.30 |    0.10 |  0.9766 |      - |   17.3 KB |        2.24 |
| NativeSingle      | 1000  | Beta      |     6.758 μs |  0.0424 μs |  0.0222 μs |  1.00 |    0.00 |  0.4272 |      - |   7.71 KB |        1.00 |
| NativeParallel    | 1000  | Beta      |    79.085 μs |  1.0823 μs |  0.7159 μs | 11.70 |    0.11 |  0.4883 |      - |   7.98 KB |        1.03 |
|                   |       |           |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **10000** | **Beta**      | **1,867.483 μs** | **19.8189 μs** | **10.3657 μs** | **28.56** |    **0.17** | **31.2500** |      **-** | **627.88 KB** |        **8.05** |
| BuilderLatestOnly | 10000 | Beta      | 1,830.777 μs | 14.1385 μs |  8.4136 μs | 28.00 |    0.15 |       - |      - | 158.05 KB |        2.03 |
| NativeSingle      | 10000 | Beta      |    65.382 μs |  0.3537 μs |  0.2105 μs |  1.00 |    0.00 |  4.3945 | 0.4883 |  78.03 KB |        1.00 |
| NativeParallel    | 10000 | Beta      |   108.389 μs |  0.7363 μs |  0.3851 μs |  1.66 |    0.01 |  3.9063 |      - |   78.3 KB |        1.00 |
