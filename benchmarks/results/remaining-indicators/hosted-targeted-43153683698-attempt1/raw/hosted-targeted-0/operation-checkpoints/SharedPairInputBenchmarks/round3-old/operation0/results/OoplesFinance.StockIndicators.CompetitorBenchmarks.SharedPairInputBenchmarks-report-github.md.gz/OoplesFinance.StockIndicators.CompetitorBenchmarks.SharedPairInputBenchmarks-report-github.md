```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **391.2 μs** |   **6.95 μs** |   **4.13 μs** |       **-** |  **69.39 KB** |
| BuilderLatestOnly | 1000  | Beta      |   404.4 μs |  51.25 μs |  33.90 μs |       - |  21.67 KB |
| **BuilderFull**       | **10000** | **Beta**      | **3,228.9 μs** |  **67.23 μs** |  **35.16 μs** | **31.2500** | **632.38 KB** |
| BuilderLatestOnly | 10000 | Beta      | 3,338.9 μs | 258.30 μs | 170.85 μs |       - | 162.54 KB |
