```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **385.4 μs** |  **14.93 μs** |   **8.89 μs** |       **-** |  **69.36 KB** |
| BuilderLatestOnly | 1000  | Beta      |   372.1 μs |   6.62 μs |   3.46 μs |       - |  21.67 KB |
| **BuilderFull**       | **10000** | **Beta**      | **3,176.4 μs** |  **41.62 μs** |  **21.77 μs** | **31.2500** | **632.37 KB** |
| BuilderLatestOnly | 10000 | Beta      | 3,267.4 μs | 236.02 μs | 140.45 μs |       - | 162.53 KB |
