```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |------ |---------- |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **217.4 μs** |  **1.64 μs** |  **0.98 μs** |       **-** |  **64.91 KB** |
| BuilderLatestOnly | 1000  | Beta      |   222.4 μs |  1.61 μs |  1.07 μs |       - |   17.3 KB |
| **BuilderFull**       | **10000** | **Beta**      | **2,316.7 μs** | **35.64 μs** | **23.57 μs** | **31.2500** | **627.84 KB** |
| BuilderLatestOnly | 10000 | Beta      | 2,376.1 μs | 31.50 μs | 20.84 μs |       - | 158.01 KB |
