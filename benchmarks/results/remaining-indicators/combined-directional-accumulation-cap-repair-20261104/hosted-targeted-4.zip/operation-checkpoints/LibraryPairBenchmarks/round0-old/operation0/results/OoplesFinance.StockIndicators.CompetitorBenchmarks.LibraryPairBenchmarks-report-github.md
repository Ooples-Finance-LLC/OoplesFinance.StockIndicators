```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId             | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |------------------- |-----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Dx** |   **599.4 μs** | **35.40 μs** | **21.07 μs** |  **1.00** |    **0.05** | **105.67 KB** |        **1.00** |
|        |       |                    |            |          |          |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Dx** | **5,742.5 μs** | **47.22 μs** | **24.70 μs** |  **1.00** |    **0.01** | **1035.7 KB** |        **1.00** |
