from pathlib import Path
import gzip,hashlib,json,subprocess,importlib.util
root=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
repo=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
state=json.loads((root/'price-relative-ratio/status.json').read_text())
control=json.loads((root/'local-price-relative-ratio-control-20261028/verified-summary.json').read_text())
qualified=control['sources']['new']
assert control['all_32_cases_verified'] and not any(r['verdict']=='slower' for r in control['decisions']) and any(r['verdict']=='faster' for r in control['decisions'])
paths=['src','tests','examples','benchmarks/OoplesFinance.StockIndicators.CompetitorTests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','scripts','.github','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json','NuGet.Config','nuget.config']
subprocess.run(['git','diff','--exit-code',qualified,'HEAD','--',*paths],cwd=repo,check=True)
for label in ['unit','parity']:
 raw=gzip.decompress((repo/f'benchmarks/results/remaining-indicators/publication-price-relative-ratio-certified-20261028-{label}.trx.gz').read_bytes())
 assert hashlib.sha256(raw).hexdigest()==state[label]['sha256']
for path,digest in state['production_dll_sha256'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
spec=importlib.util.spec_from_file_location('gpu',repo/'scripts/verify-competitor-local-gpu.py');gpu=importlib.util.module_from_spec(spec);spec.loader.exec_module(gpu)
receipt=json.loads((gpu.EVIDENCE/'receipt.json').read_text());raw=gzip.decompress((gpu.EVIDENCE/'gpu.trx.gz').read_bytes())
gpu.verify_evidence(receipt,raw,json.loads(gpu.METHODS.read_text()),gpu.source_fingerprint(repo))
proof={'qualified_commit':subprocess.check_output(['git','rev-parse',qualified],cwd=repo,text=True).strip(),'qualified_code':state['input_head'],'matched_paths':paths,'source_fingerprint_sha256':receipt['source_sha256'],'qualification_reused':{'unit':18,'parity':11,'gpu':100,'inventory':8},'consumer_dll_hashes_rechecked':state['production_dll_sha256'],'control':'local-price-relative-ratio-control-20261028','note':'Integrated executable sources and build inputs exactly match qualified candidate. Publishing checkout binaries remain older; preserved candidate DLL supplied the new measurement arm. No redundant production rebuild.'}
(repo/'benchmarks/results/remaining-indicators/price-relative-ratio-integration-source-proof-20261028.json').write_text(json.dumps(proof,indent=2)+'\n')
print('Verified exact integrated source and qualified evidence')
