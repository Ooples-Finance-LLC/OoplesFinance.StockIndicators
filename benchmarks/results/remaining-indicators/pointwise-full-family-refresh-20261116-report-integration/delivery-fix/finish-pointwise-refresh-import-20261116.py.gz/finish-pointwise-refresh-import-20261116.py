"""Finish a verified import after correcting new archive metadata line endings."""
import gzip,hashlib,json,re,subprocess
from pathlib import Path
ops=Path(__file__).parent;checkpoint=ops/'continuation-latest-20261028.json'
name='pointwise-full-family-refresh-20261116'
d=json.loads(checkpoint.read_text());q=d['performance_continuation_20261103'][name]
repo=Path(d['publishing_checkout']);out=Path(q['report_out'])
imported=json.loads((out/'imported.json').read_text())
assert q['report_visual_verified'] and q['baseline_refresh_verified'] and not q['accepted']
live=Path('C:/Users/cheat/Documents/OoplesFinance-Reports/competitor-performance.html')
sha=hashlib.sha256(live.read_bytes()).hexdigest()
assert sha==imported['candidate_sha256']==json.loads((out/'browser-verification.json').read_text())['report_sha256']
assert imported['changed_builder_slots']==0 and imported['unchanged_rows']==764
archive=repo/'benchmarks/results/remaining-indicators'/(name+'-report-integration')
fix=out/'delivery-fix';fix.mkdir()
tooling=Path(q['tooling_checkout'])
for source in (tooling/'scripts/hosted_timing/archive.py',tooling/'scripts/test_hosted_report.py',ops/'import-pointwise-family-refresh-20261116.py',ops/'publish-pointwise-family-refresh-20261116.py',Path(__file__)):
    (fix/source.name).write_bytes(source.read_bytes())
(fix/'repair.json').write_bytes((json.dumps(dict(reason='Git whitespace check caught CRLF archive JSON under * -text after verified report import.',fix='Generated metadata normalized to LF without changing its JSON value; archive/import writers now emit LF bytes.',checks='Two affected archive tests passed. Measured/raw artifacts and verified report bytes unchanged.'),indent=2)+'\n').encode())
manifest=json.loads((archive/'manifest.json').read_text())
for path in sorted(fix.rglob('*')):
    if not path.is_file():continue
    content=path.read_bytes();relative=path.relative_to(out).as_posix();target=archive/(relative+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(gzip.compress(content,mtime=0));assert gzip.decompress(target.read_bytes())==content
    manifest[relative]=dict(sha256=hashlib.sha256(content).hexdigest(),archive=target.relative_to(repo).as_posix())
(archive/'manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
for folder in (archive,Path(q['archive'])):
    for path in folder.glob('*.json'):
        original=path.read_bytes();normalized=original.replace(b'\r\n',b'\n')
        assert json.loads(original)==json.loads(normalized)
        path.write_bytes(normalized)
decision=json.loads((Path(q['archive'])/'decision.json').read_text())
assert decision['report_imported'] and decision['report_sha256']==sha and not decision['accepted'] and not decision['production_integrated']
subprocess.run(['git','add','benchmarks/results/remaining-indicators'],cwd=repo,check=True)
with (out/'final-diff-check.log').open('wb') as log:
    subprocess.run(['git','diff','--cached','--check'],cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
subprocess.run(['git','commit','-m','perf: publish complete pointwise harness baseline refresh evidence'],cwd=repo,check=True,stdout=subprocess.DEVNULL)
rows=json.loads(re.search(r'<script[^>]*id="dataset"[^>]*>(.*?)</script>',live.read_text(encoding='utf-8'),re.S)[1])['rows']
wins={str(n):sum(r['bars']==n and r['competitor_over_ooples']>1 for r in rows) for n in (1000,10000)}
q.update(report_imported=True,report_sha256=sha,report_wins=wins,report_archive=str(archive),
    prepared_publication_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
    delivery_tooling_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=tooling,text=True).strip(),
    status='Complete harness baseline refresh imported and verified; draft publication pending')
checkpoint.write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(dict(report_sha256=sha,wins=wins,head=q['prepared_publication_head'])))
