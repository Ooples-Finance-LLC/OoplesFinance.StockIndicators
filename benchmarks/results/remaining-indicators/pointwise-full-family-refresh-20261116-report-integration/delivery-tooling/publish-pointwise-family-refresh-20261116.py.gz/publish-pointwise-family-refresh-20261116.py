"""Publish approved complete harness/report refresh, retaining every A/A verdict."""
import datetime,hashlib,json,re,subprocess,time
from pathlib import Path
ops=Path(__file__).parent;checkpoint=ops/'continuation-latest-20261028.json'
name='pointwise-full-family-refresh-20261116'
d=json.loads(checkpoint.read_text());q=d['performance_continuation_20261103'][name]
repo=Path(d['publishing_checkout']);endpoint='repos/Ooples-Finance-LLC/OoplesFinance.StockIndicators/pulls/266'
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
assert q['publication_if_verified_approved'] and q['baseline_refresh_verified'] and q['local_hosted_collection_equal']
assert q['report_imported'] and q['report_visual_verified'] and q['source_retention_verified']
assert not q['accepted'] and not q['production_qualification'] and not q['production_integrated']
assert not git('status','--porcelain')
head=git('rev-parse','HEAD');assert head==q['prepared_publication_head']
assert not git('diff',q['baseline'],head,'--','src','tests')
assert not git('diff',q['source'],head,'--','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','benchmarks/OoplesFinance.StockIndicators.CompetitorTests')
assert git('ls-remote','origin','refs/heads/perf/remaining-indicator-rollout').split()[0]==q['baseline']
live=Path('C:/Users/cheat/Documents/OoplesFinance-Reports/competitor-performance.html')
assert hashlib.sha256(live.read_bytes()).hexdigest()==q['report_sha256']
imported=json.loads((Path(q['report_out'])/'imported.json').read_text())
assert imported['candidate_sha256']==q['report_sha256'] and imported['changed_baseline_rows']==38 and imported['changed_builder_slots']==0
assert sum(imported['verdicts'].values())==1544
proof=json.loads(Path(q['refresh_result']).read_text())
assert proof['baseline_refresh_verified'] and not proof['accepted'] and not proof['production_qualification']
assert (proof['case_count'],proof['decision_count'])==(190,38)
assert proof['verdicts']==q['verdicts']
pr=json.loads(subprocess.check_output(['gh','api',endpoint]))
assert pr['head']['sha']==q['baseline'] and pr['draft'] and pr['auto_merge'] is None and pr['base']['ref']=='master'
marker='### Complete pointwise harness baseline refresh'
assert marker not in pr['body']
v=q['verdicts'];wins=q['report_wins']
section=f'''{marker}

The 19 pointwise benchmark adapters now project completed spans directly into owned comparison outputs, removing three intermediate arrays while preserving Full history, output bits and presence flags. Production indicator algorithms are unchanged. This is a benchmark-harness baseline refresh, not a production speedup qualification.

Fresh canonical verification passed 111 unit cases, 73 comparator cases and 100 actual local GPU contracts. The [complete measurement run](https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/{q['timing_run']}) covered 190 cases / 38 identical-binary A/A comparisons at both sizes, with at most two measurement runners. A/A outcomes were {v.get('faster',0)} faster, {v.get('slower',0)} slower and {v.get('inconclusive',0)} inconclusive; all are retained as timing variability, not source improvement or regression. Independent collection matched CI exactly. Existing warmups, ten measured iterations, default runtime and CPU gates were preserved.

The report refreshes all 38 affected batch rows and identifies canonical production, benchmark and fresh GPU evidence separately. Four owned rounds are reviewed against each native control measured in round two; mixed/inconclusive classifications remain uncertain. All 802 table/CSV comparisons and 1,544 unchanged builder comparisons were browser-verified and screenshots inspected. Point-estimate report wins are separate from four-round confirmed native wins.

Harness/report published at `{head[:9]}`. Publication CI is pending. Overall performance work remains open.
'''
intro,history=pr['body'].split('\n\n',1)
history,count=re.subn(r'The report shows \*\*.*?auto-merge disabled\.\s*','',history,count=1,flags=re.S);assert count==1
report=f"The report shows **{wins['1000']}/401 wins at 1,000 bars and {wins['10000']}/401 at 10,000 bars**; {401-wins['10000']} batch gaps remain by point estimate at 10,000 bars. Work continues with this PR kept draft, targeting master, with auto-merge disabled."
payload=ops/('pr266-'+name+'-body.json')
payload.write_text(json.dumps(dict(body=intro+'\n\n'+section+'\n'+report+'\n\n'+history.rstrip()+'\n'))+'\n')
subprocess.run(['git','push','origin','HEAD:refs/heads/perf/remaining-indicator-rollout'],cwd=repo,check=True)
q.update(published_head=head,fresh_publication_ci_status='running',pr_body_payload=str(payload),status='Complete harness/report refresh published; publication CI pending')
d.update(published_head=head,local_head=head,working_tree='clean',report_sha256=q['report_sha256'],report_wins=wins,
    remaining_10000_bar_gaps=401-wins['10000'],updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    current_published_ci_pending=dict(head=head,reason=name),full_goal_complete=False)
d['builder_totals'].update(imported['verdicts'])
checkpoint.write_text(json.dumps(d,indent=2)+'\n')
for attempt in range(90):
    current=json.loads(subprocess.check_output(['gh','api',endpoint]))
    assert current['draft'] and current['auto_merge'] is None and current['base']['ref']=='master'
    checks=json.loads(subprocess.check_output(['gh','api','repos/Ooples-Finance-LLC/OoplesFinance.StockIndicators/commits/'+head+'/check-runs?per_page=100']))['check_runs']
    titles=[c for c in checks if c['name']=='Auto-Fix PR Title']
    if current['head']['sha']==head and titles and all(c['status']=='completed' for c in titles):
        assert all(c['conclusion'] in ('success','skipped') for c in titles)
        break
    time.sleep(2)
else:raise RuntimeError('Published; metadata checks still pending; prepared PR body not yet applied')
subprocess.run(['gh','api',endpoint,'--method','PATCH','--input',str(payload),'--silent'],check=True)
print(head)
