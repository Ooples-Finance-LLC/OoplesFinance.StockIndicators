```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |----------:|----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |  **25.38 μs** |  **0.696 μs** |  **0.414 μs** |  **0.64** |    **0.02** |   **5.3711** |   **0.9766** |   **88.31 KB** |        **0.50** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |  23.91 μs |  0.330 μs |  0.173 μs |  0.60 |    0.01 |   2.4414 |   0.2441 |    40.7 KB |        0.23 |
| NativeSingle      | Skender.GetAdl | 1000  |  39.84 μs |  1.155 μs |  0.764 μs |  1.00 |    0.03 |  10.7422 |   2.4414 |  176.21 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 1000  |  80.52 μs |  4.654 μs |  3.079 μs |  2.02 |    0.08 |  28.8086 |   9.7656 |  449.39 KB |        2.55 |
|                   |                |       |           |           |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetAdl** | **10000** | **199.14 μs** |  **1.986 μs** |  **1.038 μs** |  **0.46** |    **0.01** |  **50.7813** |  **17.5781** |  **862.11 KB** |        **0.49** |
| BuilderLatestOnly | Skender.GetAdl | 10000 | 191.51 μs |  4.219 μs |  2.511 μs |  0.44 |    0.01 |  23.4375 |   8.7891 |  392.28 KB |        0.22 |
| NativeSingle      | Skender.GetAdl | 10000 | 437.28 μs | 12.554 μs |  7.471 μs |  1.00 |    0.02 | 105.4688 |  66.4063 | 1758.25 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 10000 | 803.38 μs | 73.264 μs | 48.460 μs |  1.84 |    0.11 | 273.4375 | 179.6875 |  4474.8 KB |        2.55 |
