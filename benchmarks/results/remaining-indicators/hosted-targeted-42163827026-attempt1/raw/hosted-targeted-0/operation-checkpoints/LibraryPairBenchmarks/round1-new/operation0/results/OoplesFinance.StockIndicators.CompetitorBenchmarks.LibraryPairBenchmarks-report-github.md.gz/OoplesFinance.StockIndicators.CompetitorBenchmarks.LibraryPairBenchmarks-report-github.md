```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId         | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetAdl** |   **308.0 μs** | **17.24 μs** | **11.40 μs** |  **1.00** |    **0.05** |  **246.88 KB** |        **1.00** |
|        |       |                |            |          |          |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetAdl** | **1,459.1 μs** | **24.53 μs** | **14.60 μs** |  **1.00** |    **0.01** | **2806.13 KB** |        **1.00** |
