```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAdl** |   **286.41 μs** | **18.944 μs** | **11.273 μs** |  **1.00** |    **0.05** |  **246.88 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAdl |    47.59 μs |  8.900 μs |  5.296 μs |  0.17 |    0.02 |  273.33 KB |        1.11 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAdl** | **1,414.05 μs** | **14.005 μs** |  **7.325 μs** |  **1.00** |    **0.01** | **2807.78 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAdl |   453.91 μs | 17.203 μs | 10.237 μs |  0.32 |    0.01 | 2649.96 KB |        0.94 |
