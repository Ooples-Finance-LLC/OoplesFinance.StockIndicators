```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **QuanTAlib.Realized** | **1000**  |  **1.587 ms** | **0.0135 ms** | **0.0081 ms** |  **66.01 KB** |
| BuilderLatestOnly | QuanTAlib.Realized | 1000  |  1.140 ms | 0.0074 ms | 0.0044 ms |   18.3 KB |
| **BuilderFull**       | **QuanTAlib.Realized** | **10000** | **11.316 ms** | **0.0481 ms** | **0.0318 ms** | **629.27 KB** |
| BuilderLatestOnly | QuanTAlib.Realized | 10000 | 11.215 ms | 0.0531 ms | 0.0316 ms | 159.42 KB |
