```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated  | Alloc Ratio |
|------------------ |------------------- |------ |------------:|-----------:|-----------:|------:|--------:|--------:|-------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Realized** | **1000**  | **1,734.80 μs** |  **12.419 μs** |   **7.390 μs** | **27.53** |    **0.20** |       **-** |      **-** |   **66.01 KB** |        **1.39** |
| BuilderLatestOnly | QuanTAlib.Realized | 1000  | 1,165.67 μs |   6.181 μs |   3.678 μs | 18.50 |    0.13 |       - |      - |   18.31 KB |        0.39 |
| NativeSingle      | QuanTAlib.Realized | 1000  |    63.01 μs |   0.786 μs |   0.411 μs |  1.00 |    0.01 |  2.4414 |      - |   47.47 KB |        1.00 |
| NativeParallel    | QuanTAlib.Realized | 1000  |   144.46 μs |  11.239 μs |   7.434 μs |  2.29 |    0.11 |  5.8594 |      - |  107.95 KB |        2.27 |
|                   |                    |       |             |            |            |       |         |         |        |            |             |
| **BuilderFull**       | **QuanTAlib.Realized** | **10000** | **6,306.53 μs** | **459.273 μs** | **303.781 μs** | **10.02** |    **0.47** | **31.2500** |      **-** |  **711.48 KB** |        **1.52** |
| BuilderLatestOnly | QuanTAlib.Realized | 10000 | 6,090.36 μs | 308.923 μs | 204.333 μs |  9.68 |    0.32 |       - |      - |  241.65 KB |        0.51 |
| NativeSingle      | QuanTAlib.Realized | 10000 |   629.33 μs |   8.014 μs |   4.192 μs |  1.00 |    0.01 | 27.3438 | 3.9063 |  469.37 KB |        1.00 |
| NativeParallel    | QuanTAlib.Realized | 10000 |   971.23 μs |  22.223 μs |  13.225 μs |  1.54 |    0.02 | 62.5000 | 7.8125 | 1057.22 KB |        2.25 |
