```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Historical** | **1,248.0 μs** | **21.49 μs** | **14.21 μs** |  **1.00** |    **0.02** |  **106.81 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Historical |   578.2 μs | 20.02 μs | 11.91 μs |  0.46 |    0.01 |   439.3 KB |        4.11 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Historical** | **6,054.0 μs** | **38.07 μs** | **19.91 μs** |  **1.00** |    **0.00** | **1118.05 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Historical | 5,826.6 μs | 43.33 μs | 25.79 μs |  0.96 |    0.01 | 4375.38 KB |        3.91 |
