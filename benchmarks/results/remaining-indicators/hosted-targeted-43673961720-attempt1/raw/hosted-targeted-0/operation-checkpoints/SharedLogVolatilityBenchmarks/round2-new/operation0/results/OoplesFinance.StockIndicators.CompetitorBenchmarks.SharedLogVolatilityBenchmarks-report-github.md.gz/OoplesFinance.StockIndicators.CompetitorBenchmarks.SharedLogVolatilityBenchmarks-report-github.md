```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Historical** | **1000**  | **3,304.9 μs** |  **55.59 μs** |  **33.08 μs** |  **6.99** |    **0.07** |        **-** |       **-** |   **66.07 KB** |        **0.16** |
| BuilderLatestOnly | QuanTAlib.Historical | 1000  | 1,525.3 μs |  24.07 μs |  12.59 μs |  3.23 |    0.03 |        - |       - |   18.38 KB |        0.04 |
| NativeSingle      | QuanTAlib.Historical | 1000  |   473.0 μs |   3.62 μs |   1.89 μs |  1.00 |    0.01 |  23.4375 |       - |  414.08 KB |        1.00 |
| NativeParallel    | QuanTAlib.Historical | 1000  |   357.1 μs |  17.59 μs |  11.63 μs |  0.76 |    0.02 |  25.3906 |       - |  418.64 KB |        1.01 |
|                   |                      |       |            |           |           |       |         |          |         |            |             |
| **BuilderFull**       | **QuanTAlib.Historical** | **10000** | **8,525.3 μs** | **970.49 μs** | **641.92 μs** |  **1.77** |    **0.13** |        **-** |       **-** |  **711.85 KB** |        **0.17** |
| BuilderLatestOnly | QuanTAlib.Historical | 10000 | 8,103.7 μs | 451.07 μs | 235.92 μs |  1.68 |    0.05 |        - |       - |  242.03 KB |        0.06 |
| NativeSingle      | QuanTAlib.Historical | 10000 | 4,820.9 μs |  38.11 μs |  19.93 μs |  1.00 |    0.01 | 250.0000 | 31.2500 | 4200.62 KB |        1.00 |
| NativeParallel    | QuanTAlib.Historical | 10000 | 2,979.3 μs | 145.00 μs |  95.91 μs |  0.62 |    0.02 | 250.0000 | 46.8750 | 4205.43 KB |        1.00 |
