```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |---------- |------ |-----------:|-----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **Ema**       | **1000**  |  **30.630 μs** |  **1.5368 μs** | **1.0165 μs** | **14.25** |    **0.54** |  **2.9297** |       **-** |  **56.74 KB** |        **7.35** |
| BuilderLatestOnly | Ema       | 1000  |  19.144 μs |  0.3400 μs | 0.2249 μs |  8.91 |    0.21 |  0.4883 |       - |   8.85 KB |        1.15 |
| NativeSingle      | Ema       | 1000  |   2.151 μs |  0.0707 μs | 0.0468 μs |  1.00 |    0.03 |  0.4578 |       - |   7.72 KB |        1.00 |
| NativeParallel    | Ema       | 1000  |  65.880 μs |  2.3472 μs | 1.5526 μs | 30.65 |    0.94 |  0.4883 |       - |   7.99 KB |        1.03 |
|                   |           |       |            |            |           |       |         |         |         |           |             |
| **BuilderFull**       | **Ema**       | **10000** | **268.174 μs** | **10.2863 μs** | **6.8037 μs** | **14.41** |    **0.37** | **33.2031** | **13.6719** | **549.27 KB** |        **7.04** |
| BuilderLatestOnly | Ema       | 10000 | 168.130 μs |  4.9506 μs | 3.2745 μs |  9.03 |    0.19 |  3.9063 |       - |  79.17 KB |        1.01 |
| NativeSingle      | Ema       | 10000 |  18.618 μs |  0.3144 μs | 0.1871 μs |  1.00 |    0.01 |  4.7607 |  0.8545 |  78.03 KB |        1.00 |
| NativeParallel    | Ema       | 10000 |  82.431 μs |  2.1310 μs | 1.4095 μs |  4.43 |    0.08 |  4.3945 |  0.4883 |   78.3 KB |        1.00 |
