```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean       | Error      | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|-----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ema** | **143.020 μs** | **10.1778 μs** | **6.7320 μs** |  **1.00** |    **0.06** |  **64.84 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ema |   2.837 μs |  0.5000 μs | 0.2615 μs |  0.02 |    0.00 |  16.63 KB |        0.26 |
|            |       |                     |            |            |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ema** | **275.189 μs** | **11.9602 μs** | **7.1173 μs** |  **1.00** |    **0.03** | **627.63 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ema |  23.789 μs |  2.1917 μs | 1.3043 μs |  0.09 |    0.00 | 161.84 KB |        0.26 |
