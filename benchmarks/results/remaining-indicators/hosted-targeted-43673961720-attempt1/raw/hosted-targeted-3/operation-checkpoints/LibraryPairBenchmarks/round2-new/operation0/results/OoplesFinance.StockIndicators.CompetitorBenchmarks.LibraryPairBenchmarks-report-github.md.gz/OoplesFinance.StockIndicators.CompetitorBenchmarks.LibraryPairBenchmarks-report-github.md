```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean         | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-------------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.T3** |   **220.444 μs** | **10.2521 μs** |  **6.1008 μs** |  **1.00** |    **0.04** |  **105.89 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.T3 |     8.738 μs |  0.8108 μs |  0.4241 μs |  0.04 |    0.00 |   39.61 KB |        0.37 |
|            |       |                    |              |            |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.T3** | **1,280.811 μs** | **45.6338 μs** | **27.1559 μs** |  **1.00** |    **0.03** | **1038.23 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.T3 |    68.744 μs |  3.9971 μs |  2.3786 μs |  0.05 |    0.00 |  330.63 KB |        0.32 |
