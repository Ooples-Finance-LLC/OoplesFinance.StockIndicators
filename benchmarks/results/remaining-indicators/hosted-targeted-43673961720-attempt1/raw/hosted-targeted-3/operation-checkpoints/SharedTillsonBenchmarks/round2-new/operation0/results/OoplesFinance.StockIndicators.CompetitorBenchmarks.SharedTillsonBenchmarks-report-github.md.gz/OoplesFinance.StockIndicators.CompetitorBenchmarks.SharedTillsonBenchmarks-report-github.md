```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.T3** | **1000**  |   **149.080 μs** |  **1.6155 μs** |  **0.9614 μs** | **37.75** |    **0.45** |  **3.9063** |       **-** |  **65.25 KB** |        **9.35** |
| BuilderLatestOnly | TaLib.Functions.T3 | 1000  |   148.359 μs |  0.8120 μs |  0.4247 μs | 37.57 |    0.40 |  0.9766 |       - |  17.64 KB |        2.53 |
| NativeSingle      | TaLib.Functions.T3 | 1000  |     3.950 μs |  0.0724 μs |  0.0431 μs |  1.00 |    0.01 |  0.3967 |       - |   6.98 KB |        1.00 |
| NativeParallel    | TaLib.Functions.T3 | 1000  |    92.043 μs |  0.9522 μs |  0.5667 μs | 23.31 |    0.28 |  1.4648 |       - |  24.66 KB |        3.53 |
|                   |                    |       |              |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.T3** | **10000** |   **962.652 μs** | **13.5604 μs** |  **7.0923 μs** | **24.15** |    **0.33** | **31.2500** |  **7.8125** | **630.77 KB** |        **8.16** |
| BuilderLatestOnly | TaLib.Functions.T3 | 10000 | 1,049.240 μs | 68.2989 μs | 45.1755 μs | 26.32 |    1.13 | 31.2500 | 15.6250 | 630.09 KB |        8.15 |
| NativeSingle      | TaLib.Functions.T3 | 10000 |    39.864 μs |  0.8460 μs |  0.5034 μs |  1.00 |    0.02 |  4.6387 |       - |  77.29 KB |        1.00 |
| NativeParallel    | TaLib.Functions.T3 | 10000 |   145.479 μs |  6.7266 μs |  4.4493 μs |  3.65 |    0.11 | 17.5781 |  3.9063 | 270.76 KB |        3.50 |
