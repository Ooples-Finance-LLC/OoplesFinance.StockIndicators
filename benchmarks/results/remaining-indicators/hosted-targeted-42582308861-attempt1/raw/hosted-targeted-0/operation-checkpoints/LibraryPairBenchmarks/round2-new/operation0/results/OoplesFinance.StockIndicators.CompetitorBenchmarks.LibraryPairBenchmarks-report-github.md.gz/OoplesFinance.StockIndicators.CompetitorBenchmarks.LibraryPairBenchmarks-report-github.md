```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean         | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Beta** |   **249.022 μs** | **18.342 μs** | **10.915 μs** |  **1.00** |    **0.06** |  **108.38 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Beta |     8.850 μs |  1.915 μs |  1.267 μs |  0.04 |    0.01 |   36.27 KB |        0.33 |
|            |       |                      |              |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Beta** | **2,331.660 μs** | **76.085 μs** | **50.325 μs** |  **1.00** |    **0.03** | **1036.77 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Beta |    72.300 μs |  5.153 μs |  3.067 μs |  0.03 |    0.00 |  326.26 KB |        0.31 |
