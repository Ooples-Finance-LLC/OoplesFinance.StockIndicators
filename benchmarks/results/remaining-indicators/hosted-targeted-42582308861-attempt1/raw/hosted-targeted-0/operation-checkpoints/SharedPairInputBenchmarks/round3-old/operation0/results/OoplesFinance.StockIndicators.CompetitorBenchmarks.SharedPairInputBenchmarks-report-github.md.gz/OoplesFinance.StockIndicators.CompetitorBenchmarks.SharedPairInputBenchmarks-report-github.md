```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **301.2 μs** |  **10.88 μs** |  **6.47 μs** |  **3.9063** |       **-** |  **69.25 KB** |
| BuilderLatestOnly | 1000  | Beta      |   299.6 μs |  13.20 μs |  7.86 μs |       - |       - |  21.66 KB |
| **BuilderFull**       | **10000** | **Beta**      | **2,466.7 μs** |  **80.99 μs** | **53.57 μs** | **31.2500** | **15.6250** | **632.24 KB** |
| BuilderLatestOnly | 10000 | Beta      | 2,453.9 μs | 100.44 μs | 66.43 μs |       - |       - |  162.4 KB |
