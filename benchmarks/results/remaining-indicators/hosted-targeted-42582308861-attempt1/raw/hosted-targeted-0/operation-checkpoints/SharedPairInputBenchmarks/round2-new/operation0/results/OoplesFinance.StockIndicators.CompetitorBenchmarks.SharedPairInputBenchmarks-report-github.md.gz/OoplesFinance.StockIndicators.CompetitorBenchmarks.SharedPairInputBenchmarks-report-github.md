```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-------------:|------------:|------------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **492.541 μs** | **143.2147 μs** |  **94.7277 μs** | **92.68** |   **17.07** |       **-** |       **-** |  **69.36 KB** |        **9.00** |
| BuilderLatestOnly | 1000  | Beta      |   272.979 μs |   7.9994 μs |   4.1838 μs | 51.36 |    1.14 |       - |       - |  21.67 KB |        2.81 |
| NativeSingle      | 1000  | Beta      |     5.316 μs |   0.1429 μs |   0.0945 μs |  1.00 |    0.02 |  0.4578 |       - |   7.71 KB |        1.00 |
| NativeParallel    | 1000  | Beta      |    67.109 μs |   1.5061 μs |   0.9962 μs | 12.63 |    0.28 |  0.4883 |       - |   7.98 KB |        1.03 |
|                   |       |           |              |             |             |       |         |         |         |           |             |
| **BuilderFull**       | **10000** | **Beta**      | **2,234.899 μs** |  **40.6079 μs** |  **21.2387 μs** | **43.74** |    **0.43** | **31.2500** | **15.6250** | **632.24 KB** |        **8.10** |
| BuilderLatestOnly | 10000 | Beta      | 2,268.399 μs | 153.9180 μs | 101.8072 μs | 44.39 |    1.91 |       - |       - |  162.4 KB |        2.08 |
| NativeSingle      | 10000 | Beta      |    51.098 μs |   0.4414 μs |   0.2309 μs |  1.00 |    0.01 |  4.3945 |  0.4883 |  78.02 KB |        1.00 |
| NativeParallel    | 10000 | Beta      |    90.701 μs |   2.8705 μs |   1.8987 μs |  1.78 |    0.04 |  4.3945 |  0.4883 |  78.29 KB |        1.00 |
