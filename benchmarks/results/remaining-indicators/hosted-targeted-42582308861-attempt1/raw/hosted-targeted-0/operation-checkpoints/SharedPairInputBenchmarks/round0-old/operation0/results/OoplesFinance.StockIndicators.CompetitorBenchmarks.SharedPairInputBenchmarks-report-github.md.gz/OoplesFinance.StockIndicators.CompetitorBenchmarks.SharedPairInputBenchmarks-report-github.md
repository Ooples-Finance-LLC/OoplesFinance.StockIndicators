```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **300.5 μs** |  **33.44 μs** | **22.12 μs** |  **3.9063** |       **-** |  **69.23 KB** |
| BuilderLatestOnly | 1000  | Beta      |   288.6 μs |  15.72 μs | 10.40 μs |       - |       - |  21.65 KB |
| **BuilderFull**       | **10000** | **Beta**      | **2,220.0 μs** |  **42.20 μs** | **22.07 μs** | **31.2500** | **15.6250** | **632.09 KB** |
| BuilderLatestOnly | 10000 | Beta      | 2,284.9 μs | 131.89 μs | 87.23 μs |       - |       - | 162.36 KB |
