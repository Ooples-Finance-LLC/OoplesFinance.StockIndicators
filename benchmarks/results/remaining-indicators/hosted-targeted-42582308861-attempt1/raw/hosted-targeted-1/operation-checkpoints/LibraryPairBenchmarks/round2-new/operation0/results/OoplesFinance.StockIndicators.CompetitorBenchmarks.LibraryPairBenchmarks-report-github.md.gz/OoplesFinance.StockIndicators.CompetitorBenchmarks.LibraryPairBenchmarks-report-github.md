```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId          | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0      | Allocated   | Alloc Ratio |
|----------- |------ |---------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetBeta** |   **977.0 μs** |  **45.49 μs** |  **27.07 μs** |  **1.00** |    **0.04** |         **-** |   **450.38 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetBeta |   467.3 μs |  21.61 μs |  12.86 μs |  0.48 |    0.02 |         - |  2719.99 KB |        6.04 |
|            |       |                 |            |           |           |       |         |           |             |             |
| **Ooples**     | **10000** | **Skender.GetBeta** | **9,305.1 μs** | **141.99 μs** |  **74.26 μs** |  **1.00** |    **0.01** |         **-** |  **4387.58 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetBeta | 6,577.5 μs | 218.01 μs | 129.73 μs |  0.71 |    0.01 | 1000.0000 | 27526.31 KB |        6.27 |
