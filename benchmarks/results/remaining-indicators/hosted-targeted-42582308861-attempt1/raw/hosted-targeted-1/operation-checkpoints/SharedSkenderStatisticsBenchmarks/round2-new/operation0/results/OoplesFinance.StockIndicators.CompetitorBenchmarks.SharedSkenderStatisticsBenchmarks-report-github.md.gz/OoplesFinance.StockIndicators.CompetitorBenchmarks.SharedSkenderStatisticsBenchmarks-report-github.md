```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|------------------ |---------------- |------ |-----------:|----------:|----------:|------:|--------:|----------:|---------:|---------:|------------:|------------:|
| **BuilderFull**       | **Skender.GetBeta** | **1000**  | **1,357.8 μs** | **253.13 μs** | **167.43 μs** |  **3.35** |    **0.40** |         **-** |        **-** |        **-** |   **171.57 KB** |        **0.07** |
| BuilderLatestOnly | Skender.GetBeta | 1000  |   864.5 μs |  29.93 μs |  15.65 μs |  2.13 |    0.04 |         - |        - |        - |   123.81 KB |        0.05 |
| NativeSingle      | Skender.GetBeta | 1000  |   404.9 μs |   7.08 μs |   4.22 μs |  1.00 |    0.01 |  152.3438 |  42.9688 |        - |   2532.2 KB |        1.00 |
| NativeParallel    | Skender.GetBeta | 1000  |   390.3 μs |  23.57 μs |  14.03 μs |  0.96 |    0.03 |  156.2500 |  46.8750 |        - |  2557.07 KB |        1.01 |
|                   |                 |       |            |           |           |       |         |           |          |          |             |             |
| **BuilderFull**       | **Skender.GetBeta** | **10000** | **8,397.4 μs** | **511.40 μs** | **338.26 μs** |  **1.29** |    **0.09** |   **76.9231** |        **-** |        **-** |  **1578.72 KB** |        **0.06** |
| BuilderLatestOnly | Skender.GetBeta | 10000 | 8,041.0 μs | 100.97 μs |  52.81 μs |  1.24 |    0.07 |         - |        - |        - |  1108.82 KB |        0.04 |
| NativeSingle      | Skender.GetBeta | 10000 | 6,525.1 μs | 532.10 μs | 351.95 μs |  1.00 |    0.08 | 1687.5000 | 812.5000 | 187.5000 | 25737.17 KB |        1.00 |
| NativeParallel    | Skender.GetBeta | 10000 | 4,487.1 μs | 400.34 μs | 238.24 μs |  0.69 |    0.05 | 1593.7500 | 812.5000 |        - | 25830.73 KB |        1.00 |
