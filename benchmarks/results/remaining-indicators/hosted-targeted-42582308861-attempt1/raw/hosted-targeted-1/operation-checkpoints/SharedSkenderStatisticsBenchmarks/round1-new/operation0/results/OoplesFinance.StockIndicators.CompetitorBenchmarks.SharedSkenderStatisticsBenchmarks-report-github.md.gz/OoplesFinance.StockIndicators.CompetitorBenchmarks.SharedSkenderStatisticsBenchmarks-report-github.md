```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev    | Gen0    | Allocated  |
|------------------ |---------------- |------ |-----------:|----------:|----------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetBeta** | **1000**  | **1,803.1 μs** | **373.69 μs** | **247.17 μs** |       **-** |  **171.57 KB** |
| BuilderLatestOnly | Skender.GetBeta | 1000  |   856.2 μs |  48.62 μs |  32.16 μs |       - |  123.76 KB |
| **BuilderFull**       | **Skender.GetBeta** | **10000** | **8,451.3 μs** | **934.94 μs** | **618.40 μs** | **76.9231** | **1578.69 KB** |
| BuilderLatestOnly | Skender.GetBeta | 10000 | 7,878.6 μs |  97.04 μs |  50.76 μs |       - |  1108.8 KB |
