```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error     | StdDev    | Gen0    | Allocated  |
|------------------ |---------------- |------ |-----------:|----------:|----------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetBeta** | **1000**  | **1,594.3 μs** | **254.26 μs** | **168.18 μs** |       **-** |  **171.57 KB** |
| BuilderLatestOnly | Skender.GetBeta | 1000  |   906.4 μs |  56.57 μs |  37.42 μs |       - |   123.8 KB |
| **BuilderFull**       | **Skender.GetBeta** | **10000** | **8,098.8 μs** | **100.22 μs** |  **52.42 μs** | **76.9231** | **1578.72 KB** |
| BuilderLatestOnly | Skender.GetBeta | 10000 | 8,180.2 μs |  97.81 μs |  51.16 μs |       - | 1108.82 KB |
