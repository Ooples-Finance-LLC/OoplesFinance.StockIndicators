```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error       | StdDev      | Gen0    | Allocated  |
|------------------ |---------------- |------ |-----------:|------------:|------------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetBeta** | **1000**  | **1,508.2 μs** |    **57.75 μs** |    **38.20 μs** |       **-** |  **171.57 KB** |
| BuilderLatestOnly | Skender.GetBeta | 1000  |   851.2 μs |     8.28 μs |     4.33 μs |       - |   123.8 KB |
| **BuilderFull**       | **Skender.GetBeta** | **10000** | **8,280.6 μs** |   **446.01 μs** |   **265.42 μs** | **83.3333** | **1578.79 KB** |
| BuilderLatestOnly | Skender.GetBeta | 10000 | 9,276.8 μs | 2,337.04 μs | 1,545.80 μs |       - | 1108.93 KB |
