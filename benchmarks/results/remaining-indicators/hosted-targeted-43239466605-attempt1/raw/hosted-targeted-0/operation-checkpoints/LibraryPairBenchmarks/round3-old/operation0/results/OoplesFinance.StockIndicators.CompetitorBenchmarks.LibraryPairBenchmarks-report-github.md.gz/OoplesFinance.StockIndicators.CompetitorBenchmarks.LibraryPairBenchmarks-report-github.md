```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |-----------:|---------:|---------:|------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Beta** |   **259.6 μs** |  **2.67 μs** |  **1.77 μs** |  **1.00** |  **106.25 KB** |        **1.00** |
|        |       |                      |            |          |          |       |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Beta** | **2,420.9 μs** | **38.25 μs** | **22.76 μs** |  **1.00** | **1035.62 KB** |        **1.00** |
