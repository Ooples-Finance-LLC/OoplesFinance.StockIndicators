```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Beta** |   **282.96 μs** |  **4.165 μs** |  **2.478 μs** |  **1.00** |    **0.01** |  **106.25 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Beta |    10.36 μs |  0.280 μs |  0.167 μs |  0.04 |    0.00 |   38.84 KB |        0.37 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Beta** | **2,736.93 μs** | **46.428 μs** | **30.709 μs** |  **1.00** |    **0.02** | **1035.95 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Beta |    87.67 μs |  1.266 μs |  0.753 μs |  0.03 |    0.00 |  329.21 KB |        0.32 |
