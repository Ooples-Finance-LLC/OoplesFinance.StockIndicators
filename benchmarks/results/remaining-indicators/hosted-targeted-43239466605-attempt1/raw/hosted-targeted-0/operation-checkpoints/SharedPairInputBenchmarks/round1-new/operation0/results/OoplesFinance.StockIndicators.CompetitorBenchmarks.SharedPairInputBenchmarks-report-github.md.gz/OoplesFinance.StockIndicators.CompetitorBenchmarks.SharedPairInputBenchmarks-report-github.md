```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |------ |---------- |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **352.9 μs** |  **1.24 μs** |  **0.74 μs** |       **-** |     **65 KB** |
| BuilderLatestOnly | 1000  | Beta      |   220.0 μs |  2.69 μs |  1.41 μs |       - |   17.3 KB |
| **BuilderFull**       | **10000** | **Beta**      | **2,302.4 μs** | **18.89 μs** | **11.24 μs** | **31.2500** | **627.85 KB** |
| BuilderLatestOnly | 10000 | Beta      | 2,279.1 μs | 21.88 μs | 11.45 μs |       - | 158.02 KB |
