```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **258.806 μs** |  **1.2499 μs** |  **0.6537 μs** | **37.30** |    **0.71** |       **-** |      **-** |  **64.95 KB** |        **8.42** |
| BuilderLatestOnly | 1000  | Beta      |   245.122 μs |  1.6507 μs |  0.8633 μs | 35.33 |    0.68 |       - |      - |   17.3 KB |        2.24 |
| NativeSingle      | 1000  | Beta      |     6.940 μs |  0.2109 μs |  0.1395 μs |  1.00 |    0.03 |  0.4272 |      - |   7.71 KB |        1.00 |
| NativeParallel    | 1000  | Beta      |    79.114 μs |  1.0916 μs |  0.7220 μs | 11.40 |    0.24 |  0.4883 |      - |   7.98 KB |        1.03 |
|                   |       |           |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **10000** | **Beta**      | **2,533.202 μs** | **46.5100 μs** | **27.6773 μs** | **38.48** |    **0.50** | **31.2500** |      **-** | **627.89 KB** |        **8.05** |
| BuilderLatestOnly | 10000 | Beta      | 2,492.836 μs | 23.0807 μs | 13.7350 μs | 37.86 |    0.36 |       - |      - | 158.01 KB |        2.03 |
| NativeSingle      | 10000 | Beta      |    65.843 μs |  0.9262 μs |  0.5512 μs |  1.00 |    0.01 |  4.3945 | 0.4883 |  78.03 KB |        1.00 |
| NativeParallel    | 10000 | Beta      |   110.078 μs |  3.6928 μs |  2.1975 μs |  1.67 |    0.03 |  3.9063 |      - |   78.3 KB |        1.00 |
