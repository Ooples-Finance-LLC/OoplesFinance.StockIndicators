using System.Reflection;
using System.Runtime.Loader;
using BenchmarkDotNet.Configs;
using BenchmarkDotNet.Diagnosers;
using BenchmarkDotNet.Exporters.Json;
using BenchmarkDotNet.Jobs;
using BenchmarkDotNet.Running;
using BenchmarkDotNet.Toolchains.InProcess.Emit;

if (args.Length is < 3 or > 4 || args.Length == 4 && args[3] != "--list")
    throw new ArgumentException("Expected captured benchmark DLL, DynamicMomentum/FallingThreeMethods, artifact directory, optional --list.");
string binary = Path.GetFullPath(args[0]);
string selection = args[1];
string fixture = selection switch
{
    "DynamicMomentum" => "SharedDynamicMomentumBenchmarks",
    "FallingThreeMethods" => "SharedTradyNativeCandleBenchmarks",
    _ => throw new ArgumentException("Only the two approved long native comparisons are supported.")
};
var resolver = new AssemblyDependencyResolver(binary);
AssemblyLoadContext.Default.Resolving += (context, name) =>
{
    string? path = resolver.ResolveAssemblyToPath(name);
    return path is null ? null : context.LoadFromAssemblyPath(path);
};
AssemblyLoadContext.Default.ResolvingUnmanagedDll += (assembly, name) =>
{
    string? path = resolver.ResolveUnmanagedDllToPath(name);
    return path is null ? IntPtr.Zero : System.Runtime.InteropServices.NativeLibrary.Load(path);
};
var assembly = AssemblyLoadContext.Default.LoadFromAssemblyPath(binary);
var type = assembly.GetType("OoplesFinance.StockIndicators.CompetitorBenchmarks." + fixture, throwOnError: true)!;
var config = ManualConfig.Create(DefaultConfig.Instance)
    .WithArtifactsPath(Path.GetFullPath(args[2]))
    .AddExporter(JsonExporter.FullCompressed)
    .AddDiagnoser(MemoryDiagnoser.Default);
var original = BenchmarkConverter.TypeToBenchmarks(type, config);
string[] methods = ["BuilderFull", "BuilderLatestOnly", "NativeSingle", "NativeParallel"];
var selected = original.BenchmarksCases.Where(c => methods.Contains(c.Descriptor.WorkloadMethod.Name)
    && (selection == "DynamicMomentum" || c.Parameters.Items.Any(p => p.Name == "Operation" && Equals(p.Value, "FallingThreeMethods"))))
    .ToArray();
if (selected.Length != 8) throw new InvalidOperationException("Expected exactly four methods at two input sizes.");
var cases = selected.Select(c =>
{
    int count = (int)c.Parameters.Items.Single(p => p.Name == "Count").Value;
    if (count is not (1000 or 10000)) throw new InvalidOperationException("Unexpected input size.");
    bool slowNative = count == 10000 && c.Descriptor.WorkloadMethod.Name is "NativeSingle" or "NativeParallel";
    var job = c.Job.WithWarmupCount(10).WithIterationCount(10).WithUnrollFactor(1)
        .WithToolchain(new InProcessEmitToolchain(TimeSpan.FromMinutes(90), logOutput: true));
    if (slowNative) job = job.WithInvocationCount(1);
    return BenchmarkCase.Create(c.Descriptor, job, c.Parameters, c.Config);
}).ToArray();
foreach (var c in cases) Console.WriteLine(c.DisplayInfo);
if (args.Length == 4) return;
// Keep the original descriptors, parameters, setup, cleanup, validators and
// correctness assertions. Replace only the approved sampling/timeout policy.
var result = BenchmarkRunner.Run(new BenchmarkRunInfo(cases, type, original.Config));
if (result.Reports.Length != 8 || result.Reports.Any(r => !r.Success))
    throw new InvalidOperationException("The approved comparison did not complete all eight cases.");
