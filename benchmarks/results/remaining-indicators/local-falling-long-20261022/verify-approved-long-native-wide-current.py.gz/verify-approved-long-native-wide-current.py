from pathlib import Path
import collections, hashlib, json, math, re, subprocess, sys

ROOT = Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
REPO = Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
run, fixture, pair, operation = {
    'DynamicMomentum': ('local-dynamic-long-20261022', 'SharedDynamicMomentumBenchmarks', 'Trady.Indicator.DynamicMomentumIndex', 'Trady.Indicator.DynamicMomentumIndex'),
    'FallingThreeMethods': ('local-falling-long-20261022', 'SharedTradyNativeCandleBenchmarks', 'Trady.Candlestick.FallingThreeMethods', 'FallingThreeMethods'),
}[sys.argv[1]]
OUT = ROOT / run
SOURCE = json.loads((OUT/'provenance.json').read_text(encoding='utf-8'))['source_sha']
state = json.loads((OUT / 'status.json').read_text())
proof = json.loads((OUT / 'provenance.json').read_text())
assert state['status'] == 'raw-measurements-complete-independent-verification-pending'
assert proof['source_sha'] == state['source_sha'] == SOURCE
assert proof['fixture'] == fixture and proof['pair'] == pair
unrelated=[]
paths=['src','tests','benchmarks/OoplesFinance.StockIndicators.CompetitorTests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json','examples','scripts','.github','NuGet.Config','nuget.config']
assert not subprocess.check_output(['git','diff',SOURCE,'HEAD','--',*paths],cwd=REPO)
assert not subprocess.check_output(['git','diff',proof['qualification']['input_head'],SOURCE,'--',*paths],cwd=REPO)
assert proof['qualification']['gpu_passed']==100 and proof['qualification']['parity']['passed']==20
assert proof['qualification']['unit']['passed']==37
assert proof['qualification']['input_head']=='22a874f21013d0fc5571e15adeedff57ecbd031e'

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def manifest(p): return {f.relative_to(p).as_posix(): digest(f) for f in p.rglob('*') if f.is_file()}

binary_manifest = json.loads((OUT / 'binary-manifest.json').read_text())
assert manifest(Path(proof['executed_binary_directory'])) == binary_manifest
assert manifest(Path(proof['original_binary_directory'])) == binary_manifest
assert manifest(Path(proof['host_binary_directory'])) == json.loads((OUT / 'host-manifest.json').read_text())
assert {name: digest(Path(proof['host_source_directory']) / name) for name in proof['host_sources']} == proof['host_sources']
status = state['fixtures'][fixture]
assert status['status'] == 'raw-measurements-complete'
assert len(status['quiet_cpu_samples']) == 3 and max(status['quiet_cpu_samples']) <= 15
raw = Path(status['report']).read_bytes()
assert hashlib.sha256(raw).hexdigest() == status['sha256']
report = json.loads(raw)
assert 'Windows' in report['HostEnvironmentInfo']['OsVersion']
cases = {}
for case in report['Benchmarks']:
    full = case['FullName']
    assert fixture + '.' in full and re.search(r'Operation: "([^"]+)"', full)[1] == operation
    bars = int(re.search(r'Count: (\d+)', full)[1])
    key = bars, case['Method']
    assert key not in cases
    stats = case['Statistics']; values = stats['OriginalValues']; ci = stats['ConfidenceInterval']
    assert stats['N'] == len(values) >= 7
    assert all(math.isfinite(v) and v > 0 for v in values)
    assert math.isclose(sum(values) / len(values), stats['Mean'], rel_tol=1e-12)
    assert math.isfinite(ci['Lower']) and math.isfinite(ci['Upper']) and ci['Lower'] <= stats['Mean'] <= ci['Upper']
    cases[key] = dict(mean_ns=stats['Mean'], lower_ns=ci['Lower'], upper_ns=ci['Upper'],
        samples=stats['N'], allocated_bytes=case['Memory']['BytesAllocatedPerOperation'])
methods = ['BuilderFull', 'BuilderLatestOnly', 'NativeSingle', 'NativeParallel']
assert cases.keys() == {(bars, method) for bars in [1000, 10000] for method in methods}
log = (OUT / (fixture + '.log')).read_text(encoding='utf-8-sig')
sections = re.split(r'^// Benchmark: ', log, flags=re.M)[1:]
assert len(sections) == 8
for section in sections:
    header = section.splitlines()[0]
    assert 'IterationCount=10' in header and 'WarmupCount=10' in header
    assert len(re.findall(r'^WorkloadWarmup\s+\d+:', section, re.M)) == 10
    measured = re.findall(r'^WorkloadActual\s+\d+:\s+(\d+) op', section, re.M)
    assert len(measured) == 10
    if 'Count=10000' in header and any(fixture + '.' + m + ':' in header for m in ['NativeSingle', 'NativeParallel']):
        assert 'InvocationCount=1,' in header and set(measured) == {'1'}
comparisons = []
for bars in [1000, 10000]:
    native = {m: cases[bars, m] for m in ['NativeSingle', 'NativeParallel']}
    for mode in ['BuilderFull', 'BuilderLatestOnly']:
        ours = cases[bars, mode]
        verdict = 'faster' if ours['upper_ns'] < min(n['lower_ns'] for n in native.values()) else 'slower' if ours['lower_ns'] > min(n['upper_ns'] for n in native.values()) else 'inconclusive'
        comparisons.append(dict(pair=pair, bars=bars, mode=mode, ooples=ours, native=native,
            fastest_native=min(native, key=lambda m: native[m]['mean_ns']), verdict=verdict))
receipt = dict(fixture=fixture, source_sha=SOURCE, run_id=run, measurement_location='Local Windows; approved longer native measurement',
    host=report['HostEnvironmentInfo'], report_sha256=status['sha256'], report_file=str(Path(status['report']).relative_to(OUT)),
    quiet_cpu_samples=status['quiet_cpu_samples'], complete=True, comparisons=comparisons)
summary = dict(source_sha=SOURCE, all_8_cases_verified=True, matched_current_source_paths=paths,
    isolated_unrelated_change=unrelated, unchanged_setup_and_method_descriptors=True, host_sources=proof['host_sources'],
    receipts=[receipt], verdicts=dict(collections.Counter(c['verdict'] for c in comparisons)))
(OUT / 'verified-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print('Verified eight cases, required warmups/samples, and four comparison slots:', summary['verdicts'])
