from pathlib import Path
import json,hashlib
out=Path('C:/Users/cheat/Documents/OoplesFinance-Reports/cpu-builder-refresh-local-falling-long-20261022')
p=out/'candidate.html';s=p.read_text(encoding='utf-8')
a='Of the 72 nominal pending builder slots, 60 belong';b='Of the 68 nominal pending builder slots, 60 belong'
assert s.count(a)==1;s=s.replace(a,b)
a='The remaining 12 slots belong to Dynamic Momentum, Falling Three Methods, and Rising Three Methods.'
b='The remaining 8 slots belong to Dynamic Momentum and Rising Three Methods. Falling Three Methods now has four verified builder comparisons.'
assert s.count(a)==1;s=s.replace(a,b)
p.write_text(s,encoding='utf-8')
state=json.loads((out/'staged.json').read_text(encoding='utf-8'));state['candidate_sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
(out/'staged.json').write_text(json.dumps(state,indent=2),encoding='utf-8')
print('Updated pending breakdown to match measured rows.')
