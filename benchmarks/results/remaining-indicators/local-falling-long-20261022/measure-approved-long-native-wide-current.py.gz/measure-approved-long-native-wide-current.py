from pathlib import Path
import datetime, hashlib, json, os, psutil, shutil, subprocess, sys

ROOT = Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
REPO = Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
SOURCE = subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
selection = sys.argv[1]
assert selection == 'FallingThreeMethods', 'Only the still-approved unstarted long comparison is selected.'
run, fixture, pair = {
    'DynamicMomentum': ('local-dynamic-long-20261022', 'SharedDynamicMomentumBenchmarks', 'Trady.Indicator.DynamicMomentumIndex'),
    'FallingThreeMethods': ('local-falling-long-20261022', 'SharedTradyNativeCandleBenchmarks', 'Trady.Candlestick.FallingThreeMethods'),
}[selection]
OUT = ROOT / run
OUT.mkdir(exist_ok=True)
assert not (OUT / 'status.json').exists()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == SOURCE
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO)
original = Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-cci-wide-grid-20261022/benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks/bin/Release/net10.0')
captured = OUT / 'binaries'
host = ROOT / 'long-native-runner'
host_bin = host / 'bin/Release/net10.0'

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def manifest(p): return {f.relative_to(p).as_posix(): digest(f) for f in p.rglob('*') if f.is_file()}

qualification = json.loads((ROOT / 'cci-wide-grid/status.json').read_text(encoding='utf-8'))
assert qualification['gpu_passed'] == 100
assert qualification['unit']['passed'] == 37 and qualification['parity']['passed'] == 20
assert qualification['input_head'] == '22a874f21013d0fc5571e15adeedff57ecbd031e'
assert qualification['status']=='checks-passed-review-and-publication-pending'
assert not subprocess.check_output(['git','diff',qualification['input_head'],SOURCE,'--','src','tests','benchmarks/OoplesFinance.StockIndicators.CompetitorTests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json','examples','scripts','.github','NuGet.Config','nuget.config'],cwd=REPO)
assert not captured.exists()
assert shutil.disk_usage(ROOT).free > sum(p.stat().st_size for p in original.rglob('*') if p.is_file()) + 1024**3
shutil.copytree(original, captured)
binary_manifest = manifest(captured)
assert binary_manifest == manifest(original)
assert binary_manifest['OoplesFinance.StockIndicators.dll'] in qualification['production_dll_sha256'].values()
host_manifest = manifest(host_bin)
assert host_manifest['BenchmarkDotNet.dll'] == binary_manifest['BenchmarkDotNet.dll']
source_manifest = {name: digest(host / name) for name in ['Program.cs', 'LongNativeRunner.csproj']}
(OUT / 'binary-manifest.json').write_text(json.dumps(binary_manifest, indent=2))
(OUT / 'host-manifest.json').write_text(json.dumps(host_manifest, indent=2))
provenance = dict(source_sha=SOURCE, qualification=qualification,
    original_binary_directory=str(original), executed_binary_directory=str(captured),
    host_binary_directory=str(host_bin), host_source_directory=str(host), host_sources=source_manifest,
    selection=selection, fixture=fixture, pair=pair, measurement_location='Local Windows',
    policy='Original benchmark descriptors, parameters and correctness setup. Ten warmups and ten requested measured iterations. Only 10,000-bar NativeSingle/NativeParallel use one invocation; other cases retain adaptive invocation counts. Toolchain timeout 90 minutes, whole-fixture process limit 90 minutes.',
    approval='Explicit user approval for this bounded longer measurement received 2026-10-22.')
(OUT / 'provenance.json').write_text(json.dumps(provenance, indent=2))
state = dict(source_sha=SOURCE, status='waiting-quiet-window', fixture=fixture, fixtures={})

def save():
    state['updated_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (OUT / 'status.json').write_text(json.dumps(state, indent=2))

folder = OUT / fixture
command = ['dotnet', str(host_bin / 'LongNativeRunner.dll'),
    str(captured / 'OoplesFinance.StockIndicators.CompetitorBenchmarks.dll'), selection, str(folder)]
listing = subprocess.check_output(command + ['--list'], cwd=captured, text=True)
assert len([line for line in listing.splitlines() if fixture + '.' in line]) == 8
assert listing.count('InvocationCount=1,') == 2
assert listing.count('WarmupCount=10') == 8 and listing.count('IterationCount=10') == 8
(OUT / 'planned-cases.txt').write_text(listing, encoding='utf-8')
save()
samples = []
while len(samples) < 3 or any(v > 15 for v in samples[-3:]):
    builds = [p.pid for p in psutil.process_iter(['name', 'cmdline'])
        if (p.info['name'] or '').lower() == 'dotnet.exe' and 'build' in (p.info['cmdline'] or [])]
    samples.append(psutil.cpu_percent(interval=5))
    if builds: samples = []
state['fixtures'][fixture] = dict(quiet_cpu_samples=samples[-3:])
state['status'] = 'measuring'
save()
env = os.environ.copy()
env['TEMP'] = env['TMP'] = str(ROOT / 'temp')
try:
    with (OUT / (fixture + '.log')).open('wb') as stream:
        subprocess.run(command, cwd=captured, env=env, stdout=stream, stderr=subprocess.STDOUT, check=True, timeout=5400)
    reports = list((folder / 'results').glob('*-report-full-compressed.json'))
    assert len(reports) == 1
    report = json.loads(reports[0].read_bytes())
    assert len(report['Benchmarks']) == 8
    assert all(c.get('Statistics') and c['Statistics']['N'] >= 7 for c in report['Benchmarks'])
    assert manifest(captured) == binary_manifest == manifest(original)
    assert manifest(host_bin) == host_manifest
    assert {name: digest(host / name) for name in source_manifest} == source_manifest
    state['fixtures'][fixture].update(status='raw-measurements-complete', report=str(reports[0]), sha256=digest(reports[0]), cases=8)
    state['status'] = 'raw-measurements-complete-independent-verification-pending'
    save()
    print(state['status'], flush=True)
except Exception as error:
    state['fixtures'][fixture].update(status='failed', error=str(error))
    state['status'] = 'failed-preserved-for-inspection'
    save()
    raise
