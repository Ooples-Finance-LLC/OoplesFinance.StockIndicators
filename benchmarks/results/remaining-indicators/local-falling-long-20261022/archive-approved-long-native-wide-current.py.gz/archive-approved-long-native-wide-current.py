from pathlib import Path
import gzip, hashlib, json, re, subprocess, sys
ROOT = Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
REPO = Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
run = sys.argv[1]
assert run in ['local-dynamic-long-20261022', 'local-falling-long-20261022']
RAW = ROOT / run
OUT = REPO / 'benchmarks/results/remaining-indicators' / run
summary = json.loads((RAW / 'verified-summary.json').read_text())
proof = json.loads((RAW / 'provenance.json').read_text())
assert summary['all_8_cases_verified']
assert all(r['complete'] and r['run_id'] == run for r in summary['receipts'])
assert not subprocess.check_output(['git', 'diff', summary['source_sha'], 'HEAD', '--', *summary['matched_current_source_paths']], cwd=REPO)
files = [(name, RAW / name) for name in ['verified-summary.json', 'status.json', 'provenance.json', 'binary-manifest.json', 'host-manifest.json', 'planned-cases.txt']]
files += [(r['report_file'], RAW / r['report_file']) for r in summary['receipts']]
files += [(p.name, p) for p in RAW.glob('*.log')]
files += [('host/' + name, Path(proof['host_source_directory']) / name) for name in proof['host_sources']]
files += [('host/build.log', Path(proof['host_source_directory']) / 'build.log')]
files += [(name, ROOT / name) for name in ['measure-approved-long-native-wide-current.py', 'verify-approved-long-native-wide-current.py', 'archive-approved-long-native-wide-current.py']]
OUT.mkdir(exist_ok=True)
archives = {}
for name, path in files:
    raw = path.read_bytes(); target = OUT / (name + '.gz'); target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(raw, mtime=0))
    archives[name] = dict(sha256=hashlib.sha256(raw).hexdigest(), archive=target.relative_to(REPO).as_posix())
(OUT / 'manifest.json').write_text(json.dumps(dict(source_sha=summary['source_sha'], measurement_location='Local Windows; approved bounded longer native measurement',
    cases=8, comparisons=4, partial=False, unchanged_setup_and_method_descriptors=True,
    sampling_policy=proof['policy'], archives=archives), indent=2) + '\n',encoding='utf-8',newline='\n')
(OUT / '.gitattributes').write_bytes(b'* -text\n')
print('Archived complete long-native measurement and exact host source:', run)
