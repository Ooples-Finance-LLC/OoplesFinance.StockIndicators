```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **473.49 μs** |  **7.938 μs** |  **4.724 μs** | **30.63** |    **0.31** |       **-** |      **-** |  **64.99 KB** |        **8.42** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   468.55 μs |  5.252 μs |  3.474 μs | 30.31 |    0.24 |       - |      - |  17.43 KB |        2.26 |
| NativeSingle      | TaLib.Functions.Dx | 1000  |    15.46 μs |  0.108 μs |  0.057 μs |  1.00 |    0.00 |  0.3662 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 1000  |    25.62 μs |  2.032 μs |  1.209 μs |  1.66 |    0.07 |  1.7090 |      - |  27.24 KB |        3.53 |
|                   |                    |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **4,868.76 μs** | **63.703 μs** | **42.136 μs** | **30.92** |    **0.31** | **31.2500** |      **-** | **628.08 KB** |        **8.05** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 4,781.52 μs | 23.539 μs | 15.569 μs | 30.37 |    0.19 |       - |      - | 158.28 KB |        2.03 |
| NativeSingle      | TaLib.Functions.Dx | 10000 |   157.45 μs |  1.535 μs |  0.913 μs |  1.00 |    0.01 |  3.9063 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 10000 |   223.20 μs |  4.597 μs |  2.405 μs |  1.42 |    0.02 | 17.5781 | 3.9063 | 273.35 KB |        3.50 |
