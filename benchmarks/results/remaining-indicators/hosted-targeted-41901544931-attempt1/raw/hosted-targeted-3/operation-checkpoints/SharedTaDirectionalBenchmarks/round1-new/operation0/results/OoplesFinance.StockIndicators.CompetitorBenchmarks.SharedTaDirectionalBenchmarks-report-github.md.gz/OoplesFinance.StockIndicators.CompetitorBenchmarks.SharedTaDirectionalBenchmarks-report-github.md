```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev  | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **452.1 μs** |  **3.06 μs** | **1.82 μs** |       **-** |  **65.02 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   448.8 μs |  4.08 μs | 2.43 μs |       - |  17.43 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **4,647.9 μs** | **15.05 μs** | **7.87 μs** | **31.2500** | **628.09 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 4,591.5 μs | 13.90 μs | 7.27 μs |       - | 158.26 KB |
