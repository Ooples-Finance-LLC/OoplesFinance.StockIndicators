```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **458.0 μs** |  **4.63 μs** |  **2.76 μs** |       **-** |  **65.02 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   449.3 μs |  3.76 μs |  1.97 μs |       - |  17.43 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **4,726.4 μs** | **62.35 μs** | **37.10 μs** | **31.2500** | **628.09 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 4,630.9 μs | 28.51 μs | 16.97 μs |       - | 158.28 KB |
