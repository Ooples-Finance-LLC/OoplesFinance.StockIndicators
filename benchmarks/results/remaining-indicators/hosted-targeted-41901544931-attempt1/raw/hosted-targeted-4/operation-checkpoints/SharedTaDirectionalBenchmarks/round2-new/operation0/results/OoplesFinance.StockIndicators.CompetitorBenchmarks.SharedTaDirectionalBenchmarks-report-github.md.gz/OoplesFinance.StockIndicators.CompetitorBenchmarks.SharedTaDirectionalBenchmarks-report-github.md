```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **225.911 μs** |  **6.3599 μs** |  **3.7847 μs** | **30.53** |    **0.55** |       **-** |      **-** |  **65.01 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   220.757 μs |  0.7107 μs |  0.4229 μs | 29.83 |    0.25 |       - |      - |  17.41 KB |        2.26 |
| NativeSingle      | TaLib(...)nusDI [23] | 1000  |     7.401 μs |  0.0977 μs |  0.0647 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 1000  |    11.898 μs |  0.7360 μs |  0.4868 μs |  1.61 |    0.06 |  1.8311 |      - |  27.24 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **2,175.303 μs** | **12.7441 μs** |  **7.5838 μs** | **29.86** |    **0.51** | **31.2500** |      **-** | **627.98 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,134.509 μs | 17.4956 μs | 11.5722 μs | 29.30 |    0.51 |       - |      - | 158.16 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDI [23] | 10000 |    72.860 μs |  2.1893 μs |  1.3028 μs |  1.00 |    0.02 |  4.3945 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 10000 |   120.778 μs |  9.4598 μs |  6.2571 μs |  1.66 |    0.09 | 17.5781 | 4.8828 | 273.34 KB |        3.50 |
