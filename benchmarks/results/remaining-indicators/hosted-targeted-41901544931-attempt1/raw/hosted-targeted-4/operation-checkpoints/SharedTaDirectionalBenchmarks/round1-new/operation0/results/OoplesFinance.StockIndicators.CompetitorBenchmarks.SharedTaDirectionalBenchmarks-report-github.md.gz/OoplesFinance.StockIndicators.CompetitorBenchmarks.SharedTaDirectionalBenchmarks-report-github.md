```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **223.5 μs** |  **1.97 μs** |  **1.17 μs** |       **-** |  **65.01 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   222.4 μs |  1.92 μs |  1.15 μs |       - |  17.41 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **2,141.5 μs** |  **7.22 μs** |  **4.29 μs** | **31.2500** | **627.98 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,116.6 μs | 17.71 μs | 11.71 μs |       - | 158.15 KB |
