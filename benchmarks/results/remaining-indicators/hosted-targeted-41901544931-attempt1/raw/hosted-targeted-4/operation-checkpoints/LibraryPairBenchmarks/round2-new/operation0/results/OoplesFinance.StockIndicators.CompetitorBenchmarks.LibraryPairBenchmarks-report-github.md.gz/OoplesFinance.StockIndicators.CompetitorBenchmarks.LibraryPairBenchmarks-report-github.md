```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDI [23]** |   **260.19 μs** |  **3.612 μs** |  **2.150 μs** |  **1.00** |  **105.69 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDI [23] |    16.34 μs |  0.785 μs |  0.519 μs |  0.06 |   40.55 KB |        0.38 |
|            |       |                      |             |           |           |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDI [23]** | **2,352.84 μs** | **27.133 μs** | **16.146 μs** |  **1.00** | **1036.74 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDI [23] |   153.39 μs | 17.726 μs | 11.725 μs |  0.07 |  330.64 KB |        0.32 |
