```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **446.40 μs** |  **6.289 μs** |  **3.742 μs** | **25.76** |    **0.22** |       **-** |      **-** |  **66.31 KB** |        **4.42** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   444.04 μs |  4.674 μs |  2.445 μs | 25.63 |    0.15 |       - |      - |  18.72 KB |        1.25 |
| NativeSingle      | TaLib.Functions.Adxr | 1000  |    17.33 μs |  0.088 μs |  0.052 μs |  1.00 |    0.00 |  0.8545 |      - |  14.99 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 1000  |    32.68 μs |  1.460 μs |  0.869 μs |  1.89 |    0.05 |  3.1738 |      - |  45.43 KB |        3.03 |
|                   |                      |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **4,712.50 μs** | **32.360 μs** | **16.925 μs** | **27.26** |    **0.26** | **31.2500** |      **-** | **632.01 KB** |        **4.06** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 4,751.56 μs | 58.959 μs | 38.997 μs | 27.48 |    0.32 |       - |      - | 162.18 KB |        1.04 |
| NativeSingle      | TaLib.Functions.Adxr | 10000 |   172.89 μs |  2.401 μs |  1.588 μs |  1.00 |    0.01 |  8.7891 | 0.9766 | 155.63 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 10000 |   271.30 μs | 23.784 μs | 15.732 μs |  1.57 |    0.09 | 29.2969 | 9.7656 | 467.32 KB |        3.00 |
