```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adxr** |   **543.55 μs** | **33.580 μs** | **22.211 μs** |  **1.00** |    **0.05** |  **106.98 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adxr |    32.78 μs |  9.419 μs |  6.230 μs |  0.06 |    0.01 |   48.45 KB |        0.45 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adxr** | **4,964.71 μs** | **42.957 μs** | **25.563 μs** |  **1.00** |    **0.01** | **1040.59 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adxr |   257.30 μs | 23.934 μs | 15.831 μs |  0.05 |    0.00 |   405.9 KB |        0.39 |
