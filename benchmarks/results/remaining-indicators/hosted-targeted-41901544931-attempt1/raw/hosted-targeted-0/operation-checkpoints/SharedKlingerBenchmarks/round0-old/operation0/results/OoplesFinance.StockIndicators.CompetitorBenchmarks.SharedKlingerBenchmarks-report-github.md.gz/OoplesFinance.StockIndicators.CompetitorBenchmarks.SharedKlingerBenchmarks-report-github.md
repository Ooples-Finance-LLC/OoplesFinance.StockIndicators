```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetKvo** | **1000**  |   **738.1 μs** |  **3.80 μs** |  **2.26 μs** |  **81.21 KB** |
| BuilderLatestOnly | Skender.GetKvo | 1000  |   786.1 μs | 18.01 μs | 11.91 μs |  33.63 KB |
| **BuilderFull**       | **Skender.GetKvo** | **10000** | **7,568.1 μs** | **39.75 μs** | **23.66 μs** | **785.05 KB** |
| BuilderLatestOnly | Skender.GetKvo | 10000 | 7,542.0 μs | 15.99 μs |  8.36 μs | 315.21 KB |
