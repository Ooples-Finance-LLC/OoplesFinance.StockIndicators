```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetKvo** | **1000**  |   **686.2 μs** |  **5.02 μs** |  **2.98 μs** |  **81.29 KB** |
| BuilderLatestOnly | Skender.GetKvo | 1000  |   676.5 μs |  3.14 μs |  1.87 μs |  33.64 KB |
| **BuilderFull**       | **Skender.GetKvo** | **10000** | **6,880.8 μs** | **70.52 μs** | **36.89 μs** | **784.98 KB** |
| BuilderLatestOnly | Skender.GetKvo | 10000 | 6,859.0 μs | 34.32 μs | 17.95 μs | 315.21 KB |
