```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Gen0   | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetKvo** | **1000**  |   **761.6 μs** | **10.62 μs** |  **7.03 μs** | **3.9063** |  **81.21 KB** |
| BuilderLatestOnly | Skender.GetKvo | 1000  |   745.7 μs |  3.51 μs |  2.09 μs |      - |  33.62 KB |
| **BuilderFull**       | **Skender.GetKvo** | **10000** | **7,612.6 μs** | **20.46 μs** | **10.70 μs** |      **-** |  **785.1 KB** |
| BuilderLatestOnly | Skender.GetKvo | 10000 | 7,539.5 μs | 32.08 μs | 16.78 μs |      - | 315.29 KB |
