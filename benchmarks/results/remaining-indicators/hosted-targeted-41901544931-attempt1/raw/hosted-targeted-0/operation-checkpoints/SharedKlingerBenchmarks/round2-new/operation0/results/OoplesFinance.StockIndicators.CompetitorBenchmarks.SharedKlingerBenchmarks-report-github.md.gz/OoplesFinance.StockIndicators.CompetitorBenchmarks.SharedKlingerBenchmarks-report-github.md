```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetKvo** | **1000**  |   **688.04 μs** |   **8.853 μs** |  **5.268 μs** | **12.54** |    **0.22** |        **-** |        **-** |   **81.25 KB** |        **0.39** |
| BuilderLatestOnly | Skender.GetKvo | 1000  |   678.39 μs |   7.228 μs |  3.780 μs | 12.36 |    0.21 |        - |        - |   33.64 KB |        0.16 |
| NativeSingle      | Skender.GetKvo | 1000  |    54.90 μs |   1.380 μs |  0.912 μs |  1.00 |    0.02 |  12.6953 |   3.9063 |  207.63 KB |        1.00 |
| NativeParallel    | Skender.GetKvo | 1000  |   105.32 μs |   5.002 μs |  2.616 μs |  1.92 |    0.05 |  33.2031 |  10.7422 |  528.18 KB |        2.54 |
|                   |                |       |             |            |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetKvo** | **10000** | **6,805.61 μs** | **121.176 μs** | **72.110 μs** | **11.12** |    **0.14** |        **-** |        **-** |  **785.24 KB** |        **0.38** |
| BuilderLatestOnly | Skender.GetKvo | 10000 | 6,889.21 μs |  27.806 μs | 14.543 μs | 11.26 |    0.09 |        - |        - |   315.3 KB |        0.15 |
| NativeSingle      | Skender.GetKvo | 10000 |   611.93 μs |   9.743 μs |  5.096 μs |  1.00 |    0.01 | 125.0000 |  78.1250 | 2070.92 KB |        1.00 |
| NativeParallel    | Skender.GetKvo | 10000 | 1,090.57 μs |  85.657 μs | 56.657 μs |  1.78 |    0.09 | 320.3125 | 257.8125 | 5256.75 KB |        2.54 |
