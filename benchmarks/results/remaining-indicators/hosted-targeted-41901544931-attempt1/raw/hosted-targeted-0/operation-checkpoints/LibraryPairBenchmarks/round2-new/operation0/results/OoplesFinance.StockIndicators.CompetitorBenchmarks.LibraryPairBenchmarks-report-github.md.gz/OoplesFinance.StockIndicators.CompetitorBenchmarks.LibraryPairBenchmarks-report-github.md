```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetKvo** |   **860.34 μs** | **20.461 μs** | **13.534 μs** |  **1.00** |    **0.02** |  **162.97 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetKvo |    63.61 μs |  3.934 μs |  2.057 μs |  0.07 |    0.00 |  270.22 KB |        1.66 |
|            |       |                |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetKvo** | **8,186.30 μs** | **35.945 μs** | **18.800 μs** |  **1.00** |    **0.00** | **1593.03 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetKvo |   667.06 μs | 33.465 μs | 19.915 μs |  0.08 |    0.00 | 2646.55 KB |        1.66 |
