```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **217.0 μs** |  **2.80 μs** |  **1.46 μs** |       **-** |  **65.01 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   215.5 μs |  2.77 μs |  1.45 μs |       - |  17.41 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **2,154.7 μs** | **10.59 μs** |  **5.54 μs** | **31.2500** | **627.97 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,114.6 μs | 31.70 μs | 16.58 μs |       - | 158.13 KB |
