```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **212.872 μs** |  **9.0296 μs** | **5.3734 μs** | **28.88** |    **0.71** |       **-** |      **-** |  **65.01 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   209.078 μs |  2.3447 μs | 1.3953 μs | 28.36 |    0.23 |       - |      - |  17.41 KB |        2.26 |
| NativeSingle      | TaLib(...)lusDI [22] | 1000  |     7.371 μs |  0.0640 μs | 0.0381 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 1000  |    12.380 μs |  0.7515 μs | 0.4971 μs |  1.68 |    0.06 |  1.8311 |      - |  27.24 KB |        3.53 |
|                   |                      |       |              |            |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **2,081.392 μs** | **15.3889 μs** | **9.1577 μs** | **28.25** |    **0.15** | **31.2500** |      **-** | **627.98 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,055.283 μs |  7.5634 μs | 3.9558 μs | 27.90 |    0.10 |       - |      - | 158.13 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDI [22] | 10000 |    73.671 μs |  0.3742 μs | 0.2475 μs |  1.00 |    0.00 |  4.3945 |      - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 10000 |   122.828 μs |  3.9572 μs | 2.0697 μs |  1.67 |    0.03 | 17.5781 | 3.9063 | 273.34 KB |        3.50 |
