```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDI [22]** |   **251.90 μs** |  **3.608 μs** |  **1.887 μs** |  **1.00** |  **105.69 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDI [22] |    18.82 μs |  4.118 μs |  2.450 μs |  0.07 |   40.55 KB |        0.38 |
|            |       |                      |             |           |           |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDI [22]** | **2,321.77 μs** | **25.548 μs** | **15.203 μs** |  **1.00** | **1036.41 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDI [22] |   174.82 μs | 12.203 μs |  8.071 μs |  0.08 |  330.59 KB |        0.32 |
