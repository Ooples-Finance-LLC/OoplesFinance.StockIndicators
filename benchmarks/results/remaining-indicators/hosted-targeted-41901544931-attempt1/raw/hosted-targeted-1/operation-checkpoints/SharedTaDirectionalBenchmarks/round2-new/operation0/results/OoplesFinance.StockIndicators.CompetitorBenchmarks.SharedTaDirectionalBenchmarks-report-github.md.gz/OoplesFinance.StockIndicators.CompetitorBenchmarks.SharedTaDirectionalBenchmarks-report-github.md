```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error     | StdDev   | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|----------:|---------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **423.94 μs** |  **3.669 μs** | **2.184 μs** | **28.15** |    **0.17** |       **-** |      **-** |  **65.24 KB** |        **8.62** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   420.32 μs |  4.873 μs | 2.900 μs | 27.91 |    0.21 |       - |      - |  17.65 KB |        2.33 |
| NativeSingle      | TaLib.Functions.Adx | 1000  |    15.06 μs |  0.100 μs | 0.059 μs |  1.00 |    0.01 |  0.3662 |      - |   7.57 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 1000  |    27.41 μs |  1.060 μs | 0.554 μs |  1.82 |    0.04 |  1.7090 |      - |  26.71 KB |        3.53 |
|                   |                     |       |             |           |          |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **4,429.35 μs** | **14.475 μs** | **8.614 μs** | **29.07** |    **0.16** | **31.2500** |      **-** | **630.92 KB** |        **8.10** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 4,391.06 μs | 17.114 μs | 8.951 μs | 28.82 |    0.16 |       - |      - | 161.11 KB |        2.07 |
| NativeSingle      | TaLib.Functions.Adx | 10000 |   152.35 μs |  1.444 μs | 0.860 μs |  1.00 |    0.01 |  3.9063 |      - |  77.89 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 10000 |   221.46 μs |  6.774 μs | 3.543 μs |  1.45 |    0.02 | 17.5781 | 3.9063 | 272.82 KB |        3.50 |
