```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **421.0 μs** | **19.66 μs** | **11.70 μs** |       **-** |  **65.24 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   408.4 μs | 12.00 μs |  7.14 μs |       - |  17.65 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **4,343.7 μs** | **55.97 μs** | **29.27 μs** | **31.2500** | **630.89 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 4,270.5 μs | 25.67 μs | 13.43 μs |       - | 161.08 KB |
