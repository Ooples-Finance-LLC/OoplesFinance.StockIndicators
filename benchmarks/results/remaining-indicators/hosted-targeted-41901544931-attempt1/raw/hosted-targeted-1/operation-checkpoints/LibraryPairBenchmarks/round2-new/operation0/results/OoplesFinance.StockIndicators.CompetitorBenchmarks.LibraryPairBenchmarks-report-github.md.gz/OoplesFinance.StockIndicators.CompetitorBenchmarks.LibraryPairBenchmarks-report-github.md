```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adx** |   **482.14 μs** | **36.741 μs** | **24.302 μs** |  **1.00** |    **0.07** |  **105.91 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adx |    24.05 μs |  0.560 μs |  0.293 μs |  0.05 |    0.00 |   40.27 KB |        0.38 |
|            |       |                     |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adx** | **4,489.20 μs** |  **9.920 μs** |  **5.188 μs** |  **1.00** |    **0.00** | **1031.69 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adx |   227.36 μs | 11.070 μs |  5.790 μs |  0.05 |    0.00 |  330.59 KB |        0.32 |
