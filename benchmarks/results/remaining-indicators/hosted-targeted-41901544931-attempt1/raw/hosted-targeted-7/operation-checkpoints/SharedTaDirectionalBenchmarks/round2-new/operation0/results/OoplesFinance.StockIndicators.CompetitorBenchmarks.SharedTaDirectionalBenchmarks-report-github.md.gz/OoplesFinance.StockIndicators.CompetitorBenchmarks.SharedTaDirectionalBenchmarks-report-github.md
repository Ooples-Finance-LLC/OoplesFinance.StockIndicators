```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **134.64 μs** |  **4.359 μs** |  **2.280 μs** | **13.26** |    **0.23** |  **3.9063** |      **-** |  **65.01 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   131.31 μs |  0.711 μs |  0.470 μs | 12.93 |    0.10 |  0.9766 |      - |  17.41 KB |        2.26 |
| NativeSingle      | TaLib(...)lusDM [22] | 1000  |    10.16 μs |  0.119 μs |  0.071 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 1000  |    13.33 μs |  0.479 μs |  0.251 μs |  1.31 |    0.02 |  1.8311 |      - |  27.23 KB |        3.53 |
|                   |                      |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **1,289.09 μs** | **20.767 μs** | **12.358 μs** | **12.28** |    **0.15** | **31.2500** | **7.8125** | **627.92 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 1,280.90 μs | 33.639 μs | 20.018 μs | 12.20 |    0.21 |  7.8125 |      - | 158.09 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDM [22] | 10000 |   104.98 μs |  1.376 μs |  0.910 μs |  1.00 |    0.01 |  3.9063 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 10000 |   157.71 μs |  4.079 μs |  2.698 μs |  1.50 |    0.03 | 17.5781 | 3.9063 | 273.33 KB |        3.50 |
