```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |  **75.79 μs** |  **4.789 μs** |  **2.850 μs** |  **3.9063** |       **-** |  **65.01 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |  70.10 μs |  0.820 μs |  0.429 μs |  0.9766 |       - |   17.4 KB |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **716.32 μs** | **36.962 μs** | **21.996 μs** | **35.1563** | **11.7188** | **627.88 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 693.21 μs | 16.272 μs | 10.763 μs |  7.8125 |       - | 158.04 KB |
