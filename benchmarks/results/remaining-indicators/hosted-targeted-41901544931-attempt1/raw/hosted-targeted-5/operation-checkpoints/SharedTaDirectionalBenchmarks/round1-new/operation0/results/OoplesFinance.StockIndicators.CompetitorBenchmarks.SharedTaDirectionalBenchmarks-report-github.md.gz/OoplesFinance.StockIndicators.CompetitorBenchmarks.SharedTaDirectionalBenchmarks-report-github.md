```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |  **77.75 μs** |  **1.129 μs** |  **0.590 μs** |  **3.9063** |  **0.4883** |  **65.01 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |  73.21 μs |  2.181 μs |  1.442 μs |  0.9766 |       - |   17.4 KB |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **713.88 μs** | **11.630 μs** |  **6.083 μs** | **35.1563** | **11.7188** | **627.86 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 702.33 μs | 23.960 μs | 15.848 μs |  7.8125 |       - | 158.03 KB |
