```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |  **74.493 μs** |  **2.2996 μs** |  **1.3685 μs** |  **8.98** |    **0.23** |  **3.9063** |       **-** |  **65.01 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |  71.270 μs |  2.4770 μs |  1.6384 μs |  8.59 |    0.24 |  0.9766 |       - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDM [23] | 1000  |   8.299 μs |  0.2383 μs |  0.1576 μs |  1.00 |    0.03 |  0.4272 |       - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 1000  |   9.579 μs |  0.6269 μs |  0.4147 μs |  1.15 |    0.05 |  1.7700 |  0.0610 |  27.23 KB |        3.53 |
|                   |                      |       |            |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **693.822 μs** | **30.7871 μs** | **20.3638 μs** |  **8.82** |    **0.34** | **35.1563** | **11.7188** | **627.88 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 684.949 μs | 19.7981 μs | 13.0952 μs |  8.70 |    0.27 |  7.8125 |       - | 158.05 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDM [23] | 10000 |  78.744 μs |  3.6266 μs |  2.1581 μs |  1.00 |    0.04 |  4.3945 |       - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 10000 | 119.510 μs |  4.2716 μs |  2.5419 μs |  1.52 |    0.05 | 17.5781 |  3.9063 | 273.33 KB |        3.50 |
