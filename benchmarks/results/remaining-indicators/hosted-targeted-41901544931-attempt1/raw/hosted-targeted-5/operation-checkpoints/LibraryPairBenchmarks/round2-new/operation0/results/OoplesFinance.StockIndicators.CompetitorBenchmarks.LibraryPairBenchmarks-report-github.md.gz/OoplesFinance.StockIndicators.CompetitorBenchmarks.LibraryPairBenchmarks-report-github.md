```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDM [23]** | **514.55 μs** | **42.575 μs** | **28.161 μs** |  **1.00** |    **0.07** |  **105.73 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDM [23] |  47.52 μs |  0.344 μs |  0.205 μs |  0.09 |    0.00 |   38.91 KB |        0.37 |
|            |       |                      |           |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDM [23]** | **836.90 μs** | **21.710 μs** | **12.919 μs** |  **1.00** |    **0.02** | **1031.49 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDM [23] | 104.77 μs |  2.475 μs |  1.473 μs |  0.13 |    0.00 |  328.29 KB |        0.32 |
