from pathlib import Path
import gzip,hashlib,json
ROOT=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
RAW=ROOT/'local-t3-certified-control-20261022'
REPO=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
OUT=REPO/'benchmarks/results/remaining-indicators/local-t3-certified-control-20261022'
summary=json.loads((RAW/'verified-summary.json').read_text(encoding='utf-8'))
assert summary['all_144_cases_verified']
accepted=not any(r['verdict']=='slower' for r in summary['decisions']) and any(r['verdict']=='faster' for r in summary['decisions'])
state=json.loads((RAW/'status.json').read_text(encoding='utf-8'))
paths=['status.json','provenance.json','binary-manifest.json','verified-summary.json']
paths += [Path(r['report']).relative_to(RAW).as_posix() for r in state['rounds']]
paths += [p.name for p in RAW.glob('*.log')]
OUT.mkdir(exist_ok=True)
manifest={}
for name in paths:
 data=(RAW/name).read_bytes();target=OUT/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(gzip.compress(data,mtime=0));manifest[name]={'sha256':hashlib.sha256(data).hexdigest(),'archive':target.relative_to(REPO).as_posix()}
scripts={}
for name in ['measure-t3-certified-control.py','verify-t3-certified-control.py']:
 data=(ROOT/name).read_bytes();(OUT/(name+'.gz')).write_bytes(gzip.compress(data,mtime=0));scripts[name]=hashlib.sha256(data).hexdigest()
(OUT/'decision.json').write_text(json.dumps({'status':'candidate-qualified-for-integration' if accepted else 'candidate-rejected-or-inconclusive','sources':summary['sources'],'candidate_code_source':'f2e1d75429289dc36ff9097c83aa435366c6eb0e','measurement_location':'Local Windows; preserved source-qualified binaries; only production DLL differs','decisions':summary['decisions'],'archives':manifest,'scripts':scripts,'report_imported':False,'production_integrated':False},indent=2)+'\n',encoding='utf-8')
(OUT/'.gitattributes').write_bytes(b'* -text\n')
print('Archived144 cases; qualified for integration:',accepted)
