```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetPrs** | **1000**  |   **250.39 μs** |  **73.567 μs** |  **48.660 μs** |  **4.01** |    **0.74** |        **-** |        **-** |        **-** |   **101.9 KB** |        **0.62** |
| BuilderLatestOnly | Skender.GetPrs | 1000  |   190.06 μs |  40.011 μs |  23.810 μs |  3.04 |    0.36 |   1.9531 |        - |        - |   54.21 KB |        0.33 |
| NativeSingle      | Skender.GetPrs | 1000  |    62.50 μs |   1.037 μs |   0.542 μs |  1.00 |    0.01 |   6.3477 |   0.9766 |        - |  164.79 KB |        1.00 |
| NativeParallel    | Skender.GetPrs | 1000  |    48.74 μs |   4.111 μs |   2.719 μs |  0.78 |    0.04 |   8.5449 |   1.7090 |        - |  184.81 KB |        1.12 |
|                   |                |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetPrs** | **10000** | **1,484.70 μs** | **169.732 μs** | **112.267 μs** |  **1.26** |    **0.13** |  **31.2500** |  **15.6250** |        **-** |  **945.98 KB** |        **0.58** |
| BuilderLatestOnly | Skender.GetPrs | 10000 | 1,358.67 μs |  23.640 μs |  12.364 μs |  1.15 |    0.08 |  15.6250 |        - |        - |  476.23 KB |        0.29 |
| NativeSingle      | Skender.GetPrs | 10000 | 1,182.80 μs | 133.869 μs |  88.546 μs |  1.01 |    0.10 | 187.5000 | 156.2500 | 148.4375 | 1643.04 KB |        1.00 |
| NativeParallel    | Skender.GetPrs | 10000 |   522.86 μs |  51.284 μs |  33.921 μs |  0.44 |    0.04 |  74.2188 |  31.2500 |        - | 1731.72 KB |        1.05 |
