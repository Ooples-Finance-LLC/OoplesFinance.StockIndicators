```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |--------------- |------ |-----------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetPrs** | **1000**  |   **572.2 μs** | **172.98 μs** | **114.42 μs** |  **31.2500** |        **-** |  **991.02 KB** |
| BuilderLatestOnly | Skender.GetPrs | 1000  |   466.4 μs |  72.53 μs |  47.97 μs |  35.1563 |   3.9063 |  943.43 KB |
| **BuilderFull**       | **Skender.GetPrs** | **10000** | **4,535.6 μs** | **423.90 μs** | **280.38 μs** | **375.0000** | **187.5000** | **9429.37 KB** |
| BuilderLatestOnly | Skender.GetPrs | 10000 | 4,706.9 μs | 699.25 μs | 462.51 μs | 343.7500 | 156.2500 |  8959.5 KB |
