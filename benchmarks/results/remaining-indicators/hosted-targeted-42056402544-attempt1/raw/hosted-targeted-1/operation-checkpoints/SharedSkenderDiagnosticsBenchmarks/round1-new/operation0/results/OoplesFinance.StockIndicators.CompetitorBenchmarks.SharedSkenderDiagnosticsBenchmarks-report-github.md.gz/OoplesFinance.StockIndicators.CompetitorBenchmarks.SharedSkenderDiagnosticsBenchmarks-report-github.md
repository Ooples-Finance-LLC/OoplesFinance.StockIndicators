```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetPrs** | **1000**  |   **243.7 μs** |  **63.99 μs** |  **42.32 μs** |       **-** |       **-** | **101.81 KB** |
| BuilderLatestOnly | Skender.GetPrs | 1000  |   227.9 μs |  27.86 μs |  18.43 μs |  1.9531 |       - |  54.21 KB |
| **BuilderFull**       | **Skender.GetPrs** | **10000** | **1,529.1 μs** | **252.57 μs** | **167.06 μs** | **31.2500** | **15.6250** | **945.98 KB** |
| BuilderLatestOnly | Skender.GetPrs | 10000 | 1,474.3 μs | 222.57 μs | 147.21 μs | 15.6250 |       - | 476.14 KB |
