```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetPrs** |   **200.40 μs** |  **17.49 μs** |  **9.147 μs** |  **1.00** |    **0.06** | **221.55 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetPrs |    89.64 μs |  12.59 μs |  7.493 μs |  0.45 |    0.04 |  254.3 KB |        1.15 |
|            |       |                |             |           |           |       |         |           |             |
| **Ooples**     | **10000** | **Skender.GetPrs** | **1,555.81 μs** |  **59.55 μs** | **35.438 μs** |  **1.00** |    **0.03** | **2153.2 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetPrs |   948.79 μs | 148.42 μs | 77.627 μs |  0.61 |    0.05 | 2457.4 KB |        1.14 |
