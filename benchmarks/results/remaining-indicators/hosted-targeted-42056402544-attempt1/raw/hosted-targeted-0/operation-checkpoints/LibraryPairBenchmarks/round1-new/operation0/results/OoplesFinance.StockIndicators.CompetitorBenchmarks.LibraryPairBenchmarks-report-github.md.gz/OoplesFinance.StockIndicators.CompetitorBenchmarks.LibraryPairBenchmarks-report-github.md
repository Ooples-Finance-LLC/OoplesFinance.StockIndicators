```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId         | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------- |-----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetPrs** |   **266.9 μs** | **33.30 μs** | **19.82 μs** |  **1.01** |    **0.10** | **221.55 KB** |        **1.00** |
|        |       |                |            |          |          |       |         |           |             |
| **Ooples** | **10000** | **Skender.GetPrs** | **1,460.9 μs** | **41.01 μs** | **24.40 μs** |  **1.00** |    **0.02** | **2153.9 KB** |        **1.00** |
