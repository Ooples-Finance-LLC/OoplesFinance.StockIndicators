```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Crows [31]** |  **91.69 μs** | **24.47 μs** | **16.18 μs** |  **1.03** |    **0.25** |  **65.13 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Crows [31] |  73.89 μs | 21.49 μs | 14.21 μs |  0.83 |    0.21 |  19.63 KB |        0.30 |
|            |       |                      |           |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Crows [31]** | **222.52 μs** | **45.11 μs** | **26.85 μs** |  **1.01** |    **0.17** | **637.48 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Crows [31] | 526.79 μs | 28.13 μs | 18.61 μs |  2.40 |    0.31 | 124.72 KB |        0.20 |
