```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)River [30]** |  **83.21 μs** |  **16.336 μs** |   **9.721 μs** |  **1.01** |    **0.15** |  **68.66 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)River [30] |  59.19 μs |   2.143 μs |   1.275 μs |  0.72 |    0.07 |  19.58 KB |        0.29 |
|            |       |                      |           |            |            |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)River [30]** | **319.96 μs** | **183.832 μs** | **121.593 μs** |  **1.11** |    **0.52** | **639.28 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)River [30] | 541.40 μs |  17.002 μs |  11.246 μs |  1.87 |    0.52 | 125.38 KB |        0.20 |
