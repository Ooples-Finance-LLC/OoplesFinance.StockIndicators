```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Crows [22]** |  **73.10 μs** |  **5.810 μs** |  **3.039 μs** |  **1.00** |    **0.06** |  **65.13 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Crows [22] |  53.11 μs |  4.126 μs |  2.729 μs |  0.73 |    0.05 |  19.58 KB |        0.30 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Crows [22]** | **247.87 μs** | **50.576 μs** | **30.097 μs** |  **1.01** |    **0.16** |    **639 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Crows [22] | 316.07 μs | 14.314 μs |  9.468 μs |  1.29 |    0.15 | 125.09 KB |        0.20 |
