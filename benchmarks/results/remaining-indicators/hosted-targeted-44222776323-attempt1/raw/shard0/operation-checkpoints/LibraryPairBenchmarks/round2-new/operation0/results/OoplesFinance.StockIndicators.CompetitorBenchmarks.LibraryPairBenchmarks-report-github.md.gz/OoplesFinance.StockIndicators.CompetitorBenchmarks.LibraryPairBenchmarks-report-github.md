```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nside [25]** |   **191.88 μs** |  **21.158 μs** |  **12.591 μs** |  **1.00** |    **0.09** |  **68.63 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nside [25] |    61.24 μs |   2.553 μs |   1.335 μs |  0.32 |    0.02 |  19.25 KB |        0.28 |
|            |       |                      |             |            |            |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)nside [25]** | **1,013.72 μs** | **362.090 μs** | **239.500 μs** |  **1.06** |    **0.38** | **638.92 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nside [25] |   587.77 μs |  24.074 μs |  15.924 μs |  0.62 |    0.17 | 125.05 KB |        0.20 |
