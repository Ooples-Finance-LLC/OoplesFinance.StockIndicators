```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean     | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |---------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)River [30]** | **188.0 μs** |  **56.07 μs** | **37.08 μs** |  **1.04** |    **0.30** |  **68.66 KB** |        **1.00** |
|        |       |                      |          |           |          |       |         |           |             |
| **Ooples** | **10000** | **TaLib(...)River [30]** | **622.8 μs** | **105.52 μs** | **55.19 μs** |  **1.01** |    **0.12** |    **639 KB** |        **1.00** |
