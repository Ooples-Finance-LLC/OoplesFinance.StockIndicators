```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)Crows [31]** | **1000**  | **183.2 μs** | **18.53 μs** | **12.26 μs** |       **-** |  **64.25 KB** |
| BuilderLatestOnly | TaLib(...)Crows [31] | 1000  | 173.5 μs |  7.67 μs |  5.07 μs |       - |  16.38 KB |
| **BuilderFull**       | **TaLib(...)Crows [31]** | **10000** | **864.8 μs** | **86.53 μs** | **57.24 μs** | **15.6250** | **556.84 KB** |
| BuilderLatestOnly | TaLib(...)Crows [31] | 10000 | 857.6 μs | 67.33 μs | 40.07 μs |       - |  86.75 KB |
