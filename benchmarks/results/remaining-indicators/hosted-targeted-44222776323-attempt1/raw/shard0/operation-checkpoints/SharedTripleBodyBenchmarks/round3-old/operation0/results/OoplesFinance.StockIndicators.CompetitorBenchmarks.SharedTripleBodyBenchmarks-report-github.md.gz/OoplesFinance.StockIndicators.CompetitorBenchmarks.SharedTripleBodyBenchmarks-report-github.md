```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error     | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |---------:|----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)nside [25]** | **1000**  | **276.9 μs** | **194.11 μs** | **128.39 μs** |       **-** |      **-** |  **64.25 KB** |
| BuilderLatestOnly | TaLib(...)nside [25] | 1000  | 121.7 μs |   5.77 μs |   3.43 μs |       - |      - |  16.38 KB |
| **BuilderFull**       | **TaLib(...)nside [25]** | **10000** | **539.6 μs** |  **64.43 μs** |  **38.34 μs** | **19.5313** | **3.9063** | **556.81 KB** |
| BuilderLatestOnly | TaLib(...)nside [25] | 10000 | 512.3 μs |  62.04 μs |  41.04 μs |       - |      - |  86.71 KB |
