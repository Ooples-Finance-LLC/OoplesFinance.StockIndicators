```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error     | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |---------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)River [30]** | **1000**  | **178.8 μs** |  **12.24 μs** |  **7.28 μs** |       **-** |  **64.22 KB** |
| BuilderLatestOnly | TaLib(...)River [30] | 1000  | 175.6 μs |   8.52 μs |  5.63 μs |       - |  16.38 KB |
| **BuilderFull**       | **TaLib(...)River [30]** | **10000** | **870.0 μs** | **113.89 μs** | **75.33 μs** | **15.6250** | **556.81 KB** |
| BuilderLatestOnly | TaLib(...)River [30] | 10000 | 798.7 μs |  87.10 μs | 51.83 μs |       - |  86.69 KB |
