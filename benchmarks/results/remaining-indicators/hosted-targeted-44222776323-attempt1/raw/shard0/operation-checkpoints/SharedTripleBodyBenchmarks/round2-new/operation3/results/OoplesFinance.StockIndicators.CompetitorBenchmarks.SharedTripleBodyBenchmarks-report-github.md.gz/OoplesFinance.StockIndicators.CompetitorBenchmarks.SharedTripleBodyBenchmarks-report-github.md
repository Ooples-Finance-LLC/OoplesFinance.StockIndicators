```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)River [30]** | **1000**  |  **42.29 μs** |  **0.356 μs** |  **0.212 μs** |  **1.00** |    **0.01** |       **-** |      **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)River [30] | 1000  | 104.88 μs |  9.986 μs |  6.605 μs |  2.48 |    0.15 |       - |      - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib(...)River [30] | 1000  |  98.20 μs |  6.340 μs |  4.194 μs |  2.32 |    0.10 |  1.9531 |      - |  62.49 KB |       15.75 |
| BuilderLatestOnly | TaLib(...)River [30] | 1000  |  95.53 μs |  6.535 μs |  4.322 μs |  2.26 |    0.10 |       - |      - |  14.61 KB |        3.68 |
|                   |                      |       |           |           |           |       |         |         |        |           |             |
| **NativeSingle**      | **TaLib(...)River [30]** | **10000** | **426.54 μs** |  **2.852 μs** |  **1.492 μs** |  **1.00** |    **0.00** |       **-** |      **-** |  **39.16 KB** |        **1.00** |
| NativeParallel    | TaLib(...)River [30] | 10000 | 321.66 μs | 31.316 μs | 20.714 μs |  0.75 |    0.05 |  3.9063 |      - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib(...)River [30] | 10000 | 301.10 μs | 38.656 μs | 25.569 μs |  0.71 |    0.06 | 21.4844 | 7.8125 |  556.8 KB |       14.22 |
| BuilderLatestOnly | TaLib(...)River [30] | 10000 | 259.47 μs | 32.515 μs | 21.506 μs |  0.61 |    0.05 |  1.9531 |      - |   86.7 KB |        2.21 |
