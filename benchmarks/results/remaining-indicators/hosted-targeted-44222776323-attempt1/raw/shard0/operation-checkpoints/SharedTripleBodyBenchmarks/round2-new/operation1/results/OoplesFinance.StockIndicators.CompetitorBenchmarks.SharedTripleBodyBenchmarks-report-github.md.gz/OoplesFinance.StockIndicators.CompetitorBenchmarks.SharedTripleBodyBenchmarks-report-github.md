```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)Crows [22]** | **1000**  |  **25.94 μs** |  **0.108 μs** |  **0.065 μs** |  **1.00** |    **0.00** |       **-** |      **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)Crows [22] | 1000  |  93.92 μs |  8.168 μs |  5.402 μs |  3.62 |    0.20 |       - |      - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib(...)Crows [22] | 1000  |  99.35 μs |  3.385 μs |  1.770 μs |  3.83 |    0.06 |  1.9531 |      - |   62.5 KB |       15.75 |
| BuilderLatestOnly | TaLib(...)Crows [22] | 1000  |  96.74 μs |  8.992 μs |  5.351 μs |  3.73 |    0.20 |       - |      - |  14.61 KB |        3.68 |
|                   |                      |       |           |           |           |       |         |         |        |           |             |
| **NativeSingle**      | **TaLib(...)Crows [22]** | **10000** | **230.92 μs** |  **2.527 μs** |  **1.322 μs** |  **1.00** |    **0.01** |       **-** |      **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib(...)Crows [22] | 10000 | 215.67 μs |  7.647 μs |  3.999 μs |  0.93 |    0.02 |  3.9063 |      - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib(...)Crows [22] | 10000 | 261.64 μs | 40.466 μs | 26.766 μs |  1.13 |    0.11 | 21.4844 | 7.8125 |  556.8 KB |       14.23 |
| BuilderLatestOnly | TaLib(...)Crows [22] | 10000 | 206.48 μs |  5.872 μs |  3.071 μs |  0.89 |    0.01 |  1.9531 |      - |   86.7 KB |        2.22 |
