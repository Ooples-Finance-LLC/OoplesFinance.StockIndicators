```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error     | StdDev    | Median   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |---------:|----------:|----------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)Crows [22]** | **1000**  | **209.4 μs** | **156.92 μs** | **103.79 μs** | **163.3 μs** |       **-** |      **-** |  **64.25 KB** |
| BuilderLatestOnly | TaLib(...)Crows [22] | 1000  | 120.0 μs |   9.80 μs |   6.48 μs | 117.4 μs |       - |      - |  16.38 KB |
| **BuilderFull**       | **TaLib(...)Crows [22]** | **10000** | **664.4 μs** | **198.71 μs** | **131.44 μs** | **718.0 μs** | **19.5313** | **3.9063** | **556.81 KB** |
| BuilderLatestOnly | TaLib(...)Crows [22] | 10000 | 560.5 μs | 108.99 μs |  72.09 μs | 575.5 μs |       - |      - |  86.71 KB |
