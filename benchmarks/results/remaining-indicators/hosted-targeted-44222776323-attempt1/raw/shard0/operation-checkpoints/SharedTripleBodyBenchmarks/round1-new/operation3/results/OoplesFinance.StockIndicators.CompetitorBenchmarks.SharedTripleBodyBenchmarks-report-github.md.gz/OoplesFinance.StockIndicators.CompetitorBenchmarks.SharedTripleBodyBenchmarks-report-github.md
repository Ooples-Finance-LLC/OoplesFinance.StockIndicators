```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)River [30]** | **1000**  |  **73.06 μs** |  **4.616 μs** | **2.747 μs** |  **1.9531** |      **-** |  **62.49 KB** |
| BuilderLatestOnly | TaLib(...)River [30] | 1000  |  94.67 μs |  6.746 μs | 4.462 μs |  0.4883 |      - |  14.61 KB |
| **BuilderFull**       | **TaLib(...)River [30]** | **10000** | **281.97 μs** |  **9.175 μs** | **4.799 μs** | **21.4844** | **7.8125** |  **556.8 KB** |
| BuilderLatestOnly | TaLib(...)River [30] | 10000 | 248.67 μs | 10.315 μs | 5.395 μs |  1.9531 |      - |   86.7 KB |
