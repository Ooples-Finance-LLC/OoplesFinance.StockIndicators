```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)Crows [31]** | **1000**  | **152.6 μs** | **37.57 μs** | **24.85 μs** |       **-** |      **-** |  **64.25 KB** |
| BuilderLatestOnly | TaLib(...)Crows [31] | 1000  | 127.1 μs |  6.01 μs |  3.98 μs |       - |      - |  16.38 KB |
| **BuilderFull**       | **TaLib(...)Crows [31]** | **10000** | **545.0 μs** | **53.92 μs** | **32.09 μs** | **19.5313** | **3.9063** | **556.81 KB** |
| BuilderLatestOnly | TaLib(...)Crows [31] | 10000 | 555.4 μs | 75.27 μs | 49.79 μs |       - |      - |  86.71 KB |
