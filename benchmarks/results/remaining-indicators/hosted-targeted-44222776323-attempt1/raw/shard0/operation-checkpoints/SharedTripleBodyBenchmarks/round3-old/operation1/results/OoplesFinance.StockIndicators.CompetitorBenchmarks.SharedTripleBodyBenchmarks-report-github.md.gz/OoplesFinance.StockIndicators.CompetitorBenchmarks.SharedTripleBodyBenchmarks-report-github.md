```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev  | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|--------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)Crows [22]** | **1000**  | **134.5 μs** |  **6.57 μs** | **3.44 μs** |       **-** |      **-** |  **64.29 KB** |
| BuilderLatestOnly | TaLib(...)Crows [22] | 1000  | 117.7 μs |  4.05 μs | 2.41 μs |       - |      - |  16.38 KB |
| **BuilderFull**       | **TaLib(...)Crows [22]** | **10000** | **482.7 μs** | **17.85 μs** | **9.34 μs** | **19.5313** | **3.9063** | **556.81 KB** |
| BuilderLatestOnly | TaLib(...)Crows [22] | 10000 | 442.2 μs |  9.26 μs | 4.84 μs |       - |      - |  86.71 KB |
