```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)Crows [31]** | **1000**  | **108.88 μs** | **17.785 μs** | **11.764 μs** |  **1.9531** |      **-** |  **62.49 KB** |
| BuilderLatestOnly | TaLib(...)Crows [31] | 1000  |  92.33 μs |  4.347 μs |  2.587 μs |       - |      - |  14.61 KB |
| **BuilderFull**       | **TaLib(...)Crows [31]** | **10000** | **281.69 μs** | **46.396 μs** | **30.688 μs** | **19.5313** | **3.9063** | **556.81 KB** |
| BuilderLatestOnly | TaLib(...)Crows [31] | 10000 | 236.57 μs | 27.003 μs | 17.861 μs |  1.9531 |      - |   86.7 KB |
