```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)Crows [31]** | **1000**  |  **55.52 μs** |  **0.443 μs** |  **0.263 μs** |  **1.00** |    **0.01** |       **-** |      **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)Crows [31] | 1000  | 100.33 μs |  1.316 μs |  0.688 μs |  1.81 |    0.01 |       - |      - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib(...)Crows [31] | 1000  |  98.36 μs |  3.519 μs |  1.840 μs |  1.77 |    0.03 |  1.9531 |      - |  62.46 KB |       15.74 |
| BuilderLatestOnly | TaLib(...)Crows [31] | 1000  |  68.92 μs |  2.996 μs |  1.567 μs |  1.24 |    0.03 |  0.4883 |      - |  14.61 KB |        3.68 |
|                   |                      |       |           |           |           |       |         |         |        |           |             |
| **NativeSingle**      | **TaLib(...)Crows [31]** | **10000** | **422.23 μs** |  **7.821 μs** |  **5.173 μs** |  **1.00** |    **0.02** |       **-** |      **-** |  **39.16 KB** |        **1.00** |
| NativeParallel    | TaLib(...)Crows [31] | 10000 | 293.02 μs | 32.163 μs | 21.274 μs |  0.69 |    0.05 |  3.9063 |      - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib(...)Crows [31] | 10000 | 237.13 μs | 15.019 μs |  8.938 μs |  0.56 |    0.02 | 21.4844 | 7.8125 | 556.76 KB |       14.22 |
| BuilderLatestOnly | TaLib(...)Crows [31] | 10000 | 197.18 μs |  4.198 μs |  2.195 μs |  0.47 |    0.01 |  1.9531 |      - |   86.7 KB |        2.21 |
