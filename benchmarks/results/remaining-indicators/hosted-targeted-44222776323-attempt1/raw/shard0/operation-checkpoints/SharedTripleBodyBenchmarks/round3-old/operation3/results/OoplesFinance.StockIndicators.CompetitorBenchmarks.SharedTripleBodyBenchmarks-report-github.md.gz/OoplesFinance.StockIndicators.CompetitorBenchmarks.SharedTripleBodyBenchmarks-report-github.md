```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)River [30]** | **1000**  | **130.3 μs** |  **4.57 μs** |  **2.39 μs** |       **-** |      **-** |  **64.25 KB** |
| BuilderLatestOnly | TaLib(...)River [30] | 1000  | 126.2 μs | 10.72 μs |  7.09 μs |       - |      - |  16.38 KB |
| **BuilderFull**       | **TaLib(...)River [30]** | **10000** | **547.1 μs** | **69.10 μs** | **45.71 μs** | **19.5313** | **7.8125** | **556.81 KB** |
| BuilderLatestOnly | TaLib(...)River [30] | 10000 | 551.8 μs | 59.87 μs | 39.60 μs |       - |      - |  86.71 KB |
