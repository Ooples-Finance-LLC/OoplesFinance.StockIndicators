```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)nside [25]** | **1000**  |  **45.03 μs** |  **0.317 μs** |  **0.188 μs** |  **1.00** |    **0.01** |       **-** |      **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)nside [25] | 1000  |  80.07 μs |  9.423 μs |  6.233 μs |  1.78 |    0.13 |       - |      - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib(...)nside [25] | 1000  | 101.45 μs |  1.998 μs |  1.045 μs |  2.25 |    0.02 |  1.9531 |      - |  64.26 KB |       16.19 |
| BuilderLatestOnly | TaLib(...)nside [25] | 1000  | 102.08 μs | 13.690 μs |  9.055 μs |  2.27 |    0.19 |       - |      - |  16.38 KB |        4.13 |
|                   |                      |       |           |           |           |       |         |         |        |           |             |
| **NativeSingle**      | **TaLib(...)nside [25]** | **10000** | **444.86 μs** |  **3.065 μs** |  **1.603 μs** |  **1.00** |    **0.00** |       **-** |      **-** |  **39.15 KB** |        **1.00** |
| NativeParallel    | TaLib(...)nside [25] | 10000 | 309.08 μs | 38.765 μs | 25.641 μs |  0.69 |    0.06 |  3.9063 |      - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib(...)nside [25] | 10000 | 577.91 μs | 58.466 μs | 38.671 μs |  1.30 |    0.08 | 19.5313 | 3.9063 | 556.81 KB |       14.22 |
| BuilderLatestOnly | TaLib(...)nside [25] | 10000 | 513.63 μs | 44.595 μs | 26.538 μs |  1.15 |    0.06 |       - |      - |  86.71 KB |        2.21 |
