"""Archive the root-authenticated run with frozen tooling; commit only new evidence."""
import gzip,hashlib,json,os,subprocess,sys
from pathlib import Path

RUN='44222776323'
TOOLING_HEAD='304d97f61654ad4159b36b4ca6082667ea74df78'
BASE='08ff12fb7333e3f76808672b05a2c62e85e5ae80'
CANONICAL='9e914007c3438d9f251f3fab9ef321d49c22de83'
OLD='6469c65c50dc2c9211c92a8303734e06ae817c60'
TOOLING=Path(r'C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-triple-body-master-reconciliation-20261117')
PUBLISHER=TOOLING.parent/'si-triple-body-0151-publisher-20261118'
OPS=Path(__file__).resolve().parent
Z=Path(r'Z:\StockIndicators-Archives\active-performance-evidence\triple-body-master-reconciliation-44222776323')
PREP=OPS/('hosted-inputs-'+RUN)
RAW=Z/'raw'/'evidence'
PLAN=TOOLING/'benchmarks/plans/hosted-triple-body-master-reconciliation-20261117.json'

def git(*args,cwd=PUBLISHER):return subprocess.check_output(['git',*args],cwd=cwd,text=True).strip()
def frozen():
    assert git('rev-parse','HEAD',cwd=TOOLING)==TOOLING_HEAD
    assert not git('status','--porcelain',cwd=TOOLING)
def sha(raw):return hashlib.sha256(raw).hexdigest()
frozen()
assert git('rev-parse','HEAD')==BASE and not git('status','--porcelain')
os.environ['HOSTED_TIMING_PLAN']=str(PLAN)
sys.path.insert(0,str(TOOLING/'scripts'))
from hosted_timing import pipeline as p
from hosted_timing import archive as archiver
from hosted_timing import master_reconciliation as q

root=p.read(Z/'root-review.json')
assert root['root_auth']=='PASS' and str(root['run'])==RUN and root['head']==TOOLING_HEAD
assert root['source_gate'] is True and root['native_gate'] is True and root['new_ledger_rows']==0
assert (root['cases'],root['decisions'])==(120,24) and root['verdicts']==dict(inconclusive=9,faster=15)
identity=q.original.previous.SOURCE_IDENTITY_PATHS
assert not git('diff','--name-only',CANONICAL,BASE,'--',*identity)
changed=set(git('diff','--name-only',OLD,CANONICAL,'--','src','tests').splitlines())
assert changed==q.PATHS
expected_patch=subprocess.check_output(['git','diff','--binary',OLD,CANONICAL,'--','src','tests'],cwd=PUBLISHER)

destination=archiver.archive(RAW,PREP,PUBLISHER,'targeted')
frozen()
prefix=destination.relative_to(PUBLISHER).as_posix()
decision=p.read(destination/'decision.json')
summary=p.read(destination/'verified-summary.json')
assert summary==p.read(Z/'independent-summary.json')
assert summary['accepted'] is True and summary['source_gate_accepted'] is True and summary['native_progress_gate_passed'] is True
assert summary['input_provenance_sha256']==root['prepared_sha256']
assert sha((destination/'verified-summary.json').read_bytes())=='730ad3da48bea7608705c901375ac4f746ef71dd6a9e08bed24b0afe244adaf0'
assert decision['production_integrated'] is False and decision['report_imported'] is False
assert decision['master_reconciliation'] is True and decision['closure_ledger_new_rows']==0

def add(relative,raw):
    assert relative not in decision['archives']
    target=destination/(relative+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(gzip.compress(raw,mtime=0))
    assert gzip.decompress(target.read_bytes())==raw
    decision['archives'][relative]=dict(sha256=sha(raw),archive=target.relative_to(PUBLISHER).as_posix())

add('prepared/fixture-method-inventory.json',(PREP/'fixture-method-inventory.json').read_bytes())
for name in ('root-review.json','run-api.json','artifact-api.json','collection-summary.json','materialization-manifest.json','native-acceptance-detail.json'):
    add('review/'+name,(Z/name).read_bytes())
add('review/independent-summary.json',(Z/'independent-summary.json').read_bytes())
add('review/collector.py',(OPS/('collect-master-reconciliation-'+RUN+'.py')).read_bytes())
add('review/archive-orchestration.py',Path(__file__).read_bytes())
source_proof=dict(canonical=CANONICAL,baseline=OLD,publisher_base=BASE,qualified_tooling=TOOLING_HEAD,
    source_identity_paths=identity,source_identity_delta_against_canonical=[],
    canonical_source_fingerprint='79ccf727c22cb156a0cb75cdd0f764da037603d7b74c8cd9cb075da2c6498815',
    candidate_source_patch_paths=sorted(changed),candidate_source_patch_sha256=sha(expected_patch),
    new_archive_only=True,historical_archive_flags_or_labels_changed=False,compiled_runtime_in_git=False,
    accepted_current_tensor_version='0.151.1',existing_two_crows_new_ledger_rows=0)
add('review/source-identity-proof.json',(json.dumps(source_proof,indent=2)+'\n').encode())
archiver.write(destination/'decision.json',decision)

archive_bytes=0;decompressed_bytes=0
for logical,item in decision['archives'].items():
    path=(PUBLISHER/item['archive']).resolve()
    assert path.is_relative_to(destination.resolve()) and path.name.endswith('.gz')
    assert not any(part in ('blobs','common','production') for part in Path(logical).parts)
    assert Path(logical).suffix.lower() not in ('.dll','.exe','.pdb','.so','.dylib')
    raw=gzip.decompress(path.read_bytes());assert sha(raw)==item['sha256']
    archive_bytes+=path.stat().st_size;decompressed_bytes+=len(raw)
    if logical=='candidate-source.patch':assert raw==expected_patch
    if logical=='prepared/fixture-method-inventory.json':assert sha(raw)==root.get('fixture_inventory_sha256','63597a61ee3ebaba3cc798c6221f2676cba86d9acad44c87dca193b3dc326802')
expected_files={destination/'decision.json',destination/'verified-summary.json',destination/'.gitattributes'}|{PUBLISHER/item['archive'] for item in decision['archives'].values()}
assert {path for path in destination.rglob('*') if path.is_file()}==expected_files
assert not git('diff','--name-only',CANONICAL,'HEAD','--',*identity)
subprocess.run(['git','diff','--check'],cwd=PUBLISHER,check=True)
assert not git('diff','--cached','--name-only')
subprocess.run(['git','add','--',prefix],cwd=PUBLISHER,check=True)
staged=git('diff','--cached','--name-only').splitlines()
assert len(staged)==len(expected_files) and all(name.startswith(prefix+'/') for name in staged)
subprocess.run(['git','diff','--cached','--check'],cwd=PUBLISHER,check=True)
subprocess.run(['git','commit','-m','perf: archive TripleBody current-master qualification'],cwd=PUBLISHER,check=True)
head=git('rev-parse','HEAD')
assert git('rev-parse',head+'^')==BASE and not git('status','--porcelain')
assert set(git('diff','--name-only',BASE,head).splitlines())==set(staged)
assert not git('diff','--name-only',CANONICAL,head,'--',*identity)
fingerprint=q.common.source_fingerprint(head)
assert fingerprint==source_proof['canonical_source_fingerprint']
frozen()
receipt=dict(status='new-archive-only-local-commit-verified',run_id=RUN,head=head,parent=BASE,
    worktree=str(PUBLISHER),decision=prefix+'/decision.json',decision_sha256=p.digest(destination/'decision.json'),
    verified_summary_sha256=p.digest(destination/'verified-summary.json'),archive_blob_count=len(decision['archives']),
    committed_files=len(staged),gzip_bytes=archive_bytes,decompressed_bytes=decompressed_bytes,
    source_fingerprint=fingerprint,source_identity_delta_against_canonical=[],
    source_patch_paths=sorted(changed),source_patch_sha256=sha(expected_patch),
    all_archive_hashes_verified=True,root_summary_equal_archiver_recollection=True,
    accepted=True,source_gate=True,native_gate=True,new_ledger_rows=0,
    historical_archive_flags_or_labels_changed=False,pushed=False,production_integrated=False,report_imported=False)
p.write(Z/'local-publication-archive-receipt.json',receipt)
print(json.dumps(receipt))
