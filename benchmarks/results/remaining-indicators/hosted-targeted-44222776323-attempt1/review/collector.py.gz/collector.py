"""Collect exactly one frozen hosted run; preserve bulk on Z, reuse runtime on C."""
import hashlib,json,os,shutil,stat,subprocess,sys,traceback,zipfile
from pathlib import Path,PurePosixPath

RUN='44222776323'
HEAD='304d97f61654ad4159b36b4ca6082667ea74df78'
NAME='triple-body-master-reconciliation'
REPOSITORY='Ooples-Finance-LLC/OoplesFinance.StockIndicators'
REPO=Path(r'C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-triple-body-master-reconciliation-20261117')
OPS=Path(__file__).resolve().parent
Z=Path(r'Z:\StockIndicators-Archives\active-performance-evidence')/('triple-body-master-reconciliation-'+RUN)
PREP=OPS/('hosted-inputs-'+RUN)
LOCAL=OPS/'prepared-local-parent-review-20261118'
RAW=Z/'raw'/'evidence'
PLAN=REPO/'benchmarks/plans/hosted-triple-body-master-reconciliation-20261117.json'
def verifier_bound():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==HEAD
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=REPO),'Verifier worktree must remain clean/frozen'
verifier_bound()
os.environ['HOSTED_TIMING_PLAN']=str(PLAN)
sys.path.insert(0,str(REPO/'scripts'))
from hosted_timing import master_reconciliation as q

def api(path):
    return json.loads(subprocess.check_output(['gh','api','repos/'+REPOSITORY+'/'+path],cwd=REPO))
def digest_bytes(data):return hashlib.sha256(data).hexdigest()
def digest_file(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

state=api('actions/runs/'+RUN)
assert str(state['id'])==RUN and state['head_sha']==HEAD and state['run_attempt']==1
assert state['head_branch']=='perf/triple-body-master-reconciliation-20261117'
assert state['path']=='.github/workflows/triple-body-master-reconciliation.yml'
assert state['status']=='completed','Active run: no artifact collection is permitted yet'
assert not Z.exists() and not PREP.exists(),'Fresh single-run outputs only; inspect prior output instead of retrying'
items=api('actions/runs/'+RUN+'/artifacts')['artifacts']
items=[item for item in items if item['name']==NAME and not item['expired']]
assert len(items)==1
artifact=items[0]
assert str(artifact['workflow_run']['id'])==RUN and artifact['workflow_run']['head_sha']==HEAD
assert artifact['digest'].startswith('sha256:')
expected_zip=artifact['digest'][7:]
Z.mkdir(parents=True)
q.p.write(Z/'run-api.json',state);q.p.write(Z/'artifact-api.json',artifact)
partial=Z/'artifact.zip.partial'
with partial.open('xb') as output:
    subprocess.run(['gh','api','repos/'+REPOSITORY+'/actions/artifacts/'+str(artifact['id'])+'/zip'],cwd=REPO,stdout=output,check=True)
assert digest_file(partial)==expected_zip
package_path=Z/'artifact.zip';partial.replace(package_path)

try:
    with zipfile.ZipFile(package_path) as package:
        files={entry.filename:entry for entry in package.infolist() if not entry.is_dir()}
        assert len(files)==len([entry for entry in package.infolist() if not entry.is_dir()])
        assert len(files)==len({name.casefold() for name in files})
        prepared={name[len('reconciled-inputs/'):]:entry for name,entry in files.items() if name.startswith('reconciled-inputs/')}
        raw={name[len('reconciled-qualification/evidence/'):]:entry for name,entry in files.items() if name.startswith('reconciled-qualification/evidence/shard0/')}
        assert prepared and raw
        hosted_proof=json.loads(package.read('reconciled-inputs/provenance.json'))
        assert str(hosted_proof['run_id'])==RUN and str(hosted_proof['run_attempt'])=='1'
        assert hosted_proof['workflow_head']==HEAD and hosted_proof['plan_sha256']==q.p.digest(PLAN)
        assert hosted_proof['sources']==q.p.read(PLAN)['sources']
        cache={}
        for folder in (LOCAL/'common',LOCAL/'production',LOCAL/'old-authentication'/'blobs',LOCAL/'successor-authentication'/'blobs'):
            for path in folder.rglob('*'):
                if path.is_file():cache.setdefault(digest_file(path),path)
        selected=list(prepared.items())+list(raw.items())
        for relative,entry in selected:
            path=PurePosixPath(relative)
            assert not path.is_absolute() and '..' not in path.parts and ':' not in relative and '\\' not in relative
            assert all(part not in ('.','..') and not part.endswith(('.',' ')) for part in path.parts)
            assert not stat.S_ISLNK(entry.external_attr>>16)
        metadata_bytes=0
        for relative,entry in prepared.items():
            payload=(relative.startswith('common/') or relative.startswith('production/') or '/blobs/' in relative)
            if not payload:metadata_bytes+=entry.file_size
        assert shutil.disk_usage(OPS).free>=metadata_bytes+128*1024*1024
        PREP.mkdir();RAW.mkdir(parents=True)
        links=0;prepared_manifest={};raw_manifest={}
        for relative,entry in prepared.items():
            target=PREP.joinpath(*PurePosixPath(relative).parts)
            assert target.resolve().is_relative_to(PREP.resolve())
            target.parent.mkdir(parents=True,exist_ok=True)
            data=package.read(entry);sha=digest_bytes(data)
            payload=(relative.startswith('common/') or relative.startswith('production/') or '/blobs/' in relative)
            if payload:
                assert sha in cache,'No new runtime payload may be installed: '+relative
                os.link(cache[sha],target);links+=1
            else:
                target.write_bytes(data)
            assert digest_file(target)==sha
            prepared_manifest[relative]=sha
        for relative,entry in raw.items():
            target=RAW.joinpath(*PurePosixPath(relative).parts)
            assert target.resolve().is_relative_to(RAW.resolve())
            assert target.suffix.lower() not in ('.dll','.exe','.pdb'),'No runtime extraction to Z'
            target.parent.mkdir(parents=True,exist_ok=True)
            data=package.read(entry);target.write_bytes(data)
            raw_manifest[relative]=digest_bytes(data)
        q.p.write(Z/'materialization-manifest.json',dict(prepared=prepared_manifest,raw=raw_manifest))
        verifier_bound()
        result=q.collect(RAW,inputs=PREP)
        verifier_bound()
        hosted=json.loads(package.read('reconciled-qualification/summary.json'))
        assert json.loads(json.dumps(result,allow_nan=False))==hosted
        assert result['case_count']==120 and result['decision_count']==24
        assert result['closure_ledger_new_rows']==0
        q.p.write(Z/'independent-summary.json',result)
        receipt=dict(status='complete-single-run-independently-authenticated',run_id=RUN,run_attempt=1,head=HEAD,
            workflow_conclusion=state['conclusion'],artifact_id=artifact['id'],artifact_zip_sha256=expected_zip,
            prepared=str(PREP),raw=str(RAW),runtime_hardlinks=links,new_runtime_payload_bytes=0,
            prepared_provenance_sha256=q.p.digest(PREP/'provenance.json'),
            fixture_inventory_sha256=q.p.digest(PREP/'fixture-method-inventory.json'),
            independent_summary_sha256=q.p.digest(Z/'independent-summary.json'),
            accepted=result['accepted'],source_gate_accepted=result['source_gate_accepted'],
            native_progress_gate_passed=result['native_progress_gate_passed'],
            cases=result['case_count'],decisions=result['decision_count'],verdicts=result['verdicts'],
            ledger_new_rows=0,hosted_summary_equal_independent=True,new_measurements=0,
            production_integrated=False,report_imported=False)
        q.p.write(Z/'collection-summary.json',receipt)
        print(json.dumps(receipt))
except BaseException as error:
    q.p.write(Z/'collection-failure.json',dict(run_id=RUN,head=HEAD,error=str(error),traceback=traceback.format_exc(),
        source_zip_preserved=True,automatic_retry_allowed=False,qualification_claimed=False))
    raise
