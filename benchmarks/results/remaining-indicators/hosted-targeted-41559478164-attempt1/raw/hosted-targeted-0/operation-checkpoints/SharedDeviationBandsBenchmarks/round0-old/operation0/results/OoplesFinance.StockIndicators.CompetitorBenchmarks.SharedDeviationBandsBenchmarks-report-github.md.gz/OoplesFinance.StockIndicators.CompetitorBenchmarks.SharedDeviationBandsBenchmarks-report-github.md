```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Skend(...)Bands [25]** | **1000**  | **135.12 μs** |  **8.264 μs** |  **4.322 μs** |  **7.8125** |       **-** |  **132.97 KB** |
| BuilderLatestOnly | Skend(...)Bands [25] | 1000  |  87.69 μs |  5.991 μs |  3.963 μs |  4.8828 |  0.9766 |   85.36 KB |
| **BuilderFull**       | **Skend(...)Bands [25]** | **10000** | **746.02 μs** | **29.903 μs** | **15.640 μs** | **70.3125** | **62.5000** | **1258.36 KB** |
| BuilderLatestOnly | Skend(...)Bands [25] | 10000 | 774.92 μs | 85.789 μs | 56.744 μs | 46.8750 | 19.5313 |  788.52 KB |
