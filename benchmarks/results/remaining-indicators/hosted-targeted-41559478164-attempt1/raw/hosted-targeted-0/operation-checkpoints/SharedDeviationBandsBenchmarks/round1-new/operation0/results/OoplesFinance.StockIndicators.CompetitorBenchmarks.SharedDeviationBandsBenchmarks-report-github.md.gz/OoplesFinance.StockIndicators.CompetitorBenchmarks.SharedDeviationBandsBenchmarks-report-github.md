```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error      | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |----------:|-----------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Skend(...)Bands [25]** | **1000**  | **130.06 μs** |  **40.564 μs** | **26.831 μs** |  **7.8125** |       **-** |  **133.23 KB** |
| BuilderLatestOnly | Skend(...)Bands [25] | 1000  |  95.07 μs |   6.307 μs |  3.299 μs |  4.8828 |  0.9766 |   85.58 KB |
| **BuilderFull**       | **Skend(...)Bands [25]** | **10000** | **821.02 μs** | **108.984 μs** | **57.001 μs** | **70.3125** | **62.5000** | **1258.61 KB** |
| BuilderLatestOnly | Skend(...)Bands [25] | 10000 | 757.16 μs |   5.392 μs |  2.820 μs | 46.8750 | 23.4375 |  788.73 KB |
