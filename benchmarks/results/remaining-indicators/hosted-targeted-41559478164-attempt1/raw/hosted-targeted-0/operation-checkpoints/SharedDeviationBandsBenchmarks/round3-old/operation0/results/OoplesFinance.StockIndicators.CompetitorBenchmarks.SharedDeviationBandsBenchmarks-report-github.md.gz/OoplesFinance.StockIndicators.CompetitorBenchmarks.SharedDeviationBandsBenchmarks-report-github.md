```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error      | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |----------:|-----------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Skend(...)Bands [25]** | **1000**  | **108.41 μs** |  **30.372 μs** | **20.089 μs** |  **7.8125** |       **-** |  **132.97 KB** |
| BuilderLatestOnly | Skend(...)Bands [25] | 1000  |  75.79 μs |   2.433 μs |  1.273 μs |  4.8828 |  0.9766 |   85.36 KB |
| **BuilderFull**       | **Skend(...)Bands [25]** | **10000** | **665.78 μs** |  **54.397 μs** | **35.980 μs** | **74.2188** | **70.3125** | **1258.34 KB** |
| BuilderLatestOnly | Skend(...)Bands [25] | 10000 | 692.47 μs | 111.706 μs | 73.886 μs | 46.8750 | 23.4375 |  788.51 KB |
