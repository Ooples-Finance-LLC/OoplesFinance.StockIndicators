```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)Bands [25]** | **1000**  |   **137.31 μs** |  **30.076 μs** | **19.893 μs** |  **2.25** |    **0.32** |   **7.8125** |        **-** |       **-** |  **133.19 KB** |        **0.39** |
| BuilderLatestOnly | Skend(...)Bands [25] | 1000  |    97.90 μs |  10.540 μs |  6.972 μs |  1.60 |    0.12 |   4.8828 |   0.9766 |       - |   85.58 KB |        0.25 |
| NativeSingle      | Skend(...)Bands [25] | 1000  |    61.13 μs |   3.694 μs |  2.444 μs |  1.00 |    0.05 |  20.9961 |   5.3711 |       - |  344.63 KB |        1.00 |
| NativeParallel    | Skend(...)Bands [25] | 1000  |    51.87 μs |   0.838 μs |  0.555 μs |  0.85 |    0.03 |  22.4609 |   5.8594 |       - |  363.39 KB |        1.05 |
|                   |                      |       |             |            |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)Bands [25]** | **10000** |   **789.05 μs** |  **22.953 μs** | **12.005 μs** |  **0.57** |    **0.04** |  **70.3125** |  **62.5000** |       **-** | **1258.59 KB** |        **0.36** |
| BuilderLatestOnly | Skend(...)Bands [25] | 10000 |   818.48 μs | 116.145 μs | 69.116 μs |  0.60 |    0.06 |  46.8750 |  23.4375 |       - |  788.76 KB |        0.23 |
| NativeSingle      | Skend(...)Bands [25] | 10000 | 1,379.45 μs | 139.523 μs | 92.286 μs |  1.00 |    0.09 | 273.4375 | 203.1250 | 85.9375 | 3474.36 KB |        1.00 |
| NativeParallel    | Skend(...)Bands [25] | 10000 |   434.50 μs |  18.264 μs | 12.081 μs |  0.32 |    0.02 | 222.6563 | 125.0000 |       - | 3562.64 KB |        1.03 |
