```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)bands [22]** | **1000**  |  **60.70 μs** |  **6.390 μs** |  **4.227 μs** |  **4.8828** |  **0.9766** |  **84.29 KB** |
| BuilderLatestOnly | TaLib(...)bands [22] | 1000  |  58.53 μs |  5.552 μs |  3.673 μs |  1.9531 |       - |  36.68 KB |
| **BuilderFull**       | **TaLib(...)bands [22]** | **10000** | **404.05 μs** | **15.255 μs** |  **7.979 μs** | **46.8750** | **19.5313** | **787.78 KB** |
| BuilderLatestOnly | TaLib(...)bands [22] | 10000 | 391.35 μs | 33.307 μs | 17.420 μs | 15.6250 |  3.9063 | 317.95 KB |
