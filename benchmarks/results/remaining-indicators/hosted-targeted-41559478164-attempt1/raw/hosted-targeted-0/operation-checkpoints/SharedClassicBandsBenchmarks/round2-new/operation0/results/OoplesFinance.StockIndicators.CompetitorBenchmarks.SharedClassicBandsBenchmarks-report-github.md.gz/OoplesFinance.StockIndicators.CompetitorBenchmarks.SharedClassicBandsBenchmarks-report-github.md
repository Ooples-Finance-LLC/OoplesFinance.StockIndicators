```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)bands [22]** | **1000**  |  **67.062 μs** | **14.9454 μs** |  **9.8855 μs** | **15.14** |    **2.14** |  **3.9063** |       **-** |  **84.29 KB** |        **3.63** |
| BuilderLatestOnly | TaLib(...)bands [22] | 1000  |  55.770 μs |  5.5928 μs |  3.6993 μs | 12.59 |    0.82 |  1.9531 |       - |  36.68 KB |        1.58 |
| NativeSingle      | TaLib(...)bands [22] | 1000  |   4.431 μs |  0.1095 μs |  0.0724 μs |  1.00 |    0.02 |  1.4038 |  0.0916 |   23.2 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [22] | 1000  |   3.814 μs |  0.4256 μs |  0.2815 μs |  0.86 |    0.06 |  1.4343 |  0.0916 |  23.66 KB |        1.02 |
|                   |                      |       |            |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)bands [22]** | **10000** | **389.375 μs** | **12.8899 μs** |  **6.7417 μs** |  **9.17** |    **0.19** | **46.8750** | **19.5313** |  **787.8 KB** |        **3.36** |
| BuilderLatestOnly | TaLib(...)bands [22] | 10000 | 405.746 μs | 51.6536 μs | 34.1657 μs |  9.56 |    0.78 | 17.5781 |  7.8125 | 317.94 KB |        1.36 |
| NativeSingle      | TaLib(...)bands [22] | 10000 |  42.457 μs |  0.8323 μs |  0.5505 μs |  1.00 |    0.02 | 14.1602 |  4.6387 | 234.14 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [22] | 10000 |  28.906 μs |  3.3777 μs |  2.2341 μs |  0.68 |    0.05 | 14.1602 |  4.6387 |  234.6 KB |        1.00 |
