```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)bands [22]** | **1000**  |  **58.10 μs** | **10.936 μs** |  **7.234 μs** |  **3.9063** |       **-** |  **84.04 KB** |
| BuilderLatestOnly | TaLib(...)bands [22] | 1000  |  45.07 μs |  4.047 μs |  2.677 μs |  1.9531 |       - |  36.46 KB |
| **BuilderFull**       | **TaLib(...)bands [22]** | **10000** | **321.74 μs** | **40.154 μs** | **26.559 μs** | **46.8750** | **19.5313** | **787.54 KB** |
| BuilderLatestOnly | TaLib(...)bands [22] | 10000 | 315.86 μs | 32.155 μs | 21.269 μs | 17.5781 |  7.8125 | 317.73 KB |
