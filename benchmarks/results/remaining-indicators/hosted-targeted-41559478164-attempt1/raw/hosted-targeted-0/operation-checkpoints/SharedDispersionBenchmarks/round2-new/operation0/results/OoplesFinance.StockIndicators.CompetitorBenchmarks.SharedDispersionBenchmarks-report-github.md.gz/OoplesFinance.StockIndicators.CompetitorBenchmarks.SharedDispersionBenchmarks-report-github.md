```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Variance | Count | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------- |------ |-----------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **True**     | **1000**  |  **42.887 μs** |  **6.6365 μs** |  **4.3896 μs** | **22.13** |    **2.17** |  **1.9531** |       **-** |   **60.3 KB** |        **7.81** |
| BuilderLatestOnly | True     | 1000  |  26.726 μs |  2.3836 μs |  1.5766 μs | 13.79 |    0.78 |  0.7324 |       - |  12.38 KB |        1.60 |
| NativeSingle      | True     | 1000  |   1.938 μs |  0.0225 μs |  0.0149 μs |  1.00 |    0.01 |  0.4578 |       - |   7.72 KB |        1.00 |
| NativeParallel    | True     | 1000  |   2.055 μs |  0.0891 μs |  0.0530 μs |  1.06 |    0.03 |  0.4883 |       - |   7.98 KB |        1.03 |
|                   |          |       |            |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **True**     | **10000** | **235.144 μs** |  **8.4552 μs** |  **4.4222 μs** | **12.71** |    **0.23** | **33.2031** | **13.6719** | **552.81 KB** |        **7.08** |
| BuilderLatestOnly | True     | 10000 | 231.476 μs | 43.8141 μs | 28.9803 μs | 12.51 |    1.50 |  3.9063 |       - |   82.7 KB |        1.06 |
| NativeSingle      | True     | 10000 |  18.498 μs |  0.1253 μs |  0.0655 μs |  1.00 |    0.00 |  4.7607 |  0.8545 |  78.03 KB |        1.00 |
| NativeParallel    | True     | 10000 |  13.276 μs |  2.4975 μs |  1.6519 μs |  0.72 |    0.09 |  4.7607 |  0.8545 |   78.3 KB |        1.00 |
