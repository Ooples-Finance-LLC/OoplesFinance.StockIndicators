```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Variance | Count | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------- |------ |-----------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **False**    | **1000**  |  **43.426 μs** | **12.6843 μs** |  **7.5482 μs** | **12.15** |    **2.01** |       **-** |       **-** |  **60.32 KB** |        **7.82** |
| BuilderLatestOnly | False    | 1000  |  37.096 μs |  3.5528 μs |  2.3500 μs | 10.38 |    0.63 |  0.7324 |       - |  12.38 KB |        1.60 |
| NativeSingle      | False    | 1000  |   3.574 μs |  0.0189 μs |  0.0099 μs |  1.00 |    0.00 |  0.4578 |       - |   7.72 KB |        1.00 |
| NativeParallel    | False    | 1000  |   2.875 μs |  0.2109 μs |  0.1255 μs |  0.80 |    0.03 |  0.4883 |       - |   7.98 KB |        1.03 |
|                   |          |       |            |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **False**    | **10000** | **296.271 μs** | **47.5536 μs** | **28.2984 μs** |  **8.30** |    **0.76** | **33.2031** | **13.6719** | **552.81 KB** |        **7.08** |
| BuilderLatestOnly | False    | 10000 | 297.169 μs | 45.4709 μs | 30.0762 μs |  8.32 |    0.81 |  3.9063 |       - |  82.71 KB |        1.06 |
| NativeSingle      | False    | 10000 |  35.711 μs |  0.7140 μs |  0.4249 μs |  1.00 |    0.02 |  4.6387 |  0.7324 |  78.03 KB |        1.00 |
| NativeParallel    | False    | 10000 |  22.794 μs |  3.3680 μs |  1.7615 μs |  0.64 |    0.05 |  4.6387 |  0.7324 |   78.3 KB |        1.00 |
