```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Variance | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **False**    | **1000**  |  **50.05 μs** |  **9.668 μs** |  **6.395 μs** |       **-** |       **-** |  **60.32 KB** |
| BuilderLatestOnly | False    | 1000  |  37.33 μs |  3.163 μs |  2.092 μs |  0.7324 |       - |  12.38 KB |
| **BuilderFull**       | **False**    | **10000** | **320.84 μs** | **83.371 μs** | **55.145 μs** | **31.2500** | **11.7188** | **552.83 KB** |
| BuilderLatestOnly | False    | 10000 | 305.43 μs | 48.773 μs | 32.260 μs |  3.9063 |       - |   82.7 KB |
