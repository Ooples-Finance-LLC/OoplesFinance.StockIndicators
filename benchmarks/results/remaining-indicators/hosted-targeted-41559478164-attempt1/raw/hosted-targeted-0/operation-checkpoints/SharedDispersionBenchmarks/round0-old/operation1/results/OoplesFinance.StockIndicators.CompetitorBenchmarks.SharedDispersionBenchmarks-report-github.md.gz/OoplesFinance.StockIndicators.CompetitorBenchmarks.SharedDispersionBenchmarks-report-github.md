```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Variance | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **False**    | **1000**  |  **35.24 μs** |  **2.669 μs** |  **1.766 μs** |  **2.9297** |       **-** |  **60.04 KB** |
| BuilderLatestOnly | False    | 1000  |  27.63 μs |  3.253 μs |  1.936 μs |  0.7324 |       - |  12.16 KB |
| **BuilderFull**       | **False**    | **10000** | **227.67 μs** | **39.305 μs** | **25.998 μs** | **33.2031** | **11.7188** |  **552.6 KB** |
| BuilderLatestOnly | False    | 10000 | 236.87 μs | 36.962 μs | 24.448 μs |  3.9063 |       - |  82.48 KB |
