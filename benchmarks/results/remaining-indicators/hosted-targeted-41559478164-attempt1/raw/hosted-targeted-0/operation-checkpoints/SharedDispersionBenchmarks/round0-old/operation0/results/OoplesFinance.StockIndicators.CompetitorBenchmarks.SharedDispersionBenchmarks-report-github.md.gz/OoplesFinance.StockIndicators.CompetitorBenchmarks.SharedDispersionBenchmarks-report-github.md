```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Variance | Count | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------- |------ |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **True**     | **1000**  |  **23.56 μs** |  **4.050 μs** | **2.679 μs** |  **3.4180** |  **0.4883** |  **60.04 KB** |
| BuilderLatestOnly | True     | 1000  |  14.98 μs |  1.213 μs | 0.722 μs |  0.7324 |       - |  12.16 KB |
| **BuilderFull**       | **True**     | **10000** | **167.98 μs** |  **4.372 μs** | **2.892 μs** | **33.2031** | **12.6953** | **552.59 KB** |
| BuilderLatestOnly | True     | 10000 | 166.40 μs | 11.250 μs | 6.695 μs |  4.8828 |  0.9766 |  82.47 KB |
