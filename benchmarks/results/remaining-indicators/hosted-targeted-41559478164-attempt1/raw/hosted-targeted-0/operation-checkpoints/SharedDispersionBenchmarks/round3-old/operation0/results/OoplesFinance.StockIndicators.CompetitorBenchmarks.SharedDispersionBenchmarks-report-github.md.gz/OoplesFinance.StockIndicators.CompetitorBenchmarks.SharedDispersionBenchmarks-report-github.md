```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Variance | Count | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------- |------ |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **True**     | **1000**  |  **23.70 μs** |  **7.784 μs** | **5.149 μs** |  **2.9297** |       **-** |  **60.04 KB** |
| BuilderLatestOnly | True     | 1000  |  16.41 μs |  1.666 μs | 1.102 μs |  0.7324 |       - |  12.16 KB |
| **BuilderFull**       | **True**     | **10000** | **174.87 μs** | **13.621 μs** | **8.105 μs** | **33.2031** | **12.6953** | **552.59 KB** |
| BuilderLatestOnly | True     | 10000 | 163.85 μs |  5.334 μs | 3.174 μs |  4.8828 |  0.9766 |  82.48 KB |
