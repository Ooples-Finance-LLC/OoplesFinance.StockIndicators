```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Variance | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **False**    | **1000**  |  **31.40 μs** |  **7.772 μs** |  **5.141 μs** |  **2.9297** |       **-** |  **60.04 KB** |
| BuilderLatestOnly | False    | 1000  |  27.64 μs |  4.452 μs |  2.649 μs |  0.7324 |       - |  12.16 KB |
| **BuilderFull**       | **False**    | **10000** | **212.88 μs** | **29.048 μs** | **15.193 μs** | **33.2031** | **11.7188** | **552.59 KB** |
| BuilderLatestOnly | False    | 10000 | 238.27 μs | 12.027 μs |  7.157 μs |  3.9063 |       - |  82.48 KB |
