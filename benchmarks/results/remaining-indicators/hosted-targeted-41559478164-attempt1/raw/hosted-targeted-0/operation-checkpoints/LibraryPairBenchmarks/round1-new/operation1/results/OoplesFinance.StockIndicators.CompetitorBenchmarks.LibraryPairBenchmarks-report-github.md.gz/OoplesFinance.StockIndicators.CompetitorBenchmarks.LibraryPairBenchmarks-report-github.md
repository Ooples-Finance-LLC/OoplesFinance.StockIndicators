```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId             | Mean      | Error     | StdDev    | Median    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |------------------- |----------:|----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **QuanTAlib.Variance** |  **42.58 μs** | **26.309 μs** | **15.656 μs** |  **33.80 μs** |  **1.10** |    **0.48** |  **67.12 KB** |        **1.00** |
|        |       |                    |           |           |           |           |       |         |           |             |
| **Ooples** | **10000** | **QuanTAlib.Variance** | **199.22 μs** |  **2.167 μs** |  **1.134 μs** | **199.00 μs** |  **1.00** |    **0.01** | **637.05 KB** |        **1.00** |
