```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |-----------:|---------:|---------:|------:|-----------:|------------:|
| **Ooples** | **1000**  | **Trady(...)Width [34]** |   **162.6 μs** |  **3.11 μs** |  **1.62 μs** |  **1.00** |  **329.45 KB** |        **1.00** |
|        |       |                      |            |          |          |       |            |             |
| **Ooples** | **10000** | **Trady(...)Width [34]** | **1,499.0 μs** | **23.01 μs** | **13.69 μs** |  **1.00** | **3229.91 KB** |        **1.00** |
