```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error      | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)ation [33]** |    **40.31 μs** |   **0.695 μs** |  **0.414 μs** |  **1.00** |    **0.01** |   **67.05 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)ation [33] | 1,024.38 μs |  34.155 μs | 22.591 μs | 25.41 |    0.59 |  970.95 KB |       14.48 |
|            |       |                      |             |            |           |       |         |            |             |
| **Ooples**     | **10000** | **Trady(...)ation [33]** |   **260.76 μs** |   **6.736 μs** |  **4.008 μs** |  **1.00** |    **0.02** |   **637.1 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)ation [33] | 8,786.16 μs | 133.209 μs | 79.271 μs | 33.70 |    0.56 | 9571.07 KB |       15.02 |
