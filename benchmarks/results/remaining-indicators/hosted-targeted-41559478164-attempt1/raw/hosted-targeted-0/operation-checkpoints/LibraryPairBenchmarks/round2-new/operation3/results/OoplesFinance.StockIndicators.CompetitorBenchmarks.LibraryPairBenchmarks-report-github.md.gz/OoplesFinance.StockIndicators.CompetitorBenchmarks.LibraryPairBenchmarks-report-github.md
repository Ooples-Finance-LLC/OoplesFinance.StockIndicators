```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)Bands [25]** |   **196.31 μs** | **65.830 μs** | **43.542 μs** |  **1.04** |    **0.29** |   **374.7 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)Bands [25] |    87.52 μs |  5.322 μs |  3.167 μs |  0.46 |    0.08 |  501.86 KB |        1.34 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)Bands [25]** | **1,705.44 μs** | **39.018 μs** | **20.407 μs** |  **1.00** |    **0.02** | **3670.02 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)Bands [25] |   864.63 μs | 39.303 μs | 23.388 μs |  0.51 |    0.01 | 4946.55 KB |        1.35 |
