```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId            | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------ |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetStdDev** |   **126.79 μs** |  **6.350 μs** |  **3.779 μs** |  **1.00** |    **0.04** |  **270.48 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetStdDev |    83.14 μs |  0.824 μs |  0.431 μs |  0.66 |    0.02 |   420.8 KB |        1.56 |
|            |       |                   |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetStdDev** | **1,138.26 μs** | **24.173 μs** | **15.989 μs** |  **1.00** |    **0.02** | **2633.78 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetStdDev |   911.46 μs | 24.197 μs | 14.399 μs |  0.80 |    0.02 | 4145.06 KB |        1.57 |
