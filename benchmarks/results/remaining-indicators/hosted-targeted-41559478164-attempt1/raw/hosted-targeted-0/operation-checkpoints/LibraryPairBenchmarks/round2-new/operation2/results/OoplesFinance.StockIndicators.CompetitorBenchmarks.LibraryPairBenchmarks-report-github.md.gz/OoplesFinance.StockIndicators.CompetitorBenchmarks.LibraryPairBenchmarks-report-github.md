```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId           | Mean        | Error      | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |----------------- |------------:|-----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Zscore** |    **42.80 μs** |   **3.366 μs** |  **2.003 μs** |  **1.00** |    **0.06** |   **67.12 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Zscore |   294.27 μs |  19.180 μs | 11.413 μs |  6.89 |    0.39 |   422.3 KB |        6.29 |
|            |       |                  |             |            |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Zscore** |   **303.50 μs** |  **14.799 μs** |  **8.807 μs** |  **1.00** |    **0.04** |   **636.4 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Zscore | 3,020.89 μs | 141.457 μs | 84.179 μs |  9.96 |    0.38 | 4207.97 KB |        6.61 |
