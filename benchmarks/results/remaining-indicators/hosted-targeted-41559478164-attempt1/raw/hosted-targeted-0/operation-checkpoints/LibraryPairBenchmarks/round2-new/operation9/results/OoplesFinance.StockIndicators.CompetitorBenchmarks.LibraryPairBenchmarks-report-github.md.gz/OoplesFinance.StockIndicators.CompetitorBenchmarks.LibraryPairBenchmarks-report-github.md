```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)Bands [30]** |    **193.1 μs** |   **9.74 μs** |   **6.45 μs** |  **1.00** |    **0.04** |   **347.49 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)Bands [30] |  1,353.7 μs |   5.53 μs |   3.29 μs |  7.02 |    0.22 |  1965.33 KB |        5.66 |
|            |       |                      |             |           |           |       |         |             |             |
| **Ooples**     | **10000** | **Trady(...)Bands [30]** |  **1,619.8 μs** |  **23.69 μs** |  **12.39 μs** |  **1.00** |    **0.01** |  **3406.48 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)Bands [30] | 12,610.4 μs | 225.24 μs | 134.03 μs |  7.79 |    0.10 | 19144.52 KB |        5.62 |
