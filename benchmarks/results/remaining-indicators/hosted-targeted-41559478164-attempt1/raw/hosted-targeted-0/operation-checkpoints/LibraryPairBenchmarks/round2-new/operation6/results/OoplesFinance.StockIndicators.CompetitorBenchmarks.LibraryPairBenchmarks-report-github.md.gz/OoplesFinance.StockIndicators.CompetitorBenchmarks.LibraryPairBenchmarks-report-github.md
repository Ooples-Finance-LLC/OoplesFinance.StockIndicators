```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tdDev [22]** |  **38.311 μs** | **2.619 μs** | **1.5584 μs** |  **1.00** |    **0.05** |  **67.12 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tdDev [22] |   5.122 μs | 1.007 μs | 0.5995 μs |  0.13 |    0.02 |  20.31 KB |        0.30 |
|            |       |                      |            |          |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)tdDev [22]** | **256.975 μs** | **3.552 μs** | **1.8576 μs** |  **1.00** |    **0.01** | **637.05 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tdDev [22] |  38.350 μs | 2.161 μs | 1.1301 μs |  0.15 |    0.00 | 156.67 KB |        0.25 |
