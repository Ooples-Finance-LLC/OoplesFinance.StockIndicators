```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)Width [34]** |    **172.8 μs** |   **5.80 μs** |  **3.45 μs** |  **1.00** |    **0.03** |  **329.56 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)Width [34] |  1,477.7 μs |  23.02 μs | 13.70 μs |  8.56 |    0.18 | 2024.66 KB |        6.14 |
|            |       |                      |             |           |          |       |         |            |             |
| **Ooples**     | **10000** | **Trady(...)Width [34]** |  **1,612.2 μs** |  **11.56 μs** |  **6.05 μs** |  **1.00** |    **0.00** | **3230.02 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)Width [34] | 13,617.2 μs | 189.76 μs | 99.25 μs |  8.45 |    0.07 | 19630.8 KB |        6.08 |
