```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean       | Error    | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|---------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Var** |  **32.444 μs** | **3.857 μs** | **2.2952 μs** |  **1.00** |    **0.09** |  **67.12 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Var |   3.567 μs | 1.241 μs | 0.7382 μs |  0.11 |    0.02 |  16.75 KB |        0.25 |
|            |       |                     |            |          |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Var** | **186.900 μs** | **5.825 μs** | **3.4666 μs** |  **1.00** |    **0.02** | **636.77 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Var |  22.788 μs | 1.135 μs | 0.5939 μs |  0.12 |    0.00 |  164.5 KB |        0.26 |
