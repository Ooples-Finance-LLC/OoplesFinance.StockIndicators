```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Variance** |    **32.36 μs** |  **0.855 μs** |  **0.447 μs** |  **1.00** |    **0.02** |   **67.12 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Variance |   288.92 μs |  7.759 μs |  5.132 μs |  8.93 |    0.19 |  417.84 KB |        6.23 |
|            |       |                    |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Variance** |   **203.16 μs** | **13.573 μs** |  **8.077 μs** |  **1.00** |    **0.05** |  **633.49 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Variance | 2,878.64 μs | 55.010 μs | 32.736 μs | 14.19 |    0.54 | 4203.13 KB |        6.63 |
