```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)bands [22]** |  **93.79 μs** |  **6.911 μs** | **3.615 μs** |  **1.00** |    **0.05** |  **205.13 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)bands [22] |  10.22 μs |  0.263 μs | 0.156 μs |  0.11 |    0.00 |  104.82 KB |        0.51 |
|            |       |                      |           |           |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)bands [22]** | **786.51 μs** | **15.903 μs** | **9.464 μs** |  **1.00** |    **0.02** | **1997.19 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)bands [22] |  90.31 μs |  1.514 μs | 0.792 μs |  0.11 |    0.00 |  973.63 KB |        0.49 |
