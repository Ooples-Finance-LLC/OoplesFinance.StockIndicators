```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId           | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |----------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Stddev** |    **38.32 μs** |  **2.273 μs** |  **1.353 μs** |  **1.00** |    **0.05** |   **67.09 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Stddev |   300.92 μs | 10.084 μs |  6.670 μs |  7.86 |    0.31 |  417.46 KB |        6.22 |
|            |       |                  |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Stddev** |   **256.30 μs** | **22.840 μs** | **13.592 μs** |  **1.00** |    **0.07** |  **634.43 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Stddev | 2,999.50 μs | 79.364 μs | 52.495 μs | 11.73 |    0.59 | 4203.79 KB |        6.63 |
