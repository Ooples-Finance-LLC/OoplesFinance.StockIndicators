```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|----------:|------:|--------:|----------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **Trady(...)Width [34]** | **1000**  |    **353.8 μs** |    **89.45 μs** |  **59.16 μs** |  **0.22** |    **0.03** |         **-** |         **-** |        **-** |   **133.23 KB** |        **0.08** |
| BuilderLatestOnly | Trady(...)Width [34] | 1000  |    175.5 μs |    32.79 μs |  21.69 μs |  0.11 |    0.01 |    3.9063 |         - |        - |    85.58 KB |        0.05 |
| NativeSingle      | Trady(...)Width [34] | 1000  |  1,636.4 μs |    26.13 μs |  17.28 μs |  1.00 |    0.01 |   93.7500 |   78.1250 |  46.8750 |  1710.68 KB |        1.00 |
| NativeParallel    | Trady(...)Width [34] | 1000  |    800.5 μs |    16.09 μs |   8.41 μs |  0.49 |    0.01 |  101.5625 |   31.2500 |        - |  1656.45 KB |        0.97 |
|                   |                      |       |             |             |           |       |         |           |           |          |             |             |
| **BuilderFull**       | **Trady(...)Width [34]** | **10000** |  **1,530.5 μs** |   **167.63 μs** | **110.88 μs** |  **0.10** |    **0.01** |   **70.3125** |   **62.5000** |        **-** |  **1258.57 KB** |        **0.08** |
| BuilderLatestOnly | Trady(...)Width [34] | 10000 |  1,416.0 μs |    19.88 μs |  11.83 μs |  0.09 |    0.00 |   46.8750 |   15.6250 |        - |   788.83 KB |        0.05 |
| NativeSingle      | Trady(...)Width [34] | 10000 | 16,004.8 μs |   176.44 μs | 105.00 μs |  1.00 |    0.01 | 1333.3333 | 1000.0000 | 833.3333 | 16575.45 KB |        1.00 |
| NativeParallel    | Trady(...)Width [34] | 10000 | 10,669.5 μs | 1,374.83 μs | 909.36 μs |  0.67 |    0.05 | 1600.0000 | 1300.0000 | 900.0000 | 16211.22 KB |        0.98 |
