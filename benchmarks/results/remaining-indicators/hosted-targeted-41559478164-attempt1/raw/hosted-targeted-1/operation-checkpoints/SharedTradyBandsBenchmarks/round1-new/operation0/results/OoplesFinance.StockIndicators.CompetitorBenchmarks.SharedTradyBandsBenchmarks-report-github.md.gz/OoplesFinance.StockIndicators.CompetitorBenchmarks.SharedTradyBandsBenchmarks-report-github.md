```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Trady(...)Bands [30]** | **1000**  |   **212.1 μs** |  **83.46 μs** | **55.20 μs** |       **-** |       **-** | **133.23 KB** |
| BuilderLatestOnly | Trady(...)Bands [30] | 1000  |   165.6 μs |  19.04 μs | 11.33 μs |  3.9063 |       - |  85.58 KB |
| **BuilderFull**       | **Trady(...)Bands [30]** | **10000** | **1,431.1 μs** | **127.50 μs** | **84.34 μs** | **70.3125** | **62.5000** | **1258.6 KB** |
| BuilderLatestOnly | Trady(...)Bands [30] | 10000 | 1,486.2 μs |  87.57 μs | 52.11 μs | 46.8750 | 15.6250 | 788.78 KB |
