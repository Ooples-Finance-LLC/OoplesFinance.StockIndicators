```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Trady(...)Width [34]** | **1000**  |   **233.4 μs** |  **80.25 μs** |  **53.08 μs** |       **-** |       **-** |  **133.23 KB** |
| BuilderLatestOnly | Trady(...)Width [34] | 1000  |   168.4 μs |  15.57 μs |  10.30 μs |  3.9063 |       - |   85.59 KB |
| **BuilderFull**       | **Trady(...)Width [34]** | **10000** | **1,461.1 μs** | **238.97 μs** | **142.21 μs** | **62.5000** | **46.8750** | **1258.67 KB** |
| BuilderLatestOnly | Trady(...)Width [34] | 10000 | 1,454.1 μs | 110.65 μs |  65.84 μs | 46.8750 | 23.4375 |  788.79 KB |
