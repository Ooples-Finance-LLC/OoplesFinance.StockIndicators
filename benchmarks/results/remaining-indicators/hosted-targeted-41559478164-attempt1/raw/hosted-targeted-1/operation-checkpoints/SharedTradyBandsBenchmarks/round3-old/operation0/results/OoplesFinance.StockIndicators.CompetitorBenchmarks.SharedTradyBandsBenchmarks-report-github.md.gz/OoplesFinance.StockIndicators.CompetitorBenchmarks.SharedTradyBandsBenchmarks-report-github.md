```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Trady(...)Bands [30]** | **1000**  |   **158.3 μs** |  **19.47 μs** |  **11.59 μs** |  **7.8125** |       **-** |  **133.01 KB** |
| BuilderLatestOnly | Trady(...)Bands [30] | 1000  |   140.8 μs |  17.94 μs |  11.87 μs |  4.8828 |  0.9766 |   85.36 KB |
| **BuilderFull**       | **Trady(...)Bands [30]** | **10000** | **1,223.5 μs** | **155.10 μs** | **102.59 μs** | **70.3125** | **62.5000** | **1258.38 KB** |
| BuilderLatestOnly | Trady(...)Bands [30] | 10000 | 1,212.2 μs | 146.32 μs |  96.78 μs | 46.8750 | 15.6250 |  788.54 KB |
