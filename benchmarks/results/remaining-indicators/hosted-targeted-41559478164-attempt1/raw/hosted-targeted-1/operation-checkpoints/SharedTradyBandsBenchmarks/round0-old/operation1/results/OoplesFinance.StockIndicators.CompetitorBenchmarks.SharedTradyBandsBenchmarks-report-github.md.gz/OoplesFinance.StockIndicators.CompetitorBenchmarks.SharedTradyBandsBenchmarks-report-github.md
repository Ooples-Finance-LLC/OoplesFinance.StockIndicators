```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Trady(...)Width [34]** | **1000**  |   **182.0 μs** |  **58.24 μs** |  **38.52 μs** |  **7.8125** |       **-** |  **132.97 KB** |
| BuilderLatestOnly | Trady(...)Width [34] | 1000  |   145.8 μs |  15.91 μs |  10.52 μs |  4.8828 |  0.9766 |   85.36 KB |
| **BuilderFull**       | **Trady(...)Width [34]** | **10000** | **1,193.8 μs** |  **83.72 μs** |  **43.79 μs** | **70.3125** | **62.5000** | **1258.37 KB** |
| BuilderLatestOnly | Trady(...)Width [34] | 10000 | 1,268.2 μs | 164.70 μs | 108.94 μs | 46.8750 | 23.4375 |  788.54 KB |
