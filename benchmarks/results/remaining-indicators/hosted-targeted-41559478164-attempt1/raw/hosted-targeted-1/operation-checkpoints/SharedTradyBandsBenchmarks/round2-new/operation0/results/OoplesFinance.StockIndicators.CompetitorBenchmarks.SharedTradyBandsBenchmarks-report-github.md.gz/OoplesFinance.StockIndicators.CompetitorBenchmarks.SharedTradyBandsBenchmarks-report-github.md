```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **Trady(...)Bands [30]** | **1000**  |    **250.9 μs** |    **60.35 μs** |    **35.92 μs** |  **0.17** |    **0.02** |         **-** |         **-** |        **-** |   **133.23 KB** |        **0.09** |
| BuilderLatestOnly | Trady(...)Bands [30] | 1000  |    165.8 μs |    17.31 μs |    10.30 μs |  0.11 |    0.01 |    3.9063 |         - |        - |    85.58 KB |        0.06 |
| NativeSingle      | Trady(...)Bands [30] | 1000  |  1,483.7 μs |    10.68 μs |     7.06 μs |  1.00 |    0.01 |  101.5625 |   93.7500 |  46.8750 |  1554.14 KB |        1.00 |
| NativeParallel    | Trady(...)Bands [30] | 1000  |    743.7 μs |    37.76 μs |    24.98 μs |  0.50 |    0.02 |   97.6563 |   39.0625 |        - |  1567.63 KB |        1.01 |
|                   |                      |       |             |             |             |       |         |           |           |          |             |             |
| **BuilderFull**       | **Trady(...)Bands [30]** | **10000** |  **1,520.8 μs** |   **335.27 μs** |   **221.76 μs** |  **0.10** |    **0.01** |   **62.5000** |   **46.8750** |        **-** |  **1258.63 KB** |        **0.08** |
| BuilderLatestOnly | Trady(...)Bands [30] | 10000 |  1,553.4 μs |   132.46 μs |    87.62 μs |  0.11 |    0.01 |   46.8750 |   23.4375 |        - |   788.78 KB |        0.05 |
| NativeSingle      | Trady(...)Bands [30] | 10000 | 14,762.1 μs |   585.46 μs |   306.21 μs |  1.00 |    0.03 | 1285.7143 | 1000.0000 | 857.1429 | 15130.08 KB |        1.00 |
| NativeParallel    | Trady(...)Bands [30] | 10000 | 10,417.2 μs | 1,692.68 μs | 1,007.29 μs |  0.71 |    0.07 | 1454.5455 | 1090.9091 | 818.1818 | 15357.98 KB |        1.02 |
