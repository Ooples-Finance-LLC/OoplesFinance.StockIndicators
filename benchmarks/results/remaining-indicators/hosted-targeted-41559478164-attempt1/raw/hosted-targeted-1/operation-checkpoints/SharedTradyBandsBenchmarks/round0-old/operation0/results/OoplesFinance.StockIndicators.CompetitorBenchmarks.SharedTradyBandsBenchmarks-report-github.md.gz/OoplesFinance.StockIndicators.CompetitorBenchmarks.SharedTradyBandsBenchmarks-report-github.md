```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Trady(...)Bands [30]** | **1000**  |   **161.9 μs** |  **41.08 μs** |  **27.17 μs** |  **7.8125** |       **-** | **132.93 KB** |
| BuilderLatestOnly | Trady(...)Bands [30] | 1000  |   136.1 μs |   5.44 μs |   3.24 μs |  3.9063 |       - |  85.37 KB |
| **BuilderFull**       | **Trady(...)Bands [30]** | **10000** | **1,288.6 μs** | **207.42 μs** | **137.19 μs** | **62.5000** | **46.8750** | **1258.4 KB** |
| BuilderLatestOnly | Trady(...)Bands [30] | 10000 | 1,202.7 μs |  85.25 μs |  56.39 μs | 46.8750 | 15.6250 | 788.55 KB |
