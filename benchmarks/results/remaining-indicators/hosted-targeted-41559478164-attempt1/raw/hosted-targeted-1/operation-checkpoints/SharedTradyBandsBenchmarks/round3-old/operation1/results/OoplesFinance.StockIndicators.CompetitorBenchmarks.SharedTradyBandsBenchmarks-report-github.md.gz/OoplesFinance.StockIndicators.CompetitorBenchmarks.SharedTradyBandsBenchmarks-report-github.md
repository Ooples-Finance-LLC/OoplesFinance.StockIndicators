```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Trady(...)Width [34]** | **1000**  |   **233.4 μs** |  **47.04 μs** |  **31.12 μs** |  **7.8125** |       **-** |  **132.97 KB** |
| BuilderLatestOnly | Trady(...)Width [34] | 1000  |   144.6 μs |  18.48 μs |  12.22 μs |  4.8828 |  0.9766 |   85.36 KB |
| **BuilderFull**       | **Trady(...)Width [34]** | **10000** | **1,247.5 μs** | **153.14 μs** | **101.29 μs** | **70.3125** | **62.5000** | **1258.38 KB** |
| BuilderLatestOnly | Trady(...)Width [34] | 10000 | 1,247.4 μs | 162.50 μs | 107.49 μs | 46.8750 | 23.4375 |  788.57 KB |
