```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation         | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |------------------ |------ |-----------:|----------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetStdDev** | **1000**  |   **200.9 μs** |  **35.84 μs** |  **23.71 μs** |       **-** |       **-** |   **110.9 KB** |
| BuilderLatestOnly | Skender.GetStdDev | 1000  |   148.9 μs |  15.88 μs |   9.45 μs |  3.9063 |       - |   63.25 KB |
| **BuilderFull**       | **Skender.GetStdDev** | **10000** | **1,120.5 μs** | **176.88 μs** | **116.99 μs** | **62.5000** | **31.2500** | **1025.33 KB** |
| BuilderLatestOnly | Skender.GetStdDev | 10000 | 1,073.4 μs |  82.00 μs |  54.24 μs | 31.2500 |  7.8125 |  555.52 KB |
