```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation         | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |------------------ |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetStdDev** | **1000**  |   **427.73 μs** | **170.355 μs** | **112.679 μs** |  **4.17** |    **1.05** |        **-** |        **-** |       **-** |   **110.9 KB** |        **0.35** |
| BuilderLatestOnly | Skender.GetStdDev | 1000  |   159.66 μs |  24.168 μs |  15.986 μs |  1.56 |    0.15 |   3.9063 |        - |       - |   63.26 KB |        0.20 |
| NativeSingle      | Skender.GetStdDev | 1000  |   102.48 μs |   1.094 μs |   0.651 μs |  1.00 |    0.01 |  18.5547 |   3.9063 |       - |  313.39 KB |        1.00 |
| NativeParallel    | Skender.GetStdDev | 1000  |    93.65 μs |   0.787 μs |   0.521 μs |  0.91 |    0.01 |  21.9727 |   5.3711 |       - |  348.39 KB |        1.11 |
|                   |                   |       |             |            |            |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skender.GetStdDev** | **10000** | **1,122.49 μs** | **152.025 μs** | **100.555 μs** |  **0.71** |    **0.07** |  **62.5000** |  **31.2500** |       **-** | **1025.29 KB** |        **0.32** |
| BuilderLatestOnly | Skender.GetStdDev | 10000 | 1,010.68 μs |  13.339 μs |   6.977 μs |  0.64 |    0.04 |  31.2500 |   7.8125 |       - |  555.49 KB |        0.18 |
| NativeSingle      | Skender.GetStdDev | 10000 | 1,595.92 μs | 143.796 μs |  95.112 μs |  1.00 |    0.08 | 257.8125 | 164.0625 | 85.9375 | 3161.76 KB |        1.00 |
| NativeParallel    | Skender.GetStdDev | 10000 |   737.86 μs |  36.646 μs |  24.239 μs |  0.46 |    0.03 | 203.1250 |  93.7500 |       - | 3266.38 KB |        1.03 |
