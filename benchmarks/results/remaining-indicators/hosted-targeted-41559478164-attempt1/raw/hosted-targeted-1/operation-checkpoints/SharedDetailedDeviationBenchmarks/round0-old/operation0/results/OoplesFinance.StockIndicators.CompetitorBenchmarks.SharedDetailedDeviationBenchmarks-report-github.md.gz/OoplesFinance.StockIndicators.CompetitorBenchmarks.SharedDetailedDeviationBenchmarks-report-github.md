```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation         | Count | Mean     | Error     | StdDev   | Gen0    | Gen1    | Allocated  |
|------------------ |------------------ |------ |---------:|----------:|---------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetStdDev** | **1000**  | **236.9 μs** | **127.80 μs** | **84.53 μs** |       **-** |       **-** |  **110.64 KB** |
| BuilderLatestOnly | Skender.GetStdDev | 1000  | 118.5 μs |  13.22 μs |  8.74 μs |  3.9063 |       - |   63.03 KB |
| **BuilderFull**       | **Skender.GetStdDev** | **10000** | **982.8 μs** | **137.90 μs** | **82.06 μs** | **62.5000** | **31.2500** | **1025.12 KB** |
| BuilderLatestOnly | Skender.GetStdDev | 10000 | 869.4 μs | 104.43 μs | 69.08 μs | 31.2500 | 11.7188 |  555.26 KB |
