```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Variance** | **1000**  |  **37.42 μs** |  **2.931 μs** |  **1.939 μs** |  **2.9297** |       **-** |  **60.04 KB** |
| BuilderLatestOnly | QuanTAlib.Variance | 1000  |  26.24 μs |  3.589 μs |  2.374 μs |  0.7324 |       - |  12.16 KB |
| **BuilderFull**       | **QuanTAlib.Variance** | **10000** | **245.06 μs** | **36.246 μs** | **18.957 μs** | **33.2031** | **13.6719** | **552.59 KB** |
| BuilderLatestOnly | QuanTAlib.Variance | 10000 | 214.07 μs | 34.308 μs | 22.693 μs |  3.9063 |       - |  82.48 KB |
