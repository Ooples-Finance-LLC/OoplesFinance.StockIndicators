```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |----------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Stddev** | **1000**  |  **74.48 μs** |  **3.056 μs** |  **1.819 μs** |       **-** |       **-** |  **60.26 KB** |
| BuilderLatestOnly | QuanTAlib.Stddev | 1000  |  56.00 μs |  3.323 μs |  1.738 μs |  0.4883 |       - |  12.38 KB |
| **BuilderFull**       | **QuanTAlib.Stddev** | **10000** | **407.50 μs** | **37.564 μs** | **22.354 μs** | **31.2500** | **11.7188** | **552.83 KB** |
| BuilderLatestOnly | QuanTAlib.Stddev | 10000 | 426.53 μs | 68.416 μs | 45.253 μs |  3.9063 |       - |  82.71 KB |
