```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |----------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Stddev** | **1000**  |    **83.64 μs** |  **10.558 μs** |  **6.984 μs** |  **0.23** |    **0.02** |        **-** |       **-** |   **60.26 KB** |        **0.14** |
| BuilderLatestOnly | QuanTAlib.Stddev | 1000  |    55.46 μs |   4.391 μs |  2.905 μs |  0.15 |    0.01 |   0.4883 |       - |   12.38 KB |        0.03 |
| NativeSingle      | QuanTAlib.Stddev | 1000  |   364.02 μs |   3.048 μs |  1.594 μs |  1.00 |    0.01 |  25.3906 |       - |  416.34 KB |        1.00 |
| NativeParallel    | QuanTAlib.Stddev | 1000  |   223.89 μs |  15.599 μs | 10.318 μs |  0.62 |    0.03 |  25.3906 |       - |  427.18 KB |        1.03 |
|                   |                  |       |             |            |           |       |         |          |         |            |             |
| **BuilderFull**       | **QuanTAlib.Stddev** | **10000** |   **417.38 μs** |  **62.558 μs** | **41.378 μs** |  **0.11** |    **0.01** |  **33.2031** | **11.7188** |  **552.82 KB** |        **0.13** |
| BuilderLatestOnly | QuanTAlib.Stddev | 10000 |   396.41 μs |  52.388 μs | 34.651 μs |  0.11 |    0.01 |   3.9063 |       - |    82.7 KB |        0.02 |
| NativeSingle      | QuanTAlib.Stddev | 10000 | 3,654.86 μs |  43.777 μs | 26.051 μs |  1.00 |    0.01 | 250.0000 | 62.5000 | 4202.75 KB |        1.00 |
| NativeParallel    | QuanTAlib.Stddev | 10000 | 2,028.82 μs | 100.255 μs | 59.660 μs |  0.56 |    0.02 | 250.0000 | 78.1250 |  4213.8 KB |        1.00 |
