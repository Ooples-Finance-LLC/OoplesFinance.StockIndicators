```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |----------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Zscore** | **1000**  |    **86.21 μs** |   **9.899 μs** |  **5.891 μs** |  **0.23** |    **0.02** |        **-** |       **-** |   **60.33 KB** |        **0.14** |
| BuilderLatestOnly | QuanTAlib.Zscore | 1000  |    67.27 μs |   9.396 μs |  6.215 μs |  0.18 |    0.02 |   0.4883 |       - |   12.38 KB |        0.03 |
| NativeSingle      | QuanTAlib.Zscore | 1000  |   368.91 μs |   1.378 μs |  0.721 μs |  1.00 |    0.00 |  25.3906 |       - |  416.29 KB |        1.00 |
| NativeParallel    | QuanTAlib.Zscore | 1000  |   224.28 μs |  18.455 μs | 10.982 μs |  0.61 |    0.03 |  25.3906 |       - |  427.03 KB |        1.03 |
|                   |                  |       |             |            |           |       |         |          |         |            |             |
| **BuilderFull**       | **QuanTAlib.Zscore** | **10000** |   **461.30 μs** |  **10.273 μs** |  **5.373 μs** |  **0.12** |    **0.00** |  **31.2500** | **11.7188** |  **552.82 KB** |        **0.13** |
| BuilderLatestOnly | QuanTAlib.Zscore | 10000 |   466.74 μs |  58.156 μs | 38.467 μs |  0.13 |    0.01 |   3.9063 |       - |   82.71 KB |        0.02 |
| NativeSingle      | QuanTAlib.Zscore | 10000 | 3,712.50 μs |  18.575 μs | 11.054 μs |  1.00 |    0.00 | 250.0000 | 62.5000 |  4202.8 KB |        1.00 |
| NativeParallel    | QuanTAlib.Zscore | 10000 | 2,077.80 μs | 123.679 μs | 73.599 μs |  0.56 |    0.02 | 250.0000 | 78.1250 | 4213.65 KB |        1.00 |
