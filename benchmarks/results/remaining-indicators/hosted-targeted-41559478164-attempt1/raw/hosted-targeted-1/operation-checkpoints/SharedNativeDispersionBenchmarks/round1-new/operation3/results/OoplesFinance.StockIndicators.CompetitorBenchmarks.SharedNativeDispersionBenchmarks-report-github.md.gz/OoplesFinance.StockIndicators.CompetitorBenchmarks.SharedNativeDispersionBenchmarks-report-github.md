```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error      | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|-----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Trady(...)ation [33]** | **1000**  |  **73.49 μs** |   **8.428 μs** |  **5.574 μs** |       **-** |       **-** |  **60.26 KB** |
| BuilderLatestOnly | Trady(...)ation [33] | 1000  |  67.49 μs |   5.573 μs |  3.686 μs |  0.4883 |       - |  12.38 KB |
| **BuilderFull**       | **Trady(...)ation [33]** | **10000** | **651.68 μs** | **122.042 μs** | **80.723 μs** | **31.2500** | **11.7188** | **552.83 KB** |
| BuilderLatestOnly | Trady(...)ation [33] | 10000 | 655.02 μs |  58.851 μs | 38.927 μs |  3.9063 |       - |  82.72 KB |
