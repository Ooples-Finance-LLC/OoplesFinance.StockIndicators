```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Trady(...)ation [33]** | **1000**  |  **59.87 μs** | **10.772 μs** |  **7.125 μs** |  **1.9531** |       **-** |  **60.04 KB** |
| BuilderLatestOnly | Trady(...)ation [33] | 1000  |  40.13 μs |  3.798 μs |  2.512 μs |  0.7324 |       - |  12.16 KB |
| **BuilderFull**       | **Trady(...)ation [33]** | **10000** | **311.39 μs** | **65.253 μs** | **43.161 μs** | **31.2500** | **11.7188** | **552.61 KB** |
| BuilderLatestOnly | Trady(...)ation [33] | 10000 | 288.73 μs | 42.202 μs | 27.914 μs |  3.9063 |       - |  82.48 KB |
