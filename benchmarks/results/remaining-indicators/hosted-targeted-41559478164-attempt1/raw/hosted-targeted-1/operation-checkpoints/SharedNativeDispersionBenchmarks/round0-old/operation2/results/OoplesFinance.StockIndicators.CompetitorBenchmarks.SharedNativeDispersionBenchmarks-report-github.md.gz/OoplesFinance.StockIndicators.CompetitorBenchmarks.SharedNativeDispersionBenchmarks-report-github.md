```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |----------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Zscore** | **1000**  |  **73.15 μs** |  **9.131 μs** |  **5.434 μs** |       **-** |       **-** |  **60.11 KB** |
| BuilderLatestOnly | QuanTAlib.Zscore | 1000  |  57.70 μs |  1.906 μs |  1.261 μs |  0.4883 |       - |  12.16 KB |
| **BuilderFull**       | **QuanTAlib.Zscore** | **10000** | **364.47 μs** | **40.778 μs** | **26.972 μs** | **33.2031** | **11.7188** |  **552.6 KB** |
| BuilderLatestOnly | QuanTAlib.Zscore | 10000 | 343.86 μs | 29.294 μs | 17.433 μs |  3.9063 |       - |  82.49 KB |
