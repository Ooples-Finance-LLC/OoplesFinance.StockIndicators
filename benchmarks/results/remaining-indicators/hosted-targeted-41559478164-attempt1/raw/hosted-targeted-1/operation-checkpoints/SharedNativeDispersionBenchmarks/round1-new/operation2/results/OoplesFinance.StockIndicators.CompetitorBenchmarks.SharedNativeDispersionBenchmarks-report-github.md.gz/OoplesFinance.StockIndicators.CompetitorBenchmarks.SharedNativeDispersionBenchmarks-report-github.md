```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |----------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Zscore** | **1000**  |  **99.54 μs** |  **5.214 μs** |  **3.103 μs** |       **-** |       **-** |  **60.33 KB** |
| BuilderLatestOnly | QuanTAlib.Zscore | 1000  |  70.19 μs |  5.563 μs |  3.679 μs |  0.4883 |       - |  12.38 KB |
| **BuilderFull**       | **QuanTAlib.Zscore** | **10000** | **495.82 μs** | **70.723 μs** | **42.086 μs** | **31.2500** | **11.7188** | **552.83 KB** |
| BuilderLatestOnly | QuanTAlib.Zscore | 10000 | 518.55 μs | 95.420 μs | 63.114 μs |  3.9063 |       - |  82.72 KB |
