```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Trady(...)ation [33]** | **1000**  |    **77.05 μs** |   **5.864 μs** |   **3.490 μs** |  **0.09** |    **0.00** |        **-** |        **-** |        **-** |    **60.3 KB** |        **0.09** |
| BuilderLatestOnly | Trady(...)ation [33] | 1000  |    59.00 μs |   8.628 μs |   5.707 μs |  0.07 |    0.01 |   0.4883 |        - |        - |   12.38 KB |        0.02 |
| NativeSingle      | Trady(...)ation [33] | 1000  |   857.20 μs |   2.435 μs |   1.273 μs |  1.00 |    0.00 |  39.0625 |   7.8125 |        - |  682.14 KB |        1.00 |
| NativeParallel    | Trady(...)ation [33] | 1000  |   478.11 μs |  53.475 μs |  35.370 μs |  0.56 |    0.04 |  42.9688 |  11.7188 |        - |  687.65 KB |        1.01 |
|                   |                      |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Trady(...)ation [33]** | **10000** |   **444.79 μs** |  **48.894 μs** |  **32.340 μs** |  **0.05** |    **0.00** |  **31.2500** |  **11.7188** |        **-** |  **552.82 KB** |        **0.08** |
| BuilderLatestOnly | Trady(...)ation [33] | 10000 |   459.14 μs | 112.191 μs |  74.207 μs |  0.05 |    0.01 |   3.9063 |        - |        - |   82.72 KB |        0.01 |
| NativeSingle      | Trady(...)ation [33] | 10000 | 8,931.64 μs | 132.223 μs |  69.155 μs |  1.00 |    0.01 | 666.6667 | 416.6667 | 416.6667 | 6755.92 KB |        1.00 |
| NativeParallel    | Trady(...)ation [33] | 10000 | 5,736.68 μs | 658.482 μs | 435.545 μs |  0.64 |    0.05 | 593.7500 | 375.0000 | 250.0000 |  6868.3 KB |        1.02 |
