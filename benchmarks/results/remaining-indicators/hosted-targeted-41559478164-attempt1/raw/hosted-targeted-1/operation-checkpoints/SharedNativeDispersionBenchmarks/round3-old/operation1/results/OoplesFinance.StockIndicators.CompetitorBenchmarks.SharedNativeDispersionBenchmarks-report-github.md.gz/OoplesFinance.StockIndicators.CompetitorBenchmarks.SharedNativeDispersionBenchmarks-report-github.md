```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |----------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Stddev** | **1000**  |  **52.16 μs** |  **0.704 μs** |  **0.419 μs** |  **1.9531** |       **-** |  **60.04 KB** |
| BuilderLatestOnly | QuanTAlib.Stddev | 1000  |  41.34 μs |  8.242 μs |  5.452 μs |  0.4883 |       - |  12.16 KB |
| **BuilderFull**       | **QuanTAlib.Stddev** | **10000** | **280.52 μs** | **11.515 μs** |  **6.023 μs** | **31.2500** | **11.7188** |  **552.6 KB** |
| BuilderLatestOnly | QuanTAlib.Stddev | 10000 | 279.95 μs | 36.984 μs | 24.463 μs |  3.9063 |       - |  82.48 KB |
