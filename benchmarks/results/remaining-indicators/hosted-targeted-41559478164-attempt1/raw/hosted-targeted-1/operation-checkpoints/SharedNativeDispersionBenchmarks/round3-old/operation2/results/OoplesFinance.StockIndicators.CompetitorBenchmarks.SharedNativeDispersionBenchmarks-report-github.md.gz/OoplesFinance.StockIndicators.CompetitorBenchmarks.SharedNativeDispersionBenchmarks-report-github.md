```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |----------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Zscore** | **1000**  |  **96.13 μs** | **30.409 μs** | **20.114 μs** |       **-** |       **-** |  **60.08 KB** |
| BuilderLatestOnly | QuanTAlib.Zscore | 1000  |  56.97 μs |  1.972 μs |  1.304 μs |  0.4883 |       - |  12.16 KB |
| **BuilderFull**       | **QuanTAlib.Zscore** | **10000** | **362.01 μs** | **27.863 μs** | **18.429 μs** | **33.2031** | **11.7188** |  **552.6 KB** |
| BuilderLatestOnly | QuanTAlib.Zscore | 10000 | 340.89 μs | 38.095 μs | 22.669 μs |  3.9063 |       - |  82.49 KB |
