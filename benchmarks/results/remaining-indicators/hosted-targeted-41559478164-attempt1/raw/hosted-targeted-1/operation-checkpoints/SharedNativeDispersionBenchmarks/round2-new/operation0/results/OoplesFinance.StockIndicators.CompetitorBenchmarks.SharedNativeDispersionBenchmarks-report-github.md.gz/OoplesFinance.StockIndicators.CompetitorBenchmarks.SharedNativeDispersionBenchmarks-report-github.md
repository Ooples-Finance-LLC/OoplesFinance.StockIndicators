```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Variance** | **1000**  |    **57.59 μs** |   **4.909 μs** |   **2.921 μs** |  **0.16** |    **0.01** |        **-** |       **-** |    **60.3 KB** |        **0.14** |
| BuilderLatestOnly | QuanTAlib.Variance | 1000  |    43.25 μs |   3.867 μs |   2.301 μs |  0.12 |    0.01 |   0.7324 |       - |   12.38 KB |        0.03 |
| NativeSingle      | QuanTAlib.Variance | 1000  |   358.85 μs |   3.186 μs |   1.896 μs |  1.00 |    0.01 |  25.3906 |       - |  416.34 KB |        1.00 |
| NativeParallel    | QuanTAlib.Variance | 1000  |   229.91 μs |  26.076 μs |  17.248 μs |  0.64 |    0.05 |  25.3906 |       - |  427.18 KB |        1.03 |
|                   |                    |       |             |            |            |       |         |          |         |            |             |
| **BuilderFull**       | **QuanTAlib.Variance** | **10000** |   **353.19 μs** |  **44.960 μs** |  **29.738 μs** |  **0.10** |    **0.01** |  **33.2031** | **13.6719** |  **552.82 KB** |        **0.13** |
| BuilderLatestOnly | QuanTAlib.Variance | 10000 |   336.15 μs |  76.887 μs |  50.856 μs |  0.09 |    0.01 |   3.9063 |       - |    82.7 KB |        0.02 |
| NativeSingle      | QuanTAlib.Variance | 10000 | 3,588.56 μs |  33.357 μs |  17.446 μs |  1.00 |    0.01 | 250.0000 | 62.5000 | 4202.87 KB |        1.00 |
| NativeParallel    | QuanTAlib.Variance | 10000 | 2,047.30 μs | 192.460 μs | 127.300 μs |  0.57 |    0.03 | 250.0000 | 78.1250 |  4213.8 KB |        1.00 |
