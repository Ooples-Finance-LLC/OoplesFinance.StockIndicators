```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Variance** | **1000**  |  **56.90 μs** | **11.151 μs** |  **5.832 μs** |       **-** |       **-** |  **60.32 KB** |
| BuilderLatestOnly | QuanTAlib.Variance | 1000  |  45.35 μs |  5.791 μs |  3.830 μs |  0.4883 |       - |  12.38 KB |
| **BuilderFull**       | **QuanTAlib.Variance** | **10000** | **385.96 μs** | **73.485 μs** | **38.434 μs** | **31.2500** | **11.7188** | **552.83 KB** |
| BuilderLatestOnly | QuanTAlib.Variance | 10000 | 357.85 μs | 88.036 μs | 58.230 μs |  3.9063 |       - |  82.72 KB |
