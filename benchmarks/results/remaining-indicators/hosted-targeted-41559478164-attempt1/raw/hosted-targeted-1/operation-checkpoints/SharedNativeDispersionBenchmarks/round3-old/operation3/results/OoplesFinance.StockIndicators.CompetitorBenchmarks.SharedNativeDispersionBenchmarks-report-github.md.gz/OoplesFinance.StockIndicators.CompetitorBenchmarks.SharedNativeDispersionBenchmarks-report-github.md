```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Trady(...)ation [33]** | **1000**  |  **50.75 μs** |  **4.507 μs** |  **2.682 μs** |  **1.9531** |       **-** |  **60.04 KB** |
| BuilderLatestOnly | Trady(...)ation [33] | 1000  |  43.69 μs |  3.989 μs |  2.638 μs |  0.4883 |       - |  12.16 KB |
| **BuilderFull**       | **Trady(...)ation [33]** | **10000** | **287.29 μs** | **25.636 μs** | **15.256 μs** | **33.2031** | **11.7188** |  **552.6 KB** |
| BuilderLatestOnly | Trady(...)ation [33] | 10000 | 265.57 μs | 17.440 μs |  9.121 μs |  3.9063 |       - |  82.49 KB |
