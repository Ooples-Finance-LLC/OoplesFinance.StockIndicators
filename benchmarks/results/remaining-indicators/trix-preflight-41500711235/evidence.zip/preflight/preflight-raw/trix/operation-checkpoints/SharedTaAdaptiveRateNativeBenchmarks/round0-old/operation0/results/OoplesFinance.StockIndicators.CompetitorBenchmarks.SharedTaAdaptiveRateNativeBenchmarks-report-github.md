```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **567.3 μs** | **35.12 μs** | **23.23 μs** |       **-** |  **89.26 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   552.6 μs | 12.57 μs |  8.31 μs |       - |   41.6 KB |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **5,486.8 μs** | **22.34 μs** | **13.30 μs** | **31.2500** | **863.22 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 5,490.1 μs | 54.02 μs | 35.73 μs |       - | 393.39 KB |
