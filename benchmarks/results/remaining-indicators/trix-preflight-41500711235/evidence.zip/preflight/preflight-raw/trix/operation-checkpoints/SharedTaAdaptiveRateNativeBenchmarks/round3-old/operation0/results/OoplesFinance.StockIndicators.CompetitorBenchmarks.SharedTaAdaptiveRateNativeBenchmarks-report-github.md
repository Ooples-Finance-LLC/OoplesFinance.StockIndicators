```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **579.3 μs** |  **4.69 μs** |  **2.79 μs** |  **89.26 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   586.7 μs | 10.33 μs |  6.15 μs |   41.6 KB |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **5,792.4 μs** | **45.36 μs** | **26.99 μs** | **863.47 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 5,785.8 μs | 18.62 μs |  9.74 μs | 393.39 KB |
