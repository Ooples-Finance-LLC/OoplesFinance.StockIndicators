```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **327.2 μs** |  **1.02 μs** |  **0.61 μs** |       **-** |  **89.21 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   309.5 μs |  1.82 μs |  1.21 μs |  1.9531 |   41.6 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **3,259.4 μs** | **37.09 μs** | **22.07 μs** | **31.2500** | **863.22 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 3,227.6 μs | 25.79 μs | 15.35 μs |       - |  393.4 KB |
