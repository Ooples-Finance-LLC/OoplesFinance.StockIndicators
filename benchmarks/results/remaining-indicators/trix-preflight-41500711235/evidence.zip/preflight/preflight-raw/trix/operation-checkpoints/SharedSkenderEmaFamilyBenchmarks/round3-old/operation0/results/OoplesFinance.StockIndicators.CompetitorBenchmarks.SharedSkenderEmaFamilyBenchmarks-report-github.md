```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **551.3 μs** |  **2.77 μs** |  **1.65 μs** |       **-** |  **89.26 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   557.0 μs | 26.41 μs | 17.47 μs |       - |  41.59 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **5,408.8 μs** | **38.40 μs** | **20.08 μs** | **31.2500** | **863.22 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 5,407.7 μs | 29.79 μs | 17.73 μs |       - | 393.39 KB |
