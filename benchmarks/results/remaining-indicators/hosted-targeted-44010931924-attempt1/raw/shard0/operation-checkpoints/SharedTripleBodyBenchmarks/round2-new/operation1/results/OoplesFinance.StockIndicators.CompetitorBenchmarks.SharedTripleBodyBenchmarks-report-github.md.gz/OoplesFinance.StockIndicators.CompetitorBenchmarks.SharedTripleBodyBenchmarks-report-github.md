```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0   | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|-------:|-------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)Crows [22]** | **1000**  |  **20.02 μs** |  **0.093 μs** |  **0.055 μs** |  **1.00** |    **0.00** |      **-** |      **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)Crows [22] | 1000  |  66.57 μs |  0.679 μs |  0.355 μs |  3.32 |    0.02 |      - |      - |    8.4 KB |        2.12 |
| BuilderFull       | TaLib(...)Crows [22] | 1000  |  88.99 μs |  1.678 μs |  0.877 μs |  4.44 |    0.04 |      - |      - |  64.26 KB |       16.19 |
| BuilderLatestOnly | TaLib(...)Crows [22] | 1000  |  88.76 μs |  5.819 μs |  3.849 μs |  4.43 |    0.18 |      - |      - |  16.37 KB |        4.12 |
|                   |                      |       |           |           |           |       |         |        |        |           |             |
| **NativeSingle**      | **TaLib(...)Crows [22]** | **10000** | **200.45 μs** |  **1.650 μs** |  **0.863 μs** |  **1.00** |    **0.01** |      **-** |      **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib(...)Crows [22] | 10000 | 177.75 μs | 17.464 μs | 11.552 μs |  0.89 |    0.06 | 0.9766 |      - |  78.72 KB |        2.01 |
| BuilderFull       | TaLib(...)Crows [22] | 10000 | 371.64 μs | 36.184 μs | 23.933 μs |  1.85 |    0.11 | 5.8594 | 3.9063 | 556.79 KB |       14.23 |
| BuilderLatestOnly | TaLib(...)Crows [22] | 10000 | 345.83 μs | 27.328 μs | 18.076 μs |  1.73 |    0.09 |      - |      - |   86.7 KB |        2.22 |
