```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|-------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)Crows [31]** | **1000**  |  **34.72 μs** |  **2.577 μs** |  **1.705 μs** |  **1.00** |    **0.07** |      **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)Crows [31] | 1000  |  76.30 μs |  5.710 μs |  3.777 μs |  2.20 |    0.14 |      - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib(...)Crows [31] | 1000  |  92.81 μs |  2.987 μs |  1.562 μs |  2.68 |    0.13 |      - |  64.26 KB |       16.19 |
| BuilderLatestOnly | TaLib(...)Crows [31] | 1000  |  89.98 μs |  2.932 μs |  1.533 μs |  2.60 |    0.12 |      - |  16.38 KB |        4.13 |
|                   |                      |       |           |           |           |       |         |        |           |             |
| **NativeSingle**      | **TaLib(...)Crows [31]** | **10000** | **337.59 μs** |  **1.634 μs** |  **0.855 μs** |  **1.00** |    **0.00** |      **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib(...)Crows [31] | 10000 | 238.31 μs |  5.130 μs |  2.683 μs |  0.71 |    0.01 |      - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib(...)Crows [31] | 10000 | 398.20 μs |  8.526 μs |  4.459 μs |  1.18 |    0.01 | 3.9063 |  556.8 KB |       14.23 |
| BuilderLatestOnly | TaLib(...)Crows [31] | 10000 | 380.96 μs | 27.419 μs | 18.136 μs |  1.13 |    0.05 |      - |   86.7 KB |        2.21 |
