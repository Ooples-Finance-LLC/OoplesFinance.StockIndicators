```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)Crows [22]** | **1000**  |  **96.03 μs** |  **6.211 μs** |  **3.248 μs** |      **-** |  **64.25 KB** |
| BuilderLatestOnly | TaLib(...)Crows [22] | 1000  |  90.08 μs |  1.194 μs |  0.624 μs |      - |  16.38 KB |
| **BuilderFull**       | **TaLib(...)Crows [22]** | **10000** | **409.52 μs** |  **9.633 μs** |  **5.038 μs** | **3.9063** |  **556.8 KB** |
| BuilderLatestOnly | TaLib(...)Crows [22] | 10000 | 393.32 μs | 29.995 μs | 19.840 μs |      - |   86.7 KB |
