```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|-------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)River [30]** | **1000**  |  **34.73 μs** |  **0.983 μs** |  **0.650 μs** |  **1.00** |    **0.03** |      **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)River [30] | 1000  |  98.66 μs |  2.050 μs |  1.220 μs |  2.84 |    0.06 |      - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib(...)River [30] | 1000  | 116.54 μs |  1.352 μs |  0.804 μs |  3.36 |    0.06 |      - |  64.26 KB |       16.19 |
| BuilderLatestOnly | TaLib(...)River [30] | 1000  | 117.19 μs |  1.655 μs |  0.985 μs |  3.38 |    0.07 |      - |  16.38 KB |        4.13 |
|                   |                      |       |           |           |           |       |         |        |           |             |
| **NativeSingle**      | **TaLib(...)River [30]** | **10000** | **344.18 μs** |  **2.818 μs** |  **1.474 μs** |  **1.00** |    **0.01** |      **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib(...)River [30] | 10000 | 265.49 μs |  3.450 μs |  1.804 μs |  0.77 |    0.01 |      - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib(...)River [30] | 10000 | 413.87 μs | 15.042 μs |  7.867 μs |  1.20 |    0.02 | 3.9063 |  556.8 KB |       14.23 |
| BuilderLatestOnly | TaLib(...)River [30] | 10000 | 400.55 μs | 31.479 μs | 20.821 μs |  1.16 |    0.06 |      - |   86.7 KB |        2.22 |
