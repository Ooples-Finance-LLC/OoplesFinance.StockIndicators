```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0   | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)Crows [22]** | **1000**  | **121.0 μs** |  **3.62 μs** |  **2.39 μs** |      **-** |  **64.25 KB** |
| BuilderLatestOnly | TaLib(...)Crows [22] | 1000  | 117.0 μs |  2.04 μs |  1.21 μs |      - |  16.38 KB |
| **BuilderFull**       | **TaLib(...)Crows [22]** | **10000** | **454.1 μs** | **52.29 μs** | **31.12 μs** | **3.9063** |  **556.8 KB** |
| BuilderLatestOnly | TaLib(...)Crows [22] | 10000 | 427.0 μs | 42.66 μs | 25.39 μs |      - |  86.71 KB |
