```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error     | StdDev   | Allocated |
|------------------ |--------------------- |------ |---------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)Crows [31]** | **1000**  | **107.3 μs** |  **17.34 μs** | **11.47 μs** |  **64.25 KB** |
| BuilderLatestOnly | TaLib(...)Crows [31] | 1000  | 113.6 μs |  26.41 μs | 17.47 μs |  16.38 KB |
| **BuilderFull**       | **TaLib(...)Crows [31]** | **10000** | **578.5 μs** | **145.23 μs** | **96.06 μs** | **556.83 KB** |
| BuilderLatestOnly | TaLib(...)Crows [31] | 10000 | 438.0 μs |   6.02 μs |  3.15 μs |  86.71 KB |
