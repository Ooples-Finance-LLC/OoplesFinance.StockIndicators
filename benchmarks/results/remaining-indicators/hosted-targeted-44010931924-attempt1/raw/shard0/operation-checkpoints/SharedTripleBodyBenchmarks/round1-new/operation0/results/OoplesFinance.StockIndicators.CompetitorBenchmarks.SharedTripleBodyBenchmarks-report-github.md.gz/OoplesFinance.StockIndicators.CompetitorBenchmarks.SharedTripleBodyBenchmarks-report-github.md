```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)nside [25]** | **1000**  |  **95.80 μs** | **10.870 μs** |  **6.469 μs** |      **-** |  **64.25 KB** |
| BuilderLatestOnly | TaLib(...)nside [25] | 1000  |  93.72 μs |  8.214 μs |  5.433 μs |      - |  16.38 KB |
| **BuilderFull**       | **TaLib(...)nside [25]** | **10000** | **431.18 μs** |  **6.911 μs** |  **3.615 μs** | **3.9063** |  **556.8 KB** |
| BuilderLatestOnly | TaLib(...)nside [25] | 10000 | 382.83 μs | 25.009 μs | 16.542 μs |      - |   86.7 KB |
