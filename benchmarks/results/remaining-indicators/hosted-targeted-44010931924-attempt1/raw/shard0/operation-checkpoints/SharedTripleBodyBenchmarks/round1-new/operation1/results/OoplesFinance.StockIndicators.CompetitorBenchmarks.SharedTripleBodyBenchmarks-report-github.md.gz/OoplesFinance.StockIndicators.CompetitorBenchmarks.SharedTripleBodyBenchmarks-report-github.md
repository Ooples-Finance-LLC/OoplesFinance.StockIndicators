```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0   | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|-------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)Crows [22]** | **1000**  |  **96.35 μs** | **18.368 μs** | **12.149 μs** |      **-** |      **-** |  **64.25 KB** |
| BuilderLatestOnly | TaLib(...)Crows [22] | 1000  |  91.06 μs |  6.054 μs |  3.602 μs |      - |      - |  16.38 KB |
| **BuilderFull**       | **TaLib(...)Crows [22]** | **10000** | **371.89 μs** | **30.525 μs** | **20.191 μs** | **5.8594** | **3.9063** | **556.79 KB** |
| BuilderLatestOnly | TaLib(...)Crows [22] | 10000 | 341.49 μs | 29.454 μs | 19.482 μs |      - |      - |   86.7 KB |
