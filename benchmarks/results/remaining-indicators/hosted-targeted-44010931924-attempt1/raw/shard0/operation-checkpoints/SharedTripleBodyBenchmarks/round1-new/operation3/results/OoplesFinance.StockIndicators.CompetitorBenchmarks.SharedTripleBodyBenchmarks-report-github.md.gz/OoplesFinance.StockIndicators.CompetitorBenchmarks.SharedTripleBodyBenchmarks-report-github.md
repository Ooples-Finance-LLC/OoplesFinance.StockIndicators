```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev   | Gen0   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|---------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)River [30]** | **1000**  |  **99.90 μs** | **13.135 μs** | **7.816 μs** |      **-** |  **64.25 KB** |
| BuilderLatestOnly | TaLib(...)River [30] | 1000  |  89.40 μs |  1.894 μs | 0.991 μs |      - |  16.38 KB |
| **BuilderFull**       | **TaLib(...)River [30]** | **10000** | **389.34 μs** |  **3.276 μs** | **1.713 μs** | **3.9063** |  **556.8 KB** |
| BuilderLatestOnly | TaLib(...)River [30] | 10000 | 362.21 μs |  4.929 μs | 2.578 μs |      - |  86.71 KB |
