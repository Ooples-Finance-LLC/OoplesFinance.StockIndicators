```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev   | Gen0   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|---------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)River [30]** | **1000**  | **103.67 μs** | **13.558 μs** | **8.068 μs** |      **-** |  **64.25 KB** |
| BuilderLatestOnly | TaLib(...)River [30] | 1000  |  95.35 μs |  0.772 μs | 0.404 μs |      - |  16.38 KB |
| **BuilderFull**       | **TaLib(...)River [30]** | **10000** | **456.23 μs** | **11.431 μs** | **5.978 μs** | **3.9063** |  **556.8 KB** |
| BuilderLatestOnly | TaLib(...)River [30] | 10000 | 430.84 μs | 14.155 μs | 7.403 μs |      - |  86.71 KB |
