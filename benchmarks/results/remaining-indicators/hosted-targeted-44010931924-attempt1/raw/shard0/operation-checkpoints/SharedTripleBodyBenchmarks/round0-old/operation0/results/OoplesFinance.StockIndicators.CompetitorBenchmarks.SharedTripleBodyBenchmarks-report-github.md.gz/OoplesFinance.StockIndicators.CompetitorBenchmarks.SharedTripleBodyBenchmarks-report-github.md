```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)nside [25]** | **1000**  |  **99.51 μs** |  **2.478 μs** |  **1.296 μs** |      **-** |  **64.25 KB** |
| BuilderLatestOnly | TaLib(...)nside [25] | 1000  |  95.68 μs |  1.616 μs |  0.845 μs |      - |  16.38 KB |
| **BuilderFull**       | **TaLib(...)nside [25]** | **10000** | **499.49 μs** | **54.100 μs** | **35.784 μs** | **3.9063** |  **556.8 KB** |
| BuilderLatestOnly | TaLib(...)nside [25] | 10000 | 476.04 μs | 54.995 μs | 32.726 μs |      - |  86.71 KB |
