```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean     | Error    | StdDev   | Gen0   | Allocated |
|------------------ |--------------------- |------ |---------:|---------:|---------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)nside [25]** | **1000**  | **123.7 μs** |  **4.28 μs** |  **2.55 μs** |      **-** |  **64.25 KB** |
| BuilderLatestOnly | TaLib(...)nside [25] | 1000  | 125.2 μs |  4.05 μs |  2.68 μs |      - |  16.38 KB |
| **BuilderFull**       | **TaLib(...)nside [25]** | **10000** | **532.9 μs** | **52.72 μs** | **34.87 μs** | **3.9063** |  **556.8 KB** |
| BuilderLatestOnly | TaLib(...)nside [25] | 10000 | 453.0 μs |  9.15 μs |  4.78 μs |      - |  86.71 KB |
