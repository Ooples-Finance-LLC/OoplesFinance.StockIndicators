```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)Crows [31]** | **1000**  | **113.67 μs** | **24.420 μs** | **16.153 μs** |      **-** |  **64.25 KB** |
| BuilderLatestOnly | TaLib(...)Crows [31] | 1000  |  96.05 μs |  3.633 μs |  1.900 μs |      - |  16.38 KB |
| **BuilderFull**       | **TaLib(...)Crows [31]** | **10000** | **529.73 μs** | **84.950 μs** | **56.189 μs** | **3.9063** |  **556.8 KB** |
| BuilderLatestOnly | TaLib(...)Crows [31] | 10000 | 454.81 μs | 64.420 μs | 42.610 μs |      - |  86.71 KB |
