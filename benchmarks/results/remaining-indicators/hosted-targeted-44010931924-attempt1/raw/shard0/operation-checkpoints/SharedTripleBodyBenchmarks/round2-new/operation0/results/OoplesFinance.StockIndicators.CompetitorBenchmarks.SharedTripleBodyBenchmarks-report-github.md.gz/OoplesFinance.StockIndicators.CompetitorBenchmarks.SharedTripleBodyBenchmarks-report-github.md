```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|-------:|----------:|------------:|
| **NativeSingle**      | **TaLib(...)nside [25]** | **1000**  |  **47.25 μs** |  **0.198 μs** |  **0.104 μs** |  **1.00** |    **0.00** |      **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib(...)nside [25] | 1000  |  75.24 μs |  1.570 μs |  0.934 μs |  1.59 |    0.02 |      - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib(...)nside [25] | 1000  |  92.98 μs |  1.681 μs |  0.879 μs |  1.97 |    0.02 |      - |  64.26 KB |       16.19 |
| BuilderLatestOnly | TaLib(...)nside [25] | 1000  |  89.58 μs |  1.480 μs |  0.774 μs |  1.90 |    0.02 |      - |  16.38 KB |        4.13 |
|                   |                      |       |           |           |           |       |         |        |           |             |
| **NativeSingle**      | **TaLib(...)nside [25]** | **10000** | **365.00 μs** |  **4.472 μs** |  **2.339 μs** |  **1.00** |    **0.01** |      **-** |  **39.14 KB** |        **1.00** |
| NativeParallel    | TaLib(...)nside [25] | 10000 | 251.52 μs |  9.792 μs |  5.121 μs |  0.69 |    0.01 |      - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib(...)nside [25] | 10000 | 394.43 μs |  7.944 μs |  4.155 μs |  1.08 |    0.01 | 3.9063 |  556.8 KB |       14.23 |
| BuilderLatestOnly | TaLib(...)nside [25] | 10000 | 389.48 μs | 28.778 μs | 19.035 μs |  1.07 |    0.05 |      - |   86.7 KB |        2.22 |
