```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)Crows [31]** | **1000**  | **100.70 μs** | **18.723 μs** | **12.384 μs** |      **-** |  **64.25 KB** |
| BuilderLatestOnly | TaLib(...)Crows [31] | 1000  |  89.96 μs |  2.079 μs |  1.237 μs |      - |  16.38 KB |
| **BuilderFull**       | **TaLib(...)Crows [31]** | **10000** | **393.67 μs** | **13.659 μs** |  **7.144 μs** | **3.9063** |  **556.8 KB** |
| BuilderLatestOnly | TaLib(...)Crows [31] | 10000 | 411.16 μs | 31.115 μs | 20.581 μs |      - |   86.7 KB |
