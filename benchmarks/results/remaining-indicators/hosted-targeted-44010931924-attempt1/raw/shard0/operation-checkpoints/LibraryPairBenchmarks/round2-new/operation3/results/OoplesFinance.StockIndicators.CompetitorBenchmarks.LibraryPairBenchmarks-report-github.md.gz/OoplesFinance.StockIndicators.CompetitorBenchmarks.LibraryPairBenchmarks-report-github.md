```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)River [30]** |  **67.56 μs** |  **9.072 μs** |  **5.398 μs** |  **1.01** |    **0.11** |  **68.63 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)River [30] |  66.92 μs | 24.838 μs | 16.429 μs |  1.00 |    0.25 |  19.58 KB |        0.29 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)River [30]** | **379.35 μs** | **10.989 μs** |  **5.747 μs** |  **1.00** |    **0.02** | **638.95 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)River [30] | 520.02 μs | 35.700 μs | 23.613 μs |  1.37 |    0.06 | 125.09 KB |        0.20 |
