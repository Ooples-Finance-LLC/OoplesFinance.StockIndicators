```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)gLine [26]** | **109.77 μs** | **15.406 μs** |  **9.168 μs** |  **1.01** |    **0.11** |  **68.29 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)gLine [26] |  50.76 μs |  0.613 μs |  0.320 μs |  0.47 |    0.04 |  19.91 KB |        0.29 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)gLine [26]** | **283.66 μs** | **26.215 μs** | **15.600 μs** |  **1.00** |    **0.07** | **638.58 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)gLine [26] | 485.54 μs | 13.975 μs |  7.309 μs |  1.72 |    0.09 | 125.05 KB |        0.20 |
