```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Crows [31]** |  **91.92 μs** | **26.017 μs** | **15.483 μs** |  **1.02** |    **0.22** |  **68.59 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Crows [31] |  68.46 μs |  8.506 μs |  5.626 μs |  0.76 |    0.12 |  19.58 KB |        0.29 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Crows [31]** | **383.38 μs** | **23.301 μs** | **13.866 μs** |  **1.00** |    **0.05** | **638.63 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Crows [31] | 472.22 μs | 22.531 μs | 13.408 μs |  1.23 |    0.05 | 123.13 KB |        0.19 |
