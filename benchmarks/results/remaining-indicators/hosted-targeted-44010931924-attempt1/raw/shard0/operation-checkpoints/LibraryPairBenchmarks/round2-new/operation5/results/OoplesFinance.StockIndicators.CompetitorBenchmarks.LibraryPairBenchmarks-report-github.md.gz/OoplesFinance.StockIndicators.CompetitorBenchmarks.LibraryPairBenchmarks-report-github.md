```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Cover [28]** |  **68.14 μs** | **17.297 μs** | **10.293 μs** |  **1.02** |    **0.20** |  **68.22 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Cover [28] |  33.77 μs |  0.983 μs |  0.585 μs |  0.50 |    0.07 |   19.3 KB |        0.28 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Cover [28]** | **275.31 μs** | **14.809 μs** |  **8.812 μs** |  **1.00** |    **0.04** | **638.59 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Cover [28] | 317.92 μs | 16.811 μs | 11.120 μs |  1.16 |    0.05 | 124.44 KB |        0.19 |
