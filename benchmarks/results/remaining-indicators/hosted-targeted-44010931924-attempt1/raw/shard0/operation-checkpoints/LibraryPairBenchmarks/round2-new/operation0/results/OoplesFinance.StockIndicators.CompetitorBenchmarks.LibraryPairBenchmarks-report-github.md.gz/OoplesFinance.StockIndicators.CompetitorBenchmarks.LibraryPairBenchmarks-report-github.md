```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error    | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|---------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nside [25]** |  **70.12 μs** | **11.28 μs** |  **6.713 μs** |  **1.01** |    **0.13** |  **68.63 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nside [25] |  71.49 μs | 15.20 μs | 10.054 μs |  1.03 |    0.17 |  19.63 KB |        0.29 |
|            |       |                      |           |          |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)nside [25]** | **407.20 μs** | **23.29 μs** | **13.862 μs** |  **1.00** |    **0.05** |    **639 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nside [25] | 563.00 μs | 28.97 μs | 19.162 μs |  1.38 |    0.06 | 124.06 KB |        0.19 |
