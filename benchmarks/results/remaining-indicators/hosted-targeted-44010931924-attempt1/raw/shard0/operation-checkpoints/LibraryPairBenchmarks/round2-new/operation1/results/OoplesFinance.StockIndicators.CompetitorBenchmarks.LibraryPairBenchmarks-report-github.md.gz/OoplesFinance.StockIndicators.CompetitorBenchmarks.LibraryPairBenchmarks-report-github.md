```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error      | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|-----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Crows [22]** |  **66.01 μs** |  **15.496 μs** |  **9.221 μs** |  **1.02** |    **0.18** |  **68.59 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Crows [22] |  32.57 μs |   0.629 μs |  0.374 μs |  0.50 |    0.06 |   19.3 KB |        0.28 |
|            |       |                      |           |            |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)Crows [22]** | **459.08 μs** | **145.508 μs** | **86.589 μs** |  **1.04** |    **0.28** | **638.91 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Crows [22] | 307.99 μs |   8.205 μs |  4.882 μs |  0.70 |    0.14 | 124.11 KB |        0.19 |
