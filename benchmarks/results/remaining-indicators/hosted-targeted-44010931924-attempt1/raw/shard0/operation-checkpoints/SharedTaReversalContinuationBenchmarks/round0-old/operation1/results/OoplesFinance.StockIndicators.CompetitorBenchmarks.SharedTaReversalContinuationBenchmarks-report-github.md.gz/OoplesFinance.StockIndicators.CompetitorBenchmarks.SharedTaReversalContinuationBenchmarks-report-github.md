```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean     | Error   | StdDev  | Gen0   | Allocated |
|------------------ |--------------- |------ |---------:|--------:|--------:|-------:|----------:|
| **BuilderFull**       | **DarkCloudCover** | **1000**  | **114.5 μs** | **3.94 μs** | **2.61 μs** |      **-** |  **63.48 KB** |
| BuilderLatestOnly | DarkCloudCover | 1000  | 110.4 μs | 1.95 μs | 1.29 μs |      - |  15.63 KB |
| **BuilderFull**       | **DarkCloudCover** | **10000** | **431.7 μs** | **8.09 μs** | **4.23 μs** | **3.9063** | **556.03 KB** |
| BuilderLatestOnly | DarkCloudCover | 10000 | 404.5 μs | 6.30 μs | 3.29 μs |      - |  85.97 KB |
