```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation    | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0   | Gen1   | Allocated | Alloc Ratio |
|------------------ |------------- |------ |----------:|----------:|----------:|------:|--------:|-------:|-------:|----------:|------------:|
| **BuilderFull**       | **PiercingLine** | **1000**  |  **81.91 μs** |  **6.989 μs** |  **4.159 μs** |  **2.45** |    **0.12** |      **-** |      **-** |   **63.5 KB** |       **15.99** |
| BuilderLatestOnly | PiercingLine | 1000  |  80.92 μs |  8.610 μs |  5.695 μs |  2.42 |    0.16 |      - |      - |  15.63 KB |        3.94 |
| NativeSingle      | PiercingLine | 1000  |  33.38 μs |  0.341 μs |  0.203 μs |  1.00 |    0.01 |      - |      - |   3.97 KB |        1.00 |
| NativeParallel    | PiercingLine | 1000  |  76.22 μs |  5.518 μs |  3.650 μs |  2.28 |    0.11 |      - |      - |   8.39 KB |        2.11 |
|                   |              |       |           |           |           |       |         |        |        |           |             |
| **BuilderFull**       | **PiercingLine** | **10000** | **305.22 μs** | **28.841 μs** | **19.076 μs** |  **0.70** |    **0.04** | **5.8594** | **1.9531** | **556.04 KB** |       **14.20** |
| BuilderLatestOnly | PiercingLine | 10000 | 283.27 μs | 30.892 μs | 20.433 μs |  0.65 |    0.04 |      - |      - |  85.95 KB |        2.20 |
| NativeSingle      | PiercingLine | 10000 | 435.40 μs |  2.334 μs |  1.221 μs |  1.00 |    0.00 |      - |      - |  39.15 KB |        1.00 |
| NativeParallel    | PiercingLine | 10000 | 287.91 μs | 31.415 μs | 20.779 μs |  0.66 |    0.05 |      - |      - |  78.72 KB |        2.01 |
