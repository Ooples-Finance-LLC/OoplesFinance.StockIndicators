```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation    | Count | Mean      | Error     | StdDev    | Gen0   | Gen1   | Allocated |
|------------------ |------------- |------ |----------:|----------:|----------:|-------:|-------:|----------:|
| **BuilderFull**       | **PiercingLine** | **1000**  |  **85.81 μs** | **15.179 μs** | **10.040 μs** |      **-** |      **-** |   **63.5 KB** |
| BuilderLatestOnly | PiercingLine | 1000  |  78.23 μs |  5.778 μs |  3.822 μs |      - |      - |  15.62 KB |
| **BuilderFull**       | **PiercingLine** | **10000** | **301.89 μs** | **20.240 μs** | **13.388 μs** | **5.8594** | **1.9531** | **556.02 KB** |
| BuilderLatestOnly | PiercingLine | 10000 | 268.78 μs | 11.218 μs |  5.867 μs |      - |      - |  85.95 KB |
