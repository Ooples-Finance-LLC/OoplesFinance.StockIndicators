```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation    | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |------------- |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **PiercingLine** | **1000**  |  **87.15 μs** |  **1.888 μs** |  **1.123 μs** |      **-** |   **63.5 KB** |
| BuilderLatestOnly | PiercingLine | 1000  |  83.47 μs |  1.067 μs |  0.558 μs |      - |  15.63 KB |
| **BuilderFull**       | **PiercingLine** | **10000** | **412.90 μs** | **32.146 μs** | **21.263 μs** | **3.9063** | **556.05 KB** |
| BuilderLatestOnly | PiercingLine | 10000 | 387.28 μs | 31.517 μs | 20.846 μs |      - |  85.95 KB |
