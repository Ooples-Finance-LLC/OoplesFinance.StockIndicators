```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Gen0   | Gen1   | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|-------:|-------:|----------:|
| **BuilderFull**       | **DarkCloudCover** | **1000**  |  **81.13 μs** |  **3.620 μs** |  **1.893 μs** |      **-** |      **-** |  **63.51 KB** |
| BuilderLatestOnly | DarkCloudCover | 1000  |  76.60 μs |  2.401 μs |  1.256 μs |      - |      - |  15.63 KB |
| **BuilderFull**       | **DarkCloudCover** | **10000** | **296.86 μs** | **25.352 μs** | **16.769 μs** | **5.8594** | **1.9531** | **556.04 KB** |
| BuilderLatestOnly | DarkCloudCover | 10000 | 277.13 μs | 24.226 μs | 16.024 μs |      - |      - |  85.95 KB |
