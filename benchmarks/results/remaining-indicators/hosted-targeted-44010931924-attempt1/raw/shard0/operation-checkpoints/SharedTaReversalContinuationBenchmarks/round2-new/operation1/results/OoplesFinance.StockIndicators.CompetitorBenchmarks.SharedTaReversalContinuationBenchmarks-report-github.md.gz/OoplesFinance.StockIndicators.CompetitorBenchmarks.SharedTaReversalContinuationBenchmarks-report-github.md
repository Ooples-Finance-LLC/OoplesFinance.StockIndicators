```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0   | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------- |------ |----------:|----------:|----------:|------:|--------:|-------:|-------:|----------:|------------:|
| **BuilderFull**       | **DarkCloudCover** | **1000**  |  **94.61 μs** | **16.345 μs** | **10.811 μs** |  **5.14** |    **0.56** |      **-** |      **-** |  **63.51 KB** |       **16.00** |
| BuilderLatestOnly | DarkCloudCover | 1000  |  78.66 μs |  3.789 μs |  2.255 μs |  4.27 |    0.12 |      - |      - |  15.63 KB |        3.94 |
| NativeSingle      | DarkCloudCover | 1000  |  18.40 μs |  0.259 μs |  0.136 μs |  1.00 |    0.01 |      - |      - |   3.97 KB |        1.00 |
| NativeParallel    | DarkCloudCover | 1000  |  90.25 μs |  2.655 μs |  1.756 μs |  4.90 |    0.10 |      - |      - |   8.39 KB |        2.11 |
|                   |                |       |           |           |           |       |         |        |        |           |             |
| **BuilderFull**       | **DarkCloudCover** | **10000** | **331.50 μs** | **22.654 μs** | **14.984 μs** |  **1.21** |    **0.05** | **5.8594** | **1.9531** | **556.04 KB** |       **14.21** |
| BuilderLatestOnly | DarkCloudCover | 10000 | 304.20 μs | 20.745 μs | 12.345 μs |  1.11 |    0.04 |      - |      - |  85.95 KB |        2.20 |
| NativeSingle      | DarkCloudCover | 10000 | 275.03 μs |  1.955 μs |  1.293 μs |  1.00 |    0.01 |      - |      - |  39.14 KB |        1.00 |
| NativeParallel    | DarkCloudCover | 10000 | 211.72 μs |  3.597 μs |  1.881 μs |  0.77 |    0.01 |      - |      - |  78.72 KB |        2.01 |
