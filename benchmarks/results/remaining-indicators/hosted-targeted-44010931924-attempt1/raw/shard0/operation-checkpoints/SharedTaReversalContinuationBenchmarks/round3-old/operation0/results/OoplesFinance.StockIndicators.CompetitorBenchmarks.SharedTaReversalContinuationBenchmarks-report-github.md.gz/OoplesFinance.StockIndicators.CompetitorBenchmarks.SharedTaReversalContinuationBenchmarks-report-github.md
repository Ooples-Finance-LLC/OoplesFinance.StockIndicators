```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation    | Count | Mean      | Error     | StdDev    | Gen0   | Allocated |
|------------------ |------------- |------ |----------:|----------:|----------:|-------:|----------:|
| **BuilderFull**       | **PiercingLine** | **1000**  |  **97.28 μs** | **20.897 μs** | **13.822 μs** |      **-** |   **63.5 KB** |
| BuilderLatestOnly | PiercingLine | 1000  |  85.43 μs |  2.895 μs |  1.514 μs |      - |  15.63 KB |
| **BuilderFull**       | **PiercingLine** | **10000** | **402.96 μs** |  **8.967 μs** |  **4.690 μs** | **3.9063** | **556.05 KB** |
| BuilderLatestOnly | PiercingLine | 10000 | 393.74 μs | 24.391 μs | 12.757 μs |      - |  85.96 KB |
