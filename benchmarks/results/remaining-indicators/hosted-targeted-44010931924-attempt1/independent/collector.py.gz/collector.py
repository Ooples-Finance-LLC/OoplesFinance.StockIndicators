"""Collect the pinned six-candle qualification; preserve accepted and rejected evidence."""
import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import zipfile

OPS = Path(r'C:\Users\cheat\source\stock-indicators-operations')
BASELINE = OPS/'active-performance-evidence/hosted-runs/43880487485/inputs'
ARCHIVES = Path(r'Z:\StockIndicators-Archives\hosted-runs-20261116')
NETWORK_OUTPUTS = Path(r'Z:\StockIndicators-Archives\active-performance-evidence\hosted-runs')
REMOTE = 'Ooples-Finance-LLC/OoplesFinance.StockIndicators'
PLAN = 'benchmarks/plans/hosted-candle-predicate-order-20261116.json'
APPROVED_RUN = '44010931924'
APPROVED_HEAD = '938ab3b76e9552c4460e939d6cb968051291150a'
PLAN_SHA = '94260ecdb3cdc59b41d244f5912e68270e3553487a3453584a3960402d119172'
CANDIDATE = Path(r'C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-candle-predicate-order-combined-20261116')
CPU_MANIFEST = OPS/'active-performance-evidence/candle-predicate-order-20261116/correctness/ci-manifest.json'
SOURCE = 'caefc553fd01ec4ad1def3d18f205e46f32cf1cd'
QUALIFIED_HEAD = 'f63b014560a4978b7b47755fcd73f5d39c531e12'
CPU_MANIFEST_SHA = '9a211abdc551bfa6f0b900ef17e5f305ea417d8546f9f3ba2ec8d9c643391156'
CPU_PRODUCER = '2a1737f30e5e1164189d0209b39ea46bf38c1239'
CPU_RUN = '44005551788'
OLD_CANDIDATE = Path(r'C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-matchinglow-only-20261116')
OLD_CPU_MANIFEST = Path(r'Z:\StockIndicators-Archives\active-operations\matchinglow-only-20261116\correctness\ci-manifest.json')
OLD_SOURCE = 'a1f0028c601e1c6e7be5eabfe0d5da5cfe1f0758'
OLD_QUALIFIED_HEAD = 'a921574e878c82392a6ce26122f5f2adaa2f430e'
OLD_CPU_RUN = '43984038209'
OLD_CPU_MANIFEST_SHA = 'f2541e7d0621187f35160c9fcd94627f7fc70169bd185a5a6bc73cae594c1508'
OLD_CORE = '4d571648599e567bb6df0cda1f823d79e95712241078c2ab1721cf7409c10173'
NEW_CORE = '8bac548a15cf862067fffcaab85b0abbabadd2964948ceb0d160db29c3f85f52'
BASE_PROVENANCE = '92977e9786050146dbe97748c8a28d59e8eb47be5f4b5f85ae064ec4fcacef3a'

TEXT = {'.json', '.log', '.txt', '.csv', '.md', '.html', '.xml', '.trx', '.gz', '.py', '.ps1', '.cs', '.asm', '.patch'}
RESERVED = {'CON', 'PRN', 'AUX', 'NUL', 'CONIN$', 'CONOUT$',
    *(f'COM{i}' for i in range(1, 10)), *(f'LPT{i}' for i in range(1, 10)),
    *(p+n for p in ('COM', 'LPT') for n in ('\u00b9', '\u00b2', '\u00b3'))}


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, data):
    path=Path(path); temporary=path.with_name(path.name+'.new')
    with temporary.open('xb') as stream:
        stream.write((json.dumps(data,indent=2,allow_nan=False)+'\n').encode());stream.flush();os.fsync(stream.fileno())
    temporary.replace(path)


def members(package):
    result, aliases = {}, set()
    for info in package.infolist():
        assert info.orig_filename == info.filename, 'ZIP member spelling was normalized'
        name = info.filename.rstrip('/')
        parts = PurePosixPath(name)
        assert name and not parts.is_absolute() and '\\' not in name and '\0' not in name
        assert all(p not in ('', '.', '..') and p.rstrip(' .') == p
            and not any(c in p for c in ':<>"|?*') and p.split('.')[0].rstrip(' ').upper() not in RESERVED
            for p in name.split('/')), name
        assert not stat.S_ISLNK(info.external_attr >> 16), 'ZIP symlink'
        if info.is_dir():
            continue
        assert name.casefold() not in aliases, 'Duplicate/case-aliased ZIP member'
        aliases.add(name.casefold()); result[name] = info
    return result


def target(folder, name):
    path = (folder/name).resolve()
    assert path.is_relative_to(folder.resolve()) and path != folder.resolve()
    return path


def manifest(folder):
    return {p.relative_to(folder).as_posix(): digest(p) for p in folder.rglob('*') if p.is_file()}


def runtime_files(proof):
    return {'common/'+p: sha for p, sha in proof['common_manifest'].items()} | {
        'production/'+label+'.dll': sha for label, sha in proof['production_sha256'].items()}


def protected_snapshot(baseline):
    return {section+'/'+name: sha for section in ('common', 'production')
            for name, sha in manifest(baseline/section).items()}


def reserve(path, added_bytes=0):
    existing = path
    while not existing.exists():
        assert existing.parent != existing, 'Output drive/root unavailable'
        existing = existing.parent
    assert shutil.disk_usage(existing).free > 2*1024**3 + added_bytes, 'Below output-drive evidence reserve'


def same_volume(source, destination):
    return source.resolve().drive.casefold() == destination.resolve().drive.casefold()


def link_verified(source, destination, sha):
    assert source.is_file() and digest(source)==sha
    assert same_volume(source,destination), 'Runtime must be fresh C hardlinks'
    assert not destination.exists(), 'Never overwrite a runtime target'
    destination.parent.mkdir(parents=True,exist_ok=True)
    os.link(source,destination)
    assert digest(destination)==sha
    return 'hardlink'


def extract_text(package, entries, names, folder):
    records = []
    for name in sorted(names):
        assert Path(name).suffix.lower() in TEXT, 'Unexpected non-text/evidence member: '+name
        path = target(folder, name)
        assert not path.exists()
        path.parent.mkdir(parents=True, exist_ok=True)
        reserve(folder, entries[name].file_size)
        with package.open(entries[name]) as source, path.open('xb') as out:
            shutil.copyfileobj(source, out, 1024*1024)
        records.append(dict(path=name, sha256=digest(path), bytes=path.stat().st_size))
    return records



def checked_sources(baseline,candidate,cpu,old_candidate,old_cpu):
    original=json.loads((baseline/'provenance.json').read_text())
    baseline_before=protected_snapshot(baseline)
    assert baseline_before==runtime_files(original)
    by_sha={}
    for name,sha in baseline_before.items():by_sha.setdefault(sha,baseline/name)
    snapshots=[]
    for folder,manifest,source,run in [(candidate,cpu,SOURCE,CPU_RUN),(old_candidate,old_cpu,OLD_SOURCE,OLD_CPU_RUN)]:
        assert manifest['source']==source and manifest['run_id']==run
        assert manifest['workflow_head']==CPU_PRODUCER
        before={}
        for name,sha in manifest['runtime_files'].items():
            path=target(folder,name)
            assert digest(path)==sha, 'Installed CI runtime changed: '+name
            before[name]=sha;by_sha.setdefault(sha,path)
        snapshots.append(before)
    return original,baseline_before,snapshots[0],snapshots[1],by_sha


def archived_snapshots(package,entries,proof,by_sha):
    snapshots={}
    for label,production_label in [('old','old'),('new','successor')]:
        prefix='predicate-qualification/evidence/shard0-runtime-'+label+'/'
        expected=dict(proof['common_manifest'])
        expected['OoplesFinance.StockIndicators.dll']=proof['production_sha256'][production_label]
        actual={n[len(prefix):] for n in entries if n.startswith(prefix)}
        assert actual==set(expected), 'Unexpected/missing archived runtime snapshot: '+label
        for name,sha in expected.items():
            assert sha in by_sha and re.fullmatch('[a-f0-9]{64}',sha)
            with package.open(entries[prefix+name]) as stream:
                assert hashlib.file_digest(stream,'sha256').hexdigest()==sha,prefix+name
        snapshots[label]=dict(prefix=prefix,files=expected,retention='Authenticated full bytes retained in raw ZIP only; not materialized')
    return snapshots


def reconstruct(archive,out,baseline,candidate,cpu,old_candidate,old_cpu):
    original,before,candidate_before,old_before,by_sha=checked_sources(baseline,candidate,cpu,old_candidate,old_cpu)
    with zipfile.ZipFile(archive) as package:
        entries=members(package)
        assert 'predicate-inputs/provenance.json' in entries
        assert 'predicate-qualification/summary.json' in entries
        assert all(n.startswith(('predicate-inputs/','predicate-qualification/evidence/shard0/',
            'predicate-qualification/evidence/shard0-runtime-old/',
            'predicate-qualification/evidence/shard0-runtime-new/'))
            or n=='predicate-qualification/summary.json' for n in entries)
        proof=json.loads(package.read(entries['predicate-inputs/provenance.json']))
        assert len(proof['common_manifest'])==94 and proof['common_manifest']==original['common_manifest']
        assert proof['production_sha256']['old']==OLD_CORE and proof['production_sha256']['successor']==NEW_CORE
        assert proof['production_sha256']['variants']==original['production_sha256']['variants']
        snapshots=archived_snapshots(package,entries,proof,by_sha)
        snapshot_names={row['prefix']+n for row in snapshots.values() for n in row['files']}
        expected={'predicate-inputs/'+n:sha for n,sha in runtime_files(proof).items()}
        expected['predicate-inputs/baseline-authentication/common/OoplesFinance.StockIndicators.CompetitorBenchmarks.dll']=original['common_manifest']['OoplesFinance.StockIndicators.CompetitorBenchmarks.dll']
        for n in entries:
            if n.startswith(('predicate-inputs/candidate-authentication/blobs/',
                'predicate-inputs/old-candidate-authentication/blobs/')):
                sha=n.rsplit('/',1)[1];assert re.fullmatch('[a-f0-9]{64}',sha)
                expected[n]=sha
        assert all(any('/'+name+'/blobs/' in n for n in expected) for name in ('candidate-authentication','old-candidate-authentication'))
        # Authenticate ALL archived runtime/blob bytes before creating any destination.
        for name,sha in expected.items():
            assert name in entries and re.fullmatch('[a-f0-9]{64}',sha)
            with package.open(entries[name]) as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==sha,name
            assert sha in by_sha, 'No verified local source for '+name
        assert not out.exists();out.mkdir(parents=True)
        records=extract_text(package,entries,set(entries)-set(expected)-snapshot_names,out)
        for name,sha in expected.items():link_verified(by_sha[sha],target(out,name),sha)
        assert all(digest(out/name)==sha for name,sha in expected.items())
    assert protected_snapshot(baseline)==before
    assert all(digest(candidate/name)==sha for name,sha in candidate_before.items())
    assert all(digest(old_candidate/name)==sha for name,sha in old_before.items())
    return before,candidate_before,old_before,records,snapshots


def verify_tooling(repo):
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==APPROVED_HEAD
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
    raw=subprocess.check_output(['git','show',APPROVED_HEAD+':'+PLAN],cwd=repo)
    assert (repo/PLAN).read_bytes()==raw and digest(repo/PLAN)==PLAN_SHA


def check_summary(result,hosted):
    # Compare the exact JSON representation written by the frozen CI producer.
    result=json.loads(json.dumps(result,allow_nan=False))
    assert result==hosted, 'Independent collection differs from hosted summary'
    assert (result['case_count'],result['decision_count'])==(180,36)
    assert all(type(result[key]) is bool for key in ('accepted','source_gate_accepted','native_progress_gate_passed'))
    assert result['accepted']==(result['source_gate_accepted'] and result['native_progress_gate_passed'])
    assert result['native_progress_gate']['passed'] is result['native_progress_gate_passed']
    assert result.get('production_integrated',False) is False and result.get('report_imported',False) is False
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args();repo=args.repo.resolve();out=args.out.resolve()
    assert out!=OPS.resolve() and out.is_relative_to(OPS.resolve())
    assert not out.exists() and not out.is_relative_to(BASELINE.resolve())
    assert not repo.is_relative_to(out) and not CANDIDATE.resolve().is_relative_to(out) and not OLD_CANDIDATE.resolve().is_relative_to(out)
    verify_tooling(repo)
    plan=json.loads((repo/PLAN).read_text());assert (plan['cases'],plan['decisions'])==(180,36)
    def api(path):return json.loads(subprocess.check_output(['gh','api','repos/'+REMOTE+path]))
    run=api('/actions/runs/'+APPROVED_RUN)
    assert run['id']==int(APPROVED_RUN) and run['head_sha']==APPROVED_HEAD
    assert (run['status'],run['conclusion'])==('completed','success')
    artifacts=[];page=1
    while True:
        response=api(f'/actions/runs/{APPROVED_RUN}/artifacts?per_page=100&page={page}')
        artifacts+=response['artifacts']
        if len(artifacts)>=response['total_count']:break
        assert response['artifacts'];page+=1
    matches=[a for a in artifacts if a['name']=='candle-predicate-qualification' and not a['expired']]
    assert len(matches)==1;item=matches[0]
    assert ARCHIVES.is_dir()
    archive_root=(ARCHIVES/APPROVED_RUN).resolve();assert archive_root.is_relative_to(ARCHIVES.resolve())
    archive_root.mkdir(parents=True,exist_ok=True)
    archive=archive_root/f"candle-predicate-qualification-attempt{run['run_attempt']}-artifact{item['id']}.zip"
    sidecar=archive.with_suffix('.receipt.json')
    if archive.exists():
        receipt=json.loads(sidecar.read_text())
        assert receipt['run_id']==APPROVED_RUN and receipt['artifact']['id']==item['id']
        assert receipt['archive_sha256']==digest(archive)
    else:
        temporary=archive.with_suffix('.zip.download')
        with temporary.open('xb') as stream:
            subprocess.run(['gh','api',f"repos/{REMOTE}/actions/artifacts/{item['id']}/zip"],stdout=stream,check=True)
            stream.flush();os.fsync(stream.fileno())
        temporary.replace(archive)
    sha=digest(archive)
    if item.get('digest'):assert item['digest']=='sha256:'+sha
    receipt=dict(run_id=APPROVED_RUN,run_attempt=run['run_attempt'],tooling_head=APPROVED_HEAD,
        plan_sha256=PLAN_SHA,artifact=item,archive=str(archive),archive_sha256=sha)
    write(sidecar,receipt)
    reserve(out)
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=CANDIDATE,text=True).strip()==QUALIFIED_HEAD
    assert not subprocess.check_output(['git','diff','--name-only',SOURCE,QUALIFIED_HEAD,'--','src','tests',
        'benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks',
        'benchmarks/OoplesFinance.StockIndicators.CompetitorTests'],cwd=CANDIDATE)
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=OLD_CANDIDATE,text=True).strip()==OLD_QUALIFIED_HEAD
    assert not subprocess.check_output(['git','diff','--name-only',OLD_SOURCE,OLD_QUALIFIED_HEAD,'--','src','tests',
        'benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks',
        'benchmarks/OoplesFinance.StockIndicators.CompetitorTests'],cwd=OLD_CANDIDATE)
    assert digest(BASELINE/'provenance.json')==BASE_PROVENANCE
    assert digest(CPU_MANIFEST)==CPU_MANIFEST_SHA and digest(OLD_CPU_MANIFEST)==OLD_CPU_MANIFEST_SHA
    cpu=json.loads(CPU_MANIFEST.read_text());old_cpu=json.loads(OLD_CPU_MANIFEST.read_text())
    before,candidate_before,old_before,selected,snapshots=reconstruct(archive,out,BASELINE,CANDIDATE,cpu,OLD_CANDIDATE,old_cpu)
    os.environ['HOSTED_TIMING_PLAN']=str(repo/PLAN);sys.path.insert(0,str(repo/'scripts'))
    p=importlib.import_module('hosted_timing.pipeline')
    q=importlib.import_module('hosted_timing.candle_predicate_qualification')
    assert p.REPO.resolve()==repo and p.PLAN.resolve()==(repo/PLAN).resolve()
    q.validate_scope(p.read(p.PLAN))
    inputs=out/'predicate-inputs';evidence=out/'predicate-qualification/evidence'
    proof=p.verify_inputs(inputs)
    assert proof['run_id']==APPROVED_RUN and proof['workflow_head']==APPROVED_HEAD and proof['plan_sha256']==PLAN_SHA
    result=check_summary(q.collect(evidence,inputs),p.read(out/'predicate-qualification/summary.json'))
    assert protected_snapshot(BASELINE)==before
    assert all(digest(CANDIDATE/name)==sha for name,sha in candidate_before.items())
    assert all(digest(OLD_CANDIDATE/name)==sha for name,sha in old_before.items())
    assert digest(BASELINE/'provenance.json')==BASE_PROVENANCE
    assert digest(CPU_MANIFEST)==CPU_MANIFEST_SHA and digest(OLD_CPU_MANIFEST)==OLD_CPU_MANIFEST_SHA
    verify_tooling(repo)
    write(out/'independently-collected.json',result)
    write(out/'collection-receipt.json',dict(status='verified',run_id=APPROVED_RUN,tooling_head=APPROVED_HEAD,
        plan_sha256=PLAN_SHA,collector_sha256=digest(Path(__file__)),artifact=receipt,selected_files=selected,
        local_hosted_collection_equal=True,protected_baseline_unchanged=True,protected_candidate_unchanged=True,
        protected_old_candidate_unchanged=True,old_cpu_manifest_sha256=OLD_CPU_MANIFEST_SHA,new_cpu_manifest_sha256=CPU_MANIFEST_SHA,
        runtime_materialization='Fresh verified C hardlinks; every archived runtime byte hashed first',
        archived_runtime_snapshots=snapshots,
        cases=180,decisions=36,accepted=result['accepted'],source_gate_accepted=result['source_gate_accepted'],
        native_progress_gate_passed=result['native_progress_gate_passed'],
        report_imported=False,source_imported=False,policy_changed=False))
    print(json.dumps(dict(run=APPROVED_RUN,cases=180,decisions=36,accepted=result['accepted'],source_gate_accepted=result['source_gate_accepted'],
        native_progress_gate_passed=result['native_progress_gate_passed'])),flush=True)


if __name__=='__main__':main()
