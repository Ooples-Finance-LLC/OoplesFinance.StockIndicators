```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------- |-----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetCci** | **1,945.5 μs** | **45.43 μs** | **23.76 μs** |  **1.00** |    **0.02** | **106.46 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetCci |   380.1 μs | 26.98 μs | 17.84 μs |  0.20 |    0.01 | 177.77 KB |        1.67 |
|            |       |                |            |          |          |       |         |           |             |
| **Ooples**     | **10000** | **Skender.GetCci** | **2,777.7 μs** | **59.24 μs** | **35.25 μs** |  **1.00** |    **0.02** | **1037.8 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetCci | 1,050.7 μs | 27.70 μs | 16.48 μs |  0.38 |    0.01 | 1698.6 KB |        1.64 |
