```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skend(...)oints [22]** |   **863.3 μs** |  **35.97 μs** |  **23.79 μs** |  **1.00** |    **0.04** |  **233.86 KB** |        **1.00** |
|        |       |                      |            |           |           |       |         |            |             |
| **Ooples** | **10000** | **Skend(...)oints [22]** | **2,306.4 μs** | **393.00 μs** | **259.94 μs** |  **1.01** |    **0.15** | **2312.98 KB** |        **1.00** |
