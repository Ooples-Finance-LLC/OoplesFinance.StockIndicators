```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId          | Mean       | Error       | StdDev      | Median     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |-----------:|------------:|------------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetMacd** | **5,004.4 μs** |    **56.43 μs** |    **33.58 μs** | **5,000.0 μs** |  **1.00** |    **0.01** |  **331.73 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetMacd |   944.5 μs |    41.06 μs |    24.43 μs |   949.8 μs |  0.19 |    0.00 |  457.02 KB |        1.38 |
|            |       |                 |            |             |             |            |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetMacd** | **9,184.3 μs** | **9,715.35 μs** | **5,081.31 μs** | **6,828.3 μs** |  **1.16** |    **0.70** |  **3266.7 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetMacd | 1,508.0 μs |    89.11 μs |    58.94 μs | 1,505.8 μs |  0.19 |    0.05 | 4672.46 KB |        1.43 |
