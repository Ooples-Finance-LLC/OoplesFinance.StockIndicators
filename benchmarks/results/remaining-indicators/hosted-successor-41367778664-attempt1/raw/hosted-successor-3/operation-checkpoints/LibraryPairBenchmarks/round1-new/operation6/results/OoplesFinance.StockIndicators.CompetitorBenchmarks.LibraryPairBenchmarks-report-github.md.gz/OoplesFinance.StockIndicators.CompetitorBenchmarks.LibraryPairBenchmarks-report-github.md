```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId          | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |---------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetMacd** |  **5.027 ms** | **0.0624 ms** | **0.0371 ms** |  **1.00** |    **0.01** |  **331.73 KB** |        **1.00** |
|        |       |                 |           |           |           |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetMacd** | **42.750 ms** | **1.5515 ms** | **0.8115 ms** |  **1.00** |    **0.02** | **3267.07 KB** |        **1.00** |
