```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId              | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetElderRay** | **1,384.3 μs** |  **48.54 μs** |  **28.89 μs** |  **1.00** |    **0.03** |  **186.91 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetElderRay |   811.8 μs |  28.24 μs |  16.81 μs |  0.59 |    0.02 |  341.27 KB |        1.83 |
|            |       |                     |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetElderRay** | **8,301.9 μs** | **288.05 μs** | **171.41 μs** |  **1.00** |    **0.03** | **1838.66 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetElderRay | 2,376.4 μs |  56.72 μs |  33.75 μs |  0.29 |    0.01 | 3320.71 KB |        1.81 |
