```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)elier [21]** |  **1,835.5 μs** | **77.06 μs** | **40.30 μs** |  **1.00** |    **0.03** |  **145.82 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)elier [21] |    489.3 μs | 33.26 μs | 22.00 μs |  0.27 |    0.01 |  255.65 KB |        1.75 |
|            |       |                      |             |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)elier [21]** | **13,652.4 μs** | **82.38 μs** | **43.09 μs** |  **1.00** |    **0.00** | **1428.72 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)elier [21] |  3,113.8 μs | 78.20 μs | 40.90 μs |  0.23 |    0.00 | 2479.94 KB |        1.74 |
