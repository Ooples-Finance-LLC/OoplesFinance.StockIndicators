```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId             | Mean     | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |---------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetKeltner** | **2.650 ms** | **0.0432 ms** | **0.0257 ms** |  **1.00** |  **267.66 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetKeltner | 1.079 ms | 0.0659 ms | 0.0392 ms |  0.41 |  475.82 KB |        1.78 |
|            |       |                    |          |           |           |       |            |             |
| **Ooples**     | **10000** | **Skender.GetKeltner** | **4.314 ms** | **0.0487 ms** | **0.0322 ms** |  **1.00** | **2631.28 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetKeltner | 2.112 ms | 0.0481 ms | 0.0252 ms |  0.49 | 4659.74 KB |        1.77 |
