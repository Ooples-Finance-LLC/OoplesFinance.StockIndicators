```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId          | Mean      | Error      | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |---------------- |----------:|-----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetMacd** |  **5.498 ms** |  **0.0523 ms** | **0.0274 ms** |  **1.00** |    **0.01** |  **331.73 KB** |        **1.00** |
|        |       |                 |           |            |           |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetMacd** | **49.019 ms** | **13.5981 ms** | **8.9943 ms** |  **1.05** |    **0.37** | **3266.65 KB** |        **1.00** |
