```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)inOsc [21]** | **6,041.6 μs** |    **71.04 μs** |    **42.27 μs** |  **1.00** |    **0.01** |  **259.71 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)inOsc [21] |   867.3 μs |    54.01 μs |    32.14 μs |  0.14 |    0.01 |  495.14 KB |        1.91 |
|            |       |                      |            |             |             |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)inOsc [21]** | **9,042.7 μs** | **4,389.60 μs** | **2,612.18 μs** |  **1.07** |    **0.40** | **2553.35 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)inOsc [21] | 1,944.3 μs |   173.92 μs |    90.97 μs |  0.23 |    0.06 | 4854.52 KB |        1.90 |
