```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Cci** | **1000**  |   **232.83 μs** |   **4.463 μs** |   **2.656 μs** |  **7.60** |    **0.08** |       **-** |       **-** |  **66.79 KB** |        **8.64** |
| BuilderLatestOnly | TaLib.Functions.Cci | 1000  |   238.54 μs |  26.707 μs |  17.665 μs |  7.79 |    0.55 |       - |       - |  19.13 KB |        2.48 |
| NativeSingle      | TaLib.Functions.Cci | 1000  |    30.62 μs |   0.105 μs |   0.062 μs |  1.00 |    0.00 |  0.2441 |       - |   7.73 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Cci | 1000  |    18.15 μs |   1.139 μs |   0.753 μs |  0.59 |    0.02 |  0.4883 |       - |   8.02 KB |        1.04 |
|                   |                     |       |             |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Cci** | **10000** | **2,191.61 μs** | **243.218 μs** | **160.873 μs** |  **7.12** |    **0.50** | **31.2500** | **15.6250** | **629.71 KB** |        **8.07** |
| BuilderLatestOnly | TaLib.Functions.Cci | 10000 | 2,055.34 μs |  25.941 μs |  13.568 μs |  6.68 |    0.05 |       - |       - | 159.88 KB |        2.05 |
| NativeSingle      | TaLib.Functions.Cci | 10000 |   307.67 μs |   2.052 μs |   1.073 μs |  1.00 |    0.00 |  3.9063 |       - |  78.05 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Cci | 10000 |   186.52 μs |   7.403 μs |   4.896 μs |  0.61 |    0.02 |  3.9063 |       - |  78.34 KB |        1.00 |
