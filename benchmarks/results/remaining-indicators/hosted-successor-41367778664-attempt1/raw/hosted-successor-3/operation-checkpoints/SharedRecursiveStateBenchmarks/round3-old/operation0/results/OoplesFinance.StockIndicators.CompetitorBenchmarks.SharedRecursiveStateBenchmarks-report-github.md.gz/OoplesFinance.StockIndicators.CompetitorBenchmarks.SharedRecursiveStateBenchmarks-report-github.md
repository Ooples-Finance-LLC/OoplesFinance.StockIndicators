```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error    | StdDev  | Gen0    | Gen1   | Allocated |
|------------------ |---------- |------ |-----------:|---------:|--------:|--------:|-------:|----------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **132.6 μs** |  **5.11 μs** | **3.04 μs** |  **3.9063** |      **-** |  **64.84 KB** |
| BuilderLatestOnly | Ad        | 1000  |   129.7 μs |  0.69 μs | 0.36 μs |  0.9766 |      - |  17.27 KB |
| **BuilderFull**       | **Ad**        | **10000** | **1,214.0 μs** | **11.16 μs** | **6.64 μs** | **31.2500** | **7.8125** | **627.75 KB** |
| BuilderLatestOnly | Ad        | 10000 | 1,223.0 μs |  6.93 μs | 4.12 μs |  7.8125 |      - | 157.96 KB |
