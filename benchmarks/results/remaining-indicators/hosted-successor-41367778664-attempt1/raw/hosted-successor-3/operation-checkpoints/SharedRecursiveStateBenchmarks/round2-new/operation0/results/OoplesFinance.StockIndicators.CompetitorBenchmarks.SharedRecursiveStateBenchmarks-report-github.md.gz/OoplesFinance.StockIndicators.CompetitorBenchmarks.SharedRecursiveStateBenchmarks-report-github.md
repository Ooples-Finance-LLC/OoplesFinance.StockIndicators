```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean         | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |-------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **137.023 μs** | **3.2368 μs** | **1.9261 μs** | **56.36** |    **0.79** |  **3.9063** |      **-** |  **64.88 KB** |        **8.24** |
| BuilderLatestOnly | Ad        | 1000  |   137.042 μs | 0.9250 μs | 0.4838 μs | 56.37 |    0.30 |  0.9766 |      - |  17.27 KB |        2.19 |
| NativeSingle      | Ad        | 1000  |     2.431 μs | 0.0203 μs | 0.0106 μs |  1.00 |    0.01 |  0.4730 |      - |   7.88 KB |        1.00 |
| NativeParallel    | Ad        | 1000  |     5.765 μs | 0.5193 μs | 0.3435 μs |  2.37 |    0.14 |  0.4883 |      - |   8.16 KB |        1.04 |
|                   |           |       |              |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **Ad**        | **10000** | **1,233.849 μs** | **8.7977 μs** | **5.2354 μs** | **57.78** |    **0.30** | **31.2500** | **7.8125** | **627.79 KB** |        **8.03** |
| BuilderLatestOnly | Ad        | 10000 | 1,306.497 μs | 5.1591 μs | 3.0701 μs | 61.18 |    0.24 |  7.8125 |      - | 157.96 KB |        2.02 |
| NativeSingle      | Ad        | 10000 |    21.355 μs | 0.1111 μs | 0.0735 μs |  1.00 |    0.00 |  4.7607 | 0.8545 |  78.19 KB |        1.00 |
| NativeParallel    | Ad        | 10000 |    45.160 μs | 6.8822 μs | 4.5521 μs |  2.11 |    0.20 |  4.3945 | 0.4883 |  78.48 KB |        1.00 |
