```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **929.12 μs** | **31.064 μs** | **16.247 μs** | **86.70** |    **1.45** |       **-** |      **-** |  **89.26 KB** |        **5.76** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   515.01 μs |  4.415 μs |  2.920 μs | 48.06 |    0.30 |       - |      - |   41.6 KB |        2.69 |
| NativeSingle      | TaLib.Functions.Trix | 1000  |    10.72 μs |  0.056 μs |  0.034 μs |  1.00 |    0.00 |  0.9155 |      - |  15.48 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Trix | 1000  |    15.33 μs |  0.590 μs |  0.390 μs |  1.43 |    0.04 |  3.2959 | 0.1221 |   47.6 KB |        3.07 |
|                   |                      |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **5,196.93 μs** | **16.131 μs** |  **8.437 μs** | **47.87** |    **0.35** | **31.2500** |      **-** | **863.22 KB** |        **5.53** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 5,187.32 μs | 42.029 μs | 25.011 μs | 47.78 |    0.41 |       - |      - |  393.4 KB |        2.52 |
| NativeSingle      | TaLib.Functions.Trix | 10000 |   108.57 μs |  1.242 μs |  0.821 μs |  1.00 |    0.01 |  8.7891 | 0.9766 | 156.12 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Trix | 10000 |   168.14 μs |  5.358 μs |  3.544 μs |  1.55 |    0.03 | 30.2734 | 9.7656 | 469.48 KB |        3.01 |
