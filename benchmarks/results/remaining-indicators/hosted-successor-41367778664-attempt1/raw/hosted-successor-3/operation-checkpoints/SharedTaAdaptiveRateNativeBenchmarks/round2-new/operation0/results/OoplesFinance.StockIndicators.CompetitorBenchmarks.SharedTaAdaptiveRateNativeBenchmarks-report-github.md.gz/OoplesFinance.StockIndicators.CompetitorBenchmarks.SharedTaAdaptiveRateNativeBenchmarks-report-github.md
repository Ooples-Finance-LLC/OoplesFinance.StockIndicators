```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev   | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|---------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Mavp** | **1000**  | **104.93 μs** |  **2.569 μs** | **1.344 μs** |  **3.78** |    **0.05** |  **3.9063** |       **-** |  **66.38 KB** |        **3.34** |
| BuilderLatestOnly | TaLib.Functions.Mavp | 1000  |  93.89 μs |  1.082 μs | 0.716 μs |  3.38 |    0.03 |  0.9766 |       - |  18.77 KB |        0.94 |
| NativeSingle      | TaLib.Functions.Mavp | 1000  |  27.75 μs |  0.144 μs | 0.075 μs |  1.00 |    0.00 |  0.9766 |       - |   19.9 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mavp | 1000  |  45.79 μs |  3.196 μs | 2.114 μs |  1.65 |    0.07 |  3.9063 |       - |   59.1 KB |        2.97 |
|                   |                      |       |           |           |          |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Mavp** | **10000** | **916.48 μs** | **14.934 μs** | **8.887 μs** |  **2.89** |    **0.03** | **31.2500** |  **7.8125** | **629.29 KB** |        **3.22** |
| BuilderLatestOnly | TaLib.Functions.Mavp | 10000 | 872.38 μs |  2.423 μs | 1.267 μs |  2.75 |    0.01 |  7.8125 |       - | 159.47 KB |        0.81 |
| NativeSingle      | TaLib.Functions.Mavp | 10000 | 317.24 μs |  3.162 μs | 1.654 μs |  1.00 |    0.01 | 11.7188 |  1.9531 | 195.69 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mavp | 10000 | 434.18 μs | 14.808 μs | 8.812 μs |  1.37 |    0.03 | 35.1563 | 11.7188 | 568.89 KB |        2.91 |
