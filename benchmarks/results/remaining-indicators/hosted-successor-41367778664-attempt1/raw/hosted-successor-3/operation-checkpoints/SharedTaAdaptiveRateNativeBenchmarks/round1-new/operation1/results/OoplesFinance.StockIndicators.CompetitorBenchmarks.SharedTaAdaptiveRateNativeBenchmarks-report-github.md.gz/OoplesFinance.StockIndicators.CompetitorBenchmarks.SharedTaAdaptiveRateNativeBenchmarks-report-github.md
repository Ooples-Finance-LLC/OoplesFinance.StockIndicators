```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **540.2 μs** |  **1.91 μs** |  **1.14 μs** |       **-** |  **89.26 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   511.3 μs |  5.40 μs |  3.21 μs |       - |   41.6 KB |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **5,225.3 μs** | **26.66 μs** | **13.94 μs** | **31.2500** | **863.18 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 5,193.2 μs | 12.35 μs |  6.46 μs |       - | 393.39 KB |
