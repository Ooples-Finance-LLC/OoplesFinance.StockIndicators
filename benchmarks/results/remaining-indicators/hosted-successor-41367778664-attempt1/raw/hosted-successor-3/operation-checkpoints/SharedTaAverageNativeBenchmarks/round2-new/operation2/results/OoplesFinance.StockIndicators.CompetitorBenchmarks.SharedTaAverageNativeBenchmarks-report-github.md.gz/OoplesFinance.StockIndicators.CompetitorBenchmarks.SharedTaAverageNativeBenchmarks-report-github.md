```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean         | Error       | StdDev      | Ratio  | RatioSD | Gen0     | Gen1     | Allocated   | Alloc Ratio |
|------------------ |-------------------- |------ |-------------:|------------:|------------:|-------:|--------:|---------:|---------:|------------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Ppo** | **1000**  | **1,238.117 μs** | **218.9259 μs** | **144.8059 μs** | **192.05** |   **21.68** |  **62.5000** |        **-** |  **1487.41 KB** |       **95.10** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 1000  |   682.331 μs |   7.0819 μs |   3.7039 μs | 105.84 |    1.90 |  85.9375 |   7.8125 |  1439.82 KB |       92.06 |
| NativeSingle      | TaLib.Functions.Ppo | 1000  |     6.449 μs |   0.1961 μs |   0.1167 μs |   1.00 |    0.02 |   0.9155 |        - |    15.64 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ppo | 1000  |    12.517 μs |   0.3137 μs |   0.2075 μs |   1.94 |    0.05 |   3.2959 |   0.1831 |     47.7 KB |        3.05 |
|                   |                     |       |              |             |             |        |         |          |          |             |             |
| **BuilderFull**       | **TaLib.Functions.Ppo** | **10000** | **7,443.107 μs** | **193.1715 μs** | **101.0324 μs** | **118.26** |    **1.83** | **857.1429** | **428.5714** |  **14748.8 KB** |       **94.38** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 10000 | 7,669.306 μs | 341.0872 μs | 225.6081 μs | 121.86 |    3.58 | 857.1429 | 285.7143 | 14279.02 KB |       91.37 |
| NativeSingle      | TaLib.Functions.Ppo | 10000 |    62.941 μs |   0.8704 μs |   0.5757 μs |   1.00 |    0.01 |   9.2773 |   1.4648 |   156.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ppo | 10000 |   128.510 μs |   6.4207 μs |   4.2469 μs |   2.04 |    0.07 |  30.2734 |   9.7656 |   469.59 KB |        3.00 |
