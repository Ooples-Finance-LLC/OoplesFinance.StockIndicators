```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error       | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |-----------:|------------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Ma** | **1000**  | **124.778 μs** |  **14.2099 μs** |  **7.4321 μs** | **55.42** |    **3.12** |  **3.9063** |       **-** |  **78.23 KB** |        **9.84** |
| BuilderLatestOnly | TaLib.Functions.Ma | 1000  | 111.528 μs |   9.6790 μs |  6.4021 μs | 49.54 |    2.72 |  1.9531 |       - |  30.62 KB |        3.85 |
| NativeSingle      | TaLib.Functions.Ma | 1000  |   2.251 μs |   0.0178 μs |  0.0106 μs |  1.00 |    0.01 |  0.4730 |       - |   7.95 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ma | 1000  |   5.149 μs |   0.1098 μs |  0.0726 μs |  2.29 |    0.03 |  2.0142 |  0.0916 |  28.37 KB |        3.57 |
|                   |                    |       |            |             |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Ma** | **10000** | **978.309 μs** |  **65.2647 μs** | **43.1685 μs** | **44.67** |    **1.89** | **39.0625** | **15.6250** | **641.14 KB** |        **8.19** |
| BuilderLatestOnly | TaLib.Functions.Ma | 10000 | 955.345 μs | 102.5519 μs | 67.8317 μs | 43.62 |    2.96 |  7.8125 |       - | 171.31 KB |        2.19 |
| NativeSingle      | TaLib.Functions.Ma | 10000 |  21.900 μs |   0.1720 μs |  0.1024 μs |  1.00 |    0.01 |  4.7607 |  0.7324 |  78.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ma | 10000 |  39.524 μs |   1.5107 μs |  0.9992 μs |  1.80 |    0.04 | 18.0664 |  5.3711 | 274.46 KB |        3.51 |
