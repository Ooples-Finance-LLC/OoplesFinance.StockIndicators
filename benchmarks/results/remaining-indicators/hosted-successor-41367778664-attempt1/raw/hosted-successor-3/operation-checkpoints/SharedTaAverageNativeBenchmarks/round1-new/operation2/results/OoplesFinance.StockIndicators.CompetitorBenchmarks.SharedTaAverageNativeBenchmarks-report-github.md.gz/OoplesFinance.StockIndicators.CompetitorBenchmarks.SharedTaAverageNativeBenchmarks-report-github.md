```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev    | Median     | Gen0     | Gen1     | Allocated |
|------------------ |-------------------- |------ |-----------:|----------:|----------:|-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Ppo** | **1000**  |   **980.8 μs** | **833.11 μs** | **435.73 μs** |   **726.9 μs** |  **62.5000** |        **-** |   **1.45 MB** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 1000  |   680.8 μs |  79.51 μs |  47.31 μs |   655.3 μs |  85.9375 |   7.8125 |   1.41 MB |
| **BuilderFull**       | **TaLib.Functions.Ppo** | **10000** | **7,364.2 μs** | **715.35 μs** | **473.16 μs** | **7,128.5 μs** | **857.1429** | **428.5714** |   **14.4 MB** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 10000 | 7,106.1 μs | 392.37 μs | 205.22 μs | 7,164.8 μs | 857.1429 | 285.7143 |  13.94 MB |
