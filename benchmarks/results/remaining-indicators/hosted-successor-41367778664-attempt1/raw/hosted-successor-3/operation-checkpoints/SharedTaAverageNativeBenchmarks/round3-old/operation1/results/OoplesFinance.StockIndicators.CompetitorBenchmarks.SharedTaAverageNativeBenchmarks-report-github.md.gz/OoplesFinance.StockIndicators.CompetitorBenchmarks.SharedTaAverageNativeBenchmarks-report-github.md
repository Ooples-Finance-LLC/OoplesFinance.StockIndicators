```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev   | Gen0     | Gen1    | Allocated  |
|------------------ |-------------------- |------ |-----------:|----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **TaLib.Functions.Apo** | **1000**  |   **400.8 μs** | **105.97 μs** | **70.09 μs** |  **15.6250** |       **-** |  **355.26 KB** |
| BuilderLatestOnly | TaLib.Functions.Apo | 1000  |   321.5 μs |  32.23 μs | 19.18 μs |  15.6250 |       - |  307.67 KB |
| **BuilderFull**       | **TaLib.Functions.Apo** | **10000** | **2,930.2 μs** | **109.54 μs** | **72.45 μs** | **187.5000** | **93.7500** | **3167.57 KB** |
| BuilderLatestOnly | TaLib.Functions.Apo | 10000 | 2,887.4 μs | 155.52 μs | 92.55 μs | 156.2500 | 46.8750 | 2697.76 KB |
