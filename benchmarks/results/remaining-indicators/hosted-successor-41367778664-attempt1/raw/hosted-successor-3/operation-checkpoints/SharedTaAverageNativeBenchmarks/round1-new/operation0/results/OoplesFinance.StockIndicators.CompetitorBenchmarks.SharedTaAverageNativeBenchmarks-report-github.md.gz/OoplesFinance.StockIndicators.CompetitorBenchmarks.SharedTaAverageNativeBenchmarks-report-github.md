```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |------------------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Ma** | **1000**  | **140.2 μs** | **24.48 μs** | **16.19 μs** |  **3.9063** |       **-** |  **78.23 KB** |
| BuilderLatestOnly | TaLib.Functions.Ma | 1000  | 114.5 μs |  7.91 μs |  5.23 μs |  1.9531 |       - |  30.62 KB |
| **BuilderFull**       | **TaLib.Functions.Ma** | **10000** | **959.8 μs** | **82.23 μs** | **54.39 μs** | **39.0625** | **15.6250** | **641.14 KB** |
| BuilderLatestOnly | TaLib.Functions.Ma | 10000 | 896.3 μs | 22.60 μs | 11.82 μs |  7.8125 |       - | 171.31 KB |
