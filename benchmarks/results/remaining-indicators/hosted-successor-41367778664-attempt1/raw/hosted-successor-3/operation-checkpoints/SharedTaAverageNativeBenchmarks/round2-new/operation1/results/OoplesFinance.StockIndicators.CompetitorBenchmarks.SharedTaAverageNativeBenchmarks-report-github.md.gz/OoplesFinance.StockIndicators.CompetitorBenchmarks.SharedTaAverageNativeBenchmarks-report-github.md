```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |-------------------- |------ |-------------:|------------:|------------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Apo** | **1000**  |   **464.385 μs** |  **91.9334 μs** |  **54.7081 μs** | **83.19** |    **9.33** |  **15.6250** |       **-** |   **355.3 KB** |       **22.72** |
| BuilderLatestOnly | TaLib.Functions.Apo | 1000  |   309.839 μs |   2.7275 μs |   1.4266 μs | 55.51 |    0.47 |  15.6250 |       - |  307.67 KB |       19.67 |
| NativeSingle      | TaLib.Functions.Apo | 1000  |     5.582 μs |   0.0839 μs |   0.0439 μs |  1.00 |    0.01 |   0.9460 |  0.0305 |   15.64 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Apo | 1000  |    10.086 μs |   0.2549 μs |   0.1686 μs |  1.81 |    0.03 |   3.2959 |  0.2441 |    47.7 KB |        3.05 |
|                   |                     |       |              |             |             |       |         |          |         |            |             |
| **BuilderFull**       | **TaLib.Functions.Apo** | **10000** | **2,984.296 μs** | **169.3868 μs** | **112.0389 μs** | **52.47** |    **2.03** | **187.5000** | **93.7500** | **3167.61 KB** |       **20.27** |
| BuilderLatestOnly | TaLib.Functions.Apo | 10000 | 3,046.672 μs | 289.8057 μs | 191.6885 μs | 53.56 |    3.31 | 156.2500 | 46.8750 | 2697.78 KB |       17.26 |
| NativeSingle      | TaLib.Functions.Apo | 10000 |    56.891 μs |   1.4608 μs |   0.8693 μs |  1.00 |    0.02 |   9.2773 |  1.4648 |  156.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Apo | 10000 |   108.727 μs |   4.5535 μs |   3.0119 μs |  1.91 |    0.06 |  30.2734 |  9.7656 |  469.59 KB |        3.00 |
