```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |---------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **KeltnerChannels** | **1000**  |    **297.6 μs** |     **3.79 μs** |     **1.98 μs** |  **0.19** |    **0.00** |         **-** |         **-** |         **-** |    **96.91 KB** |        **0.03** |
| BuilderLatestOnly | KeltnerChannels | 1000  |    285.8 μs |     3.13 μs |     2.07 μs |  0.18 |    0.00 |    1.9531 |         - |         - |    49.27 KB |        0.02 |
| NativeSingle      | KeltnerChannels | 1000  |  1,600.0 μs |    37.98 μs |    25.12 μs |  1.00 |    0.02 |  171.8750 |  109.3750 |   46.8750 |  2804.64 KB |        1.00 |
| NativeParallel    | KeltnerChannels | 1000  |  1,305.1 μs |    54.08 μs |    35.77 μs |  0.82 |    0.02 |  281.2500 |  132.8125 |         - |  4352.94 KB |        1.55 |
|                   |                 |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **KeltnerChannels** | **10000** |  **2,936.0 μs** |    **86.60 μs** |    **57.28 μs** |  **0.17** |    **0.01** |   **46.8750** |   **15.6250** |         **-** |    **941.1 KB** |        **0.03** |
| BuilderLatestOnly | KeltnerChannels | 10000 |  2,823.4 μs |    12.81 μs |     6.70 μs |  0.16 |    0.01 |   15.6250 |         - |         - |   471.27 KB |        0.02 |
| NativeSingle      | KeltnerChannels | 10000 | 17,798.9 μs | 1,588.40 μs |   830.76 μs |  1.00 |    0.06 | 1666.6667 | 1166.6667 |  833.3333 | 27277.67 KB |        1.00 |
| NativeParallel    | KeltnerChannels | 10000 | 18,025.0 μs | 2,298.24 μs | 1,520.14 μs |  1.01 |    0.09 | 2500.0000 | 1833.3333 | 1166.6667 | 42683.89 KB |        1.56 |
