```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **KeltnerChannels** | **1000**  |   **288.3 μs** |  **6.99 μs** | **4.16 μs** |       **-** |       **-** |  **96.79 KB** |
| BuilderLatestOnly | KeltnerChannels | 1000  |   290.2 μs |  3.74 μs | 2.22 μs |  1.9531 |       - |  49.23 KB |
| **BuilderFull**       | **KeltnerChannels** | **10000** | **2,851.7 μs** | **12.29 μs** | **7.31 μs** | **46.8750** | **15.6250** | **941.03 KB** |
| BuilderLatestOnly | KeltnerChannels | 10000 | 2,830.5 μs | 10.18 μs | 5.33 μs | 15.6250 |       - | 471.22 KB |
