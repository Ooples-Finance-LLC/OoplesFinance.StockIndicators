```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **ChandelierExit** | **1000**  |    **354.3 μs** |   **124.93 μs** |    **82.64 μs** |  **0.20** |    **0.04** |         **-** |         **-** |        **-** |     **73.7 KB** |       **0.028** |
| BuilderLatestOnly | ChandelierExit | 1000  |    234.8 μs |     2.61 μs |     1.56 μs |  0.13 |    0.00 |         - |         - |        - |    26.06 KB |       0.010 |
| NativeSingle      | ChandelierExit | 1000  |  1,766.1 μs |    16.35 μs |     8.55 μs |  1.00 |    0.01 |  140.6250 |   78.1250 |  31.2500 |  2631.06 KB |       1.000 |
| NativeParallel    | ChandelierExit | 1000  |  1,268.1 μs |    90.95 μs |    60.16 μs |  0.72 |    0.03 |  250.0000 |  125.0000 |        - |  3937.19 KB |       1.496 |
|                   |                |       |             |             |             |       |         |           |           |          |             |             |
| **BuilderFull**       | **ChandelierExit** | **10000** |  **2,552.3 μs** |    **22.21 μs** |    **11.61 μs** |  **0.14** |    **0.00** |   **31.2500** |         **-** |        **-** |   **706.94 KB** |       **0.028** |
| BuilderLatestOnly | ChandelierExit | 10000 |  2,526.6 μs |    23.54 μs |    12.31 μs |  0.14 |    0.00 |         - |         - |        - |   237.11 KB |       0.009 |
| NativeSingle      | ChandelierExit | 10000 | 18,175.2 μs |   223.63 μs |   116.96 μs |  1.00 |    0.01 | 1333.3333 |  666.6667 | 500.0000 | 25625.53 KB |       1.000 |
| NativeParallel    | ChandelierExit | 10000 | 16,812.0 μs | 1,709.76 μs | 1,017.45 μs |  0.93 |    0.05 | 2000.0000 | 1166.6667 | 500.0000 | 38817.09 KB |       1.515 |
