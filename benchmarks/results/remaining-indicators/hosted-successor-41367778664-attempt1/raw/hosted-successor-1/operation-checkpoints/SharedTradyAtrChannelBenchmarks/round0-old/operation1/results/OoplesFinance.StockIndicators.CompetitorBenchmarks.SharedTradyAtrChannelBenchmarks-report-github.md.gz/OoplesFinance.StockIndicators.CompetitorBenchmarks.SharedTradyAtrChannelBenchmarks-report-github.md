```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **KeltnerChannels** | **1000**  |   **305.4 μs** |  **8.25 μs** |  **4.91 μs** |       **-** |       **-** |  **96.83 KB** |
| BuilderLatestOnly | KeltnerChannels | 1000  |   297.9 μs |  2.02 μs |  1.20 μs |  1.9531 |       - |  49.23 KB |
| **BuilderFull**       | **KeltnerChannels** | **10000** | **2,980.8 μs** | **17.64 μs** | **10.50 μs** | **46.8750** | **15.6250** | **941.06 KB** |
| BuilderLatestOnly | KeltnerChannels | 10000 | 2,932.9 μs | 10.72 μs |  5.61 μs | 15.6250 |       - | 471.22 KB |
