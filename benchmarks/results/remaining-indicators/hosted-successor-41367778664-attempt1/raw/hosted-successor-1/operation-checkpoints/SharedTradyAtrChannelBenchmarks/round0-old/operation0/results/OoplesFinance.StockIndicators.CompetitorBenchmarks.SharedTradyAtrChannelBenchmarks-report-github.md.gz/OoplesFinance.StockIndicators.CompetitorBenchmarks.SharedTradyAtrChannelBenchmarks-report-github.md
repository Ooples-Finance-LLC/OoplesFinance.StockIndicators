```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev  | Gen0    | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **ChandelierExit** | **1000**  |   **236.3 μs** |  **3.74 μs** | **1.95 μs** |       **-** |  **73.65 KB** |
| BuilderLatestOnly | ChandelierExit | 1000  |   244.6 μs |  1.73 μs | 0.90 μs |       - |  26.05 KB |
| **BuilderFull**       | **ChandelierExit** | **10000** | **2,509.2 μs** | **16.97 μs** | **8.88 μs** | **31.2500** | **706.94 KB** |
| BuilderLatestOnly | ChandelierExit | 10000 | 2,444.6 μs | 10.97 μs | 7.26 μs |       - |  237.1 KB |
