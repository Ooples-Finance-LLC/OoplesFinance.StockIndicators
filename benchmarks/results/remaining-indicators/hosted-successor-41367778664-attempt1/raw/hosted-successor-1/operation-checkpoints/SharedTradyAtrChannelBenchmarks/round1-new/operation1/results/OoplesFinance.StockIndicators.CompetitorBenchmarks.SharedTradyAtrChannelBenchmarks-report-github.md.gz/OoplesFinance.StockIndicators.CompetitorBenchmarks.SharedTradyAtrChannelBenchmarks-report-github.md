```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **KeltnerChannels** | **1000**  |   **287.8 μs** |  **1.54 μs** |  **0.81 μs** |       **-** |       **-** |  **96.91 KB** |
| BuilderLatestOnly | KeltnerChannels | 1000  |   291.9 μs |  9.03 μs |  5.97 μs |  1.9531 |       - |  49.27 KB |
| **BuilderFull**       | **KeltnerChannels** | **10000** | **3,044.5 μs** | **14.89 μs** |  **8.86 μs** | **46.8750** | **15.6250** |  **941.1 KB** |
| BuilderLatestOnly | KeltnerChannels | 10000 | 2,815.2 μs | 61.79 μs | 40.87 μs | 15.6250 |       - | 471.27 KB |
