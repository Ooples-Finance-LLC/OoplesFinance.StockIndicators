```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **ChandelierExit** | **1000**  |   **234.2 μs** |  **3.19 μs** |  **1.67 μs** |       **-** |  **73.65 KB** |
| BuilderLatestOnly | ChandelierExit | 1000  |   232.8 μs |  2.93 μs |  1.53 μs |       - |  26.06 KB |
| **BuilderFull**       | **ChandelierExit** | **10000** | **2,505.5 μs** | **18.30 μs** | **12.11 μs** | **31.2500** | **706.94 KB** |
| BuilderLatestOnly | ChandelierExit | 10000 | 2,419.2 μs | 13.94 μs |  9.22 μs |       - | 237.11 KB |
