```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Weigh(...)erage [21]** | **1000**  |  **22.78 μs** |  **2.537 μs** |  **1.678 μs** |  **2.9297** |       **-** |  **58.47 KB** |
| BuilderLatestOnly | Weigh(...)erage [21] | 1000  |  11.95 μs |  1.003 μs |  0.525 μs |  0.6104 |       - |  10.59 KB |
| **BuilderFull**       | **Weigh(...)erage [21]** | **10000** | **107.97 μs** | **22.534 μs** | **14.905 μs** | **33.2031** | **11.7188** | **551.01 KB** |
| BuilderLatestOnly | Weigh(...)erage [21] | 10000 |  90.70 μs |  7.179 μs |  4.272 μs |  4.8828 |  0.9766 |  80.91 KB |
