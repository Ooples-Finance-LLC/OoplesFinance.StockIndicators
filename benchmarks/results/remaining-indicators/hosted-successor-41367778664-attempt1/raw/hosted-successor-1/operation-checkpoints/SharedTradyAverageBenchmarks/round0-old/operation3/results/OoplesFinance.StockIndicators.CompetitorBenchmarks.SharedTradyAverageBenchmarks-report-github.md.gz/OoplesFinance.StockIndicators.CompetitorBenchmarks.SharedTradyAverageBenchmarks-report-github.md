```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **Expon(...)lator [34]** | **1000**  |  **83.80 μs** |  **3.463 μs** | **2.061 μs** |  **3.9063** |      **-** |  **64.93 KB** |
| BuilderLatestOnly | Expon(...)lator [34] | 1000  |  77.35 μs |  0.790 μs | 0.470 μs |  0.9766 |      - |  17.32 KB |
| **BuilderFull**       | **Expon(...)lator [34]** | **10000** | **884.18 μs** | **11.157 μs** | **5.835 μs** | **31.2500** | **7.8125** | **627.84 KB** |
| BuilderLatestOnly | Expon(...)lator [34] | 10000 | 859.20 μs | 11.143 μs | 6.631 μs |  7.8125 |      - | 158.01 KB |
