```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Expon(...)erage [24]** | **1000**  |  **50.70 μs** | **23.922 μs** | **15.823 μs** |  **1.9531** |       **-** |  **56.68 KB** |
| BuilderLatestOnly | Expon(...)erage [24] | 1000  |  33.63 μs |  1.112 μs |  0.735 μs |  0.4883 |       - |    8.8 KB |
| **BuilderFull**       | **Expon(...)erage [24]** | **10000** | **391.20 μs** | **18.037 μs** | **10.734 μs** | **33.2031** | **13.6719** | **549.23 KB** |
| BuilderLatestOnly | Expon(...)erage [24] | 10000 | 366.56 μs |  5.009 μs |  2.981 μs |  3.9063 |       - |  79.13 KB |
