```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error        | StdDev     | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-------------:|-----------:|------:|--------:|----------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **Expon(...)erage [24]** | **1000**  |    **37.78 μs** |     **6.553 μs** |   **4.335 μs** |  **0.08** |    **0.01** |    **1.9531** |         **-** |        **-** |    **56.64 KB** |       **0.062** |
| BuilderLatestOnly | Expon(...)erage [24] | 1000  |    32.11 μs |     1.596 μs |   1.056 μs |  0.07 |    0.00 |    0.4883 |         - |        - |      8.8 KB |       0.010 |
| NativeSingle      | Expon(...)erage [24] | 1000  |   493.01 μs |    10.068 μs |   6.660 μs |  1.00 |    0.02 |   54.6875 |   15.6250 |        - |   915.29 KB |       1.000 |
| NativeParallel    | Expon(...)erage [24] | 1000  |   500.83 μs |    29.402 μs |  19.447 μs |  1.02 |    0.04 |   82.0313 |   27.3438 |        - |  1328.65 KB |       1.452 |
|                   |                      |       |             |              |            |       |         |           |           |          |             |             |
| **BuilderFull**       | **Expon(...)erage [24]** | **10000** |   **378.72 μs** |     **1.824 μs** |   **0.954 μs** |  **0.07** |    **0.00** |   **33.2031** |   **13.6719** |        **-** |   **549.19 KB** |       **0.062** |
| BuilderLatestOnly | Expon(...)erage [24] | 10000 |   362.69 μs |     5.352 μs |   3.540 μs |  0.07 |    0.00 |    3.9063 |         - |        - |    79.13 KB |       0.009 |
| NativeSingle      | Expon(...)erage [24] | 10000 | 5,547.23 μs |    92.568 μs |  48.415 μs |  1.00 |    0.01 | 1281.2500 | 1000.0000 | 937.5000 |  8914.22 KB |       1.000 |
| NativeParallel    | Expon(...)erage [24] | 10000 | 8,312.11 μs | 1,151.226 μs | 761.464 μs |  1.50 |    0.13 | 1384.6154 | 1076.9231 | 923.0769 | 13012.69 KB |       1.460 |
