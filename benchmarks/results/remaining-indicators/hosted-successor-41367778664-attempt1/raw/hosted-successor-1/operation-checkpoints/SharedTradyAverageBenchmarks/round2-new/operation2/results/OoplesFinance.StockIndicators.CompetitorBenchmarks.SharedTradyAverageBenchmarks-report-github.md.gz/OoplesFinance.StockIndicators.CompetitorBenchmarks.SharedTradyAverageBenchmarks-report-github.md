```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0      | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|----------:|---------:|---------:|------------:|------------:|
| **BuilderFull**       | **Simpl(...)lator [29]** | **1000**  |     **55.80 μs** |  **11.798 μs** |   **6.171 μs** |  **0.06** |    **0.01** |    **3.9063** |        **-** |        **-** |    **69.55 KB** |        **0.06** |
| BuilderLatestOnly | Simpl(...)lator [29] | 1000  |     51.13 μs |   5.755 μs |   3.807 μs |  0.06 |    0.00 |    0.9766 |        - |        - |    21.94 KB |        0.02 |
| NativeSingle      | Simpl(...)lator [29] | 1000  |    901.54 μs |  15.828 μs |   8.278 μs |  1.00 |    0.01 |   62.5000 |  23.4375 |        - |   1081.5 KB |        1.00 |
| NativeParallel    | Simpl(...)lator [29] | 1000  |    501.36 μs |  43.347 μs |  28.671 μs |  0.56 |    0.03 |   66.4063 |  19.5313 |        - |  1055.79 KB |        0.98 |
|                   |                      |       |              |            |            |       |         |           |          |          |             |             |
| **BuilderFull**       | **Simpl(...)lator [29]** | **10000** |    **387.61 μs** |  **48.569 μs** |  **32.126 μs** |  **0.04** |    **0.00** |   **37.1094** |  **15.6250** |        **-** |   **632.42 KB** |        **0.06** |
| BuilderLatestOnly | Simpl(...)lator [29] | 10000 |    345.39 μs |  33.662 μs |  22.265 μs |  0.03 |    0.00 |    9.7656 |   1.9531 |        - |   162.59 KB |        0.02 |
| NativeSingle      | Simpl(...)lator [29] | 10000 | 10,390.85 μs | 487.405 μs | 322.388 μs |  1.00 |    0.04 | 1100.0000 | 900.0000 | 800.0000 | 10510.43 KB |        1.00 |
| NativeParallel    | Simpl(...)lator [29] | 10000 |  6,753.64 μs | 717.369 μs | 474.495 μs |  0.65 |    0.05 | 1000.0000 | 800.0000 | 533.3333 | 10386.94 KB |        0.99 |
