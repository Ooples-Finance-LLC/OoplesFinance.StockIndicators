```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Expon(...)erage [24]** | **1000**  |  **55.17 μs** | **20.654 μs** | **12.291 μs** |  **1.9531** |       **-** |  **56.66 KB** |
| BuilderLatestOnly | Expon(...)erage [24] | 1000  |  31.01 μs |  1.499 μs |  0.784 μs |  0.4883 |       - |   8.78 KB |
| **BuilderFull**       | **Expon(...)erage [24]** | **10000** | **369.82 μs** |  **5.319 μs** |  **3.165 μs** | **33.2031** | **13.6719** | **549.21 KB** |
| BuilderLatestOnly | Expon(...)erage [24] | 10000 | 347.61 μs |  8.449 μs |  5.588 μs |  3.9063 |       - |   79.1 KB |
