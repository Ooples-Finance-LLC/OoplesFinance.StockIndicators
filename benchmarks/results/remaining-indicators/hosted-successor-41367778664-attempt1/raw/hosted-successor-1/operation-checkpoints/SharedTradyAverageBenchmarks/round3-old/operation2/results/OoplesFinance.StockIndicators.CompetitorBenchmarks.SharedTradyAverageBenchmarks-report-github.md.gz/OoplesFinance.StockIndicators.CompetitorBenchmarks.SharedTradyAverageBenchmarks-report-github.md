```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Simpl(...)lator [29]** | **1000**  |  **62.37 μs** | **12.664 μs** |  **7.536 μs** |  **3.9063** |       **-** |  **69.55 KB** |
| BuilderLatestOnly | Simpl(...)lator [29] | 1000  |  45.85 μs |  7.715 μs |  5.103 μs |  0.9766 |       - |  21.94 KB |
| **BuilderFull**       | **Simpl(...)lator [29]** | **10000** | **393.11 μs** | **67.673 μs** | **44.761 μs** | **37.1094** | **13.6719** | **632.42 KB** |
| BuilderLatestOnly | Simpl(...)lator [29] | 10000 | 387.05 μs | 89.194 μs | 58.996 μs |  7.8125 |       - |  162.6 KB |
