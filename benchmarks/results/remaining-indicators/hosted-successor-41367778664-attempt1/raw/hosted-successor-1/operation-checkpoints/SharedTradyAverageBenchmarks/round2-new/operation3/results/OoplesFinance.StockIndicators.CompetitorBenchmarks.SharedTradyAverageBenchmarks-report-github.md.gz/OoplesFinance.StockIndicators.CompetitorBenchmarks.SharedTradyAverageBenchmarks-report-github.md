```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error        | StdDev       | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-------------:|-------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Expon(...)lator [34]** | **1000**  |     **82.85 μs** |     **0.979 μs** |     **0.582 μs** |  **0.07** |    **0.00** |    **3.9063** |         **-** |         **-** |    **64.93 KB** |       **0.030** |
| BuilderLatestOnly | Expon(...)lator [34] | 1000  |     80.70 μs |     2.940 μs |     1.944 μs |  0.07 |    0.00 |    0.9766 |         - |         - |    17.32 KB |       0.008 |
| NativeSingle      | Expon(...)lator [34] | 1000  |  1,173.72 μs |    15.622 μs |     9.297 μs |  1.00 |    0.01 |  132.8125 |   54.6875 |         - |  2200.75 KB |       1.000 |
| NativeParallel    | Expon(...)lator [34] | 1000  |  1,066.26 μs |    68.703 μs |    45.443 μs |  0.91 |    0.04 |  210.9375 |   85.9375 |         - |  3332.46 KB |       1.514 |
|                   |                      |       |              |              |              |       |         |           |           |           |             |             |
| **BuilderFull**       | **Expon(...)lator [34]** | **10000** |    **885.14 μs** |     **6.514 μs** |     **3.876 μs** |  **0.06** |    **0.00** |   **31.2500** |    **7.8125** |         **-** |   **627.84 KB** |       **0.029** |
| BuilderLatestOnly | Expon(...)lator [34] | 10000 |    841.46 μs |     4.069 μs |     2.128 μs |  0.06 |    0.00 |    7.8125 |         - |         - |   158.01 KB |       0.007 |
| NativeSingle      | Expon(...)lator [34] | 10000 | 13,724.75 μs |   834.448 μs |   551.936 μs |  1.00 |    0.05 | 1500.0000 | 1000.0000 |  750.0000 | 21974.68 KB |       1.000 |
| NativeParallel    | Expon(...)lator [34] | 10000 | 15,151.92 μs | 2,006.221 μs | 1,326.991 μs |  1.11 |    0.10 | 2571.4286 | 2000.0000 | 1285.7143 |  33532.4 KB |       1.526 |
