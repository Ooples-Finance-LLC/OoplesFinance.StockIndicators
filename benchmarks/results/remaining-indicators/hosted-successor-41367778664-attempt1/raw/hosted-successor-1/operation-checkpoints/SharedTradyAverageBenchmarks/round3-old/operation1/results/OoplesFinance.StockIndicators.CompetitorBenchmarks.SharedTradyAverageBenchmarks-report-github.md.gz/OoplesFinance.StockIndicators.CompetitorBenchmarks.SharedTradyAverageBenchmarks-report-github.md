```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Weigh(...)erage [21]** | **1000**  |  **25.71 μs** |  **4.404 μs** |  **2.913 μs** |  **2.9297** |       **-** |  **58.47 KB** |
| BuilderLatestOnly | Weigh(...)erage [21] | 1000  |  15.05 μs |  2.557 μs |  1.337 μs |  0.4883 |       - |  10.59 KB |
| **BuilderFull**       | **Weigh(...)erage [21]** | **10000** | **116.65 μs** | **17.953 μs** | **11.875 μs** | **33.2031** | **11.7188** | **551.01 KB** |
| BuilderLatestOnly | Weigh(...)erage [21] | 10000 |  84.48 μs |  6.215 μs |  3.699 μs |  4.8828 |  0.4883 |  80.91 KB |
