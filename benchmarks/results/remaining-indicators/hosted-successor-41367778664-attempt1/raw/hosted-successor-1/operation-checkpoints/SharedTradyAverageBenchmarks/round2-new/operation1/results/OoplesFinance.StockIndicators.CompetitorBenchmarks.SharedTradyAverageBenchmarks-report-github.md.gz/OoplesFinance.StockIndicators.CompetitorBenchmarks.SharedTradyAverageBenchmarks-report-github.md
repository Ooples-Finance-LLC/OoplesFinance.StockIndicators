```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Weigh(...)erage [21]** | **1000**  |     **22.88 μs** |   **5.693 μs** |   **3.766 μs** | **0.014** |    **0.00** |   **2.9297** |        **-** |        **-** |   **58.51 KB** |        **0.10** |
| BuilderLatestOnly | Weigh(...)erage [21] | 1000  |     12.59 μs |   1.379 μs |   0.721 μs | 0.007 |    0.00 |   0.6104 |        - |        - |   10.59 KB |        0.02 |
| NativeSingle      | Weigh(...)erage [21] | 1000  |  1,678.84 μs |   9.734 μs |   5.091 μs | 1.000 |    0.00 |  31.2500 |        - |        - |   559.6 KB |        1.00 |
| NativeParallel    | Weigh(...)erage [21] | 1000  |    883.14 μs |  61.112 μs |  40.422 μs | 0.526 |    0.02 |  31.2500 |   7.8125 |        - |  565.12 KB |        1.01 |
|                   |                      |       |              |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Weigh(...)erage [21]** | **10000** |    **102.76 μs** |  **17.928 μs** |  **11.858 μs** | **0.006** |    **0.00** |  **33.2031** |  **11.7188** |        **-** |  **551.01 KB** |        **0.10** |
| BuilderLatestOnly | Weigh(...)erage [21] | 10000 |    114.73 μs |  22.772 μs |  15.062 μs | 0.006 |    0.00 |   4.8828 |   0.9766 |        - |   80.91 KB |        0.01 |
| NativeSingle      | Weigh(...)erage [21] | 10000 | 17,710.74 μs | 248.761 μs | 148.034 μs | 1.000 |    0.01 | 500.0000 | 333.3333 | 333.3333 | 5508.34 KB |        1.00 |
| NativeParallel    | Weigh(...)erage [21] | 10000 |  9,896.54 μs | 604.722 μs | 399.986 μs | 0.559 |    0.02 | 400.0000 | 300.0000 | 200.0000 | 5620.98 KB |        1.02 |
