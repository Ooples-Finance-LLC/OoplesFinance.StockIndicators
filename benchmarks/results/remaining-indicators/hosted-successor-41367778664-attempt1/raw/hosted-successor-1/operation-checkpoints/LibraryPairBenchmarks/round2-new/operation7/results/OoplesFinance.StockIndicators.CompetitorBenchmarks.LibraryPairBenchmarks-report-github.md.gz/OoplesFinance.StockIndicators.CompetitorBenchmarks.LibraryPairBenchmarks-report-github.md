```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)rExit [30]** |  **2.051 ms** | **0.0510 ms** | **0.0303 ms** |  **1.00** |    **0.02** |         **-** |         **-** |         **-** |   **155.14 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)rExit [30] |  8.652 ms | 0.3330 ms | 0.1742 ms |  4.22 |    0.10 |         - |         - |         - |   3536.1 KB |       22.79 |
|            |       |                      |           |           |           |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)rExit [30]** | **16.544 ms** | **2.4639 ms** | **1.6297 ms** |  **1.01** |    **0.13** |         **-** |         **-** |         **-** |   **1517.8 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)rExit [30] | 34.097 ms | 9.9527 ms | 6.5831 ms |  2.08 |    0.42 | 2000.0000 | 1000.0000 | 1000.0000 | 28944.43 KB |       19.07 |
