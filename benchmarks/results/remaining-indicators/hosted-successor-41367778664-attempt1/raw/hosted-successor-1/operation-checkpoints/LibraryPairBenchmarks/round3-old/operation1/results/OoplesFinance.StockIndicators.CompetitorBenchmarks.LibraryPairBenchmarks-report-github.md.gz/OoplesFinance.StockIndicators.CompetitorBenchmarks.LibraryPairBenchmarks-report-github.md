```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)Stoch [21]** |  **2.872 ms** | **0.0949 ms** | **0.0564 ms** |  **1.00** |    **0.03** |  **720.57 KB** |        **1.00** |
|        |       |                      |           |           |           |       |         |            |             |
| **Ooples** | **10000** | **TaLib(...)Stoch [21]** | **26.895 ms** | **1.6856 ms** | **0.8816 ms** |  **1.00** |    **0.04** | **7144.74 KB** |        **1.00** |
