```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)nLine [44]** |  **1.244 ms** | **0.0797 ms** | **0.0527 ms** |  **1.00** |    **0.06** |  **194.68 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)nLine [44] |  3.151 ms | 0.0685 ms | 0.0408 ms |  2.54 |    0.10 |   966.9 KB |        4.97 |
|            |       |                      |           |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Trady(...)nLine [44]** |  **8.214 ms** | **0.2879 ms** | **0.1904 ms** |  **1.00** |    **0.03** | **2341.22 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)nLine [44] | 28.329 ms | 1.8461 ms | 1.0986 ms |  3.45 |    0.15 | 9436.22 KB |        4.03 |
