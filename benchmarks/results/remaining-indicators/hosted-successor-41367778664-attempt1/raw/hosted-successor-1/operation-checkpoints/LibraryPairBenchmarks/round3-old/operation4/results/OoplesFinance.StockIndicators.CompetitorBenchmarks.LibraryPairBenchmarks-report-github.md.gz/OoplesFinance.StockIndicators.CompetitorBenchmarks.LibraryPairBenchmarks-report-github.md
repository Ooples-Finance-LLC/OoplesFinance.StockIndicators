```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId             | Mean        | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |------------------- |------------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.T3** |    **956.8 μs** |    **56.45 μs** |  **37.34 μs** |  **1.00** |    **0.05** |  **105.89 KB** |        **1.00** |
|        |       |                    |             |             |           |       |         |            |             |
| **Ooples** | **10000** | **TaLib.Functions.T3** | **12,232.6 μs** | **1,012.94 μs** | **602.79 μs** |  **1.00** |    **0.07** | **1037.23 KB** |        **1.00** |
