```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId              | Mean      | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |-------------------- |----------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Ppo** |  **3.671 ms** |  **0.2590 ms** |  **0.1541 ms** |  **1.00** |    **0.06** |   **1.47 MB** |        **1.00** |
|        |       |                     |           |            |            |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Ppo** | **40.314 ms** | **17.9000 ms** | **11.8398 ms** |  **1.13** |    **0.60** |  **14.78 MB** |        **1.00** |
