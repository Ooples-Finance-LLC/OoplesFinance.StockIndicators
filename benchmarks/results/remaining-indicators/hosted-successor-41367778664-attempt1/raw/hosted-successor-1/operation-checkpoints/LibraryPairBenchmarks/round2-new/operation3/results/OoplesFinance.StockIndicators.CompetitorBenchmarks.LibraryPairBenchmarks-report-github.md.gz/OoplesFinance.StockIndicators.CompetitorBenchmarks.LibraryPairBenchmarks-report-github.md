```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)chRsi [24]** |  **3,421.5 μs** |  **59.01 μs** |  **35.12 μs** |  **1.00** |  **264.34 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)chRsi [24] |    400.1 μs |  63.46 μs |  37.76 μs |  0.12 |    89.3 KB |        0.34 |
|            |       |                      |             |           |           |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)chRsi [24]** | **27,481.1 μs** | **238.75 μs** | **142.08 μs** |  **1.00** | **2610.71 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)chRsi [24] |    934.6 μs |  51.04 μs |  30.38 μs |  0.03 |     810 KB |        0.31 |
