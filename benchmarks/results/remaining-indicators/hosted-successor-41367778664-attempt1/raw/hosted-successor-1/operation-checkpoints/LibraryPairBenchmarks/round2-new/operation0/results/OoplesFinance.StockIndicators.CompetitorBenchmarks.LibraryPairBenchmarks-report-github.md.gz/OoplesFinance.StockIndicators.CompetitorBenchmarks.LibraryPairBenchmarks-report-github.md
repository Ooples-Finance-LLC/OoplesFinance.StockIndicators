```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId              | Mean        | Error        | StdDev       | Median      | Ratio | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |-------------------- |------------:|-------------:|-------------:|------------:|------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ppo** |  **3,364.6 μs** |     **53.31 μs** |     **27.88 μs** |  **3,372.1 μs** |  **1.00** |    **0.01** |  **1505.25 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ppo |    155.7 μs |     20.03 μs |     13.25 μs |    151.2 μs |  0.05 |    0.00 |    48.84 KB |        0.03 |
|            |       |                     |             |              |              |             |       |         |             |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ppo** | **25,664.2 μs** | **29,075.49 μs** | **19,231.64 μs** | **16,289.6 μs** |  **1.51** |    **1.45** | **15133.96 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ppo |    255.3 μs |     10.25 μs |      5.36 μs |    255.5 μs |  0.02 |    0.01 |   409.19 KB |        0.03 |
