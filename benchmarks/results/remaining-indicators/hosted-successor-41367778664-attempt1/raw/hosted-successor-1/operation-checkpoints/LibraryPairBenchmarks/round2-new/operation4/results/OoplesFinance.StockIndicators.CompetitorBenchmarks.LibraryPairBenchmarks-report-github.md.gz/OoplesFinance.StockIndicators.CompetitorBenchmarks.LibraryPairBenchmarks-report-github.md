```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId             | Mean       | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-----------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.T3** |   **905.1 μs** |    **35.81 μs** |    **21.31 μs** |  **1.00** |    **0.03** |  **105.89 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.T3 |   146.7 μs |    15.33 μs |    10.14 μs |  0.16 |    0.01 |   40.88 KB |        0.39 |
|            |       |                    |            |             |             |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.T3** | **6,160.1 μs** | **2,321.76 μs** | **1,535.70 μs** |  **1.09** |    **0.46** | **1037.23 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.T3 |   186.1 μs |    10.24 μs |     6.09 μs |  0.03 |    0.01 |  330.91 KB |        0.32 |
