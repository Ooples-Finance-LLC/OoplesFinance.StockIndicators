```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId             | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.T3** |  **1.106 ms** | **0.2431 ms** | **0.1608 ms** |  **1.02** |    **0.19** |  **105.89 KB** |        **1.00** |
|        |       |                    |           |           |           |       |         |            |             |
| **Ooples** | **10000** | **TaLib.Functions.T3** | **10.907 ms** | **0.3451 ms** | **0.1805 ms** |  **1.00** |    **0.02** | **1036.62 KB** |        **1.00** |
