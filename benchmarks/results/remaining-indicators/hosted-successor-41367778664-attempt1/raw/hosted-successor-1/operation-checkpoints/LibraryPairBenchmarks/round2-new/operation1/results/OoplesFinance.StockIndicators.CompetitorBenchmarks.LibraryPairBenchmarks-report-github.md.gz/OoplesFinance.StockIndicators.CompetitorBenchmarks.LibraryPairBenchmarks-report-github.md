```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Stoch [21]** |  **2,967.8 μs** |   **221.01 μs** |   **146.18 μs** |  **1.00** |    **0.07** |  **720.57 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Stoch [21] |    420.0 μs |   104.10 μs |    68.86 μs |  0.14 |    0.02 |   97.36 KB |        0.14 |
|            |       |                      |             |             |             |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)Stoch [21]** | **28,980.9 μs** | **4,191.83 μs** | **2,772.63 μs** |  **1.01** |    **0.13** | **7145.07 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Stoch [21] |    607.4 μs |    31.99 μs |    19.04 μs |  0.02 |    0.00 |  888.38 KB |        0.12 |
