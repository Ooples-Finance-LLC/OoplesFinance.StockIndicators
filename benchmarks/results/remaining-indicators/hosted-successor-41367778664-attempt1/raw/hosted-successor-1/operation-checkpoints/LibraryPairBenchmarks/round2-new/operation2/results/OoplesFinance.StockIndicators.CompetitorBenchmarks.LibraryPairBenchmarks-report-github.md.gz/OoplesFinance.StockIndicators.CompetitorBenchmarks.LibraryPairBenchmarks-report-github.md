```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tochF [22]** |  **2,101.6 μs** |    **78.16 μs** |    **46.51 μs** |  **1.00** |    **0.03** |  **469.99 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tochF [22] |    308.4 μs |    15.44 μs |     9.19 μs |  0.15 |    0.01 |   97.33 KB |        0.21 |
|            |       |                      |             |             |             |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)tochF [22]** | **18,519.5 μs** | **2,693.80 μs** | **1,603.04 μs** |  **1.01** |    **0.11** | **4644.49 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tochF [22] |    534.0 μs |    12.83 μs |     6.71 μs |  0.03 |    0.00 |  888.34 KB |        0.19 |
