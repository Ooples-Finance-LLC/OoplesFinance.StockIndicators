```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Trix** | **7,506.6 μs** |  **54.15 μs** | **32.23 μs** |  **1.00** |    **0.01** |  **192.99 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Trix |   166.1 μs |  21.56 μs | 14.26 μs |  0.02 |    0.00 |   48.74 KB |        0.25 |
|            |       |                      |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Trix** | **6,121.3 μs** | **152.79 μs** | **90.92 μs** |  **1.00** |    **0.02** | **1897.77 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Trix |   271.3 μs |  18.00 μs | 10.71 μs |  0.04 |    0.00 |  409.09 KB |        0.22 |
