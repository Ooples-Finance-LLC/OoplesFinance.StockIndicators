```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error        | StdDev      | Median      | Ratio | RatioSD | Gen0      | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-------------:|------------:|------------:|------:|--------:|----------:|---------:|---------:|----------:|------------:|
| **BuilderFull**       | **Skender.GetBeta** | **1000**  |  **9,106.9 μs** | **11,660.52 μs** | **7,712.72 μs** |  **4,001.6 μs** | **18.25** |   **14.76** |         **-** |        **-** |        **-** |   **1.29 MB** |        **0.52** |
| BuilderLatestOnly | Skender.GetBeta | 1000  |  1,688.7 μs |     13.69 μs |     7.16 μs |  1,689.7 μs |  3.38 |    0.04 |   78.1250 |  15.6250 |        - |   1.24 MB |        0.50 |
| NativeSingle      | Skender.GetBeta | 1000  |    499.0 μs |      9.79 μs |     5.12 μs |    500.4 μs |  1.00 |    0.01 |  152.3438 |  42.9688 |        - |   2.47 MB |        1.00 |
| NativeParallel    | Skender.GetBeta | 1000  |    340.2 μs |     14.90 μs |     9.86 μs |    340.0 μs |  0.68 |    0.02 |  158.2031 |  46.8750 |        - |    2.5 MB |        1.01 |
|                   |                 |       |             |              |             |             |       |         |           |          |          |           |             |
| **BuilderFull**       | **Skender.GetBeta** | **10000** | **18,792.1 μs** |  **1,429.11 μs** |   **747.45 μs** | **18,846.7 μs** |  **2.55** |    **0.22** |  **800.0000** | **600.0000** |        **-** |  **12.96 MB** |        **0.52** |
| BuilderLatestOnly | Skender.GetBeta | 10000 | 18,550.9 μs |    949.87 μs |   565.25 μs | 18,388.0 μs |  2.52 |    0.21 |  600.0000 | 400.0000 |        - |  12.51 MB |        0.50 |
| NativeSingle      | Skender.GetBeta | 10000 |  7,398.7 μs |    882.15 μs |   583.49 μs |  7,483.0 μs |  1.01 |    0.11 | 1642.8571 | 714.2857 | 142.8571 |  25.13 MB |        1.00 |
| NativeParallel    | Skender.GetBeta | 10000 |  4,626.5 μs |    314.98 μs |   187.44 μs |  4,585.9 μs |  0.63 |    0.05 | 1656.2500 | 781.2500 |  62.5000 |  25.23 MB |        1.00 |
