```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean     | Error    | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |-------------------- |------ |---------:|---------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetElderRay** | **1000**  | **107.4 μs** |  **0.78 μs** | **0.46 μs** |       **-** |       **-** |  **80.65 KB** |
| BuilderLatestOnly | Skender.GetElderRay | 1000  | 101.0 μs |  0.99 μs | 0.65 μs |  1.9531 |       - |     33 KB |
| **BuilderFull**       | **Skender.GetElderRay** | **10000** | **976.6 μs** |  **6.97 μs** | **4.15 μs** | **46.8750** | **23.4375** | **784.15 KB** |
| BuilderLatestOnly | Skender.GetElderRay | 10000 | 969.5 μs | 10.36 μs | 6.85 μs | 15.6250 |       - | 314.31 KB |
