```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetElderRay** | **1000**  |   **103.19 μs** |  **0.548 μs** |  **0.326 μs** |  **1.07** |    **0.02** |        **-** |        **-** |       **-** |   **80.67 KB** |        **0.32** |
| BuilderLatestOnly | Skender.GetElderRay | 1000  |    97.81 μs |  0.951 μs |  0.497 μs |  1.01 |    0.02 |   1.9531 |        - |       - |   33.03 KB |        0.13 |
| NativeSingle      | Skender.GetElderRay | 1000  |    96.61 μs |  3.007 μs |  1.989 μs |  1.00 |    0.03 |  15.1367 |   3.9063 |       - |  251.06 KB |        1.00 |
| NativeParallel    | Skender.GetElderRay | 1000  |   160.83 μs |  4.083 μs |  2.136 μs |  1.67 |    0.04 |  39.0625 |  13.6719 |       - |  637.19 KB |        2.54 |
|                   |                     |       |             |           |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skender.GetElderRay** | **10000** |   **959.35 μs** | **15.362 μs** |  **8.035 μs** |  **0.75** |    **0.02** |  **46.8750** |  **23.4375** |       **-** |  **784.17 KB** |        **0.31** |
| BuilderLatestOnly | Skender.GetElderRay | 10000 |   940.46 μs |  9.557 μs |  5.687 μs |  0.74 |    0.02 |  15.6250 |        - |       - |  314.34 KB |        0.13 |
| NativeSingle      | Skender.GetElderRay | 10000 | 1,272.32 μs | 46.437 μs | 30.715 μs |  1.00 |    0.03 | 148.4375 | 101.5625 | 46.8750 | 2501.48 KB |        1.00 |
| NativeParallel    | Skender.GetElderRay | 10000 | 2,055.71 μs | 48.327 μs | 25.276 μs |  1.62 |    0.04 | 421.8750 | 359.3750 | 78.1250 | 6333.22 KB |        2.53 |
