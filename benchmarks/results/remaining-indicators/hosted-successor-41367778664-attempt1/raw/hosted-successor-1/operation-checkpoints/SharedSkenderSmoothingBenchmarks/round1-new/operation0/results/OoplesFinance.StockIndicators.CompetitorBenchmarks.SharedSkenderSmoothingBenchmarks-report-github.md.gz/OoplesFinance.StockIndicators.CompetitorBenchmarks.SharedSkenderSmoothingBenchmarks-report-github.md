```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |-------------------- |------ |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetElderRay** | **1000**  | **105.01 μs** |  **1.201 μs** | **0.628 μs** |       **-** |       **-** |  **80.67 KB** |
| BuilderLatestOnly | Skender.GetElderRay | 1000  |  98.50 μs |  1.490 μs | 0.887 μs |  1.9531 |       - |  33.02 KB |
| **BuilderFull**       | **Skender.GetElderRay** | **10000** | **957.38 μs** | **11.202 μs** | **5.859 μs** | **46.8750** | **23.4375** | **784.17 KB** |
| BuilderLatestOnly | Skender.GetElderRay | 10000 | 948.67 μs | 16.482 μs | 9.808 μs | 15.6250 |       - | 314.34 KB |
