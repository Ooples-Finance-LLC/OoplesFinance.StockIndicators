```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |------------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |    **989.8 μs** |  **14.26 μs** |   **8.49 μs** |  **68.93 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1,004.9 μs |  31.80 μs |  21.03 μs |  21.36 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **10,724.6 μs** | **246.91 μs** | **146.93 μs** | **631.82 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 11,089.7 μs | 473.57 μs | 313.24 μs | 162.09 KB |
