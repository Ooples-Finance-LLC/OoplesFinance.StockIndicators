```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **1.025 ms** | **0.0182 ms** | **0.0120 ms** |  **84.83 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1.049 ms | 0.0421 ms | 0.0250 ms |  37.25 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **11.091 ms** | **0.1498 ms** | **0.0783 ms** | **788.71 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 11.192 ms | 0.3499 ms | 0.2082 ms | 318.79 KB |
