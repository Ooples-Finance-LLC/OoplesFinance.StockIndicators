```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |------------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |    **993.8 μs** |  **34.01 μs** |  **20.24 μs** |  **68.93 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |    998.7 μs |  38.95 μs |  23.18 μs |  21.39 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **10,803.2 μs** | **221.13 μs** | **146.26 μs** | **632.21 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 10,654.9 μs |  89.17 μs |  46.64 μs | 162.44 KB |
