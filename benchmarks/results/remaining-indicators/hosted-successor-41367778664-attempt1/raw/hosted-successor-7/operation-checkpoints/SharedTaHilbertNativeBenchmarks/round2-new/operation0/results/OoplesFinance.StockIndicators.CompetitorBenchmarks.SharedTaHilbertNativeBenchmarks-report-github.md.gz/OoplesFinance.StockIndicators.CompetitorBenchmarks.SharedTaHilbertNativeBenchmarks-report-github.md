```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **1,074.7 μs** |  **24.05 μs** |  **15.91 μs** |  **2.98** |    **0.04** |  **69.02 KB** |        **8.25** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1,064.7 μs |  29.19 μs |  17.37 μs |  2.95 |    0.05 |  21.35 KB |        2.55 |
| NativeSingle      | TaLib(...)Phase [25] | 1000  |    360.8 μs |   2.36 μs |   1.23 μs |  1.00 |    0.00 |   8.36 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 1000  |    495.6 μs |  49.98 μs |  33.06 μs |  1.37 |    0.09 |  30.17 KB |        3.61 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **11,371.6 μs** | **171.60 μs** |  **89.75 μs** |  **3.00** |    **0.04** | **632.16 KB** |        **8.02** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 11,302.2 μs | 172.65 μs | 102.74 μs |  2.98 |    0.04 | 162.38 KB |        2.06 |
| NativeSingle      | TaLib(...)Phase [25] | 10000 |  3,791.6 μs |  78.71 μs |  41.17 μs |  1.00 |    0.01 |  78.81 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 10000 |  5,009.2 μs | 304.04 μs | 201.10 μs |  1.32 |    0.05 | 276.46 KB |        3.51 |
