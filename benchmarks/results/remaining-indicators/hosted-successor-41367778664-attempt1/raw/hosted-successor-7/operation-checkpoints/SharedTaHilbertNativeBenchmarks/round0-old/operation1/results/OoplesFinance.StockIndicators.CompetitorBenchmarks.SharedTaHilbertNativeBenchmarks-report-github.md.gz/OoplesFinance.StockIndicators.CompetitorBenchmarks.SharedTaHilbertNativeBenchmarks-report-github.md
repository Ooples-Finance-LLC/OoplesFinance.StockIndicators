```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **1.078 ms** | **0.0047 ms** | **0.0028 ms** |  **84.88 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1.065 ms | 0.0093 ms | 0.0049 ms |  37.28 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **11.541 ms** | **0.3095 ms** | **0.1842 ms** | **788.86 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 11.691 ms | 0.5195 ms | 0.2717 ms | 318.53 KB |
