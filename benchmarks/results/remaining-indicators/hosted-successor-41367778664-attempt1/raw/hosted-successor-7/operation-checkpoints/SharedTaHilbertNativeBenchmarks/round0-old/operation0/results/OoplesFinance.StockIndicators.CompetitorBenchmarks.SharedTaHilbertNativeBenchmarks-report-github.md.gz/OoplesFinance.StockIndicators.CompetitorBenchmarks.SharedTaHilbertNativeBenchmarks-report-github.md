```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **1.050 ms** | **0.0271 ms** | **0.0161 ms** |  **68.93 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1.032 ms | 0.0314 ms | 0.0187 ms |  21.36 KB |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **11.412 ms** | **0.1814 ms** | **0.1079 ms** |  **632.3 KB** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 11.779 ms | 0.2662 ms | 0.1584 ms | 162.52 KB |
