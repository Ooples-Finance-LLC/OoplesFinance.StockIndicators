```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **1,001.5 μs** |   **7.58 μs** |   **4.51 μs** |  **2.81** |    **0.02** |       **-** |  **84.91 KB** |        **5.40** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |    984.4 μs |   9.27 μs |   4.85 μs |  2.76 |    0.02 |       - |  37.27 KB |        2.37 |
| NativeSingle      | TaLib(...)tSine [22] | 1000  |    356.9 μs |   4.64 μs |   2.43 μs |  1.00 |    0.01 |       - |  15.72 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 1000  |    486.7 μs |  22.78 μs |  13.55 μs |  1.36 |    0.04 |  3.9063 |  55.94 KB |        3.56 |
|                   |                      |       |             |           |           |       |         |         |           |             |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **10,724.7 μs** | **326.79 μs** | **194.47 μs** |  **2.82** |    **0.06** |       **-** | **788.99 KB** |        **5.04** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 10,999.7 μs | 356.67 μs | 235.92 μs |  2.89 |    0.07 |       - | 319.01 KB |        2.04 |
| NativeSingle      | TaLib(...)tSine [22] | 10000 |  3,805.9 μs |  66.84 μs |  39.78 μs |  1.00 |    0.01 |       - | 156.56 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 10000 |  5,379.9 μs | 410.54 μs | 271.54 μs |  1.41 |    0.07 | 31.2500 | 548.35 KB |        3.50 |
