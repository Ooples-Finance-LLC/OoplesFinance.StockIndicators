```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |------------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **1,013.6 μs** |  **51.82 μs** |  **30.84 μs** |  **84.83 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |    989.9 μs |  11.46 μs |   6.82 μs |  37.26 KB |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **11,033.0 μs** | **536.57 μs** | **354.91 μs** | **788.34 KB** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 10,983.3 μs | 218.42 μs | 129.98 μs | 318.53 KB |
