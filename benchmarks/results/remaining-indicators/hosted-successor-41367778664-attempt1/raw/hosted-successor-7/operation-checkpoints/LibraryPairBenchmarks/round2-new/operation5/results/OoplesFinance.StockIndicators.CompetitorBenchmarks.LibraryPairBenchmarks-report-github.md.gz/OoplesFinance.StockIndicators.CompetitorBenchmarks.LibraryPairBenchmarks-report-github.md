```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDM [23]** |   **464.40 μs** | **41.224 μs** | **27.267 μs** |  **1.00** |    **0.08** |  **105.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDM [23] |    82.97 μs | 10.816 μs |  7.154 μs |  0.18 |    0.02 |   38.95 KB |        0.37 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDM [23]** | **5,908.02 μs** | **49.236 μs** | **32.567 μs** |  **1.00** |    **0.01** | **1034.75 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDM [23] |   181.80 μs |  6.105 μs |  4.038 μs |  0.03 |    0.00 |  325.66 KB |        0.31 |
