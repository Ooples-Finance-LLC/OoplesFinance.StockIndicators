```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)cdExt [23]** |  **1,366.4 μs** |    **30.69 μs** |    **18.27 μs** |  **1.00** |    **0.02** |   **752.1 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)cdExt [23] |    133.7 μs |    10.30 μs |     6.81 μs |  0.10 |    0.00 |  121.54 KB |        0.16 |
|            |       |                      |             |             |             |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)cdExt [23]** | **17,817.7 μs** | **5,743.60 μs** | **3,417.92 μs** |  **1.03** |    **0.25** | **7316.02 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)cdExt [23] |    209.2 μs |     8.86 μs |     5.27 μs |  0.01 |    0.00 | 1130.31 KB |        0.15 |
