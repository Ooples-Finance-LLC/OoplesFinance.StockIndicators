```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDI [23]** |   **699.7 μs** |  **21.30 μs** |  **12.68 μs** |  **1.00** |    **0.02** |  **105.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDI [23] |   110.5 μs |   7.15 μs |   4.73 μs |  0.16 |    0.01 |   40.27 KB |        0.38 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDI [23]** | **8,421.0 μs** | **283.07 μs** | **187.23 μs** |  **1.00** |    **0.03** | **1035.13 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDI [23] |   216.2 μs |   9.59 μs |   5.71 μs |  0.03 |    0.00 |  329.61 KB |        0.32 |
