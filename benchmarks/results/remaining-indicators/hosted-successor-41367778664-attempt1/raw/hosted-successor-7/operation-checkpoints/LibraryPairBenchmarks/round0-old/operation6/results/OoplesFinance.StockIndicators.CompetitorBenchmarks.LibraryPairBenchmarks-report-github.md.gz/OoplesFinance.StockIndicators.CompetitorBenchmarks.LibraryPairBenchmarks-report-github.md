```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean       | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |-----------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)lusDI [22]** |   **745.4 μs** |    **15.36 μs** |     **9.14 μs** |  **1.00** |    **0.02** |  **105.71 KB** |        **1.00** |
|        |       |                      |            |             |             |       |         |            |             |
| **Ooples** | **10000** | **TaLib(...)lusDI [22]** | **9,890.2 μs** | **3,180.00 μs** | **2,103.38 μs** |  **1.04** |    **0.31** | **1035.41 KB** |        **1.00** |
