```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |-----------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)lusDI [22]** |   **748.6 μs** |    **66.08 μs** |  **43.71 μs** |  **1.00** |    **0.08** |  **105.71 KB** |        **1.00** |
|        |       |                      |            |             |           |       |         |            |             |
| **Ooples** | **10000** | **TaLib(...)lusDI [22]** | **7,808.7 μs** | **1,547.60 μs** | **809.42 μs** |  **1.01** |    **0.14** | **1036.11 KB** |        **1.00** |
