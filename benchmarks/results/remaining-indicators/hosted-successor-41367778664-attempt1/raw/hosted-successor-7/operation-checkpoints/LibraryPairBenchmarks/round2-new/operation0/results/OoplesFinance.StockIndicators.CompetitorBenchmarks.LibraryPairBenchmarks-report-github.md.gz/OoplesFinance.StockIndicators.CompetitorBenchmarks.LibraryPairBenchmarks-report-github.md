```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Macd** |  **1,922.2 μs** |  **34.13 μs** |  **17.85 μs** |  **1.00** |    **0.01** |  **203.19 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Macd |    138.1 μs |   6.87 μs |   4.54 μs |  0.07 |    0.00 |  121.03 KB |        0.60 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Macd** | **19,470.7 μs** | **987.36 μs** | **516.41 μs** | **1.001** |    **0.04** | **1991.59 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Macd |    166.8 μs |   7.33 μs |   4.36 μs | 0.009 |    0.00 |  1125.3 KB |        0.57 |
