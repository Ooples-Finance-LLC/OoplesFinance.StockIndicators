```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)cdFix [23]** |  **2,173.9 μs** |    **32.26 μs** |    **19.20 μs** |  **1.00** |    **0.01** |  **203.25 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)cdFix [23] |    136.6 μs |    13.31 μs |     8.81 μs |  0.06 |    0.00 |  118.78 KB |        0.58 |
|            |       |                      |             |             |             |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)cdFix [23]** | **23,674.5 μs** | **4,679.11 μs** | **3,094.94 μs** |  **1.01** |    **0.17** | **1995.59 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)cdFix [23] |    250.8 μs |    12.67 μs |     7.54 μs |  0.01 |    0.00 | 1128.21 KB |        0.57 |
