```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Mavp** |   **267.9 μs** | **18.41 μs** | **10.95 μs** |  **1.00** |    **0.05** |  **107.52 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Mavp |   139.7 μs |  6.92 μs |  4.12 μs |  0.52 |    0.02 |   57.53 KB |        0.54 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Mavp** | **1,856.4 μs** | **10.66 μs** |  **5.58 μs** |  **1.00** |    **0.00** | **1037.22 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Mavp |   395.5 μs |  9.62 μs |  5.72 μs |  0.21 |    0.00 |  523.35 KB |        0.50 |
