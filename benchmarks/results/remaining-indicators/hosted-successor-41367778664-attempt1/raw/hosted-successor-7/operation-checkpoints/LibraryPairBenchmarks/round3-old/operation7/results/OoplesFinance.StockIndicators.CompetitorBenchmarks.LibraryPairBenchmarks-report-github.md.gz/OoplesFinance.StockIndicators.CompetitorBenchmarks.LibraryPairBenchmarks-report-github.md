```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean       | Error      | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |-----------:|-----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)lusDM [22]** |   **608.5 μs** |   **226.6 μs** | **149.9 μs** |  **1.06** |    **0.36** |  **105.71 KB** |        **1.00** |
|        |       |                      |            |            |          |       |         |            |             |
| **Ooples** | **10000** | **TaLib(...)lusDM [22]** | **6,314.6 μs** | **1,057.7 μs** | **629.4 μs** |  **1.01** |    **0.13** | **1034.09 KB** |        **1.00** |
