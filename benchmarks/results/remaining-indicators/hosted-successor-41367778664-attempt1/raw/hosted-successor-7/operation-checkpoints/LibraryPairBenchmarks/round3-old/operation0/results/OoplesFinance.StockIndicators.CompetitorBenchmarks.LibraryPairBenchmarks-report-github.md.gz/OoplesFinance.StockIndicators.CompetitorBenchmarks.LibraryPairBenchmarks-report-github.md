```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |----------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Macd** |  **2.166 ms** | **0.0193 ms** | **0.0115 ms** |  **1.00** |  **203.19 KB** |        **1.00** |
|        |       |                      |           |           |           |       |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Macd** | **21.509 ms** | **0.3241 ms** | **0.1929 ms** |  **1.00** | **1995.52 KB** |        **1.00** |
