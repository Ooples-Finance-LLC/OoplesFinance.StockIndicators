```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)cdFix [23]** |  **2.175 ms** | **0.0432 ms** | **0.0257 ms** |  **1.00** |    **0.02** | **203.25 KB** |        **1.00** |
|        |       |                      |           |           |           |       |         |           |             |
| **Ooples** | **10000** | **TaLib(...)cdFix [23]** | **21.983 ms** | **1.7619 ms** | **0.9215 ms** |  **1.00** |    **0.06** | **1994.7 KB** |        **1.00** |
