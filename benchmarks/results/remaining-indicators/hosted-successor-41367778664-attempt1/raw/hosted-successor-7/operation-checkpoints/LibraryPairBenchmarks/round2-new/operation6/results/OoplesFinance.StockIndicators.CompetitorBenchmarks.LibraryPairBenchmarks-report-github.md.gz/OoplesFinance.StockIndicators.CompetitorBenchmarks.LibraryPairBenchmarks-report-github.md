```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDI [22]** |   **689.7 μs** | **21.66 μs** | **12.89 μs** |  **1.00** |    **0.03** |  **105.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDI [22] |   108.2 μs |  7.27 μs |  4.33 μs |  0.16 |    0.01 |    37.6 KB |        0.36 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDI [22]** | **5,866.1 μs** | **51.76 μs** | **27.07 μs** |  **1.00** |    **0.01** | **1037.05 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDI [22] |   212.8 μs |  3.82 μs |  2.27 μs |  0.04 |    0.00 |   328.3 KB |        0.32 |
