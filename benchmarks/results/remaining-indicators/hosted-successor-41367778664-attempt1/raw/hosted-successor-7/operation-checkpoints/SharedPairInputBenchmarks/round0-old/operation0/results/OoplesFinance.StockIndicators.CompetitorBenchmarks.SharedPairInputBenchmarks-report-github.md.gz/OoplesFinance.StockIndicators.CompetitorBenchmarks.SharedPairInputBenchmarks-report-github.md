```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **255.7 μs** |  **28.26 μs** |  **16.82 μs** |  **3.9063** |       **-** |  **69.23 KB** |
| BuilderLatestOnly | 1000  | Beta      |   212.9 μs |  10.23 μs |   5.35 μs |       - |       - |  21.66 KB |
| **BuilderFull**       | **10000** | **Beta**      | **2,153.0 μs** | **166.98 μs** |  **99.37 μs** | **31.2500** | **15.6250** | **632.09 KB** |
| BuilderLatestOnly | 10000 | Beta      | 2,193.0 μs | 182.57 μs | 120.76 μs |       - |       - | 162.28 KB |
