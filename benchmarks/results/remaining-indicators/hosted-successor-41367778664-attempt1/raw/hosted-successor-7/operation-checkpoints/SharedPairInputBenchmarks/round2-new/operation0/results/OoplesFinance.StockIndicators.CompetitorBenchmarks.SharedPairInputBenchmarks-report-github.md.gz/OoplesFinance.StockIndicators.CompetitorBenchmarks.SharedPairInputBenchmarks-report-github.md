```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-------------:|------------:|------------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **209.724 μs** |   **2.3989 μs** |   **1.4275 μs** | **41.21** |    **0.90** |       **-** |       **-** |  **69.26 KB** |        **8.98** |
| BuilderLatestOnly | 1000  | Beta      |   217.204 μs |  19.0338 μs |  12.5896 μs | 42.68 |    2.52 |       - |       - |  21.65 KB |        2.81 |
| NativeSingle      | 1000  | Beta      |     5.092 μs |   0.1691 μs |   0.1118 μs |  1.00 |    0.03 |  0.4578 |       - |   7.71 KB |        1.00 |
| NativeParallel    | 1000  | Beta      |     4.139 μs |   1.0607 μs |   0.7016 μs |  0.81 |    0.13 |  0.4883 |       - |   7.98 KB |        1.03 |
|                   |       |           |              |             |             |       |         |         |         |           |             |
| **BuilderFull**       | **10000** | **Beta**      | **2,317.754 μs** | **171.8685 μs** | **102.2762 μs** | **47.43** |    **2.23** | **31.2500** | **15.6250** | **632.16 KB** |        **8.10** |
| BuilderLatestOnly | 10000 | Beta      | 2,274.039 μs | 158.3917 μs | 104.7663 μs | 46.53 |    2.28 |       - |       - | 162.33 KB |        2.08 |
| NativeSingle      | 10000 | Beta      |    48.892 μs |   1.6702 μs |   1.1047 μs |  1.00 |    0.03 |  4.3945 |  0.4883 |  78.02 KB |        1.00 |
| NativeParallel    | 10000 | Beta      |    33.842 μs |   3.9038 μs |   2.5821 μs |  0.69 |    0.05 |  4.6387 |  0.7324 |  78.29 KB |        1.00 |
