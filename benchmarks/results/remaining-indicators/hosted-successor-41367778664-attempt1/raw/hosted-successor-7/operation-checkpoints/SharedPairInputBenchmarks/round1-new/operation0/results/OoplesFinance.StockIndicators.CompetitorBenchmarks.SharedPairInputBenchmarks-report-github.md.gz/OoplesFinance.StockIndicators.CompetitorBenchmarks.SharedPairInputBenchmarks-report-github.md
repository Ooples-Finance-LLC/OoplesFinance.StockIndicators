```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **305.8 μs** |   **3.59 μs** |   **2.13 μs** |       **-** |       **-** |  **69.36 KB** |
| BuilderLatestOnly | 1000  | Beta      |   219.1 μs |  19.18 μs |  12.69 μs |       - |       - |  21.65 KB |
| **BuilderFull**       | **10000** | **Beta**      | **2,102.2 μs** | **140.98 μs** |  **83.90 μs** | **31.2500** | **15.6250** | **632.15 KB** |
| BuilderLatestOnly | 10000 | Beta      | 2,224.5 μs | 236.19 μs | 156.23 μs |       - |       - | 162.33 KB |
