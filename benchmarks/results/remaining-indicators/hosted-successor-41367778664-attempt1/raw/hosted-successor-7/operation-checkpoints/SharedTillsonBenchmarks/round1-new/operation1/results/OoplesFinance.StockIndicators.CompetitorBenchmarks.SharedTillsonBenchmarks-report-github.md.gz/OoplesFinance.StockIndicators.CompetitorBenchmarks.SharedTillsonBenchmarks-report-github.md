```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error     | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |------------------- |------ |----------:|----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib.Functions.T3** | **1000**  |  **95.23 μs** |  **1.291 μs** |  **0.768 μs** |  **3.9063** |      **-** |  **65.14 KB** |
| BuilderLatestOnly | TaLib.Functions.T3 | 1000  |  90.21 μs |  2.335 μs |  1.390 μs |  0.9766 |      - |  17.57 KB |
| **BuilderFull**       | **TaLib.Functions.T3** | **10000** | **981.74 μs** | **75.436 μs** | **49.896 μs** | **31.2500** | **7.8125** | **628.01 KB** |
| BuilderLatestOnly | TaLib.Functions.T3 | 10000 | 943.87 μs | 39.168 μs | 23.308 μs |  7.8125 |      - | 158.23 KB |
