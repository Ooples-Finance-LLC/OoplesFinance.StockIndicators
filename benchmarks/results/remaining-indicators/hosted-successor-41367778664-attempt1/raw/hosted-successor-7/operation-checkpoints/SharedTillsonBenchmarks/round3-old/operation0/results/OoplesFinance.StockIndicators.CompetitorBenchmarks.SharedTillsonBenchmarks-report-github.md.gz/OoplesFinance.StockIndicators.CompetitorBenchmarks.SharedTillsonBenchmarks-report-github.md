```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation     | Count | Mean      | Error     | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |-------------- |------ |----------:|----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetT3** | **1000**  |  **99.01 μs** |  **1.907 μs** |  **1.135 μs** |  **3.9063** |      **-** |  **65.17 KB** |
| BuilderLatestOnly | Skender.GetT3 | 1000  |  97.13 μs |  2.532 μs |  1.675 μs |  0.9766 |      - |  17.57 KB |
| **BuilderFull**       | **Skender.GetT3** | **10000** | **951.22 μs** | **15.804 μs** | **10.453 μs** | **31.2500** | **7.8125** | **628.03 KB** |
| BuilderLatestOnly | Skender.GetT3 | 10000 | 942.03 μs | 22.127 μs | 14.636 μs |  7.8125 |      - |  158.2 KB |
