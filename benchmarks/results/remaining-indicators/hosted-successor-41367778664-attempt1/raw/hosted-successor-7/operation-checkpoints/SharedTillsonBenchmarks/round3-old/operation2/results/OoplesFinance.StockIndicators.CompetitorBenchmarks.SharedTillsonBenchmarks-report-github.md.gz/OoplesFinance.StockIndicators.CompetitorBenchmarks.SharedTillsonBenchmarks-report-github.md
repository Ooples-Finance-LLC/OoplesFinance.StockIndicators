```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation    | Count | Mean      | Error     | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |------------- |------ |----------:|----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **QuanTAlib.T3** | **1000**  | **100.51 μs** |  **1.993 μs** |  **1.186 μs** |  **3.9063** |      **-** |  **65.17 KB** |
| BuilderLatestOnly | QuanTAlib.T3 | 1000  |  98.48 μs |  2.016 μs |  1.054 μs |  0.9766 |      - |  17.57 KB |
| **BuilderFull**       | **QuanTAlib.T3** | **10000** | **964.28 μs** | **24.657 μs** | **16.309 μs** | **31.2500** | **7.8125** | **628.03 KB** |
| BuilderLatestOnly | QuanTAlib.T3 | 10000 | 942.33 μs | 21.267 μs | 12.656 μs |  7.8125 |      - |  158.2 KB |
