```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean         | Error       | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |-------------:|------------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.T3** | **1000**  |   **103.134 μs** |   **3.1110 μs** |  **1.8513 μs** | **36.86** |    **1.17** |  **3.9063** |      **-** |  **65.18 KB** |        **9.34** |
| BuilderLatestOnly | TaLib.Functions.T3 | 1000  |    92.331 μs |   2.8317 μs |  1.8730 μs | 33.00 |    1.09 |  0.9766 |      - |  17.57 KB |        2.52 |
| NativeSingle      | TaLib.Functions.T3 | 1000  |     2.800 μs |   0.1200 μs |  0.0793 μs |  1.00 |    0.04 |  0.4120 |      - |   6.98 KB |        1.00 |
| NativeParallel    | TaLib.Functions.T3 | 1000  |     5.712 μs |   0.2594 μs |  0.1716 μs |  2.04 |    0.08 |  1.8311 | 0.0610 |  24.66 KB |        3.53 |
|                   |                    |       |              |             |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.T3** | **10000** | **1,013.177 μs** | **136.0826 μs** | **71.1738 μs** | **35.95** |    **2.78** | **31.2500** |      **-** | **628.04 KB** |        **8.13** |
| BuilderLatestOnly | TaLib.Functions.T3 | 10000 |   981.413 μs |  13.3530 μs |  7.9461 μs | 34.82 |    1.42 |  7.8125 |      - | 158.21 KB |        2.05 |
| NativeSingle      | TaLib.Functions.T3 | 10000 |    28.226 μs |   1.7696 μs |  1.1705 μs |  1.00 |    0.06 |  4.6387 |      - |  77.29 KB |        1.00 |
| NativeParallel    | TaLib.Functions.T3 | 10000 |    54.788 μs |   3.6823 μs |  2.4356 μs |  1.94 |    0.11 | 18.0664 | 4.3945 | 270.75 KB |        3.50 |
