```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation    | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Gen2   | Allocated  | Alloc Ratio |
|------------------ |------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|-------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.T3** | **1000**  | **105.60 μs** |  **4.388 μs** |  **2.903 μs** |  **6.64** |    **0.20** |  **3.9063** |       **-** |      **-** |   **65.18 KB** |        **1.34** |
| BuilderLatestOnly | QuanTAlib.T3 | 1000  |  99.68 μs |  3.661 μs |  2.179 μs |  6.27 |    0.16 |  0.9766 |       - |      - |   17.57 KB |        0.36 |
| NativeSingle      | QuanTAlib.T3 | 1000  |  15.89 μs |  0.443 μs |  0.232 μs |  1.00 |    0.02 |  3.0518 |  0.2441 | 0.2441 |   48.69 KB |        1.00 |
| NativeParallel    | QuanTAlib.T3 | 1000  |  46.30 μs |  2.635 μs |  1.743 μs |  2.91 |    0.11 |  6.8359 |  1.2207 | 1.2207 |  112.85 KB |        2.32 |
|                   |              |       |           |           |           |       |         |         |         |        |            |             |
| **BuilderFull**       | **QuanTAlib.T3** | **10000** | **986.92 μs** | **40.570 μs** | **21.219 μs** |  **7.48** |    **0.33** | **31.2500** |  **7.8125** |      **-** |  **628.04 KB** |        **1.33** |
| BuilderLatestOnly | QuanTAlib.T3 | 10000 | 988.85 μs |  9.481 μs |  5.642 μs |  7.50 |    0.30 |  7.8125 |       - |      - |  158.26 KB |        0.34 |
| NativeSingle      | QuanTAlib.T3 | 10000 | 132.09 μs |  8.411 μs |  5.563 μs |  1.00 |    0.06 | 28.3203 |  4.8828 |      - |  470.56 KB |        1.00 |
| NativeParallel    | QuanTAlib.T3 | 10000 | 196.89 μs | 12.579 μs |  8.320 μs |  1.49 |    0.08 | 65.4297 | 13.6719 | 0.9766 | 1062.08 KB |        2.26 |
