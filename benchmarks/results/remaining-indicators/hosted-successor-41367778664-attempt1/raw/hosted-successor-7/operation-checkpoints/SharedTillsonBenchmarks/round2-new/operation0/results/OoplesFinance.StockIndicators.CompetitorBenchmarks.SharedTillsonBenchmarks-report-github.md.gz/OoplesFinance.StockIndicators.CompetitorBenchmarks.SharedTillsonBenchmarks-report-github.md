```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation     | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |-------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetT3** | **1000**  |   **102.49 μs** |   **3.327 μs** |   **1.980 μs** |  **4.07** |    **0.12** |   **3.9063** |        **-** |        **-** |   **65.18 KB** |        **0.72** |
| BuilderLatestOnly | Skender.GetT3 | 1000  |    97.32 μs |   2.957 μs |   1.956 μs |  3.87 |    0.12 |   0.9766 |        - |        - |   17.57 KB |        0.19 |
| NativeSingle      | Skender.GetT3 | 1000  |    25.19 μs |   0.925 μs |   0.612 μs |  1.00 |    0.03 |   5.3711 |   0.7324 |        - |   90.24 KB |        1.00 |
| NativeParallel    | Skender.GetT3 | 1000  |    55.75 μs |   1.790 μs |   1.184 μs |  2.21 |    0.07 |  15.6250 |   3.9063 |        - |  234.42 KB |        2.60 |
|                   |               |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetT3** | **10000** |   **954.84 μs** |  **20.311 μs** |  **12.087 μs** |  **2.65** |    **0.07** |  **31.2500** |   **7.8125** |        **-** |  **628.03 KB** |        **0.70** |
| BuilderLatestOnly | Skender.GetT3 | 10000 |   943.87 μs |  29.449 μs |  19.478 μs |  2.62 |    0.08 |   7.8125 |        - |        - |  158.23 KB |        0.18 |
| NativeSingle      | Skender.GetT3 | 10000 |   360.07 μs |  16.027 μs |   9.538 μs |  1.00 |    0.04 | 119.1406 |  93.7500 |  83.9844 |   899.9 KB |        1.00 |
| NativeParallel    | Skender.GetT3 | 10000 | 1,801.01 μs | 590.268 μs | 390.425 μs |  5.00 |    1.04 | 250.0000 | 187.5000 | 140.6250 | 2329.17 KB |        2.59 |
