```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation     | Count | Mean      | Error     | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |-------------- |------ |----------:|----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetT3** | **1000**  |  **99.79 μs** |  **2.875 μs** |  **1.711 μs** |  **3.9063** |      **-** |  **65.18 KB** |
| BuilderLatestOnly | Skender.GetT3 | 1000  |  98.93 μs |  2.645 μs |  1.574 μs |  0.9766 |      - |  17.57 KB |
| **BuilderFull**       | **Skender.GetT3** | **10000** | **959.39 μs** | **18.719 μs** | **12.382 μs** | **31.2500** | **7.8125** | **628.05 KB** |
| BuilderLatestOnly | Skender.GetT3 | 10000 | 965.37 μs | 47.847 μs | 31.648 μs |  7.8125 |      - | 158.23 KB |
