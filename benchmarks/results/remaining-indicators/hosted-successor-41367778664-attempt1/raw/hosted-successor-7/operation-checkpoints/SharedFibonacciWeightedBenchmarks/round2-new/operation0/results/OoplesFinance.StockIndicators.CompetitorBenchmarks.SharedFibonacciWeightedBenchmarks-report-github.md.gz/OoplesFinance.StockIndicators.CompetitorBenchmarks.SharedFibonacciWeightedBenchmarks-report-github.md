```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |----------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Fwma** | **1000**  |  **39.00 μs** |  **6.274 μs** |  **4.150 μs** |  **0.87** |    **0.09** |   **2.9297** |       **-** |   **60.35 KB** |        **0.24** |
| BuilderLatestOnly | QuanTAlib.Fwma | 1000  |  31.13 μs |  2.921 μs |  1.738 μs |  0.69 |    0.04 |   0.7324 |       - |   12.46 KB |        0.05 |
| NativeSingle      | QuanTAlib.Fwma | 1000  |  45.06 μs |  1.458 μs |  0.964 μs |  1.00 |    0.03 |  15.3809 |  0.4883 |   254.5 KB |        1.00 |
| NativeParallel    | QuanTAlib.Fwma | 1000  |  38.76 μs |  3.125 μs |  2.067 μs |  0.86 |    0.05 |  16.1133 |  0.4883 |   262.7 KB |        1.03 |
|                   |                |       |           |           |           |       |         |          |         |            |             |
| **BuilderFull**       | **QuanTAlib.Fwma** | **10000** | **261.13 μs** | **44.166 μs** | **29.213 μs** |  **0.62** |    **0.07** |  **33.2031** | **13.6719** |  **552.89 KB** |        **0.22** |
| BuilderLatestOnly | QuanTAlib.Fwma | 10000 | 218.34 μs | 58.901 μs | 38.959 μs |  0.51 |    0.09 |   3.9063 |       - |   82.79 KB |        0.03 |
| NativeSingle      | QuanTAlib.Fwma | 10000 | 424.59 μs |  7.919 μs |  4.142 μs |  1.00 |    0.01 | 156.2500 | 31.2500 | 2564.27 KB |        1.00 |
| NativeParallel    | QuanTAlib.Fwma | 10000 | 279.77 μs | 19.749 μs | 11.752 μs |  0.66 |    0.03 | 158.2031 | 31.2500 | 2572.65 KB |        1.00 |
