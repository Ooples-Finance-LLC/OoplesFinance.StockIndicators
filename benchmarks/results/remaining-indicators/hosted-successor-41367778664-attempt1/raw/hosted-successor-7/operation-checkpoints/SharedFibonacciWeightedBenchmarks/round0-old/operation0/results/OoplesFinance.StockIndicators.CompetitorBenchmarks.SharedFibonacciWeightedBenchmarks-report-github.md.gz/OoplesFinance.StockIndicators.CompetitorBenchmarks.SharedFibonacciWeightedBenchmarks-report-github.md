```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Fwma** | **1000**  |  **37.06 μs** |  **7.706 μs** |  **4.586 μs** |  **2.9297** |       **-** |  **60.35 KB** |
| BuilderLatestOnly | QuanTAlib.Fwma | 1000  |  31.99 μs |  3.217 μs |  2.128 μs |  0.7324 |       - |  12.46 KB |
| **BuilderFull**       | **QuanTAlib.Fwma** | **10000** | **220.14 μs** | **34.248 μs** | **20.380 μs** | **33.2031** | **13.6719** |  **552.9 KB** |
| BuilderLatestOnly | QuanTAlib.Fwma | 10000 | 219.20 μs | 49.062 μs | 32.452 μs |  3.9063 |       - |  82.79 KB |
