```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Fwma** | **1000**  |  **36.54 μs** |  **7.084 μs** |  **4.686 μs** |  **2.9297** |       **-** |  **60.35 KB** |
| BuilderLatestOnly | QuanTAlib.Fwma | 1000  |  32.21 μs |  3.554 μs |  2.115 μs |  0.7324 |       - |  12.46 KB |
| **BuilderFull**       | **QuanTAlib.Fwma** | **10000** | **234.40 μs** | **43.804 μs** | **28.974 μs** | **33.2031** | **13.6719** | **552.88 KB** |
| BuilderLatestOnly | QuanTAlib.Fwma | 10000 | 232.37 μs | 46.557 μs | 30.794 μs |  3.9063 |       - |  82.79 KB |
