```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetCci** | **1000**  |   **345.3 μs** | **91.66 μs** | **47.94 μs** |       **-** |       **-** |  **66.78 KB** |
| BuilderLatestOnly | Skender.GetCci | 1000  |   209.3 μs | 13.44 μs |  8.89 μs |       - |       - |  19.13 KB |
| **BuilderFull**       | **Skender.GetCci** | **10000** | **1,637.4 μs** | **22.62 μs** | **11.83 μs** | **31.2500** | **15.6250** |  **629.7 KB** |
| BuilderLatestOnly | Skender.GetCci | 10000 | 1,605.8 μs | 25.44 μs | 13.31 μs |       - |       - | 159.87 KB |
