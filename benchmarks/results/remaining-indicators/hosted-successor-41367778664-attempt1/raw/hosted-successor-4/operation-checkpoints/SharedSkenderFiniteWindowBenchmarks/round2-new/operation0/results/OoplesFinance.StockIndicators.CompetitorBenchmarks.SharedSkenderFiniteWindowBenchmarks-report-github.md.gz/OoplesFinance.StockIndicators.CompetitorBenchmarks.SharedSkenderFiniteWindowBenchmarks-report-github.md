```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetCci** | **1000**  |   **352.33 μs** | **167.088 μs** | **110.518 μs** |  **4.06** |    **1.22** |       **-** |       **-** |   **66.74 KB** |        **0.46** |
| BuilderLatestOnly | Skender.GetCci | 1000  |   215.87 μs |   8.401 μs |   5.557 μs |  2.49 |    0.07 |       - |       - |   19.13 KB |        0.13 |
| NativeSingle      | Skender.GetCci | 1000  |    86.74 μs |   1.435 μs |   0.854 μs |  1.00 |    0.01 |  8.7891 |  1.9531 |  145.01 KB |        1.00 |
| NativeParallel    | Skender.GetCci | 1000  |    66.35 μs |   3.551 μs |   2.349 μs |  0.77 |    0.03 |  9.7656 |  1.9531 |  162.64 KB |        1.12 |
|                   |                |       |             |            |            |       |         |         |         |            |             |
| **BuilderFull**       | **Skender.GetCci** | **10000** | **1,746.75 μs** | **231.353 μs** | **153.026 μs** |  **1.82** |    **0.15** | **31.2500** |       **-** |  **629.71 KB** |        **0.44** |
| BuilderLatestOnly | Skender.GetCci | 10000 | 1,620.24 μs |  17.241 μs |   9.018 μs |  1.69 |    0.01 |       - |       - |  159.87 KB |        0.11 |
| NativeSingle      | Skender.GetCci | 10000 |   960.40 μs |  12.124 μs |   7.215 μs |  1.00 |    0.01 | 85.9375 | 39.0625 | 1445.83 KB |        1.00 |
| NativeParallel    | Skender.GetCci | 10000 |   575.77 μs |  37.887 μs |  25.060 μs |  0.60 |    0.03 | 97.6563 | 39.0625 | 1533.76 KB |        1.06 |
