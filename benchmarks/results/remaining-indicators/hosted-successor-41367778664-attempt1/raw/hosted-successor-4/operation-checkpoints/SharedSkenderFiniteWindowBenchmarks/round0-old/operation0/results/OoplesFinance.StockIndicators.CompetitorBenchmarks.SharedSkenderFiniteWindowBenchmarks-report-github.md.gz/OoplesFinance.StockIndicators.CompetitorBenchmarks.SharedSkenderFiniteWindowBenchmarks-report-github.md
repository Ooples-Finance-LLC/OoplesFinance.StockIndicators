```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetCci** | **1000**  |   **469.6 μs** | **76.76 μs** | **50.77 μs** |       **-** |       **-** |  **66.78 KB** |
| BuilderLatestOnly | Skender.GetCci | 1000  |   217.6 μs | 10.32 μs |  6.82 μs |       - |       - |  19.13 KB |
| **BuilderFull**       | **Skender.GetCci** | **10000** | **1,660.6 μs** | **42.62 μs** | **22.29 μs** | **31.2500** | **15.6250** | **629.69 KB** |
| BuilderLatestOnly | Skender.GetCci | 10000 | 1,629.2 μs | 17.90 μs |  9.36 μs |       - |       - | 159.86 KB |
