```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)Bands [21]** | **2,566.4 μs** |    **28.31 μs** |    **16.85 μs** |  **1.00** |    **0.01** |  **219.61 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)Bands [21] |   988.6 μs |    40.50 μs |    24.10 μs |  0.39 |    0.01 |  419.91 KB |        1.91 |
|            |       |                      |            |             |             |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)Bands [21]** | **5,126.0 μs** | **1,840.95 μs** | **1,217.67 μs** |  **1.06** |    **0.36** |  **2152.9 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)Bands [21] | 1,664.0 μs |    83.97 μs |    49.97 μs |  0.34 |    0.08 | 4102.48 KB |        1.91 |
