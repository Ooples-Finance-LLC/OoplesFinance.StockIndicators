```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId           | Mean        | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |----------------- |------------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetRocWb** |  **4,214.8 μs** |    **67.25 μs** |    **44.48 μs** |  **1.00** |    **0.01** |  **172.63 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetRocWb |    811.2 μs |    33.26 μs |    19.79 μs |  0.19 |    0.00 |  275.74 KB |        1.60 |
|            |       |                  |             |             |             |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetRocWb** | **40,700.2 μs** | **7,330.05 μs** | **4,848.37 μs** |  **1.01** |    **0.16** | **1692.51 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetRocWb |  7,436.3 μs | 1,690.06 μs | 1,117.87 μs |  0.18 |    0.03 | 2666.65 KB |        1.58 |
