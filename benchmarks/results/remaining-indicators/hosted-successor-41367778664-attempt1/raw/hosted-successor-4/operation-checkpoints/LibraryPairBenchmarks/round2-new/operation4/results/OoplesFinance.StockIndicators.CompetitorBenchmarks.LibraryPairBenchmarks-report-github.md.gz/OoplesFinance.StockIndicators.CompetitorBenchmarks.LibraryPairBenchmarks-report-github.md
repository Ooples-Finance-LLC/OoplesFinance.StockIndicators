```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)lysis [22]** | **5,141.4 μs** |   **658.28 μs** | **435.41 μs** |  **1.01** |    **0.12** |  **298.85 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)lysis [22] |   755.8 μs |    29.75 μs |  17.70 μs |  0.15 |    0.01 |  291.85 KB |        0.98 |
|            |       |                      |            |             |           |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)lysis [22]** | **4,682.1 μs** | **1,329.66 μs** | **879.49 μs** |  **1.03** |    **0.26** | **2876.71 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)lysis [22] | 1,405.7 μs |   133.59 μs |  88.36 μs |  0.31 |    0.06 |  2823.1 KB |        0.98 |
