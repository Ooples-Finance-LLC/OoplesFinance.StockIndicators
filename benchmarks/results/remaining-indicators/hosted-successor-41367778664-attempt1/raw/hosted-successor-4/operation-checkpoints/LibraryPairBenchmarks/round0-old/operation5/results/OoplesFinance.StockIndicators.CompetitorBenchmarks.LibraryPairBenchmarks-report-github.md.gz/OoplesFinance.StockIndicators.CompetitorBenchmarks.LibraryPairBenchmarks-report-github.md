```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean      | Error      | StdDev    | Median    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |----------:|-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skend(...)Bands [21]** |  **2.449 ms** |  **0.0342 ms** | **0.0204 ms** |  **2.449 ms** |  **1.00** |    **0.01** |  **219.57 KB** |        **1.00** |
|        |       |                      |           |            |           |           |       |         |            |             |
| **Ooples** | **10000** | **Skend(...)Bands [21]** | **16.992 ms** | **12.9084 ms** | **8.5381 ms** | **22.193 ms** |  **1.42** |    **1.22** | **2152.86 KB** |        **1.00** |
