```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean     | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |---------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)ivots [24]** | **2.224 ms** | **0.0508 ms** | **0.0302 ms** |  **1.00** |    **0.02** |   **388.2 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)ivots [24] | 2.132 ms | 0.0380 ms | 0.0199 ms |  0.96 |    0.01 |  738.49 KB |        1.90 |
|            |       |                      |          |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)ivots [24]** | **4.175 ms** | **0.1128 ms** | **0.0671 ms** |  **1.00** |    **0.02** |  **3849.8 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)ivots [24] | 9.887 ms | 1.7238 ms | 1.1402 ms |  2.37 |    0.26 | 7321.83 KB |        1.90 |
