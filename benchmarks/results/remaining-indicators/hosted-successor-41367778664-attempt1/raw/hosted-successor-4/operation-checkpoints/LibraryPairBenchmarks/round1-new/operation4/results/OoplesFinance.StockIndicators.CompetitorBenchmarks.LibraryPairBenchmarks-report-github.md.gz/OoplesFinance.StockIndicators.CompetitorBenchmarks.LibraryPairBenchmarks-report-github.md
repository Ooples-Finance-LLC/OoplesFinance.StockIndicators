```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean      | Error      | StdDev     | Median   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |----------:|-----------:|-----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skend(...)lysis [22]** |  **4.688 ms** |  **0.0396 ms** |  **0.0207 ms** | **4.695 ms** |  **1.00** |    **0.01** |  **298.85 KB** |        **1.00** |
|        |       |                      |           |            |            |          |       |         |            |             |
| **Ooples** | **10000** | **Skend(...)lysis [22]** | **13.519 ms** | **16.8515 ms** | **11.1462 ms** | **5.651 ms** |  **1.72** |    **1.82** | **2876.38 KB** |        **1.00** |
