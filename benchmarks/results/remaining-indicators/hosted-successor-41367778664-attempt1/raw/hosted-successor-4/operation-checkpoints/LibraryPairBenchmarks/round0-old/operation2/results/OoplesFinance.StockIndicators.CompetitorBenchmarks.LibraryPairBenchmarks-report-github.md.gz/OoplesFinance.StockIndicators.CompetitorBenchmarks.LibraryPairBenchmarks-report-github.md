```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId           | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |----------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetRocWb** |  **4.189 ms** | **0.0222 ms** | **0.0132 ms** |  **1.00** |    **0.00** |  **172.61 KB** |        **1.00** |
|        |       |                  |           |           |           |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetRocWb** | **39.211 ms** | **2.2683 ms** | **1.1864 ms** |  **1.00** |    **0.04** | **1692.55 KB** |        **1.00** |
