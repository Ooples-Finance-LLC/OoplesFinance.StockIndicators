```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean        | Error       | StdDev      | Ratio | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |--------------- |------------:|------------:|------------:|------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetPrs** |  **3,091.3 μs** |    **76.74 μs** |    **40.14 μs** |  **1.00** |    **0.02** |  **1079.65 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetPrs |    960.8 μs |   100.74 μs |    66.63 μs |  0.31 |    0.02 |   255.61 KB |        0.24 |
|            |       |                |             |             |             |       |         |             |             |
| **Ooples**     | **10000** | **Skender.GetPrs** | **35,560.4 μs** | **3,352.96 μs** | **2,217.78 μs** |  **1.00** |    **0.08** | **10607.02 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetPrs |  3,175.3 μs |    50.02 μs |    29.77 μs |  0.09 |    0.01 |  2461.99 KB |        0.23 |
