```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId        | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------- |-----------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetT3** |   **922.7 μs** |    **47.55 μs** |  **31.45 μs** |  **1.00** |    **0.05** |  **105.89 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetT3 |   954.2 μs |    38.55 μs |  22.94 μs |  1.04 |    0.04 |  115.37 KB |        1.09 |
|            |       |               |            |             |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetT3** | **3,490.8 μs** | **1,063.80 μs** | **556.39 μs** |  **1.02** |    **0.20** | **1037.23 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetT3 | 1,153.2 μs |    30.32 μs |  20.05 μs |  0.34 |    0.04 | 1073.66 KB |        1.04 |
