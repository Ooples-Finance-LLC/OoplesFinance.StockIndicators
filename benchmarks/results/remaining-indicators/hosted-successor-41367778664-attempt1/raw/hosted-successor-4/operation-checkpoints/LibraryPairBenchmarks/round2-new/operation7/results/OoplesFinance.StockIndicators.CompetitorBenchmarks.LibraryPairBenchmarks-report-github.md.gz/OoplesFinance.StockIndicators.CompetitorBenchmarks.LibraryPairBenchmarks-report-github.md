```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId          | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetTrix** | **7,665.1 μs** |  **47.21 μs** |  **24.69 μs** |  **1.00** |    **0.00** |  **211.13 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetTrix |   861.4 μs |  51.02 μs |  30.36 μs |  0.11 |    0.00 |   203.7 KB |        0.96 |
|            |       |                 |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetTrix** | **6,065.0 μs** | **210.73 μs** | **125.40 μs** |  **1.00** |    **0.03** | **2074.11 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetTrix | 1,335.4 μs | 756.24 μs | 450.02 μs |  0.22 |    0.07 | 1953.33 KB |        0.94 |
