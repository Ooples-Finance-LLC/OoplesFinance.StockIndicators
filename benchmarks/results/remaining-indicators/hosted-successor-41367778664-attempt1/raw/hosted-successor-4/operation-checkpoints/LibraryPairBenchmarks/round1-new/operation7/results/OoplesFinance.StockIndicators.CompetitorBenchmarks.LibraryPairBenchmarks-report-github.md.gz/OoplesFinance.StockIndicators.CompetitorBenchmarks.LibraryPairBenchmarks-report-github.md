```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId          | Mean     | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |---------------- |---------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetTrix** | **7.824 ms** | **0.0525 ms** | **0.0274 ms** |  **1.00** |    **0.00** |  **211.13 KB** |        **1.00** |
|        |       |                 |          |           |           |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetTrix** | **6.196 ms** | **0.5953 ms** | **0.3113 ms** |  **1.00** |    **0.06** | **2073.45 KB** |        **1.00** |
