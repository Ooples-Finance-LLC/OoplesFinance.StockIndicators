```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |   **619.4 μs** | **114.13 μs** | **75.49 μs** |       **-** |  **105.03 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |   528.0 μs |   3.09 μs |  1.62 μs |       - |   57.39 KB |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** | **5,343.9 μs** |  **19.39 μs** | **10.14 μs** | **31.2500** | **1019.64 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 | 5,233.1 μs |  30.15 μs | 17.94 μs | 31.2500 |  549.82 KB |
