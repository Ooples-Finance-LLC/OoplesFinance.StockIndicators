```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |    **533.1 μs** |     **3.94 μs** |   **2.06 μs** |  **0.27** |    **0.00** |         **-** |         **-** |         **-** |   **105.03 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |    529.8 μs |     2.05 μs |   1.07 μs |  0.27 |    0.00 |         - |         - |         - |    57.39 KB |        0.02 |
| NativeSingle      | Movin(...)gence [34] | 1000  |  1,950.9 μs |    36.86 μs |  24.38 μs |  1.00 |    0.02 |  203.1250 |  140.6250 |   46.8750 |  3232.13 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 1000  |  1,754.9 μs |    98.98 μs |  58.90 μs |  0.90 |    0.03 |  359.3750 |  156.2500 |         - |  5670.91 KB |        1.75 |
|                   |                      |       |             |             |           |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** |  **5,193.8 μs** |    **65.57 μs** |  **39.02 μs** |  **0.26** |    **0.00** |   **31.2500** |         **-** |         **-** |  **1019.65 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 |  5,185.2 μs |    44.34 μs |  26.39 μs |  0.26 |    0.00 |   31.2500 |         - |         - |   549.83 KB |        0.02 |
| NativeSingle      | Movin(...)gence [34] | 10000 | 19,735.5 μs |   399.16 μs | 208.77 μs |  1.00 |    0.01 | 2000.0000 | 1400.0000 | 1000.0000 | 31912.58 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 10000 | 21,878.7 μs | 1,260.64 μs | 833.84 μs |  1.11 |    0.04 | 3200.0000 | 2200.0000 | 1400.0000 |  56073.3 KB |        1.76 |
