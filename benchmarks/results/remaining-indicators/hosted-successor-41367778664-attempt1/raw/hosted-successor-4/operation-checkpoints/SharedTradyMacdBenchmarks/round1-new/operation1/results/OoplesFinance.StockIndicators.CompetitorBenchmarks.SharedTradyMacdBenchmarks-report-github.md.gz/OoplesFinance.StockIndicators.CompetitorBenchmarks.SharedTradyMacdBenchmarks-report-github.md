```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |   **515.4 μs** | **22.38 μs** | **14.81 μs** |       **-** |  **73.68 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |   491.5 μs |  3.43 μs |  2.27 μs |       - |  26.05 KB |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** | **4,890.4 μs** | **13.58 μs** |  **8.08 μs** | **31.2500** | **707.06 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 | 4,930.9 μs | 53.17 μs | 35.17 μs |       - | 237.22 KB |
