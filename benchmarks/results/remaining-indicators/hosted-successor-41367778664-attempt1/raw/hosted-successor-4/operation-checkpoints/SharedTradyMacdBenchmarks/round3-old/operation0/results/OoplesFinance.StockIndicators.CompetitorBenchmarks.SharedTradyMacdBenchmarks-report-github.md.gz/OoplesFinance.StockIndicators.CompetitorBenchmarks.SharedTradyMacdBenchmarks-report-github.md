```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |   **538.6 μs** |  **2.49 μs** |  **1.48 μs** |       **-** |  **104.99 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |   528.9 μs |  1.26 μs |  0.66 μs |       - |   57.39 KB |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** | **5,241.4 μs** | **18.90 μs** | **11.25 μs** | **31.2500** | **1019.64 KB** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 | 5,307.8 μs | 10.68 μs |  5.58 μs | 31.2500 |  549.84 KB |
