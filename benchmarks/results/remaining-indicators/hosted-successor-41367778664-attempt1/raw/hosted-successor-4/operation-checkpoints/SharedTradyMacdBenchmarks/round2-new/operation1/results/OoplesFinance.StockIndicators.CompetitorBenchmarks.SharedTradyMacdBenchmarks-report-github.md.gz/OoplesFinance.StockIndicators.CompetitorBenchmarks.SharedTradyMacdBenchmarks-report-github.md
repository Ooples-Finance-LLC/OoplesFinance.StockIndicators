```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |    **529.9 μs** |    **18.16 μs** |  **10.81 μs** |  **0.26** |    **0.01** |         **-** |         **-** |         **-** |    **73.68 KB** |       **0.022** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |    566.7 μs |    58.81 μs |  38.90 μs |  0.28 |    0.02 |         - |         - |         - |    26.05 KB |       0.008 |
| NativeSingle      | Movin(...)ogram [43] | 1000  |  2,057.9 μs |    15.48 μs |   9.21 μs |  1.00 |    0.01 |  203.1250 |  109.3750 |   46.8750 |  3389.09 KB |       1.000 |
| NativeParallel    | Movin(...)ogram [43] | 1000  |  1,774.2 μs |    75.51 μs |  39.49 μs |  0.86 |    0.02 |  359.3750 |  187.5000 |         - |  5597.51 KB |       1.652 |
|                   |                      |       |             |             |           |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** |  **5,086.1 μs** |     **7.64 μs** |   **4.00 μs** |  **0.23** |    **0.01** |   **31.2500** |         **-** |         **-** |   **707.03 KB** |       **0.021** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 |  4,922.6 μs |    22.83 μs |  13.59 μs |  0.22 |    0.01 |         - |         - |         - |   237.23 KB |       0.007 |
| NativeSingle      | Movin(...)ogram [43] | 10000 | 22,229.6 μs | 1,133.89 μs | 750.00 μs |  1.00 |    0.05 | 2000.0000 | 1400.0000 | 1000.0000 |  33358.1 KB |       1.000 |
| NativeParallel    | Movin(...)ogram [43] | 10000 | 22,767.3 μs | 1,099.06 μs | 654.03 μs |  1.03 |    0.04 | 3000.0000 | 2000.0000 | 1250.0000 | 55283.04 KB |       1.657 |
