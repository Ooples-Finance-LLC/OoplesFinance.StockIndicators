```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |    **78.95 μs** |  **1.131 μs** |  **0.591 μs** |  **1.02** |    **0.01** |   **3.9063** |        **-** |   **88.31 KB** |        **0.50** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |    56.25 μs |  0.443 μs |  0.232 μs |  0.73 |    0.01 |   2.4414 |        - |    40.7 KB |        0.23 |
| NativeSingle      | Skender.GetAdl | 1000  |    77.35 μs |  1.191 μs |  0.709 μs |  1.00 |    0.01 |  10.7422 |   2.4414 |  176.21 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 1000  |   142.24 μs | 10.835 μs |  7.167 μs |  1.84 |    0.09 |  28.3203 |   8.7891 |   449.4 KB |        2.55 |
|                   |                |       |             |           |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetAdl** | **10000** |   **569.14 μs** |  **5.627 μs** |  **3.722 μs** |  **0.65** |    **0.00** |  **50.7813** |  **15.6250** |  **862.14 KB** |        **0.49** |
| BuilderLatestOnly | Skender.GetAdl | 10000 |   554.22 μs |  6.896 μs |  3.607 μs |  0.64 |    0.00 |  23.4375 |   7.8125 |  392.31 KB |        0.22 |
| NativeSingle      | Skender.GetAdl | 10000 |   869.97 μs |  7.611 μs |  3.981 μs |  1.00 |    0.01 | 101.5625 |  62.5000 |  1758.3 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 10000 | 1,453.04 μs | 74.802 μs | 49.477 μs |  1.67 |    0.05 | 273.4375 | 187.5000 | 4474.84 KB |        2.54 |
