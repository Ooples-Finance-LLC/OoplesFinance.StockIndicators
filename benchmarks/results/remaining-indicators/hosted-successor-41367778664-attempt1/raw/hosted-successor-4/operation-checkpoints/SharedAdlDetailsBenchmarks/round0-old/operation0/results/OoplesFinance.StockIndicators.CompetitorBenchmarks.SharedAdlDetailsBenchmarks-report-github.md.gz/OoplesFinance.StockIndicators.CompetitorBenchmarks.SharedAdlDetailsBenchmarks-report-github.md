```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |  **59.12 μs** | **0.453 μs** | **0.237 μs** |  **3.9063** |       **-** |  **88.31 KB** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |  56.39 μs | 0.380 μs | 0.251 μs |  2.4414 |       - |   40.7 KB |
| **BuilderFull**       | **Skender.GetAdl** | **10000** | **611.48 μs** | **4.309 μs** | **2.254 μs** | **50.7813** | **15.6250** | **862.14 KB** |
| BuilderLatestOnly | Skender.GetAdl | 10000 | 545.80 μs | 6.286 μs | 3.741 μs | 23.4375 |  7.8125 |  392.3 KB |
