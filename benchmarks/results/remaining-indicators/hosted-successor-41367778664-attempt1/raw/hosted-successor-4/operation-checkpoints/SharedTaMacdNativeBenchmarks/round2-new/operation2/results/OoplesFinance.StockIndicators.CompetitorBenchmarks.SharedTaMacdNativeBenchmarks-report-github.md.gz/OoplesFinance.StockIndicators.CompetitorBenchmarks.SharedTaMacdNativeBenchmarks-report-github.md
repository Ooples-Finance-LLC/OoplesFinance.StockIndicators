```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **1000**  |   **409.96 μs** |  **2.639 μs** |  **1.571 μs** | **34.95** |    **0.62** |       **-** |       **-** |   **81.32 KB** |        **2.13** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 1000  |   401.98 μs |  2.052 μs |  1.221 μs | 34.27 |    0.60 |       - |       - |   33.72 KB |        0.88 |
| NativeSingle      | TaLib(...)cdFix [23] | 1000  |    11.73 μs |  0.323 μs |  0.214 μs |  1.00 |    0.02 |  2.3193 |  0.1221 |   38.27 KB |        1.00 |
| NativeParallel    | TaLib(...)cdFix [23] | 1000  |    18.84 μs |  1.012 μs |  0.669 μs |  1.61 |    0.06 |  7.9346 |  1.0986 |  119.47 KB |        3.12 |
|                   |                      |       |             |           |           |       |         |         |         |            |             |
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **10000** | **4,123.11 μs** | **15.668 μs** |  **8.195 μs** | **35.49** |    **0.54** | **31.2500** |       **-** |  **785.04 KB** |        **2.01** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 10000 | 4,056.73 μs | 47.443 μs | 28.233 μs | 34.92 |    0.58 |       - |       - |  315.19 KB |        0.81 |
| NativeSingle      | TaLib(...)cdFix [23] | 10000 |   116.20 μs |  2.810 μs |  1.859 μs |  1.00 |    0.02 | 23.4375 |       - |  389.84 KB |        1.00 |
| NativeParallel    | TaLib(...)cdFix [23] | 10000 |   189.18 μs |  3.188 μs |  1.667 μs |  1.63 |    0.03 | 74.2188 | 33.2031 | 1209.33 KB |        3.10 |
