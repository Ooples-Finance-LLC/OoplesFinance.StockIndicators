```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Macd** | **1000**  |   **437.9 μs** | **26.55 μs** | **13.89 μs** |       **-** |  **81.26 KB** |
| BuilderLatestOnly | TaLib.Functions.Macd | 1000  |   420.0 μs |  2.56 μs |  1.52 μs |       - |  33.66 KB |
| **BuilderFull**       | **TaLib.Functions.Macd** | **10000** | **4,295.0 μs** | **14.54 μs** |  **8.65 μs** | **31.2500** | **784.93 KB** |
| BuilderLatestOnly | TaLib.Functions.Macd | 10000 | 4,318.0 μs | 10.38 μs |  5.43 μs |       - | 315.14 KB |
