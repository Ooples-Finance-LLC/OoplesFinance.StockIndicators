```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **1000**  |   **403.6 μs** |  **2.51 μs** |  **1.49 μs** |       **-** |  **81.32 KB** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 1000  |   408.3 μs |  3.26 μs |  1.94 μs |       - |  33.72 KB |
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **10000** | **4,124.4 μs** | **13.99 μs** |  **7.32 μs** | **31.2500** | **785.02 KB** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 10000 | 4,070.0 μs | 19.48 μs | 10.19 μs |       - |  315.2 KB |
