```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Macd** | **1000**  |   **411.66 μs** |  **6.827 μs** |  **3.571 μs** | **35.72** |    **0.59** |       **-** |       **-** |   **81.29 KB** |        **2.12** |
| BuilderLatestOnly | TaLib.Functions.Macd | 1000  |   411.65 μs |  4.576 μs |  3.027 μs | 35.72 |    0.57 |       - |       - |   33.66 KB |        0.88 |
| NativeSingle      | TaLib.Functions.Macd | 1000  |    11.53 μs |  0.291 μs |  0.173 μs |  1.00 |    0.02 |  1.9531 |       - |   38.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Macd | 1000  |    18.69 μs |  0.666 μs |  0.440 μs |  1.62 |    0.04 |  7.9346 |  1.2207 |  119.47 KB |        3.12 |
|                   |                      |       |             |           |           |       |         |         |         |            |             |
| **BuilderFull**       | **TaLib.Functions.Macd** | **10000** | **4,149.43 μs** | **23.868 μs** | **14.204 μs** | **35.42** |    **0.54** | **31.2500** |       **-** |  **784.96 KB** |        **2.01** |
| BuilderLatestOnly | TaLib.Functions.Macd | 10000 | 4,121.00 μs |  4.462 μs |  2.334 μs | 35.18 |    0.53 |       - |       - |  315.13 KB |        0.81 |
| NativeSingle      | TaLib.Functions.Macd | 10000 |   117.17 μs |  2.801 μs |  1.853 μs |  1.00 |    0.02 | 23.4375 |       - |  389.84 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Macd | 10000 |   196.17 μs |  5.814 μs |  3.845 μs |  1.67 |    0.04 | 75.1953 | 31.2500 | 1209.32 KB |        3.10 |
