```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **1000**  |   **571.112 μs** | **128.3477 μs** |  **84.8940 μs** | **62.47** |    **8.96** |  **31.2500** |        **-** |  **665.05 KB** |       **17.30** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 1000  |   522.598 μs |  49.2150 μs |  32.5527 μs | 57.16 |    3.61 |  35.1563 |   3.9063 |  617.46 KB |       16.06 |
| NativeSingle      | TaLib(...)cdExt [23] | 1000  |     9.146 μs |   0.3117 μs |   0.2062 μs |  1.00 |    0.03 |   2.3193 |   0.1831 |   38.45 KB |        1.00 |
| NativeParallel    | TaLib(...)cdExt [23] | 1000  |    17.827 μs |   0.4700 μs |   0.3109 μs |  1.95 |    0.05 |   8.1787 |   1.3428 |  120.22 KB |        3.13 |
|                   |                      |       |              |             |             |       |         |          |          |            |             |
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **10000** | **5,076.719 μs** | **443.4871 μs** | **293.3393 μs** | **58.39** |    **3.26** | **375.0000** | **187.5000** | **6140.93 KB** |       **15.75** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 10000 | 5,025.493 μs | 513.6986 μs | 339.7798 μs | 57.80 |    3.76 | 343.7500 | 156.2500 |  5671.1 KB |       14.54 |
| NativeSingle      | TaLib(...)cdExt [23] | 10000 |    86.954 μs |   1.4001 μs |   0.8332 μs |  1.00 |    0.01 |  23.4375 |   7.8125 |  390.02 KB |        1.00 |
| NativeParallel    | TaLib(...)cdExt [23] | 10000 |   174.928 μs |   9.9206 μs |   6.5619 μs |  2.01 |    0.07 |  76.1719 |  34.1797 | 1210.07 KB |        3.10 |
