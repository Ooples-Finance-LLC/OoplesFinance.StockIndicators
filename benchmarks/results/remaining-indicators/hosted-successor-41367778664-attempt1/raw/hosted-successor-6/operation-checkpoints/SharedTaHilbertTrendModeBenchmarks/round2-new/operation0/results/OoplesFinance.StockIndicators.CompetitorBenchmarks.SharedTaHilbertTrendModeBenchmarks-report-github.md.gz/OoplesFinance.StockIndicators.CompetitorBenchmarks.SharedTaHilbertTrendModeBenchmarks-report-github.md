```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **3,252.3 μs** |  **13.27 μs** |   **6.94 μs** |  **5.56** |    **0.03** |  **71.71 KB** |       **15.15** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  2,623.1 μs |   9.99 μs |   5.22 μs |  4.48 |    0.02 |  24.07 KB |        5.09 |
| NativeSingle      | TaLib(...)dMode [27] | 1000  |    585.5 μs |   4.39 μs |   2.61 μs |  1.00 |    0.01 |   4.73 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 1000  |    783.3 μs |  53.78 μs |  35.57 μs |  1.34 |    0.06 |   17.4 KB |        3.68 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **26,954.5 μs** | **334.99 μs** | **199.35 μs** |  **4.24** |    **0.03** | **636.49 KB** |       **15.78** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 26,883.3 μs | 103.83 μs |  54.31 μs |  4.23 |    0.01 | 166.61 KB |        4.13 |
| NativeSingle      | TaLib(...)dMode [27] | 10000 |  6,358.6 μs |  20.64 μs |  12.28 μs |  1.00 |    0.00 |  40.33 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 10000 |  8,007.2 μs |  91.54 μs |  47.88 μs |  1.26 |    0.01 | 141.02 KB |        3.50 |
