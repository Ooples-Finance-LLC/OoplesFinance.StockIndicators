```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **3.706 ms** | **0.0347 ms** | **0.0207 ms** |  **71.71 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  2.582 ms | 0.0105 ms | 0.0055 ms |  24.06 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **26.714 ms** | **0.0920 ms** | **0.0481 ms** | **636.42 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 26.522 ms | 0.1163 ms | 0.0769 ms | 166.68 KB |
