```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **542.9 μs** |  **3.78 μs** |  **2.25 μs** |       **-** |  **128.54 KB** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   554.6 μs | 22.99 μs | 15.20 μs |  3.9063 |    80.9 KB |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **5,453.7 μs** | **24.56 μs** | **14.61 μs** | **62.5000** | **1254.09 KB** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 5,558.6 μs | 19.51 μs | 11.61 μs | 31.2500 |  784.25 KB |
