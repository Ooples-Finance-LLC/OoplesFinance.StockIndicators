```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **952.95 μs** |   **5.260 μs** |   **3.130 μs** | **31.25** |    **0.28** |        **-** |        **-** |        **-** |   **89.26 KB** |        **0.73** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   529.33 μs |   3.811 μs |   1.993 μs | 17.36 |    0.16 |        - |        - |        - |    41.6 KB |        0.34 |
| NativeSingle      | Skender.GetTrix | 1000  |    30.50 μs |   0.462 μs |   0.275 μs |  1.00 |    0.01 |   7.3242 |   1.7090 |        - |  121.49 KB |        1.00 |
| NativeParallel    | Skender.GetTrix | 1000  |    62.68 μs |   1.737 μs |   1.149 μs |  2.06 |    0.04 |  20.5078 |   5.8594 |        - |  312.32 KB |        2.57 |
|                   |                 |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **5,111.74 μs** |  **32.630 μs** |  **17.066 μs** |  **9.30** |    **0.07** |  **31.2500** |        **-** |        **-** |  **863.23 KB** |        **0.71** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 5,133.78 μs |  48.597 μs |  28.919 μs |  9.34 |    0.08 |        - |        - |        - |  393.39 KB |        0.32 |
| NativeSingle      | Skender.GetTrix | 10000 |   549.79 μs |   7.159 μs |   4.260 μs |  1.00 |    0.01 |  97.6563 |  97.6563 |  97.6563 | 1212.12 KB |        1.00 |
| NativeParallel    | Skender.GetTrix | 10000 | 1,936.07 μs | 284.014 μs | 187.858 μs |  3.52 |    0.33 | 312.5000 | 257.8125 | 164.0625 | 3109.41 KB |        2.57 |
