```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **657.99 μs** |   **3.316 μs** |   **1.973 μs** |  **9.87** |    **0.08** |        **-** |        **-** |        **-** |  **105.05 KB** |        **0.37** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   654.23 μs |   8.662 μs |   5.154 μs |  9.81 |    0.11 |        - |        - |        - |   57.39 KB |        0.20 |
| NativeSingle      | Skender.GetPvo | 1000  |    66.70 μs |   0.959 μs |   0.571 μs |  1.00 |    0.01 |  17.0898 |   3.4180 |        - |  285.61 KB |        1.00 |
| NativeParallel    | Skender.GetPvo | 1000  |   134.40 μs |  11.014 μs |   7.285 μs |  2.02 |    0.11 |  46.8750 |  15.6250 |        - |  729.53 KB |        2.55 |
|                   |                |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **6,511.99 μs** |  **34.103 μs** |  **20.294 μs** |  **5.75** |    **0.16** |        **-** |        **-** |        **-** | **1019.87 KB** |        **0.33** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 6,724.02 μs |  24.716 μs |  12.927 μs |  5.94 |    0.16 |        - |        - |        - |  550.13 KB |        0.18 |
| NativeSingle      | Skender.GetPvo | 10000 | 1,132.79 μs |  47.939 μs |  31.709 μs |  1.00 |    0.04 | 164.0625 | 164.0625 | 164.0625 |  3052.2 KB |        1.00 |
| NativeParallel    | Skender.GetPvo | 10000 | 3,507.76 μs | 466.618 μs | 308.639 μs |  3.10 |    0.27 | 625.0000 | 468.7500 | 250.0000 | 7581.72 KB |        2.48 |
