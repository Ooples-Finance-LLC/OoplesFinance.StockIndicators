```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated  |
|------------------ |--------------- |------ |-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **687.6 μs** |  **4.00 μs** |  **2.38 μs** |  **105.05 KB** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   668.4 μs |  3.93 μs |  2.05 μs |   57.39 KB |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **6,887.4 μs** | **54.59 μs** | **32.48 μs** | **1019.91 KB** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 6,814.8 μs | 46.70 μs | 27.79 μs |  550.09 KB |
