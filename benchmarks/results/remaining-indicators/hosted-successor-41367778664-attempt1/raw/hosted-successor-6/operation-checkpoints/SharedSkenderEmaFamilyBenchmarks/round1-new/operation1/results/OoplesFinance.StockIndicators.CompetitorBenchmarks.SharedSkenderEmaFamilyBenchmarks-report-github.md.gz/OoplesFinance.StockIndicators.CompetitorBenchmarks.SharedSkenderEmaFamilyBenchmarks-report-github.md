```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated  |
|------------------ |--------------- |------ |-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **681.0 μs** |  **3.76 μs** |  **2.24 μs** |  **105.05 KB** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   643.0 μs |  3.08 μs |  1.61 μs |   57.39 KB |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **6,654.1 μs** | **11.09 μs** |  **6.60 μs** | **1019.87 KB** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 6,499.5 μs | 25.38 μs | 15.10 μs |  550.06 KB |
