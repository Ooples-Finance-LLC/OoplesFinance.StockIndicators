```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **904.0 μs** | **25.57 μs** | **13.37 μs** |       **-** |  **89.27 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   558.7 μs |  5.55 μs |  3.30 μs |       - |   41.6 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **5,215.1 μs** | **51.45 μs** | **26.91 μs** | **31.2500** | **863.23 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 5,155.4 μs | 17.91 μs | 10.66 μs |       - | 393.39 KB |
