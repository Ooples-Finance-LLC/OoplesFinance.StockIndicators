```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **546.94 μs** |   **9.187 μs** |   **5.467 μs** |  **9.10** |    **0.14** |        **-** |        **-** |        **-** |   **128.5 KB** |        **0.40** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   528.13 μs |   3.718 μs |   2.213 μs |  8.79 |    0.11 |   3.9063 |        - |        - |    80.9 KB |        0.25 |
| NativeSingle      | Skender.GetMacd | 1000  |    60.11 μs |   1.489 μs |   0.779 μs |  1.00 |    0.02 |  19.5313 |   6.3477 |        - |  324.54 KB |        1.00 |
| NativeParallel    | Skender.GetMacd | 1000  |   123.93 μs |   8.326 μs |   5.507 μs |  2.06 |    0.09 |  53.7109 |  22.4609 |        - |  826.63 KB |        2.55 |
|                   |                 |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **5,348.40 μs** |  **40.352 μs** |  **24.013 μs** |  **4.54** |    **0.08** |  **62.5000** |        **-** |        **-** | **1254.08 KB** |        **0.36** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 5,336.85 μs |  22.593 μs |  13.445 μs |  4.53 |    0.07 |  31.2500 |        - |        - |  784.27 KB |        0.23 |
| NativeSingle      | Skender.GetMacd | 10000 | 1,177.91 μs |  30.658 μs |  20.278 μs |  1.00 |    0.02 | 218.7500 | 218.7500 | 218.7500 | 3443.12 KB |        1.00 |
| NativeParallel    | Skender.GetMacd | 10000 | 4,224.42 μs | 598.309 μs | 395.744 μs |  3.59 |    0.33 | 750.0000 | 625.0000 | 312.5000 | 8556.35 KB |        2.49 |
