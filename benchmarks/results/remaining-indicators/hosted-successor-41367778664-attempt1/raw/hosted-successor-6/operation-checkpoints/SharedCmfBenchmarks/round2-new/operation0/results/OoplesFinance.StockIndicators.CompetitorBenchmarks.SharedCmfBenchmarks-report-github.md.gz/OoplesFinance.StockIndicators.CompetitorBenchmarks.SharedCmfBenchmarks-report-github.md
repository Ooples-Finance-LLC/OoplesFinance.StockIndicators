```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetCmf** | **1000**  |    **86.92 μs** |  **8.134 μs** |  **4.841 μs** |  **0.69** |    **0.04** |   **3.9063** |        **-** |       **-** |   **85.73 KB** |        **0.29** |
| BuilderLatestOnly | Skender.GetCmf | 1000  |    77.41 μs |  5.028 μs |  3.326 μs |  0.61 |    0.03 |   1.9531 |        - |       - |   38.12 KB |        0.13 |
| NativeSingle      | Skender.GetCmf | 1000  |   126.02 μs |  1.628 μs |  1.077 μs |  1.00 |    0.01 |  17.5781 |   4.8828 |       - |   297.9 KB |        1.00 |
| NativeParallel    | Skender.GetCmf | 1000  |    84.68 μs |  2.134 μs |  1.116 μs |  0.67 |    0.01 |  20.5078 |   5.8594 |       - |   326.3 KB |        1.10 |
|                   |                |       |             |           |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skender.GetCmf** | **10000** |   **547.61 μs** | **82.265 μs** | **54.413 μs** |  **0.34** |    **0.03** |  **46.8750** |  **15.6250** |       **-** |  **789.24 KB** |        **0.27** |
| BuilderLatestOnly | Skender.GetCmf | 10000 |   530.06 μs | 72.345 μs | 47.852 μs |  0.33 |    0.03 |  15.6250 |   3.9063 |       - |  319.41 KB |        0.11 |
| NativeSingle      | Skender.GetCmf | 10000 | 1,607.01 μs | 20.672 μs | 12.301 μs |  1.00 |    0.01 | 187.5000 | 140.6250 | 46.8750 | 2970.25 KB |        1.00 |
| NativeParallel    | Skender.GetCmf | 10000 |   876.58 μs | 36.942 μs | 21.983 μs |  0.55 |    0.01 | 195.3125 | 132.8125 |       - | 3068.54 KB |        1.03 |
