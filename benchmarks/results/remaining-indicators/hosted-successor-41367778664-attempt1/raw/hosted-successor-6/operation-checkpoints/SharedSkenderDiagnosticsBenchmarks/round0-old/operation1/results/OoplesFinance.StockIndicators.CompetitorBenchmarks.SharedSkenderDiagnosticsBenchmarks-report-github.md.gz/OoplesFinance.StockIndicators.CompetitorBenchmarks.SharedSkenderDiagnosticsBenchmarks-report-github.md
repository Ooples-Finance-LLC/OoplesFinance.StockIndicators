```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Skend(...)lysis [22]** | **1000**  |   **483.3 μs** |  **26.72 μs** |  **15.90 μs** |       **-** |       **-** |  **144.21 KB** |
| BuilderLatestOnly | Skend(...)lysis [22] | 1000  |   364.8 μs | 164.93 μs | 109.09 μs |  3.9063 |       - |   96.58 KB |
| **BuilderFull**       | **Skend(...)lysis [22]** | **10000** | **4,207.8 μs** |  **40.51 μs** |  **24.11 μs** | **62.5000** | **31.2500** | **1272.72 KB** |
| BuilderLatestOnly | Skend(...)lysis [22] | 10000 | 2,856.5 μs | 614.21 μs | 406.26 μs | 46.8750 | 15.6250 |   802.8 KB |
