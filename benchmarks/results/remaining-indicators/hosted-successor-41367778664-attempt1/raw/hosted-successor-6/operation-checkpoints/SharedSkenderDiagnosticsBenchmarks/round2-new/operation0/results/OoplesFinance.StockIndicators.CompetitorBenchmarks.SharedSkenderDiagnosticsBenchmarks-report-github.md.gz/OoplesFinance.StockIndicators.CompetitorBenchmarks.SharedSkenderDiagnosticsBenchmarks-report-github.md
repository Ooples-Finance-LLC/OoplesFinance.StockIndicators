```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetPrs** | **1000**  |   **412.47 μs** |   **6.916 μs** |   **3.617 μs** |  **7.75** |    **0.15** |  **46.8750** |        **-** |        **-** |  **991.03 KB** |        **6.01** |
| BuilderLatestOnly | Skender.GetPrs | 1000  |   413.58 μs |  11.725 μs |   6.132 μs |  7.77 |    0.17 |  54.6875 |   7.8125 |        - |  943.45 KB |        5.73 |
| NativeSingle      | Skender.GetPrs | 1000  |    53.21 μs |   1.625 μs |   0.967 μs |  1.00 |    0.02 |   9.7656 |   1.4648 |        - |  164.79 KB |        1.00 |
| NativeParallel    | Skender.GetPrs | 1000  |    38.26 μs |   3.613 μs |   2.389 μs |  0.72 |    0.04 |  12.6953 |   2.9297 |        - |  184.81 KB |        1.12 |
|                   |                |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetPrs** | **10000** | **4,247.51 μs** | **406.830 μs** | **269.093 μs** |  **5.71** |    **0.35** | **562.5000** | **281.2500** |        **-** | **9429.54 KB** |        **5.74** |
| BuilderLatestOnly | Skender.GetPrs | 10000 | 4,017.84 μs | 238.375 μs | 141.853 μs |  5.40 |    0.19 | 531.2500 | 250.0000 |        - | 8959.74 KB |        5.45 |
| NativeSingle      | Skender.GetPrs | 10000 |   744.36 μs |  10.817 μs |   5.657 μs |  1.00 |    0.01 | 210.9375 | 164.0625 | 156.2500 | 1643.69 KB |        1.00 |
| NativeParallel    | Skender.GetPrs | 10000 |   382.69 μs |  12.309 μs |   6.438 μs |  0.51 |    0.01 | 113.2813 |  50.7813 |        - | 1731.72 KB |        1.05 |
