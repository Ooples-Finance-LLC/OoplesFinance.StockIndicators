```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)lysis [22]** | **1000**  |   **305.02 μs** |  **11.049 μs** |   **5.779 μs** |  **3.61** |    **0.09** |        **-** |        **-** |       **-** |  **144.21 KB** |        **0.78** |
| BuilderLatestOnly | Skend(...)lysis [22] | 1000  |   266.41 μs |  12.339 μs |   6.453 μs |  3.16 |    0.09 |   3.9063 |        - |       - |   96.57 KB |        0.52 |
| NativeSingle      | Skend(...)lysis [22] | 1000  |    84.42 μs |   2.401 μs |   1.588 μs |  1.00 |    0.03 |  11.2305 |   2.4414 |       - |  184.11 KB |        1.00 |
| NativeParallel    | Skend(...)lysis [22] | 1000  |    58.50 μs |   5.740 μs |   3.797 μs |  0.69 |    0.04 |  13.1836 |   2.9297 |       - |  204.15 KB |        1.11 |
|                   |                      |       |             |            |            |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)lysis [22]** | **10000** | **2,631.37 μs** | **199.040 μs** | **118.446 μs** |  **2.15** |    **0.15** |  **62.5000** |  **31.2500** |       **-** | **1272.75 KB** |        **0.69** |
| BuilderLatestOnly | Skend(...)lysis [22] | 10000 | 2,685.32 μs | 236.083 μs | 156.155 μs |  2.19 |    0.17 |  46.8750 |  15.6250 |       - |  802.77 KB |        0.44 |
| NativeSingle      | Skend(...)lysis [22] | 10000 | 1,229.45 μs | 111.306 μs |  73.622 μs |  1.00 |    0.08 | 171.8750 | 125.0000 | 85.9375 | 1837.38 KB |        1.00 |
| NativeParallel    | Skend(...)lysis [22] | 10000 |   557.82 μs |  55.423 μs |  36.659 μs |  0.46 |    0.04 | 121.0938 |  62.5000 |       - | 1926.84 KB |        1.05 |
