```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|------------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Beta** | **5,928.4 μs** |    **74.21 μs** |  **49.09 μs** |  **1.00** |    **0.01** | **108.47 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Beta |   191.4 μs |    26.82 μs |  17.74 μs |  0.03 |    0.00 |  41.14 KB |        0.38 |
|            |       |                      |            |             |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Beta** | **6,930.4 μs** | **1,359.31 μs** | **899.10 μs** |  **1.01** |    **0.17** | **1039.8 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Beta |   210.9 μs |    64.06 μs |  42.37 μs |  0.03 |    0.01 | 331.18 KB |        0.32 |
