```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tSine [22]** | **18.625 ms** | **0.1140 ms** | **0.0754 ms** |  **1.00** |  **166.54 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tSine [22] |  2.104 ms | 0.0175 ms | 0.0104 ms |  0.11 |   74.28 KB |        0.45 |
|            |       |                      |           |           |           |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)tSine [22]** | **19.817 ms** | **0.3243 ms** | **0.1930 ms** |  **1.00** | **1598.85 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tSine [22] |  6.032 ms | 0.0720 ms | 0.0429 ms |  0.30 |  654.64 KB |        0.41 |
