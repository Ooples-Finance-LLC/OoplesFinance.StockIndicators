```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId              | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Cci** | **2,197.6 μs** | **438.77 μs** | **290.22 μs** |  **1.02** |    **0.18** | **106.46 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Cci |   436.8 μs |  30.90 μs |  18.39 μs |  0.20 |    0.03 |  41.06 KB |        0.39 |
|            |       |                     |            |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Cci** | **3,068.1 μs** | **599.61 μs** | **356.82 μs** |  **1.01** |    **0.15** | **1037.8 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Cci |   486.7 μs |  40.45 μs |  24.07 μs |  0.16 |    0.02 |  331.1 KB |        0.32 |
