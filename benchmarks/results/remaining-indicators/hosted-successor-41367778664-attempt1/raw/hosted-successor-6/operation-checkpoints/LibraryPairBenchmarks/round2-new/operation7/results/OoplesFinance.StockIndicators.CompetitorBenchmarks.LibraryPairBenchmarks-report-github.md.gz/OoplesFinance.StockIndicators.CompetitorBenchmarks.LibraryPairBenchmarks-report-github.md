```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId             | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ma** |   **622.5 μs** |  **57.89 μs** |  **38.29 μs** |  **1.00** |    **0.08** |  **112.63 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ma |   106.8 μs |  18.84 μs |  12.46 μs |  0.17 |    0.02 |   40.91 KB |        0.36 |
|            |       |                    |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ma** | **6,984.0 μs** | **191.57 μs** | **126.71 μs** |  **1.00** |    **0.02** | **1043.97 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ma |   164.2 μs |  20.92 μs |  13.84 μs |  0.02 |    0.00 |  330.95 KB |        0.32 |
