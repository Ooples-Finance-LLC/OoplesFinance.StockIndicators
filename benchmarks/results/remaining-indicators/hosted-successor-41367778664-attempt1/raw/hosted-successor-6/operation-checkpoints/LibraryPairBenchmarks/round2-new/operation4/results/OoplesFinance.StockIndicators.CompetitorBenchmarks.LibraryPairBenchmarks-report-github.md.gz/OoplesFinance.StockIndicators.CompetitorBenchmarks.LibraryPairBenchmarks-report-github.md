```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Phase [25]** | **18.275 ms** | **0.0567 ms** | **0.0297 ms** |  **1.00** |  **110.13 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Phase [25] |  1.921 ms | 0.0421 ms | 0.0250 ms |  0.11 |   41.76 KB |        0.38 |
|            |       |                      |           |           |           |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)Phase [25]** | **19.539 ms** | **0.1458 ms** | **0.0868 ms** |  **1.00** | **1040.86 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Phase [25] |  5.747 ms | 0.0294 ms | 0.0175 ms |  0.29 |  332.13 KB |        0.32 |
