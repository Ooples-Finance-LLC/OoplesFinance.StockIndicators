```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId             | Mean       | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-----------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Dx** | **3,114.1 μs** |    **54.93 μs** |    **36.33 μs** |  **1.00** |    **0.02** |  **105.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Dx |   274.9 μs |    19.23 μs |    12.72 μs |  0.09 |    0.00 |   40.88 KB |        0.39 |
|            |       |                    |            |             |             |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Dx** | **8,211.7 μs** | **1,723.46 μs** | **1,139.96 μs** |  **1.02** |    **0.18** | **1037.05 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Dx |   375.0 μs |    36.46 μs |    24.12 μs |  0.05 |    0.01 |  330.92 KB |        0.32 |
