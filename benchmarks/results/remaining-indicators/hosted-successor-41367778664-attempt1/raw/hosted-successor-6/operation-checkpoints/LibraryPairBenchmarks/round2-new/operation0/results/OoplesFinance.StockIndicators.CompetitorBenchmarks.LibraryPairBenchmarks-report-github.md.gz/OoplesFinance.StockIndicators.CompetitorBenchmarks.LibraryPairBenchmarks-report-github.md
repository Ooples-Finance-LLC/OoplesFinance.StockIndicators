```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)bands [22]** | **1,048.6 μs** | **29.11 μs** | **17.32 μs** |  **1.00** |    **0.02** |  **205.27 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)bands [22] |   340.4 μs | 97.15 μs | 64.26 μs |  0.32 |    0.06 |  106.13 KB |        0.52 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)bands [22]** | **4,613.9 μs** | **49.38 μs** | **29.38 μs** |  **1.00** |    **0.01** | **1997.93 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)bands [22] |   268.1 μs | 17.34 μs | 10.32 μs |  0.06 |    0.00 |  976.58 KB |        0.49 |
