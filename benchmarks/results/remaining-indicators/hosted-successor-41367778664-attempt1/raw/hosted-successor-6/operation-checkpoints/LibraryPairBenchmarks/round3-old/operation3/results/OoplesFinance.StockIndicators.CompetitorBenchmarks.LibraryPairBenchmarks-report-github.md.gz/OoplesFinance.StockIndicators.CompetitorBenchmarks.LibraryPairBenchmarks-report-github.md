```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId             | Mean     | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|------- |------ |------------------- |---------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Dx** | **3.554 ms** | **0.0534 ms** | **0.0318 ms** |  **1.00** |  **105.71 KB** |        **1.00** |
|        |       |                    |          |           |           |       |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Dx** | **7.873 ms** | **0.0960 ms** | **0.0571 ms** |  **1.00** | **1036.44 KB** |        **1.00** |
