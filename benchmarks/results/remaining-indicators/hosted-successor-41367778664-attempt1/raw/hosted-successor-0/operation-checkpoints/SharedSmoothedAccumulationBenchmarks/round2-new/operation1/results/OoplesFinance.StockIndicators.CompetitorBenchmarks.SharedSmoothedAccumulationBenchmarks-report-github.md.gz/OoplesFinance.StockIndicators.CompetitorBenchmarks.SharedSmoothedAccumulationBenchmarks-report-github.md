```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio  | RatioSD | Gen0   | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|-------:|--------:|-------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **360.884 μs** |  **1.9376 μs** |  **1.0134 μs** | **107.66** |    **0.63** |      **-** |      **-** |  **73.51 KB** |        **9.42** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   361.989 μs | 10.2414 μs |  6.7740 μs | 107.99 |    2.01 |      - |      - |  25.91 KB |        3.32 |
| NativeSingle      | TaLib(...)AdOsc [21] | 1000  |     3.352 μs |  0.0277 μs |  0.0183 μs |   1.00 |    0.01 | 0.0916 |      - |    7.8 KB |        1.00 |
| NativeParallel    | TaLib(...)AdOsc [21] | 1000  |     9.494 μs |  0.1507 μs |  0.0897 μs |   2.83 |    0.03 | 0.3662 |      - |  27.56 KB |        3.53 |
|                   |                      |       |              |            |            |        |         |        |        |           |             |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **3,701.125 μs** | **80.0924 μs** | **52.9762 μs** | **119.24** |    **1.97** |      **-** |      **-** | **706.87 KB** |        **9.05** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 3,537.208 μs | 36.5685 μs | 24.1878 μs | 113.96 |    1.29 |      - |      - | 237.07 KB |        3.03 |
| NativeSingle      | TaLib(...)AdOsc [21] | 10000 |    31.042 μs |  0.5113 μs |  0.3043 μs |   1.00 |    0.01 | 0.7324 |      - |  78.12 KB |        1.00 |
| NativeParallel    | TaLib(...)AdOsc [21] | 10000 |    79.061 μs |  6.2874 μs |  4.1587 μs |   2.55 |    0.13 | 3.4180 | 0.9766 | 273.66 KB |        3.50 |
