```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **379.0 μs** |   **3.06 μs** |  **1.82 μs** |  **3.66** |    **0.03** |        **-** |        **-** |       **-** |   **97.07 KB** |        **0.26** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   369.5 μs |   2.79 μs |  1.46 μs |  3.57 |    0.03 |        - |        - |       - |   49.44 KB |        0.13 |
| NativeSingle      | Skend(...)inOsc [21] | 1000  |   103.5 μs |   1.34 μs |  0.89 μs |  1.00 |    0.01 |   3.9063 |        - |       - |  379.71 KB |        1.00 |
| NativeParallel    | Skend(...)inOsc [21] | 1000  |   182.3 μs |   6.02 μs |  3.98 μs |  1.76 |    0.04 |  11.7188 |   5.8594 |       - |  958.69 KB |        2.52 |
|                   |                      |       |            |           |          |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **3,809.6 μs** |  **39.14 μs** | **25.89 μs** |  **2.63** |    **0.12** |        **-** |        **-** |       **-** |  **941.32 KB** |        **0.25** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 3,734.5 μs |  26.30 μs | 15.65 μs |  2.57 |    0.11 |        - |        - |       - |  471.54 KB |        0.12 |
| NativeSingle      | Skend(...)inOsc [21] | 10000 | 1,453.3 μs |  98.98 μs | 65.47 μs |  1.00 |    0.06 |  46.8750 |  46.8750 | 46.8750 | 3790.28 KB |        1.00 |
| NativeParallel    | Skend(...)inOsc [21] | 10000 | 2,390.6 μs | 135.30 μs | 89.49 μs |  1.65 |    0.09 | 156.2500 | 140.6250 | 78.1250 |  9555.1 KB |        2.52 |
