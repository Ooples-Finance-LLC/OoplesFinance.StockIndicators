```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **347.8 μs** |   **2.71 μs** |  **1.42 μs** |  **73.51 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   346.6 μs |   2.39 μs |  1.25 μs |  25.92 KB |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **3,547.7 μs** | **112.22 μs** | **74.22 μs** | **706.84 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 3,466.5 μs |  23.37 μs | 12.23 μs |  237.1 KB |
