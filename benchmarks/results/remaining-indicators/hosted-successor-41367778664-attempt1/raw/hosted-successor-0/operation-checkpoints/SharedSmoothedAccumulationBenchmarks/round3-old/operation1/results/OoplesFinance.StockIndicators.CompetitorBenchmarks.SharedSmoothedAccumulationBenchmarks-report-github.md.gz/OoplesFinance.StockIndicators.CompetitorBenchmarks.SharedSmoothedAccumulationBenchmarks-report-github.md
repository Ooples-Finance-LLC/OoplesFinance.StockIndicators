```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **360.2 μs** |  **2.89 μs** |  **1.51 μs** |  **73.57 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   347.8 μs |  7.88 μs |  4.69 μs |  25.91 KB |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **3,493.8 μs** | **54.71 μs** | **28.61 μs** | **706.83 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 3,422.1 μs | 26.32 μs | 13.76 μs | 237.06 KB |
