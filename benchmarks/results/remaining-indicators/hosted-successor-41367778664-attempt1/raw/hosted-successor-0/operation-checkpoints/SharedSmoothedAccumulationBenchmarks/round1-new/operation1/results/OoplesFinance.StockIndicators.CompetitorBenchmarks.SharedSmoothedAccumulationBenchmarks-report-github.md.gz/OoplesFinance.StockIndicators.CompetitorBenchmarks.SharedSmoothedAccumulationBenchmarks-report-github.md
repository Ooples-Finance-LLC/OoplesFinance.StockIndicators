```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **361.2 μs** |  **2.69 μs** |  **1.40 μs** |  **73.51 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   357.3 μs |  3.62 μs |  2.15 μs |  25.91 KB |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **3,634.2 μs** | **40.21 μs** | **23.93 μs** |  **706.9 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 3,599.8 μs | 53.67 μs | 28.07 μs | 237.08 KB |
