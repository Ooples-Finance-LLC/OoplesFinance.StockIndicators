```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **387.0 μs** |   **9.77 μs** |  **5.82 μs** |  **97.02 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   382.3 μs |   3.79 μs |  2.26 μs |  49.44 KB |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **3,947.3 μs** | **129.33 μs** | **85.55 μs** | **941.32 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 3,830.7 μs |  35.79 μs | 21.30 μs | 471.45 KB |
