```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **372.7 μs** |  **3.50 μs** |  **1.83 μs** |  **97.02 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   367.2 μs |  1.22 μs |  0.64 μs |  49.44 KB |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **3,817.6 μs** | **36.09 μs** | **23.87 μs** | **941.35 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 3,713.0 μs | 34.46 μs | 18.02 μs | 471.51 KB |
