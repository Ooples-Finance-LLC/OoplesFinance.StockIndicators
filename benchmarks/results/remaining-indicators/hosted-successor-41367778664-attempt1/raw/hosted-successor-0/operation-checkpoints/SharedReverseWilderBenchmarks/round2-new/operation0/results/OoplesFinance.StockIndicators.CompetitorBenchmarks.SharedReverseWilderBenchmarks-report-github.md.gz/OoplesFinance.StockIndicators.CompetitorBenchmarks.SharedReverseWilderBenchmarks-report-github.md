```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated  | Alloc Ratio |
|------------------ |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|-----------:|------------:|
| **BuilderFull**       | **1000**  |    **78.45 μs** |  **0.806 μs** |  **0.422 μs** |  **4.66** |    **0.05** |       **-** |      **-** |   **91.77 KB** |        **1.94** |
| BuilderLatestOnly | 1000  |    75.12 μs |  0.288 μs |  0.151 μs |  4.47 |    0.04 |  0.4883 |      - |   43.89 KB |        0.93 |
| NativeSingle      | 1000  |    16.82 μs |  0.255 μs |  0.152 μs |  1.00 |    0.01 |  0.4883 |      - |    47.2 KB |        1.00 |
| NativeParallel    | 1000  |    26.68 μs |  1.390 μs |  0.827 μs |  1.59 |    0.05 |  1.2207 |      - |  106.85 KB |        2.26 |
|                   |       |             |           |           |       |         |         |        |            |             |
| **BuilderFull**       | **10000** | **3,709.74 μs** | **25.965 μs** | **15.452 μs** | **21.30** |    **0.27** | **31.2500** |      **-** | **5102.48 KB** |       **10.88** |
| BuilderLatestOnly | 10000 | 3,676.51 μs | 91.824 μs | 60.736 μs | 21.11 |    0.42 | 31.2500 |      - | 4632.42 KB |        9.88 |
| NativeSingle      | 10000 |   174.15 μs |  3.374 μs |  2.231 μs |  1.00 |    0.02 |  4.8828 | 0.9766 |  469.08 KB |        1.00 |
| NativeParallel    | 10000 |   219.82 μs | 18.393 μs | 10.946 μs |  1.26 |    0.06 | 11.7188 | 1.9531 | 1056.09 KB |        2.25 |
