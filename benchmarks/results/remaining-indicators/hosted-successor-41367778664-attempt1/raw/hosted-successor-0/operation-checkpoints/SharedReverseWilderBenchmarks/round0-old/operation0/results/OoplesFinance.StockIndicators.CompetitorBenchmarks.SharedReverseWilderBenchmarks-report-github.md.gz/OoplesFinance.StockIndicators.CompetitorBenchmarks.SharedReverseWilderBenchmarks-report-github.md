```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean        | Error     | StdDev    | Gen0    | Allocated  |
|------------------ |------ |------------:|----------:|----------:|--------:|-----------:|
| **BuilderFull**       | **1000**  |    **77.21 μs** |  **0.808 μs** |  **0.481 μs** |       **-** |   **91.75 KB** |
| BuilderLatestOnly | 1000  |    75.20 μs |  0.534 μs |  0.279 μs |  0.4883 |   43.87 KB |
| **BuilderFull**       | **10000** | **3,615.80 μs** | **16.502 μs** |  **8.631 μs** | **31.2500** | **5102.46 KB** |
| BuilderLatestOnly | 10000 | 3,674.57 μs | 41.127 μs | 21.510 μs | 31.2500 |  4632.4 KB |
