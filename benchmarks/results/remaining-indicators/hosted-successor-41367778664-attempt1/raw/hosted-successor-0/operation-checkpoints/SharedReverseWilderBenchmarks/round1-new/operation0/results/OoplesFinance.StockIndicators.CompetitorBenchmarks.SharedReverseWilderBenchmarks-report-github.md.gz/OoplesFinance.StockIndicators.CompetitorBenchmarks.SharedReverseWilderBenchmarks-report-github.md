```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean        | Error     | StdDev    | Gen0    | Allocated  |
|------------------ |------ |------------:|----------:|----------:|--------:|-----------:|
| **BuilderFull**       | **1000**  |    **80.34 μs** |  **0.568 μs** |  **0.297 μs** |       **-** |   **91.77 KB** |
| BuilderLatestOnly | 1000  |    76.60 μs |  2.033 μs |  1.345 μs |  0.4883 |   43.89 KB |
| **BuilderFull**       | **10000** | **3,741.05 μs** | **80.906 μs** | **53.515 μs** | **31.2500** | **5102.51 KB** |
| BuilderLatestOnly | 10000 | 3,679.14 μs | 27.629 μs | 14.450 μs | 31.2500 | 4632.41 KB |
