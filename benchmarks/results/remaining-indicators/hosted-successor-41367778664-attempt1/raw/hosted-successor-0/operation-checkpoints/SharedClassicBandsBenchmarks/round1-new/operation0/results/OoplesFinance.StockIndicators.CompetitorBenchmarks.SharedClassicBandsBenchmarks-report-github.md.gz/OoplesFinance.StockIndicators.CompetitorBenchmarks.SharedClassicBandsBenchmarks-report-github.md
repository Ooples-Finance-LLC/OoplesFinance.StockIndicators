```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0   | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|-------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)bands [22]** | **1000**  |  **87.22 μs** |  **5.887 μs** |  **3.503 μs** |      **-** |      **-** |  **84.07 KB** |
| BuilderLatestOnly | TaLib(...)bands [22] | 1000  |  78.08 μs |  4.173 μs |  2.760 μs |      - |      - |  36.46 KB |
| **BuilderFull**       | **TaLib(...)bands [22]** | **10000** | **523.52 μs** |  **8.137 μs** |  **4.256 μs** | **7.8125** | **3.9063** | **787.56 KB** |
| BuilderLatestOnly | TaLib(...)bands [22] | 10000 | 493.60 μs | 52.872 μs | 34.971 μs |      - |      - | 317.73 KB |
