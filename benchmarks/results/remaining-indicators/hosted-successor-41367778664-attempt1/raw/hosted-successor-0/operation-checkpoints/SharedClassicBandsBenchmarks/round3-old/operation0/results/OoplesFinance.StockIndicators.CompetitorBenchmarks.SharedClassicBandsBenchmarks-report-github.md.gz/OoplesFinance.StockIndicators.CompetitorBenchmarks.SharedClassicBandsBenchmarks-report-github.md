```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0   | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|-------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)bands [22]** | **1000**  |  **86.26 μs** |  **9.711 μs** |  **5.779 μs** |      **-** |      **-** |  **84.07 KB** |
| BuilderLatestOnly | TaLib(...)bands [22] | 1000  |  77.43 μs |  2.390 μs |  1.250 μs |      - |      - |  36.46 KB |
| **BuilderFull**       | **TaLib(...)bands [22]** | **10000** | **544.56 μs** | **48.920 μs** | **29.111 μs** | **7.8125** | **3.9063** | **787.52 KB** |
| BuilderLatestOnly | TaLib(...)bands [22] | 10000 | 472.53 μs | 33.020 μs | 17.270 μs |      - |      - | 317.74 KB |
