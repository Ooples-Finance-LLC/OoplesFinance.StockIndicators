```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0   | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|-----------:|-----------:|------:|--------:|-------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)bands [22]** | **1000**  |  **93.573 μs** |  **6.2075 μs** |  **3.6940 μs** | **11.64** |    **0.45** |      **-** |      **-** |  **84.03 KB** |        **3.62** |
| BuilderLatestOnly | TaLib(...)bands [22] | 1000  |  80.642 μs |  5.5789 μs |  3.6901 μs | 10.03 |    0.45 |      - |      - |  36.46 KB |        1.57 |
| NativeSingle      | TaLib(...)bands [22] | 1000  |   8.039 μs |  0.1471 μs |  0.0875 μs |  1.00 |    0.01 | 0.2441 |      - |   23.2 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [22] | 1000  |   6.918 μs |  0.3064 μs |  0.1824 μs |  0.86 |    0.02 | 0.2441 |      - |  23.66 KB |        1.02 |
|                   |                      |       |            |            |            |       |         |        |        |           |             |
| **BuilderFull**       | **TaLib(...)bands [22]** | **10000** | **574.025 μs** | **87.9313 μs** | **58.1611 μs** |  **8.16** |    **0.79** | **7.8125** | **3.9063** | **787.52 KB** |        **3.36** |
| BuilderLatestOnly | TaLib(...)bands [22] | 10000 | 467.413 μs |  3.6397 μs |  1.9036 μs |  6.65 |    0.08 |      - |      - | 317.73 KB |        1.36 |
| NativeSingle      | TaLib(...)bands [22] | 10000 |  70.315 μs |  1.3081 μs |  0.8652 μs |  1.00 |    0.02 | 2.4414 | 0.9766 | 234.14 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [22] | 10000 |  50.523 μs |  4.9703 μs |  3.2876 μs |  0.72 |    0.05 | 2.4414 | 0.9766 |  234.6 KB |        1.00 |
