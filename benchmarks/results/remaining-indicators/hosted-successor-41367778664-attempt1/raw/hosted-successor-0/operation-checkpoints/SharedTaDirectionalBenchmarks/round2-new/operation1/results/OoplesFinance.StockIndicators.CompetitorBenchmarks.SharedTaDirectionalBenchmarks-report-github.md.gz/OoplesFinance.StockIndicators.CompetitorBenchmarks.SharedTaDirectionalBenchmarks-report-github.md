```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **164.270 μs** |  **1.3275 μs** |  **0.6943 μs** | **16.98** |    **0.13** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   158.889 μs |  2.2247 μs |  1.3239 μs | 16.42 |    0.17 |      - |  17.39 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDM [23] | 1000  |     9.677 μs |  0.1161 μs |  0.0691 μs |  1.00 |    0.01 | 0.0610 |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 1000  |    14.568 μs |  0.8508 μs |  0.5063 μs |  1.51 |    0.05 | 0.2441 |  27.23 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,632.121 μs** | **24.4071 μs** | **16.1438 μs** | **17.23** |    **0.17** |      **-** | **627.93 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 1,549.878 μs | 19.1885 μs | 11.4188 μs | 16.36 |    0.12 |      - | 158.13 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDM [23] | 10000 |    94.751 μs |  0.3541 μs |  0.1852 μs |  1.00 |    0.00 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 10000 |   150.168 μs |  6.5438 μs |  4.3283 μs |  1.58 |    0.04 | 2.9297 | 273.33 KB |        3.50 |
