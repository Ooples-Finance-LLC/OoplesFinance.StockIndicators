```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **590.9 μs** |  **3.74 μs** |  **1.96 μs** |     **65 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   590.5 μs |  3.92 μs |  2.59 μs |  17.41 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **6,227.8 μs** | **60.31 μs** | **35.89 μs** | **628.01 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 6,214.8 μs | 47.26 μs | 28.12 μs |  158.5 KB |
