```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |------------:|----------:|----------:|------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **594.23 μs** |  **5.605 μs** |  **3.336 μs** | **34.67** |    **0.20** |      **-** |  **64.98 KB** |        **8.42** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   607.87 μs |  4.676 μs |  2.783 μs | 35.47 |    0.17 |      - |  17.41 KB |        2.26 |
| NativeSingle      | TaLib.Functions.Dx | 1000  |    17.14 μs |  0.071 μs |  0.037 μs |  1.00 |    0.00 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 1000  |    25.01 μs |  2.303 μs |  1.523 μs |  1.46 |    0.08 | 0.2441 |  27.24 KB |        3.53 |
|                   |                    |       |             |           |           |       |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **6,189.20 μs** | **61.929 μs** | **36.853 μs** | **35.82** |    **0.23** |      **-** | **627.97 KB** |        **8.05** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 6,104.57 μs | 49.892 μs | 26.094 μs | 35.33 |    0.18 |      - | 158.19 KB |        2.03 |
| NativeSingle      | TaLib.Functions.Dx | 10000 |   172.81 μs |  0.799 μs |  0.528 μs |  1.00 |    0.00 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 10000 |   244.13 μs |  5.223 μs |  2.732 μs |  1.41 |    0.02 | 1.9531 | 273.35 KB |        3.50 |
