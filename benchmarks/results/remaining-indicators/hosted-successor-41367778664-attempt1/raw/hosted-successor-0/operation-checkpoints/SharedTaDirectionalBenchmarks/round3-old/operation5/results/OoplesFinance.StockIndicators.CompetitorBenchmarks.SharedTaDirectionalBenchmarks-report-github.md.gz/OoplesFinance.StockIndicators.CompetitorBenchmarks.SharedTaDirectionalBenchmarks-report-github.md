```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |-------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **543.4 μs** |   **6.10 μs** |  **3.63 μs** |  **65.64 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   534.1 μs |   2.66 μs |  1.58 μs |  18.06 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **5,998.9 μs** | **127.84 μs** | **84.56 μs** | **637.61 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 5,593.6 μs | 121.55 μs | 80.40 μs | 167.77 KB |
