```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **276.7 μs** |  **2.23 μs** |  **1.33 μs** |  **65.04 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   267.7 μs |  1.51 μs |  0.79 μs |   17.4 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **2,845.5 μs** | **60.34 μs** | **39.91 μs** | **627.92 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,796.8 μs | 37.57 μs | 24.85 μs | 158.09 KB |
