```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev    | Allocated |
|------------------ |-------------------- |------ |-----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **570.9 μs** |   **7.42 μs** |   **4.42 μs** |  **65.64 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   566.3 μs |   6.27 μs |   4.15 μs |  18.06 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **6,088.1 μs** |  **47.70 μs** |  **31.55 μs** | **637.54 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 5,806.0 μs | 233.24 μs | 154.27 μs | 167.76 KB |
