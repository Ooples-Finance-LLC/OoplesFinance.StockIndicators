```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **568.3 μs** |  **5.07 μs** |  **2.65 μs** |  **66.72 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   555.9 μs |  6.84 μs |  4.53 μs |  19.13 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **5,856.3 μs** | **77.80 μs** | **46.30 μs** | **638.64 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 5,741.8 μs | 29.58 μs | 17.60 μs | 168.81 KB |
