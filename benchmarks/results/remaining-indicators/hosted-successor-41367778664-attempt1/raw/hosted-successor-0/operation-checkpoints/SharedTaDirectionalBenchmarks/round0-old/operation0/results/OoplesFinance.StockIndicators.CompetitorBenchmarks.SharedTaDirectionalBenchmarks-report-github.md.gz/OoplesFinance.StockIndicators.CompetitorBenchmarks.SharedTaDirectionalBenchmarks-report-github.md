```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **156.2 μs** |  **1.23 μs** |  **0.73 μs** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   146.9 μs |  0.96 μs |  0.57 μs |  17.39 KB |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **1,559.8 μs** | **14.61 μs** |  **9.66 μs** | **627.95 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 1,479.5 μs | 28.63 μs | 17.04 μs | 158.12 KB |
