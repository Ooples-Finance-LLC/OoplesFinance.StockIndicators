```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **159.1 μs** |  **1.87 μs** |  **0.98 μs** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   152.5 μs |  1.28 μs |  0.76 μs |  17.39 KB |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,561.4 μs** | **11.05 μs** |  **6.58 μs** | **627.95 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 1,508.8 μs | 40.53 μs | 26.81 μs | 158.06 KB |
