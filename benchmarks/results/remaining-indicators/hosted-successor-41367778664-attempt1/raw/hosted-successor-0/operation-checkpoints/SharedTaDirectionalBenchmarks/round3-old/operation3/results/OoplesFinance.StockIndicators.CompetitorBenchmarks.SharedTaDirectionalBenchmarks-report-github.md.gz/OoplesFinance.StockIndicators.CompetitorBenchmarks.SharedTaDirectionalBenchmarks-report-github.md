```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **286.4 μs** |  **1.62 μs** |  **0.85 μs** |  **65.04 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   276.9 μs |  2.40 μs |  1.43 μs |   17.4 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **2,928.9 μs** | **21.00 μs** | **10.98 μs** | **627.94 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,852.7 μs | 27.79 μs | 16.54 μs | 158.11 KB |
