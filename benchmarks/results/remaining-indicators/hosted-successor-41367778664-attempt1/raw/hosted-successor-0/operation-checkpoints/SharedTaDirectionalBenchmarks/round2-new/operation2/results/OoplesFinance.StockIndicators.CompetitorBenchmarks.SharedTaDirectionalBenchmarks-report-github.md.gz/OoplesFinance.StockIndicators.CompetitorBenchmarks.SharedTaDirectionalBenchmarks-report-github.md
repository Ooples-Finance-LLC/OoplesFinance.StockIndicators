```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0   | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|-------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **292.492 μs** | **23.6882 μs** | **14.0965 μs** | **35.05** |    **1.61** |      **-** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   280.546 μs |  3.3059 μs |  1.7291 μs | 33.62 |    0.23 |      - |      - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib(...)lusDI [22] | 1000  |     8.345 μs |  0.0511 μs |  0.0338 μs |  1.00 |    0.01 | 0.0610 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 1000  |    13.108 μs |  0.0991 μs |  0.0655 μs |  1.57 |    0.01 | 0.2441 |      - |  27.24 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |        |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **3,107.170 μs** | **61.6730 μs** | **36.7006 μs** | **33.74** |    **0.48** |      **-** |      **-** | **628.02 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,895.502 μs | 23.8825 μs | 14.2121 μs | 31.45 |    0.32 |      - |      - | 158.12 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDI [22] | 10000 |    92.088 μs |  1.4567 μs |  0.8669 μs |  1.00 |    0.01 |      - |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 10000 |   156.758 μs | 12.7148 μs |  8.4101 μs |  1.70 |    0.09 | 2.9297 | 0.9766 | 273.34 KB |        3.50 |
