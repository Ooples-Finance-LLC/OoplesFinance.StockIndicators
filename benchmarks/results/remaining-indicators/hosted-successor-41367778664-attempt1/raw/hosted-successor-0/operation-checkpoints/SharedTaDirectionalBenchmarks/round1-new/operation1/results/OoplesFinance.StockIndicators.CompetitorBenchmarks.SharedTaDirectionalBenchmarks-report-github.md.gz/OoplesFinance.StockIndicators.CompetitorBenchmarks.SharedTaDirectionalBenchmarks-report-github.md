```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **164.8 μs** | **10.12 μs** |  **6.69 μs** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   155.3 μs |  1.83 μs |  1.09 μs |  17.39 KB |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,581.8 μs** | **22.92 μs** | **11.99 μs** | **627.93 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 1,502.7 μs | 12.16 μs |  7.24 μs | 158.13 KB |
