```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **175.1 μs** |  **1.27 μs** |  **0.67 μs** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   157.1 μs |  0.90 μs |  0.54 μs |  17.39 KB |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **1,702.2 μs** |  **7.83 μs** |  **4.10 μs** | **627.91 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 1,578.9 μs | 18.56 μs | 11.04 μs | 158.11 KB |
