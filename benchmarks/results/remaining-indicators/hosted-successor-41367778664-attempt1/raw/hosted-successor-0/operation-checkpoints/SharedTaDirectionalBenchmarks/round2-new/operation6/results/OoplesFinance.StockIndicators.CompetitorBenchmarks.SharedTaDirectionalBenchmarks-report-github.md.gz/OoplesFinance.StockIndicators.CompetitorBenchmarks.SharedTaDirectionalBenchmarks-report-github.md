```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **575.40 μs** |  **13.415 μs** |   **7.983 μs** | **39.41** |    **0.56** |      **-** |  **66.71 KB** |        **4.45** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   573.42 μs |  16.938 μs |  11.204 μs | 39.28 |    0.76 |      - |  19.13 KB |        1.28 |
| NativeSingle      | TaLib.Functions.Adxr | 1000  |    14.60 μs |   0.162 μs |   0.085 μs |  1.00 |    0.01 | 0.1221 |  14.99 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 1000  |    27.66 μs |   1.550 μs |   1.025 μs |  1.89 |    0.07 | 0.4883 |  45.43 KB |        3.03 |
|                   |                      |       |             |            |            |       |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **6,041.26 μs** | **202.645 μs** | **134.037 μs** | **41.11** |    **0.90** |      **-** | **638.63 KB** |        **4.10** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 5,890.37 μs |  37.642 μs |  24.898 μs | 40.08 |    0.27 |      - | 168.84 KB |        1.08 |
| NativeSingle      | TaLib.Functions.Adxr | 10000 |   146.97 μs |   1.646 μs |   0.861 μs |  1.00 |    0.01 | 0.9766 | 155.62 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 10000 |   227.69 μs |  22.789 μs |  15.074 μs |  1.55 |    0.10 | 5.8594 | 467.32 KB |        3.00 |
