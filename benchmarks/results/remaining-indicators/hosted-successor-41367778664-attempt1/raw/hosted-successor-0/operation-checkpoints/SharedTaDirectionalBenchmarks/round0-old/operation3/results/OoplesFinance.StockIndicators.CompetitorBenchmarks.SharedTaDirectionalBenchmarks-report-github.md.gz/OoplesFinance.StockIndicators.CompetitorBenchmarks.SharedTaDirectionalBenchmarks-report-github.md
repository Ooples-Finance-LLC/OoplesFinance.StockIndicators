```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **276.1 μs** |  **4.82 μs** |  **2.52 μs** |  **65.04 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   277.3 μs |  2.51 μs |  1.31 μs |   17.4 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **2,823.3 μs** | **35.44 μs** | **18.53 μs** | **627.91 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,743.5 μs | 34.17 μs | 20.33 μs |  158.1 KB |
