```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |-------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **557.3 μs** |   **2.44 μs** |  **1.28 μs** |  **65.64 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   564.1 μs |  12.62 μs |  8.35 μs |  18.06 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **5,771.3 μs** |  **37.04 μs** | **19.37 μs** | **637.51 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 5,751.0 μs | 142.86 μs | 85.01 μs | 167.81 KB |
