```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **291.6 μs** |  **8.76 μs** |  **5.21 μs** |  **65.04 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   278.1 μs |  7.89 μs |  5.22 μs |   17.4 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **2,948.5 μs** | **42.63 μs** | **25.37 μs** | **627.95 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,873.7 μs | 32.75 μs | 21.67 μs |  158.1 KB |
