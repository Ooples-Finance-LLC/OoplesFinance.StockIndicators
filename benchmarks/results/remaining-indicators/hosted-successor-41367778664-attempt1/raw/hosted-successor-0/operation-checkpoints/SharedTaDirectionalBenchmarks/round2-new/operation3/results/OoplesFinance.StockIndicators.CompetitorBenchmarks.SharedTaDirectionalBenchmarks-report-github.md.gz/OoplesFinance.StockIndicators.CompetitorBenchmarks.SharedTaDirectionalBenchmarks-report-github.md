```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0   | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|-------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **285.539 μs** |  **6.8614 μs** |  **4.0831 μs** | **34.39** |    **0.47** |      **-** |      **-** |  **65.04 KB** |        **8.43** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   275.168 μs |  1.6928 μs |  0.8854 μs | 33.14 |    0.12 |      - |      - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDI [23] | 1000  |     8.303 μs |  0.0328 μs |  0.0195 μs |  1.00 |    0.00 | 0.0610 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 1000  |    13.180 μs |  0.2858 μs |  0.1495 μs |  1.59 |    0.02 | 0.3662 |      - |  27.24 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |        |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **2,940.460 μs** | **58.6223 μs** | **34.8852 μs** | **34.66** |    **0.41** |      **-** |      **-** |  **627.9 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,876.218 μs | 65.4794 μs | 43.3106 μs | 33.90 |    0.50 |      - |      - | 158.11 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDI [23] | 10000 |    84.835 μs |  0.5358 μs |  0.2802 μs |  1.00 |    0.00 |      - |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 10000 |   141.960 μs | 11.9714 μs |  7.9183 μs |  1.67 |    0.09 | 2.9297 | 0.9766 | 273.34 KB |        3.50 |
