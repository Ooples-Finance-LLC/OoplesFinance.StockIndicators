```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0   | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|-------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **156.980 μs** |  **3.2482 μs** |  **1.9329 μs** | **16.76** |    **0.20** |      **-** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   148.849 μs |  3.3913 μs |  2.0181 μs | 15.89 |    0.21 |      - |      - |  17.39 KB |        2.25 |
| NativeSingle      | TaLib(...)lusDM [22] | 1000  |     9.367 μs |  0.0389 μs |  0.0232 μs |  1.00 |    0.00 | 0.0610 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 1000  |    14.638 μs |  0.6311 μs |  0.3756 μs |  1.56 |    0.04 | 0.2441 |      - |  27.23 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |        |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **1,559.009 μs** | **12.4734 μs** |  **7.4227 μs** | **16.89** |    **0.08** |      **-** |      **-** | **627.91 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 1,509.301 μs | 37.1858 μs | 24.5961 μs | 16.35 |    0.26 |      - |      - | 158.06 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDM [22] | 10000 |    92.326 μs |  0.2425 μs |  0.1268 μs |  1.00 |    0.00 |      - |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 10000 |   147.204 μs |  5.7754 μs |  3.4368 μs |  1.59 |    0.04 | 2.9297 | 0.9766 | 273.33 KB |        3.50 |
