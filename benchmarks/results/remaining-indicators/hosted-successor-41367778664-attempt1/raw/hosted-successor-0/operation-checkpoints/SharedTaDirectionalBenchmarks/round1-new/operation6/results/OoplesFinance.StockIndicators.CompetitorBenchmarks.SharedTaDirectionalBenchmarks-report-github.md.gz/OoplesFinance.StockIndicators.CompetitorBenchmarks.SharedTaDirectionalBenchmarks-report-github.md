```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **582.4 μs** |   **8.49 μs** |  **5.62 μs** |  **66.71 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   573.3 μs |   3.62 μs |  1.89 μs |  19.13 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **6,089.5 μs** | **114.87 μs** | **75.98 μs** | **638.63 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 5,988.1 μs |  54.33 μs | 28.42 μs | 168.82 KB |
