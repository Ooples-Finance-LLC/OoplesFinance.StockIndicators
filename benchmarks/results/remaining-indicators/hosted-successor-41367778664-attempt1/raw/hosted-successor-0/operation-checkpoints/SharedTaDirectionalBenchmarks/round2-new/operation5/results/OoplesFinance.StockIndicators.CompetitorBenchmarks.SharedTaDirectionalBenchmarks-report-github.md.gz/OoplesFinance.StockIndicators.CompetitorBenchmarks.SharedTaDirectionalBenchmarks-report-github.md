```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|-----------:|----------:|------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **557.54 μs** |   **3.299 μs** |  **1.726 μs** | **45.64** |    **0.17** |      **-** |  **65.65 KB** |        **8.67** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   553.71 μs |   2.776 μs |  1.652 μs | 45.33 |    0.17 |      - |  18.06 KB |        2.39 |
| NativeSingle      | TaLib.Functions.Adx | 1000  |    12.22 μs |   0.048 μs |  0.031 μs |  1.00 |    0.00 |      - |   7.57 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 1000  |    25.57 μs |   1.550 μs |  1.025 μs |  2.09 |    0.08 | 0.2441 |  26.71 KB |        3.53 |
|                   |                     |       |             |            |           |       |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **6,103.77 μs** | **149.063 μs** | **88.705 μs** | **49.37** |    **0.74** |      **-** | **637.54 KB** |        **8.19** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 5,828.51 μs |  39.664 μs | 23.604 μs | 47.14 |    0.33 |      - |  167.7 KB |        2.15 |
| NativeSingle      | TaLib.Functions.Adx | 10000 |   123.64 μs |   1.284 μs |  0.764 μs |  1.00 |    0.01 |      - |  77.89 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 10000 |   190.11 μs |   9.730 μs |  5.790 μs |  1.54 |    0.05 | 1.9531 | 272.82 KB |        3.50 |
