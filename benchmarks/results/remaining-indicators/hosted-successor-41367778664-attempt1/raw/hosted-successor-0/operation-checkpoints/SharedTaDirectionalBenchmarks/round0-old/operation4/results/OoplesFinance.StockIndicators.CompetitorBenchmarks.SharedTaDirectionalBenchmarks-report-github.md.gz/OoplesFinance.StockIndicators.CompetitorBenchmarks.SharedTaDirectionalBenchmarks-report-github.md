```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **605.1 μs** |  **9.27 μs** |  **4.85 μs** |     **65 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   601.1 μs |  7.97 μs |  4.17 μs |  17.41 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **6,299.6 μs** | **49.39 μs** | **25.83 μs** | **628.23 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 6,259.3 μs | 47.58 μs | 24.89 μs | 158.24 KB |
