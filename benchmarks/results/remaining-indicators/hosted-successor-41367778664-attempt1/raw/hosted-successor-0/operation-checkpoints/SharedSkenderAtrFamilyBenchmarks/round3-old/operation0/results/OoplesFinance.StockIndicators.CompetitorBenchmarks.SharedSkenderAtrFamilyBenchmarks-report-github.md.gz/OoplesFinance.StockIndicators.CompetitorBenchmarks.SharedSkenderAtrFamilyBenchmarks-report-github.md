```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skend(...)elier [21]** | **1000**  |   **196.9 μs** |  **2.39 μs** |  **1.42 μs** |  **73.28 KB** |
| BuilderLatestOnly | Skend(...)elier [21] | 1000  |   188.9 μs |  1.59 μs |  0.83 μs |  25.68 KB |
| **BuilderFull**       | **Skend(...)elier [21]** | **10000** | **2,114.5 μs** | **25.85 μs** | **15.38 μs** | **706.54 KB** |
| BuilderLatestOnly | Skend(...)elier [21] | 10000 | 2,012.4 μs | 22.12 μs | 11.57 μs |  236.7 KB |
