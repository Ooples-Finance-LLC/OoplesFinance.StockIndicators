```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skend(...)Bands [21]** | **1000**  |   **264.0 μs** |  **4.86 μs** |  **2.54 μs** |  **97.39 KB** |
| BuilderLatestOnly | Skend(...)Bands [21] | 1000  |   259.5 μs |  3.50 μs |  2.31 μs |  49.79 KB |
| **BuilderFull**       | **Skend(...)Bands [21]** | **10000** | **2,692.9 μs** | **35.48 μs** | **18.56 μs** | **941.58 KB** |
| BuilderLatestOnly | Skend(...)Bands [21] | 10000 | 2,706.5 μs | 70.73 μs | 46.78 μs | 471.74 KB |
