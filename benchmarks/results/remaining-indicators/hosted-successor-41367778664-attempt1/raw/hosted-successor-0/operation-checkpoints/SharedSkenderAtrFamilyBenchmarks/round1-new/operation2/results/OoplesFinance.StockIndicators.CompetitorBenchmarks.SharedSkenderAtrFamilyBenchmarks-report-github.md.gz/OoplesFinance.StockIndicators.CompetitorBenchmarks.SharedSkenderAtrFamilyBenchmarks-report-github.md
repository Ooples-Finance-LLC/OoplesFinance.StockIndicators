```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skend(...)Bands [21]** | **1000**  |   **266.5 μs** | **29.37 μs** | **19.43 μs** |  **97.43 KB** |
| BuilderLatestOnly | Skend(...)Bands [21] | 1000  |   248.6 μs |  1.63 μs |  0.85 μs |  49.83 KB |
| **BuilderFull**       | **Skend(...)Bands [21]** | **10000** | **2,593.5 μs** | **18.46 μs** |  **9.65 μs** | **941.61 KB** |
| BuilderLatestOnly | Skend(...)Bands [21] | 10000 | 2,550.1 μs | 77.54 μs | 51.29 μs | 471.79 KB |
