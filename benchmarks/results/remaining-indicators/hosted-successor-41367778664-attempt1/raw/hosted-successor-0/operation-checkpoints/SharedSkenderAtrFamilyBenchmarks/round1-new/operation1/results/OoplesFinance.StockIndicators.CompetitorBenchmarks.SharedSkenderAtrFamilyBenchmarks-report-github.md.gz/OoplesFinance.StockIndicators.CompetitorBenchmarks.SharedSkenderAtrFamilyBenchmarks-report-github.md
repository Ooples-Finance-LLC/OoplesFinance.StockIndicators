```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Allocated  |
|------------------ |------------------- |------ |-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetKeltner** | **1000**  |   **286.5 μs** |  **2.84 μs** |  **1.49 μs** |   **104.7 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 1000  |   278.0 μs |  1.54 μs |  0.91 μs |    57.1 KB |
| **BuilderFull**       | **Skender.GetKeltner** | **10000** | **2,930.6 μs** | **15.68 μs** |  **9.33 μs** | **1019.33 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 10000 | 2,882.4 μs | 30.74 μs | 18.29 μs |  549.39 KB |
