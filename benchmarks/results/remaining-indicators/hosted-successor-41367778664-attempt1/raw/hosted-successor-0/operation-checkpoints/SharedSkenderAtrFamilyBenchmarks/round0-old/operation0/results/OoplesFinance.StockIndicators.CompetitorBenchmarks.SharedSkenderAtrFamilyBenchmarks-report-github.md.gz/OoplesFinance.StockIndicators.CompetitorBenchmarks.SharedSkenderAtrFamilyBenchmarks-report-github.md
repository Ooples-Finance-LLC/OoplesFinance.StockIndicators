```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skend(...)elier [21]** | **1000**  |   **197.3 μs** |  **2.43 μs** |  **1.27 μs** |  **73.28 KB** |
| BuilderLatestOnly | Skend(...)elier [21] | 1000  |   188.8 μs |  2.29 μs |  1.36 μs |  25.68 KB |
| **BuilderFull**       | **Skend(...)elier [21]** | **10000** | **2,108.3 μs** | **45.31 μs** | **26.96 μs** | **706.54 KB** |
| BuilderLatestOnly | Skend(...)elier [21] | 10000 | 2,044.0 μs | 51.32 μs | 33.95 μs |  236.7 KB |
