```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skend(...)Bands [21]** | **1000**  |   **255.4 μs** |  **5.08 μs** |  **3.02 μs** |  **97.39 KB** |
| BuilderLatestOnly | Skend(...)Bands [21] | 1000  |   258.2 μs |  1.57 μs |  1.04 μs |  49.79 KB |
| **BuilderFull**       | **Skend(...)Bands [21]** | **10000** | **2,654.7 μs** | **21.48 μs** | **12.78 μs** | **941.57 KB** |
| BuilderLatestOnly | Skend(...)Bands [21] | 10000 | 2,560.9 μs | 19.84 μs | 11.81 μs | 471.76 KB |
