```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error     | StdDev   | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |------------------- |------ |-----------:|----------:|---------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetKeltner** | **1000**  |   **283.2 μs** |   **6.60 μs** |  **3.92 μs** |  **2.34** |    **0.04** |        **-** |        **-** |       **-** |  **104.74 KB** |        **0.29** |
| BuilderLatestOnly | Skender.GetKeltner | 1000  |   278.0 μs |   1.90 μs |  1.13 μs |  2.30 |    0.02 |        - |        - |       - |    57.1 KB |        0.16 |
| NativeSingle      | Skender.GetKeltner | 1000  |   120.8 μs |   1.72 μs |  1.02 μs |  1.00 |    0.01 |   3.9063 |   0.9766 |       - |  360.53 KB |        1.00 |
| NativeParallel    | Skender.GetKeltner | 1000  |   200.3 μs |  17.34 μs | 11.47 μs |  1.66 |    0.09 |  11.7188 |   5.8594 |       - |     911 KB |        2.53 |
|                   |                    |       |            |           |          |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skender.GetKeltner** | **10000** | **2,905.6 μs** |  **22.94 μs** | **15.17 μs** |  **1.80** |    **0.04** |        **-** |        **-** |       **-** | **1019.18 KB** |        **0.28** |
| BuilderLatestOnly | Skender.GetKeltner | 10000 | 2,851.6 μs | 119.65 μs | 79.14 μs |  1.77 |    0.06 |        - |        - |       - |   549.4 KB |        0.15 |
| NativeSingle      | Skender.GetKeltner | 10000 | 1,614.9 μs |  66.53 μs | 39.59 μs |  1.00 |    0.03 |  46.8750 |  46.8750 | 46.8750 | 3595.38 KB |        1.00 |
| NativeParallel    | Skender.GetKeltner | 10000 | 2,441.5 μs | 157.54 μs | 93.75 μs |  1.51 |    0.07 | 156.2500 | 140.6250 | 78.1250 | 9067.97 KB |        2.52 |
