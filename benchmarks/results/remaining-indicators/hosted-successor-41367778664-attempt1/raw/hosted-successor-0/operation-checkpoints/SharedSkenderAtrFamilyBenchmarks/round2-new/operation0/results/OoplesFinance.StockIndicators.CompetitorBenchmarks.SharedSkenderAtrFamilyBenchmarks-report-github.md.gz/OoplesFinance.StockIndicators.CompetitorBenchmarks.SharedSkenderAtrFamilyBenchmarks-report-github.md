```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)elier [21]** | **1000**  |   **195.88 μs** |   **1.817 μs** |  **1.081 μs** |  **2.02** |    **0.02** |       **-** |       **-** |   **73.28 KB** |        **0.33** |
| BuilderLatestOnly | Skend(...)elier [21] | 1000  |   188.55 μs |   1.471 μs |  0.875 μs |  1.95 |    0.02 |       - |       - |   25.68 KB |        0.12 |
| NativeSingle      | Skend(...)elier [21] | 1000  |    96.89 μs |   1.188 μs |  0.786 μs |  1.00 |    0.01 |  2.4414 |  0.9766 |  223.22 KB |        1.00 |
| NativeParallel    | Skend(...)elier [21] | 1000  |   163.83 μs |  20.472 μs | 13.541 μs |  1.69 |    0.13 |  5.8594 |  1.9531 |  566.86 KB |        2.54 |
|                   |                      |       |             |            |           |       |         |         |         |            |             |
| **BuilderFull**       | **Skend(...)elier [21]** | **10000** | **2,118.87 μs** |  **28.203 μs** | **16.783 μs** |  **1.48** |    **0.01** |       **-** |       **-** |  **706.53 KB** |        **0.32** |
| BuilderLatestOnly | Skend(...)elier [21] | 10000 | 2,026.87 μs |  21.320 μs | 12.687 μs |  1.42 |    0.01 |       - |       - |  236.72 KB |        0.11 |
| NativeSingle      | Skend(...)elier [21] | 10000 | 1,426.90 μs |  10.809 μs |  5.653 μs |  1.00 |    0.01 | 23.4375 | 15.6250 | 2227.18 KB |        1.00 |
| NativeParallel    | Skend(...)elier [21] | 10000 | 2,148.38 μs | 148.530 μs | 98.243 μs |  1.51 |    0.07 | 62.5000 | 46.8750 | 5647.04 KB |        2.54 |
