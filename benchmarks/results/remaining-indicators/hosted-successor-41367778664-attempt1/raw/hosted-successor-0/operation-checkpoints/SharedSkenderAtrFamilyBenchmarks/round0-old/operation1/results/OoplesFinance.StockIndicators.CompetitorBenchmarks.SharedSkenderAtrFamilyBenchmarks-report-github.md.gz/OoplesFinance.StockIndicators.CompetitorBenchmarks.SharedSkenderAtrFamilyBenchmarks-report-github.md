```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Allocated  |
|------------------ |------------------- |------ |-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetKeltner** | **1000**  |   **300.4 μs** |  **4.75 μs** |  **2.48 μs** |  **104.71 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 1000  |   289.4 μs |  1.80 μs |  0.94 μs |   57.06 KB |
| **BuilderFull**       | **Skender.GetKeltner** | **10000** | **2,998.8 μs** | **15.83 μs** |  **8.28 μs** | **1019.27 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 10000 | 2,922.1 μs | 21.49 μs | 11.24 μs |  549.33 KB |
