```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skend(...)elier [21]** | **1000**  |   **196.7 μs** |  **2.18 μs** |  **1.14 μs** |  **73.28 KB** |
| BuilderLatestOnly | Skend(...)elier [21] | 1000  |   190.9 μs |  0.85 μs |  0.44 μs |  25.68 KB |
| **BuilderFull**       | **Skend(...)elier [21]** | **10000** | **2,119.5 μs** | **19.93 μs** | **11.86 μs** | **706.54 KB** |
| BuilderLatestOnly | Skend(...)elier [21] | 10000 | 2,031.5 μs |  9.19 μs |  4.81 μs | 236.71 KB |
