```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)Bands [21]** | **1000**  |   **254.9 μs** |   **7.02 μs** |  **4.18 μs** |  **1.90** |    **0.03** |        **-** |        **-** |       **-** |   **97.47 KB** |        **0.30** |
| BuilderLatestOnly | Skend(...)Bands [21] | 1000  |   274.5 μs |   6.25 μs |  4.13 μs |  2.05 |    0.03 |        - |        - |       - |   49.83 KB |        0.15 |
| NativeSingle      | Skend(...)Bands [21] | 1000  |   134.0 μs |   1.84 μs |  1.22 μs |  1.00 |    0.01 |   3.9063 |        - |       - |  329.24 KB |        1.00 |
| NativeParallel    | Skend(...)Bands [21] | 1000  |   208.0 μs |   9.20 μs |  4.81 μs |  1.55 |    0.04 |   9.7656 |   5.8594 |       - |  832.72 KB |        2.53 |
|                   |                      |       |            |           |          |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)Bands [21]** | **10000** | **2,629.7 μs** |  **60.68 μs** | **40.13 μs** |  **1.41** |    **0.03** |        **-** |        **-** |       **-** |  **941.62 KB** |        **0.29** |
| BuilderLatestOnly | Skend(...)Bands [21] | 10000 | 2,574.2 μs |  68.93 μs | 45.60 μs |  1.38 |    0.03 |        - |        - |       - |   471.8 KB |        0.14 |
| NativeSingle      | Skend(...)Bands [21] | 10000 | 1,864.9 μs |  46.47 μs | 30.74 μs |  1.00 |    0.02 |  46.8750 |  46.8750 | 46.8750 |  3282.8 KB |        1.00 |
| NativeParallel    | Skend(...)Bands [21] | 10000 | 2,856.3 μs | 134.51 μs | 88.97 μs |  1.53 |    0.05 | 156.2500 | 140.6250 | 78.1250 | 8286.56 KB |        2.52 |
