```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |------ |-----------:|----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **1000**  |   **228.2 μs** |  **70.12 μs** |  **46.38 μs** |  **0.37** |    **0.07** |   **7.8125** |        **-** |  **128.46 KB** |        **0.26** |
| BuilderLatestOnly | 1000  |   211.3 μs |  38.01 μs |  25.14 μs |  0.34 |    0.04 |   3.9063 |        - |   80.85 KB |        0.16 |
| NativeSingle      | 1000  |   616.3 μs |   6.73 μs |   4.01 μs |  1.00 |    0.01 |  27.3438 |   7.8125 |  499.64 KB |        1.00 |
| NativeParallel    | 1000  |   336.1 μs |  19.04 μs |  12.59 μs |  0.55 |    0.02 |  31.2500 |   9.7656 |  525.33 KB |        1.05 |
|                   |       |            |           |           |       |         |          |          |            |             |
| **BuilderFull**       | **10000** | **1,606.2 μs** |  **32.92 μs** |  **17.22 μs** |  **0.25** |    **0.00** |  **62.5000** |  **31.2500** | **1183.63 KB** |        **0.24** |
| BuilderLatestOnly | 10000 | 1,744.2 μs | 326.45 μs | 215.93 μs |  0.27 |    0.03 |  31.2500 |  15.6250 |   713.8 KB |        0.14 |
| NativeSingle      | 10000 | 6,468.2 μs |  41.48 μs |  27.43 μs |  1.00 |    0.01 | 250.0000 | 187.5000 | 5035.29 KB |        1.00 |
| NativeParallel    | 10000 | 3,463.1 μs | 130.36 μs |  68.18 μs |  0.54 |    0.01 | 312.5000 | 218.7500 |  5131.1 KB |        1.02 |
