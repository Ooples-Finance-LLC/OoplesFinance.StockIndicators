```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |----------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetRocWb** | **1000**  |   **404.7 μs** |  **2.94 μs** |  **1.75 μs** |       **-** |  **105.36 KB** |
| BuilderLatestOnly | Skender.GetRocWb | 1000  |   392.0 μs |  2.06 μs |  1.22 μs |       - |   57.72 KB |
| **BuilderFull**       | **Skender.GetRocWb** | **10000** | **3,969.4 μs** | **34.62 μs** | **22.90 μs** | **31.2500** | **1019.97 KB** |
| BuilderLatestOnly | Skender.GetRocWb | 10000 | 3,962.6 μs | 18.54 μs | 11.03 μs | 31.2500 |  550.15 KB |
