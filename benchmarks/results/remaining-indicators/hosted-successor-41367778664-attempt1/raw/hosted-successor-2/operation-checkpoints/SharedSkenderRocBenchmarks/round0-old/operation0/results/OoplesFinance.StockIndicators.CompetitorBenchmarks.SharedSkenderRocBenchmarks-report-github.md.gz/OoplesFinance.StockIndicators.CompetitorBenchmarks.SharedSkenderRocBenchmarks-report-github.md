```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |----------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetRocWb** | **1000**  |   **406.1 μs** |  **6.66 μs** |  **3.48 μs** |       **-** |  **105.36 KB** |
| BuilderLatestOnly | Skender.GetRocWb | 1000  |   393.5 μs |  2.64 μs |  1.74 μs |       - |   57.72 KB |
| **BuilderFull**       | **Skender.GetRocWb** | **10000** | **4,028.3 μs** | **28.63 μs** | **18.94 μs** | **31.2500** | **1019.94 KB** |
| BuilderLatestOnly | Skender.GetRocWb | 10000 | 4,039.7 μs | 21.18 μs | 11.08 μs | 31.2500 |  550.15 KB |
