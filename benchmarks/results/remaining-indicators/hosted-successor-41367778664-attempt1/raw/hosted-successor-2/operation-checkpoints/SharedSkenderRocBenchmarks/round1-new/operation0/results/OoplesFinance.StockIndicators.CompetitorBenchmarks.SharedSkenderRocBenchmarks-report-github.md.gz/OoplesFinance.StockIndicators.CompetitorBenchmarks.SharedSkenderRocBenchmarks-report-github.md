```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |----------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetRocWb** | **1000**  |   **457.7 μs** |  **6.29 μs** |  **3.29 μs** |       **-** |  **105.38 KB** |
| BuilderLatestOnly | Skender.GetRocWb | 1000  |   441.9 μs |  1.51 μs |  1.00 μs |       - |   57.74 KB |
| **BuilderFull**       | **Skender.GetRocWb** | **10000** | **4,524.3 μs** | **80.63 μs** | **47.98 μs** | **31.2500** | **1019.99 KB** |
| BuilderLatestOnly | Skender.GetRocWb | 10000 | 4,546.1 μs | 20.30 μs | 10.62 μs | 31.2500 |  550.18 KB |
