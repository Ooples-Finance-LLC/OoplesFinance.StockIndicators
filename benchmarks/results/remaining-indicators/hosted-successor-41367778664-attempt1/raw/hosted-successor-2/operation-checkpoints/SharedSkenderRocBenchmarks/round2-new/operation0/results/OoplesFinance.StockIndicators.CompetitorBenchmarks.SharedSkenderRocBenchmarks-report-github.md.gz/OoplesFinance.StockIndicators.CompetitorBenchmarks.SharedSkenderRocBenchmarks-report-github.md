```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |----------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetRocWb** | **1000**  |   **444.64 μs** |   **3.466 μs** |   **2.063 μs** |  **8.59** |    **0.16** |        **-** |        **-** |        **-** |  **105.35 KB** |        **0.46** |
| BuilderLatestOnly | Skender.GetRocWb | 1000  |   438.94 μs |   3.482 μs |   2.303 μs |  8.48 |    0.16 |        - |        - |        - |   57.74 KB |        0.25 |
| NativeSingle      | Skender.GetRocWb | 1000  |    51.79 μs |   1.510 μs |   0.999 μs |  1.00 |    0.03 |  13.6719 |   3.4180 |        - |  231.09 KB |        1.00 |
| NativeParallel    | Skender.GetRocWb | 1000  |   100.63 μs |   7.687 μs |   4.574 μs |  1.94 |    0.09 |  37.1094 |  11.7188 |        - |  586.66 KB |        2.54 |
|                   |                  |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetRocWb** | **10000** | **4,421.23 μs** |  **22.360 μs** |  **13.306 μs** |  **4.97** |    **0.07** |  **31.2500** |        **-** |        **-** | **1019.95 KB** |        **0.44** |
| BuilderLatestOnly | Skender.GetRocWb | 10000 | 4,391.16 μs |  27.262 μs |  16.223 μs |  4.93 |    0.07 |  31.2500 |        - |        - |  550.18 KB |        0.24 |
| NativeSingle      | Skender.GetRocWb | 10000 |   890.08 μs |  20.448 μs |  12.168 μs |  1.00 |    0.02 | 148.4375 | 148.4375 | 148.4375 | 2306.53 KB |        1.00 |
| NativeParallel    | Skender.GetRocWb | 10000 | 2,798.13 μs | 550.167 μs | 363.901 μs |  3.14 |    0.39 | 515.6250 | 468.7500 | 234.3750 |  5845.3 KB |        2.53 |
