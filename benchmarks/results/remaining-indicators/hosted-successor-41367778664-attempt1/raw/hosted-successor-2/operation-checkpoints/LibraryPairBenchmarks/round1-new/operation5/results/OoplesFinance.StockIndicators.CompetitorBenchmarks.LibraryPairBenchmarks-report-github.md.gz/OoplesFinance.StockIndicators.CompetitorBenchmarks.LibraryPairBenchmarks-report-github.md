```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId        | Mean     | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |-------------- |---------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **QuanTAlib.Wma** | **154.5 μs** | **30.57 μs** | **18.19 μs** |  **1.01** |    **0.15** |  **65.77 KB** |        **1.00** |
|        |       |               |          |          |          |       |         |           |             |
| **Ooples** | **10000** | **QuanTAlib.Wma** | **254.7 μs** | **83.14 μs** | **49.48 μs** |  **1.03** |    **0.25** |  **636.1 KB** |        **1.00** |
