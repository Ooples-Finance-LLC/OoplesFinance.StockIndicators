```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)gence [50]** |  **4.893 ms** | **0.0349 ms** | **0.0208 ms** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |   **290.13 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)gence [50] |  9.211 ms | 0.2223 ms | 0.1471 ms |  1.88 |    0.03 |         - |         - |         - |  4583.87 KB |       15.80 |
|            |       |                      |           |           |           |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)gence [50]** |  **7.140 ms** | **1.5522 ms** | **0.9237 ms** |  **1.01** |    **0.17** |         **-** |         **-** |         **-** |  **2856.93 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)gence [50] | 24.439 ms | 1.7245 ms | 1.0262 ms |  3.47 |    0.43 | 2000.0000 | 1000.0000 | 1000.0000 | 34698.83 KB |       12.15 |
