```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |-----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **Trady(...)lator [45]** |   **596.1 μs** | **122.55 μs** | **81.06 μs** |  **1.02** |    **0.20** | **107.88 KB** |        **1.00** |
|        |       |                      |            |           |          |       |         |           |             |
| **Ooples** | **10000** | **Trady(...)lator [45]** | **2,550.6 μs** |  **84.78 μs** | **44.34 μs** |  **1.00** |    **0.02** | **1040.2 KB** |        **1.00** |
