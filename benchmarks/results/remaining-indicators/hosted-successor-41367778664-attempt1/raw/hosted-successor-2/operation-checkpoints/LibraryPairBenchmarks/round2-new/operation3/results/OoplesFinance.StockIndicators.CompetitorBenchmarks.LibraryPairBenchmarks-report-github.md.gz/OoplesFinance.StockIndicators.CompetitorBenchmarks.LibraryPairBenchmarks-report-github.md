```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId        | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------- |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Rma** |    **433.2 μs** |  **28.71 μs** |  **17.09 μs** |  **1.00** |    **0.05** |   **97.6 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Rma |    290.3 μs |  23.38 μs |  15.46 μs |  0.67 |    0.04 |   55.1 KB |        0.56 |
|            |       |               |             |           |           |       |         |           |             |
| **Ooples**     | **10000** | **QuanTAlib.Rma** | **21,049.5 μs** | **627.87 μs** | **373.63 μs** |  **1.00** |    **0.02** | **5245.7 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Rma |  1,561.4 μs | 149.49 μs |  98.88 μs |  0.07 |    0.00 | 477.05 KB |        0.09 |
