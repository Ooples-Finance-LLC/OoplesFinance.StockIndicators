```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId        | Mean        | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |-------------- |------------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **QuanTAlib.Rma** |    **417.7 μs** |  **23.37 μs** | **13.91 μs** |  **1.00** |    **0.04** |   **97.58 KB** |        **1.00** |
|        |       |               |             |           |          |       |         |            |             |
| **Ooples** | **10000** | **QuanTAlib.Rma** | **10,795.2 μs** | **147.30 μs** | **87.66 μs** |  **1.00** |    **0.01** | **5245.96 KB** |        **1.00** |
