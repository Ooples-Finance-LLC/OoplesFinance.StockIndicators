```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)lator [45]** |    **489.4 μs** |  **18.28 μs** |  **10.88 μs** |  **1.00** |    **0.03** |   **107.88 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)lator [45] |  6,389.2 μs | 146.42 μs |  76.58 μs | 13.06 |    0.31 |   1702.9 KB |       15.79 |
|            |       |                      |             |           |           |       |         |             |             |
| **Ooples**     | **10000** | **Trady(...)lator [45]** |  **3,110.9 μs** | **814.75 μs** | **538.91 μs** |  **1.03** |    **0.23** |  **1037.24 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)lator [45] | 13,595.4 μs | 606.99 μs | 401.48 μs |  4.48 |    0.70 | 13490.73 KB |       13.01 |
