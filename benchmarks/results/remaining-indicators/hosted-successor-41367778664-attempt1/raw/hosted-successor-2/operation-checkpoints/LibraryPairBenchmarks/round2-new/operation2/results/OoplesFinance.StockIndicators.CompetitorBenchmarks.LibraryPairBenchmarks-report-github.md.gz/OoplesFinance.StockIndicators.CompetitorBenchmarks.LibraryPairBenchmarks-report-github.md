```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean       | Error       | StdDev      | Median     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|------------:|------------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Fwma** |   **396.2 μs** |    **19.85 μs** |    **13.13 μs** |   **392.9 μs** |  **1.00** |    **0.04** |   **15.98 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Fwma |   698.8 μs |    27.40 μs |    14.33 μs |   694.6 μs |  1.77 |    0.06 |  262.73 KB |       16.44 |
|            |       |                |            |             |             |            |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Fwma** | **1,465.5 μs** | **2,341.84 μs** | **1,548.98 μs** |   **506.9 μs** |  **2.16** |    **2.72** |  **164.43 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Fwma | 1,128.1 μs |    28.00 μs |    16.66 μs | 1,125.5 μs |  1.66 |    0.89 | 2572.22 KB |       15.64 |
