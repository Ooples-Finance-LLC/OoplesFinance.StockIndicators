```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId        | Mean        | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |-------------- |------------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **QuanTAlib.Rma** |    **420.4 μs** |    **33.27 μs** |    **19.80 μs** |  **1.00** |    **0.06** |   **97.58 KB** |        **1.00** |
|        |       |               |             |             |             |       |         |            |             |
| **Ooples** | **10000** | **QuanTAlib.Rma** | **14,078.0 μs** | **3,627.12 μs** | **2,399.12 μs** |  **1.03** |    **0.24** | **5245.63 KB** |        **1.00** |
