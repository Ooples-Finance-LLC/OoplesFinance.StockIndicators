```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|----------:|----------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)Index [37]** |   **2.527 ms** | **0.0363 ms** | **0.0216 ms** |  **1.00** |    **0.01** |         **-** |         **-** |  **108.34 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)Index [37] |  53.041 ms | 0.9491 ms | 0.4964 ms | 20.99 |    0.25 |         - |         - | 4767.06 KB |       44.00 |
|            |       |                      |            |           |           |       |         |           |           |            |             |
| **Ooples**     | **10000** | **Trady(...)Index [37]** |   **2.527 ms** | **0.0296 ms** | **0.0155 ms** |  **1.00** |    **0.01** |         **-** |         **-** | **1036.06 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)Index [37] | 153.575 ms | 6.8476 ms | 4.5293 ms | 60.76 |    1.75 | 2000.0000 | 1000.0000 | 48262.3 KB |       46.58 |
