```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean       | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |-----------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Trady(...)lator [50]** |   **807.8 μs** |    **40.92 μs** |    **24.35 μs** |  **1.00** |    **0.04** |  **105.64 KB** |        **1.00** |
|        |       |                      |            |             |             |       |         |            |             |
| **Ooples** | **10000** | **Trady(...)lator [50]** | **5,762.7 μs** | **1,680.68 μs** | **1,111.67 μs** |  **1.03** |    **0.25** | **1037.96 KB** |        **1.00** |
