```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Dwma** |   **275.2 μs** |   **9.40 μs** |   **4.92 μs** |  **1.00** |    **0.02** |   **66.41 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Dwma | 1,396.9 μs |  42.71 μs |  22.34 μs |  5.08 |    0.11 |  547.69 KB |        8.25 |
|            |       |                |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Dwma** |   **994.5 μs** | **202.07 μs** | **133.66 μs** |  **1.02** |    **0.18** |  **636.73 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Dwma | 2,011.2 μs |  70.00 μs |  36.61 μs |  2.05 |    0.25 | 5449.13 KB |        8.56 |
