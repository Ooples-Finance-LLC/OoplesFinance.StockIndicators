```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error        | StdDev       | Median      | Ratio  | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-------------:|-------------:|------------:|-------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)erage [37]** |    **144.3 μs** |     **15.03 μs** |      **8.94 μs** |    **140.9 μs** |   **1.00** |    **0.08** |  **65.77 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)erage [37] |  7,805.0 μs |     77.94 μs |     51.55 μs |  7,810.0 μs |  54.26 |    2.96 | 913.49 KB |       13.89 |
|            |       |                      |             |              |              |             |        |         |           |             |
| **Ooples**     | **10000** | **Trady(...)erage [37]** |    **362.7 μs** |     **79.77 μs** |     **52.76 μs** |    **339.8 μs** |   **1.02** |    **0.19** | **637.09 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)erage [37] | 56,408.9 μs | 30,315.38 μs | 20,051.75 μs | 43,550.4 μs | 158.34 |   57.85 | 8952.2 KB |       14.05 |
