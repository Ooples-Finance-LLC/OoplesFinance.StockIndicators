```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean      | Error      | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |----------:|-----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Trady(...)gence [50]** |  **4.876 ms** |  **0.0760 ms** | **0.0503 ms** |  **1.00** |    **0.01** |  **290.13 KB** |        **1.00** |
|        |       |                      |           |            |           |       |         |            |             |
| **Ooples** | **10000** | **Trady(...)gence [50]** | **38.427 ms** | **14.6900 ms** | **8.7418 ms** |  **1.10** |    **0.52** | **2857.21 KB** |        **1.00** |
