```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean         | Error       | StdDev      | Ratio  | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |-------------:|------------:|------------:|-------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)erage [40]** |     **277.1 μs** |    **29.81 μs** |    **19.71 μs** |   **1.00** |    **0.09** |    **64.78 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)erage [40] |  23,131.4 μs |   394.06 μs |   260.64 μs |  83.85 |    5.48 |  1489.44 KB |       22.99 |
|            |       |                      |              |             |             |        |         |             |             |
| **Ooples**     | **10000** | **Trady(...)erage [40]** |   **1,873.8 μs** |    **90.01 μs** |    **47.08 μs** |   **1.00** |    **0.03** |   **636.09 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)erage [40] | 234,626.4 μs | 5,476.66 μs | 3,622.47 μs | 125.28 |    3.48 | 13293.03 KB |       20.90 |
