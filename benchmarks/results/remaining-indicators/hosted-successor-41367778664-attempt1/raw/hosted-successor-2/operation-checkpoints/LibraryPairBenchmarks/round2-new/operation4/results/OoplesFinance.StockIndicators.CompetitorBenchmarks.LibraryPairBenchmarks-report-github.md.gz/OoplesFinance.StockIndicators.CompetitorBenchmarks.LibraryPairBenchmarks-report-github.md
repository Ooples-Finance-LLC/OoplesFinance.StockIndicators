```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId       | Mean       | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------- |-----------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.T3** | **1,044.5 μs** |    **54.95 μs** |    **36.34 μs** |  **1.00** |    **0.05** |  **105.89 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.T3 |   401.3 μs |    48.74 μs |    32.24 μs |  0.38 |    0.03 |      74 KB |        0.70 |
|            |       |              |            |             |             |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.T3** | **8,740.8 μs** | **2,220.78 μs** | **1,468.91 μs** |  **1.04** |    **0.28** | **1037.23 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.T3 |   936.1 μs |    31.97 μs |    19.02 μs |  0.11 |    0.02 |  645.31 KB |        0.62 |
