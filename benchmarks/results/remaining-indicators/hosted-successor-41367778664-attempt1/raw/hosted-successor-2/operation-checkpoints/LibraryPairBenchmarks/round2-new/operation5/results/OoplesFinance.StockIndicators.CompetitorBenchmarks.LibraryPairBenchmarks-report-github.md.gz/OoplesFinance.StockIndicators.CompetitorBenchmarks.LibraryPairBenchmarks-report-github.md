```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId        | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Wma** |   **139.8 μs** | **16.32 μs** | **10.79 μs** |  **1.01** |    **0.10** |   **65.77 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Wma |   714.5 μs | 48.37 μs | 28.78 μs |  5.14 |    0.41 |  262.55 KB |        3.99 |
|            |       |               |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Wma** |   **266.7 μs** | **17.74 μs** | **10.56 μs** |  **1.00** |    **0.05** |  **636.43 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Wma | 1,133.6 μs | 38.62 μs | 22.98 μs |  4.26 |    0.17 | 2572.32 KB |        4.04 |
