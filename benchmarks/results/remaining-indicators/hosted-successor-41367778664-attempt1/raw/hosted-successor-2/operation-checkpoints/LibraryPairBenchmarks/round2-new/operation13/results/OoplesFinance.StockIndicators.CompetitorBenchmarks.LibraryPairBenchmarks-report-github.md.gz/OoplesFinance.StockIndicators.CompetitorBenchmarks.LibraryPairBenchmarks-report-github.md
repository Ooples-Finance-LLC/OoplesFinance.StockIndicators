```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error      | StdDev     | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |----------:|-----------:|-----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)ogram [59]** |  **4.373 ms** |  **0.0148 ms** |  **0.0077 ms** |  **1.00** |    **0.00** |         **-** |         **-** |         **-** |   **240.77 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)ogram [59] |  9.711 ms |  0.2399 ms |  0.1254 ms |  2.22 |    0.03 |         - |         - |         - |  4823.95 KB |       20.04 |
|            |       |                      |           |            |            |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)ogram [59]** | **33.067 ms** | **20.7925 ms** | **13.7529 ms** |  **1.41** |    **1.37** |         **-** |         **-** |         **-** |  **2368.07 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)ogram [59] | 31.359 ms |  5.2698 ms |  3.1360 ms |  1.34 |    1.12 | 2000.0000 | 1000.0000 | 1000.0000 | 36354.28 KB |       15.35 |
