```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)lator [50]** |    **870.6 μs** |    **44.48 μs** |    **26.47 μs** |  **1.00** |    **0.04** |         **-** |         **-** |         **-** |   **105.64 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)lator [50] |  6,659.1 μs |   184.41 μs |   109.74 μs |  7.66 |    0.25 |         - |         - |         - |  3073.38 KB |       29.09 |
|            |       |                      |             |             |             |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)lator [50]** |  **5,453.4 μs** |   **158.12 μs** |   **104.59 μs** |  **1.00** |    **0.03** |         **-** |         **-** |         **-** |  **1037.96 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)lator [50] | 23,739.4 μs | 4,296.76 μs | 2,842.04 μs |  4.35 |    0.50 | 1000.0000 | 1000.0000 | 1000.0000 | 24967.15 KB |       24.05 |
