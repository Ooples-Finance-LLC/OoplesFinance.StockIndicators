```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId          | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0      | Allocated | Alloc Ratio |
|----------- |------ |---------------- |----------:|----------:|----------:|------:|--------:|----------:|----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetBeta** | **15.112 ms** | **0.4965 ms** | **0.2597 ms** |  **1.00** |    **0.02** |         **-** |   **1.56 MB** |        **1.00** |
| Competitor | 1000  | Skender.GetBeta |  2.169 ms | 0.0457 ms | 0.0272 ms |  0.14 |    0.00 |         - |   2.66 MB |        1.70 |
|            |       |                 |           |           |           |       |         |           |           |             |
| **Ooples**     | **10000** | **Skender.GetBeta** | **24.788 ms** | **6.7615 ms** | **4.4723 ms** |  **1.03** |    **0.26** |         **-** |  **15.71 MB** |        **1.00** |
| Competitor | 10000 | Skender.GetBeta |  7.452 ms | 0.3606 ms | 0.1886 ms |  0.31 |    0.06 | 1000.0000 |  26.89 MB |        1.71 |
