```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId           | Mean       | Error       | StdDev      | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |----------------- |-----------:|------------:|------------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Afirma** |   **743.8 μs** |    **17.11 μs** |     **8.95 μs** |  **1.00** |    **0.02** |  **24.68 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Afirma | 1,208.7 μs |    39.72 μs |    26.27 μs |  1.63 |    0.04 |  55.45 KB |        2.25 |
|            |       |                  |            |             |             |       |         |           |             |
| **Ooples**     | **10000** | **QuanTAlib.Afirma** | **6,206.0 μs** | **2,842.61 μs** | **1,691.59 μs** |  **1.22** |    **0.93** | **243.45 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Afirma | 1,826.9 μs |    56.29 μs |    33.50 μs |  0.36 |    0.25 | 477.65 KB |        1.96 |
