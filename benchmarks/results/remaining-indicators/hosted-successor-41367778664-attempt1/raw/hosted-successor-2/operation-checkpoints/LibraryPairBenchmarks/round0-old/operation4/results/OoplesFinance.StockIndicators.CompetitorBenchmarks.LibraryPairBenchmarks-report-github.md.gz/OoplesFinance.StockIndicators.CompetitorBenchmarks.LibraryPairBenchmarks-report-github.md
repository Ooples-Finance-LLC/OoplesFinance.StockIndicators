```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId       | Mean     | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |------------- |---------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **QuanTAlib.T3** | **1.012 ms** | **0.0299 ms** | **0.0178 ms** |  **1.00** |    **0.02** |  **105.89 KB** |        **1.00** |
|        |       |              |          |           |           |       |         |            |             |
| **Ooples** | **10000** | **QuanTAlib.T3** | **9.866 ms** | **0.2362 ms** | **0.1235 ms** |  **1.00** |    **0.02** | **1037.23 KB** |        **1.00** |
