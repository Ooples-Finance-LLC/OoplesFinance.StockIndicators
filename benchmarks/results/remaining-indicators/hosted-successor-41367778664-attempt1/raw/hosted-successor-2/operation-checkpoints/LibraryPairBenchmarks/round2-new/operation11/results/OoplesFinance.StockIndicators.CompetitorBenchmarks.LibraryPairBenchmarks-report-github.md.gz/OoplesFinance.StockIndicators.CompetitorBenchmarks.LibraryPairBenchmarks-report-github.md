```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)nnels [31]** |  **2.490 ms** | **0.0443 ms** | **0.0264 ms** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |   **219.05 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)nnels [31] |  7.715 ms | 0.2285 ms | 0.1195 ms |  3.10 |    0.05 |         - |         - |         - |  3955.55 KB |       18.06 |
|            |       |                      |           |           |           |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)nnels [31]** | **20.841 ms** | **6.8546 ms** | **4.5339 ms** |  **1.04** |    **0.29** |         **-** |         **-** |         **-** |  **2153.32 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)nnels [31] | 24.938 ms | 2.8627 ms | 1.4972 ms |  1.24 |    0.24 | 2000.0000 | 1000.0000 | 1000.0000 | 33801.02 KB |       15.70 |
