```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId         | Mean       | Error       | StdDev    | Median     | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------- |-----------:|------------:|----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **QuanTAlib.Dwma** |   **414.2 μs** |    **18.86 μs** |  **11.22 μs** |   **414.3 μs** |  **1.00** |    **0.04** |  **66.41 KB** |        **1.00** |
|        |       |                |            |             |           |            |       |         |           |             |
| **Ooples** | **10000** | **QuanTAlib.Dwma** | **2,010.3 μs** | **1,295.54 μs** | **856.92 μs** | **1,491.0 μs** |  **1.16** |    **0.65** | **636.73 KB** |        **1.00** |
