```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **Trady(...)erage [40]** |   **275.7 μs** |  **21.23 μs** |  **14.04 μs** |  **1.00** |    **0.07** |  **64.78 KB** |        **1.00** |
|        |       |                      |            |           |           |       |         |           |             |
| **Ooples** | **10000** | **Trady(...)erage [40]** | **1,618.0 μs** | **535.29 μs** | **354.06 μs** |  **1.04** |    **0.29** | **636.09 KB** |        **1.00** |
