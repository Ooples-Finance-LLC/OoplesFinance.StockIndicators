```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAdl** |   **772.5 μs** |    **54.31 μs** |  **35.93 μs** |  **1.00** |    **0.06** |  **246.88 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAdl |   575.8 μs |    22.65 μs |  13.48 μs |  0.75 |    0.04 |  274.64 KB |        1.11 |
|            |       |                |            |             |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAdl** | **5,052.4 μs** | **1,570.68 μs** | **821.50 μs** |  **1.03** |    **0.25** | **2814.32 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAdl | 1,487.6 μs |    26.75 μs |  15.92 μs |  0.30 |    0.06 | 2656.48 KB |        0.94 |
