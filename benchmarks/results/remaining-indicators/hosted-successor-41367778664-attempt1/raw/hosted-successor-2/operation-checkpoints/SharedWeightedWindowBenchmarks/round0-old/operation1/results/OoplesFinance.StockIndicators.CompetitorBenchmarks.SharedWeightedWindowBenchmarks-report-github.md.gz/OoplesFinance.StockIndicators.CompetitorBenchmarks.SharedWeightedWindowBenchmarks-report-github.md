```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean     | Error     | StdDev   | Gen0    | Gen1    | Allocated  |
|------------------ |---------- |------ |---------:|----------:|---------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Dwma**      | **1000**  | **142.2 μs** |   **6.01 μs** |  **3.98 μs** |  **7.8125** |       **-** |  **173.22 KB** |
| BuilderLatestOnly | Dwma      | 1000  | 130.8 μs |   6.59 μs |  4.36 μs |  6.8359 |       - |  125.63 KB |
| **BuilderFull**       | **Dwma**      | **10000** | **886.7 μs** | **144.53 μs** | **95.60 μs** | **93.7500** | **39.0625** | **1609.01 KB** |
| BuilderLatestOnly | Dwma      | 10000 | 812.8 μs |  70.46 μs | 46.61 μs | 66.4063 | 11.7188 | 1139.17 KB |
