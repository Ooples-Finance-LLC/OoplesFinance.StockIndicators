```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean     | Error     | StdDev   | Gen0    | Gen1    | Allocated  |
|------------------ |---------- |------ |---------:|----------:|---------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Dwma**      | **1000**  | **146.8 μs** |  **10.99 μs** |  **7.27 μs** |  **7.8125** |       **-** |  **173.26 KB** |
| BuilderLatestOnly | Dwma      | 1000  | 134.8 μs |   5.78 μs |  3.82 μs |  6.8359 |       - |  125.64 KB |
| **BuilderFull**       | **Dwma**      | **10000** | **864.6 μs** | **107.74 μs** | **71.27 μs** | **93.7500** | **39.0625** | **1609.04 KB** |
| BuilderLatestOnly | Dwma      | 10000 | 800.5 μs |  22.20 μs | 11.61 μs | 62.5000 |  7.8125 |  1139.2 KB |
