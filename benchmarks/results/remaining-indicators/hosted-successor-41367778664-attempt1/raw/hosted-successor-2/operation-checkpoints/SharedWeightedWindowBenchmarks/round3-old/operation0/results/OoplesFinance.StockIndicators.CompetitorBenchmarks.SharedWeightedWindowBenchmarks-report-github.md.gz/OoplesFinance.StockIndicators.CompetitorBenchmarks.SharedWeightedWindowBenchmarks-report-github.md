```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Wma**       | **1000**  |  **19.92 μs** | **2.343 μs** | **1.550 μs** |  **2.9297** |       **-** |  **58.45 KB** |
| BuilderLatestOnly | Wma       | 1000  |  11.74 μs | 2.207 μs | 1.154 μs |  0.6104 |       - |  10.56 KB |
| **BuilderFull**       | **Wma**       | **10000** | **100.32 μs** | **9.473 μs** | **4.955 μs** | **33.2031** | **11.7188** | **550.98 KB** |
| BuilderLatestOnly | Wma       | 10000 |  90.68 μs | 9.701 μs | 6.416 μs |  4.8828 |  0.9766 |  80.88 KB |
