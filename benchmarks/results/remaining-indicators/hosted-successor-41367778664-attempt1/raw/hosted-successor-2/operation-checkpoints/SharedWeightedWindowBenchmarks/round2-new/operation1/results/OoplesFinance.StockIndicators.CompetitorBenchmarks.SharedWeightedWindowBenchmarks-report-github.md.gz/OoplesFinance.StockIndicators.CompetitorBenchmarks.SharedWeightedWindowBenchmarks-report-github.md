```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error    | StdDev   | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |---------- |------ |-----------:|---------:|---------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Dwma**      | **1000**  |   **147.2 μs** |  **9.15 μs** |  **6.05 μs** |  **0.84** |    **0.04** |   **7.8125** |       **-** |  **173.26 KB** |        **0.32** |
| BuilderLatestOnly | Dwma      | 1000  |   137.6 μs |  5.76 μs |  3.81 μs |  0.78 |    0.02 |   6.8359 |       - |  125.64 KB |        0.23 |
| NativeSingle      | Dwma      | 1000  |   176.2 μs |  4.70 μs |  3.11 μs |  1.00 |    0.02 |  32.2266 |  0.9766 |  540.12 KB |        1.00 |
| NativeParallel    | Dwma      | 1000  |   159.7 μs |  2.75 μs |  1.44 μs |  0.91 |    0.02 |  36.1328 |  0.9766 |  588.75 KB |        1.09 |
|                   |           |       |            |          |          |       |         |          |         |            |             |
| **BuilderFull**       | **Dwma**      | **10000** |   **796.2 μs** | **32.47 μs** | **16.98 μs** |  **0.46** |    **0.01** |  **93.7500** | **39.0625** | **1609.04 KB** |        **0.30** |
| BuilderLatestOnly | Dwma      | 10000 |   803.4 μs | 22.46 μs | 11.75 μs |  0.46 |    0.01 |  62.5000 |  7.8125 | 1139.19 KB |        0.21 |
| NativeSingle      | Dwma      | 10000 | 1,748.4 μs | 22.24 μs | 13.23 μs |  1.00 |    0.01 | 328.1250 | 62.5000 |    5441 KB |        1.00 |
| NativeParallel    | Dwma      | 10000 | 1,082.7 μs | 78.37 μs | 46.64 μs |  0.62 |    0.03 | 335.9375 | 62.5000 | 5489.94 KB |        1.01 |
