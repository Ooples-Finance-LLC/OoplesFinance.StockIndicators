```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated  |
|------------------ |---------- |------ |---------:|---------:|---------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Dwma**      | **1000**  | **145.2 μs** |  **8.09 μs** |  **5.35 μs** |  **7.8125** |       **-** |  **173.23 KB** |
| BuilderLatestOnly | Dwma      | 1000  | 137.2 μs |  4.90 μs |  3.24 μs |  6.8359 |       - |  125.64 KB |
| **BuilderFull**       | **Dwma**      | **10000** | **849.8 μs** | **97.20 μs** | **64.29 μs** | **93.7500** | **39.0625** | **1609.01 KB** |
| BuilderLatestOnly | Dwma      | 10000 | 792.7 μs | 50.50 μs | 30.05 μs | 62.5000 |  7.8125 |  1139.2 KB |
