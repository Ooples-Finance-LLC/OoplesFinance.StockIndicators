```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |---------- |------ |----------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Wma**       | **1000**  |  **17.68 μs** |  **4.170 μs** |  **2.481 μs** |  **0.25** |    **0.03** |   **2.9297** |       **-** |   **58.45 KB** |        **0.23** |
| BuilderLatestOnly | Wma       | 1000  |  10.56 μs |  0.959 μs |  0.501 μs |  0.15 |    0.01 |   0.6104 |       - |   10.56 KB |        0.04 |
| NativeSingle      | Wma       | 1000  |  70.53 μs |  0.480 μs |  0.285 μs |  1.00 |    0.01 |  15.1367 |  0.4883 |  254.32 KB |        1.00 |
| NativeParallel    | Wma       | 1000  |  58.75 μs |  9.429 μs |  6.237 μs |  0.83 |    0.08 |  16.1133 |  0.4883 |  261.98 KB |        1.03 |
|                   |           |       |           |           |           |       |         |          |         |            |             |
| **BuilderFull**       | **Wma**       | **10000** | **110.62 μs** |  **4.344 μs** |  **2.874 μs** |  **0.16** |    **0.00** |  **33.2031** | **11.7188** |  **550.98 KB** |        **0.21** |
| BuilderLatestOnly | Wma       | 10000 |  86.87 μs |  5.574 μs |  3.317 μs |  0.12 |    0.00 |   4.8828 |  0.9766 |   80.88 KB |        0.03 |
| NativeSingle      | Wma       | 10000 | 701.90 μs |  5.977 μs |  3.557 μs |  1.00 |    0.01 | 156.2500 | 31.2500 | 2564.12 KB |        1.00 |
| NativeParallel    | Wma       | 10000 | 447.41 μs | 27.556 μs | 18.226 μs |  0.64 |    0.02 | 156.2500 | 31.2500 | 2571.95 KB |        1.00 |
