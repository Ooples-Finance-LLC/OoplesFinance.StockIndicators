```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Wma**       | **1000**  |  **20.75 μs** | **0.845 μs** | **0.442 μs** |  **2.9297** |       **-** |  **58.45 KB** |
| BuilderLatestOnly | Wma       | 1000  |  10.54 μs | 0.690 μs | 0.361 μs |  0.6104 |       - |  10.56 KB |
| **BuilderFull**       | **Wma**       | **10000** | **106.91 μs** | **8.991 μs** | **4.703 μs** | **33.2031** | **11.7188** | **550.98 KB** |
| BuilderLatestOnly | Wma       | 10000 |  89.75 μs | 5.888 μs | 3.895 μs |  4.8828 |  0.4883 |  80.88 KB |
