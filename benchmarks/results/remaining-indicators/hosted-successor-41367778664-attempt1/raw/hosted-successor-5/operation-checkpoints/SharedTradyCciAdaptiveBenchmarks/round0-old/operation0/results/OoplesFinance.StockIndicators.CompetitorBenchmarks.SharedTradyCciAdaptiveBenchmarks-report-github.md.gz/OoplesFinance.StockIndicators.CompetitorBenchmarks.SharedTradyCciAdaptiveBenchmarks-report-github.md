```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Commo(...)Index [21]** | **1000**  |   **237.1 μs** |   **4.66 μs** |   **2.77 μs** |       **-** |       **-** |  **70.53 KB** |
| BuilderLatestOnly | Commo(...)Index [21] | 1000  |   238.9 μs |  20.50 μs |  13.56 μs |       - |       - |  22.88 KB |
| **BuilderFull**       | **Commo(...)Index [21]** | **10000** | **2,304.8 μs** | **177.77 μs** | **117.58 μs** | **31.2500** | **15.6250** | **633.46 KB** |
| BuilderLatestOnly | Commo(...)Index [21] | 10000 | 2,290.2 μs | 157.99 μs | 104.50 μs |       - |       - | 163.62 KB |
