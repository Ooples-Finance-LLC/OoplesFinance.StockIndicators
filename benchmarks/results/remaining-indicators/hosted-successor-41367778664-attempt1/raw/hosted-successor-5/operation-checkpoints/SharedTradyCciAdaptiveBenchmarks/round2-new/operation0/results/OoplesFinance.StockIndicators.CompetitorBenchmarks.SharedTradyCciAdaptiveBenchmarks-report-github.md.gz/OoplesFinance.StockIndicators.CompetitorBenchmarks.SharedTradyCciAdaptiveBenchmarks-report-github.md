```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | Gen0      | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|----------:|---------:|---------:|------------:|------------:|
| **BuilderFull**       | **Commo(...)Index [21]** | **1000**  |     **286.7 μs** |    **77.68 μs** |    **51.38 μs** |  **0.02** |         **-** |        **-** |        **-** |    **70.53 KB** |       **0.016** |
| BuilderLatestOnly | Commo(...)Index [21] | 1000  |     229.5 μs |     7.43 μs |     3.89 μs |  0.02 |         - |        - |        - |    22.88 KB |       0.005 |
| NativeSingle      | Commo(...)Index [21] | 1000  |  12,996.0 μs |   112.60 μs |    74.48 μs |  1.00 |  250.0000 |        - |        - |  4398.11 KB |       1.000 |
| NativeParallel    | Commo(...)Index [21] | 1000  |   6,535.6 μs |   131.30 μs |    68.67 μs |  0.50 |  266.6667 |  66.6667 |        - |  4407.32 KB |       1.002 |
|                   |                      |       |              |             |             |       |           |          |          |             |             |
| **BuilderFull**       | **Commo(...)Index [21]** | **10000** |   **2,199.3 μs** |    **10.23 μs** |     **5.35 μs** |  **0.02** |   **31.2500** |  **15.6250** |        **-** |   **633.45 KB** |       **0.014** |
| BuilderLatestOnly | Commo(...)Index [21] | 10000 |   2,185.8 μs |    38.47 μs |    20.12 μs |  0.02 |         - |        - |        - |   163.62 KB |       0.004 |
| NativeSingle      | Commo(...)Index [21] | 10000 | 138,032.2 μs |   536.82 μs |   280.77 μs |  1.00 | 2750.0000 | 500.0000 | 250.0000 |  45275.6 KB |       1.000 |
| NativeParallel    | Commo(...)Index [21] | 10000 |  79,712.5 μs | 3,066.36 μs | 2,028.21 μs |  0.58 | 2750.0000 | 500.0000 | 250.0000 | 45393.96 KB |       1.003 |
