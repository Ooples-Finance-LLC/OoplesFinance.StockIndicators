```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)chRsi [24]** | **1000**  |   **487.18 μs** |  **6.198 μs** |  **3.688 μs** | **22.80** |    **0.37** |       **-** |       **-** |  **182.03 KB** |        **5.84** |
| BuilderLatestOnly | TaLib(...)chRsi [24] | 1000  |   480.31 μs |  3.562 μs |  1.863 μs | 22.48 |    0.33 |  7.8125 |       - |  134.44 KB |        4.32 |
| NativeSingle      | TaLib(...)chRsi [24] | 1000  |    21.37 μs |  0.540 μs |  0.321 μs |  1.00 |    0.02 |  1.8311 |  0.1221 |   31.16 KB |        1.00 |
| NativeParallel    | TaLib(...)chRsi [24] | 1000  |    31.58 μs |  0.517 μs |  0.308 μs |  1.48 |    0.03 |  6.1035 |  0.7324 |   94.43 KB |        3.03 |
|                   |                      |       |             |           |           |       |         |         |         |            |             |
| **BuilderFull**       | **TaLib(...)chRsi [24]** | **10000** | **5,080.51 μs** | **22.316 μs** | **14.761 μs** | **18.69** |    **0.11** | **93.7500** | **31.2500** | **1799.91 KB** |        **5.76** |
| BuilderLatestOnly | TaLib(...)chRsi [24] | 10000 | 5,011.99 μs | 21.940 μs | 13.056 μs | 18.43 |    0.11 | 62.5000 |       - | 1330.06 KB |        4.26 |
| NativeSingle      | TaLib(...)chRsi [24] | 10000 |   271.88 μs |  2.647 μs |  1.575 μs |  1.00 |    0.01 | 17.5781 |  3.9063 |  312.42 KB |        1.00 |
| NativeParallel    | TaLib(...)chRsi [24] | 10000 |   367.74 μs | 17.368 μs | 11.488 μs |  1.35 |    0.04 | 58.5938 | 27.3438 |   938.2 KB |        3.00 |
