```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|-----------:|
| **BuilderFull**       | **TaLib(...)chRsi [24]** | **1000**  |   **485.3 μs** |  **4.16 μs** |  **2.48 μs** |       **-** |       **-** |  **182.03 KB** |
| BuilderLatestOnly | TaLib(...)chRsi [24] | 1000  |   496.5 μs | 23.96 μs | 14.26 μs |  7.8125 |       - |  134.44 KB |
| **BuilderFull**       | **TaLib(...)chRsi [24]** | **10000** | **5,042.4 μs** | **20.65 μs** | **10.80 μs** | **93.7500** | **31.2500** |  **1799.9 KB** |
| BuilderLatestOnly | TaLib(...)chRsi [24] | 10000 | 5,049.6 μs | 30.52 μs | 20.19 μs | 62.5000 |       - | 1330.05 KB |
