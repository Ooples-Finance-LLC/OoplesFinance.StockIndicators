```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **1000**  |   **484.033 μs** | **110.7734 μs** |  **65.9195 μs** | **48.99** |    **6.43** |  **31.2500** |        **-** |  **645.94 KB** |       **27.22** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 1000  |   469.489 μs |  56.5539 μs |  37.4069 μs | 47.52 |    3.78 |  35.1563 |        - |  598.35 KB |       25.22 |
| NativeSingle      | TaLib(...)Stoch [21] | 1000  |     9.885 μs |   0.3763 μs |   0.2489 μs |  1.00 |    0.03 |   1.4038 |   0.0610 |   23.73 KB |        1.00 |
| NativeParallel    | TaLib(...)Stoch [21] | 1000  |    19.153 μs |   0.4715 μs |   0.2806 μs |  1.94 |    0.05 |   5.0049 |   0.4883 |   75.96 KB |        3.20 |
|                   |                      |       |              |             |             |       |         |          |          |            |             |
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **10000** | **4,655.373 μs** | **424.5318 μs** | **280.8015 μs** | **32.78** |    **1.99** | **375.0000** | **187.5000** | **6342.14 KB** |       **27.03** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 10000 | 4,689.960 μs | 421.5653 μs | 278.8393 μs | 33.02 |    1.98 | 343.7500 |  93.7500 |  5872.3 KB |       25.02 |
| NativeSingle      | TaLib(...)Stoch [21] | 10000 |   142.079 μs |   4.9149 μs |   2.9248 μs |  1.00 |    0.03 |  13.6719 |   2.9297 |  234.67 KB |        1.00 |
| NativeParallel    | TaLib(...)Stoch [21] | 10000 |   209.608 μs |  23.2170 μs |  15.3566 μs |  1.48 |    0.11 |  46.8750 |  15.6250 |  743.95 KB |        3.17 |
