```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)tochF [22]** | **1000**  |   **476.517 μs** |  **87.9212 μs** |  **58.1544 μs** | **59.16** |    **6.97** |  **15.6250** |       **-** |  **392.18 KB** |       **16.55** |
| BuilderLatestOnly | TaLib(...)tochF [22] | 1000  |   362.563 μs |  36.7327 μs |  24.2964 μs | 45.02 |    2.99 |  19.5313 |       - |  344.56 KB |       14.54 |
| NativeSingle      | TaLib(...)tochF [22] | 1000  |     8.057 μs |   0.2310 μs |   0.1528 μs |  1.00 |    0.03 |   1.4038 |  0.0610 |    23.7 KB |        1.00 |
| NativeParallel    | TaLib(...)tochF [22] | 1000  |    17.355 μs |   0.6835 μs |   0.4521 μs |  2.15 |    0.07 |   5.0049 |  0.6104 |   75.77 KB |        3.20 |
|                   |                      |       |              |             |             |       |         |          |         |            |             |
| **BuilderFull**       | **TaLib(...)tochF [22]** | **10000** | **3,435.107 μs** | **381.1344 μs** | **226.8070 μs** | **26.05** |    **1.88** | **218.7500** | **93.7500** | **3838.21 KB** |       **16.36** |
| BuilderLatestOnly | TaLib(...)tochF [22] | 10000 | 3,308.284 μs | 165.3789 μs |  86.4964 μs | 25.09 |    1.09 | 187.5000 | 62.5000 | 3368.38 KB |       14.36 |
| NativeSingle      | TaLib(...)tochF [22] | 10000 |   132.042 μs |   7.3436 μs |   4.8573 μs |  1.00 |    0.05 |  13.6719 |  2.9297 |  234.64 KB |        1.00 |
| NativeParallel    | TaLib(...)tochF [22] | 10000 |   186.813 μs |  11.9553 μs |   7.9077 μs |  1.42 |    0.08 |  46.8750 | 16.6016 |  743.75 KB |        3.17 |
