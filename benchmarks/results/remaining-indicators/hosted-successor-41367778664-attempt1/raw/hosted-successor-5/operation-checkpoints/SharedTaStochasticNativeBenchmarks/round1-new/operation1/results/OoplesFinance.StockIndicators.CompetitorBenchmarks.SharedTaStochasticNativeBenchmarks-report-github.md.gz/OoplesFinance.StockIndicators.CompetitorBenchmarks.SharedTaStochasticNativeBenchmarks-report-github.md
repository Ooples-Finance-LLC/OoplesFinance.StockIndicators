```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0     | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|---------:|--------:|-----------:|
| **BuilderFull**       | **TaLib(...)tochF [22]** | **1000**  |   **521.9 μs** | **112.01 μs** |  **74.09 μs** |  **15.6250** |       **-** |  **392.18 KB** |
| BuilderLatestOnly | TaLib(...)tochF [22] | 1000  |   353.5 μs |  41.64 μs |  24.78 μs |  19.5313 |       - |  344.56 KB |
| **BuilderFull**       | **TaLib(...)tochF [22]** | **10000** | **3,521.1 μs** | **338.76 μs** | **224.07 μs** | **218.7500** | **93.7500** | **3838.23 KB** |
| BuilderLatestOnly | TaLib(...)tochF [22] | 10000 | 3,466.0 μs | 415.03 μs | 274.52 μs | 187.5000 | 62.5000 | 3368.36 KB |
