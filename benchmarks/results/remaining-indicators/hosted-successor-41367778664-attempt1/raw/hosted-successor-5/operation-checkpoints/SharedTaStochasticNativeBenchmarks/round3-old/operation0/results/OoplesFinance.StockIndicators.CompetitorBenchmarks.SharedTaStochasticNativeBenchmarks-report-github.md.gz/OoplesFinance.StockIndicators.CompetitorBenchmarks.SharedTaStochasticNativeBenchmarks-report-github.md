```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **1000**  |   **551.8 μs** | **143.35 μs** |  **94.82 μs** |  **31.2500** |        **-** |  **645.94 KB** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 1000  |   446.0 μs |  17.66 μs |   9.24 μs |  35.1563 |        - |  598.35 KB |
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **10000** | **4,547.8 μs** | **197.88 μs** | **117.76 μs** | **375.0000** | **156.2500** | **6342.14 KB** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 10000 | 4,561.2 μs | 348.33 μs | 230.40 μs | 343.7500 |  93.7500 |  5872.3 KB |
