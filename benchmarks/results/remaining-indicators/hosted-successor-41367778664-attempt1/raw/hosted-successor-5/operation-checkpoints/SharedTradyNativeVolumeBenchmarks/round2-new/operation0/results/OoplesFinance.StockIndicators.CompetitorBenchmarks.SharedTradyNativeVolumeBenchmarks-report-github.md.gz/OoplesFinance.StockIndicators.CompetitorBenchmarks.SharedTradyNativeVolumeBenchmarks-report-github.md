```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|----------:|----------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Accum(...)nLine [28]** | **1000**  |   **159.0 μs** |   **1.40 μs** |   **0.83 μs** |  **0.30** |    **0.00** |    **7.8125** |         **-** |        **-** |  **153.97 KB** |        **0.26** |
| BuilderLatestOnly | Accum(...)nLine [28] | 1000  |   160.3 μs |   3.63 μs |   2.16 μs |  0.30 |    0.00 |    5.8594 |         - |        - |  106.36 KB |        0.18 |
| NativeSingle      | Accum(...)nLine [28] | 1000  |   531.0 μs |   5.57 μs |   3.32 μs |  1.00 |    0.01 |   35.1563 |   11.7188 |        - |  594.33 KB |        1.00 |
| NativeParallel    | Accum(...)nLine [28] | 1000  |   457.0 μs |   7.12 μs |   3.72 μs |  0.86 |    0.01 |   54.6875 |   15.6250 |        - |  894.29 KB |        1.50 |
|                   |                      |       |            |           |           |       |         |           |           |          |            |             |
| **BuilderFull**       | **Accum(...)nLine [28]** | **10000** | **1,840.3 μs** |  **19.74 μs** |  **11.75 μs** |  **0.32** |    **0.01** |  **109.3750** |   **46.8750** |        **-** | **1931.53 KB** |        **0.33** |
| BuilderLatestOnly | Accum(...)nLine [28] | 10000 | 1,961.1 μs |  17.71 μs |  10.54 μs |  0.34 |    0.01 |   78.1250 |   15.6250 |        - | 1461.65 KB |        0.25 |
| NativeSingle      | Accum(...)nLine [28] | 10000 | 5,804.1 μs | 145.98 μs |  96.55 μs |  1.00 |    0.02 |  656.2500 |  437.5000 | 437.5000 | 5824.12 KB |        1.00 |
| NativeParallel    | Accum(...)nLine [28] | 10000 | 5,867.8 μs | 485.53 μs | 321.15 μs |  1.01 |    0.06 | 1250.0000 | 1062.5000 | 968.7500 | 8717.89 KB |        1.50 |
