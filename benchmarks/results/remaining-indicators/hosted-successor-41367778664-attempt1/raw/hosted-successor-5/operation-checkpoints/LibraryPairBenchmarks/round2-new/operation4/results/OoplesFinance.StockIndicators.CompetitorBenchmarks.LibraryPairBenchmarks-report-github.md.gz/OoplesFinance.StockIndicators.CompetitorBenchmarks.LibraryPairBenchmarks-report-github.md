```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId              | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adx** | **3,434.0 μs** | **91.25 μs** | **54.30 μs** |  **1.00** |    **0.02** | **106.36 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adx |   254.0 μs | 14.76 μs |  9.77 μs |  0.07 |    0.00 |  40.27 KB |        0.38 |
|            |       |                     |            |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adx** | **6,875.0 μs** | **60.23 μs** | **39.84 μs** |  **1.00** |    **0.01** | **1046.3 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adx |   326.0 μs | 14.23 μs |  8.47 μs |  0.05 |    0.00 | 330.59 KB |        0.32 |
