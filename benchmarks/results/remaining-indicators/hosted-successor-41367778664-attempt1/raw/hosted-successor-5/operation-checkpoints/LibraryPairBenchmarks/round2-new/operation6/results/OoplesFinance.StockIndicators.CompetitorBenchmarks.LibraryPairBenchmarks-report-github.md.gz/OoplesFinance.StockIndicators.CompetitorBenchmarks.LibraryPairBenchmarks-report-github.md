```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId              | Mean        | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |------------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Apo** |  **1,769.3 μs** |    **30.65 μs** |  **16.03 μs** |  **1.00** |    **0.01** |   **373.2 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Apo |    141.4 μs |     7.08 μs |   4.21 μs |  0.08 |    0.00 |   48.84 KB |        0.13 |
|            |       |                     |             |             |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Apo** | **16,220.6 μs** | **1,386.53 μs** | **917.11 μs** |  **1.00** |    **0.08** | **3553.78 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Apo |    228.6 μs |    16.17 μs |   8.46 μs |  0.01 |    0.00 |  409.19 KB |        0.12 |
