```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean     | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |---------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Adxr** | **3.182 ms** | **0.0393 ms** | **0.0234 ms** |  **1.00** |  **107.43 KB** |        **1.00** |
|        |       |                      |          |           |           |       |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Adxr** | **7.347 ms** | **0.0321 ms** | **0.0212 ms** |  **1.00** | **1046.34 KB** |        **1.00** |
