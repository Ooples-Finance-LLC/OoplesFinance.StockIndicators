```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId             | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |------------------- |-----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Ad** |   **815.6 μs** | **35.70 μs** | **21.25 μs** |  **1.00** |    **0.03** | **160.84 KB** |        **1.00** |
|        |       |                    |            |          |          |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Ad** | **7,412.4 μs** | **39.26 μs** | **23.36 μs** |  **1.00** |    **0.00** | **2015.6 KB** |        **1.00** |
