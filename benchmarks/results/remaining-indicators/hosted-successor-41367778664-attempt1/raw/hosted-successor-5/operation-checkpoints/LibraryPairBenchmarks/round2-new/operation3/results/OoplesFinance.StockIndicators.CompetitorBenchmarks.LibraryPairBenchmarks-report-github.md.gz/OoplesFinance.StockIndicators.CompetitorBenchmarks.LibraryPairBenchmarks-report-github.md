```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)AdOsc [21]** | **5,849.1 μs** |    **97.60 μs** |    **64.56 μs** |  **1.00** |    **0.01** |  **209.12 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)AdOsc [21] |   141.0 μs |     9.30 μs |     4.86 μs |  0.02 |    0.00 |   41.18 KB |        0.20 |
|            |       |                      |            |             |             |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)AdOsc [21]** | **7,277.9 μs** | **2,347.12 μs** | **1,396.73 μs** |  **1.03** |    **0.25** | **2054.52 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)AdOsc [21] |   153.8 μs |    49.83 μs |    32.96 μs |  0.02 |    0.01 |  331.19 KB |        0.16 |
