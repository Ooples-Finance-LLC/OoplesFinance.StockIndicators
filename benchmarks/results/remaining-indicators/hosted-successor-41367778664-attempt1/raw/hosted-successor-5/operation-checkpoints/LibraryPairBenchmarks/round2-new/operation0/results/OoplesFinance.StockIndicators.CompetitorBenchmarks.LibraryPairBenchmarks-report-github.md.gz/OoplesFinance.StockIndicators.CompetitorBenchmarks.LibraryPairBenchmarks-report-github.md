```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId            | Mean      | Error      | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------ |----------:|-----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetZigZag** |  **1.135 ms** |  **0.0575 ms** | **0.0342 ms** |  **1.00** |    **0.04** |  **479.98 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetZigZag |  1.840 ms |  0.0422 ms | 0.0251 ms |  1.62 |    0.05 |  430.48 KB |        0.90 |
|            |       |                   |           |            |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetZigZag** |  **7.855 ms** |  **0.0769 ms** | **0.0402 ms** |  **1.00** |    **0.01** | **4851.34 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetZigZag | 11.798 ms | 10.7925 ms | 7.1386 ms |  1.50 |    0.87 | 4090.77 KB |        0.84 |
