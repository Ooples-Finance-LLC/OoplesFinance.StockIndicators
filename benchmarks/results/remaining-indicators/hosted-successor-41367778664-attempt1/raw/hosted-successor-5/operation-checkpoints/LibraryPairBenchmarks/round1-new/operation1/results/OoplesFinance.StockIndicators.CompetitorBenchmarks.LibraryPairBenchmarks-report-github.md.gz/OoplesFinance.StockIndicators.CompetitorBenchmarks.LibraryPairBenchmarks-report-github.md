```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean      | Error      | StdDev     | Ratio | RatioSD | Gen0      | Gen1      | Allocated | Alloc Ratio |
|------- |------ |--------------------- |----------:|-----------:|-----------:|------:|--------:|----------:|----------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)bands [24]** |  **7.819 ms** |  **0.2148 ms** |  **0.1278 ms** |  **1.00** |    **0.02** |         **-** |         **-** |   **3.23 MB** |        **1.00** |
|        |       |                      |           |            |            |       |         |           |           |           |             |
| **Ooples** | **10000** | **TaLib(...)bands [24]** | **69.579 ms** | **18.8140 ms** | **12.4443 ms** |  **1.03** |    **0.24** | **2000.0000** | **1000.0000** |  **32.43 MB** |        **1.00** |
