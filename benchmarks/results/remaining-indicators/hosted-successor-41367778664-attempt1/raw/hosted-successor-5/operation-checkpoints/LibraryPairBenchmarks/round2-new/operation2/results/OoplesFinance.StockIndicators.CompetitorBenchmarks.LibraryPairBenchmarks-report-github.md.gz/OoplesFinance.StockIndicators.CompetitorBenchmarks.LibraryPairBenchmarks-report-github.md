```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId             | Mean        | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |------------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ad** |   **725.56 μs** |  **12.109 μs** |   **7.206 μs** |  **1.00** |    **0.01** |  **160.84 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ad |    47.88 μs |   3.396 μs |   2.021 μs |  0.07 |    0.00 |   15.65 KB |        0.10 |
|            |       |                    |             |            |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ad** | **7,725.89 μs** | **576.046 μs** | **381.019 μs** |  **1.00** |    **0.07** | **2015.88 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ad |    97.63 μs |  28.401 μs |  18.785 μs |  0.01 |    0.00 |   86.29 KB |        0.04 |
