```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|---------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adxr** | **3,090.8 μs** |  **41.08 μs** | **24.45 μs** |  **1.00** |  **107.43 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adxr |   274.7 μs |  25.21 μs | 16.67 μs |  0.09 |   48.45 KB |        0.45 |
|            |       |                      |            |           |          |       |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adxr** | **7,150.5 μs** |  **92.15 μs** | **60.95 μs** |  **1.00** | **1047.66 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adxr |   377.0 μs | 151.28 μs | 79.12 μs |  0.05 |   408.8 KB |        0.39 |
