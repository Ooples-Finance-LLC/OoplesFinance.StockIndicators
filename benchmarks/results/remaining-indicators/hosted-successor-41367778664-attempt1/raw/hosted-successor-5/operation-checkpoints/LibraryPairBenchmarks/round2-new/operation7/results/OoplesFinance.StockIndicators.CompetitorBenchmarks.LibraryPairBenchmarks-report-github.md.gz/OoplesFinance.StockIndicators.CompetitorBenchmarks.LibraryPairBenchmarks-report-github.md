```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error      | StdDev     | Median      | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-----------:|-----------:|------------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)vgDev [22]** | **1,484.25 μs** |  **16.810 μs** |   **8.792 μs** | **1,480.80 μs** |  **1.00** |    **0.01** |  **73.16 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)vgDev [22] |    52.42 μs |   1.878 μs |   0.982 μs |    52.05 μs |  0.04 |    0.00 |  23.52 KB |        0.32 |
|            |       |                      |             |            |            |             |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)vgDev [22]** | **1,450.30 μs** | **926.002 μs** | **551.049 μs** | **1,104.30 μs** |  **1.11** |    **0.53** | **643.49 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)vgDev [22] |   320.48 μs |   7.828 μs |   4.658 μs |   318.10 μs |  0.25 |    0.07 | 164.14 KB |        0.26 |
