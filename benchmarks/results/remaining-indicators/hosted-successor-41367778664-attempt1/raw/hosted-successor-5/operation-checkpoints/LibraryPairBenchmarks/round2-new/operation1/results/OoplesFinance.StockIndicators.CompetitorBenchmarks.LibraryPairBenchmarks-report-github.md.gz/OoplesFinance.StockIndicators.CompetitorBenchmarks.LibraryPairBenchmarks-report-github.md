```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)bands [24]** |  **7,699.2 μs** |   **105.89 μs** |    **63.01 μs** |  **1.00** |    **0.01** |         **-** |         **-** |  **3309.52 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)bands [24] |    300.7 μs |    27.18 μs |    16.18 μs |  0.04 |    0.00 |         - |         - |   121.84 KB |        0.04 |
|            |       |                      |             |             |             |       |         |           |           |             |             |
| **Ooples**     | **10000** | **TaLib(...)bands [24]** | **17,771.6 μs** | **5,072.86 μs** | **3,355.39 μs** |  **1.03** |    **0.27** | **2000.0000** | **1000.0000** | **33205.35 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)bands [24] |    346.1 μs |    54.35 μs |    32.34 μs |  0.02 |    0.00 |         - |         - |  1132.91 KB |        0.03 |
