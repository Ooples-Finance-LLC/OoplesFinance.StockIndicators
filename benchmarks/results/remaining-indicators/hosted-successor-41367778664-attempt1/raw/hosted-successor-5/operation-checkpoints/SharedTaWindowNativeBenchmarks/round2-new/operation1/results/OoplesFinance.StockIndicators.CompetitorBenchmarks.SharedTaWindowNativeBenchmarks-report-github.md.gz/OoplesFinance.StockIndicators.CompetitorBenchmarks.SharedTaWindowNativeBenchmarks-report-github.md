```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **1000**  |   **154.89 μs** |  **32.962 μs** | **19.615 μs** |  **5.48** |    **0.66** |       **-** |       **-** |  **73.14 KB** |        **9.23** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 1000  |   138.45 μs |  17.588 μs | 11.633 μs |  4.90 |    0.39 |  0.9766 |       - |  25.22 KB |        3.18 |
| NativeSingle      | TaLib(...)vgDev [22] | 1000  |    28.26 μs |   0.189 μs |  0.099 μs |  1.00 |    0.00 |  0.2441 |       - |   7.92 KB |        1.00 |
| NativeParallel    | TaLib(...)vgDev [22] | 1000  |    17.58 μs |   1.552 μs |  1.027 μs |  0.62 |    0.03 |  1.0986 |       - |  16.76 KB |        2.11 |
|                   |                      |       |             |            |           |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **10000** | **1,099.95 μs** | **142.646 μs** | **94.351 μs** |  **3.83** |    **0.31** | **31.2500** | **15.6250** |  **565.7 KB** |        **7.23** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 10000 | 1,056.79 μs | 108.241 μs | 71.595 μs |  3.68 |    0.24 |       - |       - |  95.59 KB |        1.22 |
| NativeSingle      | TaLib(...)vgDev [22] | 10000 |   287.10 μs |   1.652 μs |  0.983 μs |  1.00 |    0.00 |  3.9063 |       - |  78.25 KB |        1.00 |
| NativeParallel    | TaLib(...)vgDev [22] | 10000 |   182.55 μs |   7.927 μs |  5.243 μs |  0.64 |    0.02 | 10.7422 |  1.9531 | 157.39 KB |        2.01 |
