```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **1000**  |   **159.5 μs** | **54.70 μs** | **36.18 μs** |       **-** |       **-** |  **73.24 KB** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 1000  |   139.7 μs | 10.21 μs |  6.75 μs |  0.9766 |       - |  25.22 KB |
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **10000** | **1,070.9 μs** | **82.98 μs** | **54.89 μs** | **31.2500** | **15.6250** | **565.69 KB** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 10000 |   983.2 μs | 17.97 μs |  9.40 μs |       - |       - |  95.59 KB |
