```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **1000**  |   **153.2 μs** |  **25.98 μs** | **17.19 μs** |       **-** |       **-** |  **73.14 KB** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 1000  |   142.8 μs |   6.41 μs |  4.24 μs |  0.9766 |       - |  25.22 KB |
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **10000** | **1,038.9 μs** |  **86.00 μs** | **56.88 μs** | **31.2500** | **15.6250** |  **565.7 KB** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 10000 | 1,019.5 μs | 128.63 μs | 85.08 μs |       - |       - |  95.59 KB |
