```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **1000**  |   **149.8 μs** |  **33.73 μs** |  **22.31 μs** |       **-** |       **-** |  **73.14 KB** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 1000  |   143.7 μs |   5.87 μs |   3.88 μs |  0.9766 |       - |  25.22 KB |
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **10000** | **1,052.0 μs** | **111.02 μs** |  **73.43 μs** | **31.2500** | **15.6250** | **565.69 KB** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 10000 | 1,055.9 μs | 183.50 μs | 121.38 μs |       - |       - |  95.59 KB |
