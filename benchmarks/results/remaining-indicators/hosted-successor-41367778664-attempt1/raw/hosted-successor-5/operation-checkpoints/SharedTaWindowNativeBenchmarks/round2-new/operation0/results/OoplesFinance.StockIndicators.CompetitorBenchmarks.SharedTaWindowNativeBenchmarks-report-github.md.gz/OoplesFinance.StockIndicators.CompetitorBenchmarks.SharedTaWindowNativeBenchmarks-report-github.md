```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean          | Error       | StdDev      | Ratio  | RatioSD | Gen0      | Gen1     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |--------------:|------------:|------------:|-------:|--------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **TaLib(...)bands [24]** | **1000**  |  **2,235.202 μs** | **119.8478 μs** |  **71.3195 μs** | **236.55** |   **11.45** |  **142.8571** |        **-** |   **3187.7 KB** |       **81.56** |
| BuilderLatestOnly | TaLib(...)bands [24] | 1000  |  2,115.485 μs |  18.5944 μs |  12.2991 μs | 223.88 |    8.54 |  187.5000 |  31.2500 |   3140.2 KB |       80.34 |
| NativeSingle      | TaLib(...)bands [24] | 1000  |      9.462 μs |   0.5599 μs |   0.3704 μs |   1.00 |    0.05 |    2.3804 |   0.1831 |    39.09 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [24] | 1000  |     17.987 μs |   0.7127 μs |   0.4241 μs |   1.90 |    0.08 |    8.0566 |   1.2207 |   122.26 KB |        3.13 |
|                   |                      |       |               |             |             |        |         |           |          |             |             |
| **BuilderFull**       | **TaLib(...)bands [24]** | **10000** | **13,848.476 μs** | **397.2215 μs** | **262.7374 μs** | **158.17** |    **3.96** | **1857.1429** | **857.1429** |  **32093.4 KB** |       **82.15** |
| BuilderLatestOnly | TaLib(...)bands [24] | 10000 | 13,980.690 μs | 474.3394 μs | 313.7461 μs | 159.68 |    4.39 | 1875.0000 | 875.0000 | 31623.45 KB |       80.95 |
| NativeSingle      | TaLib(...)bands [24] | 10000 |     87.579 μs |   2.4281 μs |   1.6061 μs |   1.00 |    0.02 |   23.4375 |   7.8125 |   390.65 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [24] | 10000 |    168.231 μs |  10.2850 μs |   6.8029 μs |   1.92 |    0.08 |   76.1719 |  35.1563 |  1212.11 KB |        3.10 |
