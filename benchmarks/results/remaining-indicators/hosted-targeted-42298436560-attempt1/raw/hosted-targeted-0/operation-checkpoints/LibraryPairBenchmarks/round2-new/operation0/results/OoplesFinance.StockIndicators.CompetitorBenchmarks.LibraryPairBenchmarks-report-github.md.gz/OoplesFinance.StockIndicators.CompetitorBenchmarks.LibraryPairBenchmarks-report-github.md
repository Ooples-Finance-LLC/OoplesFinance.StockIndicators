```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tHold [22]** |  **91.56 μs** | **16.668 μs** | **11.025 μs** |  **1.01** |    **0.16** |  **66.36 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tHold [22] |  79.82 μs |  0.600 μs |  0.357 μs |  0.88 |    0.09 |  18.59 KB |        0.28 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)tHold [22]** | **393.07 μs** | **14.662 μs** |  **8.725 μs** |  **1.00** |    **0.03** | **638.94 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tHold [22] | 812.75 μs | 33.534 μs | 22.181 μs |  2.07 |    0.07 | 124.44 KB |        0.19 |
