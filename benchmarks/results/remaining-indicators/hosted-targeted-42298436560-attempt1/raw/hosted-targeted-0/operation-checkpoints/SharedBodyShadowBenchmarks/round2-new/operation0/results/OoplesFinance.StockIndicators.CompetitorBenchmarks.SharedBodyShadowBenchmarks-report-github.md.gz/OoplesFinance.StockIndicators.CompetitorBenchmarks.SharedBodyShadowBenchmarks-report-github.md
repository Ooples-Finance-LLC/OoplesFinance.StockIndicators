```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |---------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **BeltHold**  | **1000**  | **116.72 μs** | **15.374 μs** |  **8.041 μs** |  **2.41** |    **0.16** |       **-** |       **-** |  **58.28 KB** |       **14.81** |
| BuilderLatestOnly | BeltHold  | 1000  |  64.03 μs |  0.203 μs |  0.106 μs |  1.32 |    0.00 |  0.4883 |       - |  10.39 KB |        2.64 |
| NativeSingle      | BeltHold  | 1000  |  48.47 μs |  0.183 μs |  0.095 μs |  1.00 |    0.00 |       - |       - |   3.93 KB |        1.00 |
| NativeParallel    | BeltHold  | 1000  | 111.37 μs |  0.989 μs |  0.517 μs |  2.30 |    0.01 |       - |       - |   4.23 KB |        1.07 |
|                   |           |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **BeltHold**  | **10000** | **427.97 μs** |  **6.917 μs** |  **3.618 μs** |  **0.87** |    **0.01** | **31.2500** | **11.7188** |  **556.1 KB** |       **14.22** |
| BuilderLatestOnly | BeltHold  | 10000 | 430.06 μs |  7.702 μs |  4.028 μs |  0.87 |    0.01 |  3.9063 |       - |     86 KB |        2.20 |
| NativeSingle      | BeltHold  | 10000 | 492.28 μs |  6.572 μs |  3.911 μs |  1.00 |    0.01 |       - |       - |  39.11 KB |        1.00 |
| NativeParallel    | BeltHold  | 10000 | 349.50 μs | 25.037 μs | 16.560 μs |  0.71 |    0.03 |  1.9531 |       - |  39.39 KB |        1.01 |
