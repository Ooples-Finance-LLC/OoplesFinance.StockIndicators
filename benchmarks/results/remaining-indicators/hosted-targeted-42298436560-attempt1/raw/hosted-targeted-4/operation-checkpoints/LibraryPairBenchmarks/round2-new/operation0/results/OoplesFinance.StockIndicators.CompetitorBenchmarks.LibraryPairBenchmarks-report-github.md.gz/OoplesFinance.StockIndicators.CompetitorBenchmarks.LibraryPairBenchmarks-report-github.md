```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)hWave [22]** |  **79.53 μs** |  **7.919 μs** |  **4.713 μs** |  **1.00** |    **0.08** |  **66.36 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)hWave [22] |  74.48 μs |  0.633 μs |  0.377 μs |  0.94 |    0.05 |  18.97 KB |        0.29 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)hWave [22]** | **418.71 μs** | **16.950 μs** | **10.086 μs** |  **1.00** |    **0.03** | **638.94 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)hWave [22] | 766.09 μs | 28.605 μs | 18.921 μs |  1.83 |    0.06 | 125.05 KB |        0.20 |
