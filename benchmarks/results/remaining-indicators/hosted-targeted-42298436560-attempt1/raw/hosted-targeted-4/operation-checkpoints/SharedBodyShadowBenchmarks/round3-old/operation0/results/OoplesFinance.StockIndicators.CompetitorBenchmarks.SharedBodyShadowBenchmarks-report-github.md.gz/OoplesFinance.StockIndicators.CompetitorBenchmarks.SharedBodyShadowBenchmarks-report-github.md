```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **HighWave**  | **1000**  |  **85.74 μs** |  **1.585 μs** |  **0.829 μs** |       **-** |       **-** |  **58.24 KB** |
| BuilderLatestOnly | HighWave  | 1000  |  84.30 μs |  1.071 μs |  0.638 μs |  0.4883 |       - |  10.39 KB |
| **BuilderFull**       | **HighWave**  | **10000** | **491.17 μs** |  **5.019 μs** |  **2.625 μs** | **31.2500** | **11.7188** | **556.07 KB** |
| BuilderLatestOnly | HighWave  | 10000 | 477.42 μs | 37.170 μs | 24.586 μs |  3.9063 |       - |     86 KB |
