```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |---------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **HighWave**  | **1000**  |  **82.20 μs** |  **0.636 μs** |  **0.379 μs** |  **1.58** |    **0.02** |       **-** |       **-** |  **58.31 KB** |       **14.82** |
| BuilderLatestOnly | HighWave  | 1000  |  54.16 μs |  0.329 μs |  0.196 μs |  1.04 |    0.01 |  0.4883 |       - |  10.39 KB |        2.64 |
| NativeSingle      | HighWave  | 1000  |  52.11 μs |  0.932 μs |  0.488 μs |  1.00 |    0.01 |       - |       - |   3.93 KB |        1.00 |
| NativeParallel    | HighWave  | 1000  | 113.37 μs |  1.576 μs |  0.824 μs |  2.18 |    0.02 |       - |       - |   4.23 KB |        1.07 |
|                   |           |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **HighWave**  | **10000** | **380.73 μs** | **15.412 μs** |  **8.061 μs** |  **0.73** |    **0.02** | **31.2500** | **11.7188** |  **556.1 KB** |       **14.22** |
| BuilderLatestOnly | HighWave  | 10000 | 372.95 μs | 26.591 μs | 17.588 μs |  0.71 |    0.03 |  3.9063 |       - |  85.99 KB |        2.20 |
| NativeSingle      | HighWave  | 10000 | 521.96 μs |  5.592 μs |  3.328 μs |  1.00 |    0.01 |       - |       - |  39.12 KB |        1.00 |
| NativeParallel    | HighWave  | 10000 | 349.90 μs |  7.203 μs |  3.767 μs |  0.67 |    0.01 |       - |       - |  39.41 KB |        1.01 |
