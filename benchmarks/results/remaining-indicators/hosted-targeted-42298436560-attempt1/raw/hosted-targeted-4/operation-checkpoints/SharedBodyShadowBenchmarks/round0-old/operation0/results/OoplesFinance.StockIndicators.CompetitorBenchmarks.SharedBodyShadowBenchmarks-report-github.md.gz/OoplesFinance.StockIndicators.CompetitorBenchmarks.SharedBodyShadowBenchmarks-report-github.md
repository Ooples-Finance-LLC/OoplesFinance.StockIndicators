```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **HighWave**  | **1000**  |  **79.27 μs** |  **5.587 μs** |  **3.696 μs** |       **-** |       **-** |  **58.28 KB** |
| BuilderLatestOnly | HighWave  | 1000  |  75.03 μs |  0.219 μs |  0.131 μs |  0.4883 |       - |  10.39 KB |
| **BuilderFull**       | **HighWave**  | **10000** | **496.69 μs** | **27.456 μs** | **16.338 μs** | **31.2500** | **11.7188** |  **556.1 KB** |
| BuilderLatestOnly | HighWave  | 10000 | 461.83 μs |  9.709 μs |  5.078 μs |  3.9063 |       - |     86 KB |
