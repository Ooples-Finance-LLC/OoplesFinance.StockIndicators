```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tLine [23]** | **153.87 μs** | **10.543 μs** |  **6.274 μs** |  **1.00** |    **0.05** |  **66.36 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tLine [23] |  98.90 μs |  8.614 μs |  5.126 μs |  0.64 |    0.04 |  18.27 KB |        0.28 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)tLine [23]** | **531.86 μs** | **23.206 μs** | **13.810 μs** |  **1.00** |    **0.03** | **638.66 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tLine [23] | 902.29 μs | 22.126 μs | 14.635 μs |  1.70 |    0.05 | 123.08 KB |        0.19 |
