```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **ShortLine** | **1000**  | **182.23 μs** | **29.397 μs** | **19.444 μs** |       **-** |       **-** |  **58.32 KB** |
| BuilderLatestOnly | ShortLine | 1000  |  94.95 μs |  1.835 μs |  1.092 μs |       - |       - |   10.4 KB |
| **BuilderFull**       | **ShortLine** | **10000** | **611.78 μs** | **59.437 μs** | **39.314 μs** | **31.2500** | **11.7188** |  **556.1 KB** |
| BuilderLatestOnly | ShortLine | 10000 | 551.84 μs | 12.901 μs |  6.747 μs |  3.9063 |       - |     86 KB |
