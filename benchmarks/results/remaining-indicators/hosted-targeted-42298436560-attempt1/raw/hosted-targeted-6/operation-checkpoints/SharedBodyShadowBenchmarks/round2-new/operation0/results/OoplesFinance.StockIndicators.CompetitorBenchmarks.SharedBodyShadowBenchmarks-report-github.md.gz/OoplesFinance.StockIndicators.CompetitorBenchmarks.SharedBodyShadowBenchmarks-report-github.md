```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |---------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **ShortLine** | **1000**  |  **76.25 μs** |  **2.602 μs** |  **1.548 μs** |  **1.49** |    **0.04** |       **-** |       **-** |  **58.28 KB** |       **14.82** |
| BuilderLatestOnly | ShortLine | 1000  |  75.74 μs |  1.383 μs |  0.915 μs |  1.48 |    0.03 |  0.4883 |       - |  10.39 KB |        2.64 |
| NativeSingle      | ShortLine | 1000  |  51.26 μs |  1.437 μs |  0.950 μs |  1.00 |    0.03 |       - |       - |   3.93 KB |        1.00 |
| NativeParallel    | ShortLine | 1000  | 115.97 μs |  3.401 μs |  1.779 μs |  2.26 |    0.05 |       - |       - |   4.23 KB |        1.07 |
|                   |           |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **ShortLine** | **10000** | **542.45 μs** | **33.168 μs** | **21.938 μs** |  **0.94** |    **0.04** | **31.2500** | **11.7188** |  **556.1 KB** |       **14.22** |
| BuilderLatestOnly | ShortLine | 10000 | 531.20 μs | 51.840 μs | 34.289 μs |  0.92 |    0.06 |  3.9063 |       - |     86 KB |        2.20 |
| NativeSingle      | ShortLine | 10000 | 579.27 μs | 21.062 μs | 12.534 μs |  1.00 |    0.03 |       - |       - |  39.11 KB |        1.00 |
| NativeParallel    | ShortLine | 10000 | 367.51 μs | 25.885 μs | 17.122 μs |  0.63 |    0.03 |  1.9531 |       - |  39.39 KB |        1.01 |
