```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **ShortLine** | **1000**  | **123.44 μs** | **14.339 μs** |  **8.533 μs** |       **-** |       **-** |  **58.32 KB** |
| BuilderLatestOnly | ShortLine | 1000  |  76.01 μs |  2.229 μs |  1.327 μs |       - |       - |   10.4 KB |
| **BuilderFull**       | **ShortLine** | **10000** | **541.14 μs** | **54.905 μs** | **32.673 μs** | **31.2500** | **11.7188** |  **556.1 KB** |
| BuilderLatestOnly | ShortLine | 10000 | 463.30 μs | 15.579 μs |  8.148 μs |  3.9063 |       - |     86 KB |
