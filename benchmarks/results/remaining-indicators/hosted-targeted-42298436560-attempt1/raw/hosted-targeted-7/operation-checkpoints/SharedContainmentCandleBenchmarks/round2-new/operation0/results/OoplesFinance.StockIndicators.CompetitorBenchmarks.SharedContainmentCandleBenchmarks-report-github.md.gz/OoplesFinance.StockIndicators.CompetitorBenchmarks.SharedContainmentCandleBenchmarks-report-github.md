```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **NativeSingle**      | **TaLib.Candles.Harami** | **1000**  |  **44.09 μs** |  **0.801 μs** |  **0.477 μs** |  **1.00** |    **0.01** |       **-** |       **-** |   **3.97 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Harami | 1000  | 109.90 μs |  6.391 μs |  4.227 μs |  2.49 |    0.09 |       - |       - |   8.41 KB |        2.12 |
| BuilderFull       | TaLib.Candles.Harami | 1000  | 120.63 μs |  6.155 μs |  4.071 μs |  2.74 |    0.09 |  3.9063 |       - |   63.7 KB |       16.05 |
| BuilderLatestOnly | TaLib.Candles.Harami | 1000  | 117.87 μs |  7.623 μs |  5.042 μs |  2.67 |    0.11 |  0.9766 |       - |  15.81 KB |        3.98 |
|                   |                      |       |           |           |           |       |         |         |         |           |             |
| **NativeSingle**      | **TaLib.Candles.Harami** | **10000** | **441.01 μs** |  **1.486 μs** |  **0.777 μs** |  **1.00** |    **0.00** |       **-** |       **-** |  **39.16 KB** |        **1.00** |
| NativeParallel    | TaLib.Candles.Harami | 10000 | 333.92 μs | 28.472 μs | 18.833 μs |  0.76 |    0.04 |  5.8594 |       - |  78.73 KB |        2.01 |
| BuilderFull       | TaLib.Candles.Harami | 10000 | 398.54 μs | 32.897 μs | 21.760 μs |  0.90 |    0.05 | 33.2031 | 13.6719 | 556.24 KB |       14.21 |
| BuilderLatestOnly | TaLib.Candles.Harami | 10000 | 377.17 μs | 28.570 μs | 18.897 μs |  0.86 |    0.04 |  3.9063 |       - |  86.14 KB |        2.20 |
