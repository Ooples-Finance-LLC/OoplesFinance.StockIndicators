```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Candles.Harami** | **384.69 μs** | **39.885 μs** | **26.382 μs** |  **1.00** |    **0.09** |  **68.38 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Candles.Harami |  61.23 μs |  5.874 μs |  3.072 μs |  0.16 |    0.01 |  18.97 KB |        0.28 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Candles.Harami** | **374.76 μs** | **14.415 μs** |  **8.578 μs** |  **1.00** |    **0.03** |    **639 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Candles.Harami | 604.65 μs | 21.721 μs | 14.367 μs |  1.61 |    0.05 | 117.55 KB |        0.18 |
