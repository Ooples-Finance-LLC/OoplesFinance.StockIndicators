```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Marubozu**  | **1000**  | **103.59 μs** |  **0.474 μs** |  **0.282 μs** |       **-** |       **-** |  **58.28 KB** |
| BuilderLatestOnly | Marubozu  | 1000  |  64.07 μs |  0.190 μs |  0.113 μs |  0.4883 |       - |  10.39 KB |
| **BuilderFull**       | **Marubozu**  | **10000** | **452.34 μs** | **56.125 μs** | **37.124 μs** | **31.2500** | **11.7188** |  **556.1 KB** |
| BuilderLatestOnly | Marubozu  | 10000 | 428.15 μs |  6.271 μs |  3.280 μs |  3.9063 |       - |     86 KB |
