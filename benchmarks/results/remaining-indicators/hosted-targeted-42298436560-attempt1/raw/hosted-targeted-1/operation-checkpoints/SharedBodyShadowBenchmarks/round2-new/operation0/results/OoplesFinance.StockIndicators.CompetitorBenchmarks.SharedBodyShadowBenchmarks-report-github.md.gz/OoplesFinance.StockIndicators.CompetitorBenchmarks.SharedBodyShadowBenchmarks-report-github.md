```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error    | StdDev   | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |---------- |------ |----------:|---------:|---------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **Marubozu**  | **1000**  | **103.76 μs** | **0.711 μs** | **0.372 μs** |  **2.14** |    **0.01** |       **-** |       **-** |  **58.28 KB** |       **14.81** |
| BuilderLatestOnly | Marubozu  | 1000  |  65.81 μs | 0.626 μs | 0.328 μs |  1.36 |    0.01 |  0.4883 |       - |  10.39 KB |        2.64 |
| NativeSingle      | Marubozu  | 1000  |  48.47 μs | 0.548 μs | 0.287 μs |  1.00 |    0.01 |       - |       - |   3.93 KB |        1.00 |
| NativeParallel    | Marubozu  | 1000  | 111.50 μs | 3.834 μs | 2.282 μs |  2.30 |    0.05 |       - |       - |   4.23 KB |        1.07 |
|                   |           |       |           |          |          |       |         |         |         |           |             |
| **BuilderFull**       | **Marubozu**  | **10000** | **431.80 μs** | **7.036 μs** | **3.680 μs** |  **0.88** |    **0.01** | **31.2500** | **11.7188** |  **556.1 KB** |       **14.22** |
| BuilderLatestOnly | Marubozu  | 10000 | 424.34 μs | 9.993 μs | 5.227 μs |  0.87 |    0.01 |  3.9063 |       - |     86 KB |        2.20 |
| NativeSingle      | Marubozu  | 10000 | 488.49 μs | 2.392 μs | 1.251 μs |  1.00 |    0.00 |       - |       - |  39.11 KB |        1.00 |
| NativeParallel    | Marubozu  | 10000 | 339.02 μs | 4.735 μs | 2.477 μs |  0.69 |    0.01 |       - |       - |   39.4 KB |        1.01 |
