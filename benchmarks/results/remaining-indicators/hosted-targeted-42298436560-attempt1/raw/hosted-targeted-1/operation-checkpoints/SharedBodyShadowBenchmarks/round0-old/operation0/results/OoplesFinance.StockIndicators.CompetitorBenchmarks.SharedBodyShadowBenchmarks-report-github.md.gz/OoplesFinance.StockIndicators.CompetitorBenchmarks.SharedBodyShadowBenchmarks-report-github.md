```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Marubozu**  | **1000**  |  **90.40 μs** |  **0.845 μs** |  **0.503 μs** |       **-** |       **-** |  **58.28 KB** |
| BuilderLatestOnly | Marubozu  | 1000  |  89.86 μs |  0.580 μs |  0.345 μs |  0.4883 |       - |  10.39 KB |
| **BuilderFull**       | **Marubozu**  | **10000** | **541.12 μs** | **15.167 μs** |  **7.933 μs** | **31.2500** | **11.7188** |  **556.1 KB** |
| BuilderLatestOnly | Marubozu  | 10000 | 535.24 μs | 31.466 μs | 18.725 μs |  3.9063 |       - |     86 KB |
