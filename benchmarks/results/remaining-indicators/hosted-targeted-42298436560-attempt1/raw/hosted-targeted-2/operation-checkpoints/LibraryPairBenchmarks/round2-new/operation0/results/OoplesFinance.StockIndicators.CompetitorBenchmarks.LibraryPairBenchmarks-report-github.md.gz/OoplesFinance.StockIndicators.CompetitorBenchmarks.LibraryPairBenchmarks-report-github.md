```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)ubozu [29]** | **106.38 μs** | **13.677 μs** |  **8.139 μs** |  **1.00** |    **0.10** |  **66.36 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)ubozu [29] |  63.23 μs |  2.133 μs |  1.116 μs |  0.60 |    0.04 |  18.59 KB |        0.28 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)ubozu [29]** | **483.28 μs** | **23.261 μs** | **13.842 μs** |  **1.00** |    **0.04** | **638.61 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)ubozu [29] | 651.48 μs | 34.392 μs | 22.748 μs |  1.35 |    0.06 | 125.38 KB |        0.20 |
