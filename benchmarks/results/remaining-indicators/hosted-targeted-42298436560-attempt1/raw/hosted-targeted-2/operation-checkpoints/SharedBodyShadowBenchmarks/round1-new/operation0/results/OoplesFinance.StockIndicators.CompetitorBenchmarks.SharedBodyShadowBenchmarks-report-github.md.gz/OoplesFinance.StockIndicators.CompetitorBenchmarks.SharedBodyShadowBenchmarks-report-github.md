```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |---------------- |------ |----------:|----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **ClosingMarubozu** | **1000**  |  **71.88 μs** |  **1.380 μs** |  **0.722 μs** |       **-** |      **-** |  **58.28 KB** |
| BuilderLatestOnly | ClosingMarubozu | 1000  |  65.40 μs |  0.516 μs |  0.307 μs |       - |      - |  10.39 KB |
| **BuilderFull**       | **ClosingMarubozu** | **10000** | **445.13 μs** | **27.455 μs** | **14.359 μs** | **19.5313** | **7.8125** | **556.09 KB** |
| BuilderLatestOnly | ClosingMarubozu | 10000 | 410.76 μs | 13.452 μs |  7.036 μs |       - |      - |     86 KB |
