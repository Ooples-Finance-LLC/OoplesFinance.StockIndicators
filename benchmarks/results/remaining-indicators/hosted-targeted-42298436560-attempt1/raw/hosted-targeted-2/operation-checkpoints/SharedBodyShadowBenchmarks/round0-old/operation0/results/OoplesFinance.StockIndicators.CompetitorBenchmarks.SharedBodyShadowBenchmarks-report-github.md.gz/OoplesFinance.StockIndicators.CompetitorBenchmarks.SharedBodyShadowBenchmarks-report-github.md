```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error      | StdDev    | Gen0    | Gen1   | Allocated |
|------------------ |---------------- |------ |----------:|-----------:|----------:|--------:|-------:|----------:|
| **BuilderFull**       | **ClosingMarubozu** | **1000**  |  **86.12 μs** |   **1.641 μs** |  **0.858 μs** |       **-** |      **-** |  **58.28 KB** |
| BuilderLatestOnly | ClosingMarubozu | 1000  |  80.91 μs |   0.937 μs |  0.558 μs |       - |      - |   10.4 KB |
| **BuilderFull**       | **ClosingMarubozu** | **10000** | **560.60 μs** | **101.647 μs** | **67.233 μs** | **19.5313** | **7.8125** | **556.09 KB** |
| BuilderLatestOnly | ClosingMarubozu | 10000 | 482.42 μs |   9.472 μs |  4.954 μs |       - |      - |     86 KB |
