```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------------- |------ |----------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **ClosingMarubozu** | **1000**  |  **70.83 μs** |  **1.456 μs** |  **0.866 μs** |  **1.49** |    **0.02** |       **-** |      **-** |  **58.28 KB** |       **14.82** |
| BuilderLatestOnly | ClosingMarubozu | 1000  |  64.07 μs |  0.467 μs |  0.244 μs |  1.35 |    0.01 |       - |      - |  10.39 KB |        2.64 |
| NativeSingle      | ClosingMarubozu | 1000  |  47.44 μs |  0.307 μs |  0.161 μs |  1.00 |    0.00 |       - |      - |   3.93 KB |        1.00 |
| NativeParallel    | ClosingMarubozu | 1000  | 107.55 μs |  7.805 μs |  5.162 μs |  2.27 |    0.10 |       - |      - |   4.23 KB |        1.08 |
|                   |                 |       |           |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **ClosingMarubozu** | **10000** | **446.55 μs** | **18.146 μs** |  **9.490 μs** |  **0.85** |    **0.02** | **19.5313** | **7.8125** | **556.09 KB** |       **14.22** |
| BuilderLatestOnly | ClosingMarubozu | 10000 | 412.91 μs |  9.592 μs |  5.017 μs |  0.79 |    0.01 |       - |      - |     86 KB |        2.20 |
| NativeSingle      | ClosingMarubozu | 10000 | 522.49 μs |  5.088 μs |  2.661 μs |  1.00 |    0.01 |       - |      - |  39.12 KB |        1.00 |
| NativeParallel    | ClosingMarubozu | 10000 | 345.04 μs | 40.827 μs | 27.004 μs |  0.66 |    0.05 |       - |      - |  39.39 KB |        1.01 |
