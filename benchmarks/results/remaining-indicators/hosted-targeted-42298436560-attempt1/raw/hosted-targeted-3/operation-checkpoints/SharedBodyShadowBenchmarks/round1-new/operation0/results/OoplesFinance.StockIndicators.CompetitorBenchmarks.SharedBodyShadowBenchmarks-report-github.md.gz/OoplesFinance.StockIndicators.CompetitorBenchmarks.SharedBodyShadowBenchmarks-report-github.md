```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------------ |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **SpinningTop** | **1000**  |  **47.19 μs** |  **0.762 μs** |  **0.453 μs** |  **1.9531** |       **-** |  **58.28 KB** |
| BuilderLatestOnly | SpinningTop | 1000  |  35.62 μs |  1.761 μs |  1.165 μs |  0.4883 |       - |  10.39 KB |
| **BuilderFull**       | **SpinningTop** | **10000** | **264.55 μs** | **17.546 μs** | **11.605 μs** | **33.2031** | **15.6250** | **556.08 KB** |
| BuilderLatestOnly | SpinningTop | 10000 | 232.53 μs | 15.444 μs | 10.215 μs |  3.9063 |       - |  85.99 KB |
