```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------ |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **SpinningTop** | **1000**  |  **44.38 μs** |  **3.700 μs** |  **2.202 μs** |  **2.86** |    **0.17** |  **1.9531** |       **-** |  **58.28 KB** |       **14.83** |
| BuilderLatestOnly | SpinningTop | 1000  |  32.19 μs |  0.492 μs |  0.293 μs |  2.07 |    0.07 |  0.4883 |       - |  10.39 KB |        2.64 |
| NativeSingle      | SpinningTop | 1000  |  15.54 μs |  0.879 μs |  0.581 μs |  1.00 |    0.05 |  0.1221 |       - |   3.93 KB |        1.00 |
| NativeParallel    | SpinningTop | 1000  |  74.53 μs |  1.203 μs |  0.796 μs |  4.80 |    0.17 |       - |       - |   4.22 KB |        1.07 |
|                   |             |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **SpinningTop** | **10000** | **237.47 μs** | **20.556 μs** | **13.596 μs** |  **1.50** |    **0.10** | **33.2031** | **13.6719** | **556.08 KB** |       **14.23** |
| BuilderLatestOnly | SpinningTop | 10000 | 260.94 μs | 17.006 μs | 11.249 μs |  1.65 |    0.09 |  3.9063 |       - |  85.99 KB |        2.20 |
| NativeSingle      | SpinningTop | 10000 | 158.22 μs | 11.054 μs |  6.578 μs |  1.00 |    0.06 |  1.9531 |       - |  39.09 KB |        1.00 |
| NativeParallel    | SpinningTop | 10000 | 181.95 μs |  5.484 μs |  3.628 μs |  1.15 |    0.05 |  1.9531 |       - |  39.38 KB |        1.01 |
