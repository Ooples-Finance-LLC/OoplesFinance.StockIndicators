```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation   | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |------------ |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **SpinningTop** | **1000**  |  **46.72 μs** |  **0.854 μs** |  **0.446 μs** |  **1.9531** |       **-** |  **58.28 KB** |
| BuilderLatestOnly | SpinningTop | 1000  |  46.27 μs |  0.734 μs |  0.384 μs |  0.4883 |       - |  10.39 KB |
| **BuilderFull**       | **SpinningTop** | **10000** | **316.52 μs** | **30.206 μs** | **15.798 μs** | **33.2031** | **13.6719** | **556.08 KB** |
| BuilderLatestOnly | SpinningTop | 10000 | 301.10 μs | 17.600 μs | 10.474 μs |  3.9063 |       - |  85.99 KB |
