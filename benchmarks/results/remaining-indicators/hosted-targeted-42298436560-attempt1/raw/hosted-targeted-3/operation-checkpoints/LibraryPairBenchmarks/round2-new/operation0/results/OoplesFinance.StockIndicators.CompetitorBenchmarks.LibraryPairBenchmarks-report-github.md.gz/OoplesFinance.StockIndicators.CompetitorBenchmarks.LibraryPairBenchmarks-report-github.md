```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)ngTop [25]** | **281.01 μs** |  **5.243 μs** |  **2.742 μs** |  **1.00** |    **0.01** |   **66.4 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)ngTop [25] |  31.28 μs |  4.421 μs |  2.924 μs |  0.11 |    0.01 |  15.64 KB |        0.24 |
|            |       |                      |           |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)ngTop [25]** | **220.63 μs** | **23.854 μs** | **14.195 μs** |  **1.00** |    **0.09** | **638.94 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)ngTop [25] | 281.17 μs |  8.297 μs |  4.937 μs |  1.28 |    0.08 | 122.75 KB |        0.19 |
