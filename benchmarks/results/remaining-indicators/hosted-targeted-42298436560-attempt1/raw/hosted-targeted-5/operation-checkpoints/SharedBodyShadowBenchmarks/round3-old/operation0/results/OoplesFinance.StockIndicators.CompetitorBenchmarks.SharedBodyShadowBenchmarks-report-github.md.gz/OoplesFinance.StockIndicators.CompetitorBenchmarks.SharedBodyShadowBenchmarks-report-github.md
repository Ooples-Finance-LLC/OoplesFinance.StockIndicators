```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean     | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |---------- |------ |---------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **LongLine**  | **1000**  | **105.3 μs** |  **0.57 μs** |  **0.34 μs** |       **-** |      **-** |  **58.28 KB** |
| BuilderLatestOnly | LongLine  | 1000  | 103.5 μs |  0.46 μs |  0.24 μs |       - |      - |   10.4 KB |
| **BuilderFull**       | **LongLine**  | **10000** | **645.6 μs** | **27.62 μs** | **14.44 μs** | **31.2500** | **7.8125** | **556.13 KB** |
| BuilderLatestOnly | LongLine  | 10000 | 636.8 μs | 54.47 μs | 36.03 μs |  3.9063 |      - |     86 KB |
