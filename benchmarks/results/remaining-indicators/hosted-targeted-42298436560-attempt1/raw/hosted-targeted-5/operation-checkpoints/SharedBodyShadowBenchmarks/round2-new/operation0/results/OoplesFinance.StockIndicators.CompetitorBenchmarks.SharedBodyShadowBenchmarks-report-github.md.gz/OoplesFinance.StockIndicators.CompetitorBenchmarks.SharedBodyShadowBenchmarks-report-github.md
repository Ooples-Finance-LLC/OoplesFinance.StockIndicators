```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |---------- |------ |----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **LongLine**  | **1000**  |  **81.94 μs** |  **1.173 μs** |  **0.698 μs** |  **1.60** |    **0.02** |       **-** |       **-** |  **58.28 KB** |       **14.81** |
| BuilderLatestOnly | LongLine  | 1000  |  80.50 μs |  0.778 μs |  0.515 μs |  1.57 |    0.01 |  0.4883 |       - |  10.39 KB |        2.64 |
| NativeSingle      | LongLine  | 1000  |  51.37 μs |  0.555 μs |  0.290 μs |  1.00 |    0.01 |       - |       - |   3.93 KB |        1.00 |
| NativeParallel    | LongLine  | 1000  | 116.97 μs |  6.057 μs |  4.006 μs |  2.28 |    0.08 |       - |       - |   4.23 KB |        1.07 |
|                   |           |       |           |           |           |       |         |         |         |           |             |
| **BuilderFull**       | **LongLine**  | **10000** | **514.90 μs** |  **8.614 μs** |  **4.505 μs** |  **0.98** |    **0.01** | **31.2500** | **11.7188** |  **556.1 KB** |       **14.22** |
| BuilderLatestOnly | LongLine  | 10000 | 498.03 μs | 19.430 μs | 10.162 μs |  0.95 |    0.02 |  3.9063 |       - |     86 KB |        2.20 |
| NativeSingle      | LongLine  | 10000 | 524.34 μs |  3.638 μs |  2.165 μs |  1.00 |    0.01 |       - |       - |  39.12 KB |        1.00 |
| NativeParallel    | LongLine  | 10000 | 368.25 μs | 37.950 μs | 25.101 μs |  0.70 |    0.05 |  1.9531 |       - |  39.39 KB |        1.01 |
