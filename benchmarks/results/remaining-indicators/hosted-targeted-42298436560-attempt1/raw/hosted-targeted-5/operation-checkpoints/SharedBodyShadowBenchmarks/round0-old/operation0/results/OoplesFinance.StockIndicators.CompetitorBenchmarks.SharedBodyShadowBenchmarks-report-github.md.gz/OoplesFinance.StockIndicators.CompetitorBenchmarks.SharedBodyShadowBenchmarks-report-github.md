```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean     | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |---------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **LongLine**  | **1000**  | **148.1 μs** |  **0.68 μs** |  **0.40 μs** |       **-** |       **-** |  **58.28 KB** |
| BuilderLatestOnly | LongLine  | 1000  | 102.6 μs |  0.58 μs |  0.35 μs |       - |       - |   10.4 KB |
| **BuilderFull**       | **LongLine**  | **10000** | **703.6 μs** | **73.14 μs** | **48.38 μs** | **31.2500** | **11.7188** |  **556.1 KB** |
| BuilderLatestOnly | LongLine  | 10000 | 655.2 μs | 63.81 μs | 42.20 μs |  3.9063 |       - |     86 KB |
