```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |---------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **LongLine**  | **1000**  |  **80.08 μs** |  **0.281 μs** |  **0.167 μs** |       **-** |       **-** |  **58.28 KB** |
| BuilderLatestOnly | LongLine  | 1000  |  77.76 μs |  0.375 μs |  0.223 μs |  0.4883 |       - |  10.39 KB |
| **BuilderFull**       | **LongLine**  | **10000** | **517.21 μs** |  **6.055 μs** |  **3.167 μs** | **31.2500** | **11.7188** |  **556.1 KB** |
| BuilderLatestOnly | LongLine  | 10000 | 510.34 μs | 46.497 μs | 30.755 μs |  3.9063 |       - |     86 KB |
