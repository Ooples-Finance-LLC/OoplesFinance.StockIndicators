```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean      | Error      | StdDev     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|-----------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)gLine [22]** | **104.57 μs** |   **0.765 μs** |   **0.456 μs** |  **1.00** |    **0.01** |  **66.36 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)gLine [22] |  91.40 μs |   1.285 μs |   0.765 μs |  0.87 |    0.01 |  19.63 KB |        0.30 |
|            |       |                      |           |            |            |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)gLine [22]** | **648.90 μs** | **275.854 μs** | **182.460 μs** |  **1.07** |    **0.39** | **638.94 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)gLine [22] | 908.92 μs |  34.087 μs |  22.546 μs |  1.49 |    0.35 | 125.09 KB |        0.20 |
