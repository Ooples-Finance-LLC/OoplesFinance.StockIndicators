```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method | Bars  | PairId               | Mean     | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |---------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)gLine [22]** | **143.5 μs** |  **23.51 μs** |  **13.99 μs** |  **1.01** |    **0.13** |  **66.36 KB** |        **1.00** |
|        |       |                      |          |           |           |       |         |           |             |
| **Ooples** | **10000** | **TaLib(...)gLine [22]** | **931.1 μs** | **400.56 μs** | **264.95 μs** |  **1.08** |    **0.42** | **638.61 KB** |        **1.00** |
