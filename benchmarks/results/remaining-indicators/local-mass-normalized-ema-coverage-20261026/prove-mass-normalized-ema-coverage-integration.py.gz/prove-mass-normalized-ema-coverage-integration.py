from pathlib import Path
import gzip,hashlib,json,subprocess,importlib.util
root=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
repo=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
state=json.loads((root/'mass-normalized-ema-coverage/status.json').read_text())
control=json.loads((root/'local-mass-normalized-ema-coverage-20261026/verified-summary.json').read_text())
candidate=repo.parent/'si-mass-normalized-ema-coverage-20261026'
qualified=subprocess.check_output(['git','rev-parse','HEAD'],cwd=candidate,text=True).strip()
assert subprocess.check_output(['git','rev-parse',qualified+'^'],cwd=candidate,text=True).strip()==state['input_head']
assert control['source_sha']==state['input_head']
assert control['all_16_cases_verified'] and len(control['rows'])==16
paths=['src','tests','examples','benchmarks/OoplesFinance.StockIndicators.CompetitorTests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','scripts','.github','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json','NuGet.Config','nuget.config']
subprocess.run(['git','diff','--exit-code',qualified,'HEAD','--',*paths],cwd=repo,check=True)
for label in ['unit','parity']:
 raw=gzip.decompress((repo/f'benchmarks/results/remaining-indicators/publication-mass-normalized-ema-coverage-certified-20261026-{label}.trx.gz').read_bytes())
 assert hashlib.sha256(raw).hexdigest()==state[label]['sha256']
for path,digest in state['production_dll_sha256'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
spec=importlib.util.spec_from_file_location('gpu',repo/'scripts/verify-competitor-local-gpu.py');gpu=importlib.util.module_from_spec(spec);spec.loader.exec_module(gpu)
receipt=json.loads((gpu.EVIDENCE/'receipt.json').read_text());raw=gzip.decompress((gpu.EVIDENCE/'gpu.trx.gz').read_bytes())
gpu.verify_evidence(receipt,raw,json.loads(gpu.METHODS.read_text()),gpu.source_fingerprint(repo))
proof={'qualified_commit':subprocess.check_output(['git','rev-parse',qualified],cwd=repo,text=True).strip(),'qualified_code':state['input_head'],'matched_paths':paths,'source_fingerprint_sha256':receipt['source_sha256'],'qualification_reused':{'unit':state['unit']['passed'],'parity':state['parity']['passed'],'gpu':100,'inventory':8},'consumer_dll_hashes_rechecked':state['production_dll_sha256'],'control':'local-mass-normalized-ema-coverage-20261026','qualification_kind':'Additional compensated EMA constructor coverage and exact master dependency alignment','note':'Integrated executable sources and build inputs exactly match qualified candidate. Publishing checkout binaries remain older; preserved candidate DLL supplied the constructor measurements. No redundant production rebuild.'}
(repo/'benchmarks/results/remaining-indicators/mass-normalized-ema-coverage-integration-source-proof-20261026.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Verified exact integrated source and qualified evidence')
