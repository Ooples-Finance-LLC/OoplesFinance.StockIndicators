from pathlib import Path
import datetime, hashlib, html, json, re, subprocess

ROOT = Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
REPO = Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
RUN = 'local-mass-normalized-ema-coverage-20261026'
LIVE = Path('C:/Users/cheat/Documents/OoplesFinance-Reports/competitor-performance.html')
OUT = LIVE.parent / ('ema-constructor-refresh-' + RUN)
MARKER = '<!-- compensated-ema-constructor-results:start -->'

def embedded(document, name):
    return json.loads(re.search(r'<script[^>]*id="' + re.escape(name) + r'"[^>]*>(.*?)</script>', document, re.S)[1])

def render(document, receipt, url):
    assert MARKER not in document and document.count('<footer') == 1
    assert receipt['baseline_replacements'] == receipt['catalog_pending_slots_completed'] == 0
    rows = receipt['comparisons']; assert len(rows) == 8
    expected = {(c, b, m) for c in ['period-20-compensated', 'explicit-alpha-0.2']
                for b in [1000, 10000] for m in ['BuilderFull', 'BuilderLatestOnly']}
    assert {(r['constructor_contract'], r['bars'], r['mode']) for r in rows} == expected
    body = []
    for row in rows:
        assert row['pair'] == 'QuanTAlib.Ema' and row['indicator'] == 'MassNormalizedEma'
        cells = [row['constructor_contract'], f"{row['bars']:,}", row['mode'],
                 f"{row['ooples']['mean_ns']/1e6:.6f}",
                 f"{row['native']['NativeSingle']['mean_ns']/1e6:.6f}",
                 f"{row['native']['NativeParallel']['mean_ns']/1e6:.6f}", row['verdict']]
        body.append('<tr>' + ''.join('<td>' + html.escape(value) + '</td>' for value in cells) + '</tr>')
    section = (MARKER + '<section id="ema-constructor-results" class="section">'
               '<h2>Compensated EMA constructor comparisons</h2>'
               '<p>MassNormalizedEma compared with the matching QuanTAlib.Ema constructor. '
               'These eight builder comparisons supplement the 401-API catalog; the seeded EMA baseline '
               'and its pending counts remain separate. Times are milliseconds. Faster means the '
               'Ooples confidence interval is below both native modes.</p>'
               '<p>Measured source: <code>' + html.escape(receipt['source_sha']) + '</code>. '
               '<a href="' + html.escape(url, quote=True) + '">Raw measurements and qualification</a>.</p>'
               '<div class="panel tablewrap"><table id="ema-constructor-table"><thead><tr>'
               '<th>Constructor</th><th>Bars</th><th>Builder mode</th><th>Ooples ms</th>'
               '<th>Native single ms</th><th>Native parallel ms</th><th>Verdict</th>'
               '</tr></thead><tbody>' + ''.join(body) + '</tbody></table></div></section>'
               '<script type="application/json" id="ema-constructor-data">' +
               json.dumps({**receipt, 'measurement_url': url}, ensure_ascii=True).replace('<', '\\u003c') +
               '</script><!-- compensated-ema-constructor-results:end -->')
    candidate = document.replace('<footer', section + '<footer', 1)
    for name in ['dataset', 'archived-baseline-dataset', 'current-competitor-data', 'rollout-status-data']:
        assert embedded(candidate, name) == embedded(document, name)
    return candidate

def refresh_metadata(document, head, inventory_hash, updated):
    status = embedded(document, 'rollout-status-data')
    old_head = status['published_head']
    updates = {'published_head': head, 'inventory_commit': head,
               'inventory_sha256': inventory_hash, 'updated_utc': updated}
    status.update(updates)
    document, count = re.subn(r'(<script[^>]*id="rollout-status-data"[^>]*>).*?(</script>)',
        lambda m: m[1] + json.dumps(status, ensure_ascii=True).replace('<', '\\u003c') + m[2],
        document, flags=re.S)
    assert count == 1
    old = 'published <code>' + old_head[:8] + '</code>'
    assert old in document
    document = document.replace(old, 'published <code>' + head[:8] + '</code>')
    return document, updates

def main():
    receipt = json.loads((ROOT / RUN / 'constructor-coverage-receipt.json').read_text())
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    archive = 'benchmarks/results/remaining-indicators/' + RUN + '/constructor-coverage-receipt.json'
    archived = subprocess.check_output(['git', 'show', head + ':' + archive], cwd=REPO)
    assert json.loads(archived) == receipt
    url = 'https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/blob/' + head + '/' + archive
    original = LIVE.read_bytes(); text = render(original.decode('utf-8'), receipt, url)
    inventory_hash = hashlib.sha256((REPO / 'benchmarks/results/remaining-indicators/inventory.json').read_bytes()).hexdigest()
    text, updates = refresh_metadata(text, head, inventory_hash, datetime.datetime.now(datetime.timezone.utc).isoformat())
    candidate = text.encode('utf-8')
    OUT.mkdir(exist_ok=False)
    (OUT / 'before.html').write_bytes(original)
    (OUT / 'candidate.html').write_bytes(candidate)
    stage = {'before_sha256': hashlib.sha256(original).hexdigest(),
             'candidate_sha256': hashlib.sha256(candidate).hexdigest(),
             'source_sha': receipt['source_sha'], 'measurement_url': url,
             'published_head': head, 'rollout_metadata_updates': updates,
             'changed_baseline_rows': 0, 'changed_existing_builder_slots': 0,
             'additional_constructor_comparisons': 8, 'catalog_pending_slots_completed': 0}
    (OUT / 'staged.json').write_text(json.dumps(stage, indent=2) + '\n', encoding='utf-8', newline='\n')
    print('Staged actual constructor measurements; live report unchanged pending browser verification.')

if __name__ == '__main__': main()
