from pathlib import Path
import datetime, hashlib, json, psutil, time

ROOT = Path('C:/Users/cheat/Documents/OoplesFinance-Reports')
OUT = ROOT / 'ema-constructor-refresh-local-mass-normalized-ema-coverage-20261026'
LIVE = ROOT / 'competitor-performance.html'

def main():
    stage = json.loads((OUT / 'staged.json').read_text())
    verified = json.loads((OUT / 'browser-verification.json').read_text())
    assert verified['report_sha256'] == stage['candidate_sha256']
    assert verified['before_sha256'] == stage['before_sha256']
    assert verified['baseline_comparisons'] == verified['displayed_table_comparisons'] == verified['exported_comparisons'] == 802
    assert verified['existing_datasets_preserved'] and verified['additional_constructor_comparisons'] == 8
    assert not verified['javascript_errors']
    assert not [p.pid for p in psutil.process_iter(['cmdline'])
                if any('OoplesFinance.StockIndicators.CompetitorBenchmarks.dll' in a for a in p.info['cmdline'] or [])]
    candidate = (OUT / 'candidate.html').read_bytes()
    assert hashlib.sha256(candidate).hexdigest() == stage['candidate_sha256']
    assert hashlib.sha256(LIVE.read_bytes()).hexdigest() == stage['before_sha256']
    temporary = LIVE.with_name(LIVE.name + '.ema-' + str(time.time_ns()))
    temporary.write_bytes(candidate)
    for attempt in range(50):
        assert hashlib.sha256(LIVE.read_bytes()).hexdigest() == stage['before_sha256']
        try:
            temporary.replace(LIVE)
            break
        except PermissionError:
            if attempt == 49: raise
            time.sleep(.1)
    assert hashlib.sha256(LIVE.read_bytes()).hexdigest() == stage['candidate_sha256']
    receipt = {**stage, 'imported_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (OUT / 'imported.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8', newline='\n')
    print('Imported verified constructor results; baseline and existing builder datasets preserved.')

if __name__ == '__main__': main()
