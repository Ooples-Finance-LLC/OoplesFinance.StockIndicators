from pathlib import Path
import collections, datetime, hashlib, json, psutil, subprocess, time

ROOT = Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
REPO = Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
CANDIDATE = REPO.parent / 'si-mass-normalized-ema-coverage-20261026'
OUT = ROOT / 'ema-coverage-publication-20261026'
RUN = 'local-mass-normalized-ema-coverage-20261026'
RESULTS = 'benchmarks/results/remaining-indicators'
REPORTS = Path('C:/Users/cheat/Documents/OoplesFinance-Reports')
STAGE = REPORTS / ('ema-constructor-refresh-' + RUN)
LIVE = REPORTS / 'competitor-performance.html'

def read(path):
    for attempt in range(50):
        try: return json.loads(path.read_text(encoding='utf-8'))
        except (PermissionError, FileNotFoundError, json.JSONDecodeError):
            if attempt == 49: raise
            time.sleep(.1)

def write(path, value):
    temp = path.with_name(path.name + '.tmp-' + str(time.time_ns()))
    temp.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')
    for attempt in range(50):
        try:
            temp.replace(path); return
        except PermissionError:
            if attempt == 49: raise
            time.sleep(.1)

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def capture(args, cwd=REPO): return subprocess.check_output(args, cwd=cwd, text=True).strip()

def main():
    OUT.mkdir(exist_ok=False)
    state = {'full_goal_complete': False}
    review = read(ROOT / 'mass-normalized-ema-coverage-draft-20261026/publication-review.json')
    def save(status, **extra):
        state.update(status=status, updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), **extra)
        write(OUT / 'status.json', state); print(status, state.get('step'), flush=True)
    def run(label, args, cwd=REPO):
        save('running', step=label)
        with (OUT / (label + '.log')).open('wb') as log:
            subprocess.run(args, cwd=cwd, stdout=log, stderr=subprocess.STDOUT, check=True)
    def script(label, name, *args):
        for filename, expected in review['scripts'].items():
            assert digest(ROOT / filename) == expected, filename
        run(label, ['python3.13.exe', '-X', 'utf8', str(ROOT / name), *args], ROOT)
    def commit(label, paths, message, cwd=REPO):
        run(label + '-stage', ['git', 'add', '--', *paths], cwd)
        run(label + '-check', ['git', 'diff', '--cached', '--check'], cwd)
        run(label + '-commit', ['git', 'commit', '-m', message], cwd)
    try:
        while True:
            prior = read(ROOT / 'ema-coverage-timing-followup-20261026/status.json')
            if prior['status'] == 'EMA-timings-verified-report-and-publication-pending': break
            if 'failed' in prior['status']: raise RuntimeError(('EMA timing failed', prior))
            owner = psutil.Process(review['predecessor_pid'])
            assert abs(owner.create_time() - review['predecessor_created']) < .001
            save('waiting-verified-EMA-timings', predecessor_pid=owner.pid, predecessor_status=prior['status'])
            time.sleep(15)
        while True:
            active = [p.pid for p in psutil.process_iter(['cmdline'])
                      if any('OoplesFinance.StockIndicators.CompetitorBenchmarks.dll' in a for a in p.info['cmdline'] or [])]
            if not active: break
            save('waiting-measurements', measurement_pids=active); time.sleep(5)
        qualification = read(ROOT / 'mass-normalized-ema-coverage/status.json')
        summary = read(ROOT / RUN / 'verified-summary.json')
        code = qualification['input_head']
        assert qualification['status'] == 'checks-passed-review-and-publication-pending'
        assert qualification['unit']['passed'] == 6 and qualification['gpu_passed'] == 100
        assert qualification['parity']['class_counts']['MassNormalizedEmaBenchmarkTests'] == 4
        assert summary['all_16_cases_verified'] and summary['source_sha'] == code
        assert capture(['git', 'rev-parse', 'HEAD'], CANDIDATE) == code
        baseline = capture(['git', 'rev-parse', code + '^'])
        assert capture(['git', 'rev-parse', 'HEAD']) == baseline
        assert not capture(['git', 'status', '--porcelain'])
        pull = json.loads(capture(['gh', 'api', 'repos/Ooples-Finance-LLC/OoplesFinance.StockIndicators/pulls/266']))
        assert pull['head']['sha'] == baseline and pull['base']['ref'] == 'master'
        script('constructor-receipt', 'build-ema-constructor-receipt.py')
        script('archive-qualification', 'archive-mass-normalized-ema-coverage-qualification.py')
        stem = RESULTS + '/publication-mass-normalized-ema-coverage-certified-20261026'
        paths = [stem + suffix for suffix in ['-unit.trx.gz', '-parity.trx.gz', '-verification.json']]
        paths += [RESULTS + '/inventory.json', 'benchmarks/results/shared-rollout/local-gpu-contracts/gpu.trx.gz',
                  'benchmarks/results/shared-rollout/local-gpu-contracts/receipt.json']
        dirty = subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'],
                                        cwd=CANDIDATE, text=True).splitlines()
        assert {line[3:] for line in dirty} <= set(paths), dirty
        commit('qualification', paths, 'test: qualify compensated ema constructors', CANDIDATE)
        qualified = capture(['git', 'rev-parse', 'HEAD'], CANDIDATE)
        assert capture(['git', 'rev-parse', qualified + '^']) == code
        script('archive-measurements', 'archive-ema-coverage-evidence.py', 'measurements')
        assert capture(['git', 'status', '--porcelain']) == '?? ' + RESULTS + '/' + RUN + '/'
        run('integrate', ['git', 'cherry-pick', code, qualified])
        script('source-proof', 'prove-mass-normalized-ema-coverage-integration.py')
        proof = RESULTS + '/mass-normalized-ema-coverage-integration-source-proof-20261026.json'
        assert (REPO / proof).is_file()
        run('publish-qualified-source', ['git', 'push', 'origin', qualified + ':refs/heads/perf/qualified-mass-normalized-ema-coverage-20261026'])
        assert capture(['gh', 'api', 'repos/Ooples-Finance-LLC/OoplesFinance.StockIndicators/commits/' + qualified, '--jq', '.sha']) == qualified
        decision_path = REPO / RESULTS / RUN / 'decision.json'
        decision = read(decision_path)
        decision.update(production_integrated=True, integration_source_proof=proof, qualified_source_commit=qualified)
        write(decision_path, decision)
        commit('measurements', [RESULTS + '/' + RUN, proof], 'test: archive compensated ema competitor measurements')
        script('stage-report', 'stage-ema-constructor-report.py')
        script('verify-report', 'verify-ema-constructor-report.py')
        script('import-report', 'import-ema-constructor-report.py')
        script('archive-report', 'archive-ema-coverage-evidence.py', 'report')
        commit('report', [RESULTS + '/' + RUN], 'docs: publish compensated ema constructor measurements')
        assert not capture(['git', 'status', '--porcelain'])
        run('push', ['git', 'push', 'origin', 'HEAD:perf/remaining-indicator-rollout'])
        published = capture(['git', 'rev-parse', 'HEAD'])
        pull = json.loads(capture(['gh', 'api', 'repos/Ooples-Finance-LLC/OoplesFinance.StockIndicators/pulls/266']))
        assert pull['head']['sha'] == published and pull['base']['ref'] == 'master'
        imported = read(STAGE / 'imported.json'); assert digest(LIVE) == imported['candidate_sha256']
        verdicts = dict(collections.Counter(row['verdict'] for row in read(ROOT / RUN / 'constructor-coverage-receipt.json')['comparisons']))
        marker = '<!-- compensated-ema-qualification -->'
        assert marker not in (pull['body'] or '')
        body = (pull['body'] or '').rstrip() + '\n\n' + marker + '\n'
        body += ('Compensated EMA coverage now measures both period-20 and explicit-alpha-0.2 constructors, '
                 'at 1,000 and 10,000 bars in both builder history modes. The report includes eight additional '
                 'constructor comparisons while preserving the seeded EMA baseline and existing catalog counts.\n\n')
        body += (f'Validation: 6 focused unit cases, {qualification["parity"]["passed"]} comparison cases, '
                 '100 GPU cases, inventory checks, and 16 controlled timing cases. The two dependency versions '
                 'match the inspected master merge tree; CI gates remain subject to the new run.\n')
        body += '\n[Measurement evidence](' + imported['measurement_url'] + ').\n'
        body_file = OUT / 'pr266-body.txt'; body_file.write_text(body, encoding='utf-8', newline='\n')
        run('update-PR-description', ['gh', 'pr', 'edit', '266', '--repo', 'Ooples-Finance-LLC/OoplesFinance.StockIndicators', '--body-file', str(body_file)])
        save('EMA-coverage-published-full-goal-still-open', published_head=published,
             report_sha256=digest(LIVE), constructor_verdicts=verdicts, catalog_rows_replaced=0,
             constructor_comparisons=8, ci_status='New CI run requires inspection')
    except Exception as error:
        save('failed-needs-inspection', error=repr(error)); raise

if __name__ == '__main__': main()
