import csv,json,re,hashlib,psutil
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path('C:/Users/cheat/Documents/OoplesFinance-Reports')
out=root/'ema-constructor-refresh-local-mass-normalized-ema-coverage-20261026'
report=out/'candidate.html'
document=report.read_text(encoding='utf-8')
before=(out/'before.html').read_text(encoding='utf-8')
stage=json.loads((out/'staged.json').read_text())
assert hashlib.sha256(report.read_bytes()).hexdigest()==stage['candidate_sha256']
assert hashlib.sha256((out/'before.html').read_bytes()).hexdigest()==stage['before_sha256']
def embedded(name,text=document):
 return json.loads(re.search(r'<script[^>]*id="'+re.escape(name)+r'"[^>]*>(.*?)</script>',text,re.S)[1])
for name in ['dataset','archived-baseline-dataset','current-competitor-data']:
 assert embedded(name)==embedded(name,before)
expected_status=embedded('rollout-status-data',before)
expected_status.update(stage['rollout_metadata_updates'])
assert embedded('rollout-status-data')==expected_status
assert stage['published_head']==expected_status['published_head']
assert 'published <code>'+stage['published_head'][:8]+'</code>' in document
data=embedded('dataset');builder=embedded('current-competitor-data');constructor=embedded('ema-constructor-data')
assert len(data['rows'])==802 and len(constructor['comparisons'])==8
assert constructor['source_sha']==stage['source_sha'] and constructor['measurement_url']==stage['measurement_url']
assert stage['changed_baseline_rows']==stage['changed_existing_builder_slots']==stage['catalog_pending_slots_completed']==0
assert constructor['baseline_replacements']==constructor['catalog_pending_slots_completed']==0
stage['builder_rows']=[{**c,'measurement_url':r.get('measurement_url','https://github.com/Ooples-Finance-LLC/OoplesFinance.StockIndicators/actions/runs/'+str(r['run_id']))} for r in builder['receipts'] for c in r['comparisons']]
assert not [p.pid for p in psutil.process_iter(['cmdline']) if any('OoplesFinance.StockIndicators.CompetitorBenchmarks.dll' in a for a in p.info['cmdline'] or [])], 'Browser verification must not overlap measurements'
summary = []
for library in sorted({r['library'] for r in data['rows']}):
    for bars in [1000,10000]:
        rows = [r for r in data['rows'] if r['library'] == library and r['bars'] == bars]
        lower = sum(r['competitor_over_ooples'] > 1 for r in rows)
        higher = sum(r['competitor_over_ooples'] < 1 for r in rows)
        equal = len(rows)-lower-higher
        summary.append(dict(library=library,bars=bars,comparisons=len(rows),lower=lower,higher=higher,equal=equal))
assert sum(r['comparisons'] for r in summary) == 802
with sync_playwright() as pw:
    browser = pw.chromium.launch(channel='msedge',headless=True)
    page = browser.new_page(viewport={'width':1440,'height':1000},accept_downloads=True)
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto(report.as_uri())
    page.wait_for_selector('#rows tr')
    for bars in [1000,10000]:
        page.locator(f'[data-size="{bars}"]').click()
        wins = sum(r['lower'] for r in summary if r['bars']==bars)
        assert page.locator('#wins').inner_text() == f'{wins} / 401'
        assert page.locator('#librarycards .libcard').count() == 4
    page.locator('#size').select_option('all')
    assert page.locator('#resultcount').inner_text() == '802 size comparisons · 401 APIs'
    # Traverse the complete paginated results table, not only the export or hero cards.
    formatted = page.evaluate("rows => rows.map(r => ({pair:r.pair,bars:r.bars,values:[time(r.ooples_mean_ns),time(r.competitor_mean_ns),ratio(r.competitor_over_ooples)]}))", data['rows'])
    expected_cells = {(r['pair'],r['bars']):r['values'] for r in formatted}
    table_keys = set()
    while True:
        visible = page.locator('#rows tr').evaluate_all("rows => rows.map(r => ({pair:r.querySelector('[data-pair]').dataset.pair,bars:Number(r.cells[1].textContent.replace(/[^0-9]/g,'')),values:[r.cells[2].textContent,r.cells[3].textContent,r.cells[4].textContent]}))")
        for row in visible:
            key = (row['pair'], row['bars'])
            assert key not in table_keys, key
            assert row['values'] == expected_cells[key], (key,row['values'],expected_cells[key])
            table_keys.add(key)
        if page.locator('#next').is_disabled(): break
        page.locator('#next').click()
    assert len(table_keys) == 802
    while not page.locator('#prev').is_disabled(): page.locator('#prev').click()
    with page.expect_download() as download:
        page.locator('#export').click()
    exported=list(csv.DictReader(Path(download.value.path()).read_text(encoding='utf-8').splitlines()))
    assert len(exported)==802
    expected={(r['pair'],r['bars']):r for r in data['rows']}
    for row in exported:
        actual=expected[row['pair'],int(row['bars'])]
        for key in ['ooples_mean_ns','competitor_mean_ns','competitor_over_ooples']:
            assert float(row[key])==actual[key]
        assert row['source_sha']==actual['source_sha'] and row['measurement_run_url']==actual['measurement_run_url']
    page.locator('#rows [data-pair]').first.click()
    assert page.locator('#detail').is_visible()
    assert 'Sample 3 (ns)' in page.locator('#detailbody').inner_text()
    page.locator('#close').click()
    page.evaluate('window.scrollTo(0,0)')
    page.screenshot(path=str(out/'refreshed-baseline.png'))
    visible_html=re.sub(r'<script.*?</script>','',document,flags=re.S)
    assert f'{sum(r["lower"] for r in summary if r["bars"]==10000)} / 401 APIs at 10,000 bars' in visible_html
    assert page.locator('#builder-current-results tbody tr').count()==len(stage['builder_rows'])
    for r in stage['builder_rows']:
        row=page.locator(f'#builder-current-results tr[data-builder-pair="{r["pair"]}"][data-bars="{r["bars"]}"][data-mode="{r["mode"]}"]')
        cells=row.locator('td').all_inner_texts()
        assert cells[3:6]==[f'{r["ooples"]["mean_ns"]/1e6:.6f}',f'{r["native"]["NativeSingle"]["mean_ns"]/1e6:.6f}',f'{r["native"]["NativeParallel"]["mean_ns"]/1e6:.6f}']
        assert cells[6]=={'faster':'Faster than both','slower':'Slower than at least one','inconclusive':'Inconclusive'}[r['verdict']]
        assert row.locator('a').get_attribute('href') == r['measurement_url']
    actual_rows=page.locator('#ema-constructor-table tbody tr').all()
    assert len(actual_rows)==8
    for actual,expected in zip(actual_rows,constructor['comparisons'],strict=True):
        values=[expected['constructor_contract'],f"{expected['bars']:,}",expected['mode'],
                f"{expected['ooples']['mean_ns']/1e6:.6f}",
                f"{expected['native']['NativeSingle']['mean_ns']/1e6:.6f}",
                f"{expected['native']['NativeParallel']['mean_ns']/1e6:.6f}",expected['verdict']]
        assert actual.locator('td').all_inner_texts()==values
    section=page.locator('#ema-constructor-results')
    assert constructor['source_sha'] in section.inner_text()
    assert section.locator('a').get_attribute('href')==stage['measurement_url']
    section.scroll_into_view_if_needed();section.screenshot(path=str(out/'constructor-results.png'))
    assert not errors,errors
    browser.close()
receipt={'report_sha256':stage['candidate_sha256'],'before_sha256':stage['before_sha256'],
         'baseline_comparisons':802,'displayed_table_comparisons':len(table_keys),
         'exported_comparisons':len(exported),'existing_builder_slots':len(stage['builder_rows']),
         'additional_constructor_comparisons':8,'existing_datasets_preserved':True,'javascript_errors':errors}
(out/'browser-verification.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(receipt))
