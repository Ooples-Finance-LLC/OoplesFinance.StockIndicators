from pathlib import Path
import datetime, hashlib, json, os, psutil, subprocess, time
from benchmark_process_cleanup import capture_children, stop_owned_benchmark

ROOT = Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
REPO = Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-mass-normalized-ema-coverage-20261026')
OUT = ROOT / 'local-mass-normalized-ema-coverage-20261026'
BIN = REPO / 'benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks/bin/Release/net10.0'
DLL = BIN / 'OoplesFinance.StockIndicators.CompetitorBenchmarks.dll'
FIXTURE = 'SharedMassNormalizedEmaBenchmarks'

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def manifest():
    return {p.relative_to(BIN).as_posix(): digest(p) for p in BIN.rglob('*') if p.is_file()}

def write(path, value):
    temp = path.with_name(path.name + '.tmp-' + str(time.time_ns()))
    temp.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')
    for attempt in range(50):
        try:
            temp.replace(path)
            return
        except PermissionError:
            if attempt == 49: raise
            time.sleep(.1)

def builds():
    return [p.pid for p in psutil.process_iter(['name', 'cmdline'])
            if (p.info['name'] or '').lower() == 'dotnet.exe' and 'build' in (p.info['cmdline'] or [])]

def other_measurements():
    return [p.pid for p in psutil.process_iter(['cmdline'])
            if any('OoplesFinance.StockIndicators.CompetitorBenchmarks.dll' in a for a in p.info['cmdline'] or [])]

def main():
    qualification = json.loads((ROOT / 'mass-normalized-ema-coverage/status.json').read_text())
    assert qualification['status'] == 'checks-passed-review-and-publication-pending'
    assert qualification['unit']['passed'] == 6 and qualification['gpu_passed'] == 100
    assert qualification['parity']['class_counts']['MassNormalizedEmaBenchmarkTests'] == 4
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    assert head == qualification['input_head']
    paths = ['src', 'tests', 'benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks',
             'benchmarks/OoplesFinance.StockIndicators.CompetitorTests', 'Directory.Build.props',
             'Directory.Build.targets', 'Directory.Packages.props', 'global.json']
    assert not subprocess.check_output(['git', 'diff', 'HEAD', '--', *paths], cwd=REPO)
    original = manifest()
    assert original['OoplesFinance.StockIndicators.dll'] in qualification['production_dll_sha256'].values()
    OUT.mkdir(exist_ok=False)
    write(OUT / 'provenance.json', {'source_sha': head, 'qualification': qualification,
          'binary_manifest': original, 'fixture': FIXTURE, 'measurement_location': 'Local Windows',
          'scope': 'Constructor-specific compensated EMA coverage; never substitute for seeded EMA rows.'})
    state = {'completed_cases': 0, 'full_goal_complete': False}
    def save(status, **extra):
        state.update(status=status, updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), **extra)
        write(OUT / 'status.json', state)
    env = os.environ.copy()
    env['TEMP'] = env['TMP'] = str(ROOT / 'temp')
    for key in ['COMPARISON_PAIR', 'COMPARISON_SHARD', 'COMPARISON_SHARDS']: env.pop(key, None)
    try:
        attempt = 0
        while True:
            samples = []
            while len(samples) < 12:
                busy = builds() + other_measurements()
                cpu = psutil.cpu_percent(interval=5)
                samples = [] if busy or cpu > 15 else samples + [cpu]
                save('waiting-quiet-window', blocking_pids=busy, quiet_cpu_samples=samples)
            folder = OUT / ('attempt-' + str(attempt)); attempt += 1
            args = ['dotnet', str(DLL), '--filter', '*' + FIXTURE + '.*', '--warmupCount', '10',
                    '--iterationCount', '10', '--exporters', 'json', '--artifacts', str(folder)]
            save('measuring', attempt=attempt, artifacts=str(folder))
            owned = {}; observations = 0; interrupted = []
            with folder.with_suffix('.log').open('wb') as log:
                process = subprocess.Popen(args, cwd=BIN, env=env, stdout=log, stderr=subprocess.STDOUT)
                started = time.monotonic()
                try:
                    while True:
                        capture_children(process, owned)
                        interrupted = builds(); observations += 1
                        if interrupted:
                            stop_owned_benchmark(process, owned); break
                        code = process.poll()
                        if code is not None:
                            if code: raise subprocess.CalledProcessError(code, args)
                            break
                        if time.monotonic() - started > 3600:
                            stop_owned_benchmark(process, owned)
                            raise subprocess.TimeoutExpired(args, 3600)
                        time.sleep(1)
                except BaseException:
                    stop_owned_benchmark(process, owned)
                    raise
            if interrupted:
                write(folder.with_suffix('.invalid.json'), {'external_build_pids': interrupted,
                      'reason': 'Build observed during timing; retained attempt excluded.'})
                continue
            reports = list((folder / 'results').glob('*-report-full-compressed.json'))
            assert len(reports) == 1
            cases = json.loads(reports[0].read_bytes())['Benchmarks']
            assert len(cases) == 16 and all(c.get('Statistics') and c['Statistics']['N'] >= 7 for c in cases)
            assert manifest() == original
            save('raw-measurements-complete-independent-verification-pending', completed_cases=16,
                 report=str(reports[0]), report_sha256=digest(reports[0]), log=str(folder.with_suffix('.log')),
                 quiet_cpu_samples=samples, build_monitor_observations=observations)
            break
    except Exception as error:
        save('failed-needs-inspection', error=repr(error)); raise

if __name__ == '__main__': main()
