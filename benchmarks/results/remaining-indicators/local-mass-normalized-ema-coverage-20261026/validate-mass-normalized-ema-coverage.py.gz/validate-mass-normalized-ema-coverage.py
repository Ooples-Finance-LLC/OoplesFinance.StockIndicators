"""Recover the next bounded publication batch without accessing the repairing drive."""
import collections
import datetime
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import psutil
import shutil
import subprocess
import time
import xml.etree.ElementTree as ET

repo=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-mass-normalized-ema-coverage-20261026')
root=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
out=root/'mass-normalized-ema-coverage';out.mkdir(exist_ok=True)
temporary=root/'temp';temporary.mkdir(exist_ok=True)
os.environ['TEMP']=os.environ['TMP']=str(temporary)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
state=dict(input_head=head,source='C-drive recovery; committed source and compressed evidence retained',
    checks={},drive='C:',status='starting')
def save(status,step):
    state.update(status=status,step=step,updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    path=out/('status.tmp-'+str(time.time_ns()));path.write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8',newline='\n')
    for attempt in range(50):
        try:
            path.replace(out/'status.json');break
        except PermissionError:
            if attempt==49:raise
            time.sleep(.1)
    print(status,step,flush=True)
def capacity():
    active = [p.info['pid'] for p in psutil.process_iter(['pid', 'cmdline'])
              if any('OoplesFinance.StockIndicators.CompetitorBenchmarks.dll' in arg
                     for arg in (p.info['cmdline'] or []))]
    assert not active, ('Refusing build during active measurements', active)

def run(label,args):
    if label.startswith('build-'):capacity()
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
    save('running',label)
    with (out/(label+'.log')).open('wb') as stream:
        subprocess.run(args,cwd=repo,env=os.environ.copy(),stdout=stream,stderr=subprocess.STDOUT,check=True)
    state['checks'][label]='passed'
def verify(label,expected):
    path=out/label/(label+'.trx');raw=path.read_bytes();tree=ET.fromstring(raw)
    assert tree.find('.//{*}ResultSummary').attrib['outcome']=='Completed'
    definitions={t.attrib['id']:t.find('.//{*}TestMethod').attrib['className'].split(',')[0].rsplit('.',1)[-1]
        for t in tree.findall('.//{*}UnitTest')}
    results=tree.findall('.//{*}UnitTestResult')
    assert results and all(t.attrib['outcome']=='Passed' for t in results)
    counts=dict(collections.Counter(definitions[t.attrib['testId']] for t in results))
    assert counts.keys()==expected.keys(),(counts,expected)
    assert all(counts[k]>0 and (v is None or counts[k]==v) for k,v in expected.items()),(counts,expected)
    state[label]=dict(passed=len(results),class_counts=counts,trx=str(path),sha256=hashlib.sha256(raw).hexdigest())
def test(label,dll,classes):
    run(label,['dotnet','vstest',str(repo/dll),'/TestCaseFilter:'+'|'.join('FullyQualifiedName~.'+x+'.' for x in classes),
        '/Logger:trx;LogFileName='+label+'.trx','/ResultsDirectory:'+str(out/label)])
    verify(label,classes)
try:
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
    expected={'src/OoplesFinance.StockIndicators.csproj','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks/LibraryComparisons/SharedMassNormalizedEmaBenchmarks.cs','benchmarks/OoplesFinance.StockIndicators.CompetitorTests/MassNormalizedEmaBenchmarkTests.cs'}
    changes=set(subprocess.check_output(['git','diff','--name-only',head+'^',head,'--','src','tests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','benchmarks/OoplesFinance.StockIndicators.CompetitorTests'],cwd=repo,text=True).splitlines())
    assert changes==expected,changes
    state['reviewed_source_changes']=sorted(changes)
    state['batch_note']='Compensated/explicit-alpha EMA coverage and master dependency alignment; six existing numerical regression cases, four new constructor fixture cases, existing mass-normalized comparisons, GPU100 and inventory8. No speed claim before separate controlled measurements.'
    run('build-unit',['dotnet','build','tests/OoplesFinance.StockIndicators.Tests.Unit.csproj','-c','Release','-p:GeneratePackageOnBuild=false','-p:UseSharedCompilation=false','-m:1'])
    test('unit','tests/bin/Release/net10.0/OoplesFinance.StockIndicators.Tests.Unit.dll',{'MassNormalizedStageExecutionTests':6})
    run('build-benchmark',['dotnet','build','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','-c','Release','-p:BuildProjectReferences=false','-p:GeneratePackageOnBuild=false','-p:UseSharedCompilation=false','-m:1'])
    run('build-comparator',['dotnet','build','benchmarks/OoplesFinance.StockIndicators.CompetitorTests','-c','Release','-p:BuildProjectReferences=false','-p:GeneratePackageOnBuild=false','-p:UseSharedCompilation=false','-m:1'])
    test('parity','benchmarks/OoplesFinance.StockIndicators.CompetitorTests/bin/Release/net10.0/OoplesFinance.StockIndicators.CompetitorTests.dll',{'MassNormalizedComparisonTests':None,'MassNormalizedEmaBenchmarkTests':4})
    spec=importlib.util.spec_from_file_location('gpu',repo/'scripts/verify-competitor-local-gpu.py')
    gpu=importlib.util.module_from_spec(spec);spec.loader.exec_module(gpu)
    before=gpu.source_fingerprint(repo);methods=json.loads(gpu.METHODS.read_text())
    settings=out/'serial.runsettings'
    settings.write_text('<RunSettings><RunConfiguration><MaxCpuCount>1</MaxCpuCount></RunConfiguration><xUnit><ParallelizeTestCollections>false</ParallelizeTestCollections><MaxParallelThreads>1</MaxParallelThreads></xUnit></RunSettings>',encoding='utf-8')
    dll=repo/'benchmarks/OoplesFinance.StockIndicators.CompetitorTests/bin/Release/net10.0/OoplesFinance.StockIndicators.CompetitorTests.dll'
    run('gpu',['dotnet','vstest',str(dll),'/Settings:'+str(settings),'/TestCaseFilter:'+'|'.join('FullyQualifiedName='+m for m in methods),
        '/Logger:trx;LogFileName=gpu.trx','/ResultsDirectory:'+str(out/'gpu')])
    raw=(out/'gpu/gpu.trx').read_bytes();count=gpu.contracts.verify_trx(out/'gpu/gpu.trx',methods)
    assert count==100 and gpu.source_fingerprint(repo)==before
    receipt=dict(source_sha256=before,methods=methods,passed_cases=count,trx_sha256=hashlib.sha256(raw).hexdigest(),
        host=platform.platform(),device='Radeon RX 5500 XT; RequiredGPU fixtures',
        dotnet_info=subprocess.check_output(['dotnet','--info']).decode(),test_assembly_sha256=hashlib.sha256(dll.read_bytes()).hexdigest(),
        note='Actual RequiredGPU execution using already-built source-matched binaries; correctness, not performance qualification.')
    gpu.verify_evidence(receipt,raw,methods,before)
    (gpu.EVIDENCE/'gpu.trx.gz').write_bytes(gzip.compress(raw,mtime=0))
    (gpu.EVIDENCE/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
    state['gpu_passed']=count
    run('discover-contracts',['python3.13.exe','scripts/run-competitor-contracts.py','discover',str(dll),str(out/'all-methods.json')])
    run('gpu-source-verification',['python3.13.exe','scripts/verify-competitor-local-gpu.py','verify',str(out/'all-methods.json'),str(out/'hosted-methods.json')])
    run('inventory',['python3.13.exe','benchmarks/build_remaining_indicator_inventory.py'])
    run('inventory-check',['python3.13.exe','benchmarks/build_remaining_indicator_inventory.py','--check'])
    run('inventory-tests',['python3.13.exe','-m','unittest','discover','-s','benchmarks','-p','test_remaining_indicator_inventory.py'])
    paths=['src','tests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','benchmarks/OoplesFinance.StockIndicators.CompetitorTests']
    state['production_dll_sha256']={str(repo/p/'bin/Release/net10.0/OoplesFinance.StockIndicators.dll'):
        hashlib.sha256((repo/p/'bin/Release/net10.0/OoplesFinance.StockIndicators.dll').read_bytes()).hexdigest() for p in paths}
    assert len(set(state['production_dll_sha256'].values()))==1
    run('diff-check',['git','diff','--check'])
    save('checks-passed-review-and-publication-pending','complete')
except Exception as error:
    state['error']=repr(error);save('failed-needs-inspection',state.get('step','startup'));raise
