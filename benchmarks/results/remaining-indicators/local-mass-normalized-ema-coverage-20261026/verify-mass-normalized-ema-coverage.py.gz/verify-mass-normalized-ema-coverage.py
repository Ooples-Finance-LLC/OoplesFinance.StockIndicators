from pathlib import Path
import hashlib, json, math, re

ROOT = Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
OUT = ROOT / 'local-mass-normalized-ema-coverage-20261026'
FIXTURE = 'SharedMassNormalizedEmaBenchmarks'

def verify_report(report, log):
    cases = {}
    for case in report['Benchmarks']:
        name = case['FullName']; assert FIXTURE + '.' in name
        explicit = re.search(r'ExplicitWeight: (true|false)', name, re.I)[1].lower() == 'true'
        count = int(re.search(r'Count: (\d+)', name)[1])
        key = explicit, count, case['Method']; assert key not in cases
        stats = case['Statistics']; values = stats['OriginalValues']; ci = stats['ConfidenceInterval']
        assert len(values) == stats['N'] >= 7 and all(math.isfinite(v) and v > 0 for v in values)
        assert math.isclose(sum(values) / len(values), stats['Mean'], rel_tol=1e-12)
        assert math.isfinite(ci['Lower']) and math.isfinite(ci['Upper'])
        assert ci['Lower'] <= stats['Mean'] <= ci['Upper']
        cases[key] = {'explicit_alpha': explicit, 'bars': count, 'method': case['Method'],
                      'mean_ns': stats['Mean'], 'lower_ns': ci['Lower'], 'upper_ns': ci['Upper'],
                      'samples': stats['N'], 'allocated_bytes': case['Memory']['BytesAllocatedPerOperation']}
    assert cases.keys() == {(e, n, m) for e in [False, True] for n in [1000, 10000]
                           for m in ['BuilderFull', 'BuilderLatestOnly', 'NativeSingle', 'NativeParallel']}
    sections = re.split(r'^// Benchmark: ', log, flags=re.M)[1:]
    assert len(sections) == 16
    for section in sections:
        header = section.splitlines()[0]
        assert 'IterationCount=10' in header and 'WarmupCount=10' in header
        assert len(re.findall(r'^WorkloadWarmup\s+\d+:', section, re.M)) == 10
        assert len(re.findall(r'^WorkloadActual\s+\d+:', section, re.M)) == 10
    return list(cases.values())

def main():
    state = json.loads((OUT / 'status.json').read_text())
    assert state['status'] == 'raw-measurements-complete-independent-verification-pending'
    assert state['completed_cases'] == 16 and state['build_monitor_observations'] >= 1
    assert len(state['quiet_cpu_samples']) == 12 and max(state['quiet_cpu_samples']) <= 15
    proof = json.loads((OUT / 'provenance.json').read_text())
    q = proof['qualification']
    assert q['status'] == 'checks-passed-review-and-publication-pending'
    assert q['input_head'] == proof['source_sha'] and q['gpu_passed'] == 100
    assert q['unit']['passed'] == 6 and q['parity']['class_counts']['MassNormalizedEmaBenchmarkTests'] == 4
    folder = Path(state['artifacts']).resolve(); assert folder.is_relative_to(OUT.resolve())
    assert not folder.with_suffix('.invalid.json').exists()
    report = Path(state['report']).resolve(); assert report.is_relative_to(folder)
    raw = report.read_bytes(); assert hashlib.sha256(raw).hexdigest() == state['report_sha256']
    rows = verify_report(json.loads(raw), Path(state['log']).read_text(encoding='utf-8-sig'))
    repo = Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-mass-normalized-ema-coverage-20261026')
    binary = repo / 'benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks/bin/Release/net10.0'
    assert {p.relative_to(binary).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in binary.rglob('*') if p.is_file()} == proof['binary_manifest']
    assert proof['binary_manifest']['OoplesFinance.StockIndicators.dll'] in q['production_dll_sha256'].values()
    summary = {'all_16_cases_verified': True, 'source_sha': proof['source_sha'],
               'measurement_location': 'Local Windows', 'report_sha256': state['report_sha256'],
               'constructor_contracts': {'False': 'period20 compensated EMA', 'True': 'explicit alpha0.2 EMA'},
               'rows': rows, 'report_policy': 'Separate constructor-qualified coverage; preserve seeded EMA rows.'}
    (OUT / 'verified-summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8', newline='\n')
    print('All 16 constructor-specific EMA timing cases independently verified.')

if __name__ == '__main__': main()
