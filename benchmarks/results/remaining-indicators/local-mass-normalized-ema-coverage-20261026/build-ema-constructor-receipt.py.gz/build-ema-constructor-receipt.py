from pathlib import Path
import hashlib, json

ROOT = Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
OUT = ROOT / 'local-mass-normalized-ema-coverage-20261026'
METHODS = ['BuilderFull', 'BuilderLatestOnly', 'NativeSingle', 'NativeParallel']

def comparisons(rows):
    indexed = {(r['explicit_alpha'], r['bars'], r['method']): r for r in rows}
    expected = {(e, n, m) for e in [False, True] for n in [1000, 10000] for m in METHODS}
    assert len(rows) == 16 and indexed.keys() == expected
    def stats(row):
        return {k: row[k] for k in ['mean_ns', 'lower_ns', 'upper_ns', 'samples', 'allocated_bytes']}
    result = []
    for explicit in [False, True]:
        contract = 'explicit-alpha-0.2' if explicit else 'period-20-compensated'
        for bars in [1000, 10000]:
            native = {m: stats(indexed[explicit, bars, m]) for m in METHODS[2:]}
            for mode in METHODS[:2]:
                ours = stats(indexed[explicit, bars, mode])
                verdict = ('faster' if ours['upper_ns'] < min(n['lower_ns'] for n in native.values())
                           else 'slower' if ours['lower_ns'] > min(n['upper_ns'] for n in native.values())
                           else 'inconclusive')
                result.append({'pair': 'QuanTAlib.Ema', 'constructor_contract': contract,
                               'indicator': 'MassNormalizedEma', 'bars': bars, 'mode': mode,
                               'ooples': ours, 'native': native, 'verdict': verdict,
                               'fastest_native': min(native, key=lambda m: native[m]['mean_ns'])})
    assert len({(r['constructor_contract'], r['bars'], r['mode']) for r in result}) == 8
    return result

def main():
    summary_file = OUT / 'verified-summary.json'
    summary = json.loads(summary_file.read_text())
    assert summary['all_16_cases_verified']
    state = json.loads((OUT / 'status.json').read_text())
    report = Path(state['report']).resolve()
    assert report.is_relative_to(OUT.resolve())
    assert hashlib.sha256(report.read_bytes()).hexdigest() == summary['report_sha256']
    receipt = {'fixture': 'SharedMassNormalizedEmaBenchmarks', 'source_sha': summary['source_sha'],
               'run_id': OUT.name, 'measurement_location': 'Local Windows',
               'report_sha256': summary['report_sha256'], 'report_file': str(report.relative_to(OUT)),
               'verification_sha256': hashlib.sha256(summary_file.read_bytes()).hexdigest(),
               'scope': 'Additional constructor coverage outside the seeded 401-API baseline catalog.',
               'baseline_replacements': 0, 'catalog_pending_slots_completed': 0,
               'comparisons': comparisons(summary['rows'])}
    (OUT / 'constructor-coverage-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n',
                                                       encoding='utf-8', newline='\n')
    print('Created eight constructor-qualified comparisons; no baseline rows or catalog totals changed.')

if __name__ == '__main__': main()
