from pathlib import Path
import gzip, hashlib, json, psutil, sys

ROOT = Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
REPO = Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
RUN = 'local-mass-normalized-ema-coverage-20261026'
RAW = ROOT / RUN
OUT = REPO / 'benchmarks/results/remaining-indicators' / RUN
REPORT = Path('C:/Users/cheat/Documents/OoplesFinance-Reports') / ('ema-constructor-refresh-' + RUN)

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')

def archive(source, name):
    assert Path(name).name == name
    raw = source.read_bytes(); compressed = gzip.compress(raw, mtime=0)
    assert gzip.decompress(compressed) == raw
    target = OUT / (name + '.gz'); assert not target.exists()
    target.write_bytes(compressed)
    return {'archive': target.relative_to(REPO).as_posix(), 'sha256': hashlib.sha256(raw).hexdigest()}

def main():
    assert not [p.pid for p in psutil.process_iter(['cmdline'])
                if any('OoplesFinance.StockIndicators.CompetitorBenchmarks.dll' in a for a in p.info['cmdline'] or [])]
    assert len(sys.argv) == 2 and sys.argv[1] in ['measurements', 'report']
    if sys.argv[1] == 'measurements':
        state = read(RAW / 'status.json'); summary = read(RAW / 'verified-summary.json')
        receipt = read(RAW / 'constructor-coverage-receipt.json')
        assert state['status'] == 'raw-measurements-complete-independent-verification-pending'
        assert state['completed_cases'] == 16 and summary['all_16_cases_verified']
        assert summary['source_sha'] == receipt['source_sha']
        assert summary['report_sha256'] == receipt['report_sha256'] == state['report_sha256']
        assert len(receipt['comparisons']) == 8
        assert receipt['baseline_replacements'] == receipt['catalog_pending_slots_completed'] == 0
        report = Path(state['report']).resolve(); assert report.is_relative_to(RAW.resolve())
        assert hashlib.sha256(report.read_bytes()).hexdigest() == state['report_sha256']
        OUT.mkdir(exist_ok=False)
        records = {}
        for name in ['status.json', 'provenance.json', 'verified-summary.json']:
            records[name] = archive(RAW / name, name)
        records['benchmark-report.json'] = archive(report, 'benchmark-report.json')
        records['benchmark.log'] = archive(Path(state['log']), 'benchmark.log')
        for path in sorted(RAW.glob('attempt-*.invalid.json')):
            records[path.name] = archive(path, path.name)
            log = path.with_name(path.name.replace('.invalid.json', '.log'))
            if log.exists(): records[log.name] = archive(log, log.name)
        scripts = ['validate-mass-normalized-ema-coverage.py', 'measure-mass-normalized-ema-coverage.py',
                   'verify-mass-normalized-ema-coverage.py', 'build-ema-constructor-receipt.py',
                   'archive-mass-normalized-ema-coverage-qualification.py', 'stage-ema-constructor-report.py',
                   'verify-ema-constructor-report.py', 'import-ema-constructor-report.py',
                   'archive-ema-coverage-evidence.py', 'prove-mass-normalized-ema-coverage-integration.py',
                   'continue-ema-coverage-publication-20261026.py', 'benchmark_process_cleanup.py']
        for name in scripts: records[name] = archive(ROOT / name, name)
        write(OUT / 'constructor-coverage-receipt.json', receipt)
        write(OUT / 'decision.json', {'status': 'constructor-coverage-qualified', 'source_sha': summary['source_sha'],
              'all_16_cases_verified': True, 'additional_constructor_comparisons': 8,
              'qualification_type': 'New constructor coverage; not a candidate-versus-prior-Ooples speedup trial.',
              'production_integrated': False, 'report_imported': False, 'archives': records})
        print('Archived actual EMA measurements, verification, provenance and executed tooling.')
    else:
        imported = read(REPORT / 'imported.json'); verified = read(REPORT / 'browser-verification.json')
        assert imported['candidate_sha256'] == verified['report_sha256']
        assert hashlib.sha256((REPORT.parent / 'competitor-performance.html').read_bytes()).hexdigest() == verified['report_sha256']
        assert verified['existing_datasets_preserved'] and verified['additional_constructor_comparisons'] == 8
        assert not verified['javascript_errors']
        decision = read(OUT / 'decision.json'); assert decision['production_integrated']
        decision['report_archives'] = {name: archive(REPORT / name, 'report-' + name)
                                      for name in ['staged.json', 'browser-verification.json', 'imported.json']}
        decision.update(report_imported=True, report_sha256=verified['report_sha256'])
        write(OUT / 'decision.json', decision)
        print('Archived verified report import; existing catalog datasets preserved.')

if __name__ == '__main__': main()
