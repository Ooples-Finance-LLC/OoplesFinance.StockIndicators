```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **361.8 μs** | **55.44 μs** | **36.67 μs** |       **-** |   **89.2 KB** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   317.6 μs |  1.40 μs |  0.93 μs |  1.9531 |   41.6 KB |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **3,284.2 μs** | **26.44 μs** | **15.73 μs** | **31.2500** | **863.24 KB** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 3,172.3 μs |  6.63 μs |  3.47 μs |       - | 393.38 KB |
