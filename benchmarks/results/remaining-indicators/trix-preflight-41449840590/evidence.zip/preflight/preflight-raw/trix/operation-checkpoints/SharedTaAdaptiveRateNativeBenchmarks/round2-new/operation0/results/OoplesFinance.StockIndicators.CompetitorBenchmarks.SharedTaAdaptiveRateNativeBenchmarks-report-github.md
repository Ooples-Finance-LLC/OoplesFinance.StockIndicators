```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **309.4 μs** |  **2.44 μs** |  **1.45 μs** |       **-** |  **89.16 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   313.3 μs |  2.27 μs |  1.50 μs |  1.9531 |   41.6 KB |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **3,406.6 μs** | **28.05 μs** | **14.67 μs** | **31.2500** |  **863.2 KB** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 3,218.1 μs |  9.84 μs |  5.14 μs |       - |  393.4 KB |
