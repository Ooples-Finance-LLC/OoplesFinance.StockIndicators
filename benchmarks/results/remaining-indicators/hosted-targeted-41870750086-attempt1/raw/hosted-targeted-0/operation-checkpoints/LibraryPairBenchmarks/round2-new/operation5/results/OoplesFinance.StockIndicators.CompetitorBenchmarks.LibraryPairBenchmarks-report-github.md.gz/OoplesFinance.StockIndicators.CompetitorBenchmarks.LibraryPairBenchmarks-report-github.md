```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adx** |   **484.69 μs** | **35.957 μs** | **21.398 μs** |  **1.00** |    **0.06** |  **105.91 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adx |    22.10 μs |  1.968 μs |  1.030 μs |  0.05 |    0.00 |   40.23 KB |        0.38 |
|            |       |                     |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adx** | **4,150.73 μs** | **65.371 μs** | **38.901 μs** |  **1.00** |    **0.01** | **1039.84 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adx |   224.02 μs | 60.208 μs | 39.824 μs |  0.05 |    0.01 |  330.92 KB |        0.32 |
