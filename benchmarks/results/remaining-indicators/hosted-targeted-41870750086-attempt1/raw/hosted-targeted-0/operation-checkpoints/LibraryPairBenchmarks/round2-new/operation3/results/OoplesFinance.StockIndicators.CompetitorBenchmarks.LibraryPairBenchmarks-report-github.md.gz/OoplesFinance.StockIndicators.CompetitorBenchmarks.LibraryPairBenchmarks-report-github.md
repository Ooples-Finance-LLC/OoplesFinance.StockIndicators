```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDI [23]** |   **282.56 μs** | **30.696 μs** | **16.055 μs** |  **1.00** |    **0.07** |  **105.65 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDI [23] |    18.59 μs |  6.207 μs |  4.105 μs |  0.07 |    0.01 |   39.95 KB |        0.38 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDI [23]** | **2,215.84 μs** | **65.549 μs** | **34.283 μs** |  **1.00** |    **0.02** | **1036.38 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDI [23] |   127.91 μs | 16.550 μs |  9.848 μs |  0.06 |    0.00 |  330.59 KB |        0.32 |
