```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDM [23]** |   **179.66 μs** | **29.757 μs** | **17.708 μs** |  **1.01** |    **0.13** |  **105.69 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDM [23] |    17.69 μs |  0.505 μs |  0.264 μs |  0.10 |    0.01 |   38.95 KB |        0.37 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDM [23]** | **1,361.73 μs** | **57.756 μs** | **34.369 μs** |  **1.00** |    **0.03** | **1036.41 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDM [23] |   147.19 μs |  3.967 μs |  2.075 μs |  0.11 |    0.00 |  329.93 KB |        0.32 |
