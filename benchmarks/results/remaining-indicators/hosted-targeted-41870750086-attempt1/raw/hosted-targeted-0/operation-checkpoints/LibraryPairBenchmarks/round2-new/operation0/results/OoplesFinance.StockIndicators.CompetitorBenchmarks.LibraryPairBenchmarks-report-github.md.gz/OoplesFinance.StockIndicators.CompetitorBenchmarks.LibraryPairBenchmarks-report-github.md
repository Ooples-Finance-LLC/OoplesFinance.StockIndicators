```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDM [22]** |   **168.46 μs** | **10.571 μs** |  **6.290 μs** |  **1.00** |    **0.05** | **105.65 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDM [22] |    17.83 μs |  0.460 μs |  0.274 μs |  0.11 |    0.00 |  40.22 KB |        0.38 |
|            |       |                      |             |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)lusDM [22]** | **1,321.53 μs** | **30.761 μs** | **18.305 μs** |  **1.00** |    **0.02** | **1036.7 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDM [22] |   148.09 μs |  6.934 μs |  3.627 μs |  0.11 |    0.00 | 330.59 KB |        0.32 |
