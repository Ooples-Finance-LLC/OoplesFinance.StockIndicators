```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Dx** |   **525.21 μs** | **35.155 μs** | **23.253 μs** |  **1.00** |    **0.06** |  **105.66 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Dx |    22.45 μs |  0.490 μs |  0.256 μs |  0.04 |    0.00 |    39.9 KB |        0.38 |
|            |       |                    |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Dx** | **4,451.02 μs** | **29.422 μs** | **17.509 μs** |  **1.00** |    **0.01** | **1035.35 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Dx |   201.28 μs | 12.052 μs |  7.172 μs |  0.05 |    0.00 |  330.92 KB |        0.32 |
