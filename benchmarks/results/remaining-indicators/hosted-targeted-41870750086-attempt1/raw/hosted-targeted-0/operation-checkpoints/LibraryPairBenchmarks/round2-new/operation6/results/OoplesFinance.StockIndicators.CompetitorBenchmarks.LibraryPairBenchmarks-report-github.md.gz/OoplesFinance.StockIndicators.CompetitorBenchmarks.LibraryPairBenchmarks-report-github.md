```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adxr** |   **511.66 μs** | **48.133 μs** | **31.837 μs** |  **1.00** |    **0.08** |  **106.98 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adxr |    26.43 μs |  4.740 μs |  2.479 μs |  0.05 |    0.01 |   48.45 KB |        0.45 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adxr** | **4,471.26 μs** | **74.677 μs** | **44.439 μs** |  **1.00** |    **0.01** | **1040.91 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adxr |   216.89 μs | 29.422 μs | 17.508 μs |  0.05 |    0.00 |  407.87 KB |        0.39 |
