```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **461.94 μs** |  **7.133 μs** |  **3.731 μs** | **26.83** |    **0.21** |       **-** |      **-** |  **66.31 KB** |        **4.42** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   456.27 μs |  4.298 μs |  2.843 μs | 26.50 |    0.16 |       - |      - |  18.72 KB |        1.25 |
| NativeSingle      | TaLib.Functions.Adxr | 1000  |    17.22 μs |  0.051 μs |  0.027 μs |  1.00 |    0.00 |  0.8545 |      - |  14.99 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 1000  |    34.24 μs |  2.226 μs |  1.324 μs |  1.99 |    0.07 |  3.1738 |      - |  45.43 KB |        3.03 |
|                   |                      |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **4,768.91 μs** | **29.625 μs** | **15.495 μs** | **27.17** |    **0.19** | **31.2500** |      **-** | **631.98 KB** |        **4.06** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 4,757.80 μs | 18.773 μs |  9.819 μs | 27.10 |    0.18 |       - |      - | 162.17 KB |        1.04 |
| NativeSingle      | TaLib.Functions.Adxr | 10000 |   175.55 μs |  2.229 μs |  1.166 μs |  1.00 |    0.01 |  8.7891 | 0.9766 | 155.63 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 10000 |   259.65 μs |  9.738 μs |  5.093 μs |  1.48 |    0.03 | 29.2969 | 5.8594 | 467.32 KB |        3.00 |
