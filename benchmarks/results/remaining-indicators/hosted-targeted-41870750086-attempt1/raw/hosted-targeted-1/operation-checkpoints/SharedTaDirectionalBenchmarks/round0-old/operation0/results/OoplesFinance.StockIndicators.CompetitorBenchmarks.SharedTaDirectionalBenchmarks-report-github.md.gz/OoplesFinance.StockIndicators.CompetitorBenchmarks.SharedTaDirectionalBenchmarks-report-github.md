```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **134.2 μs** |  **1.38 μs** |  **0.72 μs** |  **3.9063** |      **-** |  **65.01 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   132.3 μs |  3.46 μs |  2.06 μs |  0.9766 |      - |  17.41 KB |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **1,305.9 μs** | **11.76 μs** |  **7.00 μs** | **31.2500** | **7.8125** | **627.92 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 1,284.1 μs | 22.46 μs | 11.75 μs |  7.8125 |      - | 158.09 KB |
