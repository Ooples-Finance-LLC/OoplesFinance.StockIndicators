```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **546.3 μs** |  **9.48 μs** |  **4.96 μs** |       **-** |  **64.99 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   540.5 μs | 16.05 μs |  9.55 μs |       - |  17.43 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **5,549.4 μs** | **84.79 μs** | **44.35 μs** | **31.2500** | **628.07 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 5,453.4 μs | 33.46 μs | 17.50 μs |       - | 158.27 KB |
