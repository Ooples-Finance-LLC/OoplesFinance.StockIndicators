```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev  | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **232.6 μs** |  **1.45 μs** | **0.76 μs** |       **-** |  **65.01 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   234.5 μs |  1.99 μs | 1.18 μs |       - |  17.41 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **2,301.8 μs** |  **4.55 μs** | **2.71 μs** | **31.2500** | **627.97 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,258.5 μs | 15.12 μs | 9.00 μs |       - | 158.14 KB |
