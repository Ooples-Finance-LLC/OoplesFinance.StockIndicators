```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **451.95 μs** |   **5.894 μs** |   **3.083 μs** | **29.20** |    **0.22** |       **-** |      **-** |  **65.02 KB** |        **8.42** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   442.51 μs |   3.676 μs |   1.923 μs | 28.59 |    0.16 |       - |      - |  17.43 KB |        2.26 |
| NativeSingle      | TaLib.Functions.Dx | 1000  |    15.48 μs |   0.100 μs |   0.060 μs |  1.00 |    0.01 |  0.3662 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 1000  |    26.07 μs |   1.446 μs |   0.861 μs |  1.68 |    0.05 |  1.7090 |      - |  27.24 KB |        3.53 |
|                   |                    |       |             |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **5,256.37 μs** | **769.861 μs** | **509.216 μs** | **33.68** |    **3.11** | **31.2500** |      **-** | **628.12 KB** |        **8.05** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 4,635.84 μs |  21.202 μs |  12.617 μs | 29.70 |    0.11 |       - |      - | 158.27 KB |        2.03 |
| NativeSingle      | TaLib.Functions.Dx | 10000 |   156.08 μs |   0.714 μs |   0.425 μs |  1.00 |    0.00 |  3.9063 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 10000 |   233.23 μs |  17.976 μs |  11.890 μs |  1.49 |    0.07 | 17.5781 | 3.9063 | 273.35 KB |        3.50 |
