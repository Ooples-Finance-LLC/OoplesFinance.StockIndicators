```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **509.0 μs** |  **4.68 μs** |  **2.78 μs** |       **-** |  **65.24 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   504.3 μs |  7.63 μs |  5.04 μs |       - |  17.64 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **5,232.6 μs** | **82.28 μs** | **54.42 μs** | **31.2500** | **630.93 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 5,160.6 μs | 39.59 μs | 23.56 μs |       - |  161.1 KB |
