```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error    | StdDev   | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|---------:|---------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **139.92 μs** | **2.049 μs** | **1.219 μs** | **13.58** |    **0.12** |  **3.9063** |      **-** |  **65.01 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   135.69 μs | 2.079 μs | 1.088 μs | 13.17 |    0.11 |  0.9766 |      - |  17.41 KB |        2.26 |
| NativeSingle      | TaLib(...)nusDM [23] | 1000  |    10.30 μs | 0.066 μs | 0.039 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 1000  |    14.18 μs | 0.766 μs | 0.507 μs |  1.38 |    0.05 |  1.8311 |      - |  27.23 KB |        3.53 |
|                   |                      |       |             |          |          |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,320.48 μs** | **8.446 μs** | **5.026 μs** | **12.62** |    **0.05** | **31.2500** | **7.8125** | **627.92 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 1,307.12 μs | 7.524 μs | 4.478 μs | 12.49 |    0.04 |  7.8125 |      - | 158.09 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDM [23] | 10000 |   104.62 μs | 0.267 μs | 0.140 μs |  1.00 |    0.00 |  3.9063 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 10000 |   160.34 μs | 4.177 μs | 2.763 μs |  1.53 |    0.03 | 17.5781 | 3.9063 | 273.33 KB |        3.50 |
