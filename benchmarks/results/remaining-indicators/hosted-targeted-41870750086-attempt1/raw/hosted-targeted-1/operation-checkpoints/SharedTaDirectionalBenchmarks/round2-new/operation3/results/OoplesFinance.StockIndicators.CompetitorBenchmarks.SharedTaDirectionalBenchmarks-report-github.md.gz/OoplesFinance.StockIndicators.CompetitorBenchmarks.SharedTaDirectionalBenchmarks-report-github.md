```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **222.319 μs** |  **2.9597 μs** |  **1.5480 μs** | **30.16** |    **0.24** |       **-** |      **-** |  **64.97 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   219.535 μs |  0.5890 μs |  0.3081 μs | 29.78 |    0.14 |       - |      - |  17.41 KB |        2.26 |
| NativeSingle      | TaLib(...)nusDI [23] | 1000  |     7.372 μs |  0.0595 μs |  0.0354 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 1000  |    12.321 μs |  0.6347 μs |  0.4198 μs |  1.67 |    0.05 |  1.8311 |      - |  27.24 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **2,153.125 μs** | **13.0062 μs** |  **6.8025 μs** | **29.40** |    **0.41** | **31.2500** |      **-** | **627.94 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,112.448 μs | 19.4996 μs | 11.6039 μs | 28.84 |    0.42 |       - |      - | 158.15 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDI [23] | 10000 |    73.251 μs |  1.6003 μs |  1.0585 μs |  1.00 |    0.02 |  4.3945 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 10000 |   120.224 μs | 12.9360 μs |  8.5564 μs |  1.64 |    0.11 | 17.5781 | 4.8828 | 273.34 KB |        3.50 |
