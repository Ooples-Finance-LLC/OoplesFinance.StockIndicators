```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **267.7 μs** | **14.37 μs** |  **8.55 μs** |       **-** |  **65.01 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   247.3 μs |  6.73 μs |  4.00 μs |       - |  17.41 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **2,388.3 μs** | **16.69 μs** |  **8.73 μs** | **31.2500** | **627.98 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,405.8 μs | 29.34 μs | 17.46 μs |       - | 158.15 KB |
