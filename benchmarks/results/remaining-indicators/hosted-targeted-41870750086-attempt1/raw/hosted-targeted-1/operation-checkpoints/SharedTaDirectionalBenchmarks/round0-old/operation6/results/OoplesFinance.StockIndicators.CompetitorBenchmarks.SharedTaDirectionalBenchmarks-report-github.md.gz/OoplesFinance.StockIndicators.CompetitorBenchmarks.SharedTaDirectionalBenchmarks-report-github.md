```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **550.3 μs** |  **5.14 μs** |  **2.69 μs** |       **-** |  **66.28 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   564.2 μs | 37.46 μs | 24.78 μs |       - |  18.72 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **5,631.9 μs** | **24.14 μs** | **12.62 μs** | **31.2500** | **631.98 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 5,601.6 μs | 24.19 μs | 12.65 μs |       - | 162.15 KB |
