```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error    | StdDev   | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|---------:|---------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **132.07 μs** | **2.183 μs** | **1.299 μs** | **12.81** |    **0.12** |  **3.9063** |      **-** |  **65.01 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   128.25 μs | 2.927 μs | 1.742 μs | 12.44 |    0.16 |  0.9766 |      - |  17.41 KB |        2.26 |
| NativeSingle      | TaLib(...)lusDM [22] | 1000  |    10.31 μs | 0.047 μs | 0.028 μs |  1.00 |    0.00 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 1000  |    14.16 μs | 1.037 μs | 0.686 μs |  1.37 |    0.06 |  1.8311 |      - |  27.23 KB |        3.53 |
|                   |                      |       |             |          |          |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **1,268.65 μs** | **6.780 μs** | **4.484 μs** | **12.17** |    **0.04** | **31.2500** | **7.8125** | **627.92 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 1,244.14 μs | 8.536 μs | 4.464 μs | 11.94 |    0.04 |  7.8125 |      - | 158.09 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDM [22] | 10000 |   104.22 μs | 0.181 μs | 0.095 μs |  1.00 |    0.00 |  3.9063 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 10000 |   159.76 μs | 3.934 μs | 2.341 μs |  1.53 |    0.02 | 17.5781 | 3.9063 | 273.33 KB |        3.50 |
