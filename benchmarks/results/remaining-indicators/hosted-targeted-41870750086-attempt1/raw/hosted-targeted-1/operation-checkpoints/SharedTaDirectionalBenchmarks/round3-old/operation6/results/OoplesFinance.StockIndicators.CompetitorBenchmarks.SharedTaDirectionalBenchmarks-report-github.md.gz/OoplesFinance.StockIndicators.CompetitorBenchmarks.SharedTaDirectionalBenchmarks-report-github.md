```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **547.7 μs** |   **3.75 μs** |  **2.23 μs** |       **-** |  **66.31 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   544.4 μs |   3.48 μs |  1.82 μs |       - |  18.72 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **5,664.6 μs** | **147.47 μs** | **97.54 μs** | **31.2500** | **631.98 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 5,577.7 μs |  26.77 μs | 15.93 μs |       - | 162.17 KB |
