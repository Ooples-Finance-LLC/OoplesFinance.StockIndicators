```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **216.667 μs** |  **7.3517 μs** |  **4.3749 μs** | **29.26** |    **0.57** |       **-** |      **-** |  **65.01 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   214.275 μs |  1.3978 μs |  0.9246 μs | 28.94 |    0.17 |       - |      - |  17.41 KB |        2.26 |
| NativeSingle      | TaLib(...)lusDI [22] | 1000  |     7.405 μs |  0.0526 μs |  0.0313 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 1000  |    12.577 μs |  0.8826 μs |  0.5252 μs |  1.70 |    0.07 |  1.8311 |      - |  27.24 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **2,119.428 μs** | **36.6516 μs** | **21.8108 μs** | **28.60** |    **0.32** | **31.2500** |      **-** | **627.98 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,066.256 μs | 14.7885 μs |  8.8004 μs | 27.89 |    0.18 |       - |      - | 158.14 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDI [22] | 10000 |    74.098 μs |  0.6898 μs |  0.4105 μs |  1.00 |    0.01 |  4.3945 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 10000 |   135.030 μs |  9.4903 μs |  6.2772 μs |  1.82 |    0.08 | 17.5781 | 3.9063 | 273.34 KB |        3.50 |
