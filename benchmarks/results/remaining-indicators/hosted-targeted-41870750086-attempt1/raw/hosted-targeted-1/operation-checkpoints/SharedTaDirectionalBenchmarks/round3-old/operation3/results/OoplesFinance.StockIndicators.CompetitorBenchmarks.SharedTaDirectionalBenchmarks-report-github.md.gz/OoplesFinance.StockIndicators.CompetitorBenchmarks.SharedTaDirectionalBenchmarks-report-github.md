```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **250.7 μs** |  **0.96 μs** |  **0.50 μs** |       **-** |  **65.06 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   241.7 μs |  1.60 μs |  0.95 μs |       - |  17.41 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **2,391.6 μs** | **42.95 μs** | **25.56 μs** | **31.2500** | **627.97 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,387.9 μs | 19.40 μs | 11.55 μs |       - | 158.15 KB |
