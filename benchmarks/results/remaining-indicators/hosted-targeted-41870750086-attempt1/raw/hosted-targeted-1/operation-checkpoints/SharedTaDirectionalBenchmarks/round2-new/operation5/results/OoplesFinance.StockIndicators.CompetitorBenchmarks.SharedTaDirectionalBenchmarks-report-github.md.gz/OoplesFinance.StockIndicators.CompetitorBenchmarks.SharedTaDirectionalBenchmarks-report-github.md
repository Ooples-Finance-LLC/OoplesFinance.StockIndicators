```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **419.54 μs** |  **2.549 μs** |  **1.517 μs** | **27.62** |    **0.19** |       **-** |      **-** |  **65.24 KB** |        **8.62** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   412.49 μs |  6.701 μs |  3.505 μs | 27.16 |    0.27 |       - |      - |  17.65 KB |        2.33 |
| NativeSingle      | TaLib.Functions.Adx | 1000  |    15.19 μs |  0.157 μs |  0.094 μs |  1.00 |    0.01 |  0.3662 |      - |   7.57 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 1000  |    28.54 μs |  0.752 μs |  0.497 μs |  1.88 |    0.03 |  1.7090 |      - |  26.71 KB |        3.53 |
|                   |                     |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **4,394.47 μs** | **29.423 μs** | **17.509 μs** | **28.58** |    **0.25** | **31.2500** |      **-** | **630.94 KB** |        **8.10** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 4,369.82 μs | 25.018 μs | 14.888 μs | 28.42 |    0.24 |       - |      - | 161.09 KB |        2.07 |
| NativeSingle      | TaLib.Functions.Adx | 10000 |   153.79 μs |  2.177 μs |  1.295 μs |  1.00 |    0.01 |  3.9063 |      - |  77.89 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 10000 |   227.72 μs | 12.990 μs |  7.730 μs |  1.48 |    0.05 | 17.5781 | 5.8594 | 272.82 KB |        3.50 |
