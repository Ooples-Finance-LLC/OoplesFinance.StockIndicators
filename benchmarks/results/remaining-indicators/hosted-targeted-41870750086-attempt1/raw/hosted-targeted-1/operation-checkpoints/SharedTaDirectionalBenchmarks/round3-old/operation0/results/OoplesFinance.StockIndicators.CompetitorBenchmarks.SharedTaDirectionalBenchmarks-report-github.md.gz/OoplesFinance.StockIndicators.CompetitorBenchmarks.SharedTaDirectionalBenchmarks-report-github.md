```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **134.1 μs** |  **1.06 μs** |  **0.55 μs** |  **3.9063** |      **-** |  **65.01 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   129.1 μs |  1.02 μs |  0.68 μs |  0.9766 |      - |  17.41 KB |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **1,298.7 μs** | **21.72 μs** | **14.37 μs** | **31.2500** | **7.8125** | **627.92 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 1,258.5 μs |  9.31 μs |  4.87 μs |  7.8125 |      - | 158.09 KB |
