```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **414.2 μs** | **16.23 μs** |  **8.49 μs** |       **-** |  **65.24 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   403.8 μs |  4.59 μs |  2.73 μs |       - |  17.65 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **4,320.5 μs** | **30.84 μs** | **18.35 μs** | **31.2500** | **630.93 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 4,252.1 μs | 68.90 μs | 41.00 μs |       - |  161.1 KB |
