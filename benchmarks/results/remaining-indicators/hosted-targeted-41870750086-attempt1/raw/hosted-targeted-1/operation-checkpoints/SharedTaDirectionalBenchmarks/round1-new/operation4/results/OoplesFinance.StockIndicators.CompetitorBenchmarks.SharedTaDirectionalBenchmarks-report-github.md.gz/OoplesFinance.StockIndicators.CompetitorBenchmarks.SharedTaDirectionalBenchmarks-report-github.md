```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **452.1 μs** |  **3.45 μs** |  **2.05 μs** |       **-** |  **65.02 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   444.8 μs |  3.38 μs |  2.01 μs |       - |  17.43 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **4,729.4 μs** | **32.74 μs** | **17.12 μs** | **31.2500** | **628.09 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 4,608.8 μs | 25.58 μs | 15.22 μs |       - | 158.28 KB |
