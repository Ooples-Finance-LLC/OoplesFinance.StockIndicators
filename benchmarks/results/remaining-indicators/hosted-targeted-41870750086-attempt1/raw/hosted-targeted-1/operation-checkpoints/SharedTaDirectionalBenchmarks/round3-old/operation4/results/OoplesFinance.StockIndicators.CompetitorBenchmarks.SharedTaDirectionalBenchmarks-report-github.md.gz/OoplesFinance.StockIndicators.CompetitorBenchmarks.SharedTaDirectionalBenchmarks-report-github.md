```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **547.7 μs** |  **5.28 μs** |  **3.14 μs** |       **-** |  **65.02 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   539.9 μs |  3.68 μs |  1.93 μs |       - |  17.43 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **5,518.4 μs** | **22.34 μs** | **13.30 μs** | **31.2500** | **628.12 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 5,474.1 μs | 14.40 μs |  7.53 μs |       - | 158.29 KB |
