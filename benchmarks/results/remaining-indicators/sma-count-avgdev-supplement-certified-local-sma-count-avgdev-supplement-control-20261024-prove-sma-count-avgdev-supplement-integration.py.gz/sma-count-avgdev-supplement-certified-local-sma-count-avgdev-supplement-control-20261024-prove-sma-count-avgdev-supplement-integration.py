from pathlib import Path
import hashlib,json,subprocess
root=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
repo=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
run='local-sma-count-avgdev-supplement-control-20261024'
summary=json.loads((root/run/'verified-summary.json').read_text())
checks=json.loads((root/'sma-count-avgdev-supplement/checks.json').read_text())
qualified=json.loads((root/'sma-count-publication/status.json').read_text())
assert summary['all_48_cases_verified'] and not any(r['verdict']=='slower' for r in summary['decisions'])
assert checks['passed']==25 and checks['source']==summary['sources']['new']
for path,sha in qualified['production_dll_sha256'].items(): assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==sha
paths=['src','tests','benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks','benchmarks/OoplesFinance.StockIndicators.CompetitorTests','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json']
differences=set(subprocess.check_output(['git','diff','--name-only',checks['source'],'HEAD','--',*paths],cwd=repo,text=True).splitlines())
assert differences=={'src/Helpers/CertifiedHilbertProjection.cs','tests/ModelsTests/CertifiedHilbertProjectionTests.cs'},differences
proof={'measurement_source':checks['source'],'publication_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'checks':checks,'unchanged_input_scope':paths,'unrelated_differences':sorted(differences),'qualified_code':qualified['input_head'],'qualification_reused':{'unit':49,'parity':2,'gpu':100,'inventory':8},'additional_affected_consumer_checks':25,'note':'Existing published SMA count implementation measured for its AvgDev consumer. All executable/build inputs match the preserved qualified binary except the later unrelated Hilbert projection helper/tests. Mean-error calculation does not call the Hilbert projection helper. No new production integration or build.'}
(repo/'benchmarks/results/remaining-indicators/sma-count-avgdev-supplement-integration-source-proof-20261024.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Verified preserved qualified source and affected-consumer evidence')
