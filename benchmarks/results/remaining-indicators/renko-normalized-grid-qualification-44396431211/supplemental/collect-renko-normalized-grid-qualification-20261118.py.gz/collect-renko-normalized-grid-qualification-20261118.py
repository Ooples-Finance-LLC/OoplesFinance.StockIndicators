"""Collect one normalized Renko full qualification; explicit --recollect re-streams hosted ZIP but never replaces retained evidence or installs payload."""
import argparse,hashlib,io,json,os,re,shutil,stat,subprocess,sys,tempfile,traceback,zipfile
from pathlib import Path,PurePosixPath

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--run',required=True);parser.add_argument('--head',required=True)
parser.add_argument('--plan-sha256',required=True);parser.add_argument('--recollect',action='store_true')
parser.add_argument('--repo',type=Path,default=Path(r'C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-renko-normalized-grid-qualification-20261118'))
args=parser.parse_args()
assert re.fullmatch('[1-9][0-9]*',args.run) and re.fullmatch('[a-f0-9]{40}',args.head) and re.fullmatch('[a-f0-9]{64}',args.plan_sha256)
assert (args.run,args.head,args.plan_sha256)==('44396431211','815df1c14e783bb0b3ab4ffe79aaf8fe22d76120','ffdf5df12c0085d8573c27e2b2db768cc76fc6b1e27d6eeb61a2ee7f51137013'),'Current reviewed run/head/plan only'
REPO=args.repo.resolve();REMOTE='Ooples-Finance-LLC/OoplesFinance.StockIndicators'
PLAN_REL='benchmarks/plans/hosted-renko-normalized-grid-qualification-20261118.json';PLAN=REPO/PLAN_REL
OPS=Path(r'C:\Users\cheat\source\stock-indicators-operations\renko-normalized-grid-qualification-20261118')
OUT=OPS/'local-evidence'/('renko-normalized-grid-qualification-'+args.run)
PREP=OPS/('hosted-inputs-'+args.run);RAW=OUT/'raw/evidence';SCRATCH=OPS/('verification-temp-'+args.run)
CACHES=[Path('C:/Users/cheat/source/stock-indicators-operations/ultimate-direct-long-certificate-correctness-20261118/authenticated-input-44341191246'),Path('C:/Users/cheat/source/stock-indicators-operations/renko-normalized-grid-correctness-20261118/authenticated-input-44388147138')]

def git(*values):return subprocess.check_output(['git',*values],cwd=REPO)
def api(path):return json.loads(subprocess.check_output(['gh','api','repos/'+REMOTE+'/'+path],cwd=REPO))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def write(path,data):path.write_bytes((json.dumps(data,indent=2)+'\n').encode())
def zip_digest(package,entry):
    with package.open(entry) as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def verifier_bound():
    assert git('rev-parse','HEAD').decode().strip()==args.head and not git('status','--porcelain')
    raw=PLAN.read_bytes();assert sha(raw)==args.plan_sha256 and b'\r' not in raw and raw==git('show',args.head+':'+PLAN_REL)

verifier_bound();os.environ['HOSTED_TIMING_PLAN']=str(PLAN);sys.path.insert(0,str(REPO/'scripts'))
from hosted_timing import renko_normalized_grid_qualification as q
plan=q.p.read(PLAN);q.validate_scope(plan)
assert q.OLD=='c5bfd4950982aa80dddbfd2db6358ad43ddb9e4c' and q.NEW=='d9d00ca56ebb857b87ead45044616970b607019c'
assert q.PAIRS==['Skender.GetRenko','Skender.GetRenkoAtr']
assert q.SCOPE=='renko-normalized-grid-qualification-20261118' and q.KIND=='renko-normalized-grid-qualification'
state=api('actions/runs/'+args.run)
assert str(state['id'])==args.run and state['head_sha']==args.head and state['run_attempt']==1
assert state['head_branch']=='perf/renko-normalized-grid-qualification-20261118' and state['path']=='.github/workflows/renko-normalized-grid-qualification.yml'
assert state['event']=='push' and state['status']=='completed','Require actual completion before collection'
assert state['conclusion']=='success','Failed workflow cannot establish an authenticated completed diagnostic'
jobs=api('actions/runs/'+args.run+'/jobs?per_page=100')['jobs'];active=[job for job in jobs if job['conclusion']!='skipped']
assert len(active)==1 and active[0]['conclusion']=='success','Exactly one successful diagnostic runner is required'
items=api('actions/runs/'+args.run+'/artifacts')['artifacts'];items=[item for item in items if item['name']=='renko-normalized-grid-qualification' and not item['expired']]
assert len(items)==1;artifact=items[0]
assert str(artifact['workflow_run']['id'])==args.run and artifact['workflow_run']['head_sha']==args.head
assert re.fullmatch('sha256:[a-f0-9]{64}',artifact['digest'])
if args.recollect:
    receipt=q.p.read(OUT/'collection-receipt.json')
    assert receipt['status']=='actual-renko-normalized-grid-qualification-authenticated' and receipt['run_id']==args.run and receipt['head']==args.head
    assert receipt['plan_sha256']==args.plan_sha256 and receipt['artifact_id']==artifact['id'] and receipt['artifact_zip_sha256']==artifact['digest'][7:]
    assert PREP.is_dir() and RAW.is_dir() and SCRATCH.is_dir()
else:
    assert not OUT.exists() and not PREP.exists() and not SCRATCH.exists(),'Preserve existing or failed collection; no automatic retry'
    assert shutil.disk_usage(OPS.parent).free>=64*1024**2,'Fresh metadata headroom; exact post-ZIP budget follows before installation'
    OUT.mkdir(parents=True);write(OUT/'run-api.json',state);write(OUT/'artifact-api.json',artifact)

phase='hosted-memory-recollection' if args.recollect else 'download-memory'
try:
    assert 0<artifact['size_in_bytes']<=512*1024*1024,'Unexpected archive size; leave hosted'
    print(json.dumps(dict(phase=phase,run_id=args.run,artifact_id=artifact['id'],bytes=artifact['size_in_bytes'])),flush=True)
    buffer=io.BytesIO();download_hash=hashlib.sha256();downloaded=0
    process=subprocess.Popen(['gh','api',f"repos/{REMOTE}/actions/artifacts/{artifact['id']}/zip"],cwd=REPO,stdout=subprocess.PIPE)
    try:
        while True:
            chunk=process.stdout.read(1024*1024)
            if not chunk:break
            downloaded+=len(chunk);assert downloaded<=artifact['size_in_bytes'];download_hash.update(chunk);buffer.write(chunk)
        assert process.wait()==0
    finally:
        if process.poll() is None:process.kill();process.wait()
    assert downloaded==artifact['size_in_bytes'] and download_hash.hexdigest()==artifact['digest'][7:]
    buffer.seek(0)
    phase='zip-authentication'
    with zipfile.ZipFile(buffer) as package:
        entries=[entry for entry in package.infolist() if not entry.is_dir()];files={entry.filename:entry for entry in entries}
        assert len(files)==len(entries)==len({name.casefold() for name in files})
        for name,entry in files.items():
            rel=PurePosixPath(name)
            assert not rel.is_absolute() and '..' not in rel.parts and ':' not in name and '\\' not in name
            assert all(part not in ('.','..') and not part.endswith(('.',' ')) for part in rel.parts)
            assert not stat.S_ISLNK(entry.external_attr>>16)
        prep_prefix='reconciled-inputs/';raw_prefix='reconciled-qualification/evidence/';summary_name='reconciled-qualification/summary.json'
        prepared={name[len(prep_prefix):]:entry for name,entry in files.items() if name.startswith(prep_prefix)}
        raw={name[len(raw_prefix):]:entry for name,entry in files.items() if name.startswith(raw_prefix+'shard0/')}
        assert prepared and raw and summary_name in files
        proof_raw=package.read(prep_prefix+'provenance.json');proof=json.loads(proof_raw)
        assert str(proof['run_id'])==args.run and str(proof['run_attempt'])=='1' and proof['workflow_head']==args.head
        assert proof['sources']==plan['sources'] and proof['plan_sha256']==args.plan_sha256
        shard=json.loads(package.read(raw_prefix+'shard0/provenance.json'))
        assert shard['input_provenance_sha256']==sha(proof_raw)
        classified={prep_prefix+name for name in prepared}|{raw_prefix+name for name in raw}|{summary_name};runtime_count=0
        for arm in ('old','new'):
            prefix=raw_prefix+'shard0-runtime-'+arm+'/'
            actual={name[len(prefix):]:entry for name,entry in files.items() if name.startswith(prefix)}
            declared=shard['binary_manifest'][arm];assert set(actual)==set(declared)
            for relative,entry in actual.items():
                assert zip_digest(package,entry)==declared[relative];classified.add(entry.filename);runtime_count+=1
        assert classified==set(files),'Every uploaded file must have an authenticated role'
        cache={};unit_temp_sizes=[]
        for root,key in zip(CACHES,('old_candidate','candidate')):
            manifest_path=root/'manifest.json';assert digest(manifest_path)==plan[key]['manifest_sha256'];manifest=json.loads(manifest_path.read_bytes())
            assert manifest['source']==plan[key]['source'] and str(manifest['run_id'])==plan[key]['ci_run']
            for path in (root/'blobs').rglob('*'):
                if path.is_file():cache.setdefault(path.name,path)
            unit_temp_sizes.append(sum((root/'blobs'/value).stat().st_size for name,value in manifest['runtime_files'].items() if name.startswith('tests/bin/Release/net10.0/')))
        def payload(relative):return relative.startswith(('common/','production/')) or '/blobs/' in relative
        metadata_bytes=sum(entry.file_size for relative,entry in prepared.items() if not payload(relative))
        raw_bytes=sum(entry.file_size for entry in raw.values());summary_bytes=files[summary_name].file_size
        metadata_allowance=4096*(len(prepared)+len(raw)+64)
        temp_peak=max(unit_temp_sizes);required=(0 if args.recollect else metadata_bytes+raw_bytes+3*summary_bytes+metadata_allowance)+temp_peak+64*1024*1024
        if not args.recollect:OPS.mkdir(parents=True,exist_ok=True)
        free=shutil.disk_usage(OPS).free;assert free>=required,'Insufficient C metadata/temp/headroom; preserve artifact without materializing payload'
        if not args.recollect:
            write(OUT/'storage-budget.json',dict(available_free_bytes=free,required_free_bytes=required,prepared_metadata_bytes=metadata_bytes,retained_raw_bytes=raw_bytes,summary_bytes=summary_bytes,counted_metadata_allowance_bytes=metadata_allowance,verification_temp_peak_bytes=temp_peak,reserve_bytes=64*1024*1024,new_runtime_payload_bytes=0,retained_zip_bytes=0))
            PREP.mkdir();RAW.mkdir(parents=True);SCRATCH.mkdir()
        phase='prepared-and-raw-verification';verified_cache=set();links=0
        for relative,entry in prepared.items():
            target=PREP.joinpath(*PurePosixPath(relative).parts);assert target.resolve().is_relative_to(PREP.resolve())
            expected=zip_digest(package,entry)
            if args.recollect:assert target.is_file() and digest(target)==expected
            else:
                target.parent.mkdir(parents=True,exist_ok=True)
                if payload(relative):
                    assert expected in cache,'No uncached runtime payload may be installed: '+relative
                    if expected not in verified_cache:assert digest(cache[expected])==expected;verified_cache.add(expected)
                    os.link(cache[expected],target);assert os.path.samefile(cache[expected],target);links+=1
                else:
                    assert target.suffix.lower() not in ('.dll','.exe','.pdb')
                    target.write_bytes(package.read(entry));assert digest(target)==expected
        for relative,entry in raw.items():
            target=RAW.joinpath(*PurePosixPath(relative).parts);assert target.resolve().is_relative_to(RAW.resolve())
            assert target.suffix.lower() not in ('.dll','.exe','.pdb'),'Runtime ZIP payload is authenticated in place; retain only critical raw evidence'
            expected=zip_digest(package,entry)
            if args.recollect:assert target.is_file() and digest(target)==expected
            else:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(package.read(entry));assert digest(target)==expected
        assert {path.relative_to(PREP).as_posix() for path in PREP.rglob('*') if path.is_file()}==set(prepared)
        assert {path.relative_to(RAW).as_posix() for path in RAW.rglob('*') if path.is_file()}==set(raw)
        summary_raw=package.read(summary_name);hosted=json.loads(summary_raw)
        assert len(prepared)+len(raw)+runtime_count+1==len(files)
        if not args.recollect:(OUT/'uploaded-summary.json').write_bytes(summary_raw)
        else:assert (OUT/'uploaded-summary.json').read_bytes()==summary_raw
        assert digest(PREP/'provenance.json')==sha(proof_raw)
        assert shutil.disk_usage(OPS).free>=temp_peak+64*1024*1024,'Fresh verification temp budget required'
        os.environ.update(TEMP=str(SCRATCH),TMP=str(SCRATCH));tempfile.tempdir=str(SCRATCH)
        phase='actual-collector-replay';verifier_bound();q.p.verify_inputs(PREP);result=q.collect(RAW);verifier_bound()
        assert result==hosted and result['input_provenance_sha256']==sha(proof_raw)
        assert (result['case_count'],result['decision_count'])==(44,8)
        assert type(result['accepted']) is bool and result['qualification'] is True
        assert result['production_integrated'] is False and result['report_imported'] is False
        assert result['accepted']==(result['source_gate_accepted'] and result['native_progress_gate_passed'])
        expected={(pair,bars,'LibraryPairBenchmarks','Ooples') for pair in q.PAIRS for bars in (1000,10000)}
        expected|={(pair,bars,'SharedSkenderRenkoChartNativeBenchmarks','Snapshot') for pair in q.PAIRS for bars in (1000,10000)}
        assert {(row['pair'],row['bars'],row['fixture'],row['method']) for row in result['decisions']}==expected
        rendered=(json.dumps(result,indent=2)+'\n').encode();assert rendered==summary_raw,'Recomputed canonical summary must be byte-identical to uploaded summary'
        screen=result['native_progress_gate']
        concise=dict(status='actual-renko-normalized-grid-qualification-authenticated',run_id=args.run,head=args.head,plan_sha256=args.plan_sha256,
            artifact_id=artifact['id'],artifact_zip_sha256=artifact['digest'][7:],artifact_zip_bytes_verified_in_memory=downloaded,retained_zip_bytes=0,zip_files_verified=len(files),prepared_files_verified=len(prepared),raw_files_verified=len(raw),runtime_zip_payload_files_verified=runtime_count,
            prepared=str(PREP),raw=str(RAW),prepared_provenance_sha256=sha(proof_raw),fixture_inventory_sha256=digest(PREP/'fixture-method-inventory.json'),
            summary_sha256=sha(rendered),cases=44,decisions=8,verdicts=result['verdicts'],source_gate_passed=result['source_gate_accepted'],native_progress_gate_passed=screen['passed'],
            net_10000_point_progress=screen['net_10000_point_progress'],old_10000_point_win_counts=screen['old_10000_point_win_counts'],candidate_10000_point_win_counts=screen['candidate_10000_point_win_counts'],
            new_10000_target_win_pairs=[row['pair'] for row in screen['new_10000_target_wins']],
            runtime_hardlinks=links if not args.recollect else receipt['runtime_hardlinks'],new_runtime_payload_bytes=0,uploaded_summary_byte_equal=True,
            accepted=result['accepted'],qualification=True,production_integrated=False,report_imported=False,closure_credit=0,automatic_qualification=False,new_measurements=0,root_authentication_pending=True)
        if args.recollect:
            assert (OUT/'authenticated-summary.json').read_bytes()==rendered and receipt['summary_sha256']==sha(rendered)
            concise['status']='independent-recollection-matches-original';concise['retained_evidence_files_changed']=0
        else:(OUT/'authenticated-summary.json').write_bytes(rendered);write(OUT/'collection-receipt.json',concise)
        print(json.dumps(concise,indent=2),flush=True)
except BaseException as error:
    if not args.recollect:write(OUT/'collection-failure.json',dict(run_id=args.run,head=args.head,phase=phase,error=str(error),traceback=traceback.format_exc(),automatic_retry_allowed=False,accepted=False,closure_credit=0))
    raise
