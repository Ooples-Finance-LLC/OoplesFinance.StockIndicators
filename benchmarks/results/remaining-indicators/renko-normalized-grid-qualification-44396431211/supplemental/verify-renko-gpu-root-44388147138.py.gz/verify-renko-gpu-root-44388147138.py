import gzip,hashlib,importlib.util,json,subprocess,sys,xml.etree.ElementTree as ET
from pathlib import Path
assert sys.argv[1:]==['44388147138']
run='44388147138'; source='d9d00ca56ebb857b87ead45044616970b607019c'
ops=Path(r'C:\Users\cheat\source\stock-indicators-operations\renko-normalized-grid-correctness-20261118')
repo=Path(r'C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-renko-normalized-grid-gpu-only-20261118')
view=ops/('authenticated-input-'+run); out=ops/('actual-gpu-'+run)
sha=lambda b:hashlib.sha256(b).hexdigest()
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
rootraw=(ops/('cpu-'+run)/'root-review.json').read_bytes()
assert sha(rootraw)=='c59d338346e20abf24a8405a1320e0d7975f5b4d8e20213174e08b7ad0d93269'
root=json.loads(rootraw)
assert digest(view/'manifest.json')==root['manifest_sha256']
m=json.loads((view/'manifest.json').read_bytes()); runtime=m['runtime_files']
assert len(runtime)==444
assert all(digest(repo/name)==value==digest(view/'blobs'/value) for name,value in runtime.items())
raw=(out/'actual-local-gpu-receipt.json').read_bytes()
assert sha(raw)=='8c5fa1866814f4cd6a60666470c7a75c5171142d943a669c4d824532e6a2ca82'
r=json.loads(raw); trx=gzip.decompress((out/'actual-local-gpu.trx.gz').read_bytes())
methods=json.loads((repo/'scripts/competitor-gpu-methods.json').read_bytes())
assert len(methods)==len(set(methods))==12
spec=importlib.util.spec_from_file_location('gpu_root_verify',repo/'scripts/verify-competitor-local-gpu.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
assert mod.source_fingerprint(repo)==root['source_fingerprint']
assert mod.verify_evidence(r,trx,methods,root['source_fingerprint'])==100
assert r['passed_cases']==100 and r['test_assembly_sha256']==root['competitor_test_dll_sha256']
origin=r['build_origin']
assert (origin['run_id'],origin['source'],origin['workflow_head'],origin['artifact_id'])==(run,source,root['producer'],root['artifact_id'])
assert all(digest(Path(p))==value for p,value in r['local_gpu_file_pins'].items())
assert sha(trx)==r['trx_sha256']
rows=ET.fromstring(trx).findall('.//{*}UnitTestResult')
assert len(rows)==100 and all(row.attrib['outcome']=='Passed' for row in rows)
assert (repo/'benchmarks/results/shared-rollout/local-gpu-contracts/receipt.json').read_bytes()==raw
assert gzip.decompress((repo/'benchmarks/results/shared-rollout/local-gpu-contracts/gpu.trx.gz').read_bytes())==trx
review=dict(status='root-independent-actual-gpu-authentication-passed',source=source,run_id=run,source_fingerprint=root['source_fingerprint'],passed_cases=100,methods=12,verified_installed_runtime_entries=444,receipt_sha256=sha(raw),trx_sha256=sha(trx),cpu_root_review_sha256=sha(rootraw),new_builds=0,new_measurements=0,qualified=False,closure_credit=0)
path=out/'root-review.json';assert not path.exists();path.write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(review,indent=2));print('root_review_sha256='+digest(path))
