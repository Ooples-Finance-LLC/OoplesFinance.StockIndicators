"""Independent root verification of one hosted CPU artifact; no build or ZIP disk copy."""
import hashlib, io, json, subprocess, sys, zipfile, xml.etree.ElementTree as ET
from pathlib import Path, PurePosixPath

assert sys.argv[1:] == ['44388147138']
RUN = '44388147138'
SOURCE = 'd9d00ca56ebb857b87ead45044616970b607019c'
PRODUCER = 'ce6d1a0373166c42583278e4d7efd38f65e0934d'
FINGERPRINT = 'c526951d5a65c7aeaa1cdcbcaaf56035cc96b241095704f6bf278513753935e3'
REMOTE = 'repos/Ooples-Finance-LLC/OoplesFinance.StockIndicators/'
OPS = Path(r'C:\Users\cheat\source\stock-indicators-operations\renko-normalized-grid-correctness-20261118')
CPU, VIEW = OPS / ('cpu-' + RUN), OPS / ('authenticated-input-' + RUN)
EXPECTED = {'unit': ['RenkoPriceGridTests', 'RenkoPriceNormalizationTests', 'RenkoCompactVolumeTests', 'RenkoNormalizedGridTests'],
            'parity': ['RenkoComparisonTests']}
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def api(path):
    return json.loads(subprocess.check_output(['gh', 'api', REMOTE + path]))
def file_hash(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()

assert not (CPU / 'root-review.json').exists()
collection_raw = (CPU / 'collection-receipt.json').read_bytes()
assert sha(collection_raw) == '16553edfa245b486b51f464372390ceab512b2f0d583ab74460e3d004fc9f9d9'
collection = json.loads(collection_raw)
run = api('actions/runs/' + RUN)
assert (str(run['id']), run['head_sha'], run['run_attempt'], run['event'], run['status'], run['conclusion']) == (RUN, PRODUCER, 1, 'workflow_dispatch', 'completed', 'success')
artifact = api('actions/artifacts/14467645201')
assert artifact['name'] == 'candidate-correctness-inputs' and not artifact['expired']
assert str(artifact['workflow_run']['id']) == RUN and artifact['workflow_run']['head_sha'] == PRODUCER
assert artifact['digest'] == 'sha256:07f1bab22ccdb4e7a3a7084a5706ca79f9c4839227485168a1d55df6d32b19a7'
retained_zip = Path(collection['artifact_zip_path'])
assert retained_zip.is_absolute()
raw_zip = retained_zip.read_bytes()
assert len(raw_zip) == artifact['size_in_bytes'] == 78399594 and sha(raw_zip) == artifact['digest'][7:]
with zipfile.ZipFile(io.BytesIO(raw_zip)) as archive:
    names = [entry.filename for entry in archive.infolist() if not entry.is_dir()]
    assert len(names) == len(set(name.casefold() for name in names)) == 320
    for name in names:
        relative = PurePosixPath(name)
        assert not relative.is_absolute() and '..' not in relative.parts and ':' not in name and '\\' not in name
    manifest_raw = archive.read('manifest.json')
    assert sha(manifest_raw) == '291f8660e56d5f056ad47881891e92742522704f5cac8f9016f11ba1a2c4c332'
    assert manifest_raw == (VIEW / 'manifest.json').read_bytes()
    manifest = json.loads(manifest_raw)
    assert manifest['source'] == SOURCE and manifest['source_sha256'] == FINGERPRINT
    assert manifest['run_id'] == RUN and manifest['workflow_head'] == PRODUCER and manifest['classes'] == EXPECTED
    runtime = manifest['runtime_files']
    blobs = set(runtime.values())
    assert len(runtime) == 444 and len(blobs) == 312
    assert set(names) == {'manifest.json'} | {'blobs/' + value for value in blobs} | set(manifest['evidence'])
    for value in blobs:
        assert sha(archive.read('blobs/' + value)) == value == file_hash(VIEW / 'blobs' / value)
    checks = {}
    for category, classes in EXPECTED.items():
        raw = archive.read('evidence/' + category + '.trx')
        assert raw == (VIEW / 'evidence' / (category + '.trx')).read_bytes()
        results = ET.fromstring(raw).findall('.//{*}UnitTestResult')
        assert results and all(row.attrib['outcome'] == 'Passed' for row in results)
        counts = {name: sum(name + '.' in row.attrib['testName'] for row in results) for name in classes}
        assert all(counts.values()) and sum(counts.values()) == len(results)
        checks[category] = {'passed': len(results), 'classes': counts, 'sha256': sha(raw)}
        assert checks[category] == manifest['checks'][category] == collection['checks'][category]
    for name, expected_hash in manifest['evidence'].items():
        assert sha(archive.read(name)) == expected_hash == file_hash(VIEW / name)
    for path, value in runtime.items():
        if path.endswith('.deps.json'):
            versions = [name for name in json.loads(archive.read('blobs/' + value))['libraries'] if name.startswith('AiDotNet.Tensors/')]
            assert versions == ['AiDotNet.Tensors/0.151.1']
    core_path = 'src/bin/Release/net10.0/OoplesFinance.StockIndicators.dll'
    bench = 'benchmarks/OoplesFinance.StockIndicators.CompetitorBenchmarks/bin/Release/net10.0/'
    test = 'benchmarks/OoplesFinance.StockIndicators.CompetitorTests/bin/Release/net10.0/'
    core = runtime[core_path]
    assert core == collection['production_core_sha256'] == 'ebc789ea23a9145d85705d53ce35fedb707e803c6c80cadfeafc431dbec1a3d7'
    assert checks['unit']['passed'] == 55 and checks['parity']['passed'] == 8
    review = dict(status='root-independent-cpu-authentication-passed', run_id=RUN, source=SOURCE, producer=PRODUCER,
                  source_fingerprint=FINGERPRINT, artifact_id=artifact['id'], zip_sha256=artifact['digest'][7:],
                  zip_verified_in_memory=True, retained_zip_bytes=len(raw_zip), manifest_sha256=sha(manifest_raw), core_sha256=core,
                  actual_harness_sha256=runtime[bench + 'OoplesFinance.StockIndicators.CompetitorBenchmarks.dll'],
                  competitor_test_dll_sha256=runtime[test + 'OoplesFinance.StockIndicators.CompetitorTests.dll'],
                  collection_receipt_sha256=sha(collection_raw), unit=55, parity=8, checks=checks,
                  verified_zip_files=len(names), verified_runtime_entries=len(runtime), verified_unique_blobs=len(blobs),
                  gpu_executed=False, qualification=False, accepted_native_wins=0)
(CPU / 'root-review.json').write_text(json.dumps(review, indent=2) + '\n', encoding='utf-8')
print(json.dumps(review, indent=2))
print('root_review_sha256=' + file_hash(CPU / 'root-review.json'))
