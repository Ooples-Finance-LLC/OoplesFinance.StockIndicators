"""Stage only: consume a pinned supplemental acceptance without changing frozen evidence."""
import argparse,copy,hashlib,json,os,re,subprocess,sys
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--actual-live',type=Path,required=True);ap.add_argument('--actual-live-sha256',required=True);ap.add_argument('--base-report',type=Path,required=True);ap.add_argument('--base-report-sha256',required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
OPS=Path(r'C:\Users\cheat\source\stock-indicators-operations')
TOOL=Path(r'C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-renko-normalized-grid-qualification-20261118')
PUB=Path(r'C:\Users\cheat\source\repos\Ooples-Finance-LLC\si-renko-normalized-grid-publisher-20261118')
E=OPS/'renko-normalized-grid-qualification-20261118/local-evidence/renko-normalized-grid-qualification-44396431211'
SOURCE='d9d00ca56ebb857b87ead45044616970b607019c';HEAD='815df1c14e783bb0b3ab4ffe79aaf8fe22d76120'
PLAN=TOOL/'benchmarks/plans/hosted-renko-normalized-grid-qualification-20261118.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_bytes())
assert not a.out.exists() and sha(a.actual_live)==a.actual_live_sha256
assert sha(a.base_report)==a.base_report_sha256=='dac6b48a308c3c98b56599dbbe60afd2b0ba11332231e00acb770caf4c33c651'
assert a.actual_live.resolve()!=a.base_report.resolve()
assert sha(E/'authenticated-summary.json')=='500c9e3b4ed77498f30caf33700e081ec54cf0d71f5bb6945d26413063db5723'
assert sha(PLAN)=='ffdf5df12c0085d8573c27e2b2db768cc76fc6b1e27d6eeb61a2ee7f51137013'
assert sha(OPS/'native-win-rule-user-approved-20261118.json')=='414b558eae1deda750c3d169020128986a0e0db9b2acd95f23da035be03bfd7c'
root=OPS/'renko-normalized-grid-statistical-win-root-supplement-20261118.json'
assert sha(root)=='e8de5b1a593ac6d811a358cf815b974c857170df366c295c36ef311936750511'
supp=load(root);assert supp['supplemental_qualification_accepted'] and not supp['original_accepted'] and supp['qualified_native_wins']==1
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=TOOL,text=True).strip()==HEAD
subprocess.run(['git','diff','--exit-code',SOURCE,'--','src','tests'],cwd=PUB,check=True)
os.environ['HOSTED_TIMING_PLAN']=str(PLAN);sys.path[:0]=[str(TOOL/'scripts'),str(PUB/'benchmarks')]
from hosted_timing import report
original_collect=report.collect
original=load(E/'authenticated-summary.json')
assert original['accepted'] is False and original['source_gate_accepted'] and original['verdicts']=={'inconclusive':2,'faster':6}
def supplemented_collect(raw,phase):
    assert Path(raw).resolve()==(E/'raw/evidence').resolve() and phase=='targeted'
    actual=original_collect(raw,phase);assert actual==original
    # This report view is separately accepted by the explicit supplemental rule.
    # Neither original result nor original native gate is rewritten or persisted.
    view=copy.deepcopy(actual);view['original_accepted']=actual['accepted'];view['accepted']=True
    view['supplemental_acceptance']=dict(receipt_sha256=sha(root),policy_sha256=supp['policy_sha256'])
    return view
report.collect=supplemented_collect
try:candidate=report.stage(a.base_report,E/'raw/evidence',PUB,a.out,phase='targeted')
finally:report.collect=original_collect
assert sha(E/'authenticated-summary.json')=='500c9e3b4ed77498f30caf33700e081ec54cf0d71f5bb6945d26413063db5723'
def embedded(path,name):return json.loads(re.search(r'<script[^>]*id="'+name+r'"[^>]*>(.*?)</script>',path.read_text(encoding='utf-8'),re.S)[1])
before={(r['pair'],r['bars']):r for r in embedded(a.base_report,'dataset')['rows']};after={(r['pair'],r['bars']):r for r in embedded(candidate,'dataset')['rows']}
keys={(p,n) for p in ('Skender.GetRenko','Skender.GetRenkoAtr') for n in (1000,10000)}
assert before.keys()==after.keys() and {k for k in before if before[k]!=after[k]}==keys
assert embedded(a.base_report,'current-competitor-data')==embedded(candidate,'current-competitor-data')
staged=load(a.out/'staged.json');assert staged['changed_snapshot_rows']==4
assert sha(a.actual_live)==a.actual_live_sha256 and sha(a.base_report)==a.base_report_sha256
live_rows={(r['pair'],r['bars']):r for r in embedded(a.actual_live,'dataset')['rows']}
prior_changes={k for k in before if before[k]!=live_rows[k]}
assert all(after[k]==before[k] for k in prior_changes-keys)
def other_snapshots(path):
    return [dict(receipt,rows=[r for r in receipt['rows'] if (r['pair'],r['bars']) not in keys]) for receipt in embedded(path,'dataset')['evidence'].get('snapshotMeasurements',[]) if any((r['pair'],r['bars']) not in keys for r in receipt['rows'])]
assert other_snapshots(a.base_report)==other_snapshots(candidate)
receipt=dict(status='staged-only-awaiting-root-review-and-browser-visual-check',original_summary_accepted=False,supplemental_qualification_accepted=True,supplemental_receipt_sha256=sha(root),base_report=str(a.base_report),base_report_sha256=a.base_report_sha256,actual_live_before=str(a.actual_live),actual_live_before_sha256=a.actual_live_sha256,prior_staged_baseline_changes_preserved=len(prior_changes-keys),candidate_sha256=sha(candidate),changed_baseline_rows=4,changed_builder_slots=0,expected_snapshot_rows=4,live_imported=False,published_closure_credit=0)
(a.out/'supplemental-report-admission.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
