// Execute exact candidate render function with a minimal DOM; never browser QA.
const fs=require('fs'),vm=require('vm'),assert=require('assert'),crypto=require('crypto');
const [htmlPath,outPath]=process.argv.slice(2),text=fs.readFileSync(htmlPath,'utf8');
const D=JSON.parse(text.match(/<script[^>]*id="dataset"[^>]*>([\s\S]*?)<\/script>/)[1]);
assert.equal(D.rows.length,802);
const start=text.lastIndexOf('<script>',text.indexOf('function render()'))+8;
const prefix=text.slice(start,text.indexOf('function overview()',start));
const render=text.slice(text.indexOf('function render()'),text.indexOf('function detail(',text.indexOf('function render()')));
const nodes={dataset:{textContent:JSON.stringify(D)}};
for(const id of ['query','library','size','kind','direction','sort','resultcount','rows','pageinfo','prev','next'])nodes[id]={value:id==='query'?'':id==='sort'?'pair':'all'};
const context={document:{getElementById(id){assert(nodes[id],id);return nodes[id];}}};vm.createContext(context);
vm.runInContext(prefix+render,context,{timeout:2000});
const keys=new Set();let rendered=0;
for(let i=0;i<Math.ceil(D.rows.length/30);i++){
 vm.runInContext(`page=${i};render();`,context,{timeout:2000});
 const rows=[...nodes.rows.innerHTML.matchAll(/<tr>([\s\S]*?)<\/tr>/g)];
 const data=vm.runInContext('filtered.slice(page*pageSize,(page+1)*pageSize)',context);
 assert.equal(rows.length,data.length);
 for(let j=0;j<rows.length;j++){
  const cells=[...rows[j][1].matchAll(/<td>([\s\S]*?)<\/td>/g)].map(x=>x[1]);assert.equal(cells.length,7);
  const row=data[j],pair=cells[0].match(/data-pair="([^"]+)"/)[1],key=pair+'|'+row.bars;
  assert.equal(pair,row.pair);assert.equal(cells[1],Number(row.bars).toLocaleString('en-US',{maximumFractionDigits:2}));
  assert(!keys.has(key));keys.add(key);
  // Use the candidate's unchanged display helpers, separately from its row map.
  for(const [cell,field,formatter] of [[2,'ooples_mean_ns','time'],[3,'competitor_mean_ns','time'],[5,'ooples_allocated_bytes','bytes'],[6,'competitor_allocated_bytes','bytes']]){
   context.checkValue=row[field];assert.equal(cells[cell],vm.runInContext(`${formatter}(checkValue)`,context));
  }
  context.checkValue=row.competitor_over_ooples;assert(cells[4].includes(vm.runInContext('ratio(checkValue)',context)));
  rendered++;
 }
}
assert.equal(rendered,802);assert.equal(keys.size,802);
const result={kind:'cli-exact-render-function-with-minimal-dom',candidate_sha256:crypto.createHash('sha256').update(fs.readFileSync(htmlPath)).digest('hex'),rendered_rows_verified:rendered,pages_verified:Math.ceil(rendered/30),dataset_rows:802,actual_browser_or_layout_verified:false};
fs.writeFileSync(outPath,JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result));
