```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method   | Count | Operation           | Mean       | Error    | StdDev   | Allocated |
|--------- |------ |-------------------- |-----------:|---------:|---------:|----------:|
| **Snapshot** | **1000**  | **Skender.GetRenkoAtr** |   **104.6 μs** |  **1.21 μs** |  **0.72 μs** |    **4.9 KB** |
| **Snapshot** | **10000** | **Skender.GetRenkoAtr** | **1,047.2 μs** | **38.92 μs** | **25.74 μs** |  **34.72 KB** |
