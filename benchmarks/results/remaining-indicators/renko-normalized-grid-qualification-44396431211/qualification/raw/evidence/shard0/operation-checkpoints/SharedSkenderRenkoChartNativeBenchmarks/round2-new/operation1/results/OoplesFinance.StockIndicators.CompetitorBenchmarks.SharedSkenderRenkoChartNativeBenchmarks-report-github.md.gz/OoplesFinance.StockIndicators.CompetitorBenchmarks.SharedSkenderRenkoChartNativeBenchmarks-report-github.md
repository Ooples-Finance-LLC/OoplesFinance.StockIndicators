```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method         | Count | Operation           | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|--------------- |------ |-------------------- |------------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **Snapshot**       | **1000**  | **Skender.GetRenkoAtr** |   **151.17 μs** | **77.514 μs** | **51.271 μs** |  **1.87** |    **0.60** |        **-** |       **-** |     **4.9 KB** |        **0.02** |
| NativeSingle   | 1000  | Skender.GetRenkoAtr |    80.96 μs |  0.795 μs |  0.526 μs |  1.00 |    0.01 |  11.7188 |  1.9531 |  208.66 KB |        1.00 |
| NativeParallel | 1000  | Skender.GetRenkoAtr |   154.26 μs |  7.049 μs |  4.662 μs |  1.91 |    0.06 |  16.6016 |  2.9297 |  270.48 KB |        1.30 |
|                |       |                     |             |           |           |       |         |          |         |            |             |
| **Snapshot**       | **10000** | **Skender.GetRenkoAtr** | **1,053.29 μs** | **30.020 μs** | **15.701 μs** |  **1.12** |    **0.02** |        **-** |       **-** |   **34.69 KB** |        **0.02** |
| NativeSingle   | 10000 | Skender.GetRenkoAtr |   936.68 μs | 15.622 μs | 10.333 μs |  1.00 |    0.01 | 125.0000 | 62.5000 | 2078.48 KB |        1.00 |
| NativeParallel | 10000 | Skender.GetRenkoAtr | 1,295.46 μs | 77.131 μs | 45.900 μs |  1.38 |    0.05 | 164.0625 | 85.9375 |  2686.3 KB |        1.29 |
