```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId              | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetRenkoAtr** |   **178.09 μs** |  **2.693 μs** |  **1.603 μs** |  **1.00** |    **0.01** |   **10.44 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetRenkoAtr |    90.50 μs |  4.215 μs |  2.508 μs |  0.51 |    0.01 |  223.09 KB |       21.37 |
|            |       |                     |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetRenkoAtr** | **1,041.28 μs** | **19.629 μs** | **12.983 μs** |  **1.00** |    **0.02** |   **65.23 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetRenkoAtr |   939.42 μs | 23.073 μs | 13.730 μs |  0.90 |    0.02 | 2142.95 KB |       32.85 |
