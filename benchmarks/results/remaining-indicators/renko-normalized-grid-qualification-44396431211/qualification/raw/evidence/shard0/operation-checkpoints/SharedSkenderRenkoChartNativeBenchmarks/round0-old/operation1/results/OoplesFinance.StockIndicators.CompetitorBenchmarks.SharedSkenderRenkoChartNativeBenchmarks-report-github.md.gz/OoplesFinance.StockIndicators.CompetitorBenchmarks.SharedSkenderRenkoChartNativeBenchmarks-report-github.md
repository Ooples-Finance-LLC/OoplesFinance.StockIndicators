```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method   | Count | Operation           | Mean       | Error    | StdDev   | Gen0    | Allocated |
|--------- |------ |-------------------- |-----------:|---------:|---------:|--------:|----------:|
| **Snapshot** | **1000**  | **Skender.GetRenkoAtr** |   **132.4 μs** |  **5.47 μs** |  **3.62 μs** |  **3.9063** |  **86.43 KB** |
| **Snapshot** | **10000** | **Skender.GetRenkoAtr** | **1,333.9 μs** | **33.50 μs** | **22.16 μs** | **46.8750** | **857.57 KB** |
