```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method         | Count | Operation        | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|--------------- |------ |----------------- |----------:|----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **Snapshot**       | **1000**  | **Skender.GetRenko** |  **45.80 μs** |  **1.098 μs** |  **0.654 μs** |  **1.02** |    **0.01** |       **-** |       **-** |   **12.74 KB** |        **0.25** |
| NativeSingle   | 1000  | Skender.GetRenko |  44.79 μs |  0.356 μs |  0.186 μs |  1.00 |    0.01 |  1.9531 |       - |   51.41 KB |        1.00 |
| NativeParallel | 1000  | Skender.GetRenko | 117.16 μs |  8.422 μs |  5.570 μs |  2.62 |    0.12 |  8.7891 |  0.9766 |  130.01 KB |        2.53 |
|                |       |                  |           |           |           |       |         |         |         |            |             |
| **Snapshot**       | **10000** | **Skender.GetRenko** | **501.22 μs** |  **5.079 μs** |  **2.657 μs** |  **0.98** |    **0.01** |  **3.9063** |       **-** |  **116.66 KB** |        **0.23** |
| NativeSingle   | 10000 | Skender.GetRenko | 513.89 μs |  6.617 μs |  3.461 μs |  1.00 |    0.01 | 31.2500 |  7.8125 |  513.29 KB |        1.00 |
| NativeParallel | 10000 | Skender.GetRenko | 844.07 μs | 70.386 μs | 41.886 μs |  1.64 |    0.08 | 78.1250 | 31.2500 | 1309.58 KB |        2.55 |
