```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V45 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.15 (10.0.15, 10.0.1526.53008), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId           | Mean     | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |----------------- |---------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetRenko** | **262.1 μs** | **10.09 μs** |  **6.00 μs** |  **1.00** |    **0.03** |  **24.59 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetRenko | 102.9 μs |  6.22 μs |  3.70 μs |  0.39 |    0.02 |  79.63 KB |        3.24 |
|            |       |                  |          |          |          |       |         |           |             |
| **Ooples**     | **10000** | **Skender.GetRenko** | **557.5 μs** | **21.26 μs** | **14.06 μs** |  **1.00** |    **0.03** | **211.59 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetRenko | 607.7 μs | 14.08 μs |  9.32 μs |  1.09 |    0.03 | 725.84 KB |        3.43 |
