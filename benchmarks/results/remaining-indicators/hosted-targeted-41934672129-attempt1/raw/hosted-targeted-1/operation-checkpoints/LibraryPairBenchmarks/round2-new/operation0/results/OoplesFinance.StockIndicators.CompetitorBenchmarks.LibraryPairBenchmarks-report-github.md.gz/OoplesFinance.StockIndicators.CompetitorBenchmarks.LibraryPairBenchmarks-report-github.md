```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId             | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Realized** | **1,012.5 μs** | **48.78 μs** | **32.27 μs** |  **1.00** |    **0.04** |  **106.78 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Realized |   126.3 μs |  0.64 μs |  0.34 μs |  0.12 |    0.00 |   72.72 KB |        0.68 |
|            |       |                    |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Realized** | **9,687.4 μs** | **36.96 μs** | **21.99 μs** |  **1.00** |    **0.00** | **1037.79 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Realized | 1,254.4 μs | 14.79 μs |  7.74 μs |  0.13 |    0.00 |  644.34 KB |        0.62 |
