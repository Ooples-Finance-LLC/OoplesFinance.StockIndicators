```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean         | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated  | Alloc Ratio |
|------------------ |------------------- |------ |-------------:|-----------:|----------:|------:|--------:|--------:|-------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Realized** | **1000**  |  **2,912.77 μs** |  **25.327 μs** | **15.072 μs** | **36.52** |    **0.55** |       **-** |      **-** |   **66.03 KB** |        **1.39** |
| BuilderLatestOnly | QuanTAlib.Realized | 1000  |  1,198.76 μs |  18.567 μs | 12.281 μs | 15.03 |    0.26 |       - |      - |   18.32 KB |        0.39 |
| NativeSingle      | QuanTAlib.Realized | 1000  |     79.77 μs |   1.825 μs |  1.207 μs |  1.00 |    0.02 |  2.4414 |      - |   47.47 KB |        1.00 |
| NativeParallel    | QuanTAlib.Realized | 1000  |    145.75 μs |  11.071 μs |  7.323 μs |  1.83 |    0.09 |  5.8594 |      - |  107.95 KB |        2.27 |
|                   |                    |       |              |            |           |       |         |         |        |            |             |
| **BuilderFull**       | **QuanTAlib.Realized** | **10000** | **11,940.60 μs** | **112.815 μs** | **67.135 μs** | **15.04** |    **0.10** |       **-** |      **-** |  **629.53 KB** |        **1.34** |
| BuilderLatestOnly | QuanTAlib.Realized | 10000 | 11,795.96 μs |  63.135 μs | 37.571 μs | 14.86 |    0.07 |       - |      - |   159.9 KB |        0.34 |
| NativeSingle      | QuanTAlib.Realized | 10000 |    793.86 μs |   4.952 μs |  2.947 μs |  1.00 |    0.00 | 23.4375 |      - |  469.41 KB |        1.00 |
| NativeParallel    | QuanTAlib.Realized | 10000 |  1,139.36 μs | 155.627 μs | 92.611 μs |  1.44 |    0.11 | 62.5000 | 7.8125 | 1057.23 KB |        2.25 |
