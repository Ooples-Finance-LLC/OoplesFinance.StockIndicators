```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **QuanTAlib.Realized** | **1000**  |  **3.147 ms** | **0.0390 ms** | **0.0232 ms** |  **66.03 KB** |
| BuilderLatestOnly | QuanTAlib.Realized | 1000  |  1.255 ms | 0.0298 ms | 0.0156 ms |  18.32 KB |
| **BuilderFull**       | **QuanTAlib.Realized** | **10000** | **12.408 ms** | **0.0777 ms** | **0.0463 ms** | **629.64 KB** |
| BuilderLatestOnly | QuanTAlib.Realized | 10000 | 12.346 ms | 0.0358 ms | 0.0213 ms | 159.79 KB |
