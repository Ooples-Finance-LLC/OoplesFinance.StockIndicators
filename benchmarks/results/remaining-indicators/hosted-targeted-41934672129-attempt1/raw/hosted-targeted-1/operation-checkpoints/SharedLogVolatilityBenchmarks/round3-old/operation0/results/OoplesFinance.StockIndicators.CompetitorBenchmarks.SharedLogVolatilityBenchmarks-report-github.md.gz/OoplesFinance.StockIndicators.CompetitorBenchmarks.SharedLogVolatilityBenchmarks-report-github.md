```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **QuanTAlib.Realized** | **1000**  |  **4.473 ms** | **2.4252 ms** | **1.6041 ms** |  **66.07 KB** |
| BuilderLatestOnly | QuanTAlib.Realized | 1000  |  1.428 ms | 0.0095 ms | 0.0056 ms |  18.32 KB |
| **BuilderFull**       | **QuanTAlib.Realized** | **10000** | **14.239 ms** | **0.0711 ms** | **0.0423 ms** | **629.75 KB** |
| BuilderLatestOnly | QuanTAlib.Realized | 10000 | 14.048 ms | 0.0914 ms | 0.0604 ms | 159.91 KB |
