```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Historical** | **1000**  |  **3,313.2 μs** |  **63.39 μs** |  **41.93 μs** |  **6.89** |    **0.09** |        **-** |       **-** |   **66.07 KB** |        **0.16** |
| BuilderLatestOnly | QuanTAlib.Historical | 1000  |  1,501.4 μs |  32.04 μs |  19.07 μs |  3.12 |    0.04 |        - |       - |   18.31 KB |        0.04 |
| NativeSingle      | QuanTAlib.Historical | 1000  |    480.9 μs |   4.31 μs |   2.56 μs |  1.00 |    0.01 |  23.4375 |       - |  414.08 KB |        1.00 |
| NativeParallel    | QuanTAlib.Historical | 1000  |    278.7 μs |  17.03 μs |  10.13 μs |  0.58 |    0.02 |  25.3906 |       - |  418.64 KB |        1.01 |
|                   |                      |       |             |           |           |       |         |          |         |            |             |
| **BuilderFull**       | **QuanTAlib.Historical** | **10000** | **15,177.7 μs** | **115.87 μs** |  **68.95 μs** |  **3.06** |    **0.02** |        **-** |       **-** |  **629.86 KB** |        **0.15** |
| BuilderLatestOnly | QuanTAlib.Historical | 10000 | 14,902.8 μs |  48.68 μs |  32.20 μs |  3.01 |    0.02 |        - |       - |  160.05 KB |        0.04 |
| NativeSingle      | QuanTAlib.Historical | 10000 |  4,956.4 μs |  54.48 μs |  32.42 μs |  1.00 |    0.01 | 250.0000 | 31.2500 | 4200.61 KB |        1.00 |
| NativeParallel    | QuanTAlib.Historical | 10000 |  2,736.0 μs | 151.35 μs | 100.11 μs |  0.55 |    0.02 | 250.0000 | 46.8750 | 4205.43 KB |        1.00 |
