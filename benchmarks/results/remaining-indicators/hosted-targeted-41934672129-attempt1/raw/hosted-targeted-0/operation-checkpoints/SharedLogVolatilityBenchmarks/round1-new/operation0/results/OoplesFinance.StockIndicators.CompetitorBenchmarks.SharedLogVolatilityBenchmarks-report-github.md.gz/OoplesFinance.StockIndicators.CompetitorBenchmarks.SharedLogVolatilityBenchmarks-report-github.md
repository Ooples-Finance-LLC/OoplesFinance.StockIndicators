```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **QuanTAlib.Historical** | **1000**  |  **2.727 ms** | **0.0506 ms** | **0.0301 ms** |  **66.07 KB** |
| BuilderLatestOnly | QuanTAlib.Historical | 1000  |  1.501 ms | 0.0371 ms | 0.0221 ms |  18.32 KB |
| **BuilderFull**       | **QuanTAlib.Historical** | **10000** | **14.942 ms** | **0.1111 ms** | **0.0661 ms** | **629.86 KB** |
| BuilderLatestOnly | QuanTAlib.Historical | 10000 | 14.781 ms | 0.2142 ms | 0.1120 ms | 160.09 KB |
