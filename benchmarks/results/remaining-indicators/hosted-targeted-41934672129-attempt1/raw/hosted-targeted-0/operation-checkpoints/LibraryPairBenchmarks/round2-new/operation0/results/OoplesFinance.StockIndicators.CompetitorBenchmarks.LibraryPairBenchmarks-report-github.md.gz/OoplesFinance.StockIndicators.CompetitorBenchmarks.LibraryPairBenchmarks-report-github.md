```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=1000  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Historical** |  **1,277.5 μs** |  **46.31 μs** |  **30.63 μs** |  **1.00** |    **0.03** |  **106.81 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Historical |    590.4 μs |  23.84 μs |  15.77 μs |  0.46 |    0.02 |   439.3 KB |        4.11 |
|            |       |                      |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Historical** | **12,297.2 μs** | **250.92 μs** | **165.97 μs** |  **1.00** |    **0.02** | **1037.87 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Historical |  5,990.8 μs |  63.56 μs |  33.24 μs |  0.49 |    0.01 | 4375.09 KB |        4.22 |
