```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|------:|--------:|----------:|----------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Accum(...)nLine [28]** | **1000**  |   **159.1 μs** |   **6.81 μs** |   **4.50 μs** |  **0.28** |    **0.01** |    **3.9063** |         **-** |        **-** |  **153.97 KB** |        **0.26** |
| BuilderLatestOnly | Accum(...)nLine [28] | 1000  |   149.7 μs |   0.84 μs |   0.44 μs |  0.26 |    0.00 |    3.9063 |         - |        - |  106.36 KB |        0.18 |
| NativeSingle      | Accum(...)nLine [28] | 1000  |   570.4 μs |   5.91 μs |   3.91 μs |  1.00 |    0.01 |   23.4375 |    7.8125 |        - |  594.33 KB |        1.00 |
| NativeParallel    | Accum(...)nLine [28] | 1000  |   517.4 μs |  47.98 μs |  31.73 μs |  0.91 |    0.05 |   35.1563 |   11.7188 |        - |  894.29 KB |        1.50 |
|                   |                      |       |            |           |           |       |         |           |           |          |            |             |
| **BuilderFull**       | **Accum(...)nLine [28]** | **10000** | **1,913.5 μs** |  **22.63 μs** |  **11.83 μs** |  **0.26** |    **0.02** |   **78.1250** |   **31.2500** |        **-** |  **1931.5 KB** |        **0.33** |
| BuilderLatestOnly | Accum(...)nLine [28] | 10000 | 1,846.9 μs |  24.31 μs |  12.72 μs |  0.25 |    0.02 |   46.8750 |   15.6250 |        - | 1461.68 KB |        0.25 |
| NativeSingle      | Accum(...)nLine [28] | 10000 | 7,325.7 μs | 984.78 μs | 651.37 μs |  1.01 |    0.12 |  533.3333 |  400.0000 | 400.0000 | 5824.09 KB |        1.00 |
| NativeParallel    | Accum(...)nLine [28] | 10000 | 7,083.0 μs | 497.82 μs | 329.28 μs |  0.97 |    0.09 | 1071.4286 | 1000.0000 | 928.5714 | 8718.69 KB |        1.50 |
