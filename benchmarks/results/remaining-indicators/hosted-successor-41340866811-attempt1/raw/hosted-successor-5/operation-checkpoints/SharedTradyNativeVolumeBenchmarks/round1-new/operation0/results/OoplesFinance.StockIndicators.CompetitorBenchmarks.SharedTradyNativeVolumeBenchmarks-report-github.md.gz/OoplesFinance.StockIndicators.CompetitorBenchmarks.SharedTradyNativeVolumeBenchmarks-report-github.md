```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Median     | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|-----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Accum(...)nLine [28]** | **1000**  |   **318.8 μs** | **335.29 μs** | **221.78 μs** |   **161.0 μs** |       **-** |       **-** |  **153.97 KB** |
| BuilderLatestOnly | Accum(...)nLine [28] | 1000  |   149.2 μs |   1.41 μs |   0.74 μs |   149.0 μs |  3.9063 |       - |  106.36 KB |
| **BuilderFull**       | **Accum(...)nLine [28]** | **10000** | **2,005.5 μs** |  **24.16 μs** |  **14.38 μs** | **1,999.7 μs** | **78.1250** | **31.2500** |  **1931.5 KB** |
| BuilderLatestOnly | Accum(...)nLine [28] | 10000 | 1,834.5 μs |  24.09 μs |  14.34 μs | 1,834.2 μs | 46.8750 | 15.6250 | 1461.66 KB |
