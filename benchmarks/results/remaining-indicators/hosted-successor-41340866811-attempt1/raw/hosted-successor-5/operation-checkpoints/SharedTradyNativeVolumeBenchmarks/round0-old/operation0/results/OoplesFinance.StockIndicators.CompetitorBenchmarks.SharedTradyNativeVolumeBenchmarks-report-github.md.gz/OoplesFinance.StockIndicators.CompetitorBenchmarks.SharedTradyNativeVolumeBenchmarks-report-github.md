```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Accum(...)nLine [28]** | **1000**  |   **161.8 μs** | **11.83 μs** |  **7.83 μs** |  **3.9063** |       **-** |  **153.97 KB** |
| BuilderLatestOnly | Accum(...)nLine [28] | 1000  |   151.4 μs |  1.83 μs |  1.09 μs |  3.9063 |       - |  106.36 KB |
| **BuilderFull**       | **Accum(...)nLine [28]** | **10000** | **1,933.0 μs** | **22.43 μs** | **14.84 μs** | **78.1250** | **31.2500** |  **1931.5 KB** |
| BuilderLatestOnly | Accum(...)nLine [28] | 10000 | 1,881.4 μs | 15.01 μs |  7.85 μs | 46.8750 | 15.6250 | 1461.69 KB |
