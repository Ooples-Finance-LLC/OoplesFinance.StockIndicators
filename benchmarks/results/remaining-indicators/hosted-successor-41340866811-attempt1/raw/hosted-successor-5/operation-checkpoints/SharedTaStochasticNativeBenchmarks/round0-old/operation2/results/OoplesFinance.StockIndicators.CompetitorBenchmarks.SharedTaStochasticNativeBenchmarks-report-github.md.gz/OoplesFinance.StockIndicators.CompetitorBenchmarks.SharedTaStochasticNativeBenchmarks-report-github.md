```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|-----------:|
| **BuilderFull**       | **TaLib(...)chRsi [24]** | **1000**  |   **467.9 μs** |  **8.61 μs** |  **5.12 μs** |       **-** |       **-** |  **182.03 KB** |
| BuilderLatestOnly | TaLib(...)chRsi [24] | 1000  |   460.6 μs |  4.73 μs |  2.48 μs |  3.9063 |       - |  134.44 KB |
| **BuilderFull**       | **TaLib(...)chRsi [24]** | **10000** | **4,985.7 μs** | **63.18 μs** | **37.60 μs** | **62.5000** | **31.2500** | **1799.86 KB** |
| BuilderLatestOnly | TaLib(...)chRsi [24] | 10000 | 4,878.2 μs | 45.96 μs | 24.04 μs | 31.2500 |       - | 1330.02 KB |
