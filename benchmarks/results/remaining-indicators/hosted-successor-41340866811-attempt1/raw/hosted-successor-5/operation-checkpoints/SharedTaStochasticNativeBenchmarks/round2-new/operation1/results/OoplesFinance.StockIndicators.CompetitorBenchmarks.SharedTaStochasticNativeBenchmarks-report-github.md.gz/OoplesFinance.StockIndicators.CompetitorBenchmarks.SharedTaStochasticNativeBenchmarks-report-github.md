```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)tochF [22]** | **1000**  |   **706.52 μs** | **267.637 μs** | **177.025 μs** | **70.30** |   **16.81** |  **15.6250** |       **-** |  **392.15 KB** |       **16.55** |
| BuilderLatestOnly | TaLib(...)tochF [22] | 1000  |   426.17 μs |  67.892 μs |  44.907 μs | 42.41 |    4.27 |  11.7188 |       - |  344.55 KB |       14.54 |
| NativeSingle      | TaLib(...)tochF [22] | 1000  |    10.05 μs |   0.107 μs |   0.064 μs |  1.00 |    0.01 |   0.9155 |       - |    23.7 KB |        1.00 |
| NativeParallel    | TaLib(...)tochF [22] | 1000  |    22.62 μs |   1.371 μs |   0.907 μs |  2.25 |    0.09 |   3.4180 |  0.3662 |   75.77 KB |        3.20 |
|                   |                      |       |             |            |            |       |         |          |         |            |             |
| **BuilderFull**       | **TaLib(...)tochF [22]** | **10000** | **3,719.49 μs** | **565.210 μs** | **373.852 μs** | **23.12** |    **2.22** | **156.2500** | **62.5000** | **3838.09 KB** |       **16.36** |
| BuilderLatestOnly | TaLib(...)tochF [22] | 10000 | 3,512.41 μs | 398.617 μs | 237.211 μs | 21.83 |    1.40 | 125.0000 | 31.2500 | 3368.33 KB |       14.36 |
| NativeSingle      | TaLib(...)tochF [22] | 10000 |   160.91 μs |   1.651 μs |   0.864 μs |  1.00 |    0.01 |   8.7891 |  1.9531 |  234.64 KB |        1.00 |
| NativeParallel    | TaLib(...)tochF [22] | 10000 |   246.94 μs |  17.707 μs |  10.537 μs |  1.53 |    0.06 |  31.2500 | 15.6250 |  743.76 KB |        3.17 |
