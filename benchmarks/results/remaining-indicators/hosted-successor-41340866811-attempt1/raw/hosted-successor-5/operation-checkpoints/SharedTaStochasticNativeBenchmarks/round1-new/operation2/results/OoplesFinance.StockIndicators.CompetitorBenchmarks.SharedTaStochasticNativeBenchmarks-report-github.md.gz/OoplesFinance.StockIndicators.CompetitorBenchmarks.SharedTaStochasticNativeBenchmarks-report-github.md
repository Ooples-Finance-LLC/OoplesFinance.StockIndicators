```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|-----------:|
| **BuilderFull**       | **TaLib(...)chRsi [24]** | **1000**  |   **492.4 μs** | **21.11 μs** | **12.56 μs** |       **-** |       **-** |  **182.03 KB** |
| BuilderLatestOnly | TaLib(...)chRsi [24] | 1000  |   475.3 μs |  3.88 μs |  2.57 μs |  3.9063 |       - |  134.44 KB |
| **BuilderFull**       | **TaLib(...)chRsi [24]** | **10000** | **5,059.1 μs** | **24.62 μs** | **14.65 μs** | **62.5000** | **31.2500** | **1799.84 KB** |
| BuilderLatestOnly | TaLib(...)chRsi [24] | 10000 | 4,975.8 μs | 74.00 μs | 38.70 μs | 31.2500 |       - | 1329.97 KB |
