```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **1000**  |   **580.38 μs** | **160.762 μs** | **106.334 μs** | **46.06** |    **8.05** |  **15.6250** |        **-** |  **645.93 KB** |       **27.22** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 1000  |   506.75 μs |  79.115 μs |  52.330 μs | 40.22 |    3.97 |  23.4375 |        - |  598.34 KB |       25.22 |
| NativeSingle      | TaLib(...)Stoch [21] | 1000  |    12.60 μs |   0.106 μs |   0.063 μs |  1.00 |    0.01 |   0.8545 |        - |   23.73 KB |        1.00 |
| NativeParallel    | TaLib(...)Stoch [21] | 1000  |    25.97 μs |   0.979 μs |   0.583 μs |  2.06 |    0.04 |   3.4180 |   0.2441 |   75.96 KB |        3.20 |
|                   |                      |       |             |            |            |       |         |          |          |            |             |
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **10000** | **5,070.77 μs** | **587.952 μs** | **349.881 μs** | **27.62** |    **1.82** | **250.0000** | **125.0000** | **6341.92 KB** |       **27.02** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 10000 | 4,892.94 μs | 419.104 μs | 249.402 μs | 26.65 |    1.30 | 218.7500 |  62.5000 |  5872.2 KB |       25.02 |
| NativeSingle      | TaLib(...)Stoch [21] | 10000 |   183.58 μs |   1.901 μs |   1.257 μs |  1.00 |    0.01 |   8.7891 |   1.9531 |  234.67 KB |        1.00 |
| NativeParallel    | TaLib(...)Stoch [21] | 10000 |   283.30 μs |  19.987 μs |  13.220 μs |  1.54 |    0.07 |  31.2500 |  11.7188 |  743.95 KB |        3.17 |
