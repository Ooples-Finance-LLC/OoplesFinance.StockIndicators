```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)chRsi [24]** | **1000**  |   **501.18 μs** | **31.320 μs** | **18.638 μs** | **24.34** |    **0.89** |       **-** |       **-** |  **182.03 KB** |        **5.84** |
| BuilderLatestOnly | TaLib(...)chRsi [24] | 1000  |   481.26 μs |  3.902 μs |  2.041 μs | 23.37 |    0.23 |  3.9063 |       - |  134.44 KB |        4.31 |
| NativeSingle      | TaLib(...)chRsi [24] | 1000  |    20.59 μs |  0.326 μs |  0.194 μs |  1.00 |    0.01 |  1.2207 |       - |   31.16 KB |        1.00 |
| NativeParallel    | TaLib(...)chRsi [24] | 1000  |    33.92 μs |  1.644 μs |  1.087 μs |  1.65 |    0.05 |  3.9063 |  0.4883 |   94.43 KB |        3.03 |
|                   |                      |       |             |           |           |       |         |         |         |            |             |
| **BuilderFull**       | **TaLib(...)chRsi [24]** | **10000** | **5,159.17 μs** | **25.159 μs** | **14.972 μs** | **19.97** |    **0.11** | **62.5000** | **31.2500** | **1799.86 KB** |        **5.76** |
| BuilderLatestOnly | TaLib(...)chRsi [24] | 10000 | 5,059.36 μs | 25.559 μs | 15.210 μs | 19.58 |    0.11 | 31.2500 |       - | 1330.03 KB |        4.26 |
| NativeSingle      | TaLib(...)chRsi [24] | 10000 |   258.37 μs |  2.180 μs |  1.297 μs |  1.00 |    0.01 | 11.7188 |  3.9063 |  312.42 KB |        1.00 |
| NativeParallel    | TaLib(...)chRsi [24] | 10000 |   379.17 μs | 25.361 μs | 16.775 μs |  1.47 |    0.06 | 39.0625 | 17.5781 |   938.2 KB |        3.00 |
