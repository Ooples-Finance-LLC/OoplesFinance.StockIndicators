```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **1000**  |   **605.8 μs** | **203.30 μs** | **134.47 μs** |  **15.6250** |        **-** |  **645.93 KB** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 1000  |   514.5 μs |  63.06 μs |  41.71 μs |  23.4375 |        - |  598.34 KB |
| **BuilderFull**       | **TaLib(...)Stoch [21]** | **10000** | **5,140.9 μs** | **658.21 μs** | **435.37 μs** | **250.0000** | **125.0000** | **6342.04 KB** |
| BuilderLatestOnly | TaLib(...)Stoch [21] | 10000 | 5,020.2 μs | 448.84 μs | 296.88 μs | 218.7500 |  62.5000 |  5872.2 KB |
