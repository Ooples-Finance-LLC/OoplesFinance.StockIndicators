```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0     | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|---------:|--------:|-----------:|
| **BuilderFull**       | **TaLib(...)tochF [22]** | **1000**  |   **653.0 μs** | **295.45 μs** | **154.53 μs** |  **15.6250** |       **-** |  **392.15 KB** |
| BuilderLatestOnly | TaLib(...)tochF [22] | 1000  |   411.2 μs |  65.73 μs |  43.48 μs |  11.7188 |       - |  344.55 KB |
| **BuilderFull**       | **TaLib(...)tochF [22]** | **10000** | **3,589.2 μs** | **466.77 μs** | **277.77 μs** | **156.2500** | **62.5000** | **3838.13 KB** |
| BuilderLatestOnly | TaLib(...)tochF [22] | 10000 | 3,436.0 μs | 444.50 μs | 264.52 μs | 125.0000 | 31.2500 | 3368.28 KB |
