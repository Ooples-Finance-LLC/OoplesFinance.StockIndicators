```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **1000**  |   **419.5 μs** | **366.01 μs** | **242.09 μs** |       **-** |   **73.1 KB** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 1000  |   157.3 μs |  17.32 μs |  11.46 μs |  0.9766 |  25.22 KB |
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **10000** | **1,229.1 μs** | **138.46 μs** |  **82.39 μs** | **15.6250** | **565.69 KB** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 10000 | 1,194.6 μs | 148.57 μs |  98.27 μs |       - |  95.59 KB |
