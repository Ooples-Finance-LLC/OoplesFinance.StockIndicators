```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0      | Gen1     | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|---------:|----------:|
| **BuilderFull**       | **TaLib(...)bands [24]** | **1000**  |  **2.414 ms** | **0.0453 ms** | **0.0269 ms** |  **125.0000** |        **-** |   **3.11 MB** |
| BuilderLatestOnly | TaLib(...)bands [24] | 1000  |  2.453 ms | 0.0905 ms | 0.0599 ms |  125.0000 |  15.6250 |   3.07 MB |
| **BuilderFull**       | **TaLib(...)bands [24]** | **10000** | **16.583 ms** | **1.3588 ms** | **0.7107 ms** | **1166.6667** | **500.0000** |  **31.34 MB** |
| BuilderLatestOnly | TaLib(...)bands [24] | 10000 | 16.565 ms | 1.2344 ms | 0.8165 ms | 1285.7143 | 571.4286 |  30.88 MB |
