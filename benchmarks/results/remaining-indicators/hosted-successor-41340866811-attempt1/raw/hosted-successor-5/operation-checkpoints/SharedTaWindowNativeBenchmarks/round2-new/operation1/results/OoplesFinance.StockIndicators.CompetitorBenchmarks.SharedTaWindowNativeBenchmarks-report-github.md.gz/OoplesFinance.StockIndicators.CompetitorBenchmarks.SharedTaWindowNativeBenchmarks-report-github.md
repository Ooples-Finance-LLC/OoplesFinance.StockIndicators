```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **1000**  |   **275.64 μs** |   **2.619 μs** |   **1.370 μs** |  **8.76** |    **0.07** |       **-** |  **73.24 KB** |        **9.24** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 1000  |   148.96 μs |   9.855 μs |   6.519 μs |  4.74 |    0.20 |  0.9766 |  25.22 KB |        3.18 |
| NativeSingle      | TaLib(...)vgDev [22] | 1000  |    31.46 μs |   0.383 μs |   0.201 μs |  1.00 |    0.01 |  0.2441 |   7.92 KB |        1.00 |
| NativeParallel    | TaLib(...)vgDev [22] | 1000  |    21.36 μs |   3.039 μs |   2.010 μs |  0.68 |    0.06 |  0.7324 |  16.76 KB |        2.11 |
|                   |                      |       |             |            |            |       |         |         |           |             |
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **10000** | **1,234.88 μs** | **135.256 μs** |  **89.464 μs** |  **3.86** |    **0.27** | **15.6250** | **565.69 KB** |        **7.23** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 10000 | 1,194.27 μs | 181.102 μs | 119.788 μs |  3.74 |    0.36 |       - |  95.58 KB |        1.22 |
| NativeSingle      | TaLib(...)vgDev [22] | 10000 |   319.70 μs |   2.582 μs |   1.351 μs |  1.00 |    0.01 |  1.9531 |  78.25 KB |        1.00 |
| NativeParallel    | TaLib(...)vgDev [22] | 10000 |   214.86 μs |  27.024 μs |  17.875 μs |  0.67 |    0.05 |  5.8594 |  157.4 KB |        2.01 |
