```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **1000**  |   **191.8 μs** |   **8.81 μs** |   **5.24 μs** |       **-** |   **73.1 KB** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 1000  |   156.2 μs |  19.03 μs |  12.58 μs |  0.9766 |  25.22 KB |
| **BuilderFull**       | **TaLib(...)vgDev [22]** | **10000** | **1,244.9 μs** | **163.96 μs** | **108.45 μs** | **15.6250** | **565.65 KB** |
| BuilderLatestOnly | TaLib(...)vgDev [22] | 10000 | 1,147.5 μs | 147.29 μs |  97.42 μs |       - |  95.57 KB |
