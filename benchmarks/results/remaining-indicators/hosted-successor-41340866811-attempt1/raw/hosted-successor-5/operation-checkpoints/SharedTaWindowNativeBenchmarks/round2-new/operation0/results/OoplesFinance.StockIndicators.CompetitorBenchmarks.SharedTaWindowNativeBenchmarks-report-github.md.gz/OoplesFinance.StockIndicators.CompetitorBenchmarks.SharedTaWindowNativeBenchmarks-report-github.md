```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error        | StdDev     | Ratio  | RatioSD | Gen0      | Gen1     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-------------:|-----------:|-------:|--------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **TaLib(...)bands [24]** | **1000**  |  **2,389.30 μs** |    **27.050 μs** |  **16.097 μs** | **189.54** |    **1.56** |  **125.0000** |        **-** |  **3187.64 KB** |       **81.55** |
| BuilderLatestOnly | TaLib(...)bands [24] | 1000  |  2,363.83 μs |    22.067 μs |  11.542 μs | 187.52 |    1.30 |  125.0000 |  15.6250 |  3140.16 KB |       80.34 |
| NativeSingle      | TaLib(...)bands [24] | 1000  |     12.61 μs |     0.116 μs |   0.069 μs |   1.00 |    0.01 |    1.5869 |   0.1221 |    39.09 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [24] | 1000  |     25.73 μs |     1.219 μs |   0.638 μs |   2.04 |    0.05 |    5.3711 |   0.9766 |   122.26 KB |        3.13 |
|                   |                      |       |              |              |            |        |         |           |          |             |             |
| **BuilderFull**       | **TaLib(...)bands [24]** | **10000** | **16,526.51 μs** | **1,509.989 μs** | **998.764 μs** | **142.19** |    **8.83** | **1166.6667** | **500.0000** | **32093.59 KB** |       **82.15** |
| BuilderLatestOnly | TaLib(...)bands [24] | 10000 | 16,198.72 μs | 1,055.191 μs | 697.944 μs | 139.37 |    6.57 | 1285.7143 | 571.4286 | 31623.54 KB |       80.95 |
| NativeSingle      | TaLib(...)bands [24] | 10000 |    116.29 μs |     4.302 μs |   2.845 μs |   1.00 |    0.03 |   15.6250 |   7.8125 |   390.66 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [24] | 10000 |    199.63 μs |    11.276 μs |   7.458 μs |   1.72 |    0.07 |   50.7813 |  23.4375 |  1212.11 KB |        3.10 |
