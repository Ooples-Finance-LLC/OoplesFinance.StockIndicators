```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId            | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------ |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetZigZag** |  **1.187 ms** | **0.1868 ms** | **0.1235 ms** |  **1.01** |    **0.14** |  **479.98 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetZigZag |  1.396 ms | 0.0665 ms | 0.0396 ms |  1.19 |    0.12 |   430.2 KB |        0.90 |
|            |       |                   |           |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetZigZag** |  **7.111 ms** | **0.2101 ms** | **0.1099 ms** |  **1.00** |    **0.02** | **4851.34 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetZigZag | 11.998 ms | 0.1160 ms | 0.0607 ms |  1.69 |    0.03 |  4095.2 KB |        0.84 |
