```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId              | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |-------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Apo** |  **2.211 ms** | **0.0815 ms** | **0.0485 ms** |  **1.00** |    **0.03** |   **373.2 KB** |        **1.00** |
|        |       |                     |           |           |           |       |         |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Apo** | **14.064 ms** | **2.0066 ms** | **1.3272 ms** |  **1.01** |    **0.14** | **3553.78 KB** |        **1.00** |
