```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)AdOsc [21]** | **4,230.7 μs** | **101.15 μs** |  **60.20 μs** |  **1.00** |    **0.02** |  **209.12 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)AdOsc [21] |   186.8 μs |  56.91 μs |  37.65 μs |  0.04 |    0.01 |   40.85 KB |        0.20 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)AdOsc [21]** | **5,838.2 μs** | **245.42 μs** | **128.36 μs** |  **1.00** |    **0.03** | **2053.86 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)AdOsc [21] |   136.0 μs |  10.45 μs |   6.22 μs |  0.02 |    0.00 |  331.19 KB |        0.16 |
