```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean     | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |---------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Adxr** | **3.008 ms** | **0.4100 ms** | **0.2712 ms** |  **1.01** |    **0.12** |  **107.43 KB** |        **1.00** |
|        |       |                      |          |           |           |       |         |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Adxr** | **8.437 ms** | **4.9413 ms** | **2.5844 ms** |  **1.06** |    **0.39** | **1047.66 KB** |        **1.00** |
