```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean      | Error      | StdDev    | Ratio | RatioSD | Gen0      | Allocated | Alloc Ratio |
|------- |------ |--------------------- |----------:|-----------:|----------:|------:|--------:|----------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)bands [24]** |  **6.756 ms** |  **0.2124 ms** | **0.1111 ms** |  **1.00** |    **0.02** |         **-** |   **3.23 MB** |        **1.00** |
|        |       |                      |           |            |           |       |         |           |           |             |
| **Ooples** | **10000** | **TaLib(...)bands [24]** | **52.299 ms** | **14.9381 ms** | **9.8806 ms** |  **1.03** |    **0.25** | **1000.0000** |  **32.43 MB** |        **1.00** |
