```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)vgDev [22]** | **1,328.73 μs** | **209.79 μs** | **124.84 μs** |  **1.01** |    **0.12** |  **73.16 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)vgDev [22] |    70.46 μs |  19.64 μs |  12.99 μs |  0.05 |    0.01 |  23.84 KB |        0.33 |
|            |       |                      |             |           |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib(...)vgDev [22]** | **1,337.46 μs** | **201.19 μs** | **119.73 μs** |  **1.01** |    **0.12** | **643.82 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)vgDev [22] |   360.26 μs |  25.06 μs |  14.91 μs |  0.27 |    0.03 | 164.47 KB |        0.26 |
