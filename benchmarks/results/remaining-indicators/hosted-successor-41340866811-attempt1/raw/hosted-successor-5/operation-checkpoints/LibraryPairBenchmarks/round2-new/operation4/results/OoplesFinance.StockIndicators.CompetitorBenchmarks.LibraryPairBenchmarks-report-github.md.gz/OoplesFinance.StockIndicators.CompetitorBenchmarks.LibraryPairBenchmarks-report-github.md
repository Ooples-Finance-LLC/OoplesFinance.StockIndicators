```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId              | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adx** | **3,038.1 μs** | **505.61 μs** | **334.43 μs** |  **1.01** |    **0.15** |  **106.36 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adx |   224.1 μs |  42.56 μs |  28.15 μs |  0.07 |    0.01 |   40.88 KB |        0.38 |
|            |       |                     |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adx** | **5,965.7 μs** | **138.17 μs** |  **82.22 μs** |  **1.00** |    **0.02** | **1046.59 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adx |   308.4 μs |  62.59 μs |  37.25 μs |  0.05 |    0.01 |  330.92 KB |        0.32 |
