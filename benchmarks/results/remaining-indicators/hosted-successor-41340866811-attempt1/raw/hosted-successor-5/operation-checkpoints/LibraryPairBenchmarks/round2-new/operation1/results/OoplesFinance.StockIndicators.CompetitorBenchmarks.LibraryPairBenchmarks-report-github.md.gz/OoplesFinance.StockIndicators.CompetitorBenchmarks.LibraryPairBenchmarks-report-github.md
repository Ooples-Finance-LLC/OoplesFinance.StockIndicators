```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error        | StdDev       | Ratio | RatioSD | Gen0      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-------------:|-------------:|------:|--------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)bands [24]** |  **6,870.4 μs** |    **457.82 μs** |    **272.44 μs** |  **1.00** |    **0.05** |         **-** |  **3309.52 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)bands [24] |    263.5 μs |     12.75 μs |      6.67 μs |  0.04 |    0.00 |         - |   121.84 KB |        0.04 |
|            |       |                      |             |              |              |       |         |           |             |             |
| **Ooples**     | **10000** | **TaLib(...)bands [24]** | **58,038.1 μs** | **20,314.67 μs** | **13,436.90 μs** | **1.050** |    **0.34** | **1000.0000** | **33205.35 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)bands [24] |    411.5 μs |     66.75 μs |     39.72 μs | 0.007 |    0.00 |         - |  1132.91 KB |        0.03 |
