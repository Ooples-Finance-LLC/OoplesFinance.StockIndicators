```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean      | Error      | StdDev     | Median   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |----------:|-----------:|-----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)AdOsc [21]** |  **4.202 ms** |  **0.1860 ms** |  **0.0973 ms** | **4.177 ms** |  **1.00** |    **0.03** |  **209.12 KB** |        **1.00** |
|        |       |                      |           |            |            |          |       |         |            |             |
| **Ooples** | **10000** | **TaLib(...)AdOsc [21]** | **15.355 ms** | **20.9050 ms** | **12.4402 ms** | **8.844 ms** |  **1.40** |    **1.29** | **2054.19 KB** |        **1.00** |
