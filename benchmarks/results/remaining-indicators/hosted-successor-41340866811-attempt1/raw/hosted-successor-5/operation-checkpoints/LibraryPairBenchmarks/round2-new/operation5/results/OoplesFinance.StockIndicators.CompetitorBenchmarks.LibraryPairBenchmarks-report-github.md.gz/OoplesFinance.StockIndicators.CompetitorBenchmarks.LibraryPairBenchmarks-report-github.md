```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Adxr** | **2,893.0 μs** | **264.85 μs** | **175.18 μs** |  **1.00** |    **0.08** |  **107.43 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Adxr |   236.6 μs |  17.67 μs |  10.51 μs |  0.08 |    0.01 |   48.45 KB |        0.45 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Adxr** | **6,779.8 μs** |  **97.23 μs** |  **57.86 μs** |  **1.00** |    **0.01** | **1047.38 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Adxr |   312.0 μs |  39.68 μs |  23.62 μs |  0.05 |    0.00 |  408.15 KB |        0.39 |
