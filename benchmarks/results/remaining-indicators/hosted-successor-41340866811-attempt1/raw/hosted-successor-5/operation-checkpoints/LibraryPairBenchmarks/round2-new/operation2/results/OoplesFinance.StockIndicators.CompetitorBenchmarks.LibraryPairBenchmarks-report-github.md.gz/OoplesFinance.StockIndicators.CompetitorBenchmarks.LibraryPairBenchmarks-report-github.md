```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId             | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |------------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Ad** |   **868.07 μs** | **230.79 μs** | **152.65 μs** |  **1.03** |    **0.25** |  **160.84 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Ad |    91.20 μs |  41.49 μs |  27.44 μs |  0.11 |    0.04 |   15.98 KB |        0.10 |
|            |       |                    |             |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Ad** | **6,741.33 μs** | **904.28 μs** | **538.13 μs** |  **1.01** |    **0.11** | **2015.88 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Ad |   144.22 μs |  52.51 μs |  34.73 μs |  0.02 |    0.01 |   86.29 KB |        0.04 |
