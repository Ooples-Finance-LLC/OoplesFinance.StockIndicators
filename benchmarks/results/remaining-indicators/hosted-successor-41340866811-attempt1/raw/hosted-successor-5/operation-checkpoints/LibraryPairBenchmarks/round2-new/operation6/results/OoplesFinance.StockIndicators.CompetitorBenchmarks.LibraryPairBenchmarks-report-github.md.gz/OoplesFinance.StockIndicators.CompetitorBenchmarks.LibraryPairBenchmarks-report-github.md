```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId              | Mean        | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------------- |------------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Apo** |  **2,250.7 μs** |    **98.49 μs** |  **58.61 μs** |  **1.00** |    **0.03** |   **373.2 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Apo |    137.7 μs |    15.69 μs |  10.38 μs |  0.06 |    0.00 |   48.84 KB |        0.13 |
|            |       |                     |             |             |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Apo** | **10,508.4 μs** | **1,686.16 μs** | **881.89 μs** |  **1.01** |    **0.11** | **3553.78 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Apo |    227.2 μs |    10.26 μs |   5.37 μs |  0.02 |    0.00 |  409.19 KB |        0.12 |
