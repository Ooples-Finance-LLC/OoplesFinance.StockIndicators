```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|----------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **Commo(...)Index [21]** | **1000**  |     **420.5 μs** |   **121.25 μs** |    **80.20 μs** |  **0.04** |    **0.01** |         **-** |         **-** |        **-** |    **70.53 KB** |       **0.016** |
| BuilderLatestOnly | Commo(...)Index [21] | 1000  |     261.7 μs |    61.89 μs |    40.94 μs |  0.02 |    0.00 |         - |         - |        - |    22.88 KB |       0.005 |
| NativeSingle      | Commo(...)Index [21] | 1000  |  11,643.8 μs |    50.42 μs |    26.37 μs |  1.00 |    0.00 |  111.1111 |         - |        - |  4398.03 KB |       1.000 |
| NativeParallel    | Commo(...)Index [21] | 1000  |   6,162.5 μs |   429.63 μs |   284.18 μs |  0.53 |    0.02 |  156.2500 |   31.2500 |        - |  4407.04 KB |       1.002 |
|                   |                      |       |              |             |             |       |         |           |           |          |             |             |
| **BuilderFull**       | **Commo(...)Index [21]** | **10000** |   **2,083.2 μs** |   **187.90 μs** |   **124.28 μs** |  **0.02** |    **0.00** |   **15.6250** |         **-** |        **-** |   **633.42 KB** |       **0.014** |
| BuilderLatestOnly | Commo(...)Index [21] | 10000 |   1,986.5 μs |   198.67 μs |   131.41 μs |  0.02 |    0.00 |         - |         - |        - |   163.63 KB |       0.004 |
| NativeSingle      | Commo(...)Index [21] | 10000 | 126,116.9 μs | 1,772.75 μs | 1,172.56 μs |  1.00 |    0.01 | 2000.0000 |  500.0000 | 250.0000 |  45275.8 KB |       1.000 |
| NativeParallel    | Commo(...)Index [21] | 10000 |  75,819.9 μs | 3,953.63 μs | 2,615.08 μs |  0.60 |    0.02 | 2000.0000 | 1000.0000 | 250.0000 | 45394.07 KB |       1.003 |
