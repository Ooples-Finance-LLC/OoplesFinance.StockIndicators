```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **Commo(...)Index [21]** | **1000**  |   **383.6 μs** |  **19.78 μs** |  **11.77 μs** |       **-** |  **70.53 KB** |
| BuilderLatestOnly | Commo(...)Index [21] | 1000  |   249.4 μs |  53.36 μs |  35.29 μs |       - |  22.87 KB |
| **BuilderFull**       | **Commo(...)Index [21]** | **10000** | **2,159.2 μs** | **353.80 μs** | **234.02 μs** | **15.6250** | **633.43 KB** |
| BuilderLatestOnly | Commo(...)Index [21] | 10000 | 1,914.9 μs |  90.72 μs |  47.45 μs |       - | 163.62 KB |
