```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **Commo(...)Index [21]** | **1000**  |   **365.1 μs** |  **13.27 μs** |   **7.90 μs** |       **-** |  **70.53 KB** |
| BuilderLatestOnly | Commo(...)Index [21] | 1000  |   241.3 μs |  60.66 μs |  36.10 μs |       - |  22.88 KB |
| **BuilderFull**       | **Commo(...)Index [21]** | **10000** | **2,112.6 μs** | **273.08 μs** | **180.63 μs** | **15.6250** | **633.45 KB** |
| BuilderLatestOnly | Commo(...)Index [21] | 10000 | 1,940.2 μs |  67.89 μs |  40.40 μs |       - | 163.75 KB |
