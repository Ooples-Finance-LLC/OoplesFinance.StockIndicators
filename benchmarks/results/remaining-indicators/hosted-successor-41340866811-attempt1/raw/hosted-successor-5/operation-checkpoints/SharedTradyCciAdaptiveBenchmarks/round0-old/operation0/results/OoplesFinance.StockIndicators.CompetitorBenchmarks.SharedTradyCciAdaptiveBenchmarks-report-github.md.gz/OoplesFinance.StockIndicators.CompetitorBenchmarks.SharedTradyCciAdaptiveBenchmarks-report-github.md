```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
Intel Xeon Platinum 8370C CPU 2.80GHz (Max: 2.79GHz), 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **Commo(...)Index [21]** | **1000**  |   **375.1 μs** |  **14.25 μs** |   **9.42 μs** |       **-** |  **70.49 KB** |
| BuilderLatestOnly | Commo(...)Index [21] | 1000  |   235.7 μs |  47.73 μs |  31.57 μs |       - |  22.88 KB |
| **BuilderFull**       | **Commo(...)Index [21]** | **10000** | **2,202.2 μs** | **361.44 μs** | **239.07 μs** | **15.6250** | **633.44 KB** |
| BuilderLatestOnly | Commo(...)Index [21] | 10000 | 2,140.4 μs | 362.61 μs | 239.84 μs |       - |  163.6 KB |
