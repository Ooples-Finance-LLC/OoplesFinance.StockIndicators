```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Weigh(...)erage [21]** | **1000**  |     **21.40 μs** |   **4.310 μs** |   **2.565 μs** | **0.012** |    **0.00** |   **2.9297** |        **-** |        **-** |   **58.47 KB** |        **0.10** |
| BuilderLatestOnly | Weigh(...)erage [21] | 1000  |     13.89 μs |   2.973 μs |   1.966 μs | 0.008 |    0.00 |   0.4883 |        - |        - |   10.59 KB |        0.02 |
| NativeSingle      | Weigh(...)erage [21] | 1000  |  1,736.04 μs |  11.273 μs |   7.456 μs | 1.000 |    0.01 |  31.2500 |        - |        - |   559.6 KB |        1.00 |
| NativeParallel    | Weigh(...)erage [21] | 1000  |    888.12 μs |  51.880 μs |  34.315 μs | 0.512 |    0.02 |  31.2500 |   7.8125 |        - |  565.13 KB |        1.01 |
|                   |                      |       |              |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Weigh(...)erage [21]** | **10000** |    **107.55 μs** |  **10.662 μs** |   **7.052 μs** | **0.006** |    **0.00** |  **33.2031** |  **11.7188** |        **-** |  **551.01 KB** |        **0.10** |
| BuilderLatestOnly | Weigh(...)erage [21] | 10000 |     87.70 μs |   8.903 μs |   5.889 μs | 0.005 |    0.00 |   4.8828 |   0.4883 |        - |   80.91 KB |        0.01 |
| NativeSingle      | Weigh(...)erage [21] | 10000 | 17,987.60 μs |  74.988 μs |  39.220 μs | 1.000 |    0.00 | 500.0000 | 333.3333 | 333.3333 | 5508.31 KB |        1.00 |
| NativeParallel    | Weigh(...)erage [21] | 10000 |  9,647.55 μs | 356.173 μs | 235.587 μs | 0.536 |    0.01 | 454.5455 | 272.7273 | 181.8182 | 5620.76 KB |        1.02 |
