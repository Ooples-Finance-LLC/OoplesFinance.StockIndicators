```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error     | StdDev     | Ratio | RatioSD | Gen0      | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|----------:|-----------:|------:|--------:|----------:|---------:|---------:|------------:|------------:|
| **BuilderFull**       | **Simpl(...)lator [29]** | **1000**  |     **58.10 μs** |  **14.21 μs** |   **9.400 μs** |  **0.06** |    **0.01** |    **3.9063** |        **-** |        **-** |    **69.74 KB** |        **0.06** |
| BuilderLatestOnly | Simpl(...)lator [29] | 1000  |     53.86 μs |  11.63 μs |   7.694 μs |  0.06 |    0.01 |    0.9766 |        - |        - |    22.13 KB |        0.02 |
| NativeSingle      | Simpl(...)lator [29] | 1000  |    941.21 μs |  30.45 μs |  18.122 μs |  1.00 |    0.03 |   62.5000 |  23.4375 |        - |   1081.5 KB |        1.00 |
| NativeParallel    | Simpl(...)lator [29] | 1000  |    522.77 μs |  58.72 μs |  38.842 μs |  0.56 |    0.04 |   66.4063 |  19.5313 |        - |  1055.85 KB |        0.98 |
|                   |                      |       |              |           |            |       |         |           |          |          |             |             |
| **BuilderFull**       | **Simpl(...)lator [29]** | **10000** |    **445.63 μs** |  **90.14 μs** |  **59.623 μs** |  **0.04** |    **0.01** |   **35.1563** |  **15.6250** |        **-** |   **632.62 KB** |        **0.06** |
| BuilderLatestOnly | Simpl(...)lator [29] | 10000 |    383.33 μs |  44.41 μs |  26.428 μs |  0.04 |    0.00 |    9.7656 |   1.9531 |        - |   162.77 KB |        0.02 |
| NativeSingle      | Simpl(...)lator [29] | 10000 | 10,024.69 μs | 157.37 μs |  82.306 μs |  1.00 |    0.01 | 1100.0000 | 900.0000 | 800.0000 | 10511.08 KB |        1.00 |
| NativeParallel    | Simpl(...)lator [29] | 10000 |  7,417.73 μs | 752.00 μs | 447.501 μs |  0.74 |    0.04 | 1071.4286 | 785.7143 | 571.4286 | 10387.92 KB |        0.99 |
