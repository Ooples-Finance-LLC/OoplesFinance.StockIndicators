```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **Expon(...)lator [34]** | **1000**  |  **84.44 μs** |  **3.419 μs** | **1.788 μs** |  **3.9063** |      **-** |  **64.93 KB** |
| BuilderLatestOnly | Expon(...)lator [34] | 1000  |  78.32 μs |  1.700 μs | 1.012 μs |  0.9766 |      - |  17.32 KB |
| **BuilderFull**       | **Expon(...)lator [34]** | **10000** | **908.35 μs** | **10.982 μs** | **5.744 μs** | **31.2500** | **7.8125** | **627.84 KB** |
| BuilderLatestOnly | Expon(...)lator [34] | 10000 | 866.48 μs |  5.787 μs | 3.828 μs |  7.8125 |      - | 158.01 KB |
