```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error        | StdDev     | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-------------:|-----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Expon(...)lator [34]** | **1000**  |     **89.57 μs** |     **1.150 μs** |   **0.601 μs** |  **0.07** |    **0.00** |    **3.9063** |         **-** |         **-** |    **64.97 KB** |       **0.030** |
| BuilderLatestOnly | Expon(...)lator [34] | 1000  |     88.70 μs |     3.937 μs |   2.343 μs |  0.07 |    0.00 |    0.9766 |         - |         - |    17.37 KB |       0.008 |
| NativeSingle      | Expon(...)lator [34] | 1000  |  1,238.09 μs |    24.408 μs |  14.525 μs |  1.00 |    0.02 |  132.8125 |   54.6875 |         - |  2200.75 KB |       1.000 |
| NativeParallel    | Expon(...)lator [34] | 1000  |  1,065.38 μs |    38.942 μs |  23.174 μs |  0.86 |    0.02 |  210.9375 |   93.7500 |         - |  3332.46 KB |       1.514 |
|                   |                      |       |              |              |            |       |         |           |           |           |             |             |
| **BuilderFull**       | **Expon(...)lator [34]** | **10000** |    **940.02 μs** |     **8.398 μs** |   **4.392 μs** |  **0.06** |    **0.00** |   **31.2500** |    **7.8125** |         **-** |   **627.89 KB** |       **0.029** |
| BuilderLatestOnly | Expon(...)lator [34] | 10000 |    912.93 μs |     4.285 μs |   2.834 μs |  0.06 |    0.00 |    7.8125 |         - |         - |   158.06 KB |       0.007 |
| NativeSingle      | Expon(...)lator [34] | 10000 | 16,252.75 μs | 1,127.570 μs | 670.999 μs |  1.00 |    0.06 | 1571.4286 | 1142.8571 |  857.1429 | 21976.33 KB |       1.000 |
| NativeParallel    | Expon(...)lator [34] | 10000 | 15,848.05 μs | 1,070.775 μs | 637.201 μs |  0.98 |    0.05 | 2250.0000 | 1500.0000 | 1000.0000 | 33530.87 KB |       1.526 |
