```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Weigh(...)erage [21]** | **1000**  |  **28.56 μs** | **10.428 μs** | **6.897 μs** |  **2.9297** |       **-** |  **58.47 KB** |
| BuilderLatestOnly | Weigh(...)erage [21] | 1000  |  11.99 μs |  0.417 μs | 0.218 μs |  0.6104 |       - |  10.59 KB |
| **BuilderFull**       | **Weigh(...)erage [21]** | **10000** | **101.80 μs** | **12.627 μs** | **6.604 μs** | **33.2031** | **12.6953** | **551.01 KB** |
| BuilderLatestOnly | Weigh(...)erage [21] | 10000 |  87.71 μs |  9.352 μs | 6.186 μs |  4.8828 |  0.4883 |  80.91 KB |
