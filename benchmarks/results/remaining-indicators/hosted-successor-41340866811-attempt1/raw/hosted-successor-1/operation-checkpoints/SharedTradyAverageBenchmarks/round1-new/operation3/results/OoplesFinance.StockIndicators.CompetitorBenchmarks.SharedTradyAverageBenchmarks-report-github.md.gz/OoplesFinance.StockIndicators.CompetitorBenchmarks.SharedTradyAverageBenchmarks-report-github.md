```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **Expon(...)lator [34]** | **1000**  |  **85.55 μs** | **0.227 μs** | **0.119 μs** |  **3.9063** |      **-** |  **64.97 KB** |
| BuilderLatestOnly | Expon(...)lator [34] | 1000  |  84.17 μs | 2.955 μs | 1.758 μs |  0.9766 |      - |  17.36 KB |
| **BuilderFull**       | **Expon(...)lator [34]** | **10000** | **910.60 μs** | **5.957 μs** | **3.545 μs** | **31.2500** | **7.8125** | **627.89 KB** |
| BuilderLatestOnly | Expon(...)lator [34] | 10000 | 904.27 μs | 8.995 μs | 5.353 μs |  7.8125 |      - | 158.06 KB |
