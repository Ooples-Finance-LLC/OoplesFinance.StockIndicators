```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Expon(...)erage [24]** | **1000**  |  **33.89 μs** | **1.615 μs** | **1.068 μs** |  **1.9531** |       **-** |  **56.66 KB** |
| BuilderLatestOnly | Expon(...)erage [24] | 1000  |  34.26 μs | 4.138 μs | 2.737 μs |  0.4883 |       - |   8.78 KB |
| **BuilderFull**       | **Expon(...)erage [24]** | **10000** | **384.01 μs** | **7.922 μs** | **5.240 μs** | **33.2031** | **13.6719** | **549.21 KB** |
| BuilderLatestOnly | Expon(...)erage [24] | 10000 | 356.17 μs | 6.125 μs | 3.645 μs |  3.9063 |       - |   79.1 KB |
