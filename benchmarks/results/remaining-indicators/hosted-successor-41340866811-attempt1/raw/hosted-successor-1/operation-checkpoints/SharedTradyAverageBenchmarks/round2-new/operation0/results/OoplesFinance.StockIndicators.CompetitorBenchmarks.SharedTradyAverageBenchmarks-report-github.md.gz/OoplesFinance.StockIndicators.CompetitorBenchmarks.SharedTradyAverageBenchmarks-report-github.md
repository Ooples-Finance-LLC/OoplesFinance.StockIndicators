```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error        | StdDev     | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-------------:|-----------:|------:|--------:|----------:|----------:|---------:|------------:|------------:|
| **BuilderFull**       | **Expon(...)erage [24]** | **1000**  |    **40.39 μs** |     **3.598 μs** |   **2.380 μs** |  **0.08** |    **0.00** |    **1.9531** |         **-** |        **-** |    **56.64 KB** |       **0.062** |
| BuilderLatestOnly | Expon(...)erage [24] | 1000  |    39.18 μs |     1.614 μs |   1.068 μs |  0.07 |    0.00 |    0.4883 |         - |        - |      8.8 KB |       0.010 |
| NativeSingle      | Expon(...)erage [24] | 1000  |   529.94 μs |     5.072 μs |   2.653 μs |  1.00 |    0.01 |   54.6875 |   15.6250 |        - |   915.28 KB |       1.000 |
| NativeParallel    | Expon(...)erage [24] | 1000  |   506.80 μs |     8.259 μs |   4.320 μs |  0.96 |    0.01 |   82.0313 |   27.3438 |        - |  1328.65 KB |       1.452 |
|                   |                      |       |             |              |            |       |         |           |           |          |             |             |
| **BuilderFull**       | **Expon(...)erage [24]** | **10000** |   **393.85 μs** |     **8.416 μs** |   **5.567 μs** |  **0.07** |    **0.00** |   **33.2031** |   **13.6719** |        **-** |   **549.19 KB** |       **0.062** |
| BuilderLatestOnly | Expon(...)erage [24] | 10000 |   368.62 μs |    10.236 μs |   6.770 μs |  0.06 |    0.00 |    3.9063 |         - |        - |    79.13 KB |       0.009 |
| NativeSingle      | Expon(...)erage [24] | 10000 | 5,711.65 μs |   188.651 μs | 124.781 μs |  1.00 |    0.03 | 1312.5000 | 1031.2500 | 968.7500 |  8914.46 KB |       1.000 |
| NativeParallel    | Expon(...)erage [24] | 10000 | 8,414.27 μs | 1,274.640 μs | 843.096 μs |  1.47 |    0.14 | 1333.3333 | 1000.0000 | 833.3333 | 13011.57 KB |       1.460 |
