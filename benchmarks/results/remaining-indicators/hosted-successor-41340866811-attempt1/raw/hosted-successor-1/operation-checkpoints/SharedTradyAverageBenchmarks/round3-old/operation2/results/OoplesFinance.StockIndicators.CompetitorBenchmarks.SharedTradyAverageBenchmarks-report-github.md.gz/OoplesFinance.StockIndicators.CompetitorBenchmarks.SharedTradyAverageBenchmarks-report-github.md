```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Simpl(...)lator [29]** | **1000**  |  **59.33 μs** |  **0.754 μs** |  **0.395 μs** |  **3.9063** |       **-** |  **69.52 KB** |
| BuilderLatestOnly | Simpl(...)lator [29] | 1000  |  49.20 μs |  9.267 μs |  5.515 μs |  0.9766 |       - |  21.94 KB |
| **BuilderFull**       | **Simpl(...)lator [29]** | **10000** | **400.86 μs** | **98.658 μs** | **65.256 μs** | **35.1563** | **11.7188** |  **632.4 KB** |
| BuilderLatestOnly | Simpl(...)lator [29] | 10000 | 356.90 μs | 63.368 μs | 41.914 μs |  9.7656 |  1.9531 | 162.59 KB |
