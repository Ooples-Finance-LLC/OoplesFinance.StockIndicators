```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Expon(...)erage [24]** | **1000**  |  **59.47 μs** | **31.172 μs** | **20.618 μs** |  **1.9531** |       **-** |  **56.68 KB** |
| BuilderLatestOnly | Expon(...)erage [24] | 1000  |  32.39 μs |  0.352 μs |  0.184 μs |  0.4883 |       - |    8.8 KB |
| **BuilderFull**       | **Expon(...)erage [24]** | **10000** | **386.88 μs** | **10.559 μs** |  **6.984 μs** | **33.2031** | **13.6719** | **549.23 KB** |
| BuilderLatestOnly | Expon(...)erage [24] | 10000 | 365.19 μs |  3.919 μs |  2.332 μs |  3.9063 |       - |  79.13 KB |
