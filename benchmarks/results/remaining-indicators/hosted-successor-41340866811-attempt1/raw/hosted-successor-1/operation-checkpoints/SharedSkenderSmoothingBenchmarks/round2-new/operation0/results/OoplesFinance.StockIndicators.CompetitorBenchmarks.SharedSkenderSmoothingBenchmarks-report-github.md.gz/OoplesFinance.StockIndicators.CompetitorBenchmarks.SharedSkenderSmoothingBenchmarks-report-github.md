```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |-------------------- |------ |-----------:|----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetElderRay** | **1000**  |   **103.1 μs** |   **3.60 μs** |   **1.88 μs** |  **0.99** |    **0.03** |   **3.9063** |        **-** |       **-** |   **80.63 KB** |        **0.32** |
| BuilderLatestOnly | Skender.GetElderRay | 1000  |   100.4 μs |   1.74 μs |   1.03 μs |  0.96 |    0.03 |   1.9531 |        - |       - |   33.02 KB |        0.13 |
| NativeSingle      | Skender.GetElderRay | 1000  |   104.7 μs |   4.41 μs |   2.92 μs |  1.00 |    0.04 |  14.6484 |   2.9297 |       - |  251.06 KB |        1.00 |
| NativeParallel    | Skender.GetElderRay | 1000  |   174.1 μs |   4.70 μs |   2.79 μs |  1.66 |    0.05 |  41.0156 |  13.6719 |       - |  637.19 KB |        2.54 |
|                   |                     |       |            |           |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skender.GetElderRay** | **10000** |   **969.5 μs** |  **10.90 μs** |   **5.70 μs** |  **0.71** |    **0.01** |  **46.8750** |  **23.4375** |       **-** |  **784.17 KB** |        **0.31** |
| BuilderLatestOnly | Skender.GetElderRay | 10000 |   970.0 μs |  10.10 μs |   6.68 μs |  0.71 |    0.01 |  15.6250 |        - |       - |  314.34 KB |        0.13 |
| NativeSingle      | Skender.GetElderRay | 10000 | 1,360.0 μs |  32.14 μs |  21.26 μs |  1.00 |    0.02 | 148.4375 | 101.5625 | 46.8750 | 2501.47 KB |        1.00 |
| NativeParallel    | Skender.GetElderRay | 10000 | 2,255.1 μs | 151.35 μs | 100.11 μs |  1.66 |    0.07 | 421.8750 | 359.3750 | 78.1250 | 6333.22 KB |        2.53 |
