```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean     | Error    | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |-------------------- |------ |---------:|---------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetElderRay** | **1000**  | **109.4 μs** |  **1.99 μs** | **1.18 μs** |       **-** |       **-** |  **80.67 KB** |
| BuilderLatestOnly | Skender.GetElderRay | 1000  | 100.4 μs |  0.98 μs | 0.58 μs |  1.9531 |       - |  33.02 KB |
| **BuilderFull**       | **Skender.GetElderRay** | **10000** | **970.1 μs** | **12.74 μs** | **7.58 μs** | **46.8750** | **23.4375** | **784.17 KB** |
| BuilderLatestOnly | Skender.GetElderRay | 10000 | 944.3 μs |  7.49 μs | 3.92 μs | 15.6250 |       - | 314.34 KB |
