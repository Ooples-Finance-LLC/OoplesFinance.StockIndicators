```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **ChandelierExit** | **1000**  |    **240.4 μs** |     **4.40 μs** |     **2.30 μs** |  **0.13** |    **0.00** |         **-** |         **-** |         **-** |    **73.62 KB** |       **0.028** |
| BuilderLatestOnly | ChandelierExit | 1000  |    237.5 μs |     1.94 μs |     1.01 μs |  0.13 |    0.00 |         - |         - |         - |    26.05 KB |       0.010 |
| NativeSingle      | ChandelierExit | 1000  |  1,783.5 μs |    61.40 μs |    36.54 μs |  1.00 |    0.03 |  140.6250 |   78.1250 |   31.2500 |  2631.04 KB |       1.000 |
| NativeParallel    | ChandelierExit | 1000  |  1,239.5 μs |    72.38 μs |    43.07 μs |  0.70 |    0.03 |  250.0000 |  125.0000 |         - |  3937.19 KB |       1.496 |
|                   |                |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **ChandelierExit** | **10000** |  **2,537.2 μs** |    **50.49 μs** |    **33.40 μs** |  **0.14** |    **0.00** |   **31.2500** |         **-** |         **-** |   **706.89 KB** |       **0.028** |
| BuilderLatestOnly | ChandelierExit | 10000 |  2,465.2 μs |    18.37 μs |     9.61 μs |  0.14 |    0.00 |         - |         - |         - |   237.11 KB |       0.009 |
| NativeSingle      | ChandelierExit | 10000 | 17,966.2 μs |   211.04 μs |   125.58 μs |  1.00 |    0.01 | 1333.3333 |  666.6667 |  500.0000 | 25625.48 KB |       1.000 |
| NativeParallel    | ChandelierExit | 10000 | 16,158.6 μs | 2,545.80 μs | 1,514.97 μs |  0.90 |    0.08 | 2666.6667 | 1833.3333 | 1166.6667 | 38825.27 KB |       1.515 |
