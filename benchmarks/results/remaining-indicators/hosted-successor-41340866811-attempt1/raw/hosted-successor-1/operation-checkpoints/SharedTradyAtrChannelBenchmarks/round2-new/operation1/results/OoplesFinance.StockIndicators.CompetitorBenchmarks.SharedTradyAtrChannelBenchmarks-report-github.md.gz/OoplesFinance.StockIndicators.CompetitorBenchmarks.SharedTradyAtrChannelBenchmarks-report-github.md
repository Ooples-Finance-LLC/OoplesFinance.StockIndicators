```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |---------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **KeltnerChannels** | **1000**  |    **380.8 μs** |   **101.30 μs** |    **67.00 μs** |  **0.22** |    **0.04** |         **-** |         **-** |         **-** |    **96.91 KB** |        **0.03** |
| BuilderLatestOnly | KeltnerChannels | 1000  |    291.3 μs |    13.98 μs |     9.25 μs |  0.17 |    0.01 |    1.9531 |         - |         - |    49.27 KB |        0.02 |
| NativeSingle      | KeltnerChannels | 1000  |  1,747.7 μs |    51.92 μs |    34.34 μs |  1.00 |    0.03 |  203.1250 |  140.6250 |   46.8750 |  2987.94 KB |        1.00 |
| NativeParallel    | KeltnerChannels | 1000  |  1,388.3 μs |    71.92 μs |    47.57 μs |  0.79 |    0.03 |  304.6875 |  148.4375 |         - |     4778 KB |        1.60 |
|                   |                 |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **KeltnerChannels** | **10000** |  **2,903.3 μs** |    **15.94 μs** |     **8.34 μs** |  **0.13** |    **0.01** |   **46.8750** |   **15.6250** |         **-** |   **941.08 KB** |        **0.03** |
| BuilderLatestOnly | KeltnerChannels | 10000 |  2,881.9 μs |    24.58 μs |    12.85 μs |  0.13 |    0.01 |   15.6250 |         - |         - |   471.21 KB |        0.02 |
| NativeSingle      | KeltnerChannels | 10000 | 21,993.0 μs | 2,607.89 μs | 1,551.91 μs |  1.00 |    0.09 | 2000.0000 | 1400.0000 | 1000.0000 | 29149.97 KB |        1.00 |
| NativeParallel    | KeltnerChannels | 10000 | 19,389.0 μs | 1,704.76 μs | 1,127.60 μs |  0.89 |    0.08 | 2600.0000 | 1800.0000 | 1000.0000 | 47044.68 KB |        1.61 |
