```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **ChandelierExit** | **1000**  |   **237.8 μs** |  **3.95 μs** |  **2.35 μs** |       **-** |  **73.65 KB** |
| BuilderLatestOnly | ChandelierExit | 1000  |   234.2 μs |  4.71 μs |  3.12 μs |       - |  26.05 KB |
| **BuilderFull**       | **ChandelierExit** | **10000** | **2,501.6 μs** | **15.20 μs** | **10.05 μs** | **31.2500** | **706.91 KB** |
| BuilderLatestOnly | ChandelierExit | 10000 | 2,475.6 μs | 69.40 μs | 41.30 μs |       - | 237.11 KB |
