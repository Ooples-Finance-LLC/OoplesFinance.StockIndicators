```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tochF [22]** |  **2,097.5 μs** |    **59.76 μs** |    **35.56 μs** |  **1.00** |    **0.02** |  **469.99 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tochF [22] |    345.2 μs |    20.69 μs |    12.31 μs |  0.16 |    0.01 |   95.08 KB |        0.20 |
|            |       |                      |             |             |             |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)tochF [22]** | **18,760.0 μs** | **3,030.04 μs** | **2,004.18 μs** |  **1.01** |    **0.14** | **4644.49 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tochF [22] |    586.2 μs |    43.05 μs |    25.62 μs |  0.03 |    0.00 |  888.34 KB |        0.19 |
