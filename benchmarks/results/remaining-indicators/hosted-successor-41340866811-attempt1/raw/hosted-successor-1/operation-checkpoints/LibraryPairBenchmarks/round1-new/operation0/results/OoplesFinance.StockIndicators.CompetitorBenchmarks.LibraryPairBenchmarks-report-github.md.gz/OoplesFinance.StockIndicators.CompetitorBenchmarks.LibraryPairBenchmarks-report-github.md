```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId              | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |-------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Ppo** |  **3.366 ms** | **0.1074 ms** | **0.0639 ms** |  **1.00** |    **0.03** |   **1.47 MB** |        **1.00** |
|        |       |                     |           |           |           |       |         |           |             |
| **Ooples** | **10000** | **TaLib.Functions.Ppo** | **37.880 ms** | **8.6107 ms** | **5.6955 ms** |  **1.02** |    **0.20** |  **14.78 MB** |        **1.00** |
