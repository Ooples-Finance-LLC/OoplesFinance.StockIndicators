```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId             | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.T3** |   **951.5 μs** | **40.94 μs** | **27.08 μs** |  **1.00** |    **0.04** |  **105.89 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.T3 |   137.0 μs | 11.35 μs |  6.75 μs |  0.14 |    0.01 |   40.59 KB |        0.38 |
|            |       |                    |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.T3** | **2,855.5 μs** | **49.12 μs** | **25.69 μs** |  **1.00** |    **0.01** | **1037.23 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.T3 |   181.9 μs |  8.00 μs |  4.19 μs |  0.06 |    0.00 |  330.91 KB |        0.32 |
