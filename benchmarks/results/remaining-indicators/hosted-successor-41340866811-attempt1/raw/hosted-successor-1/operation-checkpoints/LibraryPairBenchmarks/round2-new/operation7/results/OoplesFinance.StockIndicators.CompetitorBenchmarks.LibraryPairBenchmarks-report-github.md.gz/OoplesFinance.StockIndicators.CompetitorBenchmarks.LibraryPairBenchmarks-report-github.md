```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)rExit [30]** |  **2.063 ms** | **0.0512 ms** | **0.0305 ms** |  **1.00** |    **0.02** |         **-** |         **-** |         **-** |   **155.14 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)rExit [30] |  8.622 ms | 0.0843 ms | 0.0557 ms |  4.18 |    0.06 |         - |         - |         - |  3536.43 KB |       22.79 |
|            |       |                      |           |           |           |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)rExit [30]** | **19.287 ms** | **4.3452 ms** | **2.5858 ms** |  **1.02** |    **0.19** |         **-** |         **-** |         **-** |  **1517.84 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)rExit [30] | 29.691 ms | 2.9919 ms | 1.5648 ms |  1.57 |    0.22 | 2000.0000 | 1000.0000 | 1000.0000 | 29572.52 KB |       19.48 |
