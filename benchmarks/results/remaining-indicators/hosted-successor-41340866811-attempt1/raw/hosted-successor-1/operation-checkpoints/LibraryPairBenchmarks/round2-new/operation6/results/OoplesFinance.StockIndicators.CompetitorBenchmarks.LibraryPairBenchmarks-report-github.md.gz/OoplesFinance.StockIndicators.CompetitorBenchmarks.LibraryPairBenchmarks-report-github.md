```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)nLine [44]** |  **1.200 ms** | **0.0524 ms** | **0.0312 ms** |  **1.00** |    **0.03** |  **194.68 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)nLine [44] |  3.217 ms | 0.1211 ms | 0.0721 ms |  2.68 |    0.09 |   966.9 KB |        4.97 |
|            |       |                      |           |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Trady(...)nLine [44]** |  **8.547 ms** | **0.3444 ms** | **0.2278 ms** |  **1.00** |    **0.04** | **2341.22 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)nLine [44] | 29.945 ms | 1.1835 ms | 0.7043 ms |  3.51 |    0.12 | 9436.22 KB |        4.03 |
