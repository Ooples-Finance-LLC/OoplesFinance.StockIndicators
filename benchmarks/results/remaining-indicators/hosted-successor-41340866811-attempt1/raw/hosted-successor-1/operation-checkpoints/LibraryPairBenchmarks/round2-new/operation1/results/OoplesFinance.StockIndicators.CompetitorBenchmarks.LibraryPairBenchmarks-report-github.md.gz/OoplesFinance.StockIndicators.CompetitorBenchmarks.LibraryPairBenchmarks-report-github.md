```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Stoch [21]** |  **2,887.9 μs** |   **207.56 μs** |   **108.56 μs** |  **1.00** |    **0.05** |  **720.57 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Stoch [21] |    330.9 μs |    29.07 μs |    17.30 μs |  0.11 |    0.01 |   97.03 KB |        0.13 |
|            |       |                      |             |             |             |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)Stoch [21]** | **29,615.8 μs** | **5,664.13 μs** | **3,746.47 μs** |  **1.02** |    **0.18** | **7145.07 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Stoch [21] |    621.0 μs |    23.75 μs |    15.71 μs |  0.02 |    0.00 |  888.09 KB |        0.12 |
