```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)chRsi [24]** |  **3,456.9 μs** |    **45.96 μs** |    **27.35 μs** |  **1.00** |    **0.01** |  **264.34 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)chRsi [24] |    393.8 μs |    19.39 μs |    12.83 μs |  0.11 |    0.00 |   89.02 KB |        0.34 |
|            |       |                      |             |             |             |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)chRsi [24]** | **33,484.2 μs** | **7,750.56 μs** | **5,126.51 μs** |  **1.02** |    **0.21** | **2610.71 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)chRsi [24] |    759.6 μs |    23.18 μs |    13.79 μs |  0.02 |    0.00 |  809.72 KB |        0.31 |
