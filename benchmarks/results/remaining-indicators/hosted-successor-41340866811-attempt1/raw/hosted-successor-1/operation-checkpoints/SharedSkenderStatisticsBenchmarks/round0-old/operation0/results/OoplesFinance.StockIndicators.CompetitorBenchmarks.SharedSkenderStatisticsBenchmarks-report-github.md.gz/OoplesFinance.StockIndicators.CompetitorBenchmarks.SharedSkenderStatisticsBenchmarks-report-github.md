```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Median    | Gen0     | Gen1     | Allocated |
|------------------ |---------------- |------ |----------:|----------:|----------:|----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetBeta** | **1000**  |  **3.869 ms** | **4.4089 ms** | **2.3060 ms** |  **2.836 ms** |        **-** |        **-** |   **1.29 MB** |
| BuilderLatestOnly | Skender.GetBeta | 1000  |  1.863 ms | 0.1985 ms | 0.1313 ms |  1.783 ms |  78.1250 |  15.6250 |   1.24 MB |
| **BuilderFull**       | **Skender.GetBeta** | **10000** | **18.900 ms** | **0.6160 ms** | **0.3222 ms** | **18.939 ms** | **666.6667** | **500.0000** |  **12.96 MB** |
| BuilderLatestOnly | Skender.GetBeta | 10000 | 19.009 ms | 0.9837 ms | 0.5145 ms | 18.961 ms | 666.6667 | 500.0000 |  12.51 MB |
