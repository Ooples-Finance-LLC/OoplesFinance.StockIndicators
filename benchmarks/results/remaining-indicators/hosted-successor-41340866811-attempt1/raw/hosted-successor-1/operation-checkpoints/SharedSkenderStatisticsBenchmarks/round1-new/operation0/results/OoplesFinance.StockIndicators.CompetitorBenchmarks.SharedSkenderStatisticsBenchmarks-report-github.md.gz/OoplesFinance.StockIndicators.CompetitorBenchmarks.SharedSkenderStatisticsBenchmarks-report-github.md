```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean      | Error     | StdDev    | Gen0     | Gen1     | Allocated |
|------------------ |---------------- |------ |----------:|----------:|----------:|---------:|---------:|----------:|
| **BuilderFull**       | **Skender.GetBeta** | **1000**  |  **3.455 ms** | **0.4728 ms** | **0.3127 ms** |        **-** |        **-** |   **1.29 MB** |
| BuilderLatestOnly | Skender.GetBeta | 1000  |  1.721 ms | 0.0719 ms | 0.0376 ms |  78.1250 |  15.6250 |   1.24 MB |
| **BuilderFull**       | **Skender.GetBeta** | **10000** | **19.071 ms** | **1.5487 ms** | **0.9216 ms** | **666.6667** | **500.0000** |  **12.96 MB** |
| BuilderLatestOnly | Skender.GetBeta | 10000 | 19.115 ms | 1.5883 ms | 1.0506 ms | 666.6667 | 500.0000 |  12.51 MB |
