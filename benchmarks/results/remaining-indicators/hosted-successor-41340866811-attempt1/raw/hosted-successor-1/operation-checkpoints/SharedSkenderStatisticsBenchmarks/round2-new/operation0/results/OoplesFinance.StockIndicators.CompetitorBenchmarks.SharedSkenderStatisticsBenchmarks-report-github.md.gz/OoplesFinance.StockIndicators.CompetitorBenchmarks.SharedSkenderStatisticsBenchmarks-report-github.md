```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error       | StdDev      | Median      | Ratio | RatioSD | Gen0      | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------------ |---------------- |------ |------------:|------------:|------------:|------------:|------:|--------:|----------:|---------:|---------:|----------:|------------:|
| **BuilderFull**       | **Skender.GetBeta** | **1000**  |  **3,920.6 μs** | **4,137.70 μs** | **2,164.10 μs** |  **2,915.9 μs** |  **7.29** |    **3.79** |         **-** |        **-** |        **-** |   **1.29 MB** |        **0.52** |
| BuilderLatestOnly | Skender.GetBeta | 1000  |  1,885.3 μs |   244.70 μs |   161.85 μs |  1,872.5 μs |  3.51 |    0.30 |   78.1250 |  15.6250 |        - |   1.24 MB |        0.50 |
| NativeSingle      | Skender.GetBeta | 1000  |    538.0 μs |    22.21 μs |    14.69 μs |    535.5 μs |  1.00 |    0.04 |  152.3438 |  42.9688 |        - |   2.47 MB |        1.00 |
| NativeParallel    | Skender.GetBeta | 1000  |    368.4 μs |    15.95 μs |    10.55 μs |    370.5 μs |  0.69 |    0.03 |  158.2031 |  46.8750 |        - |    2.5 MB |        1.01 |
|                   |                 |       |             |             |             |             |       |         |           |          |          |           |             |
| **BuilderFull**       | **Skender.GetBeta** | **10000** | **19,381.7 μs** | **1,350.24 μs** |   **893.10 μs** | **19,257.8 μs** |  **2.44** |    **0.15** |  **666.6667** | **500.0000** |        **-** |  **12.96 MB** |        **0.52** |
| BuilderLatestOnly | Skender.GetBeta | 10000 | 18,917.2 μs | 1,209.66 μs |   719.85 μs | 18,570.2 μs |  2.38 |    0.13 |  666.6667 | 500.0000 |        - |  12.51 MB |        0.50 |
| NativeSingle      | Skender.GetBeta | 10000 |  7,958.7 μs |   533.52 μs |   352.89 μs |  8,158.3 μs |  1.00 |    0.06 | 1615.3846 | 769.2308 | 153.8462 |  25.13 MB |        1.00 |
| NativeParallel    | Skender.GetBeta | 10000 |  4,965.7 μs |   665.84 μs |   440.41 μs |  4,936.2 μs |  0.63 |    0.06 | 1625.0000 | 718.7500 |  31.2500 |  25.23 MB |        1.00 |
