```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated |
|------------------ |-------------------- |------ |-----------:|----------:|----------:|---------:|---------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Ppo** | **1000**  |   **778.2 μs** | **163.82 μs** | **108.36 μs** |  **78.1250** |  **15.6250** |   **1.45 MB** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 1000  |   675.0 μs |  46.18 μs |  27.48 μs |  85.9375 |   7.8125 |   1.41 MB |
| **BuilderFull**       | **TaLib.Functions.Ppo** | **10000** | **7,303.2 μs** | **275.22 μs** | **143.95 μs** | **857.1429** | **428.5714** |   **14.4 MB** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 10000 | 7,316.5 μs | 197.20 μs | 117.35 μs | 857.1429 | 285.7143 |  13.94 MB |
