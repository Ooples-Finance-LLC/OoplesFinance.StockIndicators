```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |-------------------- |------ |-------------:|------------:|------------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Apo** | **1000**  |   **398.471 μs** | **129.4070 μs** |  **85.5947 μs** | **71.94** |   **14.76** |  **15.6250** |       **-** |   **355.3 KB** |       **22.71** |
| BuilderLatestOnly | TaLib.Functions.Apo | 1000  |   319.354 μs |  27.5114 μs |  18.1971 μs | 57.66 |    3.18 |  15.6250 |       - |  307.67 KB |       19.67 |
| NativeSingle      | TaLib.Functions.Apo | 1000  |     5.539 μs |   0.0924 μs |   0.0550 μs |  1.00 |    0.01 |   0.4883 |       - |   15.64 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Apo | 1000  |     9.871 μs |   0.1301 μs |   0.0680 μs |  1.78 |    0.02 |   3.2959 |  0.1831 |    47.7 KB |        3.05 |
|                   |                     |       |              |             |             |       |         |          |         |            |             |
| **BuilderFull**       | **TaLib.Functions.Apo** | **10000** | **2,976.634 μs** | **214.2649 μs** | **141.7230 μs** | **56.30** |    **2.56** | **187.5000** | **93.7500** | **3167.52 KB** |       **20.27** |
| BuilderLatestOnly | TaLib.Functions.Apo | 10000 | 2,972.405 μs | 194.6316 μs | 128.7368 μs | 56.22 |    2.33 | 156.2500 | 46.8750 | 2697.78 KB |       17.26 |
| NativeSingle      | TaLib.Functions.Apo | 10000 |    52.873 μs |   0.2488 μs |   0.1301 μs |  1.00 |    0.00 |   9.2773 |  1.4648 |  156.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Apo | 10000 |   103.439 μs |   4.2942 μs |   2.8403 μs |  1.96 |    0.05 |  30.2734 |  8.7891 |  469.59 KB |        3.00 |
