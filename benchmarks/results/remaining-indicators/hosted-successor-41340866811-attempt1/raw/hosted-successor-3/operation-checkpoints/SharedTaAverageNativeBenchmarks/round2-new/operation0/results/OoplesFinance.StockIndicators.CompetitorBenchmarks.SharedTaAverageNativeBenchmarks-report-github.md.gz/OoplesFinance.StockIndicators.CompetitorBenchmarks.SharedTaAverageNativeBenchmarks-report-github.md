```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |-----------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Ma** | **1000**  | **145.114 μs** | **31.1136 μs** | **20.5797 μs** | **65.73** |    **8.90** |  **3.9063** |       **-** |  **78.19 KB** |        **9.83** |
| BuilderLatestOnly | TaLib.Functions.Ma | 1000  | 112.043 μs |  6.9285 μs |  4.5828 μs | 50.75 |    2.00 |  1.9531 |       - |  30.62 KB |        3.85 |
| NativeSingle      | TaLib.Functions.Ma | 1000  |   2.208 μs |  0.0209 μs |  0.0124 μs |  1.00 |    0.01 |  0.4730 |       - |   7.95 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ma | 1000  |   4.954 μs |  0.1581 μs |  0.1046 μs |  2.24 |    0.05 |  2.0142 |  0.0916 |  28.37 KB |        3.57 |
|                   |                    |       |            |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Ma** | **10000** | **962.712 μs** | **97.9304 μs** | **58.2768 μs** | **44.60** |    **2.59** | **39.0625** | **15.6250** | **641.11 KB** |        **8.19** |
| BuilderLatestOnly | TaLib.Functions.Ma | 10000 | 944.254 μs | 89.2187 μs | 59.0127 μs | 43.75 |    2.64 |  7.8125 |       - | 171.31 KB |        2.19 |
| NativeSingle      | TaLib.Functions.Ma | 10000 |  21.586 μs |  0.3182 μs |  0.2105 μs |  1.00 |    0.01 |  4.7607 |  0.7324 |  78.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ma | 10000 |  39.181 μs |  1.9631 μs |  1.2985 μs |  1.82 |    0.06 | 18.0664 |  5.6152 | 274.46 KB |        3.51 |
