```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean         | Error       | StdDev      | Ratio  | RatioSD | Gen0     | Gen1     | Allocated   | Alloc Ratio |
|------------------ |-------------------- |------ |-------------:|------------:|------------:|-------:|--------:|---------:|---------:|------------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Ppo** | **1000**  |   **939.709 μs** | **522.9756 μs** | **273.5264 μs** | **154.67** |   **42.42** |  **62.5000** |        **-** |  **1487.38 KB** |       **95.10** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 1000  |   658.269 μs |  20.8369 μs |  10.8981 μs | 108.35 |    1.81 |  85.9375 |   7.8125 |  1439.83 KB |       92.06 |
| NativeSingle      | TaLib.Functions.Ppo | 1000  |     6.076 μs |   0.0643 μs |   0.0383 μs |   1.00 |    0.01 |   0.9155 |        - |    15.64 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ppo | 1000  |    11.756 μs |   0.3841 μs |   0.2540 μs |   1.93 |    0.04 |   3.2959 |   0.1221 |     47.7 KB |        3.05 |
|                   |                     |       |              |             |             |        |         |          |          |             |             |
| **BuilderFull**       | **TaLib.Functions.Ppo** | **10000** | **7,048.326 μs** | **236.9628 μs** | **123.9361 μs** | **118.91** |    **2.01** | **846.1538** | **384.6154** | **14748.83 KB** |       **94.38** |
| BuilderLatestOnly | TaLib.Functions.Ppo | 10000 | 7,264.768 μs | 243.5307 μs | 144.9212 μs | 122.56 |    2.35 | 846.1538 | 230.7692 | 14279.03 KB |       91.37 |
| NativeSingle      | TaLib.Functions.Ppo | 10000 |    59.274 μs |   0.3383 μs |   0.2013 μs |   1.00 |    0.00 |   9.2773 |   1.4648 |   156.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Ppo | 10000 |   109.461 μs |   5.6752 μs |   3.3772 μs |   1.85 |    0.05 |  30.2734 |   9.7656 |   469.59 KB |        3.00 |
