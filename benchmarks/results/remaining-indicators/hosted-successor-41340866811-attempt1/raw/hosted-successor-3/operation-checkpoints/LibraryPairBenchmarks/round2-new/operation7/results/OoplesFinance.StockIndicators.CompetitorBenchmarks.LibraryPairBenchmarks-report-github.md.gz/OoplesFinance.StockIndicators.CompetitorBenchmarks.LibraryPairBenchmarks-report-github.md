```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)oints [22]** |   **848.7 μs** | **42.94 μs** | **28.41 μs** |  **1.00** |    **0.04** |  **233.86 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)oints [22] | 1,449.5 μs | 31.28 μs | 16.36 μs |  1.71 |    0.06 |  513.12 KB |        2.19 |
|            |       |                      |            |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)oints [22]** | **2,241.1 μs** | **57.56 μs** | **34.25 μs** |  **1.00** |    **0.02** | **2312.98 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)oints [22] | 2,047.9 μs | 37.26 μs | 22.17 μs |  0.91 |    0.02 | 5021.91 KB |        2.17 |
