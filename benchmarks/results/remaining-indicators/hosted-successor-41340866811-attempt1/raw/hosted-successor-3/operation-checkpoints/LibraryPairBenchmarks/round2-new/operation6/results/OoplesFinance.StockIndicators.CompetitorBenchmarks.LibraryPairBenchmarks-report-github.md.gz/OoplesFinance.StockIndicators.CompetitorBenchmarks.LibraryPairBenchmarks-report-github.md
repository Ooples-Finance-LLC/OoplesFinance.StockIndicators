```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId          | Mean        | Error        | StdDev       | Median     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |---------------- |------------:|-------------:|-------------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetMacd** |  **4,957.4 μs** |     **82.69 μs** |     **54.69 μs** | **4,935.4 μs** |  **1.00** |    **0.01** |  **331.73 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetMacd |    915.3 μs |     47.78 μs |     28.43 μs |   907.2 μs |  0.18 |    0.01 |  457.02 KB |        1.38 |
|            |       |                 |             |              |              |            |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetMacd** | **20,868.8 μs** | **29,727.46 μs** | **19,662.88 μs** | **8,240.5 μs** |  **2.03** |    **2.47** | **3266.98 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetMacd |  1,351.9 μs |    199.72 μs |    104.45 μs | 1,287.1 μs |  0.13 |    0.08 | 4672.46 KB |        1.43 |
