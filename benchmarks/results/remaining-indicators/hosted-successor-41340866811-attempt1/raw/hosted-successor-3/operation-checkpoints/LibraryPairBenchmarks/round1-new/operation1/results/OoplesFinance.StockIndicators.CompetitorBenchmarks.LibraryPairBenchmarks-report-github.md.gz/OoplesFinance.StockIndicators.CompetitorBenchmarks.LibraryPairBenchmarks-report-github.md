```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean     | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |---------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skend(...)inOsc [21]** | **6.041 ms** | **0.0744 ms** | **0.0443 ms** |  **1.00** |  **259.71 KB** |        **1.00** |
|        |       |                      |          |           |           |       |            |             |
| **Ooples** | **10000** | **Skend(...)inOsc [21]** | **8.952 ms** | **0.0736 ms** | **0.0385 ms** |  **1.00** | **2553.35 KB** |        **1.00** |
