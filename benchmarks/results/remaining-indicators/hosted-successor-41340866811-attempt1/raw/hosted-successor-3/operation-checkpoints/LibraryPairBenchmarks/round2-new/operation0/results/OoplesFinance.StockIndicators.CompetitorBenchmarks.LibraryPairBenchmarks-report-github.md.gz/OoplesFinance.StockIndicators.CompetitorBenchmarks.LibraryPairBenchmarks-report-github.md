```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean       | Error       | StdDev      | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------- |-----------:|------------:|------------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetCci** | **1,957.2 μs** |    **57.04 μs** |    **37.73 μs** |  **1.00** |    **0.03** | **106.46 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetCci |   403.8 μs |    14.09 μs |     8.38 μs |  0.21 |    0.01 | 178.09 KB |        1.67 |
|            |       |                |            |             |             |       |         |           |             |
| **Ooples**     | **10000** | **Skender.GetCci** | **6,139.4 μs** | **2,812.20 μs** | **1,860.10 μs** |  **1.13** |    **0.58** | **1037.8 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetCci | 1,105.3 μs |    70.70 μs |    36.98 μs |  0.20 |    0.08 | 1698.6 KB |        1.64 |
