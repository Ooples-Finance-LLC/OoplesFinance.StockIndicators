```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId         | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetCci** |  **1.956 ms** | **0.0756 ms** | **0.0500 ms** |  **1.00** |    **0.03** | **106.46 KB** |        **1.00** |
|        |       |                |           |           |           |       |         |           |             |
| **Ooples** | **10000** | **Skender.GetCci** | **13.820 ms** | **2.9805 ms** | **1.9714 ms** |  **1.02** |    **0.19** | **1037.8 KB** |        **1.00** |
