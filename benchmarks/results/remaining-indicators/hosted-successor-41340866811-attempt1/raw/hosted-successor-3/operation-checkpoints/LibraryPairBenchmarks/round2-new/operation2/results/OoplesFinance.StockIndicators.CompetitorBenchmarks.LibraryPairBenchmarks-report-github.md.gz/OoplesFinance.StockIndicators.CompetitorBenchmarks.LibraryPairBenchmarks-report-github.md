```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error    | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|---------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)elier [21]** |  **1,801.3 μs** | **42.27 μs** | **25.15 μs** |  **1.00** |    **0.02** |  **145.82 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)elier [21] |    507.0 μs | 31.92 μs | 21.11 μs |  0.28 |    0.01 |  256.02 KB |        1.76 |
|            |       |                      |             |          |          |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)elier [21]** | **13,315.5 μs** | **65.97 μs** | **39.26 μs** |  **1.00** |    **0.00** | **1428.72 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)elier [21] |  3,072.4 μs | 44.17 μs | 26.28 μs |  0.23 |    0.00 | 2479.94 KB |        1.74 |
