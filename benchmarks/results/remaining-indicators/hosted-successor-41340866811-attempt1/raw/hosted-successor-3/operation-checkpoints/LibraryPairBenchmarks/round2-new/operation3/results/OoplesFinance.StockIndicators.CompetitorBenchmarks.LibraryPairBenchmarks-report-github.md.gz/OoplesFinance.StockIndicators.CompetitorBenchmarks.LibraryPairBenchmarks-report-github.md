```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetCmf** | **1,710.5 μs** |  **15.63 μs** |   **8.18 μs** |  **1.00** |    **0.01** |  **189.89 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetCmf |   894.0 μs |  21.95 μs |  11.48 μs |  0.52 |    0.01 |  388.08 KB |        2.04 |
|            |       |                |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetCmf** | **2,363.7 μs** | **565.87 μs** | **374.29 μs** |  **1.02** |    **0.22** |  **1841.6 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetCmf | 1,677.0 μs |  85.98 μs |  51.17 μs |  0.73 |    0.11 | 3789.77 KB |        2.06 |
