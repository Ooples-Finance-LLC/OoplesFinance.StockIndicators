```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId             | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetKeltner** |  **2.779 ms** | **0.0736 ms** | **0.0438 ms** |  **1.00** |    **0.02** |  **267.66 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetKeltner |  1.071 ms | 0.0431 ms | 0.0285 ms |  0.39 |    0.01 |  476.15 KB |        1.78 |
|            |       |                    |           |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetKeltner** | **19.293 ms** | **0.1123 ms** | **0.0587 ms** |  **1.00** |    **0.00** | **2631.61 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetKeltner |  2.040 ms | 0.0323 ms | 0.0192 ms |  0.11 |    0.00 | 4659.46 KB |        1.77 |
