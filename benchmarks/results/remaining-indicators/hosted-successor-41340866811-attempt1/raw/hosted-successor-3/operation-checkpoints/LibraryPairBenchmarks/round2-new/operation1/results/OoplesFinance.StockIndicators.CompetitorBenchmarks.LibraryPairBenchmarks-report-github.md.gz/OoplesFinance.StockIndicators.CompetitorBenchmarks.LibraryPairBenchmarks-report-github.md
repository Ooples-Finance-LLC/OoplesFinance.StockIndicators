```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error    | StdDev   | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|---------:|---------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)inOsc [21]** | **6,077.8 μs** | **92.47 μs** | **61.16 μs** |  **1.00** |  **259.71 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)inOsc [21] |   882.5 μs | 42.60 μs | 25.35 μs |  0.15 |  495.14 KB |        1.91 |
|            |       |                      |            |          |          |       |            |             |
| **Ooples**     | **10000** | **Skend(...)inOsc [21]** | **6,889.1 μs** | **59.59 μs** | **31.16 μs** |  **1.00** | **2553.07 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)inOsc [21] | 1,522.1 μs | 69.38 μs | 41.28 μs |  0.22 | 4854.52 KB |        1.90 |
