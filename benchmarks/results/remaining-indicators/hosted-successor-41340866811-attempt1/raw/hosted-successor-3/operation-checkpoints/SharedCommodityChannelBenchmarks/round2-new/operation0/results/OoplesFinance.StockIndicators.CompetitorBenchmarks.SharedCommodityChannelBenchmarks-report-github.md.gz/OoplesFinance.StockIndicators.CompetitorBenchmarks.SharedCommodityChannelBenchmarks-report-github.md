```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Cci** | **1000**  |   **265.00 μs** |  **80.520 μs** |  **53.259 μs** |  **7.97** |    **1.53** |       **-** |       **-** |  **66.79 KB** |        **8.64** |
| BuilderLatestOnly | TaLib.Functions.Cci | 1000  |   232.35 μs |  29.813 μs |  19.720 μs |  6.99 |    0.57 |       - |       - |  19.13 KB |        2.48 |
| NativeSingle      | TaLib.Functions.Cci | 1000  |    33.23 μs |   0.363 μs |   0.216 μs |  1.00 |    0.01 |  0.2441 |       - |   7.73 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Cci | 1000  |    19.46 μs |   1.634 μs |   1.081 μs |  0.59 |    0.03 |  0.4883 |       - |   8.02 KB |        1.04 |
|                   |                     |       |             |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Cci** | **10000** | **2,079.91 μs** | **201.841 μs** | **120.112 μs** |  **6.17** |    **0.35** | **31.2500** | **15.6250** |  **629.7 KB** |        **8.07** |
| BuilderLatestOnly | TaLib.Functions.Cci | 10000 | 2,075.33 μs | 231.552 μs | 153.157 μs |  6.16 |    0.44 |       - |       - | 159.88 KB |        2.05 |
| NativeSingle      | TaLib.Functions.Cci | 10000 |   337.21 μs |   7.824 μs |   5.175 μs |  1.00 |    0.02 |  3.9063 |       - |  78.05 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Cci | 10000 |   198.48 μs |  12.209 μs |   8.075 μs |  0.59 |    0.02 |  3.9063 |       - |  78.34 KB |        1.00 |
