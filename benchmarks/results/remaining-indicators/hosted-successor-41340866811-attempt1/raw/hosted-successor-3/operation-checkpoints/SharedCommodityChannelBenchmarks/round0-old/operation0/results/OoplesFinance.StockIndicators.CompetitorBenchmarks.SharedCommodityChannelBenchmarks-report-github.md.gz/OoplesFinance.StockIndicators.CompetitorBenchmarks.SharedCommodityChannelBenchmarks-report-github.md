```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |-------------------- |------ |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Cci** | **1000**  |   **330.1 μs** |  **89.45 μs** |  **59.17 μs** |       **-** |       **-** |  **66.79 KB** |
| BuilderLatestOnly | TaLib.Functions.Cci | 1000  |   237.7 μs |  23.35 μs |  15.44 μs |       - |       - |  19.13 KB |
| **BuilderFull**       | **TaLib.Functions.Cci** | **10000** | **2,070.7 μs** | **217.13 μs** | **129.21 μs** | **31.2500** | **15.6250** |  **629.7 KB** |
| BuilderLatestOnly | TaLib.Functions.Cci | 10000 | 2,148.3 μs | 256.54 μs | 169.69 μs |       - |       - | 159.88 KB |
