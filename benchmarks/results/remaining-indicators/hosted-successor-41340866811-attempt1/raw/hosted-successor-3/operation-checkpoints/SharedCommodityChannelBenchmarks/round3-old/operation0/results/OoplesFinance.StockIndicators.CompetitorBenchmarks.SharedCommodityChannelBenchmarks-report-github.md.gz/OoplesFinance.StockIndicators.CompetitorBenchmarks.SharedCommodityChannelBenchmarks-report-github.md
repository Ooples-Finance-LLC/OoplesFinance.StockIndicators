```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |-------------------- |------ |-----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Cci** | **1000**  |   **285.6 μs** |  **84.30 μs** |  **55.76 μs** |       **-** |       **-** |  **66.79 KB** |
| BuilderLatestOnly | TaLib.Functions.Cci | 1000  |   244.3 μs |  33.48 μs |  22.14 μs |       - |       - |  19.13 KB |
| **BuilderFull**       | **TaLib.Functions.Cci** | **10000** | **2,154.7 μs** | **212.53 μs** | **140.58 μs** | **31.2500** | **15.6250** |  **629.7 KB** |
| BuilderLatestOnly | TaLib.Functions.Cci | 10000 | 2,121.7 μs | 212.67 μs | 140.67 μs |       - |       - | 159.87 KB |
