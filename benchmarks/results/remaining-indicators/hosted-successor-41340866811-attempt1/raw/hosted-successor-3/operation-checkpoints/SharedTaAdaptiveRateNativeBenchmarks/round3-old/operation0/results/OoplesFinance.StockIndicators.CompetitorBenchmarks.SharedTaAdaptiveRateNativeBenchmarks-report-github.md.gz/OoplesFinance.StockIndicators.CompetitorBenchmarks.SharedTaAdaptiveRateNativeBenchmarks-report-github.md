```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Mavp** | **1000**  | **100.27 μs** | **1.077 μs** | **0.563 μs** |  **3.9063** |      **-** |  **66.38 KB** |
| BuilderLatestOnly | TaLib.Functions.Mavp | 1000  |  93.19 μs | 0.366 μs | 0.191 μs |  0.9766 |      - |  18.77 KB |
| **BuilderFull**       | **TaLib.Functions.Mavp** | **10000** | **903.82 μs** | **3.829 μs** | **2.533 μs** | **31.2500** | **7.8125** |  **629.3 KB** |
| BuilderLatestOnly | TaLib.Functions.Mavp | 10000 | 880.51 μs | 4.294 μs | 2.246 μs |  7.8125 |      - | 159.46 KB |
