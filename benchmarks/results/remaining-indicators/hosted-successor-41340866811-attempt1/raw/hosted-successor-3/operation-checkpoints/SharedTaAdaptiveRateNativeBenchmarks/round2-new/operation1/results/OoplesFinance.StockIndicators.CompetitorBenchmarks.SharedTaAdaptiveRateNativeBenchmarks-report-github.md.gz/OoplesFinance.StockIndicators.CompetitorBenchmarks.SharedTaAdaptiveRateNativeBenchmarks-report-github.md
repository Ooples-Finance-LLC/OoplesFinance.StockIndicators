```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Trix** | **1000**  |   **528.76 μs** |   **4.564 μs** |  **2.716 μs** | **50.50** |    **0.40** |       **-** |      **-** |  **89.26 KB** |        **5.76** |
| BuilderLatestOnly | TaLib.Functions.Trix | 1000  |   512.96 μs |   2.647 μs |  1.575 μs | 48.99 |    0.34 |       - |      - |   41.6 KB |        2.69 |
| NativeSingle      | TaLib.Functions.Trix | 1000  |    10.47 μs |   0.106 μs |  0.070 μs |  1.00 |    0.01 |  0.9155 |      - |  15.48 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Trix | 1000  |    14.77 μs |   0.504 μs |  0.300 μs |  1.41 |    0.03 |  3.2959 | 0.1221 |   47.6 KB |        3.07 |
|                   |                      |       |             |            |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Trix** | **10000** | **5,355.06 μs** | **146.527 μs** | **96.919 μs** | **50.53** |    **0.92** | **31.2500** |      **-** | **863.23 KB** |        **5.53** |
| BuilderLatestOnly | TaLib.Functions.Trix | 10000 | 5,263.34 μs |  24.269 μs | 14.442 μs | 49.66 |    0.32 |       - |      - | 393.39 KB |        2.52 |
| NativeSingle      | TaLib.Functions.Trix | 10000 |   105.98 μs |   0.981 μs |  0.649 μs |  1.00 |    0.01 |  8.7891 | 0.9766 | 156.12 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Trix | 10000 |   161.78 μs |   7.568 μs |  5.006 μs |  1.53 |    0.05 | 30.2734 | 9.7656 | 469.48 KB |        3.01 |
