```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error    | StdDev   | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |----------:|---------:|---------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Mavp** | **1000**  | **106.09 μs** | **1.138 μs** | **0.677 μs** |  **3.91** |    **0.02** |  **3.9063** |       **-** |  **66.38 KB** |        **3.34** |
| BuilderLatestOnly | TaLib.Functions.Mavp | 1000  |  95.89 μs | 0.887 μs | 0.464 μs |  3.54 |    0.02 |  0.9766 |       - |  18.77 KB |        0.94 |
| NativeSingle      | TaLib.Functions.Mavp | 1000  |  27.13 μs | 0.084 μs | 0.044 μs |  1.00 |    0.00 |  0.9766 |       - |   19.9 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mavp | 1000  |  43.51 μs | 2.112 μs | 1.397 μs |  1.60 |    0.05 |  4.1504 |  0.2441 |   59.1 KB |        2.97 |
|                   |                      |       |           |          |          |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib.Functions.Mavp** | **10000** | **923.98 μs** | **1.736 μs** | **1.033 μs** |  **2.94** |    **0.04** | **31.2500** |  **7.8125** | **629.29 KB** |        **3.22** |
| BuilderLatestOnly | TaLib.Functions.Mavp | 10000 | 911.44 μs | 6.033 μs | 3.155 μs |  2.90 |    0.04 |  7.8125 |       - | 159.46 KB |        0.81 |
| NativeSingle      | TaLib.Functions.Mavp | 10000 | 314.64 μs | 6.746 μs | 4.462 μs |  1.00 |    0.02 | 11.7188 |  1.9531 | 195.69 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Mavp | 10000 | 418.87 μs | 6.462 μs | 3.380 μs |  1.33 |    0.02 | 35.1563 | 11.7188 | 568.89 KB |        2.91 |
