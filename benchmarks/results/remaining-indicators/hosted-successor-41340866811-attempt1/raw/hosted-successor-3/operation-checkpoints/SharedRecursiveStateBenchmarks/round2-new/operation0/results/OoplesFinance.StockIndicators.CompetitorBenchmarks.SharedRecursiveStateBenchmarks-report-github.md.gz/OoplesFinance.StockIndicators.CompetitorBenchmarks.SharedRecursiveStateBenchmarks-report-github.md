```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean         | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |---------- |------ |-------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **Ad**        | **1000**  |   **138.171 μs** | **8.4742 μs** | **5.0429 μs** | **60.35** |    **2.11** |  **3.9063** |      **-** |  **64.88 KB** |        **8.24** |
| BuilderLatestOnly | Ad        | 1000  |   132.404 μs | 1.8805 μs | 1.1191 μs | 57.83 |    0.53 |  0.9766 |      - |  17.27 KB |        2.19 |
| NativeSingle      | Ad        | 1000  |     2.289 μs | 0.0177 μs | 0.0105 μs |  1.00 |    0.01 |  0.4730 |      - |   7.88 KB |        1.00 |
| NativeParallel    | Ad        | 1000  |     5.434 μs | 0.3937 μs | 0.2343 μs |  2.37 |    0.10 |  0.4883 |      - |   8.16 KB |        1.04 |
|                   |           |       |              |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **Ad**        | **10000** | **1,228.210 μs** | **9.6739 μs** | **5.7568 μs** | **58.44** |    **0.28** | **31.2500** | **7.8125** | **627.79 KB** |        **8.03** |
| BuilderLatestOnly | Ad        | 10000 | 1,255.014 μs | 4.8652 μs | 2.5446 μs | 59.71 |    0.16 |  7.8125 |      - | 157.96 KB |        2.02 |
| NativeSingle      | Ad        | 10000 |    21.017 μs | 0.0827 μs | 0.0432 μs |  1.00 |    0.00 |  4.7607 | 0.8545 |  78.19 KB |        1.00 |
| NativeParallel    | Ad        | 10000 |    41.836 μs | 5.0833 μs | 3.3623 μs |  1.99 |    0.15 |  4.6387 | 0.7324 |  78.48 KB |        1.00 |
