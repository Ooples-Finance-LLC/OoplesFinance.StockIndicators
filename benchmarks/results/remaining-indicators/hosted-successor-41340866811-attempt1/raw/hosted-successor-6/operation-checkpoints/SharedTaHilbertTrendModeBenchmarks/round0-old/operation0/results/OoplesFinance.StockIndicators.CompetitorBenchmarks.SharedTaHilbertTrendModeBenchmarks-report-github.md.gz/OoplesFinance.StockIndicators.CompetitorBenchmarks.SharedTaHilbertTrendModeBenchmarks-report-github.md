```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **4.972 ms** | **2.9751 ms** | **1.9678 ms** |  **71.75 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  2.567 ms | 0.0256 ms | 0.0134 ms |  24.07 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **26.383 ms** | **0.0728 ms** | **0.0433 ms** | **636.42 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 26.432 ms | 0.0987 ms | 0.0587 ms |  166.6 KB |
