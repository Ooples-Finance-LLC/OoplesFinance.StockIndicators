```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **3,897.0 μs** |  **42.59 μs** |  **25.35 μs** |  **6.69** |    **0.04** |  **71.71 KB** |       **15.15** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  2,589.7 μs |  19.84 μs |  11.81 μs |  4.45 |    0.02 |  24.06 KB |        5.08 |
| NativeSingle      | TaLib(...)dMode [27] | 1000  |    582.3 μs |   2.19 μs |   1.31 μs |  1.00 |    0.00 |   4.73 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 1000  |    787.5 μs |  57.27 μs |  37.88 μs |  1.35 |    0.06 |   17.4 KB |        3.68 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **26,792.6 μs** | **184.26 μs** | **109.65 μs** |  **4.22** |    **0.02** | **636.42 KB** |       **15.78** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 26,824.2 μs | 126.98 μs |  66.41 μs |  4.23 |    0.02 |  166.6 KB |        4.13 |
| NativeSingle      | TaLib(...)dMode [27] | 10000 |  6,347.3 μs |  27.09 μs |  17.92 μs |  1.00 |    0.00 |  40.33 KB |        1.00 |
| NativeParallel    | TaLib(...)dMode [27] | 10000 |  8,022.6 μs | 269.39 μs | 140.90 μs |  1.26 |    0.02 | 141.02 KB |        3.50 |
