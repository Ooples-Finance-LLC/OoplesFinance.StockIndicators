```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|----------:|
| **BuilderFull**       | **TaLib(...)dMode [27]** | **1000**  |  **2.637 ms** | **0.0729 ms** | **0.0381 ms** |  **71.71 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 1000  |  2.601 ms | 0.0569 ms | 0.0339 ms |  24.07 KB |
| **BuilderFull**       | **TaLib(...)dMode [27]** | **10000** | **26.625 ms** | **0.0641 ms** | **0.0382 ms** | **636.41 KB** |
| BuilderLatestOnly | TaLib(...)dMode [27] | 10000 | 26.509 ms | 0.0700 ms | 0.0366 ms | 166.68 KB |
