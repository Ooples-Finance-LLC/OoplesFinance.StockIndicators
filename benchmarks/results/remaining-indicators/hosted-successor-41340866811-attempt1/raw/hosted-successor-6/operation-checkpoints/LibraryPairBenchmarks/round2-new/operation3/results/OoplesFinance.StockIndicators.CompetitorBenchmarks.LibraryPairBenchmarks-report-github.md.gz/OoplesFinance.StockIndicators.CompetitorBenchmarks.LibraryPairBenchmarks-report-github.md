```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId             | Mean       | Error     | StdDev   | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |------------------- |-----------:|----------:|---------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Dx** | **3,600.7 μs** |  **55.88 μs** | **36.96 μs** |  **1.00** |  **105.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Dx |   258.4 μs |  10.54 μs |  6.27 μs |  0.07 |   40.88 KB |        0.39 |
|            |       |                    |            |           |          |       |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Dx** | **7,371.1 μs** | **112.61 μs** | **67.01 μs** |  **1.00** | **1036.77 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Dx |   376.2 μs |  30.44 μs | 20.13 μs |  0.05 |  330.92 KB |        0.32 |
