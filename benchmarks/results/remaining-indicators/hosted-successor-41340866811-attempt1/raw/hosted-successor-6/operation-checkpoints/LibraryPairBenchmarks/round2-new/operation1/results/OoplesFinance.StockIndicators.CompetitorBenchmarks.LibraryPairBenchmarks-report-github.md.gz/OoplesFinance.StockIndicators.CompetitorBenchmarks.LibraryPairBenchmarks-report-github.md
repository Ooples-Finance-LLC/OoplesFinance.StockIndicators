```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|------------:|----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Beta** | **6,149.2 μs** |   **452.83 μs** | **299.52 μs** |  **1.00** |    **0.06** | **108.47 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Beta |   183.2 μs |    17.75 μs |  11.74 μs |  0.03 |    0.00 |  41.14 KB |        0.38 |
|            |       |                      |            |             |           |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Beta** | **6,885.1 μs** | **1,546.24 μs** | **920.14 μs** |  **1.01** |    **0.17** | **1039.8 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Beta |   210.2 μs |    64.18 μs |  42.45 μs |  0.03 |    0.01 | 331.18 KB |        0.32 |
