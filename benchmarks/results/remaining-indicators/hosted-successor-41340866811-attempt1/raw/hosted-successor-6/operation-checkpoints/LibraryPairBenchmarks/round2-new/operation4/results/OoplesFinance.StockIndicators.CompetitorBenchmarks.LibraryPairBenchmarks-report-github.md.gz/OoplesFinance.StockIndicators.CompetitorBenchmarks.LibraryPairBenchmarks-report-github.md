```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)Phase [25]** | **18.669 ms** | **0.0598 ms** | **0.0356 ms** |  **1.00** |  **110.13 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)Phase [25] |  1.979 ms | 0.0306 ms | 0.0182 ms |  0.11 |    41.8 KB |        0.38 |
|            |       |                      |           |           |           |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)Phase [25]** | **19.152 ms** | **0.1565 ms** | **0.0931 ms** |  **1.00** | **1041.47 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)Phase [25] |  5.739 ms | 0.0325 ms | 0.0170 ms |  0.30 |  330.81 KB |        0.32 |
