```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId              | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |-------------------- |-----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Cci** | **1,944.7 μs** | **54.35 μs** | **32.35 μs** |  **1.00** |    **0.02** | **106.46 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Cci |   415.3 μs | 12.20 μs |  8.07 μs |  0.21 |    0.01 |  40.73 KB |        0.38 |
|            |       |                     |            |          |          |       |         |           |             |
| **Ooples**     | **10000** | **TaLib.Functions.Cci** | **2,716.5 μs** | **55.30 μs** | **32.91 μs** |  **1.00** |    **0.02** | **1037.8 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Cci |   467.7 μs | 62.76 μs | 32.82 μs |  0.17 |    0.01 |  331.1 KB |        0.32 |
