```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)tSine [22]** | **18.314 ms** | **0.1559 ms** | **0.0928 ms** |  **1.00** |  **166.54 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)tSine [22] |  1.976 ms | 0.0228 ms | 0.0136 ms |  0.11 |   74.28 KB |        0.45 |
|            |       |                      |           |           |           |       |            |             |
| **Ooples**     | **10000** | **TaLib(...)tSine [22]** | **19.594 ms** | **0.2988 ms** | **0.1563 ms** |  **1.00** | **1598.52 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)tSine [22] |  6.039 ms | 0.0838 ms | 0.0499 ms |  0.31 |  653.66 KB |        0.41 |
