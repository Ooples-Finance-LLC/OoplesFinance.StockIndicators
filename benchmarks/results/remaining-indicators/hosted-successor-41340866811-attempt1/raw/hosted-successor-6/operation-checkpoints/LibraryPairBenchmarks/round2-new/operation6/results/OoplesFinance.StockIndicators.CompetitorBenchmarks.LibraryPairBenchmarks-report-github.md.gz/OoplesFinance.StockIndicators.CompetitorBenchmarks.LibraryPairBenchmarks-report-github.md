```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | Allocated | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)dMode [27]** | **24.997 ms** | **0.2486 ms** | **0.1645 ms** |  **1.00** | **112.75 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)dMode [27] |  2.263 ms | 0.0260 ms | 0.0172 ms |  0.09 |  38.18 KB |        0.34 |
|            |       |                      |           |           |           |       |           |             |
| **Ooples**     | **10000** | **TaLib(...)dMode [27]** | **26.505 ms** | **0.2148 ms** | **0.1123 ms** |  **1.00** | **1043.8 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)dMode [27] |  6.472 ms | 0.0409 ms | 0.0271 ms |  0.24 | 292.78 KB |        0.28 |
