```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)lysis [22]** | **1000**  |   **303.67 μs** |   **5.017 μs** |   **2.624 μs** |  **3.80** |    **0.03** |        **-** |        **-** |       **-** |  **144.21 KB** |        **0.78** |
| BuilderLatestOnly | Skend(...)lysis [22] | 1000  |   281.55 μs |  36.115 μs |  23.888 μs |  3.52 |    0.29 |   5.8594 |        - |       - |   96.56 KB |        0.52 |
| NativeSingle      | Skend(...)lysis [22] | 1000  |    79.95 μs |   0.516 μs |   0.341 μs |  1.00 |    0.01 |  11.2305 |   2.4414 |       - |  184.11 KB |        1.00 |
| NativeParallel    | Skend(...)lysis [22] | 1000  |    58.58 μs |   5.137 μs |   3.398 μs |  0.73 |    0.04 |  13.1836 |   3.4180 |       - |  204.15 KB |        1.11 |
|                   |                      |       |             |            |            |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)lysis [22]** | **10000** | **2,682.72 μs** | **261.177 μs** | **172.753 μs** |  **2.08** |    **0.19** |  **62.5000** |  **31.2500** |       **-** | **1272.62 KB** |        **0.69** |
| BuilderLatestOnly | Skend(...)lysis [22] | 10000 | 2,659.92 μs | 269.374 μs | 160.300 μs |  2.07 |    0.19 |  46.8750 |  15.6250 |       - |  802.79 KB |        0.44 |
| NativeSingle      | Skend(...)lysis [22] | 10000 | 1,294.32 μs | 146.123 μs |  96.651 μs |  1.00 |    0.10 | 171.8750 | 125.0000 | 85.9375 | 1837.32 KB |        1.00 |
| NativeParallel    | Skend(...)lysis [22] | 10000 |   554.61 μs |  58.063 μs |  38.405 μs |  0.43 |    0.04 | 121.0938 |  54.6875 |       - | 1926.84 KB |        1.05 |
