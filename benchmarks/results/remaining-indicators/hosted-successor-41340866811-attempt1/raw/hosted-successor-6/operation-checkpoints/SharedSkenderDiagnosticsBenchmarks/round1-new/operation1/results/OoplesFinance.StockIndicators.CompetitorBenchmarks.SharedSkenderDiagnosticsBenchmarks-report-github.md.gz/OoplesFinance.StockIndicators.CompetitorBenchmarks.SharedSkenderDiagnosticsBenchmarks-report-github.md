```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Skend(...)lysis [22]** | **1000**  |   **373.5 μs** | **116.68 μs** |  **77.18 μs** |       **-** |       **-** |  **144.21 KB** |
| BuilderLatestOnly | Skend(...)lysis [22] | 1000  |   292.4 μs |  30.27 μs |  20.02 μs |  5.8594 |       - |   96.56 KB |
| **BuilderFull**       | **Skend(...)lysis [22]** | **10000** | **2,702.2 μs** | **295.18 μs** | **195.25 μs** | **62.5000** | **31.2500** | **1272.56 KB** |
| BuilderLatestOnly | Skend(...)lysis [22] | 10000 | 2,689.7 μs | 237.20 μs | 156.89 μs | 46.8750 | 15.6250 |   802.8 KB |
