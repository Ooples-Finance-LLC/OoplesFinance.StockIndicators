```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |--------------- |------ |-----------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetPrs** | **1000**  |   **620.9 μs** | **113.65 μs** |  **75.17 μs** |  **46.8750** |        **-** |  **991.03 KB** |
| BuilderLatestOnly | Skender.GetPrs | 1000  |   597.7 μs |  59.03 μs |  39.04 μs |  54.6875 |   7.8125 |  943.49 KB |
| **BuilderFull**       | **Skender.GetPrs** | **10000** | **5,501.7 μs** | **688.36 μs** | **455.30 μs** | **562.5000** | **281.2500** | **9429.53 KB** |
| BuilderLatestOnly | Skender.GetPrs | 10000 | 5,738.4 μs | 217.12 μs | 143.61 μs | 531.2500 | 250.0000 | 8959.74 KB |
