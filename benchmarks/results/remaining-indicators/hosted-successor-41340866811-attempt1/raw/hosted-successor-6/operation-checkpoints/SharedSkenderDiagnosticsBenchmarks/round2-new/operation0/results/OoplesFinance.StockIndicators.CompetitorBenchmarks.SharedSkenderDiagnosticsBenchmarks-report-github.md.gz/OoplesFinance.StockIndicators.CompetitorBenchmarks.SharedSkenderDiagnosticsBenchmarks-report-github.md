```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetPrs** | **1000**  |   **531.63 μs** | **146.393 μs** |  **96.830 μs** | **10.49** |    **1.82** |  **46.8750** |        **-** |        **-** |     **991 KB** |        **6.01** |
| BuilderLatestOnly | Skender.GetPrs | 1000  |   429.21 μs |  50.716 μs |  33.545 μs |  8.47 |    0.64 |  54.6875 |   7.8125 |        - |  943.45 KB |        5.73 |
| NativeSingle      | Skender.GetPrs | 1000  |    50.69 μs |   0.735 μs |   0.437 μs |  1.00 |    0.01 |   9.7656 |   1.4648 |        - |  164.79 KB |        1.00 |
| NativeParallel    | Skender.GetPrs | 1000  |    37.96 μs |   2.189 μs |   1.448 μs |  0.75 |    0.03 |  12.6953 |   2.9297 |        - |  184.81 KB |        1.12 |
|                   |                |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetPrs** | **10000** | **4,122.98 μs** | **353.145 μs** | **233.583 μs** |  **5.45** |    **0.33** | **562.5000** | **281.2500** |        **-** | **9429.51 KB** |        **5.74** |
| BuilderLatestOnly | Skender.GetPrs | 10000 | 4,077.16 μs | 356.765 μs | 235.978 μs |  5.39 |    0.33 | 531.2500 | 250.0000 |        - | 8959.74 KB |        5.45 |
| NativeSingle      | Skender.GetPrs | 10000 |   757.15 μs |  37.158 μs |  22.112 μs |  1.00 |    0.04 | 218.7500 | 171.8750 | 160.1563 | 1643.47 KB |        1.00 |
| NativeParallel    | Skender.GetPrs | 10000 |   395.22 μs |  29.919 μs |  19.790 μs |  0.52 |    0.03 | 113.2813 |  52.7344 |        - |  1731.7 KB |        1.05 |
