```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **528.0 μs** |  **3.44 μs** |  **2.05 μs** |       **-** | **128.54 KB** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   531.8 μs |  1.91 μs |  1.14 μs |  3.9063 |  80.87 KB |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **5,298.9 μs** | **65.52 μs** | **43.34 μs** | **62.5000** | **1254.1 KB** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 5,320.5 μs | 27.45 μs | 16.33 μs | 31.2500 | 784.28 KB |
