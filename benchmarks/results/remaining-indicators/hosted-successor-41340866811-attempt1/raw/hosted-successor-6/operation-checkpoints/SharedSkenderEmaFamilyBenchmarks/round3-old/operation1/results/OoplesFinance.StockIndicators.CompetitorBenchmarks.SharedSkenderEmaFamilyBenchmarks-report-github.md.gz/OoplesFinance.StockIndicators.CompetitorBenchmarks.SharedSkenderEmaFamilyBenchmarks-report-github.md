```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev    | Allocated  |
|------------------ |--------------- |------ |-----------:|----------:|----------:|-----------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **686.3 μs** |   **3.69 μs** |   **2.20 μs** |  **105.05 KB** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   674.4 μs |   6.54 μs |   3.89 μs |   57.39 KB |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **6,880.0 μs** |  **28.40 μs** |  **16.90 μs** | **1019.84 KB** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 6,952.4 μs | 208.29 μs | 137.77 μs |  550.09 KB |
