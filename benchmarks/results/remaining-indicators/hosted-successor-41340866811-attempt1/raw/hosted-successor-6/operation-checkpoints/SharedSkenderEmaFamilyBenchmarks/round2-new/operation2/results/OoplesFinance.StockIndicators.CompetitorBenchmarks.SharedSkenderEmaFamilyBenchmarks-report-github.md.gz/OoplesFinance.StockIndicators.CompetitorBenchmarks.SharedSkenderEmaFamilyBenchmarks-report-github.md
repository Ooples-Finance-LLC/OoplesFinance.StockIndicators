```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetTrix** | **1000**  |   **964.50 μs** |   **4.233 μs** |   **2.519 μs** | **29.49** |    **0.48** |        **-** |        **-** |        **-** |   **89.26 KB** |        **0.73** |
| BuilderLatestOnly | Skender.GetTrix | 1000  |   526.04 μs |   5.234 μs |   2.737 μs | 16.08 |    0.27 |        - |        - |        - |    41.6 KB |        0.34 |
| NativeSingle      | Skender.GetTrix | 1000  |    32.71 μs |   0.843 μs |   0.557 μs |  1.00 |    0.02 |   7.3242 |   1.7090 |        - |  121.49 KB |        1.00 |
| NativeParallel    | Skender.GetTrix | 1000  |    64.32 μs |   0.946 μs |   0.563 μs |  1.97 |    0.04 |  20.5078 |   5.8594 |        - |  312.32 KB |        2.57 |
|                   |                 |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetTrix** | **10000** | **5,333.58 μs** | **244.975 μs** | **162.036 μs** |  **9.52** |    **0.32** |  **31.2500** |        **-** |        **-** |  **863.17 KB** |        **0.71** |
| BuilderLatestOnly | Skender.GetTrix | 10000 | 5,236.89 μs |  50.762 μs |  30.208 μs |  9.34 |    0.17 |        - |        - |        - |   393.4 KB |        0.32 |
| NativeSingle      | Skender.GetTrix | 10000 |   560.59 μs |  17.483 μs |  10.404 μs |  1.00 |    0.02 |  97.6563 |  97.6563 |  97.6563 | 1212.12 KB |        1.00 |
| NativeParallel    | Skender.GetTrix | 10000 | 1,880.66 μs | 169.075 μs |  88.429 μs |  3.36 |    0.16 | 296.8750 | 250.0000 | 156.2500 | 3109.32 KB |        2.57 |
