```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **659.99 μs** |   **7.932 μs** |   **4.720 μs** |  **9.46** |    **0.23** |        **-** |        **-** |        **-** |  **105.05 KB** |        **0.37** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   637.41 μs |   2.293 μs |   1.364 μs |  9.14 |    0.22 |        - |        - |        - |   57.39 KB |        0.20 |
| NativeSingle      | Skender.GetPvo | 1000  |    69.79 μs |   2.643 μs |   1.748 μs |  1.00 |    0.03 |  17.0898 |   3.4180 |        - |  285.61 KB |        1.00 |
| NativeParallel    | Skender.GetPvo | 1000  |   135.78 μs |   6.617 μs |   3.937 μs |  1.95 |    0.07 |  46.8750 |  16.6016 |        - |  729.53 KB |        2.55 |
|                   |                |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **6,438.77 μs** |  **68.705 μs** |  **40.885 μs** |  **5.45** |    **0.17** |        **-** |        **-** |        **-** | **1019.89 KB** |        **0.33** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 6,407.98 μs |  20.782 μs |  10.869 μs |  5.42 |    0.17 |        - |        - |        - |  550.06 KB |        0.18 |
| NativeSingle      | Skender.GetPvo | 10000 | 1,183.00 μs |  58.155 μs |  38.466 μs |  1.00 |    0.04 | 164.0625 | 164.0625 | 164.0625 | 3052.21 KB |        1.00 |
| NativeParallel    | Skender.GetPvo | 10000 | 3,580.79 μs | 434.583 μs | 287.450 μs |  3.03 |    0.25 | 625.0000 | 500.0000 | 250.0000 | 7581.96 KB |        2.48 |
