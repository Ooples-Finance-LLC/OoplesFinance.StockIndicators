```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |---------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **554.4 μs** |  **6.00 μs** |  **3.57 μs** |       **-** | **128.54 KB** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   559.1 μs | 10.75 μs |  7.11 μs |  3.9063 |   80.9 KB |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **5,489.5 μs** | **63.66 μs** | **37.88 μs** | **62.5000** | **1254.1 KB** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 5,457.3 μs | 11.27 μs |  6.71 μs | 31.2500 | 784.28 KB |
