```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated  |
|------------------ |--------------- |------ |-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **720.0 μs** | **10.65 μs** |  **6.34 μs** |  **105.05 KB** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   689.0 μs |  1.54 μs |  0.92 μs |   57.39 KB |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **6,848.2 μs** | **35.92 μs** | **21.37 μs** | **1019.87 KB** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 6,889.0 μs | 45.59 μs | 30.16 μs |  550.09 KB |
