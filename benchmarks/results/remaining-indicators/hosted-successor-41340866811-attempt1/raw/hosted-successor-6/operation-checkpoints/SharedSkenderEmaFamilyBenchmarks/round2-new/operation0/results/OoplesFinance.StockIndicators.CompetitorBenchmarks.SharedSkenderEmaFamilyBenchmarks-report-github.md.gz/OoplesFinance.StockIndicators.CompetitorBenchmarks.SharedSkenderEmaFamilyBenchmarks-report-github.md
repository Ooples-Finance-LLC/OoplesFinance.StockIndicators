```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation       | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |---------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetMacd** | **1000**  |   **530.91 μs** |   **4.061 μs** |   **2.124 μs** |  **8.70** |    **0.17** |        **-** |        **-** |        **-** |  **128.54 KB** |        **0.40** |
| BuilderLatestOnly | Skender.GetMacd | 1000  |   529.51 μs |   4.570 μs |   2.720 μs |  8.68 |    0.17 |   3.9063 |        - |        - |    80.9 KB |        0.25 |
| NativeSingle      | Skender.GetMacd | 1000  |    61.06 μs |   2.104 μs |   1.252 μs |  1.00 |    0.03 |  19.5313 |   6.3477 |        - |  324.54 KB |        1.00 |
| NativeParallel    | Skender.GetMacd | 1000  |   125.42 μs |   8.317 μs |   5.501 μs |  2.05 |    0.09 |  53.7109 |  19.5313 |        - |  826.63 KB |        2.55 |
|                   |                 |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetMacd** | **10000** | **5,486.33 μs** | **134.631 μs** |  **89.050 μs** |  **4.55** |    **0.11** |  **62.5000** |        **-** |        **-** |  **1254.1 KB** |        **0.36** |
| BuilderLatestOnly | Skender.GetMacd | 10000 | 5,327.59 μs |  28.125 μs |  16.737 μs |  4.41 |    0.09 |  31.2500 |        - |        - |  784.27 KB |        0.23 |
| NativeSingle      | Skender.GetMacd | 10000 | 1,207.25 μs |  42.595 μs |  25.348 μs |  1.00 |    0.03 | 218.7500 | 218.7500 | 218.7500 | 3443.12 KB |        1.00 |
| NativeParallel    | Skender.GetMacd | 10000 | 4,343.89 μs | 777.406 μs | 514.206 μs |  3.60 |    0.41 | 750.0000 | 625.0000 | 312.5000 |  8556.7 KB |        2.49 |
