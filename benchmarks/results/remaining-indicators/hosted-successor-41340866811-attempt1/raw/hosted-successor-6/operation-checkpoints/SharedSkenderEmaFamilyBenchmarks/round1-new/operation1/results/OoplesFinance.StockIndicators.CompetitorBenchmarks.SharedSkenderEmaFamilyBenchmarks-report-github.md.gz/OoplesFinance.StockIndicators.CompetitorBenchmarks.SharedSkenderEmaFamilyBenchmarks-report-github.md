```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error    | StdDev   | Allocated  |
|------------------ |--------------- |------ |-----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **Skender.GetPvo** | **1000**  |   **675.2 μs** | **11.76 μs** |  **7.00 μs** |  **105.05 KB** |
| BuilderLatestOnly | Skender.GetPvo | 1000  |   650.2 μs |  4.84 μs |  2.88 μs |   57.39 KB |
| **BuilderFull**       | **Skender.GetPvo** | **10000** | **6,491.6 μs** | **28.75 μs** | **17.11 μs** | **1019.84 KB** |
| BuilderLatestOnly | Skender.GetPvo | 10000 | 6,710.1 μs | 74.01 μs | 44.04 μs |  550.07 KB |
