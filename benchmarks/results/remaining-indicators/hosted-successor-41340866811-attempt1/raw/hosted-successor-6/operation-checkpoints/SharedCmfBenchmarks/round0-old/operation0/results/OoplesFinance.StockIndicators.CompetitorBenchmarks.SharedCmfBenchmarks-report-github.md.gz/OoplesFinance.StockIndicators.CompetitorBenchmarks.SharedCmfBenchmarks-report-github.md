```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error      | StdDev     | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|-----------:|-----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetCmf** | **1000**  |  **83.29 μs** |   **8.964 μs** |   **5.929 μs** |  **3.9063** |       **-** |  **85.73 KB** |
| BuilderLatestOnly | Skender.GetCmf | 1000  |  75.77 μs |   4.189 μs |   2.493 μs |  1.9531 |       - |  38.12 KB |
| **BuilderFull**       | **Skender.GetCmf** | **10000** | **542.17 μs** |  **76.333 μs** |  **50.490 μs** | **46.8750** | **19.5313** | **789.24 KB** |
| BuilderLatestOnly | Skender.GetCmf | 10000 | 676.36 μs | 285.080 μs | 188.563 μs | 15.6250 |  3.9063 | 319.41 KB |
