```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetCmf** | **1000**  | **108.06 μs** |  **2.672 μs** |  **1.590 μs** |  **3.9063** |       **-** |  **85.77 KB** |
| BuilderLatestOnly | Skender.GetCmf | 1000  |  73.25 μs |  6.994 μs |  4.626 μs |  1.9531 |       - |  38.12 KB |
| **BuilderFull**       | **Skender.GetCmf** | **10000** | **515.65 μs** | **18.146 μs** |  **9.491 μs** | **46.8750** | **15.6250** | **789.24 KB** |
| BuilderLatestOnly | Skender.GetCmf | 10000 | 546.60 μs | 89.443 μs | 59.161 μs | 15.6250 |  3.9063 | 319.41 KB |
