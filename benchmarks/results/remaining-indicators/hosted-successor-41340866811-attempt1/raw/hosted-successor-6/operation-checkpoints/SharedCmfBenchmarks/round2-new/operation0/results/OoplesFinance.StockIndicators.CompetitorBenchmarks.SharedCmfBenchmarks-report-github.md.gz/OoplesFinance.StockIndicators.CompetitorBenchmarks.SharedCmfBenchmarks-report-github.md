```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetCmf** | **1000**  |    **86.29 μs** |  **8.959 μs** |  **5.331 μs** |  **0.65** |    **0.04** |   **3.9063** |        **-** |       **-** |   **85.73 KB** |        **0.29** |
| BuilderLatestOnly | Skender.GetCmf | 1000  |    76.05 μs |  7.748 μs |  5.125 μs |  0.58 |    0.04 |   1.9531 |        - |       - |   38.12 KB |        0.13 |
| NativeSingle      | Skender.GetCmf | 1000  |   132.24 μs |  6.533 μs |  3.888 μs |  1.00 |    0.04 |  17.5781 |   4.8828 |       - |   297.9 KB |        1.00 |
| NativeParallel    | Skender.GetCmf | 1000  |    89.39 μs |  7.018 μs |  4.176 μs |  0.68 |    0.04 |  20.5078 |   5.8594 |       - |   326.3 KB |        1.10 |
|                   |                |       |             |           |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skender.GetCmf** | **10000** |   **543.64 μs** | **69.508 μs** | **45.975 μs** |  **0.33** |    **0.03** |  **46.8750** |  **19.5313** |       **-** |  **789.24 KB** |        **0.27** |
| BuilderLatestOnly | Skender.GetCmf | 10000 |   500.33 μs | 28.537 μs | 14.925 μs |  0.30 |    0.01 |  15.6250 |   3.9063 |       - |  319.41 KB |        0.11 |
| NativeSingle      | Skender.GetCmf | 10000 | 1,659.98 μs | 25.149 μs | 14.966 μs |  1.00 |    0.01 | 187.5000 | 140.6250 | 46.8750 | 2970.25 KB |        1.00 |
| NativeParallel    | Skender.GetCmf | 10000 |   873.78 μs | 77.515 μs | 46.128 μs |  0.53 |    0.03 | 195.3125 | 109.3750 |       - | 3068.54 KB |        1.03 |
