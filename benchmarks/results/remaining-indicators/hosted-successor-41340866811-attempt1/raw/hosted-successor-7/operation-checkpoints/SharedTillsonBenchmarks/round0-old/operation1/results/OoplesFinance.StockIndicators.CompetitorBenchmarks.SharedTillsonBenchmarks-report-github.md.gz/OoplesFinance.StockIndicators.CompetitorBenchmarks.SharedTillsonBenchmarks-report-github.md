```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev  | Gen0    | Gen1   | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|--------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib.Functions.T3** | **1000**  |   **147.6 μs** |  **1.84 μs** | **1.10 μs** |  **3.9063** |      **-** |  **65.18 KB** |
| BuilderLatestOnly | TaLib.Functions.T3 | 1000  |   142.1 μs |  1.76 μs | 0.92 μs |  0.9766 |      - |  17.57 KB |
| **BuilderFull**       | **TaLib.Functions.T3** | **10000** | **1,487.3 μs** |  **6.84 μs** | **4.07 μs** | **31.2500** | **7.8125** | **628.08 KB** |
| BuilderLatestOnly | TaLib.Functions.T3 | 10000 | 1,441.8 μs | 12.72 μs | 7.57 μs |  7.8125 |      - | 158.26 KB |
