```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation    | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Gen2   | Allocated  | Alloc Ratio |
|------------------ |------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|--------:|-------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.T3** | **1000**  |   **211.88 μs** | **50.459 μs** | **33.376 μs** |  **7.29** |    **1.10** |       **-** |       **-** |      **-** |   **65.22 KB** |        **1.34** |
| BuilderLatestOnly | QuanTAlib.T3 | 1000  |   157.12 μs |  1.277 μs |  0.668 μs |  5.41 |    0.04 |  0.9766 |       - |      - |   17.57 KB |        0.36 |
| NativeSingle      | QuanTAlib.T3 | 1000  |    29.06 μs |  0.406 μs |  0.212 μs |  1.00 |    0.01 |  2.9297 |  0.2441 | 0.2441 |   48.69 KB |        1.00 |
| NativeParallel    | QuanTAlib.T3 | 1000  |    74.23 μs |  1.840 μs |  1.217 μs |  2.55 |    0.04 |  6.8359 |  0.9766 | 0.9766 |  112.86 KB |        2.32 |
|                   |              |       |             |           |           |       |         |         |         |        |            |             |
| **BuilderFull**       | **QuanTAlib.T3** | **10000** | **1,484.66 μs** | **15.883 μs** |  **8.307 μs** |  **5.73** |    **0.05** | **31.2500** |  **7.8125** |      **-** |  **628.08 KB** |        **1.33** |
| BuilderLatestOnly | QuanTAlib.T3 | 10000 | 1,430.68 μs |  7.874 μs |  4.118 μs |  5.53 |    0.05 |  7.8125 |       - |      - |  158.26 KB |        0.34 |
| NativeSingle      | QuanTAlib.T3 | 10000 |   258.91 μs |  3.527 μs |  2.099 μs |  1.00 |    0.01 | 27.3438 |  3.9063 |      - |  470.58 KB |        1.00 |
| NativeParallel    | QuanTAlib.T3 | 10000 |   346.37 μs | 30.097 μs | 19.907 μs |  1.34 |    0.07 | 64.4531 | 11.7188 |      - | 1062.08 KB |        2.26 |
