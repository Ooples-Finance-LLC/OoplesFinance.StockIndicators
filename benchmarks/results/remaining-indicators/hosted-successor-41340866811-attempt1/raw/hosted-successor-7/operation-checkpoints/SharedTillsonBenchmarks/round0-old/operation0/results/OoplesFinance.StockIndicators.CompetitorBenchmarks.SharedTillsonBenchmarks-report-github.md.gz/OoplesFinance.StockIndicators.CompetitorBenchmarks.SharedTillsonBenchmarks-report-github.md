```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation     | Count | Mean       | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |-------------- |------ |-----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **Skender.GetT3** | **1000**  |   **156.4 μs** |  **3.70 μs** |  **1.94 μs** |  **3.9063** |      **-** |  **65.15 KB** |
| BuilderLatestOnly | Skender.GetT3 | 1000  |   152.8 μs |  4.16 μs |  2.75 μs |  0.9766 |      - |  17.57 KB |
| **BuilderFull**       | **Skender.GetT3** | **10000** | **1,503.5 μs** | **67.43 μs** | **44.60 μs** | **31.2500** | **7.8125** | **628.06 KB** |
| BuilderLatestOnly | Skender.GetT3 | 10000 | 1,429.3 μs | 13.97 μs |  7.31 μs |  7.8125 |      - | 158.26 KB |
