```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.T3** | **1000**  |   **148.709 μs** |  **3.6056 μs** |  **2.1457 μs** | **39.33** |    **0.66** |  **3.9063** |      **-** |  **65.18 KB** |        **9.34** |
| BuilderLatestOnly | TaLib.Functions.T3 | 1000  |   146.123 μs |  3.3922 μs |  2.2438 μs | 38.65 |    0.68 |  0.9766 |      - |  17.57 KB |        2.52 |
| NativeSingle      | TaLib.Functions.T3 | 1000  |     3.781 μs |  0.0596 μs |  0.0394 μs |  1.00 |    0.01 |  0.3967 |      - |   6.98 KB |        1.00 |
| NativeParallel    | TaLib.Functions.T3 | 1000  |     8.026 μs |  0.2004 μs |  0.1193 μs |  2.12 |    0.04 |  1.8311 | 0.0610 |  24.66 KB |        3.53 |
|                   |                    |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.T3** | **10000** | **1,470.846 μs** | **28.1909 μs** | **16.7759 μs** | **37.90** |    **0.80** | **31.2500** | **7.8125** | **628.08 KB** |        **8.13** |
| BuilderLatestOnly | TaLib.Functions.T3 | 10000 | 1,443.594 μs | 36.0276 μs | 23.8300 μs | 37.20 |    0.90 |  7.8125 |      - | 158.26 KB |        2.05 |
| NativeSingle      | TaLib.Functions.T3 | 10000 |    38.823 μs |  1.1332 μs |  0.7495 μs |  1.00 |    0.03 |  4.6387 |      - |  77.29 KB |        1.00 |
| NativeParallel    | TaLib.Functions.T3 | 10000 |    78.201 μs |  4.1276 μs |  2.4563 μs |  2.01 |    0.07 | 18.0664 | 4.8828 | 270.75 KB |        3.50 |
