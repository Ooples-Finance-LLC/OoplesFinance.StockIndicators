```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation     | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |-------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetT3** | **1000**  |   **158.24 μs** |   **4.393 μs** |   **2.614 μs** |  **3.61** |    **0.09** |   **3.9063** |        **-** |        **-** |   **65.18 KB** |        **0.72** |
| BuilderLatestOnly | Skender.GetT3 | 1000  |   152.61 μs |   3.879 μs |   2.566 μs |  3.48 |    0.09 |   0.9766 |        - |        - |   17.57 KB |        0.19 |
| NativeSingle      | Skender.GetT3 | 1000  |    43.82 μs |   1.476 μs |   0.977 μs |  1.00 |    0.03 |   5.3711 |   0.7324 |        - |   90.24 KB |        1.00 |
| NativeParallel    | Skender.GetT3 | 1000  |    90.47 μs |   6.501 μs |   4.300 μs |  2.07 |    0.10 |  15.6250 |   3.4180 |        - |  234.43 KB |        2.60 |
|                   |               |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetT3** | **10000** | **1,479.46 μs** |  **12.923 μs** |   **7.690 μs** |  **2.31** |    **0.09** |  **31.2500** |   **7.8125** |        **-** |  **628.09 KB** |        **0.70** |
| BuilderLatestOnly | Skender.GetT3 | 10000 | 1,428.60 μs |   6.959 μs |   4.141 μs |  2.24 |    0.09 |   7.8125 |        - |        - |  158.26 KB |        0.18 |
| NativeSingle      | Skender.GetT3 | 10000 |   640.06 μs |  39.908 μs |  26.397 μs |  1.00 |    0.05 | 117.1875 |  89.8438 |  82.0313 |  900.08 KB |        1.00 |
| NativeParallel    | Skender.GetT3 | 10000 | 1,546.92 μs | 277.878 μs | 183.799 μs |  2.42 |    0.29 | 257.8125 | 195.3125 | 148.4375 | 2328.93 KB |        2.59 |
