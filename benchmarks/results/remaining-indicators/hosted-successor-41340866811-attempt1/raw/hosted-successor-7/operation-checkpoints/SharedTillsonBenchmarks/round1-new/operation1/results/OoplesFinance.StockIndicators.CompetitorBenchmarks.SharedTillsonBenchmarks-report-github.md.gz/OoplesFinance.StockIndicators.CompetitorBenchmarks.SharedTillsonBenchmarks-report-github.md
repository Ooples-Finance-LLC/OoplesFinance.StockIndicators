```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.T3** | **1000**  |   **150.8 μs** |  **1.16 μs** |  **0.69 μs** |       **-** |  **65.22 KB** |
| BuilderLatestOnly | TaLib.Functions.T3 | 1000  |   143.6 μs |  3.83 μs |  2.28 μs |  0.9766 |  17.57 KB |
| **BuilderFull**       | **TaLib.Functions.T3** | **10000** | **1,473.3 μs** | **31.62 μs** | **20.92 μs** | **31.2500** | **628.15 KB** |
| BuilderLatestOnly | TaLib.Functions.T3 | 10000 | 1,429.6 μs |  2.69 μs |  1.41 μs |  7.8125 | 158.26 KB |
