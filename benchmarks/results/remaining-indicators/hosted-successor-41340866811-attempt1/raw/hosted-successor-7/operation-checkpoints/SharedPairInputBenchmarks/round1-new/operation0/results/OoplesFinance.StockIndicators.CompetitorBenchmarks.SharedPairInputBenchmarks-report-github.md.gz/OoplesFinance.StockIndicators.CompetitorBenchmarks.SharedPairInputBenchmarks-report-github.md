```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **840.2 μs** |  **53.78 μs** |  **28.13 μs** |       **-** |  **69.36 KB** |
| BuilderLatestOnly | 1000  | Beta      |   435.8 μs |  55.22 μs |  36.52 μs |       - |  21.67 KB |
| **BuilderFull**       | **10000** | **Beta**      | **3,999.8 μs** |  **47.45 μs** |  **24.82 μs** | **31.2500** | **632.38 KB** |
| BuilderLatestOnly | 10000 | Beta      | 4,289.4 μs | 573.87 μs | 379.58 μs |       - | 162.53 KB |
