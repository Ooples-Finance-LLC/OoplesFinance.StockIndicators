```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------ |---------- |-------------:|------------:|------------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **672.205 μs** |  **37.0264 μs** |  **19.3655 μs** | **88.16** |    **2.45** |       **-** |      **-** |  **69.39 KB** |        **9.00** |
| BuilderLatestOnly | 1000  | Beta      |   442.468 μs |  52.1436 μs |  34.4898 μs | 58.03 |    4.33 |       - |      - |  21.67 KB |        2.81 |
| NativeSingle      | 1000  | Beta      |     7.625 μs |   0.0836 μs |   0.0498 μs |  1.00 |    0.01 |  0.4272 |      - |   7.71 KB |        1.00 |
| NativeParallel    | 1000  | Beta      |     5.508 μs |   0.4255 μs |   0.2814 μs |  0.72 |    0.04 |  0.4883 |      - |   7.98 KB |        1.03 |
|                   |       |           |              |             |             |       |         |         |        |           |             |
| **BuilderFull**       | **10000** | **Beta**      | **4,390.402 μs** | **486.6667 μs** | **321.8999 μs** | **59.35** |    **4.15** | **31.2500** |      **-** | **632.37 KB** |        **8.10** |
| BuilderLatestOnly | 10000 | Beta      | 4,166.473 μs | 438.8329 μs | 261.1424 μs | 56.32 |    3.35 |       - |      - | 162.53 KB |        2.08 |
| NativeSingle      | 10000 | Beta      |    73.977 μs |   0.1898 μs |   0.0993 μs |  1.00 |    0.00 |  4.3945 | 0.4883 |  78.03 KB |        1.00 |
| NativeParallel    | 10000 | Beta      |    51.986 μs |   5.0207 μs |   3.3209 μs |  0.70 |    0.04 |  4.6387 | 0.7324 |  78.29 KB |        1.00 |
