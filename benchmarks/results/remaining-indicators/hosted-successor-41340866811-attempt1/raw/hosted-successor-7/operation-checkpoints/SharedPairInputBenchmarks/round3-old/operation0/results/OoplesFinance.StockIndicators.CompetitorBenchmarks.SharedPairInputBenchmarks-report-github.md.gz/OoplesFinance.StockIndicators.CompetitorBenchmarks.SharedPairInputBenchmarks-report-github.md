```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **934.0 μs** | **209.58 μs** | **138.63 μs** |       **-** |  **69.39 KB** |
| BuilderLatestOnly | 1000  | Beta      |   433.7 μs |  55.33 μs |  36.60 μs |       - |  21.67 KB |
| **BuilderFull**       | **10000** | **Beta**      | **4,136.5 μs** | **527.18 μs** | **348.70 μs** | **31.2500** | **632.37 KB** |
| BuilderLatestOnly | 10000 | Beta      | 4,134.2 μs | 310.78 μs | 205.56 μs |       - | 162.52 KB |
