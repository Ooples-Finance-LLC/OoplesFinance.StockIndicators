```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Operation | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |------ |---------- |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **1000**  | **Beta**      |   **837.8 μs** |  **18.86 μs** |  **11.23 μs** |       **-** |  **69.39 KB** |
| BuilderLatestOnly | 1000  | Beta      |   417.3 μs |  50.23 μs |  33.22 μs |       - |  21.67 KB |
| **BuilderFull**       | **10000** | **Beta**      | **4,398.7 μs** | **774.07 μs** | **512.00 μs** | **31.2500** | **632.38 KB** |
| BuilderLatestOnly | 10000 | Beta      | 4,003.1 μs | 333.23 μs | 220.41 μs |       - | 162.54 KB |
