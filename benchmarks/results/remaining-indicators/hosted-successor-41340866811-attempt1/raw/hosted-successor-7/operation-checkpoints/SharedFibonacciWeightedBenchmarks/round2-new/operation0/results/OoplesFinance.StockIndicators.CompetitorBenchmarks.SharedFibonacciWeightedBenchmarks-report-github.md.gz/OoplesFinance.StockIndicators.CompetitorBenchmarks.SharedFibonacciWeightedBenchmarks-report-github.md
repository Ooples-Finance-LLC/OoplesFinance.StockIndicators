```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |----------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **QuanTAlib.Fwma** | **1000**  |  **74.74 μs** |  **5.816 μs** |  **3.847 μs** |  **0.88** |    **0.04** |   **1.9531** |       **-** |   **60.35 KB** |        **0.24** |
| BuilderLatestOnly | QuanTAlib.Fwma | 1000  |  76.05 μs |  1.537 μs |  1.017 μs |  0.90 |    0.01 |   0.4883 |       - |   12.46 KB |        0.05 |
| NativeSingle      | QuanTAlib.Fwma | 1000  |  84.63 μs |  1.310 μs |  0.780 μs |  1.00 |    0.01 |  15.1367 |  0.4883 |   254.5 KB |        1.00 |
| NativeParallel    | QuanTAlib.Fwma | 1000  |  75.60 μs |  1.685 μs |  0.881 μs |  0.89 |    0.01 |  16.1133 |  0.4883 |   262.7 KB |        1.03 |
|                   |                |       |           |           |           |       |         |          |         |            |             |
| **BuilderFull**       | **QuanTAlib.Fwma** | **10000** | **468.12 μs** | **27.998 μs** | **16.661 μs** |  **0.56** |    **0.02** |  **31.2500** | **11.7188** |  **552.91 KB** |        **0.22** |
| BuilderLatestOnly | QuanTAlib.Fwma | 10000 | 440.49 μs | 55.122 μs | 36.460 μs |  0.53 |    0.04 |   3.9063 |       - |   82.81 KB |        0.03 |
| NativeSingle      | QuanTAlib.Fwma | 10000 | 835.44 μs | 11.444 μs |  6.810 μs |  1.00 |    0.01 | 156.2500 | 31.2500 | 2564.32 KB |        1.00 |
| NativeParallel    | QuanTAlib.Fwma | 10000 | 478.17 μs | 13.082 μs |  6.842 μs |  0.57 |    0.01 | 156.2500 | 31.2500 | 2572.67 KB |        1.00 |
