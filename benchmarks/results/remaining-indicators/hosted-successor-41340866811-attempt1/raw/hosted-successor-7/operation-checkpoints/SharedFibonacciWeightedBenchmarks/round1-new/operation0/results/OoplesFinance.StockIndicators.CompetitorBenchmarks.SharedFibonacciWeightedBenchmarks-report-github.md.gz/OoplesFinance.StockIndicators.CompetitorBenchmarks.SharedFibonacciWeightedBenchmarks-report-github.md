```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **QuanTAlib.Fwma** | **1000**  |  **78.36 μs** |  **8.455 μs** |  **5.593 μs** |  **1.9531** |       **-** |  **60.35 KB** |
| BuilderLatestOnly | QuanTAlib.Fwma | 1000  |  76.31 μs |  1.483 μs |  0.981 μs |  0.4883 |       - |  12.46 KB |
| **BuilderFull**       | **QuanTAlib.Fwma** | **10000** | **431.32 μs** | **43.855 μs** | **26.097 μs** | **31.2500** | **11.7188** | **552.91 KB** |
| BuilderLatestOnly | QuanTAlib.Fwma | 10000 | 454.85 μs | 40.223 μs | 23.936 μs |  3.9063 |       - |  82.81 KB |
