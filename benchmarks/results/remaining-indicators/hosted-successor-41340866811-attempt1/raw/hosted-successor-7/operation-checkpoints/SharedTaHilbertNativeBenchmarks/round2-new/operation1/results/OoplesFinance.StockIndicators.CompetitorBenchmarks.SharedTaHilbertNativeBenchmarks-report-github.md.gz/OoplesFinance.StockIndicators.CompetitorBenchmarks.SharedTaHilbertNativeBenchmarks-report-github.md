```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)tSine [22]** | **1000**  |  **1,868.2 μs** |   **6.79 μs** |   **4.04 μs** |  **3.44** |    **0.01** |      **-** |  **84.97 KB** |        **5.40** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 1000  |  1,831.4 μs |  11.81 μs |   6.18 μs |  3.38 |    0.01 |      - |  37.34 KB |        2.37 |
| NativeSingle      | TaLib(...)tSine [22] | 1000  |    542.3 μs |   1.07 μs |   0.56 μs |  1.00 |    0.00 |      - |  15.74 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 1000  |    730.3 μs |  47.27 μs |  31.27 μs |  1.35 |    0.06 | 3.9063 |  55.96 KB |        3.56 |
|                   |                      |       |             |           |           |       |         |        |           |             |
| **BuilderFull**       | **TaLib(...)tSine [22]** | **10000** | **18,920.3 μs** | **118.11 μs** |  **78.12 μs** |  **3.22** |    **0.01** |      **-** | **789.64 KB** |        **5.04** |
| BuilderLatestOnly | TaLib(...)tSine [22] | 10000 | 19,040.0 μs | 134.41 μs |  88.91 μs |  3.24 |    0.02 |      - | 319.77 KB |        2.04 |
| NativeSingle      | TaLib(...)tSine [22] | 10000 |  5,876.0 μs |  20.95 μs |  12.46 μs |  1.00 |    0.00 |      - | 156.58 KB |        1.00 |
| NativeParallel    | TaLib(...)tSine [22] | 10000 |  7,441.0 μs | 315.28 μs | 164.90 μs |  1.27 |    0.03 |      - | 548.72 KB |        3.50 |
