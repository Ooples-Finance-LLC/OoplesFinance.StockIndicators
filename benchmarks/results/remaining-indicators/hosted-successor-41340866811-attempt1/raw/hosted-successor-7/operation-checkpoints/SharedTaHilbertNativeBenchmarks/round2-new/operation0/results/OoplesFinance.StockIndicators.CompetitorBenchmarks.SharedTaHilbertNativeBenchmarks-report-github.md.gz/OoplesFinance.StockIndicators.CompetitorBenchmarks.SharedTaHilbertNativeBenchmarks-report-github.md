```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)Phase [25]** | **1000**  |  **2,164.3 μs** |  **13.55 μs** |   **8.06 μs** |  **4.15** |    **0.03** |  **69.08 KB** |        **8.23** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 1000  |  1,838.9 μs |  10.37 μs |   5.43 μs |  3.53 |    0.02 |  21.45 KB |        2.56 |
| NativeSingle      | TaLib(...)Phase [25] | 1000  |    521.3 μs |   4.94 μs |   3.27 μs |  1.00 |    0.01 |   8.39 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 1000  |    674.3 μs |   7.41 μs |   3.88 μs |  1.29 |    0.01 |  30.22 KB |        3.60 |
|                   |                      |       |             |           |           |       |         |           |             |
| **BuilderFull**       | **TaLib(...)Phase [25]** | **10000** | **19,271.9 μs** | **220.51 μs** | **131.22 μs** |  **3.41** |    **0.02** | **633.17 KB** |        **8.02** |
| BuilderLatestOnly | TaLib(...)Phase [25] | 10000 | 19,053.4 μs | 108.80 μs |  56.91 μs |  3.38 |    0.01 | 163.31 KB |        2.07 |
| NativeSingle      | TaLib(...)Phase [25] | 10000 |  5,643.6 μs |  17.94 μs |  11.86 μs |  1.00 |    0.00 |  78.91 KB |        1.00 |
| NativeParallel    | TaLib(...)Phase [25] | 10000 |  7,106.6 μs |  79.20 μs |  41.42 μs |  1.26 |    0.01 | 276.78 KB |        3.51 |
