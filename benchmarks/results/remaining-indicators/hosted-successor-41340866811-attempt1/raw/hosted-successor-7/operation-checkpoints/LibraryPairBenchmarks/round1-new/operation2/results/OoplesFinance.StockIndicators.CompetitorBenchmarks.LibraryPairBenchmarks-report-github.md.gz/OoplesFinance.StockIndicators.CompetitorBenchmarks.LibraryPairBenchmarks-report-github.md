```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean      | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |----------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib(...)cdFix [23]** |  **5.114 ms** |  **0.0867 ms** |  **0.0516 ms** |  **1.00** |    **0.01** |  **203.25 KB** |        **1.00** |
|        |       |                      |           |            |            |       |         |            |             |
| **Ooples** | **10000** | **TaLib(...)cdFix [23]** | **30.911 ms** | **30.8986 ms** | **20.4375 ms** |  **1.85** |    **2.06** | **1995.63 KB** |        **1.00** |
