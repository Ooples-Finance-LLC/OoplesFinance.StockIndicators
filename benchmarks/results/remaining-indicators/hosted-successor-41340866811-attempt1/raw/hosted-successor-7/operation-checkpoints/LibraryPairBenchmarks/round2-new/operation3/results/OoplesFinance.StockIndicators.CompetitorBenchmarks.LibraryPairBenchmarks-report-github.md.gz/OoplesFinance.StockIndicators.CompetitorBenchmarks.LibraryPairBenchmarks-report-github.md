```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Mavp** |   **807.4 μs** |  **59.72 μs** |  **39.50 μs** |  **1.00** |    **0.07** |  **107.52 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Mavp |   280.5 μs |  19.32 μs |  12.78 μs |  0.35 |    0.02 |   60.53 KB |        0.56 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Mavp** | **5,113.2 μs** | **722.67 μs** | **377.97 μs** |  **1.00** |    **0.10** | **1038.58 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Mavp |   698.5 μs |  28.16 μs |  18.63 μs |  0.14 |    0.01 |  526.63 KB |        0.51 |
