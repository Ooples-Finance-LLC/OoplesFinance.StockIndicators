```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDM [22]** | **1,535.6 μs** |    **33.54 μs** |  **17.54 μs** |  **1.00** |    **0.02** |  **105.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDM [22] |   147.4 μs |     3.21 μs |   1.68 μs |  0.10 |    0.00 |   40.22 KB |        0.38 |
|            |       |                      |            |             |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDM [22]** | **2,915.9 μs** | **1,540.50 μs** | **916.73 μs** |  **1.07** |    **0.42** | **1036.72 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDM [22] |   265.9 μs |     5.04 μs |   2.64 μs |  0.10 |    0.02 |  330.59 KB |        0.32 |
