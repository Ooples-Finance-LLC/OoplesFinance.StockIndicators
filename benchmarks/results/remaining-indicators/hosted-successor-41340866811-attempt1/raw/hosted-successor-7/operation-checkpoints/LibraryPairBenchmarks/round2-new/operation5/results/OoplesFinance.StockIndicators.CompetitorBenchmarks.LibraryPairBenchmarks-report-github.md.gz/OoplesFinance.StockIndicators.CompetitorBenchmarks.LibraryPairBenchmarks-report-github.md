```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)nusDM [23]** | **1,050.7 μs** |  **46.14 μs** |  **27.45 μs** |  **1.00** |    **0.04** |  **105.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)nusDM [23] |   146.8 μs |   3.15 μs |   1.88 μs |  0.14 |    0.00 |   40.59 KB |        0.38 |
|            |       |                      |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)nusDM [23]** | **8,816.2 μs** | **724.37 μs** | **431.06 μs** |  **1.00** |    **0.06** | **1036.77 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)nusDM [23] |   336.7 μs |  31.29 μs |  18.62 μs |  0.04 |    0.00 |  330.91 KB |        0.32 |
