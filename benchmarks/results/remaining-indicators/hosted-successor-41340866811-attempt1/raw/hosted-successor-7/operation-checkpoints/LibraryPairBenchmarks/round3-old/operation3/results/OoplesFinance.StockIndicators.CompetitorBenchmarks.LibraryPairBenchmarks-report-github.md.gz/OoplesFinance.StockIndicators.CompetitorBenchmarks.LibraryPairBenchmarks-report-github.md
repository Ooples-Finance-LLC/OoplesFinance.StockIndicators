```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean       | Error       | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |-----------:|------------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **TaLib.Functions.Mavp** |   **830.2 μs** |    **62.90 μs** |  **41.60 μs** |  **1.00** |    **0.07** |  **107.52 KB** |        **1.00** |
|        |       |                      |            |             |           |       |         |            |             |
| **Ooples** | **10000** | **TaLib.Functions.Mavp** | **4,685.9 μs** | **1,479.93 μs** | **978.88 μs** |  **1.03** |    **0.27** | **1038.86 KB** |        **1.00** |
