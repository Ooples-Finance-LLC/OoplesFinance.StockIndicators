```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error        | StdDev       | Median     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-------------:|-------------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)cdFix [23]** |  **5,124.9 μs** |     **49.37 μs** |     **29.38 μs** | **5,122.5 μs** |  **1.00** |    **0.01** |  **203.25 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)cdFix [23] |    250.6 μs |     12.71 μs |      8.41 μs |   248.3 μs |  0.05 |    0.00 |  121.36 KB |        0.60 |
|            |       |                      |             |              |              |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)cdFix [23]** | **20,778.8 μs** | **32,871.00 μs** | **21,742.13 μs** | **7,585.4 μs** |  **2.47** |    **3.38** | **1995.91 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)cdFix [23] |    314.1 μs |     19.75 μs |     11.75 μs |   316.0 μs |  0.04 |    0.02 |  1132.1 KB |        0.57 |
