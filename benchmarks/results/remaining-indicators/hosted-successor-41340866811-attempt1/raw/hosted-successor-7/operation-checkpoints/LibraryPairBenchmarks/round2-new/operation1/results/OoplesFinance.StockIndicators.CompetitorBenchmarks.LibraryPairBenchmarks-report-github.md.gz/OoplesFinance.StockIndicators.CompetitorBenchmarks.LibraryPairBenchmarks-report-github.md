```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error        | StdDev       | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-------------:|-------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)cdExt [23]** |  **3,062.2 μs** |     **44.36 μs** |     **23.20 μs** |  **1.00** |    **0.01** |   **752.1 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)cdExt [23] |    248.0 μs |      9.23 μs |      6.11 μs |  0.08 |    0.00 |  121.87 KB |        0.16 |
|            |       |                      |             |              |              |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)cdExt [23]** | **28,339.2 μs** | **28,621.70 μs** | **18,931.49 μs** |  **1.83** |    **2.11** | **7316.67 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)cdExt [23] |    287.0 μs |     24.77 μs |     14.74 μs |  0.02 |    0.02 | 1132.61 KB |        0.15 |
