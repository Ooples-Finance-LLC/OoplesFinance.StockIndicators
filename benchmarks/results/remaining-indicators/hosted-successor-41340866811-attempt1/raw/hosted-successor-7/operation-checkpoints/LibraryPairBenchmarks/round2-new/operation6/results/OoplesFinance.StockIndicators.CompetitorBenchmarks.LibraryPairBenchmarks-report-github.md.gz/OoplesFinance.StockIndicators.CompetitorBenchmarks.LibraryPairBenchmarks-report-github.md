```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib(...)lusDI [22]** |  **2,197.8 μs** |    **27.36 μs** |    **16.28 μs** |  **1.00** |    **0.01** |  **105.71 KB** |        **1.00** |
| Competitor | 1000  | TaLib(...)lusDI [22] |    208.7 μs |     1.92 μs |     1.14 μs |  0.09 |    0.00 |    40.6 KB |        0.38 |
|            |       |                      |             |             |             |       |         |            |             |
| **Ooples**     | **10000** | **TaLib(...)lusDI [22]** | **19,886.0 μs** | **1,649.62 μs** | **1,091.12 μs** |  **1.00** |    **0.07** | **1037.05 KB** |        **1.00** |
| Competitor | 10000 | TaLib(...)lusDI [22] |    394.0 μs |    18.93 μs |    12.52 μs |  0.02 |    0.00 |  330.92 KB |        0.32 |
