```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error       | StdDev      | Median     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|------------:|------------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **TaLib.Functions.Macd** | **4,320.5 μs** |    **83.41 μs** |    **55.17 μs** | **4,308.0 μs** |  **1.00** |    **0.02** |  **203.19 KB** |        **1.00** |
| Competitor | 1000  | TaLib.Functions.Macd |   249.4 μs |    13.87 μs |     8.25 μs |   248.1 μs |  0.06 |    0.00 |  121.36 KB |        0.60 |
|            |       |                      |            |             |             |            |       |         |            |             |
| **Ooples**     | **10000** | **TaLib.Functions.Macd** | **6,520.8 μs** | **5,086.61 μs** | **2,660.39 μs** | **5,045.6 μs** |  **1.11** |    **0.54** | **1995.85 KB** |        **1.00** |
| Competitor | 10000 | TaLib.Functions.Macd |   309.0 μs |    12.65 μs |     7.53 μs |   310.3 μs |  0.05 |    0.01 | 1131.82 KB |        0.57 |
