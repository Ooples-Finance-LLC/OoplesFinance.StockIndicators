```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **386.43 μs** |   **4.020 μs** |  **2.102 μs** |  **5.94** |    **0.06** |        **-** |        **-** |       **-** |   **97.03 KB** |        **0.26** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   385.42 μs |   4.878 μs |  3.226 μs |  5.92 |    0.07 |   1.9531 |        - |       - |   49.42 KB |        0.13 |
| NativeSingle      | Skend(...)inOsc [21] | 1000  |    65.09 μs |   1.047 μs |  0.623 μs |  1.00 |    0.01 |  22.9492 |   6.8359 |       - |  379.71 KB |        1.00 |
| NativeParallel    | Skend(...)inOsc [21] | 1000  |   121.64 μs |   3.811 μs |  1.993 μs |  1.87 |    0.03 |  60.5469 |  21.4844 |       - |  958.68 KB |        2.52 |
|                   |                      |       |             |            |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **3,939.94 μs** | **134.246 μs** | **79.888 μs** |  **4.23** |    **0.09** |  **31.2500** |        **-** |       **-** |  **941.29 KB** |        **0.25** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 3,876.21 μs |  41.191 μs | 21.544 μs |  4.16 |    0.04 |        - |        - |       - |  471.49 KB |        0.12 |
| NativeSingle      | Skend(...)inOsc [21] | 10000 |   930.89 μs |  13.667 μs |  8.133 μs |  1.00 |    0.01 | 242.1875 | 148.4375 | 46.8750 | 3790.27 KB |        1.00 |
| NativeParallel    | Skend(...)inOsc [21] | 10000 | 1,810.77 μs | 135.640 μs | 89.718 μs |  1.95 |    0.09 | 593.7500 | 546.8750 | 78.1250 | 9555.16 KB |        2.52 |
