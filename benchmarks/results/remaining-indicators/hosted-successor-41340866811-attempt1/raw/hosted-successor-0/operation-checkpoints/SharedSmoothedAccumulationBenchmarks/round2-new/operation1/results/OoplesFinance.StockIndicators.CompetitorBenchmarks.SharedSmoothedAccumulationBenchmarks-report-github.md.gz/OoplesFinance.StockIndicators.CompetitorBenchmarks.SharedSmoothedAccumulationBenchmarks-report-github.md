```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio  | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|-------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **370.655 μs** |  **2.2053 μs** |  **1.1534 μs** | **153.13** |    **1.69** |       **-** |      **-** |  **73.52 KB** |        **9.42** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   365.392 μs |  1.5714 μs |  0.9351 μs | 150.96 |    1.64 |       - |      - |  25.92 KB |        3.32 |
| NativeSingle      | TaLib(...)AdOsc [21] | 1000  |     2.421 μs |  0.0458 μs |  0.0273 μs |   1.00 |    0.02 |  0.4730 |      - |    7.8 KB |        1.00 |
| NativeParallel    | TaLib(...)AdOsc [21] | 1000  |     6.399 μs |  0.4136 μs |  0.2736 μs |   2.64 |    0.11 |  1.8921 | 0.0610 |  27.56 KB |        3.53 |
|                   |                      |       |              |            |            |        |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **3,859.876 μs** | **46.4074 μs** | **24.2720 μs** | **175.95** |    **1.58** | **31.2500** |      **-** | **706.86 KB** |        **9.05** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 3,764.625 μs | 13.9098 μs |  8.2775 μs | 171.61 |    1.21 |       - |      - |  237.1 KB |        3.04 |
| NativeSingle      | TaLib(...)AdOsc [21] | 10000 |    21.938 μs |  0.2620 μs |  0.1559 μs |   1.00 |    0.01 |  4.7607 |      - |  78.12 KB |        1.00 |
| NativeParallel    | TaLib(...)AdOsc [21] | 10000 |    52.256 μs |  1.7816 μs |  0.9318 μs |   2.38 |    0.04 | 18.0664 | 4.8828 | 273.66 KB |        3.50 |
