```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **402.9 μs** |  **3.28 μs** |  **1.95 μs** |       **-** |  **97.07 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   389.5 μs |  7.56 μs |  4.50 μs |       - |  49.42 KB |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **4,028.3 μs** | **39.96 μs** | **23.78 μs** | **31.2500** | **941.29 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 4,021.7 μs | 31.61 μs | 16.53 μs |       - | 471.45 KB |
