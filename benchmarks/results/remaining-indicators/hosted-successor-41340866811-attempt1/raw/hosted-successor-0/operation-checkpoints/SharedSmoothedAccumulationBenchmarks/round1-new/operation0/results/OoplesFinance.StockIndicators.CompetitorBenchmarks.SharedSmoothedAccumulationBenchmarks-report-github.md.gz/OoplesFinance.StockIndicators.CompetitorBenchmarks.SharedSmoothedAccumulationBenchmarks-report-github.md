```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)inOsc [21]** | **1000**  |   **391.1 μs** |  **4.70 μs** |  **2.46 μs** |       **-** |  **97.03 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 1000  |   386.7 μs |  2.73 μs |  1.43 μs |       - |  49.43 KB |
| **BuilderFull**       | **Skend(...)inOsc [21]** | **10000** | **4,005.7 μs** | **15.85 μs** |  **8.29 μs** | **31.2500** |  **941.3 KB** |
| BuilderLatestOnly | Skend(...)inOsc [21] | 10000 | 3,991.0 μs | 29.67 μs | 15.52 μs |       - | 471.46 KB |
