```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev  | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **1000**  |   **382.2 μs** |  **2.10 μs** | **1.10 μs** |       **-** |  **73.53 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 1000  |   375.8 μs |  2.89 μs | 1.72 μs |       - |  25.91 KB |
| **BuilderFull**       | **TaLib(...)AdOsc [21]** | **10000** | **3,974.3 μs** |  **6.90 μs** | **3.61 μs** | **31.2500** |  **706.9 KB** |
| BuilderLatestOnly | TaLib(...)AdOsc [21] | 10000 | 3,885.1 μs | 10.29 μs | 6.12 μs |       - | 236.96 KB |
