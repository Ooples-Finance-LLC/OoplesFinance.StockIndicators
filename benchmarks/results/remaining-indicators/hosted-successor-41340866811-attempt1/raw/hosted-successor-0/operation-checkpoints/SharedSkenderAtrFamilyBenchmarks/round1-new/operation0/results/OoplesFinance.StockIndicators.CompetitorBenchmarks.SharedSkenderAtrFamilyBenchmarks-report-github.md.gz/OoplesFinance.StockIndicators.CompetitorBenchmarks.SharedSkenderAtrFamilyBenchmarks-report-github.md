```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error   | StdDev  | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)elier [21]** | **1000**  |   **150.5 μs** | **9.49 μs** | **4.96 μs** |       **-** |  **73.28 KB** |
| BuilderLatestOnly | Skend(...)elier [21] | 1000  |   148.1 μs | 1.09 μs | 0.65 μs |  0.9766 |  25.67 KB |
| **BuilderFull**       | **Skend(...)elier [21]** | **10000** | **1,802.2 μs** | **5.50 μs** | **3.27 μs** | **31.2500** | **706.54 KB** |
| BuilderLatestOnly | Skend(...)elier [21] | 10000 | 1,729.2 μs | 5.76 μs | 3.01 μs |       - | 236.71 KB |
