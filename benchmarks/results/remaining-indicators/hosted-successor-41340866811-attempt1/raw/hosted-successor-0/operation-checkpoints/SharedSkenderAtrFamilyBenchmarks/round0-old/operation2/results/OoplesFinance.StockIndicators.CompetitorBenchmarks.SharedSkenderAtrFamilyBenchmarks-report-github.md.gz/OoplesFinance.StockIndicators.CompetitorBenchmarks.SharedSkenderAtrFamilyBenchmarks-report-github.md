```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)Bands [21]** | **1000**  |   **210.6 μs** |  **3.94 μs** |  **2.34 μs** |       **-** |       **-** |  **97.39 KB** |
| BuilderLatestOnly | Skend(...)Bands [21] | 1000  |   208.4 μs |  3.30 μs |  2.18 μs |  1.9531 |       - |  49.79 KB |
| **BuilderFull**       | **Skend(...)Bands [21]** | **10000** | **2,242.0 μs** | **26.28 μs** | **13.74 μs** | **46.8750** | **15.6250** | **941.59 KB** |
| BuilderLatestOnly | Skend(...)Bands [21] | 10000 | 2,247.3 μs | 38.98 μs | 25.78 μs | 15.6250 |       - | 471.75 KB |
