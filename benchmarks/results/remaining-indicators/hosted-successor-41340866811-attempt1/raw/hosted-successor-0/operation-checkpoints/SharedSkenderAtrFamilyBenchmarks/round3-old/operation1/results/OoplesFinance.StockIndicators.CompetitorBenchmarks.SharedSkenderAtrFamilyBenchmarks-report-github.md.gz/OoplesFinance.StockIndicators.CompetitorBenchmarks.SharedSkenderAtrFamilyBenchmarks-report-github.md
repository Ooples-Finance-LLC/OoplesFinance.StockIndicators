```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated  |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetKeltner** | **1000**  |   **235.2 μs** |  **3.07 μs** |  **1.61 μs** |       **-** |       **-** |  **104.63 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 1000  |   242.5 μs |  2.11 μs |  1.26 μs |  1.9531 |       - |   57.06 KB |
| **BuilderFull**       | **Skender.GetKeltner** | **10000** | **2,518.9 μs** |  **8.25 μs** |  **4.31 μs** | **46.8750** | **15.6250** | **1019.15 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 10000 | 2,517.2 μs | 24.40 μs | 14.52 μs | 31.2500 | 15.6250 |  549.35 KB |
