```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev  | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|--------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)Bands [21]** | **1000**  |   **209.0 μs** |  **4.09 μs** | **2.14 μs** |       **-** |       **-** |  **97.39 KB** |
| BuilderLatestOnly | Skend(...)Bands [21] | 1000  |   207.3 μs |  0.94 μs | 0.49 μs |  1.9531 |       - |  49.78 KB |
| **BuilderFull**       | **Skend(...)Bands [21]** | **10000** | **2,317.1 μs** | **13.11 μs** | **6.85 μs** | **46.8750** | **15.6250** | **941.57 KB** |
| BuilderLatestOnly | Skend(...)Bands [21] | 10000 | 2,249.0 μs | 14.13 μs | 7.39 μs | 15.6250 |       - | 471.75 KB |
