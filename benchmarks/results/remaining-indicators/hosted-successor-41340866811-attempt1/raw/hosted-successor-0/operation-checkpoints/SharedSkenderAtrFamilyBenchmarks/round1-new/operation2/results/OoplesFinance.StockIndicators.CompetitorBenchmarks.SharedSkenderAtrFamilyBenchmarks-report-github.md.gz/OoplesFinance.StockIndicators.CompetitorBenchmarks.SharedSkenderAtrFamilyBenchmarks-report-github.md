```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skend(...)Bands [21]** | **1000**  |   **207.0 μs** |   **1.45 μs** |  **0.76 μs** |       **-** |       **-** |  **97.43 KB** |
| BuilderLatestOnly | Skend(...)Bands [21] | 1000  |   209.2 μs |   2.35 μs |  1.40 μs |  1.9531 |       - |  49.83 KB |
| **BuilderFull**       | **Skend(...)Bands [21]** | **10000** | **2,305.7 μs** | **101.47 μs** | **67.12 μs** | **46.8750** | **15.6250** | **941.61 KB** |
| BuilderLatestOnly | Skend(...)Bands [21] | 10000 | 2,247.4 μs |  15.93 μs |  9.48 μs | 15.6250 |       - | 471.78 KB |
