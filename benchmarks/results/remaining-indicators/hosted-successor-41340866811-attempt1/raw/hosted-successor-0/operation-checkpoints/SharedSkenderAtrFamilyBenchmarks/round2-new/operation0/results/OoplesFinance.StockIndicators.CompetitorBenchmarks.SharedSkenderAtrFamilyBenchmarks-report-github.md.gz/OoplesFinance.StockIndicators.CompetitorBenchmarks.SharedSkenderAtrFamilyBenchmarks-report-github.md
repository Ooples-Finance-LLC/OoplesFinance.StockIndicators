```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)elier [21]** | **1000**  |   **154.18 μs** |  **1.779 μs** |  **1.059 μs** |  **2.46** |    **0.02** |        **-** |        **-** |   **73.32 KB** |        **0.33** |
| BuilderLatestOnly | Skend(...)elier [21] | 1000  |   146.18 μs |  0.382 μs |  0.200 μs |  2.33 |    0.01 |   0.9766 |        - |   25.67 KB |        0.12 |
| NativeSingle      | Skend(...)elier [21] | 1000  |    62.73 μs |  0.742 μs |  0.388 μs |  1.00 |    0.01 |  13.1836 |   2.9297 |  223.22 KB |        1.00 |
| NativeParallel    | Skend(...)elier [21] | 1000  |   118.44 μs |  5.293 μs |  2.768 μs |  1.89 |    0.04 |  36.1328 |  12.6953 |  566.85 KB |        2.54 |
|                   |                      |       |             |           |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skend(...)elier [21]** | **10000** | **1,753.76 μs** | **11.709 μs** |  **6.968 μs** |  **1.64** |    **0.01** |  **31.2500** |        **-** |  **706.56 KB** |        **0.32** |
| BuilderLatestOnly | Skend(...)elier [21] | 10000 | 1,747.43 μs | 14.151 μs |  7.401 μs |  1.64 |    0.01 |        - |        - |  236.69 KB |        0.11 |
| NativeSingle      | Skend(...)elier [21] | 10000 | 1,066.89 μs |  7.624 μs |  3.987 μs |  1.00 |    0.00 | 132.8125 |  85.9375 | 2227.18 KB |        1.00 |
| NativeParallel    | Skend(...)elier [21] | 10000 | 1,780.87 μs | 56.513 μs | 33.630 μs |  1.67 |    0.03 | 343.7500 | 265.6250 | 5647.04 KB |        2.54 |
