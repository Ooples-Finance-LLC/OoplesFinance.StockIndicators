```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated  |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetKeltner** | **1000**  |   **234.9 μs** |  **5.62 μs** |  **3.35 μs** |       **-** |       **-** |   **104.7 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 1000  |   233.3 μs |  2.40 μs |  1.43 μs |  1.9531 |       - |    57.1 KB |
| **BuilderFull**       | **Skender.GetKeltner** | **10000** | **2,480.9 μs** |  **5.89 μs** |  **3.08 μs** | **46.8750** | **15.6250** | **1019.24 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 10000 | 2,494.9 μs | 50.10 μs | 26.21 μs | 31.2500 | 15.6250 |  549.38 KB |
