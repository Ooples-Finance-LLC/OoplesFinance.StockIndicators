```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |------------------- |------ |------------:|-----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetKeltner** | **1000**  |   **234.46 μs** |   **2.775 μs** |  **1.451 μs** |  **2.91** |    **0.03** |        **-** |        **-** |       **-** |   **104.7 KB** |        **0.29** |
| BuilderLatestOnly | Skender.GetKeltner | 1000  |   235.35 μs |   4.071 μs |  2.693 μs |  2.92 |    0.04 |   1.9531 |        - |       - |    57.1 KB |        0.16 |
| NativeSingle      | Skender.GetKeltner | 1000  |    80.53 μs |   1.107 μs |  0.579 μs |  1.00 |    0.01 |  21.9727 |   6.3477 |       - |  360.53 KB |        1.00 |
| NativeParallel    | Skender.GetKeltner | 1000  |   139.89 μs |   7.686 μs |  4.574 μs |  1.74 |    0.06 |  57.6172 |  22.4609 |       - |  910.99 KB |        2.53 |
|                   |                    |       |             |            |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skender.GetKeltner** | **10000** | **2,515.08 μs** |  **21.181 μs** | **11.078 μs** |  **2.23** |    **0.05** |  **46.8750** |  **15.6250** |       **-** | **1019.21 KB** |        **0.28** |
| BuilderLatestOnly | Skender.GetKeltner | 10000 | 2,531.17 μs |  75.245 μs | 44.777 μs |  2.24 |    0.06 |  31.2500 |  15.6250 |       - |  549.42 KB |        0.15 |
| NativeSingle      | Skender.GetKeltner | 10000 | 1,129.09 μs |  41.322 μs | 27.332 μs |  1.00 |    0.03 | 218.7500 | 164.0625 | 46.8750 | 3595.31 KB |        1.00 |
| NativeParallel    | Skender.GetKeltner | 10000 | 2,277.28 μs | 103.881 μs | 68.711 μs |  2.02 |    0.07 | 593.7500 | 484.3750 | 78.1250 | 9067.97 KB |        2.52 |
