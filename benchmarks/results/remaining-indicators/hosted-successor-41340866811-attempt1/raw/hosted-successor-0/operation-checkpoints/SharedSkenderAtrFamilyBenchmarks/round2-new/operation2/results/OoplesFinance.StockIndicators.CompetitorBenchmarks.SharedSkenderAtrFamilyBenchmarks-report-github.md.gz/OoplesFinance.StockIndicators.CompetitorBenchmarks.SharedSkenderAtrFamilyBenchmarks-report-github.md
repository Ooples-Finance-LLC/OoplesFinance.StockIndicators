```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skend(...)Bands [21]** | **1000**  |   **209.49 μs** |  **2.798 μs** |  **1.665 μs** |  **2.20** |    **0.04** |        **-** |        **-** |       **-** |   **97.43 KB** |        **0.30** |
| BuilderLatestOnly | Skend(...)Bands [21] | 1000  |   210.10 μs |  2.196 μs |  1.307 μs |  2.21 |    0.04 |   1.9531 |        - |       - |   49.83 KB |        0.15 |
| NativeSingle      | Skend(...)Bands [21] | 1000  |    95.14 μs |  2.421 μs |  1.601 μs |  1.00 |    0.02 |  20.0195 |   5.3711 |       - |  329.24 KB |        1.00 |
| NativeParallel    | Skend(...)Bands [21] | 1000  |   156.21 μs |  8.844 μs |  5.263 μs |  1.64 |    0.06 |  52.7344 |  21.4844 |       - |  832.71 KB |        2.53 |
|                   |                      |       |             |           |           |       |         |          |          |         |            |             |
| **BuilderFull**       | **Skend(...)Bands [21]** | **10000** | **2,249.16 μs** | **31.720 μs** | **18.876 μs** |  **1.87** |    **0.02** |  **46.8750** |  **15.6250** |       **-** |   **941.6 KB** |        **0.29** |
| BuilderLatestOnly | Skend(...)Bands [21] | 10000 | 2,262.74 μs | 21.769 μs | 12.954 μs |  1.88 |    0.02 |  15.6250 |        - |       - |   471.8 KB |        0.14 |
| NativeSingle      | Skend(...)Bands [21] | 10000 | 1,202.48 μs | 15.303 μs |  8.004 μs |  1.00 |    0.01 | 195.3125 | 148.4375 | 46.8750 | 3282.77 KB |        1.00 |
| NativeParallel    | Skend(...)Bands [21] | 10000 | 2,355.73 μs | 59.717 μs | 31.233 μs |  1.96 |    0.03 | 515.6250 | 453.1250 | 78.1250 | 8286.56 KB |        2.52 |
