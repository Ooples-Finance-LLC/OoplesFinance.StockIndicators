```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Gen1    | Allocated  |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetKeltner** | **1000**  |   **238.7 μs** | **10.51 μs** |  **5.50 μs** |       **-** |       **-** |  **104.66 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 1000  |   236.7 μs |  2.13 μs |  1.12 μs |  1.9531 |       - |   57.06 KB |
| **BuilderFull**       | **Skender.GetKeltner** | **10000** | **2,515.9 μs** | **15.08 μs** |  **7.89 μs** | **46.8750** | **15.6250** | **1019.21 KB** |
| BuilderLatestOnly | Skender.GetKeltner | 10000 | 2,579.4 μs | 25.84 μs | 13.52 μs | 31.2500 | 15.6250 |  549.36 KB |
