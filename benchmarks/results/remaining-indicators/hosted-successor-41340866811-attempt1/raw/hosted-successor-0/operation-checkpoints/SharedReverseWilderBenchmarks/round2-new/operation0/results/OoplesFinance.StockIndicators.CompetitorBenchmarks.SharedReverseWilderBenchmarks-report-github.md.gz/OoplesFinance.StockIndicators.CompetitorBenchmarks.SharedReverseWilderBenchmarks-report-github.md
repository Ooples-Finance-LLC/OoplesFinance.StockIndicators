```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **1000**  |    **69.33 μs** |  **0.848 μs** |  **0.444 μs** |  **4.55** |    **0.07** |   **3.9063** |        **-** |   **91.78 KB** |        **1.94** |
| BuilderLatestOnly | 1000  |    66.54 μs |  0.847 μs |  0.504 μs |  4.36 |    0.07 |   2.4414 |        - |    43.9 KB |        0.93 |
| NativeSingle      | 1000  |    15.25 μs |  0.371 μs |  0.221 μs |  1.00 |    0.02 |   2.8076 |        - |    47.2 KB |        1.00 |
| NativeParallel    | 1000  |    19.55 μs |  0.458 μs |  0.273 μs |  1.28 |    0.02 |   6.5918 |   0.1221 |  106.85 KB |        2.26 |
|                   |       |             |           |           |       |         |          |          |            |             |
| **BuilderFull**       | **10000** | **3,076.55 μs** | **36.706 μs** | **24.279 μs** | **20.65** |    **0.17** | **296.8750** | **125.0000** | **5102.54 KB** |       **10.88** |
| BuilderLatestOnly | 10000 | 2,943.75 μs | 17.864 μs |  9.343 μs | 19.76 |    0.09 | 281.2500 |  31.2500 | 4632.54 KB |        9.88 |
| NativeSingle      | 10000 |   148.96 μs |  0.992 μs |  0.519 μs |  1.00 |    0.00 |  28.3203 |   4.8828 |  469.08 KB |        1.00 |
| NativeParallel    | 10000 |   163.05 μs |  7.022 μs |  4.644 μs |  1.09 |    0.03 |  64.4531 |  12.6953 | 1056.08 KB |        2.25 |
