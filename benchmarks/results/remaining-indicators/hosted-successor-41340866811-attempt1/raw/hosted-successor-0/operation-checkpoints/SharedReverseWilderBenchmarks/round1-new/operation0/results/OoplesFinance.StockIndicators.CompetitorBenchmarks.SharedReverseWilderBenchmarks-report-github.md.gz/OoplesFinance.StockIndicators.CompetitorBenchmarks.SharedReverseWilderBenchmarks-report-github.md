```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean        | Error     | StdDev   | Gen0     | Gen1     | Allocated  |
|------------------ |------ |------------:|----------:|---------:|---------:|---------:|-----------:|
| **BuilderFull**       | **1000**  |    **63.21 μs** |  **2.208 μs** | **1.461 μs** |   **3.9063** |        **-** |   **91.78 KB** |
| BuilderLatestOnly | 1000  |    60.11 μs |  0.630 μs | 0.329 μs |   2.4414 |        - |    43.9 KB |
| **BuilderFull**       | **10000** | **2,856.57 μs** | **15.513 μs** | **9.232 μs** | **296.8750** | **125.0000** | **5102.52 KB** |
| BuilderLatestOnly | 10000 | 2,716.49 μs | 11.002 μs | 6.547 μs | 281.2500 |  46.8750 | 4632.41 KB |
