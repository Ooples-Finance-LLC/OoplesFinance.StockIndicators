```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-----------:|-----------:|-----------:|------:|--------:|--------:|--------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)bands [22]** | **1000**  |  **85.659 μs** | **10.3629 μs** |  **6.1668 μs** | **11.87** |    **0.83** |  **3.9063** |       **-** |  **84.07 KB** |        **3.62** |
| BuilderLatestOnly | TaLib(...)bands [22] | 1000  |  69.226 μs |  2.7749 μs |  1.6513 μs |  9.59 |    0.25 |  1.9531 |       - |  36.46 KB |        1.57 |
| NativeSingle      | TaLib(...)bands [22] | 1000  |   7.217 μs |  0.1662 μs |  0.0989 μs |  1.00 |    0.02 |  1.4038 |  0.0610 |   23.2 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [22] | 1000  |   6.171 μs |  0.1611 μs |  0.1066 μs |  0.86 |    0.02 |  1.4038 |  0.0610 |  23.66 KB |        1.02 |
|                   |                      |       |            |            |            |       |         |         |         |           |             |
| **BuilderFull**       | **TaLib(...)bands [22]** | **10000** | **475.801 μs** | **41.0616 μs** | **27.1597 μs** |  **7.28** |    **0.42** | **46.8750** | **19.5313** | **787.59 KB** |        **3.36** |
| BuilderLatestOnly | TaLib(...)bands [22] | 10000 | 486.052 μs | 87.9976 μs | 58.2050 μs |  7.44 |    0.86 | 15.6250 |  3.9063 | 317.75 KB |        1.36 |
| NativeSingle      | TaLib(...)bands [22] | 10000 |  65.393 μs |  2.0562 μs |  1.3601 μs |  1.00 |    0.03 | 14.1602 |  4.3945 | 234.14 KB |        1.00 |
| NativeParallel    | TaLib(...)bands [22] | 10000 |  46.350 μs |  4.3192 μs |  2.8569 μs |  0.71 |    0.04 | 14.1602 |  4.3945 |  234.6 KB |        1.00 |
