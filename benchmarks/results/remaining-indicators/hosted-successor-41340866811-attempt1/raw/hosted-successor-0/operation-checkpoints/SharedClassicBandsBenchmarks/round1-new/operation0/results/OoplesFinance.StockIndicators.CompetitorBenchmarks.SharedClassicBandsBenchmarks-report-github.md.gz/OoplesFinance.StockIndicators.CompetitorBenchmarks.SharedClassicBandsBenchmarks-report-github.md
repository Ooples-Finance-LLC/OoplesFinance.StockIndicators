```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)bands [22]** | **1000**  | **112.06 μs** | **31.166 μs** | **20.614 μs** |  **3.9063** |       **-** |  **84.07 KB** |
| BuilderLatestOnly | TaLib(...)bands [22] | 1000  |  68.33 μs |  4.445 μs |  2.645 μs |  1.9531 |       - |  36.46 KB |
| **BuilderFull**       | **TaLib(...)bands [22]** | **10000** | **488.99 μs** | **63.240 μs** | **41.829 μs** | **46.8750** | **19.5313** | **787.58 KB** |
| BuilderLatestOnly | TaLib(...)bands [22] | 10000 | 443.30 μs | 33.677 μs | 17.613 μs | 15.6250 |  3.9063 | 317.74 KB |
