```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean      | Error     | StdDev    | Gen0    | Gen1    | Allocated |
|------------------ |--------------------- |------ |----------:|----------:|----------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)bands [22]** | **1000**  |  **89.34 μs** |  **6.609 μs** |  **3.457 μs** |  **3.9063** |       **-** |  **84.11 KB** |
| BuilderLatestOnly | TaLib(...)bands [22] | 1000  |  66.81 μs |  1.156 μs |  0.604 μs |  1.9531 |       - |  36.46 KB |
| **BuilderFull**       | **TaLib(...)bands [22]** | **10000** | **469.51 μs** | **63.021 μs** | **37.503 μs** | **46.8750** | **19.5313** | **787.59 KB** |
| BuilderLatestOnly | TaLib(...)bands [22] | 10000 | 448.90 μs | 40.708 μs | 24.225 μs | 15.6250 |  3.9063 | 317.75 KB |
