```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **542.7 μs** |   **8.20 μs** |   **4.29 μs** |       **-** |     **65 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   506.6 μs |   5.56 μs |   3.31 μs |       - |   17.4 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **5,828.1 μs** | **153.88 μs** | **101.78 μs** | **31.2500** |    **628 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 5,588.4 μs |  38.73 μs |  20.25 μs |       - | 158.18 KB |
