```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error      | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|-----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **479.92 μs** |   **6.881 μs** |  **4.095 μs** | **36.12** |    **0.64** |       **-** |      **-** |  **66.72 KB** |        **4.45** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   468.10 μs |   7.225 μs |  4.299 μs | 35.23 |    0.64 |       - |      - |  19.13 KB |        1.28 |
| NativeSingle      | TaLib.Functions.Adxr | 1000  |    13.29 μs |   0.377 μs |  0.224 μs |  1.00 |    0.02 |  0.8545 |      - |  14.99 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 1000  |    24.00 μs |   1.274 μs |  0.843 μs |  1.81 |    0.07 |  2.9297 |      - |  45.43 KB |        3.03 |
|                   |                      |       |             |            |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **5,204.72 μs** | **114.364 μs** | **75.645 μs** | **39.14** |    **1.08** | **31.2500** |      **-** | **638.65 KB** |        **4.10** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 5,252.04 μs | 129.412 μs | 77.011 μs | 39.50 |    1.10 |       - |      - | 168.81 KB |        1.08 |
| NativeSingle      | TaLib.Functions.Adxr | 10000 |   133.05 μs |   5.173 μs |  3.421 μs |  1.00 |    0.03 |  8.7891 | 0.9766 | 155.62 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adxr | 10000 |   196.36 μs |  14.571 μs |  9.638 μs |  1.48 |    0.08 | 30.2734 | 8.7891 | 467.31 KB |        3.00 |
