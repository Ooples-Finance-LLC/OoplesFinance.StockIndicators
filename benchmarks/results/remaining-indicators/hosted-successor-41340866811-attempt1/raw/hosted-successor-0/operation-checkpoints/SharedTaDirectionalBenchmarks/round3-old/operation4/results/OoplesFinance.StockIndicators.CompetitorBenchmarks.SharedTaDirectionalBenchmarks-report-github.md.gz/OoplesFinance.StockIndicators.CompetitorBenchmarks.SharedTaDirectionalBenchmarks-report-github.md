```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **537.5 μs** |  **7.05 μs** |  **3.69 μs** |       **-** |     **65 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   509.6 μs |  5.83 μs |  3.05 μs |       - |  17.41 KB |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **5,594.2 μs** | **42.89 μs** | **25.53 μs** | **31.2500** | **627.95 KB** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 5,606.4 μs | 17.51 μs |  9.16 μs |       - | 158.21 KB |
