```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev  | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **222.1 μs** |  **4.63 μs** | **2.76 μs** |       **-** |  **64.97 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   219.4 μs |  1.49 μs | 0.78 μs |       - |   17.4 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **2,526.2 μs** | **11.19 μs** | **5.85 μs** | **31.2500** | **627.93 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,483.5 μs |  4.43 μs | 2.31 μs |       - | 158.11 KB |
