```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **218.387 μs** | **11.7015 μs** |  **7.7398 μs** | **34.74** |    **1.31** |       **-** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   220.964 μs |  2.3206 μs |  1.2137 μs | 35.15 |    0.61 |       - |      - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib(...)lusDI [22] | 1000  |     6.288 μs |  0.1657 μs |  0.1096 μs |  1.00 |    0.02 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 1000  |     9.667 μs |  0.2525 μs |  0.1503 μs |  1.54 |    0.03 |  1.8311 | 0.0610 |  27.24 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **2,423.911 μs** | **15.9089 μs** |  **9.4671 μs** | **41.14** |    **0.16** | **31.2500** |      **-** | **627.94 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,398.555 μs | 21.3991 μs | 11.1921 μs | 40.71 |    0.18 |       - |      - | 158.11 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDI [22] | 10000 |    58.912 μs |  0.1314 μs |  0.0687 μs |  1.00 |    0.00 |  4.3945 |      - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDI [22] | 10000 |   106.053 μs |  3.6228 μs |  2.3962 μs |  1.80 |    0.04 | 18.5547 | 4.8828 | 273.34 KB |        3.50 |
