```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **236.234 μs** |  **8.9905 μs** |  **4.7022 μs** | **39.12** |    **0.74** |       **-** |      **-** |  **64.96 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   215.900 μs |  1.3012 μs |  0.6805 μs | 35.75 |    0.13 |       - |      - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDI [23] | 1000  |     6.039 μs |  0.0230 μs |  0.0137 μs |  1.00 |    0.00 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 1000  |     9.545 μs |  0.3009 μs |  0.1990 μs |  1.58 |    0.03 |  1.8311 | 0.0610 |  27.24 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **2,451.137 μs** | **15.2347 μs** |  **9.0659 μs** | **41.37** |    **0.25** | **31.2500** |      **-** | **627.91 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,442.756 μs | 72.8634 μs | 43.3598 μs | 41.23 |    0.72 |       - |      - | 158.11 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDI [23] | 10000 |    59.252 μs |  0.5196 μs |  0.3092 μs |  1.00 |    0.01 |  4.3945 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDI [23] | 10000 |   106.251 μs |  2.9895 μs |  1.9773 μs |  1.79 |    0.03 | 18.5547 | 4.8828 | 273.34 KB |        3.50 |
