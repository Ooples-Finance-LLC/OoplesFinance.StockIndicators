```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |-------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **464.28 μs** |  **6.409 μs** |  **3.814 μs** | **38.71** |    **0.36** |       **-** |      **-** |  **65.65 KB** |        **8.67** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   466.45 μs | 14.468 μs |  8.610 μs | 38.89 |    0.71 |       - |      - |  18.05 KB |        2.38 |
| NativeSingle      | TaLib.Functions.Adx | 1000  |    11.99 μs |  0.119 μs |  0.062 μs |  1.00 |    0.01 |  0.3662 |      - |   7.57 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 1000  |    21.68 μs |  1.432 μs |  0.947 μs |  1.81 |    0.08 |  1.8311 |      - |  26.71 KB |        3.53 |
|                   |                     |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **4,985.64 μs** | **10.415 μs** |  **5.447 μs** | **42.69** |    **0.87** | **31.2500** |      **-** | **637.57 KB** |        **8.19** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 5,000.13 μs | 26.972 μs | 14.107 μs | 42.81 |    0.88 |       - |      - | 167.78 KB |        2.15 |
| NativeSingle      | TaLib.Functions.Adx | 10000 |   116.83 μs |  3.863 μs |  2.555 μs |  1.00 |    0.03 |  3.9063 |      - |  77.89 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Adx | 10000 |   172.55 μs | 11.980 μs |  7.924 μs |  1.48 |    0.07 | 17.5781 | 3.9063 | 272.81 KB |        3.50 |
