```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **125.749 μs** |  **1.6669 μs** |  **0.9919 μs** | **13.47** |    **0.11** |  **3.9063** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   120.781 μs |  0.6144 μs |  0.3214 μs | 12.94 |    0.05 |  0.9766 |      - |  17.38 KB |        2.25 |
| NativeSingle      | TaLib(...)nusDM [23] | 1000  |     9.333 μs |  0.0502 μs |  0.0332 μs |  1.00 |    0.00 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 1000  |    12.658 μs |  0.9948 μs |  0.6580 μs |  1.36 |    0.07 |  1.8311 |      - |  27.23 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,392.892 μs** | **14.1791 μs** |  **7.4159 μs** | **15.20** |    **0.09** | **31.2500** | **7.8125** | **627.88 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 1,380.375 μs | 24.3863 μs | 14.5119 μs | 15.07 |    0.16 |  7.8125 |      - | 158.07 KB |        2.03 |
| NativeSingle      | TaLib(...)nusDM [23] | 10000 |    91.616 μs |  0.4782 μs |  0.3163 μs |  1.00 |    0.00 |  4.3945 |      - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)nusDM [23] | 10000 |   133.265 μs |  2.4945 μs |  1.6500 μs |  1.45 |    0.02 | 17.5781 | 3.9063 | 273.33 KB |        3.50 |
