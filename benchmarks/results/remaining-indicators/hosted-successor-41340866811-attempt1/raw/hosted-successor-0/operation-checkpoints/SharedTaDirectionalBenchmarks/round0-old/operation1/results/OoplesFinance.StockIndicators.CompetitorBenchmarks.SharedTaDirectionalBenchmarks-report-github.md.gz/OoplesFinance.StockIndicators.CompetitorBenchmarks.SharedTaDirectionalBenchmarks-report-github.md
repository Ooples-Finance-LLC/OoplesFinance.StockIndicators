```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev  | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|--------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **1000**  |   **123.3 μs** |  **0.96 μs** | **0.57 μs** |  **3.9063** |      **-** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 1000  |   124.0 μs |  8.89 μs | 5.29 μs |  0.9766 |      - |  17.39 KB |
| **BuilderFull**       | **TaLib(...)nusDM [23]** | **10000** | **1,389.8 μs** | **10.43 μs** | **5.45 μs** | **31.2500** | **7.8125** | **627.89 KB** |
| BuilderLatestOnly | TaLib(...)nusDM [23] | 10000 | 1,370.0 μs | 10.09 μs | 5.28 μs |  7.8125 |      - | 158.08 KB |
