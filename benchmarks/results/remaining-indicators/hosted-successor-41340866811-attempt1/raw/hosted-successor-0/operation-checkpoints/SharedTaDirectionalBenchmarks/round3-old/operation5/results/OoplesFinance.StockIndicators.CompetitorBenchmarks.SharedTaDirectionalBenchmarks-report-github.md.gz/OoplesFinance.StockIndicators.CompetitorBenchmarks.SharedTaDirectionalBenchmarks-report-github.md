```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation           | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |-------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adx** | **1000**  |   **470.9 μs** |  **4.27 μs** |  **2.23 μs** |       **-** |  **65.65 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 1000  |   469.6 μs | 14.01 μs |  8.34 μs |       - |  18.05 KB |
| **BuilderFull**       | **TaLib.Functions.Adx** | **10000** | **5,158.7 μs** | **63.81 μs** | **37.97 μs** | **31.2500** | **637.55 KB** |
| BuilderLatestOnly | TaLib.Functions.Adx | 10000 | 5,092.2 μs | 33.66 μs | 20.03 μs |       - | 167.57 KB |
