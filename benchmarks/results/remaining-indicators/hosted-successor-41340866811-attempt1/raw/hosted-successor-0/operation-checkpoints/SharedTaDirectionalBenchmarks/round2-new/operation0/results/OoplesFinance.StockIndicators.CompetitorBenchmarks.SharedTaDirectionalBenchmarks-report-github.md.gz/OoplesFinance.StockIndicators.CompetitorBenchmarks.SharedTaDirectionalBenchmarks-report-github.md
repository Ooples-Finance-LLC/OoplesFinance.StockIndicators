```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|-----------:|-----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **121.510 μs** |  **1.3376 μs** |  **0.6996 μs** | **13.03** |    **0.09** |  **3.9063** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   117.050 μs |  1.4438 μs |  0.7551 μs | 12.55 |    0.09 |  0.9766 |      - |  17.39 KB |        2.25 |
| NativeSingle      | TaLib(...)lusDM [22] | 1000  |     9.324 μs |  0.0598 μs |  0.0396 μs |  1.00 |    0.01 |  0.4272 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 1000  |    12.645 μs |  0.4922 μs |  0.3256 μs |  1.36 |    0.03 |  1.8311 |      - |  27.23 KB |        3.53 |
|                   |                      |       |              |            |            |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **1,396.021 μs** |  **3.8241 μs** |  **2.5294 μs** | **15.30** |    **0.05** | **31.2500** | **7.8125** | **627.88 KB** |        **8.05** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 1,370.418 μs | 17.7784 μs | 10.5796 μs | 15.02 |    0.12 |  7.8125 |      - | 158.07 KB |        2.03 |
| NativeSingle      | TaLib(...)lusDM [22] | 10000 |    91.247 μs |  0.4052 μs |  0.2411 μs |  1.00 |    0.00 |  4.3945 |      - |  78.03 KB |        1.00 |
| NativeParallel    | TaLib(...)lusDM [22] | 10000 |   134.440 μs |  4.0796 μs |  2.4277 μs |  1.47 |    0.03 | 17.5781 | 3.9063 | 273.33 KB |        3.50 |
