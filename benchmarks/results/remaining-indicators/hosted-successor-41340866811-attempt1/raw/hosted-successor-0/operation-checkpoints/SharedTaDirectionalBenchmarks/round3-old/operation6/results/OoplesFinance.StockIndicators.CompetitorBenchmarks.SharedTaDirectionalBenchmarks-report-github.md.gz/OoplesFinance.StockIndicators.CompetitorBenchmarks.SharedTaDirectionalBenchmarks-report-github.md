```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **485.1 μs** |   **7.72 μs** |  **4.60 μs** |       **-** |  **66.77 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   454.1 μs |   2.84 μs |  1.48 μs |       - |  19.13 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **5,182.1 μs** | **117.28 μs** | **77.58 μs** | **31.2500** | **638.59 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 5,105.6 μs |  44.02 μs | 23.02 μs |       - | 168.74 KB |
