```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Gen1   | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|-------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **1000**  |   **129.6 μs** | **18.70 μs** | **11.13 μs** |  **3.9063** |      **-** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 1000  |   118.5 μs |  0.80 μs |  0.48 μs |  0.9766 |      - |  17.39 KB |
| **BuilderFull**       | **TaLib(...)lusDM [22]** | **10000** | **1,416.5 μs** | **23.84 μs** | **15.77 μs** | **31.2500** | **7.8125** | **627.89 KB** |
| BuilderLatestOnly | TaLib(...)lusDM [22] | 10000 | 1,396.6 μs | 26.60 μs | 17.60 μs |  7.8125 |      - | 158.05 KB |
