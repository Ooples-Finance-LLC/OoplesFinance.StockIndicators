```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev  | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **1000**  |   **222.7 μs** |  **3.08 μs** | **1.61 μs** |       **-** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 1000  |   217.6 μs |  2.25 μs | 1.18 μs |       - |   17.4 KB |
| **BuilderFull**       | **TaLib(...)nusDI [23]** | **10000** | **2,483.7 μs** | **16.99 μs** | **8.89 μs** | **31.2500** | **627.95 KB** |
| BuilderLatestOnly | TaLib(...)nusDI [23] | 10000 | 2,457.8 μs | 14.73 μs | 7.71 μs |       - | 158.09 KB |
