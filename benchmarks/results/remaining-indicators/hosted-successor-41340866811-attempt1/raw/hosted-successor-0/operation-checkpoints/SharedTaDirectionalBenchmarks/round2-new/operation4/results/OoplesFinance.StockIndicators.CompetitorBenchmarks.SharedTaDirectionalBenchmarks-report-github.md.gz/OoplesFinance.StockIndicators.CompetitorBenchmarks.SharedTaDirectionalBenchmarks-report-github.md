```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation          | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1   | Allocated | Alloc Ratio |
|------------------ |------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|-------:|----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Dx** | **1000**  |   **508.86 μs** |  **5.250 μs** |  **3.124 μs** | **39.08** |    **0.38** |       **-** |      **-** |     **65 KB** |        **8.42** |
| BuilderLatestOnly | TaLib.Functions.Dx | 1000  |   503.08 μs |  3.853 μs |  2.293 μs | 38.63 |    0.34 |       - |      - |   17.4 KB |        2.25 |
| NativeSingle      | TaLib.Functions.Dx | 1000  |    13.02 μs |  0.160 μs |  0.106 μs |  1.00 |    0.01 |  0.3662 |      - |   7.72 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 1000  |    19.50 μs |  0.696 μs |  0.364 μs |  1.50 |    0.03 |  1.8311 |      - |  27.24 KB |        3.53 |
|                   |                    |       |             |           |           |       |         |         |        |           |             |
| **BuilderFull**       | **TaLib.Functions.Dx** | **10000** | **5,541.47 μs** | **40.558 μs** | **24.135 μs** | **42.14** |    **0.18** | **31.2500** |      **-** | **628.02 KB** |        **8.05** |
| BuilderLatestOnly | TaLib.Functions.Dx | 10000 | 5,516.72 μs | 63.472 μs | 37.771 μs | 41.96 |    0.28 |       - |      - | 158.22 KB |        2.03 |
| NativeSingle      | TaLib.Functions.Dx | 10000 |   131.49 μs |  0.311 μs |  0.185 μs |  1.00 |    0.00 |  3.9063 |      - |  78.04 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Dx | 10000 |   186.44 μs |  6.279 μs |  4.153 μs |  1.42 |    0.03 | 17.5781 | 3.9063 | 273.34 KB |        3.50 |
