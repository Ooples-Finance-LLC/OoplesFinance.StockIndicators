```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Adxr** | **1000**  |   **469.6 μs** |  **19.42 μs** |  **12.85 μs** |       **-** |  **66.72 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 1000  |   457.8 μs |   9.67 μs |   5.06 μs |       - |  19.13 KB |
| **BuilderFull**       | **TaLib.Functions.Adxr** | **10000** | **5,189.0 μs** |  **39.24 μs** |  **20.52 μs** | **31.2500** | **638.63 KB** |
| BuilderLatestOnly | TaLib.Functions.Adxr | 10000 | 5,122.5 μs | 171.66 μs | 102.15 μs |       - | 168.81 KB |
