```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **1000**  |   **220.7 μs** |  **2.94 μs** |  **1.54 μs** |       **-** |     **65 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 1000  |   220.1 μs |  1.87 μs |  1.11 μs |       - |  17.39 KB |
| **BuilderFull**       | **TaLib(...)lusDI [22]** | **10000** | **2,509.4 μs** | **22.64 μs** | **13.47 μs** | **31.2500** | **627.95 KB** |
| BuilderLatestOnly | TaLib(...)lusDI [22] | 10000 | 2,496.4 μs | 47.53 μs | 24.86 μs |       - |  158.1 KB |
