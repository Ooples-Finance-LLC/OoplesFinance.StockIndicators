```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error     | StdDev    | Gen0    | Gen1    | Allocated  |
|------------------ |------ |-----------:|----------:|----------:|--------:|--------:|-----------:|
| **BuilderFull**       | **1000**  |   **270.9 μs** |  **97.07 μs** |  **64.20 μs** |  **7.8125** |       **-** |  **128.46 KB** |
| BuilderLatestOnly | 1000  |   237.4 μs |  31.74 μs |  20.99 μs |  3.9063 |       - |   80.85 KB |
| **BuilderFull**       | **10000** | **1,786.7 μs** | **142.51 μs** |  **74.53 μs** | **62.5000** | **31.2500** | **1183.63 KB** |
| BuilderLatestOnly | 10000 | 1,827.8 μs | 268.21 μs | 177.40 μs | 31.2500 | 15.6250 |   713.8 KB |
