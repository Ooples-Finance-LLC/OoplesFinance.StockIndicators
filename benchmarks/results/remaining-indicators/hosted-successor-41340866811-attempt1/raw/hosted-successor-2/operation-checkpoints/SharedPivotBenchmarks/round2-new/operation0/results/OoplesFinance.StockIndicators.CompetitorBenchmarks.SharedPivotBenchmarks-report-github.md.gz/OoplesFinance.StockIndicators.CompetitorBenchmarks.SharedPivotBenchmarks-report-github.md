```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Count | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |------ |-----------:|----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **1000**  |   **332.2 μs** | **111.50 μs** |  **73.75 μs** |  **0.54** |    **0.11** |   **7.8125** |        **-** |  **128.49 KB** |        **0.26** |
| BuilderLatestOnly | 1000  |   213.4 μs |  28.66 μs |  17.06 μs |  0.35 |    0.03 |   3.9063 |        - |   80.85 KB |        0.16 |
| NativeSingle      | 1000  |   616.8 μs |   4.88 μs |   2.55 μs |  1.00 |    0.01 |  27.3438 |   7.8125 |  499.64 KB |        1.00 |
| NativeParallel    | 1000  |   340.1 μs |  25.14 μs |  16.63 μs |  0.55 |    0.03 |  31.2500 |   9.7656 |  525.33 KB |        1.05 |
|                   |       |            |           |           |       |         |          |          |            |             |
| **BuilderFull**       | **10000** | **1,856.2 μs** | **159.20 μs** |  **94.74 μs** |  **0.29** |    **0.01** |  **62.5000** |  **31.2500** | **1183.62 KB** |        **0.24** |
| BuilderLatestOnly | 10000 | 1,922.3 μs | 279.40 μs | 184.81 μs |  0.30 |    0.03 |  31.2500 |  15.6250 |   713.8 KB |        0.14 |
| NativeSingle      | 10000 | 6,471.4 μs |  51.88 μs |  30.87 μs |  1.00 |    0.01 | 250.0000 | 187.5000 | 5035.32 KB |        1.00 |
| NativeParallel    | 10000 | 3,582.0 μs | 222.66 μs | 147.28 μs |  0.55 |    0.02 | 312.5000 | 218.7500 | 5131.11 KB |        1.02 |
