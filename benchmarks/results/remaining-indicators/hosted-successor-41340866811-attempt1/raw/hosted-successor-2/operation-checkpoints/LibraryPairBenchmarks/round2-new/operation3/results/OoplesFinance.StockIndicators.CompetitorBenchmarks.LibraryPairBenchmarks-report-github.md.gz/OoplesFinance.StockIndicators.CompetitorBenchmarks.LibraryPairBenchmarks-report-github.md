```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId        | Mean        | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------- |------------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Rma** |    **398.3 μs** |     **8.52 μs** |     **4.46 μs** |  **1.00** |    **0.01** |    **97.6 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Rma |    291.0 μs |    17.00 μs |     8.89 μs |  0.73 |    0.02 |    55.1 KB |        0.56 |
|            |       |               |             |             |             |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Rma** | **19,157.2 μs** | **6,961.81 μs** | **4,604.81 μs** |  **1.06** |    **0.38** | **5245.38 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Rma |  1,479.3 μs |   101.31 μs |    67.01 μs |  0.08 |    0.02 |  477.05 KB |        0.09 |
