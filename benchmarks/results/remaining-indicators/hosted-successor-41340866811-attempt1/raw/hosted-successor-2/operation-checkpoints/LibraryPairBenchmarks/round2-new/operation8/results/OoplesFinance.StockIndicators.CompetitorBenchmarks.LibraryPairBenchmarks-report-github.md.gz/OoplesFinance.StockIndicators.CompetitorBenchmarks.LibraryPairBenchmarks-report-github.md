```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|----------:|------:|--------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)Index [37]** |   **2.535 ms** | **0.0749 ms** | **0.0495 ms** |  **1.00** |    **0.03** |         **-** |         **-** |   **108.34 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)Index [37] |  50.690 ms | 0.3995 ms | 0.2089 ms | 20.00 |    0.38 |         - |         - |  4767.39 KB |       44.01 |
|            |       |                      |            |           |           |       |         |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)Index [37]** |   **3.590 ms** | **0.0900 ms** | **0.0535 ms** |  **1.00** |    **0.02** |         **-** |         **-** |  **1040.33 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)Index [37] | 146.987 ms | 1.7581 ms | 1.1629 ms | 40.95 |    0.65 | 2000.0000 | 1000.0000 | 48262.59 KB |       46.39 |
