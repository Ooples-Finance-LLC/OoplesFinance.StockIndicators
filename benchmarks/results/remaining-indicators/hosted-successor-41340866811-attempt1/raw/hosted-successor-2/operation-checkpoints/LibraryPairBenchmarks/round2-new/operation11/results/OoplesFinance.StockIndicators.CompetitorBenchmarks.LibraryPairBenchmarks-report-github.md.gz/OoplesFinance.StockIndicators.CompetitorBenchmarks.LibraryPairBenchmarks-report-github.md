```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |----------:|----------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)nnels [31]** |  **2.377 ms** | **0.0309 ms** | **0.0184 ms** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |   **219.05 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)nnels [31] |  7.844 ms | 0.0797 ms | 0.0474 ms |  3.30 |    0.03 |         - |         - |         - |  3955.27 KB |       18.06 |
|            |       |                      |           |           |           |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)nnels [31]** | **20.037 ms** | **5.6090 ms** | **3.7100 ms** |  **1.03** |    **0.26** |         **-** |         **-** |         **-** |  **2153.04 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)nnels [31] | 26.151 ms | 6.0945 ms | 4.0312 ms |  1.35 |    0.31 | 2000.0000 | 1000.0000 | 1000.0000 | 33254.32 KB |       15.45 |
