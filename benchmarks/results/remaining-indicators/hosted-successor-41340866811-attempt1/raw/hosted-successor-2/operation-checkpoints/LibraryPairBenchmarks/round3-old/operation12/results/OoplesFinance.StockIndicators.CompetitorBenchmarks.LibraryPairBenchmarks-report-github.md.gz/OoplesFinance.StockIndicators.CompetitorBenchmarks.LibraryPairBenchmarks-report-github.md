```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean      | Error      | StdDev     | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |----------:|-----------:|-----------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Trady(...)gence [50]** |  **5.471 ms** |  **0.0326 ms** |  **0.0194 ms** |  **1.00** |    **0.00** |  **290.13 KB** |        **1.00** |
|        |       |                      |           |            |            |       |         |            |             |
| **Ooples** | **10000** | **Trady(...)gence [50]** | **42.859 ms** | **21.0647 ms** | **12.5353 ms** |  **1.16** |    **0.70** | **2857.21 KB** |        **1.00** |
