```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId           | Mean       | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |----------------- |-----------:|---------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Afirma** |   **763.7 μs** | **22.80 μs** | **15.08 μs** |  **1.00** |    **0.03** |  **24.68 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Afirma | 1,205.2 μs | 26.47 μs | 17.51 μs |  1.58 |    0.04 |  55.77 KB |        2.26 |
|            |       |                  |            |          |          |       |         |           |             |
| **Ooples**     | **10000** | **QuanTAlib.Afirma** | **1,109.4 μs** | **58.03 μs** | **34.53 μs** |  **1.00** |    **0.04** | **243.45 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Afirma | 1,833.1 μs | 29.41 μs | 17.50 μs |  1.65 |    0.05 | 477.93 KB |        1.96 |
