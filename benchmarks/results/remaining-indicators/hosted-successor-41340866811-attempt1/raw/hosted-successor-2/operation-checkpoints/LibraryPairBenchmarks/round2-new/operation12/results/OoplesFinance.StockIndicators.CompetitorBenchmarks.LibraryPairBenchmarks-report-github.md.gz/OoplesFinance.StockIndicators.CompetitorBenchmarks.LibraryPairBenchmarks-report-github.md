```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error      | StdDev     | Median    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |----------:|-----------:|-----------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)gence [50]** |  **4.849 ms** |  **0.0301 ms** |  **0.0157 ms** |  **4.848 ms** |  **1.00** |    **0.00** |         **-** |         **-** |         **-** |   **290.13 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)gence [50] |  9.515 ms |  0.1653 ms |  0.0864 ms |  9.505 ms |  1.96 |    0.02 |         - |         - |         - |  4583.54 KB |       15.80 |
|            |       |                      |           |            |            |           |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)gence [50]** | **21.664 ms** | **27.6418 ms** | **18.2834 ms** | **13.178 ms** |  **1.90** |    **2.22** |         **-** |         **-** |         **-** |  **2856.88 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)gence [50] | 26.099 ms |  5.2099 ms |  3.4460 ms | 24.277 ms |  2.29 |    1.55 | 2000.0000 | 1000.0000 | 1000.0000 | 34698.83 KB |       12.15 |
