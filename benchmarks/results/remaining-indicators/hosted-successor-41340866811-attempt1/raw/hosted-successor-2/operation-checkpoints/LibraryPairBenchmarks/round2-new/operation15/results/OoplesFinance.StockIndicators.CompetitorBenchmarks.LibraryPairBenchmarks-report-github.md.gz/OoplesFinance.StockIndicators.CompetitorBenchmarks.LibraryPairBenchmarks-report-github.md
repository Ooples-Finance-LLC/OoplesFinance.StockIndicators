```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error        | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)erage [37]** |    **148.6 μs** |      **7.98 μs** |     **4.75 μs** |  **1.00** |    **0.04** |   **65.77 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)erage [37] |  7,968.4 μs |     72.33 μs |    47.84 μs | 53.68 |    1.64 |  913.82 KB |       13.89 |
|            |       |                      |             |              |             |       |         |            |             |
| **Ooples**     | **10000** | **Trady(...)erage [37]** |    **366.5 μs** |     **58.59 μs** |    **34.86 μs** |  **1.01** |    **0.12** |  **637.09 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)erage [37] | 33,232.8 μs | 10,346.85 μs | 6,843.80 μs | 91.32 |   19.47 | 8952.48 KB |       14.05 |
