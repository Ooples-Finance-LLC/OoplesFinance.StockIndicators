```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean       | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------- |-----------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetAdl** |   **744.5 μs** |    **43.83 μs** |    **26.08 μs** |  **1.00** |    **0.05** |  **246.88 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetAdl |   537.3 μs |    23.16 μs |    13.78 μs |  0.72 |    0.03 |  274.36 KB |        1.11 |
|            |       |                |            |             |             |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetAdl** | **4,713.5 μs** | **2,578.64 μs** | **1,705.61 μs** |  **1.17** |    **0.68** | **2814.32 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetAdl | 1,467.7 μs |    55.80 μs |    33.20 μs |  0.37 |    0.16 |  2656.2 KB |        0.94 |
