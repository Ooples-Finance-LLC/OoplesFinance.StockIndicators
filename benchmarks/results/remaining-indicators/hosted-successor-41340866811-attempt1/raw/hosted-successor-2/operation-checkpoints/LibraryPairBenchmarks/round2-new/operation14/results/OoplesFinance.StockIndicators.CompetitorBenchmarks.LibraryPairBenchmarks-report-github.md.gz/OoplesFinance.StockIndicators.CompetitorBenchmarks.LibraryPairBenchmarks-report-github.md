```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|----------:|----------:|------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)lator [45]** |    **490.9 μs** |  **33.09 μs** |  **19.69 μs** |  **1.00** |    **0.05** |   **107.97 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)lator [45] |  6,187.0 μs | 106.59 μs |  70.51 μs | 12.62 |    0.48 |  1702.57 KB |       15.77 |
|            |       |                      |             |           |           |       |         |             |             |
| **Ooples**     | **10000** | **Trady(...)lator [45]** |  **3,565.9 μs** |  **54.13 μs** |  **28.31 μs** |  **1.00** |    **0.01** |  **1040.29 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)lator [45] | 13,783.6 μs | 181.81 μs | 108.19 μs |  3.87 |    0.04 | 13491.72 KB |       12.97 |
