```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId        | Mean        | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |-------------- |------------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **QuanTAlib.Rma** |    **442.4 μs** |  **36.73 μs** | **24.29 μs** |  **1.00** |    **0.07** |    **97.6 KB** |        **1.00** |
|        |       |               |             |           |          |       |         |            |             |
| **Ooples** | **10000** | **QuanTAlib.Rma** | **11,574.0 μs** | **171.97 μs** | **89.94 μs** |  **1.00** |    **0.01** | **5245.98 KB** |        **1.00** |
