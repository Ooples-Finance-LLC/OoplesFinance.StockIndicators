```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId       | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.T3** | **1,030.3 μs** |  **52.00 μs** |  **34.40 μs** |  **1.00** |    **0.04** |  **105.89 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.T3 |   384.1 μs |  21.53 μs |  12.81 μs |  0.37 |    0.02 |   73.72 KB |        0.70 |
|            |       |              |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.T3** | **3,316.9 μs** | **920.16 μs** | **608.63 μs** |  **1.03** |    **0.24** | **1037.23 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.T3 |   995.8 μs |  44.15 μs |  26.27 μs |  0.31 |    0.05 |  645.01 KB |        0.62 |
