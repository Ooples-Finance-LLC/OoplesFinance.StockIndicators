```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------- |-----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Dwma** |   **301.1 μs** |   **7.19 μs** |  **3.76 μs** |  **1.00** |    **0.02** |  **66.41 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Dwma | 1,257.0 μs | 111.81 μs | 66.54 μs |  4.18 |    0.22 | 547.73 KB |        8.25 |
|            |       |                |            |           |          |       |         |           |             |
| **Ooples**     | **10000** | **QuanTAlib.Dwma** |   **899.9 μs** |  **41.56 μs** | **21.74 μs** |  **1.00** |    **0.03** | **636.73 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Dwma | 2,163.8 μs |  87.04 μs | 51.80 μs |  2.41 |    0.08 | 5448.8 KB |        8.56 |
