```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean      | Error     | StdDev    | Ratio | Allocated  | Alloc Ratio |
|------- |------ |--------------------- |----------:|----------:|----------:|------:|-----------:|------------:|
| **Ooples** | **1000**  | **Trady(...)nnels [31]** |  **2.428 ms** | **0.0412 ms** | **0.0216 ms** |  **1.00** |  **219.01 KB** |        **1.00** |
|        |       |                      |           |           |           |       |            |             |
| **Ooples** | **10000** | **Trady(...)nnels [31]** | **15.977 ms** | **0.2559 ms** | **0.1523 ms** |  **1.00** | **2152.95 KB** |        **1.00** |
