```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId        | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Wma** |   **141.6 μs** |   **7.84 μs** |  **4.10 μs** |  **1.00** |    **0.04** |   **65.77 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Wma |   679.3 μs |  62.93 μs | 32.92 μs |  4.80 |    0.25 |  262.23 KB |        3.99 |
|            |       |               |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **QuanTAlib.Wma** |   **349.2 μs** | **107.38 μs** | **63.90 μs** |  **1.03** |    **0.27** |   **636.1 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Wma | 1,136.7 μs |  47.93 μs | 25.07 μs |  3.36 |    0.64 | 2572.32 KB |        4.04 |
