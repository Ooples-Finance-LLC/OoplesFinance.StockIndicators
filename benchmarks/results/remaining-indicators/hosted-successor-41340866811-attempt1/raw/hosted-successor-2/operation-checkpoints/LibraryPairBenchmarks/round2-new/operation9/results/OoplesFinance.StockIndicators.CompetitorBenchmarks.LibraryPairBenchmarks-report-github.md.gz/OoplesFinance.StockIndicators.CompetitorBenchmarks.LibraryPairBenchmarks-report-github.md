```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean         | Error        | StdDev       | Ratio  | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |-------------:|-------------:|-------------:|-------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)erage [40]** |     **287.2 μs** |     **39.03 μs** |     **25.81 μs** |   **1.01** |    **0.12** |    **64.78 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)erage [40] |  23,186.2 μs |    655.11 μs |    342.63 μs |  81.27 |    6.61 |  1489.16 KB |       22.99 |
|            |       |                      |              |              |              |        |         |             |             |
| **Ooples**     | **10000** | **Trady(...)erage [40]** |     **543.5 μs** |     **41.31 μs** |     **21.61 μs** |   **1.00** |    **0.05** |   **634.83 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)erage [40] | 250,498.0 μs | 21,140.05 μs | 13,982.83 μs | 461.57 |   29.87 | 13293.31 KB |       20.94 |
