```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean        | Error        | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |------------:|-------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)lator [50]** |    **837.8 μs** |     **47.91 μs** |    **31.69 μs** |  **1.00** |    **0.05** |         **-** |         **-** |         **-** |   **105.69 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)lator [50] |  6,654.2 μs |    187.55 μs |   124.05 μs |  7.95 |    0.32 |         - |         - |         - |  3073.43 KB |       29.08 |
|            |       |                      |             |              |             |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)lator [50]** |  **5,434.4 μs** |     **67.70 μs** |    **40.29 μs** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |  **1038.01 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)lator [50] | 31,228.7 μs | 13,064.82 μs | 8,641.57 μs |  5.75 |    1.52 | 1000.0000 | 1000.0000 | 1000.0000 | 24966.65 KB |       24.05 |
