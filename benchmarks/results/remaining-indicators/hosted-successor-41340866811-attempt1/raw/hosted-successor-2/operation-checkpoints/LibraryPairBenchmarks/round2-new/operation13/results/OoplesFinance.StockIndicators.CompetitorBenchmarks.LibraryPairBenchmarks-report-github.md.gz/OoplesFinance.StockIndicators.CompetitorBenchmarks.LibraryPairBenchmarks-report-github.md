```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean      | Error      | StdDev     | Median    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|----------- |------ |--------------------- |----------:|-----------:|-----------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **Ooples**     | **1000**  | **Trady(...)ogram [59]** |  **4.450 ms** |  **0.0384 ms** |  **0.0228 ms** |  **4.448 ms** |  **1.00** |    **0.01** |         **-** |         **-** |         **-** |   **240.77 KB** |        **1.00** |
| Competitor | 1000  | Trady(...)ogram [59] |  9.888 ms |  0.3614 ms |  0.2151 ms |  9.805 ms |  2.22 |    0.05 |         - |         - |         - |  4823.67 KB |       20.03 |
|            |       |                      |           |            |            |           |       |         |           |           |           |             |             |
| **Ooples**     | **10000** | **Trady(...)ogram [59]** | **24.001 ms** | **25.9780 ms** | **17.1828 ms** | **14.882 ms** |  **1.63** |    **1.62** |         **-** |         **-** |         **-** |   **2368.4 KB** |        **1.00** |
| Competitor | 10000 | Trady(...)ogram [59] | 38.288 ms |  8.0062 ms |  5.2956 ms | 40.841 ms |  2.60 |    1.61 | 2000.0000 | 1000.0000 | 1000.0000 | 36351.61 KB |       15.35 |
