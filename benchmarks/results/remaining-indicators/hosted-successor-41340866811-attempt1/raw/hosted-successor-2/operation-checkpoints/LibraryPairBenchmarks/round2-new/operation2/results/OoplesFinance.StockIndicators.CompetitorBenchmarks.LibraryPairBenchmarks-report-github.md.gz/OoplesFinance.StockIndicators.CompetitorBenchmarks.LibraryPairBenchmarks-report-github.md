```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean       | Error       | StdDev      | Median     | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------- |------ |--------------- |-----------:|------------:|------------:|-----------:|------:|--------:|----------:|------------:|
| **Ooples**     | **1000**  | **QuanTAlib.Fwma** |   **403.8 μs** |    **17.97 μs** |    **10.69 μs** |   **401.7 μs** |  **1.00** |    **0.04** |  **15.98 KB** |        **1.00** |
| Competitor | 1000  | QuanTAlib.Fwma |   672.7 μs |    17.39 μs |    10.35 μs |   668.3 μs |  1.67 |    0.05 | 262.13 KB |       16.41 |
|            |       |                |            |             |             |            |       |         |           |             |
| **Ooples**     | **10000** | **QuanTAlib.Fwma** | **1,767.2 μs** | **2,414.02 μs** | **1,596.73 μs** |   **552.3 μs** |  **2.19** |    **2.64** |  **164.1 KB** |        **1.00** |
| Competitor | 10000 | QuanTAlib.Fwma | 1,114.3 μs |    59.65 μs |    35.50 μs | 1,103.4 μs |  1.38 |    0.88 | 2572.5 KB |       15.68 |
