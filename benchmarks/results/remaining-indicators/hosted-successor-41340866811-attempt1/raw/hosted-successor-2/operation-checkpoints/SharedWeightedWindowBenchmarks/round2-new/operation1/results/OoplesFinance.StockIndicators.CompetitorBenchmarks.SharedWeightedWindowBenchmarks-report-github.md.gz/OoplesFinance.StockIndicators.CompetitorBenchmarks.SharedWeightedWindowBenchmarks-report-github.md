```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean       | Error     | StdDev   | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |---------- |------ |-----------:|----------:|---------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Dwma**      | **1000**  |   **144.3 μs** |   **7.65 μs** |  **5.06 μs** |  **0.85** |    **0.03** |   **7.8125** |       **-** |  **173.26 KB** |        **0.32** |
| BuilderLatestOnly | Dwma      | 1000  |   136.3 μs |   6.67 μs |  4.41 μs |  0.80 |    0.03 |   6.8359 |       - |  125.64 KB |        0.23 |
| NativeSingle      | Dwma      | 1000  |   170.4 μs |   3.20 μs |  2.11 μs |  1.00 |    0.02 |  32.2266 |  0.9766 |  540.12 KB |        1.00 |
| NativeParallel    | Dwma      | 1000  |   158.4 μs |   5.63 μs |  3.35 μs |  0.93 |    0.02 |  36.1328 |  0.9766 |  588.75 KB |        1.09 |
|                   |           |       |            |           |          |       |         |          |         |            |             |
| **BuilderFull**       | **Dwma**      | **10000** |   **857.4 μs** |  **85.21 μs** | **56.36 μs** |  **0.51** |    **0.03** |  **93.7500** | **39.0625** | **1609.04 KB** |        **0.30** |
| BuilderLatestOnly | Dwma      | 10000 |   802.6 μs |  47.81 μs | 25.01 μs |  0.47 |    0.01 |  62.5000 |  7.8125 |  1139.2 KB |        0.21 |
| NativeSingle      | Dwma      | 10000 | 1,692.9 μs |  32.43 μs | 16.96 μs |  1.00 |    0.01 | 328.1250 | 62.5000 | 5441.01 KB |        1.00 |
| NativeParallel    | Dwma      | 10000 | 1,064.9 μs | 112.04 μs | 74.11 μs |  0.63 |    0.04 | 335.9375 | 62.5000 | 5489.94 KB |        1.01 |
