```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation | Count | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated  | Alloc Ratio |
|------------------ |---------- |------ |----------:|----------:|----------:|------:|--------:|---------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Wma**       | **1000**  |  **18.71 μs** |  **5.328 μs** |  **3.524 μs** |  **0.25** |    **0.05** |   **2.9297** |       **-** |   **58.49 KB** |        **0.23** |
| BuilderLatestOnly | Wma       | 1000  |  10.73 μs |  1.689 μs |  1.117 μs |  0.14 |    0.02 |   0.6104 |       - |   10.56 KB |        0.04 |
| NativeSingle      | Wma       | 1000  |  75.70 μs |  4.864 μs |  3.217 μs |  1.00 |    0.06 |  15.1367 |  0.4883 |  254.32 KB |        1.00 |
| NativeParallel    | Wma       | 1000  |  59.56 μs |  3.079 μs |  1.610 μs |  0.79 |    0.04 |  16.1133 |  0.4883 |  261.98 KB |        1.03 |
|                   |           |       |           |           |           |       |         |          |         |            |             |
| **BuilderFull**       | **Wma**       | **10000** | **115.91 μs** | **11.669 μs** |  **7.718 μs** |  **0.16** |    **0.01** |  **33.2031** | **11.7188** |  **550.98 KB** |        **0.21** |
| BuilderLatestOnly | Wma       | 10000 |  89.78 μs |  6.955 μs |  4.600 μs |  0.12 |    0.01 |   4.8828 |  0.4883 |   80.88 KB |        0.03 |
| NativeSingle      | Wma       | 10000 | 718.53 μs | 19.507 μs | 10.202 μs |  1.00 |    0.02 | 156.2500 | 31.2500 | 2564.14 KB |        1.00 |
| NativeParallel    | Wma       | 10000 | 474.63 μs | 36.624 μs | 24.224 μs |  0.66 |    0.03 | 156.2500 | 31.2500 | 2571.95 KB |        1.00 |
