```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |----------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetRocWb** | **1000**  |   **475.4 μs** |  **5.71 μs** |  **2.99 μs** |       **-** |  **105.38 KB** |
| BuilderLatestOnly | Skender.GetRocWb | 1000  |   459.0 μs |  2.85 μs |  1.49 μs |       - |   57.74 KB |
| **BuilderFull**       | **Skender.GetRocWb** | **10000** | **4,692.2 μs** | **24.00 μs** | **12.55 μs** | **31.2500** | **1019.98 KB** |
| BuilderLatestOnly | Skender.GetRocWb | 10000 | 4,646.8 μs | 40.20 μs | 21.02 μs | 31.2500 |  550.16 KB |
