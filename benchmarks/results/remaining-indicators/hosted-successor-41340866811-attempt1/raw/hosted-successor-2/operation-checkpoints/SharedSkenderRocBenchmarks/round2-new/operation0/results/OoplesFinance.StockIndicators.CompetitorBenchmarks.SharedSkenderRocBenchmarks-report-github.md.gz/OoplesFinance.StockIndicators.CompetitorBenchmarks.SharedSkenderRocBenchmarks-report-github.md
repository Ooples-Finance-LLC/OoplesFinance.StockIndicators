```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated  | Alloc Ratio |
|------------------ |----------------- |------ |------------:|-----------:|-----------:|------:|--------:|---------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetRocWb** | **1000**  |   **410.03 μs** |   **3.830 μs** |   **2.279 μs** |  **7.54** |    **0.14** |        **-** |        **-** |        **-** |  **105.38 KB** |        **0.46** |
| BuilderLatestOnly | Skender.GetRocWb | 1000  |   407.13 μs |   2.104 μs |   1.100 μs |  7.49 |    0.13 |        - |        - |        - |   57.74 KB |        0.25 |
| NativeSingle      | Skender.GetRocWb | 1000  |    54.41 μs |   1.501 μs |   0.993 μs |  1.00 |    0.02 |  13.6719 |   3.4180 |        - |  231.09 KB |        1.00 |
| NativeParallel    | Skender.GetRocWb | 1000  |   104.45 μs |   3.337 μs |   1.746 μs |  1.92 |    0.04 |  37.1094 |  11.7188 |        - |  586.66 KB |        2.54 |
|                   |                  |       |             |            |            |       |         |          |          |          |            |             |
| **BuilderFull**       | **Skender.GetRocWb** | **10000** | **4,176.79 μs** |  **24.872 μs** |  **14.801 μs** |  **4.47** |    **0.09** |  **31.2500** |        **-** |        **-** | **1019.99 KB** |        **0.44** |
| BuilderLatestOnly | Skender.GetRocWb | 10000 | 4,115.60 μs |  52.849 μs |  31.449 μs |  4.41 |    0.09 |  31.2500 |        - |        - |  550.18 KB |        0.24 |
| NativeSingle      | Skender.GetRocWb | 10000 |   934.26 μs |  28.868 μs |  19.094 μs |  1.00 |    0.03 | 148.4375 | 148.4375 | 148.4375 | 2306.52 KB |        1.00 |
| NativeParallel    | Skender.GetRocWb | 10000 | 2,913.59 μs | 514.071 μs | 340.026 μs |  3.12 |    0.35 | 515.6250 | 453.1250 | 234.3750 | 5845.19 KB |        2.53 |
