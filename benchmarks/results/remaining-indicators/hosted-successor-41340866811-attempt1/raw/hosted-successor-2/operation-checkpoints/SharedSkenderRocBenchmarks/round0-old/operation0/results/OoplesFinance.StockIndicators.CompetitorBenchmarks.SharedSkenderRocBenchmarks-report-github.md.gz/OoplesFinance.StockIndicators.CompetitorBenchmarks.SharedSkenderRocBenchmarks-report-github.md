```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |----------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetRocWb** | **1000**  |   **427.7 μs** |  **9.79 μs** |  **5.83 μs** |       **-** |  **105.32 KB** |
| BuilderLatestOnly | Skender.GetRocWb | 1000  |   408.3 μs |  2.00 μs |  1.19 μs |       - |   57.72 KB |
| **BuilderFull**       | **Skender.GetRocWb** | **10000** | **4,206.3 μs** | **11.47 μs** |  **6.83 μs** | **31.2500** | **1019.92 KB** |
| BuilderLatestOnly | Skender.GetRocWb | 10000 | 4,181.8 μs | 36.05 μs | 23.85 μs | 31.2500 |  550.15 KB |
