```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33650/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation        | Count | Mean       | Error    | StdDev   | Gen0    | Allocated  |
|------------------ |----------------- |------ |-----------:|---------:|---------:|--------:|-----------:|
| **BuilderFull**       | **Skender.GetRocWb** | **1000**  |   **417.7 μs** |  **1.84 μs** |  **1.09 μs** |       **-** |  **105.36 KB** |
| BuilderLatestOnly | Skender.GetRocWb | 1000  |   405.3 μs |  3.46 μs |  1.81 μs |       - |   57.72 KB |
| **BuilderFull**       | **Skender.GetRocWb** | **10000** | **4,143.0 μs** | **37.18 μs** | **22.13 μs** | **31.2500** | **1019.97 KB** |
| BuilderLatestOnly | Skender.GetRocWb | 10000 | 4,112.5 μs | 14.06 μs |  7.35 μs | 31.2500 |  550.15 KB |
