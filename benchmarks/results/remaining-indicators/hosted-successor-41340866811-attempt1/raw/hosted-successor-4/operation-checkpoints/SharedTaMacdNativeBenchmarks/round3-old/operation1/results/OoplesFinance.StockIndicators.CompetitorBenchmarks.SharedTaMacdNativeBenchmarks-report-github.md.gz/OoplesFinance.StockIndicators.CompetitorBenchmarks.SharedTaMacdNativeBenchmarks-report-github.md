```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib.Functions.Macd** | **1000**  |   **432.9 μs** |  **2.33 μs** |  **1.39 μs** |       **-** |  **81.29 KB** |
| BuilderLatestOnly | TaLib.Functions.Macd | 1000  |   416.8 μs |  2.92 μs |  1.53 μs |       - |  33.66 KB |
| **BuilderFull**       | **TaLib.Functions.Macd** | **10000** | **4,215.9 μs** | **17.18 μs** | **10.22 μs** | **31.2500** | **784.95 KB** |
| BuilderLatestOnly | TaLib.Functions.Macd | 10000 | 4,191.2 μs | 15.75 μs | 10.42 μs |       - | 315.13 KB |
