```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **1000**  |   **966.3 μs** | **708.32 μs** | **370.47 μs** |  **31.2500** |        **-** |   **665.1 KB** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 1000  |   518.8 μs |  57.25 μs |  37.87 μs |  35.1563 |   3.9063 |  617.46 KB |
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **10000** | **5,068.7 μs** | **282.55 μs** | **186.89 μs** | **375.0000** | **187.5000** | **6140.94 KB** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 10000 | 4,949.0 μs | 304.63 μs | 201.50 μs | 343.7500 | 156.2500 |  5671.1 KB |
