```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean         | Error       | StdDev      | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |-------------:|------------:|------------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **1000**  |   **506.931 μs** |  **39.2231 μs** |  **20.5144 μs** | **56.66** |    **2.20** |  **31.2500** |        **-** |  **665.05 KB** |       **17.30** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 1000  |   497.737 μs |  20.3418 μs |  10.6392 μs | 55.63 |    1.19 |  35.1563 |   3.9063 |  617.46 KB |       16.06 |
| NativeSingle      | TaLib(...)cdExt [23] | 1000  |     8.947 μs |   0.1257 μs |   0.0657 μs |  1.00 |    0.01 |   2.3193 |   0.1221 |   38.45 KB |        1.00 |
| NativeParallel    | TaLib(...)cdExt [23] | 1000  |    17.531 μs |   0.4816 μs |   0.2519 μs |  1.96 |    0.03 |   8.1787 |   1.3428 |  120.22 KB |        3.13 |
|                   |                      |       |              |             |             |       |         |          |          |            |             |
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **10000** | **5,107.586 μs** | **376.8833 μs** | **249.2850 μs** | **57.20** |    **2.95** | **375.0000** | **187.5000** | **6140.93 KB** |       **15.75** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 10000 | 4,996.097 μs | 415.4911 μs | 274.8216 μs | 55.95 |    3.19 | 343.7500 | 156.2500 | 5671.11 KB |       14.54 |
| NativeSingle      | TaLib(...)cdExt [23] | 10000 |    89.341 μs |   3.2263 μs |   2.1340 μs |  1.00 |    0.03 |  23.4375 |   7.8125 |  390.02 KB |        1.00 |
| NativeParallel    | TaLib(...)cdExt [23] | 10000 |   169.859 μs |   7.5587 μs |   4.9996 μs |  1.90 |    0.07 |  76.1719 |  33.2031 | 1210.07 KB |        3.10 |
