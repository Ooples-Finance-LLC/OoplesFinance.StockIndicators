```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error     | StdDev    | Gen0     | Gen1     | Allocated  |
|------------------ |--------------------- |------ |-----------:|----------:|----------:|---------:|---------:|-----------:|
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **1000**  | **1,024.4 μs** |  **63.54 μs** |  **42.03 μs** |  **31.2500** |        **-** |   **665.1 KB** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 1000  |   528.9 μs |  63.14 μs |  41.76 μs |  35.1563 |   3.9063 |  617.46 KB |
| **BuilderFull**       | **TaLib(...)cdExt [23]** | **10000** | **5,601.0 μs** | **560.16 μs** | **333.34 μs** | **375.0000** | **187.5000** | **6140.94 KB** |
| BuilderLatestOnly | TaLib(...)cdExt [23] | 10000 | 5,700.8 μs | 855.14 μs | 565.62 μs | 333.3333 | 133.3333 | 5671.38 KB |
