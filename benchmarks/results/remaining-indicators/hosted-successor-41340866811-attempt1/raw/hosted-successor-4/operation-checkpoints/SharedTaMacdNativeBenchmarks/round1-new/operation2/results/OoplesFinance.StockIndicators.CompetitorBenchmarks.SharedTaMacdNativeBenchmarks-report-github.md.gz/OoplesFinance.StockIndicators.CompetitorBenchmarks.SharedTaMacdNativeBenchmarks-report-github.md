```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **1000**  |   **424.4 μs** |  **4.69 μs** |  **2.79 μs** |       **-** |  **81.36 KB** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 1000  |   406.3 μs |  4.93 μs |  2.58 μs |       - |  33.72 KB |
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **10000** | **4,187.7 μs** | **26.19 μs** | **15.59 μs** | **31.2500** | **785.03 KB** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 10000 | 4,098.4 μs | 28.63 μs | 14.97 μs |       - | 315.19 KB |
