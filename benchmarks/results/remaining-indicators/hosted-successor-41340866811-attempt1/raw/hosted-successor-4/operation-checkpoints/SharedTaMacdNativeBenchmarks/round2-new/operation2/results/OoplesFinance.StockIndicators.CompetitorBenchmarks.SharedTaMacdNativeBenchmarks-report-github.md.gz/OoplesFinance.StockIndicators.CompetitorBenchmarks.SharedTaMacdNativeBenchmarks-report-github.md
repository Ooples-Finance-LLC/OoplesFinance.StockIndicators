```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **1000**  |   **422.69 μs** |  **1.671 μs** |  **0.995 μs** | **35.77** |    **0.47** |       **-** |       **-** |   **81.32 KB** |        **2.13** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 1000  |   408.85 μs |  6.152 μs |  4.069 μs | 34.60 |    0.56 |       - |       - |   33.72 KB |        0.88 |
| NativeSingle      | TaLib(...)cdFix [23] | 1000  |    11.82 μs |  0.243 μs |  0.161 μs |  1.00 |    0.02 |  2.3193 |  0.1221 |   38.27 KB |        1.00 |
| NativeParallel    | TaLib(...)cdFix [23] | 1000  |    18.14 μs |  0.559 μs |  0.370 μs |  1.54 |    0.04 |  7.9346 |  1.2207 |  119.47 KB |        3.12 |
|                   |                      |       |             |           |           |       |         |         |         |            |             |
| **BuilderFull**       | **TaLib(...)cdFix [23]** | **10000** | **4,214.40 μs** | **46.697 μs** | **27.789 μs** | **36.11** |    **0.43** | **31.2500** |       **-** |  **785.03 KB** |        **2.01** |
| BuilderLatestOnly | TaLib(...)cdFix [23] | 10000 | 4,115.46 μs | 19.764 μs | 13.073 μs | 35.27 |    0.38 |       - |       - |  315.19 KB |        0.81 |
| NativeSingle      | TaLib(...)cdFix [23] | 10000 |   116.71 μs |  1.898 μs |  1.256 μs |  1.00 |    0.01 | 23.4375 |       - |  389.84 KB |        1.00 |
| NativeParallel    | TaLib(...)cdFix [23] | 10000 |   196.03 μs |  5.772 μs |  3.435 μs |  1.68 |    0.03 | 74.2188 | 31.2500 | 1209.33 KB |        3.10 |
