```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error     | StdDev   | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|----------:|---------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **TaLib.Functions.Macd** | **1000**  |   **407.57 μs** |  **1.660 μs** | **0.868 μs** | **33.83** |    **0.27** |       **-** |       **-** |   **81.29 KB** |        **2.12** |
| BuilderLatestOnly | TaLib.Functions.Macd | 1000  |   406.35 μs |  3.283 μs | 1.717 μs | 33.73 |    0.29 |       - |       - |   33.66 KB |        0.88 |
| NativeSingle      | TaLib.Functions.Macd | 1000  |    12.05 μs |  0.187 μs | 0.098 μs |  1.00 |    0.01 |  1.9531 |       - |   38.27 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Macd | 1000  |    18.96 μs |  0.933 μs | 0.617 μs |  1.57 |    0.05 |  7.9346 |  1.2207 |  119.47 KB |        3.12 |
|                   |                      |       |             |           |          |       |         |         |         |            |             |
| **BuilderFull**       | **TaLib.Functions.Macd** | **10000** | **4,050.70 μs** | **10.378 μs** | **6.176 μs** | **34.39** |    **0.30** | **31.2500** |       **-** |  **784.97 KB** |        **2.01** |
| BuilderLatestOnly | TaLib.Functions.Macd | 10000 | 4,078.21 μs | 14.617 μs | 7.645 μs | 34.62 |    0.30 |       - |       - |  315.13 KB |        0.81 |
| NativeSingle      | TaLib.Functions.Macd | 10000 |   117.79 μs |  1.596 μs | 1.056 μs |  1.00 |    0.01 | 23.4375 |       - |  389.84 KB |        1.00 |
| NativeParallel    | TaLib.Functions.Macd | 10000 |   200.65 μs | 14.216 μs | 9.403 μs |  1.70 |    0.08 | 74.2188 | 33.2031 | 1209.33 KB |        3.10 |
