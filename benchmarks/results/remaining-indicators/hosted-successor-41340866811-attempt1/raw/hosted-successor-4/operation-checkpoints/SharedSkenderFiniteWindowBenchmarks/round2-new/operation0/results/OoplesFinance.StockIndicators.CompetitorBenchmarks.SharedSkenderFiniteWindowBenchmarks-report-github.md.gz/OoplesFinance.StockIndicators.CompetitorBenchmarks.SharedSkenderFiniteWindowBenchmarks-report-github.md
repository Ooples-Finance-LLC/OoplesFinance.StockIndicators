```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error      | StdDev     | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|-----------:|-----------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetCci** | **1000**  |   **435.01 μs** | **285.795 μs** | **189.036 μs** |  **5.03** |    **2.08** |       **-** |       **-** |   **66.74 KB** |        **0.46** |
| BuilderLatestOnly | Skender.GetCci | 1000  |   216.33 μs |  11.304 μs |   7.477 μs |  2.50 |    0.08 |       - |       - |   19.13 KB |        0.13 |
| NativeSingle      | Skender.GetCci | 1000  |    86.53 μs |   1.174 μs |   0.699 μs |  1.00 |    0.01 |  8.7891 |  1.9531 |  145.01 KB |        1.00 |
| NativeParallel    | Skender.GetCci | 1000  |    69.03 μs |   6.971 μs |   4.611 μs |  0.80 |    0.05 |  9.7656 |  1.9531 |  162.64 KB |        1.12 |
|                   |                |       |             |            |            |       |         |         |         |            |             |
| **BuilderFull**       | **Skender.GetCci** | **10000** | **1,689.13 μs** | **175.419 μs** | **104.389 μs** |  **1.76** |    **0.10** | **31.2500** | **15.6250** |   **629.7 KB** |        **0.44** |
| BuilderLatestOnly | Skender.GetCci | 10000 | 1,689.90 μs | 185.763 μs | 122.871 μs |  1.76 |    0.12 |       - |       - |  159.87 KB |        0.11 |
| NativeSingle      | Skender.GetCci | 10000 |   958.70 μs |  13.175 μs |   7.840 μs |  1.00 |    0.01 | 85.9375 | 39.0625 | 1445.85 KB |        1.00 |
| NativeParallel    | Skender.GetCci | 10000 |   571.94 μs |  46.051 μs |  30.460 μs |  0.60 |    0.03 | 97.6563 | 39.0625 | 1533.76 KB |        1.06 |
