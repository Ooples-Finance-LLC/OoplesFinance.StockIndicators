```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean       | Error     | StdDev   | Gen0    | Gen1    | Allocated |
|------------------ |--------------- |------ |-----------:|----------:|---------:|--------:|--------:|----------:|
| **BuilderFull**       | **Skender.GetCci** | **1000**  |   **223.7 μs** |  **52.05 μs** | **34.43 μs** |       **-** |       **-** |  **66.78 KB** |
| BuilderLatestOnly | Skender.GetCci | 1000  |   202.6 μs |  21.12 μs | 13.97 μs |       - |       - |  19.13 KB |
| **BuilderFull**       | **Skender.GetCci** | **10000** | **1,763.2 μs** |  **94.33 μs** | **56.13 μs** | **31.2500** | **15.6250** |  **629.7 KB** |
| BuilderLatestOnly | Skender.GetCci | 10000 | 1,747.0 μs | 125.02 μs | 74.40 μs |       - |       - | 159.87 KB |
