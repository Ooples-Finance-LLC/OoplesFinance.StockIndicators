```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId        | Mean       | Error       | StdDev      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|------- |------ |-------------- |-----------:|------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples** | **1000**  | **Skender.GetT3** |   **917.4 μs** |    **39.64 μs** |    **23.59 μs** |  **1.00** |    **0.03** |  **105.89 KB** |        **1.00** |
|        |       |               |            |             |             |       |         |            |             |
| **Ooples** | **10000** | **Skender.GetT3** | **8,685.3 μs** | **1,782.07 μs** | **1,178.73 μs** |  **1.02** |    **0.18** | **1037.23 KB** |        **1.00** |
