```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId           | Mean        | Error        | StdDev       | Median      | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |----------------- |------------:|-------------:|-------------:|------------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetRocWb** |  **4,086.6 μs** |     **57.84 μs** |     **34.42 μs** |  **4,092.6 μs** |  **1.00** |    **0.01** |  **172.63 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetRocWb |    798.1 μs |     49.01 μs |     29.16 μs |    800.7 μs |  0.20 |    0.01 |  275.04 KB |        1.59 |
|            |       |                  |             |              |              |             |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetRocWb** | **32,654.9 μs** | **23,007.28 μs** | **15,217.89 μs** | **37,113.3 μs** |  **1.31** |    **1.01** | **1692.23 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetRocWb |  4,434.0 μs |  3,831.54 μs |  2,534.33 μs |  5,423.9 μs |  0.18 |    0.15 | 2666.65 KB |        1.58 |
