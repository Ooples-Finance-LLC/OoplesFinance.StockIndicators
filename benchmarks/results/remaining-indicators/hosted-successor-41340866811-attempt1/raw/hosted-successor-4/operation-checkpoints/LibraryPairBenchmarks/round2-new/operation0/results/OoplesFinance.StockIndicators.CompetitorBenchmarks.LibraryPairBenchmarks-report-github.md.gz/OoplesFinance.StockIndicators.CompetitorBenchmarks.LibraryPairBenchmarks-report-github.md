```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId         | Mean        | Error     | StdDev    | Ratio | RatioSD | Allocated   | Alloc Ratio |
|----------- |------ |--------------- |------------:|----------:|----------:|------:|--------:|------------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetPrs** |  **3,140.6 μs** | **112.13 μs** |  **66.73 μs** |  **1.00** |    **0.03** |  **1079.65 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetPrs |    848.8 μs |  33.35 μs |  19.85 μs |  0.27 |    0.01 |   255.94 KB |        0.24 |
|            |       |                |             |           |           |       |         |             |             |
| **Ooples**     | **10000** | **Skender.GetPrs** | **29,569.3 μs** | **621.47 μs** | **325.04 μs** |  **1.00** |    **0.01** | **10607.02 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetPrs | 11,170.2 μs | 119.52 μs |  62.51 μs |  0.38 |    0.00 |  2461.99 KB |        0.23 |
