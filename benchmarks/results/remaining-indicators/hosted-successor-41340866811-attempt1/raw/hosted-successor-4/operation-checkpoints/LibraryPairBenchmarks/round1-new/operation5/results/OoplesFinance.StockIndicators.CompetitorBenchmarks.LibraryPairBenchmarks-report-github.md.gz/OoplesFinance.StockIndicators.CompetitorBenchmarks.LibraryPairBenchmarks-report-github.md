```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method | Bars  | PairId               | Mean      | Error      | StdDev    | Median   | Ratio | RatioSD | Allocated | Alloc Ratio |
|------- |------ |--------------------- |----------:|-----------:|----------:|---------:|------:|--------:|----------:|------------:|
| **Ooples** | **1000**  | **Skend(...)Bands [21]** |  **2.505 ms** |  **0.0284 ms** | **0.0169 ms** | **2.497 ms** |  **1.00** |    **0.01** | **219.61 KB** |        **1.00** |
|        |       |                      |           |            |           |          |       |         |           |             |
| **Ooples** | **10000** | **Skend(...)Bands [21]** | **10.824 ms** | **11.1417 ms** | **7.3696 ms** | **7.456 ms** |  **1.46** |    **1.34** | **2152.9 KB** |        **1.00** |
