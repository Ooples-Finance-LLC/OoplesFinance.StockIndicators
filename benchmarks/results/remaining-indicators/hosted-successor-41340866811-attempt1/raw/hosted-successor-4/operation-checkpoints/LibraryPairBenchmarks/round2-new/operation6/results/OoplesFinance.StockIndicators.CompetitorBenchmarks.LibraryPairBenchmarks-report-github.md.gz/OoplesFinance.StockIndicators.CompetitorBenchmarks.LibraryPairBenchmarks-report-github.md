```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId        | Mean       | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |-------------- |-----------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skender.GetT3** |   **903.7 μs** |  **19.25 μs** |  **10.07 μs** |  **1.00** |    **0.01** |  **105.89 KB** |        **1.00** |
| Competitor | 1000  | Skender.GetT3 |   938.9 μs |  46.05 μs |  30.46 μs |  1.04 |    0.03 |  115.04 KB |        1.09 |
|            |       |               |            |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skender.GetT3** | **3,302.5 μs** | **476.59 μs** | **283.61 μs** |  **1.01** |    **0.11** | **1037.23 KB** |        **1.00** |
| Competitor | 10000 | Skender.GetT3 | 1,168.0 μs |  44.02 μs |  26.19 μs |  0.36 |    0.03 | 1073.66 KB |        1.04 |
