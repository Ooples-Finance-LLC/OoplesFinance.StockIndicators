```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean       | Error     | StdDev   | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |-----------:|----------:|---------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)lysis [22]** | **4,604.1 μs** | **100.00 μs** | **66.14 μs** |  **1.00** |    **0.02** |  **298.85 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)lysis [22] |   757.2 μs |  26.70 μs | 15.89 μs |  0.16 |    0.00 |  291.85 KB |        0.98 |
|            |       |                      |            |           |          |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)lysis [22]** | **3,899.1 μs** |  **92.18 μs** | **48.21 μs** |  **1.00** |    **0.02** | **2876.71 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)lysis [22] | 1,372.0 μs |  29.76 μs | 19.69 μs |  0.35 |    0.01 |  2823.1 KB |        0.98 |
