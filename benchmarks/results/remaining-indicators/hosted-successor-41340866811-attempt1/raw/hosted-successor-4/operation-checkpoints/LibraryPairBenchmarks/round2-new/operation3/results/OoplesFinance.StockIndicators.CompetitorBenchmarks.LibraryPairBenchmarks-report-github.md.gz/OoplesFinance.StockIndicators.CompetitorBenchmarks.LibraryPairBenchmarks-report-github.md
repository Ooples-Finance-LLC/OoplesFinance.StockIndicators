```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  Toolchain=InProcessEmitToolchain  InvocationCount=1  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method     | Bars  | PairId               | Mean     | Error     | StdDev    | Ratio | RatioSD | Allocated  | Alloc Ratio |
|----------- |------ |--------------------- |---------:|----------:|----------:|------:|--------:|-----------:|------------:|
| **Ooples**     | **1000**  | **Skend(...)ivots [24]** | **2.188 ms** | **0.0356 ms** | **0.0212 ms** |  **1.00** |    **0.01** |   **388.2 KB** |        **1.00** |
| Competitor | 1000  | Skend(...)ivots [24] | 2.199 ms | 0.0588 ms | 0.0350 ms |  1.00 |    0.02 |  738.82 KB |        1.90 |
|            |       |                      |          |           |           |       |         |            |             |
| **Ooples**     | **10000** | **Skend(...)ivots [24]** | **5.190 ms** | **2.1111 ms** | **1.3964 ms** |  **1.05** |    **0.35** | **3850.13 KB** |        **1.00** |
| Competitor | 10000 | Skend(...)ivots [24] | 8.941 ms | 0.2102 ms | 0.1099 ms |  1.82 |    0.38 | 7321.55 KB |        1.90 |
