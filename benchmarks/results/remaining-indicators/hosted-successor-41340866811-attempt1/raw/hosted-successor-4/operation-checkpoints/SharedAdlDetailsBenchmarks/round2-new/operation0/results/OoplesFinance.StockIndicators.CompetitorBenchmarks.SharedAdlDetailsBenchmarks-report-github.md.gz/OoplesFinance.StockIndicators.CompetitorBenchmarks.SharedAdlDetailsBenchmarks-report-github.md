```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation      | Count | Mean        | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated  | Alloc Ratio |
|------------------ |--------------- |------ |------------:|----------:|----------:|------:|--------:|---------:|---------:|-----------:|------------:|
| **BuilderFull**       | **Skender.GetAdl** | **1000**  |    **58.21 μs** |  **0.857 μs** |  **0.510 μs** |  **0.76** |    **0.01** |   **3.9063** |        **-** |   **88.31 KB** |        **0.50** |
| BuilderLatestOnly | Skender.GetAdl | 1000  |    55.19 μs |  0.425 μs |  0.281 μs |  0.72 |    0.01 |   2.4414 |        - |    40.7 KB |        0.23 |
| NativeSingle      | Skender.GetAdl | 1000  |    76.64 μs |  2.024 μs |  1.338 μs |  1.00 |    0.02 |  10.7422 |   2.4414 |  176.21 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 1000  |   145.78 μs |  9.746 μs |  5.800 μs |  1.90 |    0.08 |  27.3438 |   7.8125 |  449.41 KB |        2.55 |
|                   |                |       |             |           |           |       |         |          |          |            |             |
| **BuilderFull**       | **Skender.GetAdl** | **10000** |   **574.69 μs** |  **6.941 μs** |  **4.591 μs** |  **0.66** |    **0.01** |  **50.7813** |  **15.6250** |  **862.13 KB** |        **0.49** |
| BuilderLatestOnly | Skender.GetAdl | 10000 |   540.87 μs | 10.212 μs |  6.077 μs |  0.62 |    0.01 |  23.4375 |   7.8125 |  392.31 KB |        0.22 |
| NativeSingle      | Skender.GetAdl | 10000 |   873.74 μs | 21.231 μs | 14.043 μs |  1.00 |    0.02 | 101.5625 |  62.5000 |  1758.3 KB |        1.00 |
| NativeParallel    | Skender.GetAdl | 10000 | 1,477.95 μs | 96.201 μs | 63.631 μs |  1.69 |    0.07 | 273.4375 | 195.3125 | 4474.84 KB |        2.54 |
