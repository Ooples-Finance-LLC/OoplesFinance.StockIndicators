```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean       | Error    | StdDev   | Gen0    | Allocated |
|------------------ |--------------------- |------ |-----------:|---------:|---------:|--------:|----------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |   **516.6 μs** |  **7.98 μs** |  **4.75 μs** |       **-** |  **73.64 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |   529.4 μs |  6.49 μs |  4.29 μs |       - |  26.05 KB |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** | **5,130.2 μs** | **23.74 μs** | **14.13 μs** | **31.2500** | **707.05 KB** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 | 5,149.7 μs | 14.84 μs |  8.83 μs |       - | 237.19 KB |
