```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev      | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|------------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)gence [34]** | **1000**  |    **510.0 μs** |     **0.96 μs** |     **0.57 μs** |  **0.26** |    **0.00** |         **-** |         **-** |         **-** |   **105.03 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)gence [34] | 1000  |    509.7 μs |     0.88 μs |     0.53 μs |  0.26 |    0.00 |         - |         - |         - |    57.39 KB |        0.02 |
| NativeSingle      | Movin(...)gence [34] | 1000  |  1,965.7 μs |    24.51 μs |    14.58 μs |  1.00 |    0.01 |  203.1250 |  140.6250 |   46.8750 |  3232.05 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 1000  |  1,750.5 μs |    73.36 μs |    43.66 μs |  0.89 |    0.02 |  359.3750 |  171.8750 |         - |  5608.42 KB |        1.74 |
|                   |                      |       |             |             |             |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)gence [34]** | **10000** |  **5,099.1 μs** |   **114.00 μs** |    **75.40 μs** |  **0.25** |    **0.01** |   **31.2500** |         **-** |         **-** |  **1019.61 KB** |        **0.03** |
| BuilderLatestOnly | Movin(...)gence [34] | 10000 |  5,061.6 μs |   101.47 μs |    67.12 μs |  0.25 |    0.01 |   31.2500 |         - |         - |   549.84 KB |        0.02 |
| NativeSingle      | Movin(...)gence [34] | 10000 | 20,088.1 μs |   891.79 μs |   589.86 μs |  1.00 |    0.04 | 2000.0000 | 1400.0000 | 1000.0000 | 31912.57 KB |        1.00 |
| NativeParallel    | Movin(...)gence [34] | 10000 | 23,463.8 μs | 2,909.77 μs | 1,731.56 μs |  1.17 |    0.09 | 2800.0000 | 1800.0000 | 1000.0000 | 55443.45 KB |        1.74 |
