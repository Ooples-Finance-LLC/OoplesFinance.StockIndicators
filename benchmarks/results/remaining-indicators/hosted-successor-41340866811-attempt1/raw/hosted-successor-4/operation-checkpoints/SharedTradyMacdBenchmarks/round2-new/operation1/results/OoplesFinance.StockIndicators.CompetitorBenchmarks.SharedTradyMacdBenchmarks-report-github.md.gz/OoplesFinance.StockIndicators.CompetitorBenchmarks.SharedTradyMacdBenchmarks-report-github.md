```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26100.33674/24H2/2024Update/HudsonValley) (Hyper-V)
AMD EPYC 7763 2.44GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.403
  [Host] : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v3

Job=ShortRun  MinIterationTime=100ms  Toolchain=InProcessEmitToolchain  
IterationCount=10  LaunchCount=1  UnrollFactor=1  
WarmupCount=10  

```
| Method            | Operation            | Count | Mean        | Error       | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated   | Alloc Ratio |
|------------------ |--------------------- |------ |------------:|------------:|----------:|------:|--------:|----------:|----------:|----------:|------------:|------------:|
| **BuilderFull**       | **Movin(...)ogram [43]** | **1000**  |    **488.3 μs** |     **3.26 μs** |   **1.94 μs** |  **0.24** |    **0.00** |         **-** |         **-** |         **-** |    **73.68 KB** |       **0.022** |
| BuilderLatestOnly | Movin(...)ogram [43] | 1000  |    483.1 μs |     1.32 μs |   0.78 μs |  0.24 |    0.00 |         - |         - |         - |    26.05 KB |       0.008 |
| NativeSingle      | Movin(...)ogram [43] | 1000  |  2,050.5 μs |    18.64 μs |  12.33 μs |  1.00 |    0.01 |  203.1250 |  109.3750 |   46.8750 |  3389.08 KB |       1.000 |
| NativeParallel    | Movin(...)ogram [43] | 1000  |  1,912.1 μs |   161.76 μs | 107.00 μs |  0.93 |    0.05 |  359.3750 |  187.5000 |         - |  5597.51 KB |       1.652 |
|                   |                      |       |             |             |           |       |         |           |           |           |             |             |
| **BuilderFull**       | **Movin(...)ogram [43]** | **10000** |  **4,822.0 μs** |    **21.41 μs** |  **11.20 μs** |  **0.22** |    **0.01** |   **31.2500** |         **-** |         **-** |   **707.04 KB** |       **0.021** |
| BuilderLatestOnly | Movin(...)ogram [43] | 10000 |  4,773.7 μs |    21.42 μs |  12.75 μs |  0.22 |    0.01 |         - |         - |         - |   237.22 KB |       0.007 |
| NativeSingle      | Movin(...)ogram [43] | 10000 | 21,691.2 μs | 1,406.97 μs | 930.62 μs |  1.00 |    0.06 | 2000.0000 | 1400.0000 | 1000.0000 |  33358.1 KB |       1.000 |
| NativeParallel    | Movin(...)ogram [43] | 10000 | 23,046.0 μs | 1,309.97 μs | 779.54 μs |  1.06 |    0.05 | 3200.0000 | 2400.0000 | 1400.0000 | 55282.43 KB |       1.657 |
