from pathlib import Path
import textwrap

def build(helper,state):
 needle='        private readonly ulong _denominator, _reciprocal;'
 assert helper.count(needle)==1
 helper=helper.replace(needle,needle+'\n\n        internal bool IsSupported => _denominator != 0;')
 start=helper.index('            const ulong fractionMask = (1UL << 52) - 1;')
 end=helper.index('            return true;\n        }\n    }',start)
 core=helper[start:end]
 assert core.count('            result = BitConverter.Int64BitsToDouble(')==1
 core=core.replace('            result = BitConverter.Int64BitsToDouble(', '            return BitConverter.Int64BitsToDouble(')
 replacement='''            result = SmoothSameBinade(priorBits, inputBits, exponent);
            return true;
        }

        // Caller establishes a supported period and positive normal operands
        // with this same exponent. Convex means preserve the binade.
        internal double SmoothSameBinade(ulong priorBits, ulong inputBits, ulong exponent)
        {
            // n <= 2^64-2048, q*d <= n, and the corrected remainder < d.
            // The rounded significand remains below 2^53. These proven bounds
            // make arithmetic overflow checks redundant inside this kernel.
            unchecked
            {
'''+textwrap.indent(core,'    ')+'            }\n        }\n'
 helper=helper[:start]+replacement+helper[end+len('            return true;\n        }\n'):]
 # The existing factor and alignment guards bound every polynomial product
 # below 2^125. Preserve its operations and guards, changing only the local
 # overflow-check context; the shared exact publisher remains untouched.
 start=helper.index('        Int128 first = 3 * (av - bv), second = 3 * (av - 2 * bv + cv);')
 end=helper.index('    }\n\n    private static bool Align',start)
 body=helper[start:end]
 helper=helper[:start]+'        // Alignment and factor guards bound every product below 2^125.\n        unchecked\n        {\n'+textwrap.indent(body,'    ')+'        }\n'+helper[end:]
 start=helper.index('        if (weight < 0) (low, high) = (high, low);')
 end=helper.index('\n    }\n',start)+1
 body=helper[start:end]
 helper=helper[:start]+'        unchecked\n        {\n'+textwrap.indent(body,'    ')+'        }\n'+helper[end:]
 def replace(a,b,count=1):
  nonlocal state
  assert state.count(a)==count,a
  state=state.replace(a,b)
 replace('        private long _index = -1;','        private long _index = -1;\n        private ulong _wordExponent;')
 replace('            _index = -1;','            _index = -1;\n            _wordExponent = 0;')
 replace('            double value = bar.Close;','''            double value = bar.Close;
            bool cached = _wordExponent != 0
                && unchecked((ulong)BitConverter.DoubleToInt64Bits(value)) >> 52 == _wordExponent;
            if (!cached) _wordExponent = 0;''')
 replace('Smooth(_stages[j], value)','Smooth(_stages[j], value, cached)',2)
 replace('            for (int j = 0; j < 6; j++)','            for (int j = 0; j < _stages.Length; j++)')
 replace('            if (_index < _first) return;','''            // Prefix seeds are not convex updates of the prior published
            // stage. Establish the invariant only after all seed windows end.
            // CascadedMeans returns above until every stage has been seeded.
            if (_wordExponent == 0 && _wordSmoother.IsSupported
                && (_seed == TillsonSeed.FirstPrice || _index >= _period - 1L))
                _wordExponent = CommonWordExponent();
            if (_index < _first) return;''')
 replace('''        private double Smooth(double prior, double input)
        {''','''        private ulong CommonWordExponent()
        {
            ulong exponent = unchecked((ulong)BitConverter.DoubleToInt64Bits(_stages[0])) >> 52;
            if (exponent is 0 or > 2046) return 0;
            for (int j = 1; j < 6; j++)
                if (unchecked((ulong)BitConverter.DoubleToInt64Bits(_stages[j])) >> 52 != exponent) return 0;
            return exponent;
        }

        private double Smooth(double prior, double input, bool cached)
        {
            if (cached) return _wordSmoother.SmoothSameBinade(
                unchecked((ulong)BitConverter.DoubleToInt64Bits(prior)),
                unchecked((ulong)BitConverter.DoubleToInt64Bits(input)), _wordExponent);''')
 return helper,state

if __name__=='__main__':
 root=Path('C:/Users/cheat/StockIndicators-Recovery-20261021')
 repo=Path('C:/Users/cheat/source/repos/Ooples-Finance-LLC/si-parabolic-array-rollback-20261022')
 draft=root/'t3-word-binade-draft-20261024';draft.mkdir(exist_ok=True)
 helper,state=build((repo/'src/Helpers/CertifiedTillson.cs').read_text(),(repo/'src/Indicators/ValuesBarExecution.Tillson.cs').read_text())
 (draft/'CertifiedTillson.cs').write_text(helper,encoding='utf-8',newline='\n')
 (draft/'ValuesBarExecution.Tillson.cs').write_text(state,encoding='utf-8',newline='\n')
 print('Prepared prototype only; regenerate from actual published baseline after polynomial outcome.')
