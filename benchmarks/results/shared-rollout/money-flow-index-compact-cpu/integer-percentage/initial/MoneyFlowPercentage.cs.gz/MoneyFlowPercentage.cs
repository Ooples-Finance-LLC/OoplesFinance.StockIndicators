#if !NETFRAMEWORK
using System.Numerics;

namespace OoplesFinance.StockIndicators.Helpers;

// Exact publication for the certified Int64 MFI recurrence. The factor 100
// needs at most 70 numerator bits; the denominator needs at most 64. Their
// quotient is always normal, and its 53-bit rounding division fits UInt128.
internal static class MoneyFlowPercentage
{
    internal static double Calculate(long positive, long total)
    {
        if (positive == 0 || total == 0) return 0;
        bool negative = (positive < 0) != (total < 0);
        ulong magnitude = positive < 0 ? unchecked((ulong)-positive) : (ulong)positive;
        ulong denominator = total < 0 ? unchecked((ulong)-total) : (ulong)total;
        UInt128 numerator = (UInt128)magnitude * 100;
        ulong upper = (ulong)(numerator >> 64);
        int numeratorBits = upper == 0 ? 64 - BitOperations.LeadingZeroCount((ulong)numerator)
            : 128 - BitOperations.LeadingZeroCount(upper);
        int power = numeratorBits - (64 - BitOperations.LeadingZeroCount(denominator));
        if (power >= 0 ? numerator < ((UInt128)denominator << power)
            : (numerator << -power) < denominator) power--;
        int shift = 52 - power;
        // A left-shifted numerator has at most 117 bits. When shift is
        // negative, the shifted denominator has at most 18 bits.
        if (shift >= 0) numerator <<= shift;
        else denominator <<= -shift;
        var (quotient, remainder) = ExactMeanAccumulator.CompactDivRem(numerator, denominator);
        var complement = denominator - remainder;
        if (remainder > complement || remainder == complement && (quotient & 1) != 0) quotient++;
        // Encode handles a carry to the next binade. No floating-point
        // estimate, operand rounding, or second scaling round is involved.
        return ExactMeanAccumulator.Encode((ulong)quotient, power + 1022, negative);
    }
}
#endif
